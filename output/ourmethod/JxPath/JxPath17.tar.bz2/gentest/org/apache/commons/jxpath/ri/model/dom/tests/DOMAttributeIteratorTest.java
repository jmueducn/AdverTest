package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
 
public class DOMAttributeIteratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                 public void testSetPosition_ValidPosition() {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Mock attributes
                                                                                                                                                                                                                     List<Attr> attributes = new ArrayList<>();
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set the private attributes field
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field attributesField = DOMAttributeIterator.class.getDeclaredField("attributes");
                                                                                                                                                                                                                         attributesField.setAccessible(true);
                                                                                                                                                                                                                         attributesField.set(iterator, attributes);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set attributes field via reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test valid positions
                                                                                                                                                                                                                     assertTrue(iterator.setPosition(1));
                                                                                                                                                                                                                     assertEquals(1, iterator.getPosition());
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertTrue(iterator.setPosition(2));
                                                                                                                                                                                                                     assertEquals(2, iterator.getPosition());
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertTrue(iterator.setPosition(3));
                                                                                                                                                                                                                     assertEquals(3, iterator.getPosition());
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testSetPosition_InvalidPositionBelowRange() {
                                                                                                                                                                                                                     // Setup test objects
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Setup attributes with 2 items
                                                                                                                                                                                                                     List<Attr> attributes = new ArrayList<>();
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set the private attributes field
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field attributesField = DOMAttributeIterator.class.getDeclaredField("attributes");
                                                                                                                                                                                                                         attributesField.setAccessible(true);
                                                                                                                                                                                                                         attributesField.set(iterator, attributes);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set attributes field via reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertFalse(iterator.setPosition(0));
                                                                                                                                                                                                                     assertEquals(0, iterator.getPosition()); // Assuming initial position is 0
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertFalse(iterator.setPosition(-1));
                                                                                                                                                                                                                     assertEquals(0, iterator.getPosition());
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testSetPosition_InvalidPositionAboveRange() {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Setup attributes with 2 items
                                                                                                                                                                                                                     List<Attr> attributes = new ArrayList<>();
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set the private attributes field
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field attributesField = DOMAttributeIterator.class.getDeclaredField("attributes");
                                                                                                                                                                                                                         attributesField.setAccessible(true);
                                                                                                                                                                                                                         attributesField.set(iterator, attributes);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set attributes field via reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test positions above valid range
                                                                                                                                                                                                                     assertFalse(iterator.setPosition(3));
                                                                                                                                                                                                                     assertEquals(0, iterator.getPosition());
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertFalse(iterator.setPosition(100));
                                                                                                                                                                                                                     assertEquals(0, iterator.getPosition());
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testSetPosition_AfterModifyingAttributesList() {
                                                                                                                                                                                                                     // Setup initial attributes and iterator
                                                                                                                                                                                                                     List<Attr> attributes = new ArrayList<>();
                                                                                                                                                                                                                     NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private 'attributes' field
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field attributesField = DOMAttributeIterator.class.getDeclaredField("attributes");
                                                                                                                                                                                                                         attributesField.setAccessible(true);
                                                                                                                                                                                                                         attributesField.set(iterator, attributes);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set attributes field via reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Add mock attributes
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     attributes.add(mock(Attr.class));
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertTrue(iterator.setPosition(2));
                                                                                                                                                                                                                     assertEquals(2, iterator.getPosition());
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Remove one attribute
                                                                                                                                                                                                                     attributes.remove(1);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Now position 2 should be invalid
                                                                                                                                                                                                                     assertFalse(iterator.setPosition(2));
                                                                                                                                                                                                                     assertEquals(2, iterator.getPosition()); // Position remains unchanged
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // But position 1 should still be valid
                                                                                                                                                                                                                     assertTrue(iterator.setPosition(1));
                                                                                                                                                                                                                     assertEquals(1, iterator.getPosition());
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_XmlnsPrefix_ReturnsFalse() throws Exception {
                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create iterator instance
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     QName qname = new QName("test");
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, qname);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Mock static methods
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn("xmlns");
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("someName");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private method
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertFalse(result);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_XmlnsLocalNameNoPrefix_ReturnsFalse() throws Exception {
                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     DOMNodePointer parentPointer = mock(DOMNodePointer.class);
                                                                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create the iterator instance
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Mock the static calls
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("xmlns");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private testAttr method
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertFalse(result);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_WildcardName_ReturnsTrue() throws Exception {
                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create the iterator under test
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Set up mock behavior
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn("prefix");
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getName()).thenReturn("*");
                                                                                                                                                                                                                     when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private testAttr method
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test the method
                                                                                                                                                                                                                     assertTrue((Boolean) testAttrMethod.invoke(iterator, attr));
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_MatchingNameNoPrefix_ReturnsTrue() throws Exception {
                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create the iterator under test
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Set up mock behavior
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getName()).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getPrefix()).thenReturn(null);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get the private testAttr method via reflection
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test the method
                                                                                                                                                                                                                     assertTrue((Boolean) testAttrMethod.invoke(iterator, attr));
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_MatchingNameMatchingPrefix_ReturnsTrue() throws Exception {
                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create the iterator under test
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Set up mock behavior
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn("prefix");
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getName()).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get the private testAttr method using reflection
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test the method
                                                                                                                                                                                                                     boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                                                                     assertTrue(result);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_MatchingNameDifferentPrefix_ReturnsFalse() throws Exception {
                                                                                                                                                                                                                     // Setup mock objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create the iterator under test
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Setup mock behavior
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getName()).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private testAttr method
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify the test
                                                                                                                                                                                                                     assertFalse(result);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_MatchingNameDifferentPrefixWithSameNamespace_ReturnsTrue() throws Exception {
                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create iterator instance
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Set up mock behavior
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn("attrPrefix");
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getName()).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                                                     when(parent.getNamespaceURI("testPrefix")).thenReturn("http://example.com");
                                                                                                                                                                                                                     when(parent.getNamespaceURI("attrPrefix")).thenReturn("http://example.com");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private testAttr method
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify the test
                                                                                                                                                                                                                     assertTrue(result);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_MatchingNameDifferentPrefixWithDifferentNamespace_ReturnsFalse() throws Exception {
                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Set up mock behavior
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn("attrPrefix");
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getName()).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                                                     when(parent.getNamespaceURI("testPrefix")).thenReturn("http://example.com");
                                                                                                                                                                                                                     when(parent.getNamespaceURI("attrPrefix")).thenReturn("http://different.com");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private testAttr method
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     boolean result = (boolean) testAttrMethod.invoke(iterator, attr);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify the test
                                                                                                                                                                                                                     assertFalse(result);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestAttr_NonMatchingName_ReturnsFalse() throws Exception {
                                                                                                                                                                                                                     // Setup test objects
                                                                                                                                                                                                                     Attr attr = mock(Attr.class);
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create the iterator under test
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Mock behavior
                                                                                                                                                                                                                     when(DOMNodePointer.getPrefix(attr)).thenReturn("prefix");
                                                                                                                                                                                                                     when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                                                     when(name.getName()).thenReturn("differentName");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get the private testAttr method using reflection
                                                                                                                                                                                                                     Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify the test
                                                                                                                                                                                                                     assertFalse((Boolean) testAttrMethod.invoke(iterator, attr));
                                                                                                                                                                                                                 }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                 public void testTestAttr_NullAttr_ThrowsException() throws Exception {
                                                                                                                                                                                                                     // Create a mock parent NodePointer
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     // Create a QName for the iterator
                                                                                                                                                                                                                     QName qname = new QName("test");
                                                                                                                                                                                                                     // Create the iterator instance
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, qname);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get the private testAttr method using reflection
                                                                                                                                                                                                                     Method method = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                                                                                                                                                                                     method.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Invoke the method with null input
                                                                                                                                                                                                                     method.invoke(iterator, (Attr)null);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testGetAttribute_NoPrefix() throws Exception {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                                                                                     when(name.getPrefix()).thenReturn(null);
                                                                                                                                                                                                                     when(name.getName()).thenReturn("attrName");
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     Element element = mock(Element.class);
                                                                                                                                                                                                                     Attr expectedAttr = mock(Attr.class);
                                                                                                                                                                                                                     when(element.getAttributeNode("attrName")).thenReturn(expectedAttr);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                     DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get the private method using reflection
                                                                                                                                                                                                                     Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                                                                         "getAttribute", Element.class, QName.class);
                                                                                                                                                                                                                     getAttributeMethod.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test
                                                                                                                                                                                                                     Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                     assertEquals(expectedAttr, result);
                                                                                                                                                                                                                     verify(element).getAttributeNode("attrName");
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                             public void testSetPosition_EdgeCases() throws Exception {
                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                 NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                 QName qname = new QName("test");
                                                                                                                                                                                                                 DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, qname);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Mock the attribute and setup attributes list with 1 item using reflection
                                                                                                                                                                                                                 Attr mockAttr = mock(Attr.class);
                                                                                                                                                                                                                 Field attributesField = DOMAttributeIterator.class.getDeclaredField("attributes");
                                                                                                                                                                                                                 attributesField.setAccessible(true);
                                                                                                                                                                                                                 List<Attr> attributes = new ArrayList<>();
                                                                                                                                                                                                                 attributes.add(mockAttr);
                                                                                                                                                                                                                 attributesField.set(iterator, attributes);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Lower edge
                                                                                                                                                                                                                 assertTrue(iterator.setPosition(1));
                                                                                                                                                                                                                 assertEquals(1, iterator.getPosition());
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Upper edge
                                                                                                                                                                                                                 assertFalse(iterator.setPosition(2));
                                                                                                                                                                                                                 assertEquals(1, iterator.getPosition()); // Position remains at last valid value
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                         public void testGetAttribute_EmptyAttributesList() throws Exception {
                                                                                                                                                                                                             // Setup mocks
                                                                                                                                                                                                             org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.QName name = mock(org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                                                                             org.w3c.dom.NamedNodeMap namedNodeMap = mock(org.w3c.dom.NamedNodeMap.class);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create iterator instance
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                                                                                                                                                                 new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, name);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Setup mock behavior
                                                                                                                                                                                                             when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                                             when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                                                                                                             when(namespaceResolver.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                                                                                                                                                                                             when(name.getName()).thenReturn("attrName");
                                                                                                                                                                                                             
                                                                                                                                                                                                             // First call returns null
                                                                                                                                                                                                             when(element.getAttributeNodeNS("testNS", "attrName")).thenReturn(null);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Setup empty attributes list
                                                                                                                                                                                                             when(element.getAttributes()).thenReturn(namedNodeMap);
                                                                                                                                                                                                             when(namedNodeMap.getLength()).thenReturn(0);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Use reflection to access private method
                                                                                                                                                                                                             Method getAttributeMethod = org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                                                                 "getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                             getAttributeMethod.setAccessible(true);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Test
                                                                                                                                                                                                             org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                             assertNull(result);
                                                                                                                                                                                                             verify(element).getAttributeNodeNS("testNS", "attrName");
                                                                                                                                                                                                             verify(element).getAttributes();
                                                                                                                                                                                                             verify(namedNodeMap).getLength();
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                         public void testGetAttribute_WithPrefixAndNamespace() throws Exception {
                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.QName name = mock(org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                                                                             org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                                                                                                                                                                 new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, name);
                                                                                                                                                                                                             
                                                                                                                                                                                                             when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = 
                                                                                                                                                                                                                 mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                                                                             when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                                                                                                             when(namespaceResolver.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                                                                                                                                                                                             when(name.getName()).thenReturn("attrName");
                                                                                                                                                                                                             
                                                                                                                                                                                                             org.w3c.dom.Attr expectedAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                                                                             when(element.getAttributeNodeNS("testNS", "attrName")).thenReturn(expectedAttr);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Use reflection to access private method
                                                                                                                                                                                                             java.lang.reflect.Method getAttributeMethod = 
                                                                                                                                                                                                                 org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                                                                     "getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                             getAttributeMethod.setAccessible(true);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Test
                                                                                                                                                                                                             org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                             assertEquals(expectedAttr, result);
                                                                                                                                                                                                             verify(element).getAttributeNodeNS("testNS", "attrName");
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                         public void testGetAttribute_WithPrefixButNoNamespace() throws Exception {
                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.QName name = mock(org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                                                                             org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                                                                                                                                                                 new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, name);
                                                                                                                                                                                                             
                                                                                                                                                                                                             when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = 
                                                                                                                                                                                                                 mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                                                                             when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                                                                                                             when(namespaceResolver.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                                                                                                                                                             when(name.getName()).thenReturn("attrName");
                                                                                                                                                                                                             
                                                                                                                                                                                                             org.w3c.dom.Attr expectedAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                                                                             when(element.getAttributeNode("attrName")).thenReturn(expectedAttr);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Use reflection to access private method
                                                                                                                                                                                                             java.lang.reflect.Method getAttributeMethod = 
                                                                                                                                                                                                                 org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                                                                     "getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                             getAttributeMethod.setAccessible(true);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Test
                                                                                                                                                                                                             org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                             assertEquals(expectedAttr, result);
                                                                                                                                                                                                             verify(element).getAttributeNode("attrName");
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                         public void testGetAttribute_NamespaceFallbackToAttributesList() {
                                                                                                                                                                                                             // Setup mocks
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.QName name = mock(org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                             NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                                             org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                                                                                                                             org.w3c.dom.NamedNodeMap namedNodeMap = mock(org.w3c.dom.NamedNodeMap.class);
                                                                                                                                                                                                             org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                                                                             DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Setup name behavior
                                                                                                                                                                                                             when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                                             when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                                                                                                             when(namespaceResolver.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                                                                                                                                                                                             when(name.getName()).thenReturn("attrName");
                                                                                                                                                                                                             
                                                                                                                                                                                                             // First call returns null
                                                                                                                                                                                                             when(element.getAttributeNodeNS("testNS", "attrName")).thenReturn(null);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Setup attributes list
                                                                                                                                                                                                             when(element.getAttributes()).thenReturn(namedNodeMap);
                                                                                                                                                                                                             when(namedNodeMap.getLength()).thenReturn(1);
                                                                                                                                                                                                             
                                                                                                                                                                                                             org.w3c.dom.Attr expectedAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                                                                             when(namedNodeMap.item(0)).thenReturn(expectedAttr);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Use reflection to call private testAttr method
                                                                                                                                                                                                             try {
                                                                                                                                                                                                                 Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", org.w3c.dom.Attr.class);
                                                                                                                                                                                                                 testAttrMethod.setAccessible(true);
                                                                                                                                                                                                                 when(testAttrMethod.invoke(iterator, expectedAttr)).thenReturn(true);
                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                 fail("Failed to set up testAttr method: " + e.getMessage());
                                                                                                                                                                                                             }
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Test
                                                                                                                                                                                                             org.w3c.dom.Attr result;
                                                                                                                                                                                                             try {
                                                                                                                                                                                                                 Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                                 getAttributeMethod.setAccessible(true);
                                                                                                                                                                                                                 result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                 fail("Failed to invoke getAttribute method: " + e.getMessage());
                                                                                                                                                                                                                 return;
                                                                                                                                                                                                             }
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                             assertEquals(expectedAttr, result);
                                                                                                                                                                                                             verify(element).getAttributeNodeNS("testNS", "attrName");
                                                                                                                                                                                                             verify(element).getAttributes();
                                                                                                                                                                                                             verify(namedNodeMap).getLength();
                                                                                                                                                                                                             verify(namedNodeMap).item(0);
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                     public void testSetPosition_EmptyAttributesList() throws Exception {
                                                                                                                                                                                                         // Create a document to use with DOMNodePointer
                                                                                                                                                                                                         javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                                                         javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                                                         org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create a parent DOMNodePointer with null node to ensure empty attributes list
                                                                                                                                                                                                         NodePointer parent = new DOMNodePointer(null, document);
                                                                                                                                                                                                         QName name = new QName("test");
                                                                                                                                                                                                         DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // attributes list should be empty
                                                                                                                                                                                                         assertFalse(iterator.setPosition(0));
                                                                                                                                                                                                         assertFalse(iterator.setPosition(1));
                                                                                                                                                                                                         assertFalse(iterator.setPosition(-1));
                                                                                                                                                                                                         assertFalse(iterator.setPosition(100));
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                 public void testGetAttribute_NamespaceFallbackNoMatchInAttributesList() {
                                                                                                                                                                                                     // Setup mocks
                                                                                                                                                                                                     org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                                                                     org.apache.commons.jxpath.ri.QName name = mock(org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                     org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                                                                                                                     org.w3c.dom.NamedNodeMap namedNodeMap = mock(org.w3c.dom.NamedNodeMap.class);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Setup name mock
                                                                                                                                                                                                     when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                                     when(name.getName()).thenReturn("attrName");
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Setup parent mock
                                                                                                                                                                                                     org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                                                                     when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                                                                                                     when(namespaceResolver.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                                                                                                                                                                                     
                                                                                                                                                                                                     // First call returns null
                                                                                                                                                                                                     when(element.getAttributeNodeNS("testNS", "attrName")).thenReturn(null);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Setup attributes list
                                                                                                                                                                                                     when(element.getAttributes()).thenReturn(namedNodeMap);
                                                                                                                                                                                                     when(namedNodeMap.getLength()).thenReturn(1);
                                                                                                                                                                                                     
                                                                                                                                                                                                     org.w3c.dom.Attr testAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                                                                     when(namedNodeMap.item(0)).thenReturn(testAttr);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create real iterator instance
                                                                                                                                                                                                     org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                                                                                                                                                         new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, name);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Use reflection to override testAttr behavior
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Method testAttrMethod = org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class
                                                                                                                                                                                                             .getDeclaredMethod("testAttr", org.w3c.dom.Attr.class);
                                                                                                                                                                                                         testAttrMethod.setAccessible(true);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Override the method to return false for our test case
                                                                                                                                                                                                         testAttrMethod.invoke(iterator, testAttr);
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Failed to access private testAttr method");
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Test - use reflection to call private getAttribute method
                                                                                                                                                                                                     org.w3c.dom.Attr result = null;
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Method getAttributeMethod = org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class
                                                                                                                                                                                                             .getDeclaredMethod("getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                                         getAttributeMethod.setAccessible(true);
                                                                                                                                                                                                         result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Failed to invoke private getAttribute method");
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                     assertNull(result);
                                                                                                                                                                                                     verify(element).getAttributeNodeNS("testNS", "attrName");
                                                                                                                                                                                                     verify(element).getAttributes();
                                                                                                                                                                                                     verify(namedNodeMap).getLength();
                                                                                                                                                                                                     verify(namedNodeMap).item(0);
                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                public void testGetAttributeWithNamespaceFallback() throws Exception {
                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                    org.apache.commons.jxpath.ri.QName qname = new org.apache.commons.jxpath.ri.QName("prefix", "localName");
                                                                                                                                                                                    org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                                                                                                    org.w3c.dom.Attr mockAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                                                    org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                                                    org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock behavior
                                                                                                                                                                                    when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                                                                                    when(namespaceResolver.getNamespaceURI("prefix")).thenReturn("http://example.com");
                                                                                                                                                                                    when(element.getAttributeNodeNS("http://example.com", "localName")).thenReturn(null);
                                                                                                                                                                                    
                                                                                                                                                                                    // This is what the mutant would break - original would return a real NamedNodeMap
                                                                                                                                                                                    org.w3c.dom.NamedNodeMap attributesMap = mock(org.w3c.dom.NamedNodeMap.class);
                                                                                                                                                                                    when(element.getAttributes()).thenReturn(attributesMap);
                                                                                                                                                                                    when(attributesMap.getLength()).thenReturn(1);
                                                                                                                                                                                    when(attributesMap.item(0)).thenReturn(mockAttr);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create test instance
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                    java.lang.reflect.Method method = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                                        "getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Invoke private method
                                                                                                                                                                                    org.w3c.dom.Attr result = (org.w3c.dom.Attr) method.invoke(iterator, element, qname);
                                                                                                                                                                                    
                                                                                                                                                                                    // Original code would reach here and we'd verify the attribute
                                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                                    assertEquals(mockAttr, result);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                           public void testGetAttribute_ShouldFindAttributeInLoop_WhenDirectLookupFails() throws Exception {
                                                                                                                                                                               // Setup test data
                                                                                                                                                                               QName qname = new QName("http://example.com", "localName");
                                                                                                                                                                               Element element = mock(Element.class);
                                                                                                                                                                               NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                               org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                                               NamedNodeMap attributes = mock(NamedNodeMap.class);
                                                                                                                                                                               Attr expectedAttr = mock(Attr.class);
                                                                                                                                                                               
                                                                                                                                                                               // Configure mocks
                                                                                                                                                                               when(qname.getPrefix()).thenReturn("prefix");
                                                                                                                                                                               when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                                                                               when(namespaceResolver.getNamespaceURI("prefix")).thenReturn("http://example.com");
                                                                                                                                                                               when(element.getAttributeNodeNS("http://example.com", "localName")).thenReturn(null);
                                                                                                                                                                               when(element.getAttributes()).thenReturn(attributes);
                                                                                                                                                                               when(attributes.getLength()).thenReturn(1);
                                                                                                                                                                               when(attributes.item(0)).thenReturn(expectedAttr);
                                                                                                                                                                               
                                                                                                                                                                               // Create test instance
                                                                                                                                                                               DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                               Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                                                               getAttributeMethod.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               // Call method and verify
                                                                                                                                                                               Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                                                                                                               assertEquals("Should return the attribute found in the loop", expectedAttr, result);
                                                                                                                                                                               
                                                                                                                                                                               // Verify interactions
                                                                                                                                                                               verify(element).getAttributeNodeNS("http://example.com", "localName");
                                                                                                                                                                               verify(element).getAttributes();
                                                                                                                                                                               verify(attributes).getLength();
                                                                                                                                                                               verify(attributes).item(0);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                  public void testGetAttribute_DetectsMutatedAttrAssignment() throws Exception {
                                                                                                                                                                      // Setup test data
                                                                                                                                                                      QName qname = new QName("testName");
                                                                                                                                                                      Element element = mock(Element.class);
                                                                                                                                                                      NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                      
                                                                                                                                                                      // Setup attributes for the fallback case
                                                                                                                                                                      Attr expectedAttr = mock(Attr.class);
                                                                                                                                                                      Attr otherAttr = mock(Attr.class);
                                                                                                                                                                      NamedNodeMap attributesMap = mock(NamedNodeMap.class);
                                                                                                                                                                      
                                                                                                                                                                      when(element.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                                                                                                                                      when(element.getAttributes()).thenReturn(attributesMap);
                                                                                                                                                                      when(attributesMap.getLength()).thenReturn(2);
                                                                                                                                                                      
                                                                                                                                                                      // Original code would call item(0) and item(1), mutant sets them to null
                                                                                                                                                                      when(attributesMap.item(0)).thenReturn(expectedAttr);
                                                                                                                                                                      when(attributesMap.item(1)).thenReturn(otherAttr);
                                                                                                                                                                      
                                                                                                                                                                      // Mock parent (namespace resolver not needed for this test)
                                                                                                                                                                      when(parent.getNamespaceResolver()).thenReturn(null);
                                                                                                                                                                      
                                                                                                                                                                      // Create instance
                                                                                                                                                                      DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to access private getAttribute method
                                                                                                                                                                      Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                          "getAttribute", Element.class, QName.class);
                                                                                                                                                                      getAttributeMethod.setAccessible(true);
                                                                                                                                                                      
                                                                                                                                                                      // Invoke the private method
                                                                                                                                                                      Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                                                                                                      
                                                                                                                                                                      // Verify - original should return expectedAttr, mutant would return null
                                                                                                                                                                      assertSame("Should return the matching attribute", expectedAttr, result);
                                                                                                                                                                      
                                                                                                                                                                      // Verify interactions
                                                                                                                                                                      verify(attributesMap, times(2)).item(anyInt());
                                                                                                                                                                  }

    @Test
                                                                                                                                                     public void testGetAttributeWithFallbackPath() throws Exception {
                                                                                                                                                         // Setup test data
                                                                                                                                                         org.apache.commons.jxpath.ri.QName testQName = new org.apache.commons.jxpath.ri.QName("testName");
                                                                                                                                                         org.w3c.dom.Element mockElement = mock(org.w3c.dom.Element.class);
                                                                                                                                                         org.apache.commons.jxpath.ri.model.NodePointer mockParent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                         org.apache.commons.jxpath.ri.NamespaceResolver mockResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                         org.w3c.dom.NamedNodeMap mockAttributes = mock(org.w3c.dom.NamedNodeMap.class);
                                                                                                                                                         org.w3c.dom.Attr expectedAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                         org.w3c.dom.Attr otherAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                         
                                                                                                                                                         // Configure mocks
                                                                                                                                                         when(mockParent.getNamespaceResolver()).thenReturn(mockResolver);
                                                                                                                                                         when(testQName.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                         when(mockResolver.getNamespaceURI("testPrefix")).thenReturn(null); // Force fallback path
                                                                                                                                                         when(mockElement.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                                                                                                                         when(mockElement.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                         when(mockAttributes.getLength()).thenReturn(2);
                                                                                                                                                         when(mockAttributes.item(0)).thenReturn(otherAttr);
                                                                                                                                                         when(mockAttributes.item(1)).thenReturn(expectedAttr);
                                                                                                                                                         
                                                                                                                                                         // Create test instance
                                                                                                                                                         DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                                                                                                         
                                                                                                                                                         // Mock the testAttr method behavior - use reflection since it's private
                                                                                                                                                         Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", org.w3c.dom.Attr.class);
                                                                                                                                                         testAttrMethod.setAccessible(true);
                                                                                                                                                         
                                                                                                                                                         // Make testAttr return false for otherAttr, true for expectedAttr
                                                                                                                                                         when((Boolean)testAttrMethod.invoke(iterator, otherAttr)).thenReturn(false);
                                                                                                                                                         when((Boolean)testAttrMethod.invoke(iterator, expectedAttr)).thenReturn(true);
                                                                                                                                                         
                                                                                                                                                         // Call the method under test (using reflection since it's private)
                                                                                                                                                         Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                                         getAttributeMethod.setAccessible(true);
                                                                                                                                                         org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                                                                                                                         
                                                                                                                                                         // Verify the result
                                                                                                                                                         assertSame("Should return the attribute that passes testAttr", expectedAttr, result);
                                                                                                                                                     }

    @Test
                                                                                                                                        public void testGetAttribute_ReturnsAttrWhenFoundViaNamespace() throws Exception {
                                                                                                                                            // Setup test data
                                                                                                                                            org.apache.commons.jxpath.ri.QName qname = new org.apache.commons.jxpath.ri.QName("prefix", "localName");
                                                                                                                                            org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                                                            org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                            org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                            org.w3c.dom.Attr expectedAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                            
                                                                                                                                            // Mock behavior
                                                                                                                                            when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                                            when(namespaceResolver.getNamespaceURI("prefix")).thenReturn("http://example.com");
                                                                                                                                            when(element.getAttributeNodeNS("http://example.com", "localName")).thenReturn(expectedAttr);
                                                                                                                                            
                                                                                                                                            // Create test object
                                                                                                                                            org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                                                                                                new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, qname);
                                                                                                                                            
                                                                                                                                            // Use reflection to access private method since we're testing it directly
                                                                                                                                            Method getAttributeMethod = org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                "getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                            getAttributeMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Invoke and verify
                                                                                                                                            org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                                                                            assertEquals("Should return the found attribute", expectedAttr, result);
                                                                                                                                        }

    @Test
                                                                                                                                   public void testGetAttribute_ShouldCheckFirstAttributeInLoop() throws Exception {
                                                                                                                                       // Setup test data
                                                                                                                                       QName qname = new QName("test");
                                                                                                                                       NodePointer parent = mock(NodePointer.class);
                                                                                                                                       Element element = mock(Element.class);
                                                                                                                                       NamedNodeMap nnm = mock(NamedNodeMap.class);
                                                                                                                                       Attr firstAttr = mock(Attr.class);
                                                                                                                                       Attr secondAttr = mock(Attr.class);
                                                                                                                                       
                                                                                                                                       // Mock behavior
                                                                                                                                       when(qname.getPrefix()).thenReturn(null); // Force non-namespace path
                                                                                                                                       when(element.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                                                                                                       when(element.getAttributes()).thenReturn(nnm);
                                                                                                                                       when(nnm.getLength()).thenReturn(2);
                                                                                                                                       when(nnm.item(0)).thenReturn(firstAttr);
                                                                                                                                       when(nnm.item(1)).thenReturn(secondAttr);
                                                                                                                                       
                                                                                                                                       // Create iterator instance
                                                                                                                                       DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                                                                       
                                                                                                                                       // Use reflection to access private method
                                                                                                                                       Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                           "getAttribute", Element.class, QName.class);
                                                                                                                                       getAttributeMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Call private method
                                                                                                                                       Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                                                                       
                                                                                                                                       // Verify - should return first attribute
                                                                                                                                       assertSame(firstAttr, result);
                                                                                                                                       
                                                                                                                                       // Verify interactions
                                                                                                                                       verify(nnm).item(0);
                                                                                                                                       verify(nnm).item(1);
                                                                                                                                   }

    @Test
                                                                                                                          public void testGetAttribute_ShouldCheckAttributesWhenNamespaceResolutionFails() throws Exception {
                                                                                                                              // Setup test data
                                                                                                                              QName qname = new QName("testName");
                                                                                                                              Element element = mock(Element.class);
                                                                                                                              Attr expectedAttr = mock(Attr.class);
                                                                                                                              
                                                                                                                              // Mock namespace resolution to fail (return null)
                                                                                                                              when(qname.getPrefix()).thenReturn("somePrefix");
                                                                                                                              NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                              org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = 
                                                                                                                                  mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                              when(parentPointer.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                                              when(namespaceResolver.getNamespaceURI("somePrefix")).thenReturn(null);
                                                                                                                              
                                                                                                                              // Mock attribute node that should be found in fallback check
                                                                                                                              NamedNodeMap attributesMap = mock(NamedNodeMap.class);
                                                                                                                              when(element.getAttributes()).thenReturn(attributesMap);
                                                                                                                              when(attributesMap.getLength()).thenReturn(1);
                                                                                                                              when(attributesMap.item(0)).thenReturn(expectedAttr);
                                                                                                                              
                                                                                                                              // Mock direct attribute access (shouldn't be called in this path)
                                                                                                                              when(element.getAttributeNode("testName")).thenReturn(null);
                                                                                                                              
                                                                                                                              // Create test instance
                                                                                                                              DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, qname);
                                                                                                                              
                                                                                                                              // Use reflection to access private getAttribute method
                                                                                                                              Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                              getAttributeMethod.setAccessible(true);
                                                                                                                              
                                                                                                                              // Call method and verify
                                                                                                                              Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                                                              assertEquals(expectedAttr, result);
                                                                                                                              
                                                                                                                              // Verify the fallback path was taken
                                                                                                                              verify(element).getAttributes();
                                                                                                                              verify(attributesMap).getLength();
                                                                                                                              verify(attributesMap).item(0);
                                                                                                                          }

    @Test
                                                                                                             public void testGetAttribute_ShouldFindAttrInFallbackLoopWhenNSLookupFails() throws Exception {
                                                                                                                 // Setup test data
                                                                                                                 org.apache.commons.jxpath.ri.QName qname = new org.apache.commons.jxpath.ri.QName("http://test", "local");
                                                                                                                 org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                                 org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                 org.apache.commons.jxpath.ri.NamespaceResolver nsResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                 
                                                                                                                 // Mock the prefix lookup
                                                                                                                 when(parent.getNamespaceResolver()).thenReturn(nsResolver);
                                                                                                                 when(nsResolver.getNamespaceURI("prefix")).thenReturn("http://test");
                                                                                                                 
                                                                                                                 // Mock the NS attribute lookup to return null (not found)
                                                                                                                 when(element.getAttributeNodeNS("http://test", "local")).thenReturn(null);
                                                                                                                 
                                                                                                                 // Create a NamedNodeMap with one attribute that should match
                                                                                                                 org.w3c.dom.NamedNodeMap nnm = mock(org.w3c.dom.NamedNodeMap.class);
                                                                                                                 org.w3c.dom.Attr expectedAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                 when(nnm.getLength()).thenReturn(1);
                                                                                                                 when(nnm.item(0)).thenReturn(expectedAttr);
                                                                                                                 when(element.getAttributes()).thenReturn(nnm);
                                                                                                                 
                                                                                                                 // Create real iterator instance instead of mocking
                                                                                                                 DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                                                 
                                                                                                                 // Use reflection to access private methods
                                                                                                                 java.lang.reflect.Method getAttributeMethod = DOMAttributeIterator.class
                                                                                                                     .getDeclaredMethod("getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                 getAttributeMethod.setAccessible(true);
                                                                                                                 
                                                                                                                 // Call the method under test
                                                                                                                 org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                                                 
                                                                                                                 // Verify the fallback loop found the attribute
                                                                                                                 assertSame(expectedAttr, result);
                                                                                                             }

    @Test
                                                                                            public void testGetAttribute_DetectsMutatedAttributeIteration() throws Exception {
                                                                                                // Setup test data
                                                                                                org.apache.commons.jxpath.ri.QName name = new org.apache.commons.jxpath.ri.QName("testName");
                                                                                                org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                                                
                                                                                                // Create a valid attribute that should pass testAttr()
                                                                                                final org.w3c.dom.Attr validAttr = mock(org.w3c.dom.Attr.class);
                                                                                                when(validAttr.getLocalName()).thenReturn("testName");
                                                                                                
                                                                                                // Create a NamedNodeMap with our test attribute
                                                                                                org.w3c.dom.NamedNodeMap nnm = mock(org.w3c.dom.NamedNodeMap.class);
                                                                                                when(nnm.getLength()).thenReturn(1);
                                                                                                when(nnm.item(0)).thenReturn(validAttr);
                                                                                                
                                                                                                // Mock the element behavior
                                                                                                when(element.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                                                                when(element.getAttributes()).thenReturn(nnm);
                                                                                                when(element.getAttributeNode(anyString())).thenReturn(null);
                                                                                                
                                                                                                // Mock the parent and name behavior
                                                                                                when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                                                when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                when(namespaceResolver.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                                                
                                                                                                // Create testable iterator
                                                                                                org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                                                    new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, name);
                                                                                                
                                                                                                // Use reflection to access the private testAttr method
                                                                                                Method testAttrMethod = org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class
                                                                                                    .getDeclaredMethod("testAttr", org.w3c.dom.Attr.class);
                                                                                                testAttrMethod.setAccessible(true);
                                                                                                
                                                                                                // Modify the NamedNodeMap to only return attributes that pass testAttr
                                                                                                when(nnm.item(0)).thenAnswer(invocation -> {
                                                                                                    // Only return the validAttr when testAttr would return true for it
                                                                                                    if ((boolean) testAttrMethod.invoke(iterator, validAttr)) {
                                                                                                        return validAttr;
                                                                                                    }
                                                                                                    return null;
                                                                                                });
                                                                                                
                                                                                                // Use reflection to access the private getAttribute method
                                                                                                Method getAttributeMethod = org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class
                                                                                                    .getDeclaredMethod("getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                getAttributeMethod.setAccessible(true);
                                                                                                
                                                                                                // Invoke the method and verify
                                                                                                org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                
                                                                                                // Assert that we got the valid attribute (would fail with the mutant)
                                                                                                assertNotNull("Method should return the valid attribute", result);
                                                                                                assertEquals("Returned attribute should be the valid one", validAttr, result);
                                                                                            }

    @Test
                                                                                       public void testGetAttribute_ShouldReturnAttrWhenFoundViaNS() throws Exception {
                                                                                           // Setup test data
                                                                                           QName qname = new QName("prefix", "localName");
                                                                                           Element element = mock(Element.class);
                                                                                           NodePointer parent = mock(NodePointer.class);
                                                                                           org.apache.commons.jxpath.ri.NamespaceResolver nsResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                           Attr expectedAttr = mock(Attr.class);
                                                                                           
                                                                                           // Mock behavior
                                                                                           when(qname.getPrefix()).thenReturn("prefix");
                                                                                           when(parent.getNamespaceResolver()).thenReturn(nsResolver);
                                                                                           when(nsResolver.getNamespaceURI("prefix")).thenReturn("namespaceURI");
                                                                                           when(element.getAttributeNodeNS("namespaceURI", "localName")).thenReturn(expectedAttr);
                                                                                           
                                                                                           // Create test instance
                                                                                           DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                           
                                                                                           // Use reflection to access private method since we're testing it directly
                                                                                           Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                               "getAttribute", Element.class, QName.class);
                                                                                           getAttributeMethod.setAccessible(true);
                                                                                           
                                                                                           // Invoke method
                                                                                           Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                           
                                                                                           // Verify
                                                                                           assertSame("Should return the attribute found via namespace lookup", 
                                                                                               expectedAttr, result);
                                                                                       }

    @Test
                                                                          public void testGetAttribute_DetectsFirstAttributeInList() throws Exception {
                                                                              // Setup test data
                                                                              org.apache.commons.jxpath.ri.QName testQName = new org.apache.commons.jxpath.ri.QName("testNS", "testName");
                                                                              String prefix = "testPrefix";
                                                                              
                                                                              // Create mock objects
                                                                              org.apache.commons.jxpath.ri.model.NodePointer parentPointer = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                              org.apache.commons.jxpath.ri.NamespaceResolver nsResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                              org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                              org.w3c.dom.NamedNodeMap attributesMap = mock(org.w3c.dom.NamedNodeMap.class);
                                                                              org.w3c.dom.Attr matchingAttr = mock(org.w3c.dom.Attr.class);
                                                                              org.w3c.dom.Attr nonMatchingAttr = mock(org.w3c.dom.Attr.class);
                                                                              
                                                                              // Configure mocks
                                                                              when(testQName.getPrefix()).thenReturn(prefix);
                                                                              when(parentPointer.getNamespaceResolver()).thenReturn(nsResolver);
                                                                              when(nsResolver.getNamespaceURI(prefix)).thenReturn(null); // Force fallback to attribute scanning
                                                                              when(element.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                                              when(element.getAttributes()).thenReturn(attributesMap);
                                                                              when(element.getAttributeNode(anyString())).thenReturn(null);
                                                                              
                                                                              // Setup attributes list where first attribute is the matching one
                                                                              when(attributesMap.getLength()).thenReturn(2);
                                                                              when(attributesMap.item(0)).thenReturn(matchingAttr);
                                                                              when(attributesMap.item(1)).thenReturn(nonMatchingAttr);
                                                                              
                                                                              // Create test instance
                                                                              org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                                  new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parentPointer, testQName);
                                                                              
                                                                              // Use reflection to access private method
                                                                              Method getAttributeMethod = org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class.getDeclaredMethod(
                                                                                  "getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                              getAttributeMethod.setAccessible(true);
                                                                              
                                                                              // Call method and verify
                                                                              org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, testQName);
                                                                              assertSame("Should return first attribute when it matches", matchingAttr, result);
                                                                          }

    @Test
                                                             public void testGetAttribute_ShouldDetectNullNamedNodeMapMutant() throws Exception {
                                                                 // Setup test data
                                                                 org.apache.commons.jxpath.ri.QName name = mock(org.apache.commons.jxpath.ri.QName.class);
                                                                 org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                                                 org.w3c.dom.Attr expectedAttr = mock(org.w3c.dom.Attr.class);
                                                                 
                                                                 // Mock name behavior
                                                                 when(name.getPrefix()).thenReturn("prefix");
                                                                 when(name.getName()).thenReturn("localName");
                                                                 
                                                                 // Mock parent and namespace resolver
                                                                 org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                 org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                 when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                                 when(namespaceResolver.getNamespaceURI("prefix")).thenReturn(null);
                                                                 
                                                                 // Mock element behavior - this is what the mutant would break
                                                                 org.w3c.dom.NamedNodeMap attributes = mock(org.w3c.dom.NamedNodeMap.class);
                                                                 when(attributes.getLength()).thenReturn(1);
                                                                 when(attributes.item(0)).thenReturn(expectedAttr);
                                                                 when(element.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                                 when(element.getAttributes()).thenReturn(attributes);
                                                                 
                                                                 // Create test instance
                                                                 org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                                                     new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, name);
                                                                 
                                                                 // Use reflection to access private getAttribute method
                                                                 java.lang.reflect.Method getAttributeMethod = 
                                                                     org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class.getDeclaredMethod(
                                                                         "getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                                                 getAttributeMethod.setAccessible(true);
                                                                 
                                                                 // This should throw NullPointerException for the mutant
                                                                 // For original code, it would return expectedAttr
                                                                 org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                 
                                                                 // Original code would reach this assertion
                                                                 assertEquals(expectedAttr, result);
                                                             }

    @Test
                                                public void testGetAttribute_ShouldCheckAllAttributesWhenNamespaceResolutionFails() throws Exception {
                                                    // Setup test data
                                                    QName qname = new QName("prefix", "localName");
                                                    Element element = mock(Element.class);
                                                    NamedNodeMap attributes = mock(NamedNodeMap.class);
                                                    NodePointer parent = mock(NodePointer.class);
                                                    org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = 
                                                        mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                    
                                                    // Create test attributes - we need at least 2 where the matching one is second
                                                    Attr nonMatchingAttr = mock(Attr.class);
                                                    Attr matchingAttr = mock(Attr.class);
                                                    
                                                    // Mock behavior
                                                    when(qname.getPrefix()).thenReturn("prefix");
                                                    when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                                                    when(namespaceResolver.getNamespaceURI("prefix")).thenReturn(null); // Force fallback path
                                                    when(element.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                    when(element.getAttributes()).thenReturn(attributes);
                                                    when(attributes.getLength()).thenReturn(2);
                                                    when(attributes.item(0)).thenReturn(nonMatchingAttr);
                                                    when(attributes.item(1)).thenReturn(matchingAttr);
                                                    
                                                    // Create iterator and access private method via reflection
                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                    Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                    getAttributeMethod.setAccessible(true);
                                                    
                                                    // Mock testAttr behavior via reflection
                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                                                    testAttrMethod.setAccessible(true);
                                                    
                                                    // Setup mock behavior for testAttr calls
                                                    when(testAttrMethod.invoke(iterator, nonMatchingAttr)).thenReturn(false);
                                                    when(testAttrMethod.invoke(iterator, matchingAttr)).thenReturn(true);
                                                    
                                                    // Call method
                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                    
                                                    // Verify
                                                    assertEquals(matchingAttr, result);
                                                    // Verify we checked both attributes
                                                    verify(attributes, times(2)).item(anyInt());
                                                    verify(testAttrMethod, times(1)).invoke(iterator, nonMatchingAttr);
                                                    verify(testAttrMethod, times(1)).invoke(iterator, matchingAttr);
                                                }

    @Test
                               public void testGetAttributeWithNamespacedAttrSearch() throws Exception {
                                   // Setup test data
                                   String namespaceURI = "http://test.ns";
                                   String localName = "test";
                                   String prefix = "prefix";
                                   org.apache.commons.jxpath.ri.QName qname = new org.apache.commons.jxpath.ri.QName(namespaceURI, localName);
                                   
                                   org.w3c.dom.Element element = mock(org.w3c.dom.Element.class);
                                   org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                   org.apache.commons.jxpath.ri.NamespaceResolver nsResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                   
                                   // Mock behavior
                                   when(parent.getNamespaceResolver()).thenReturn(nsResolver);
                                   when(nsResolver.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                                   
                                   // Setup attributes - first lookup fails, then search succeeds
                                   org.w3c.dom.Attr expectedAttr = mock(org.w3c.dom.Attr.class);
                                   when(expectedAttr.getNamespaceURI()).thenReturn(namespaceURI);
                                   when(expectedAttr.getLocalName()).thenReturn(localName);
                                   
                                   org.w3c.dom.NamedNodeMap attributes = mock(org.w3c.dom.NamedNodeMap.class);
                                   when(element.getAttributeNodeNS(namespaceURI, localName)).thenReturn(null);
                                   when(element.getAttributes()).thenReturn(attributes);
                                   when(attributes.getLength()).thenReturn(1);
                                   when(attributes.item(0)).thenReturn(expectedAttr);
                                   
                                   // Create DOMAttributeIterator instance
                                   org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator iterator = 
                                       new org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator(parent, qname);
                                   
                                   // Use reflection to access private method
                                   java.lang.reflect.Method getAttribute = org.apache.commons.jxpath.ri.model.dom.DOMAttributeIterator.class
                                       .getDeclaredMethod("getAttribute", org.w3c.dom.Element.class, org.apache.commons.jxpath.ri.QName.class);
                                   getAttribute.setAccessible(true);
                                   
                                   // Test - should return expectedAttr
                                   org.w3c.dom.Attr result = (org.w3c.dom.Attr) getAttribute.invoke(iterator, element, qname);
                                   
                                   // Verify
                                   assertSame("Should return the matching attribute", expectedAttr, result);
                               }

    @Test
                      public void testGetAttribute_ShouldReturnAttributeWhenFoundInFallbackLoop() throws Exception {
                          // Setup test data
                          QName testQName = new QName("testName");
                          String testPrefix = "testPrefix";
                          String testLocalName = "testName";
                          
                          // Create mock objects
                          NodePointer parentPointer = mock(NodePointer.class);
                          org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = 
                              mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                          Element element = mock(Element.class);
                          NamedNodeMap attributesMap = mock(NamedNodeMap.class);
                          
                          // Create test attribute that should match
                          Attr matchingAttr = mock(Attr.class);
                          Attr nonMatchingAttr = mock(Attr.class);
                          
                          // Configure mocks
                          when(parentPointer.getNamespaceResolver()).thenReturn(namespaceResolver);
                          when(testQName.getPrefix()).thenReturn(testPrefix);
                          when(testQName.getName()).thenReturn(testLocalName);
                          
                          // Simulate namespace resolution failing (null)
                          when(namespaceResolver.getNamespaceURI(testPrefix)).thenReturn(null);
                          
                          // Simulate direct attribute lookup failing (null)
                          when(element.getAttributeNodeNS(anyString(), eq(testLocalName))).thenReturn(null);
                          
                          // Setup attributes map with one matching and one non-matching attribute
                          when(element.getAttributes()).thenReturn(attributesMap);
                          when(attributesMap.getLength()).thenReturn(2);
                          when(attributesMap.item(0)).thenReturn(nonMatchingAttr);
                          when(attributesMap.item(1)).thenReturn(matchingAttr);
                          
                          // Create iterator
                          DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, testQName);
                          
                          // Use reflection to test private methods
                          Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
                          testAttrMethod.setAccessible(true);
                          
                          // Mock the behavior of testAttr through reflection
                          when(testAttrMethod.invoke(iterator, nonMatchingAttr)).thenReturn(false);
                          when(testAttrMethod.invoke(iterator, matchingAttr)).thenReturn(true);
                          
                          // Call the private getAttribute method using reflection
                          Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                              "getAttribute", Element.class, QName.class);
                          getAttributeMethod.setAccessible(true);
                          Attr result = (Attr) getAttributeMethod.invoke(iterator, element, testQName);
                          
                          // Verify the correct attribute is returned
                          assertSame("Should return the matching attribute", matchingAttr, result);
                          
                          // Verify interactions
                          verify(namespaceResolver).getNamespaceURI(testPrefix);
                          verify(element).getAttributeNodeNS(null, testLocalName);
                          verify(attributesMap, times(2)).item(anyInt());
                      }

    @Test
                 public void testGetAttributeWithNamespaceShouldReturnAttrWhenFound() throws Exception {
                     // Setup test data
                     String namespaceURI = "http://example.com";
                     String localName = "localName";
                     String prefix = "prefix";
                     QName qname = new QName(namespaceURI, localName);
                     Element element = mock(Element.class);
                     NodePointer parent = mock(NodePointer.class);
                     org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                     Attr expectedAttr = mock(Attr.class);
                     
                     // Mock behavior
                     when(qname.getPrefix()).thenReturn(prefix);
                     when(parent.getNamespaceResolver()).thenReturn(namespaceResolver);
                     when(namespaceResolver.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                     when(element.getAttributeNodeNS(namespaceURI, localName)).thenReturn(expectedAttr);
                     
                     // Create test instance
                     DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                     
                     // Use reflection to access private method since we're testing it directly
                     Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                     getAttributeMethod.setAccessible(true);
                     
                     // Invoke and verify
                     Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                     assertEquals("Should return the found attribute", expectedAttr, result);
                     
                     // Clean up
                     getAttributeMethod.setAccessible(false);
                 }

    @Test
    public void testGetAttribute_DetectsFirstAttributeInList1() throws Exception {
        // Setup test data where the matching attribute is first in the list
        QName testQName = new QName("testName");
        Element mockElement = mock(Element.class);
        NodePointer mockParent = mock(NodePointer.class);
        org.apache.commons.jxpath.ri.NamespaceResolver mockNsResolver = 
            mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
        
        // Create a mock NamedNodeMap with 2 attributes
        NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
        Attr matchingAttr = mock(Attr.class);
        Attr nonMatchingAttr = mock(Attr.class);
        
        // Configure mocks
        when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
        when(mockElement.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
        when(mockElement.getAttributes()).thenReturn(mockAttributes);
        when(mockAttributes.getLength()).thenReturn(2);
        
        // Make the first attribute match our test condition
        when(mockAttributes.item(0)).thenReturn(matchingAttr);
        when(mockAttributes.item(1)).thenReturn(nonMatchingAttr);
        
        // Use reflection to test private method
        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class);
        testAttrMethod.setAccessible(true);
        when(testAttrMethod.invoke(any(), eq(matchingAttr))).thenReturn(true);
        when(testAttrMethod.invoke(any(), eq(nonMatchingAttr))).thenReturn(false);
        
        // Also mock the non-namespace case to return null to force the loop path
        when(mockElement.getAttributeNode(testQName.getName())).thenReturn(null);
        
        // Create instance and test
        DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
        
        // Use reflection to test private getAttribute method
        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
        getAttributeMethod.setAccessible(true);
        Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
        
        // Verify the original behavior (should find the first attribute)
        assertSame("Should return the first attribute which matches", matchingAttr, result);
        
        // Verify we checked all the right things
        verify(mockElement).getAttributeNodeNS(null, testQName.getName());
        verify(mockElement).getAttributes();
        verify(mockAttributes, times(2)).getLength(); // Once in loop condition, once in setup
        verify(mockAttributes).item(0);
        verify(mockAttributes).item(1);
    }


}
