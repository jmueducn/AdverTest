package gentest.org.apache.commons.jxpath.ri.axes.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.axes.*;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.commons.jxpath.BasicNodeSet;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class UnionContextTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                public void testSetPosition_FirstTimePreparation() {
                                                                                                    // Setup
                                                                                                    EvalContext parentContext = mock(EvalContext.class);
                                                                                                    EvalContext[] contexts = new EvalContext[2];
                                                                                                    contexts[0] = mock(EvalContext.class);
                                                                                                    contexts[1] = mock(EvalContext.class);
                                                                                                    
                                                                                                    NodePointer ptr1 = mock(NodePointer.class);
                                                                                                    NodePointer ptr2 = mock(NodePointer.class);
                                                                                                    
                                                                                                    when(contexts[0].nextSet()).thenReturn(true, false);
                                                                                                    when(contexts[0].nextNode()).thenReturn(true, false);
                                                                                                    when(contexts[0].getCurrentNodePointer()).thenReturn(ptr1);
                                                                                                    
                                                                                                    when(contexts[1].nextSet()).thenReturn(true, false);
                                                                                                    when(contexts[1].nextNode()).thenReturn(true, false);
                                                                                                    when(contexts[1].getCurrentNodePointer()).thenReturn(ptr2);
                                                                                                    
                                                                                                    UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                    
                                                                                                    // Test
                                                                                                    boolean result = unionContext.setPosition(1);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertFalse(result); // Assuming super.setPosition returns false for position 1
                                                                                                    verify(contexts[0]).nextSet();
                                                                                                    verify(contexts[0]).nextNode();
                                                                                                    verify(contexts[1]).nextSet();
                                                                                                    verify(contexts[1]).nextNode();
                                                                                                }

    @Test
                                                                                                public void testSetPosition_AlreadyPrepared() {
                                                                                                    // Setup
                                                                                                    EvalContext parentContext = mock(EvalContext.class);
                                                                                                    EvalContext[] contexts = new EvalContext[1];
                                                                                                    contexts[0] = mock(EvalContext.class);
                                                                                                    
                                                                                                    NodePointer ptr = mock(NodePointer.class);
                                                                                                    
                                                                                                    when(contexts[0].nextSet()).thenReturn(true, false);
                                                                                                    when(contexts[0].nextNode()).thenReturn(true, false);
                                                                                                    when(contexts[0].getCurrentNodePointer()).thenReturn(ptr);
                                                                                                    
                                                                                                    UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                    
                                                                                                    // First call prepares the context
                                                                                                    unionContext.setPosition(1);
                                                                                                    
                                                                                                    // Second call should skip preparation
                                                                                                    boolean result = unionContext.setPosition(2);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertFalse(result);
                                                                                                    verify(contexts[0], times(1)).nextSet(); // Should only be called once during preparation
                                                                                                }

    @Test
                                                                                                public void testSetPosition_EmptyContexts() {
                                                                                                    // Setup
                                                                                                    EvalContext parentContext = mock(EvalContext.class);
                                                                                                    EvalContext[] contexts = new EvalContext[0];
                                                                                                    UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                    
                                                                                                    // Test
                                                                                                    boolean result = unionContext.setPosition(1);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertFalse(result);
                                                                                                }

    @Test
                                                                                                public void testSetPosition_DuplicatePointers() {
                                                                                                    // Setup
                                                                                                    EvalContext parentContext = mock(EvalContext.class);
                                                                                                    EvalContext[] contexts = new EvalContext[2];
                                                                                                    contexts[0] = mock(EvalContext.class);
                                                                                                    contexts[1] = mock(EvalContext.class);
                                                                                                    
                                                                                                    NodePointer ptr = mock(NodePointer.class);
                                                                                                    
                                                                                                    when(contexts[0].nextSet()).thenReturn(true, false);
                                                                                                    when(contexts[0].nextNode()).thenReturn(true, false);
                                                                                                    when(contexts[0].getCurrentNodePointer()).thenReturn(ptr);
                                                                                                    
                                                                                                    when(contexts[1].nextSet()).thenReturn(true, false);
                                                                                                    when(contexts[1].nextNode()).thenReturn(true, false);
                                                                                                    when(contexts[1].getCurrentNodePointer()).thenReturn(ptr); // Same pointer
                                                                                                    
                                                                                                    UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                    
                                                                                                    // Test
                                                                                                    boolean result = unionContext.setPosition(1);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertFalse(result);
                                                                                                    // Pointer should only be added once despite appearing in both contexts
                                                                                                }

    @Test
                                                                                                public void testSetPosition_MultipleSetsAndNodes() {
                                                                                                    // Setup
                                                                                                    EvalContext parentContext = mock(EvalContext.class);
                                                                                                    EvalContext[] contexts = new EvalContext[1];
                                                                                                    contexts[0] = mock(EvalContext.class);
                                                                                                    
                                                                                                    NodePointer ptr1 = mock(NodePointer.class);
                                                                                                    NodePointer ptr2 = mock(NodePointer.class);
                                                                                                    
                                                                                                    when(contexts[0].nextSet()).thenReturn(true, true, false);
                                                                                                    when(contexts[0].nextNode()).thenReturn(true, false, true, false);
                                                                                                    when(contexts[0].getCurrentNodePointer()).thenReturn(ptr1, ptr2);
                                                                                                    
                                                                                                    UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                    
                                                                                                    // Test
                                                                                                    boolean result = unionContext.setPosition(1);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertFalse(result);
                                                                                                    verify(contexts[0], times(2)).nextSet();
                                                                                                    verify(contexts[0], times(2)).nextNode();
                                                                                                }

    @Test
                                                        public void testSetPosition_NullContexts() {
                                                            org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                            exception.expect(NullPointerException.class);
                                                            org.apache.commons.jxpath.ri.EvalContext parentContext = null;
                                                            org.apache.commons.jxpath.ri.axes.UnionContext unionContext = 
                                                                new org.apache.commons.jxpath.ri.axes.UnionContext(parentContext, null);
                                                            unionContext.setPosition(1);
                                                        }

    @Test
                                                   public void testSetPosition_ShouldCollectActualPointersNotNulls() {
                                                       // Arrange
                                                       EvalContext parentContext = mock(EvalContext.class);
                                                       EvalContext mockContext1 = mock(EvalContext.class);
                                                       EvalContext mockContext2 = mock(EvalContext.class);
                                                       EvalContext[] contexts = {mockContext1, mockContext2};
                                                       UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                       
                                                       // Stub the getCurrentNodePointer calls to return non-null values
                                                       when(mockContext1.getCurrentNodePointer()).thenReturn(mock(NodePointer.class));
                                                       when(mockContext2.getCurrentNodePointer()).thenReturn(mock(NodePointer.class));
                                                       
                                                       // Act
                                                       boolean result = unionContext.setPosition(0);
                                                       
                                                       // Assert that pointers were collected properly
                                                       verify(mockContext1, times(1)).getCurrentNodePointer();
                                                       verify(mockContext2, times(1)).getCurrentNodePointer();
                                                       
                                                       // Additional assertions could be added if we had access to nodeSet
                                                   }

    @Test
                                                   public void testSetPosition_ShouldFilterDuplicatePointers() {
                                                       // Setup test data with duplicate pointers
                                                       EvalContext mockContext1 = mock(EvalContext.class);
                                                       EvalContext mockContext2 = mock(EvalContext.class);
                                                       NodePointer duplicatePointer = mock(NodePointer.class);
                                                       
                                                       // Mock context behavior to return duplicate pointers
                                                       when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                                                       when(mockContext1.nextNode()).thenReturn(true).thenReturn(false);
                                                       when(mockContext1.getCurrentNodePointer()).thenReturn(duplicatePointer);
                                                       
                                                       when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
                                                       when(mockContext2.nextNode()).thenReturn(true).thenReturn(false);
                                                       when(mockContext2.getCurrentNodePointer()).thenReturn(duplicatePointer);
                                                       
                                                       EvalContext[] contexts = {mockContext1, mockContext2};
                                                       UnionContext unionContext = new UnionContext(null, contexts);
                                                       
                                                       // Call setPosition which should prepare the node set
                                                       unionContext.setPosition(0);
                                                       
                                                       // Get the underlying node set
                                                       BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                                       
                                                       // Verify only one instance of the duplicate pointer was added
                                                       // This assertion will fail if the mutant is present (which would add both)
                                                       assertEquals(1, nodeSet.getPointers().size());
                                                   }

    @Test
                                                  public void testSetPosition_DetectsPointerCloneMutant() {
                                                      // Setup test data
                                                      EvalContext mockContext1 = mock(EvalContext.class);
                                                      EvalContext mockContext2 = mock(EvalContext.class);
                                                      EvalContext[] contexts = new EvalContext[]{mockContext1, mockContext2};
                                                      
                                                      NodePointer mockPointer = mock(NodePointer.class);
                                                      when(mockPointer.clone()).thenReturn(mock(NodePointer.class)); // Clone returns different instance
                                                      
                                                      // Mock context behavior
                                                      when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                                                      when(mockContext1.nextNode()).thenReturn(true).thenReturn(false);
                                                      when(mockContext1.getCurrentNodePointer()).thenReturn(mockPointer);
                                                      
                                                      when(mockContext2.nextSet()).thenReturn(false);
                                                      
                                                      // Create test object
                                                      UnionContext unionContext = new UnionContext(null, contexts);
                                                      
                                                      // Modify the pointer after it would be added (if not cloned)
                                                      unionContext.setPosition(0);
                                                      
                                                      // Verify the node set contains the original pointer (not clone)
                                                      // This will fail if mutant is present (since clone would be added instead)
                                                      verify(mockPointer, atLeastOnce()).clone(); // This verifies clone was called
                                                  }

    @Test
                                        public void testSetPosition_SortsNodePointers() {
                                            // Create mock contexts with nodes in unsorted order
                                            EvalContext ctx1 = mock(EvalContext.class);
                                            EvalContext ctx2 = mock(EvalContext.class);
                                            
                                            // Setup node pointers with unsorted values
                                            NodePointer ptr1 = mock(NodePointer.class);
                                            NodePointer ptr2 = mock(NodePointer.class);
                                            when(ptr1.compareTo(ptr2)).thenReturn(1); // ptr1 > ptr2 (unsorted)
                                            
                                            // Setup context behavior
                                            when(ctx1.nextSet()).thenReturn(true).thenReturn(false);
                                            when(ctx1.nextNode()).thenReturn(true).thenReturn(false);
                                            when(ctx1.getCurrentNodePointer()).thenReturn(ptr1);
                                            
                                            when(ctx2.nextSet()).thenReturn(true).thenReturn(false);
                                            when(ctx2.nextNode()).thenReturn(true).thenReturn(false);
                                            when(ctx2.getCurrentNodePointer()).thenReturn(ptr2);
                                            
                                            EvalContext[] contexts = new EvalContext[]{ctx1, ctx2};
                                            UnionContext unionContext = new UnionContext(null, contexts);
                                            
                                            // Call setPosition which should trigger preparation
                                            unionContext.setPosition(0);
                                            
                                            // Get the node pointers through the public API
                                            List<NodePointer> pointers = new ArrayList<>();
                                            for (int i = 0; i < 2; i++) {
                                                unionContext.setPosition(i);
                                                pointers.add(unionContext.getCurrentNodePointer());
                                            }
                                            
                                            // Verify pointers are sorted (original behavior)
                                            // Since ptr1 > ptr2, sorted order should be [ptr2, ptr1]
                                            assertEquals(ptr2, pointers.get(0));
                                            assertEquals(ptr1, pointers.get(1));
                                            
                                            // The mutant would leave them as [ptr1, ptr2] which would fail this test
                                        }

    @Test
                               public void testSetPosition_SortsPointersBeforeAddingToNodeSet() {
                                   // Setup test data with multiple contexts and nodes
                                   NodePointer ptr1 = mock(NodePointer.class);
                                   NodePointer ptr2 = mock(NodePointer.class);
                                   NodePointer ptr3 = mock(NodePointer.class);
                                   
                                   // Create contexts that will return these pointers in non-sorted order
                                   EvalContext ctx1 = mock(EvalContext.class);
                                   when(ctx1.nextSet()).thenReturn(true, false);
                                   when(ctx1.nextNode()).thenReturn(true, false);
                                   when(ctx1.getCurrentNodePointer()).thenReturn(ptr2); // Middle value
                                   
                                   EvalContext ctx2 = mock(EvalContext.class);
                                   when(ctx2.nextSet()).thenReturn(true, false);
                                   when(ctx2.nextNode()).thenReturn(true, false);
                                   when(ctx2.getCurrentNodePointer()).thenReturn(ptr1); // Should be first
                                   
                                   EvalContext ctx3 = mock(EvalContext.class);
                                   when(ctx3.nextSet()).thenReturn(true, false);
                                   when(ctx3.nextNode()).thenReturn(true, false);
                                   when(ctx3.getCurrentNodePointer()).thenReturn(ptr3); // Should be last
                                   
                                   EvalContext[] contexts = {ctx1, ctx2, ctx3};
                                   UnionContext unionContext = new UnionContext(null, contexts);
                                   
                                   // Mock the comparison behavior of pointers to define expected sort order
                                   when(ptr1.compareTo(ptr2)).thenReturn(-1);
                                   when(ptr1.compareTo(ptr3)).thenReturn(-1);
                                   when(ptr2.compareTo(ptr1)).thenReturn(1);
                                   when(ptr2.compareTo(ptr3)).thenReturn(-1);
                                   when(ptr3.compareTo(ptr1)).thenReturn(1);
                                   when(ptr3.compareTo(ptr2)).thenReturn(1);
                                   
                                   // Execute
                                   unionContext.setPosition(0);
                                   
                                   // Verify the nodeSet contains pointers in sorted order
                                   BasicNodeSet nodeSet = new BasicNodeSet();
                                   try {
                                       Field nodeSetField = UnionContext.class.getDeclaredField("nodeSet");
                                       nodeSetField.setAccessible(true);
                                       nodeSet = (BasicNodeSet) nodeSetField.get(unionContext);
                                   } catch (Exception e) {
                                       fail("Failed to access nodeSet field");
                                   }
                                   
                                   List<NodePointer> pointers = new ArrayList<NodePointer>();
                                   for (Iterator<NodePointer> it = nodeSet.getPointers().iterator(); it.hasNext();) {
                                       pointers.add(it.next());
                                   }
                                   
                                   // Assert the order is correct (ptr1, ptr2, ptr3)
                                   assertEquals(ptr1, pointers.get(0));
                                   assertEquals(ptr2, pointers.get(1));
                                   assertEquals(ptr3, pointers.get(2));
                                   
                                   // Also verify the pointers were actually added (not empty)
                                   assertEquals(3, pointers.size());
                               }

    @Test
                          public void testSetPosition_ShouldNotContainDuplicatePointers() {
                              // Setup test data with duplicate pointers
                              NodePointer mockPointer1 = mock(NodePointer.class);
                              NodePointer mockPointer2 = mock(NodePointer.class);
                              
                              // Create contexts that will return duplicate pointers
                              EvalContext context1 = mock(EvalContext.class);
                              when(context1.nextSet()).thenReturn(true, false);
                              when(context1.nextNode()).thenReturn(true, false);
                              when(context1.getCurrentNodePointer()).thenReturn(mockPointer1);
                              
                              EvalContext context2 = mock(EvalContext.class);
                              when(context2.nextSet()).thenReturn(true, false);
                              when(context2.nextNode()).thenReturn(true, false);
                              when(context2.getCurrentNodePointer()).thenReturn(mockPointer1); // Same pointer as context1
                              
                              EvalContext[] contexts = {context1, context2};
                              UnionContext unionContext = new UnionContext(null, contexts);
                              
                              // Call setPosition which should prepare the node set
                              unionContext.setPosition(0);
                              
                              // Get the internal node set to verify contents
                              BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                              
                              // Verify only one instance of the pointer was added (no duplicates)
                              // This assertion would fail if the mutant is present
                              assertEquals(1, nodeSet.getPointers().size());
                              
                              // Also verify the prepared flag was set using reflection
                              try {
                                  Field preparedField = UnionContext.class.getDeclaredField("prepared");
                                  preparedField.setAccessible(true);
                                  boolean prepared = (boolean) preparedField.get(unionContext);
                                  assertTrue(prepared);
                              } catch (Exception e) {
                                  fail("Failed to access prepared field through reflection: " + e.getMessage());
                              }
                          }

    @Test
         public void testSetPosition_DetectsDuplicatePointerMutation() throws Exception {
             // Setup test data
             EvalContext mockContext1 = mock(EvalContext.class);
             EvalContext mockContext2 = mock(EvalContext.class);
             EvalContext[] contexts = new EvalContext[]{mockContext1, mockContext2};
             
             // Create mock node pointers
             NodePointer ptr1 = mock(NodePointer.class);
             NodePointer ptr2 = mock(NodePointer.class);
             
             // Mock context behavior
             when(mockContext1.nextSet()).thenReturn(true, false);
             when(mockContext1.nextNode()).thenReturn(true, true, false);
             when(mockContext1.getCurrentNodePointer()).thenReturn(ptr1, ptr2);
             
             when(mockContext2.nextSet()).thenReturn(true, false);
             when(mockContext2.nextNode()).thenReturn(true, false);
             when(mockContext2.getCurrentNodePointer()).thenReturn(ptr1); // duplicate of ptr1
             
             // Create UnionContext instance
             UnionContext unionContext = new UnionContext(null, contexts);
             
             // Verify initial state using reflection
             Field preparedField = UnionContext.class.getDeclaredField("prepared");
             preparedField.setAccessible(true);
             assertFalse((boolean) preparedField.get(unionContext));
             
             // Execute
             unionContext.setPosition(0);
             
             // Get the internal node set
             BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
             
             // Verify results - should contain exactly 2 unique nodes
             assertEquals(2, nodeSet.getPointers().size());
             assertTrue(nodeSet.getPointers().contains(ptr1));
             assertTrue(nodeSet.getPointers().contains(ptr2));
             
             // Verify prepared flag was set using reflection
             assertTrue((boolean) preparedField.get(unionContext));
             
             // Additional check for duplicates - this would fail if mutation is present
             List<NodePointer> pointers = new ArrayList<NodePointer>(nodeSet.getPointers());
             assertEquals(new java.util.HashSet<NodePointer>(pointers).size(), pointers.size());
         }

    @Test
    public void testSetPosition_IteratorScopeAndBehavior() {
        // Create mock contexts array
        EvalContext[] mockContexts = new EvalContext[2];
        mockContexts[0] = mock(EvalContext.class);
        mockContexts[1] = mock(EvalContext.class);
        
        // Setup mock context behavior
        when(mockContexts[0].nextSet()).thenReturn(true, false);
        when(mockContexts[0].nextNode()).thenReturn(true, false);
        NodePointer mockPointer1 = mock(NodePointer.class);
        when(mockContexts[0].getCurrentNodePointer()).thenReturn(mockPointer1);
        
        when(mockContexts[1].nextSet()).thenReturn(true, false);
        when(mockContexts[1].nextNode()).thenReturn(true, false);
        NodePointer mockPointer2 = mock(NodePointer.class);
        when(mockContexts[1].getCurrentNodePointer()).thenReturn(mockPointer2);
        
        // Create mock parent context and node set
        EvalContext mockParentContext = mock(EvalContext.class);
        BasicNodeSet mockNodeSet = mock(BasicNodeSet.class);
        
        // Create union context with mocks
        UnionContext unionContext = new UnionContext(mockParentContext, mockContexts);
        
        // Use reflection to set the node set
        try {
            Field nodeSetField = EvalContext.class.getDeclaredField("nodeSet");
            nodeSetField.setAccessible(true);
            nodeSetField.set(unionContext, mockNodeSet);
        } catch (Exception e) {
            fail("Reflection setup failed: " + e.getMessage());
        }
        
        // Create a spy list to verify iterator usage
        ArrayList<NodePointer> pointers = new ArrayList<>();
        ArrayList<NodePointer> spyList = spy(pointers);
        
        // Use reflection to replace the pointers list with our spy
        try {
            java.lang.reflect.Field contextsField = UnionContext.class.getDeclaredField("contexts");
            contextsField.setAccessible(true);
            contextsField.set(unionContext, mockContexts);
        } catch (Exception e) {
            fail("Reflection setup failed: " + e.getMessage());
        }
        
        // Test the method
        unionContext.setPosition(0);
        
        // Verify the iterator was used properly
        // The key verification is that iterator() is called exactly once
        verify(spyList, times(1)).iterator();
        
        // Verify all nodes were added to the node set
        verify(mockNodeSet).add(mockPointer1);
        verify(mockNodeSet).add(mockPointer2);
        
        // Verify parent's setPosition was called
        verify(mockParentContext).setPosition(0);
    }


}
