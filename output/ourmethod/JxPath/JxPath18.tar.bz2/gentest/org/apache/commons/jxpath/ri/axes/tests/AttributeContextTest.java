package gentest.org.apache.commons.jxpath.ri.axes.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.axes.*;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class AttributeContextTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                               public void testNextNode_FirstCallWithUnsupportedNodeTest_ReturnsFalse() {
                                                   // Setup
                                                   EvalContext parentContext = mock(EvalContext.class);
                                                   NodeTest unsupportedTest = mock(NodeTest.class);
                                                   
                                                   AttributeContext attributeContext = new AttributeContext(parentContext, unsupportedTest);
                                                   
                                                   // Test
                                                   boolean result = attributeContext.nextNode();
                                                   
                                                   // Verify
                                                   assertFalse(result);
                                                   
                                                   // Use reflection to access private fields for verification
                                                   try {
                                                       Field setStartedField = AttributeContext.class.getDeclaredField("setStarted");
                                                       setStartedField.setAccessible(true);
                                                       boolean setStarted = (boolean) setStartedField.get(attributeContext);
                                                       assertTrue(setStarted);
                                                       
                                                       Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                                                       iteratorField.setAccessible(true);
                                                       Object iterator = iteratorField.get(attributeContext);
                                                       assertNull(iterator);
                                                   } catch (Exception e) {
                                                       fail("Failed to access private fields: " + e.getMessage());
                                                   }
                                               }

 @Test
                                               public void testNextNode_SubsequentCallWithNoIterator_ReturnsFalse() throws Exception {
                                                   // Setup
                                                   EvalContext parentContext = mock(EvalContext.class);
                                                   NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                                                   
                                                   AttributeContext attributeContext = new AttributeContext(parentContext, nodeNameTest);
                                                   
                                                   // Set private field setStarted to true using reflection
                                                   Field setStartedField = AttributeContext.class.getDeclaredField("setStarted");
                                                   setStartedField.setAccessible(true);
                                                   setStartedField.setBoolean(attributeContext, true);
                                                   
                                                   // Set private field iterator to null using reflection
                                                   Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                                                   iteratorField.setAccessible(true);
                                                   iteratorField.set(attributeContext, null);
                                                   
                                                   // Test
                                                   boolean result = attributeContext.nextNode();
                                                   
                                                   // Verify
                                                   assertFalse(result);
                                               }

 @Test
                                           public void testNextNode_FirstCallWithNodeTypeTestNode_Success() {
                                               // Setup
                                               EvalContext parentContext = mock(EvalContext.class);
                                               NodePointer currentNodePointer = mock(NodePointer.class);
                                               NodeIterator iterator = mock(NodeIterator.class);
                                               NodeTypeTest nodeTypeTest = mock(NodeTypeTest.class);
                                               
                                               when(nodeTypeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                               when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                               when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(iterator);
                                               when(iterator.setPosition(1)).thenReturn(true);
                                               when(iterator.getNodePointer()).thenReturn(currentNodePointer);
                                               
                                               AttributeContext attributeContext = new AttributeContext(parentContext, nodeTypeTest);
                                               
                                               // Use reflection to access private field setStarted
                                               try {
                                                   Field setStartedField = AttributeContext.class.getDeclaredField("setStarted");
                                                   setStartedField.setAccessible(true);
                                                   setStartedField.setBoolean(attributeContext, false); // Initialize to false
                                               } catch (Exception e) {
                                                   fail("Failed to access private field setStarted");
                                               }
                                               
                                               // Test
                                               boolean result = attributeContext.nextNode();
                                               
                                               // Verify
                                               assertTrue(result);
                                               try {
                                                   Field setStartedField = AttributeContext.class.getDeclaredField("setStarted");
                                                   setStartedField.setAccessible(true);
                                                   assertTrue(setStartedField.getBoolean(attributeContext));
                                               } catch (Exception e) {
                                                   fail("Failed to verify setStarted field");
                                               }
                                               verify(currentNodePointer).attributeIterator(new QName("*"));
                                           }

 @Test
                                           public void testNextNode_SubsequentCallWithIteratorSuccess_ReturnsTrue() {
                                               // Setup
                                               EvalContext parentContext = mock(EvalContext.class);
                                               NodePointer currentNodePointer = mock(NodePointer.class);
                                               NodePointer newPointer = mock(NodePointer.class);
                                               NodeIterator iterator = mock(NodeIterator.class);
                                               NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                                               
                                               QName anyQName = mock(QName.class);
                                               when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                               when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(iterator);
                                               when(iterator.setPosition(1)).thenReturn(true);
                                               when(iterator.getNodePointer()).thenReturn(newPointer);
                                               
                                               AttributeContext attributeContext = new AttributeContext(parentContext, nodeNameTest);
                                               
                                               // Use reflection to set private fields
                                               try {
                                                   Field startedField = AttributeContext.class.getDeclaredField("started");
                                                   startedField.setAccessible(true);
                                                   startedField.setBoolean(attributeContext, true); // Simulate previous call
                                                   
                                                   Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                                                   iteratorField.setAccessible(true);
                                                   iteratorField.set(attributeContext, iterator);
                                               } catch (Exception e) {
                                                   fail("Failed to set private fields via reflection: " + e.getMessage());
                                               }
                                               
                                               // Test
                                               boolean result = attributeContext.nextNode();
                                               
                                               // Verify
                                               assertTrue(result);
                                               
                                               try {
                                                   Field currentPointerField = AttributeContext.class.getDeclaredField("currentNodePointer");
                                                   currentPointerField.setAccessible(true);
                                                   assertEquals(newPointer, currentPointerField.get(attributeContext));
                                               } catch (Exception e) {
                                                   fail("Failed to verify currentNodePointer: " + e.getMessage());
                                               }
                                               
                                               verify(iterator).setPosition(1);
                                           }

 @Test
                                       public void testNextNode_FirstCallWithNodeNameTest_Success() {
                                           // Setup
                                           EvalContext parentContext = mock(EvalContext.class);
                                           NodePointer currentNodePointer = mock(NodePointer.class);
                                           NodeIterator iterator = mock(NodeIterator.class);
                                           QName qname = new QName("test");
                                           NodeNameTest nodeNameTest = new NodeNameTest(qname);
                                           
                                           when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                           when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(iterator);
                                           when(iterator.setPosition(1)).thenReturn(true);
                                           when(iterator.getNodePointer()).thenReturn(currentNodePointer);
                                           
                                           AttributeContext attributeContext = new AttributeContext(parentContext, nodeNameTest);
                                           
                                           // Use reflection to access private field setStarted
                                           boolean setStarted = false;
                                           try {
                                               Field field = AttributeContext.class.getDeclaredField("setStarted");
                                               field.setAccessible(true);
                                               setStarted = field.getBoolean(attributeContext);
                                           } catch (Exception e) {
                                               fail("Failed to access private field setStarted");
                                           }
                                           
                                           // Test
                                           boolean result = attributeContext.nextNode();
                                           
                                           // Verify
                                           assertTrue(result);
                                           assertTrue(setStarted);
                                           verify(iterator).setPosition(1);
                                       }

 @Test
                                       public void testNextNode_SubsequentCallWithIteratorFails_ReturnsFalse() {
                                           // Setup
                                           EvalContext parentContext = mock(EvalContext.class);
                                           NodePointer currentNodePointer = mock(NodePointer.class);
                                           NodeIterator iterator = mock(NodeIterator.class);
                                           QName qname = new QName("test");
                                           NodeNameTest nodeNameTest = new NodeNameTest(qname);
                                           
                                           when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                           when(currentNodePointer.attributeIterator(qname)).thenReturn(iterator);
                                           when(iterator.setPosition(1)).thenReturn(false);
                                           
                                           AttributeContext attributeContext = new AttributeContext(parentContext, nodeNameTest);
                                           
                                           // Use reflection to set private fields
                                           try {
                                               Field startedField = AttributeContext.class.getDeclaredField("started");
                                               startedField.setAccessible(true);
                                               startedField.setBoolean(attributeContext, true); // Simulate previous call
                                               
                                               Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                                               iteratorField.setAccessible(true);
                                               iteratorField.set(attributeContext, iterator);
                                           } catch (Exception e) {
                                               fail("Failed to set private fields via reflection: " + e.getMessage());
                                           }
                                           
                                           // Test
                                           boolean result = attributeContext.nextNode();
                                           
                                           // Verify
                                           assertFalse(result);
                                           verify(iterator).setPosition(1);
                                       }

 @Test
                                       public void testResetSetsSetStartedToFalse() throws Exception {
                                           // Setup
                                           NodeTest mockNodeTest = mock(NodeTest.class);
                                           EvalContext mockParentContext = mock(EvalContext.class);
                                           
                                           // Create test instance
                                           AttributeContext context = new AttributeContext(mockParentContext, mockNodeTest);
                                           
                                           // Set initial state where setStarted is true
                                           // Since setStarted is private, we need to either:
                                           // 1. Use reflection to set it (shown here)
                                           // 2. Or perform operations that would set it to true naturally
                                           try {
                                               java.lang.reflect.Field field = AttributeContext.class.getDeclaredField("setStarted");
                                               field.setAccessible(true);
                                               field.set(context, true);
                                           } catch (Exception e) {
                                               fail("Failed to set setStarted field via reflection");
                                           }
                                           
                                           // Action
                                           context.reset();
                                           
                                           // Verification
                                           // Check if setStarted was properly reset to false
                                           try {
                                               java.lang.reflect.Field field = AttributeContext.class.getDeclaredField("setStarted");
                                               field.setAccessible(true);
                                               boolean actualSetStarted = (boolean) field.get(context);
                                               assertFalse("reset() should set setStarted to false", actualSetStarted);
                                           } catch (Exception e) {
                                               fail("Failed to verify setStarted field via reflection");
                                           }
                                           
                                           // Additional verification that other fields are reset
                                           // (though not directly related to this mutant)
                                           try {
                                               java.lang.reflect.Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                                               iteratorField.setAccessible(true);
                                               assertNull("iterator should be null after reset", iteratorField.get(context));
                                           } catch (Exception e) {
                                               fail("Failed to verify iterator field via reflection");
                                           }
                                       }

 @Test
                                 public void testResetShouldSetIteratorToNull() throws Exception {
                                     // Setup mock hierarchy
                                     EvalContext parentContext = mock(EvalContext.class);
                                     NodeTest nodeTest = mock(NodeTest.class);
                                     NodePointer currentNodePointer = mock(NodePointer.class);
                                     
                                     // Configure mocks
                                     when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                     
                                     // Create test object
                                     AttributeContext context = new AttributeContext(parentContext, nodeTest);
                                     
                                     // Get private fields
                                     Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                                     iteratorField.setAccessible(true);
                                     Field setStartedField = AttributeContext.class.getDeclaredField("setStarted");
                                     setStartedField.setAccessible(true);
                                     
                                     // Set some initial state to ensure reset changes it
                                     iteratorField.set(context, mock(NodeIterator.class));
                                     setStartedField.setBoolean(context, true);
                                     
                                     // Execute reset
                                     context.reset();
                                     
                                     // Verify iterator was set to null (original behavior)
                                     assertNull("Iterator should be null after reset", iteratorField.get(context));
                                     
                                     // Verify other state was reset
                                     assertFalse("setStarted should be false after reset", setStartedField.getBoolean(context));
                                     
                                     // Verify parent reset was called
                                     verify(parentContext).reset();
                                 }

 @Test
            public void testSetPositionWithCurrentGreaterThanTarget() throws Exception {
                // Setup context
                NodeTest mockNodeTest = mock(NodeTest.class);
                EvalContext parentContext = mock(EvalContext.class);
                AttributeContext context = new AttributeContext(parentContext, mockNodeTest);
                
                // Mock iterator behavior
                NodeIterator mockIterator = mock(NodeIterator.class);
                when(mockIterator.getPosition()).thenReturn(5); // Current position is 5
                
                // Use reflection to set private iterator field
                Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                iteratorField.setAccessible(true);
                iteratorField.set(context, mockIterator);
                
                // Test setPosition with target position less than current (3 < 5)
                boolean result = context.setPosition(3);
                
                // Verify behavior - should return false immediately without entering loop
                assertFalse(result);
                // Verify context's nextNode wasn't called (since we shouldn't enter loop)
                verify(mockIterator, never()).getPosition(); // Only called once initially
                
                // Additional verification that we didn't try to get position multiple times
                verify(mockIterator, times(1)).getPosition();
            }

 @Test
       public void testResetPositionIncrement() {
           // Setup test context
           NodeTest mockNodeTest = mock(NodeTest.class);
           EvalContext parentContext = mock(EvalContext.class);
           
           // Create AttributeContext and set initial position
           AttributeContext context = new AttributeContext(parentContext, mockNodeTest);
           when(context.getCurrentPosition()).thenReturn(5); // initial position
           
           // Mock the setPosition behavior to capture the value
           doReturn(true).when(context).setPosition(anyInt());
           
           // Execute reset
           context.reset();
           
           // Verify position was incremented (original behavior)
           // This will fail if mutant is present (which doesn't increment)
           verify(context).setPosition(6); // 5 + 1
           
           // Also verify other reset behaviors using reflection
           try {
               Field setStartedField = AttributeContext.class.getDeclaredField("setStarted");
               setStartedField.setAccessible(true);
               assertFalse(setStartedField.getBoolean(context));
               
               Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
               iteratorField.setAccessible(true);
               assertNull(iteratorField.get(context));
           } catch (Exception e) {
               fail("Failed to access private fields: " + e.getMessage());
           }
       }

 @Test
   public void testSetPosition_ShouldResetWhenPositionLessThanCurrent() {
       // Arrange
       AttributeContext context = new AttributeContext(null, mock(NodeTest.class));
       AttributeContext spyContext = spy(context);
       
       // Mock current position to be 5
       when(spyContext.getCurrentPosition()).thenReturn(5);
       
       // Act - try to set position to 3 (less than current)
       spyContext.setPosition(3);
       
       // Assert - verify reset was called
       verify(spyContext).reset();
       
       // Also verify we try to move forward from current position
       verify(spyContext, times(2)).nextNode(); // Would need 2 nextNode() calls to go from 3 to 5
   }

 @Test
  public void testSetPosition_OvershootPosition() {
      // Setup mock behavior
      AttributeContext context = mock(AttributeContext.class);
      
      // Stub getCurrentPosition() to return increasing values (overshooting target)
      when(context.getCurrentPosition()).thenReturn(0, 1, 2, 3); // Overshoots position 2
      
      // Stub nextNode() to always return true (allowing iteration)
      when(context.nextNode()).thenReturn(true);
      
      // Call real method for setPosition (partial mock)
      when(context.setPosition(anyInt())).thenCallRealMethod();
      
      // Test with position 2
      boolean result = context.setPosition(2);
      
      // Verify original would return true after reaching position 2
      // Mutant would continue trying to find exact match (position 3 != 2)
      assertTrue(result);
      
      // Verify nextNode() was called exactly 2 times (for positions 1 and 2)
      // Mutant would call it 3 times (positions 1, 2, and 3)
      verify(context, times(2)).nextNode();
  }

 @Test
 public void testSetPosition_BackwardMovement_ShouldReset() {
     // Setup - create context with current position at 5
     AttributeContext context = mock(AttributeContext.class);
     
     // Stub getCurrentPosition to return 5 initially
     when(context.getCurrentPosition()).thenReturn(5);
     
     // Create partial mock to test actual setPosition behavior
     AttributeContext partialMock = spy(new AttributeContext(null, null));
     when(partialMock.getCurrentPosition()).thenReturn(5);
     
     // Test - try to set position to 3 (moving backward)
     partialMock.setPosition(3);
     
     // Verify reset() was called (should be called in original, not in mutant)
     verify(partialMock).reset();
     
     // Also verify we didn't try to move forward (nextNode shouldn't be called)
     verify(partialMock, never()).nextNode();
 }

}
