package gentest.org.apache.commons.jxpath.ri.model.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.*;
import java.util.Locale;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.JXPathContextReferenceImpl;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
 
public class NodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                           public void testCompareNodePointers_EqualPointersSameDepth() {
                                                                                                                                                                               NodePointer pointer = mock(NodePointer.class);
                                                                                                                                                                               when(pointer.equals(pointer)).thenReturn(true);
                                                                                                                                                                               
                                                                                                                                                                               // Create a concrete NodePointer instance with proper parameters
                                                                                                                                                                               QName name = new QName("test");
                                                                                                                                                                               Object bean = new Object();
                                                                                                                                                                               Locale locale = Locale.getDefault();
                                                                                                                                                                               NodePointer testPointer = NodePointer.newNodePointer(name, bean, locale);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access the private compareNodePointers method
                                                                                                                                                                               try {
                                                                                                                                                                                   Method method = NodePointer.class.getDeclaredMethod("compareNodePointers", 
                                                                                                                                                                                       NodePointer.class, int.class, NodePointer.class, int.class);
                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                   int result = (int) method.invoke(testPointer, pointer, 2, pointer, 2);
                                                                                                                                                                                   assertEquals(0, result);
                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                   fail("Failed to invoke compareNodePointers method: " + e.getMessage());
                                                                                                                                                                               }
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testCompareNodePointers_NullPointersSameDepth() throws Exception {
                                                                                                                                                                               NodePointer pointer = NodePointer.newNodePointer(null, null, null);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                                                                   "compareNodePointers", 
                                                                                                                                                                                   NodePointer.class, int.class, NodePointer.class, int.class
                                                                                                                                                                               );
                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               int result = (int) method.invoke(pointer, null, 1, null, 1);
                                                                                                                                                                               assertEquals(0, result);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testCompareNodePointers_Depth1LessThanDepth() throws Exception {
                                                                                                                                                                               NodePointer p1 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2Parent = mock(NodePointer.class);
                                                                                                                                                                               
                                                                                                                                                                               when(p2.getParent()).thenReturn(p2Parent);
                                                                                                                                                                               when(p1.equals(p2Parent)).thenReturn(false);
                                                                                                                                                                               when(p1.compareChildNodePointers(p1, p2Parent)).thenReturn(-1);
                                                                                                                                                                               
                                                                                                                                                                               // Create a concrete NodePointer instance using the factory method
                                                                                                                                                                               NodePointer testPointer = NodePointer.newNodePointer(null, null, null);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access the private method
                                                                                                                                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                                                                   "compareNodePointers", 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class, 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class
                                                                                                                                                                               );
                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               int result = (int) method.invoke(testPointer, p1, 1, p2, 2);
                                                                                                                                                                               assertEquals(-1, result);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testCompareNodePointers_Depth1GreaterThanDepth() throws Exception {
                                                                                                                                                                               NodePointer p1 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p1Parent = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2 = mock(NodePointer.class);
                                                                                                                                                                               
                                                                                                                                                                               when(p1.getParent()).thenReturn(p1Parent);
                                                                                                                                                                               when(p1Parent.equals(p2)).thenReturn(false);
                                                                                                                                                                               when(p1Parent.compareChildNodePointers(p1Parent, p2)).thenReturn(1);
                                                                                                                                                                               
                                                                                                                                                                               // Create a test NodePointer instance
                                                                                                                                                                               NodePointer testPointer = NodePointer.newNodePointer(null, null, null);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access the private method
                                                                                                                                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                                                                   "compareNodePointers", 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class, 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class
                                                                                                                                                                               );
                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                               int result = (int) method.invoke(testPointer, p1, 2, p2, 1);
                                                                                                                                                                               
                                                                                                                                                                               assertEquals(1, result);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testCompareNodePointers_Depth1EqualsDepth2DifferentPointers() throws Exception {
                                                                                                                                                                               NodePointer p1 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p1Parent = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2Parent = mock(NodePointer.class);
                                                                                                                                                                               
                                                                                                                                                                               when(p1.getParent()).thenReturn(p1Parent);
                                                                                                                                                                               when(p2.getParent()).thenReturn(p2Parent);
                                                                                                                                                                               when(p1Parent.equals(p2Parent)).thenReturn(false);
                                                                                                                                                                               when(p1Parent.compareChildNodePointers(p1, p2)).thenReturn(-1);
                                                                                                                                                                               
                                                                                                                                                                               // Create a concrete NodePointer instance using one of the factory methods
                                                                                                                                                                               NodePointer testPointer = NodePointer.newNodePointer(null, null, null);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access the private method
                                                                                                                                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                                                                   "compareNodePointers", 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class, 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class
                                                                                                                                                                               );
                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                               int result = (int) method.invoke(testPointer, p1, 2, p2, 2);
                                                                                                                                                                               
                                                                                                                                                                               assertEquals(-1, result);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testCompareNodePointers_Depth1EqualsDepth2SameParents() throws Exception {
                                                                                                                                                                               NodePointer p1 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                               NodePointer testPointer = NodePointer.newNodePointer(null, null, null);
                                                                                                                                                                               
                                                                                                                                                                               when(p1.getParent()).thenReturn(parent);
                                                                                                                                                                               when(p2.getParent()).thenReturn(parent);
                                                                                                                                                                               when(parent.equals(parent)).thenReturn(true);
                                                                                                                                                                               when(parent.compareChildNodePointers(p1, p2)).thenReturn(1);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                                                                   "compareNodePointers", 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class, 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class
                                                                                                                                                                               );
                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                               int result = (int) method.invoke(testPointer, p1, 2, p2, 2);
                                                                                                                                                                               
                                                                                                                                                                               assertEquals(1, result);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testCompareNodePointers_Depth1Equals() throws Exception {
                                                                                                                                                                               NodePointer p1 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2 = mock(NodePointer.class);
                                                                                                                                                                               QName name = new QName("test");
                                                                                                                                                                               Locale locale = Locale.getDefault();
                                                                                                                                                                               
                                                                                                                                                                               NodePointer testPointer = NodePointer.newNodePointer(name, null, locale);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                                                                   "compareNodePointers", 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class, 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class
                                                                                                                                                                               );
                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                               int result = (int) method.invoke(testPointer, p1, 1, p2, 1);
                                                                                                                                                                               
                                                                                                                                                                               assertEquals(0, result);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testCompareNodePointers_RecursiveComparison() throws Exception {
                                                                                                                                                                               NodePointer p1 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2 = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p1Parent = mock(NodePointer.class);
                                                                                                                                                                               NodePointer p2Parent = mock(NodePointer.class);
                                                                                                                                                                               NodePointer grandParent = mock(NodePointer.class);
                                                                                                                                                                               
                                                                                                                                                                               // Set up parent hierarchy
                                                                                                                                                                               when(p1.getParent()).thenReturn(p1Parent);
                                                                                                                                                                               when(p2.getParent()).thenReturn(p2Parent);
                                                                                                                                                                               when(p1Parent.getParent()).thenReturn(grandParent);
                                                                                                                                                                               when(p2Parent.getParent()).thenReturn(grandParent);
                                                                                                                                                                               
                                                                                                                                                                               // First recursive call will compare parents
                                                                                                                                                                               when(p1Parent.equals(p2Parent)).thenReturn(false);
                                                                                                                                                                               when(p1Parent.compareChildNodePointers(p1Parent, p2Parent)).thenReturn(0);
                                                                                                                                                                               
                                                                                                                                                                               // Then compare the original nodes
                                                                                                                                                                               when(grandParent.compareChildNodePointers(p1Parent, p2Parent)).thenReturn(-1);
                                                                                                                                                                               
                                                                                                                                                                               // Create a concrete NodePointer instance using one of the factory methods
                                                                                                                                                                               NodePointer testPointer = NodePointer.newChildNodePointer(null, null, null);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private compareNodePointers method
                                                                                                                                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                                                                   "compareNodePointers", 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class, 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class
                                                                                                                                                                               );
                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                               int result = (int) method.invoke(testPointer, p1, 3, p2, 3);
                                                                                                                                                                               
                                                                                                                                                                               assertEquals(-1, result);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testCompareNodePointers_OneNullPointer() throws Exception {
                                                                                                                                                                               NodePointer p1 = mock(NodePointer.class);
                                                                                                                                                                               QName name = new QName("test");
                                                                                                                                                                               Locale locale = Locale.getDefault();
                                                                                                                                                                               
                                                                                                                                                                               NodePointer parentPointer = NodePointer.newNodePointer(name, null, locale);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                                                                   "compareNodePointers", 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class, 
                                                                                                                                                                                   NodePointer.class, 
                                                                                                                                                                                   int.class
                                                                                                                                                                               );
                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                               int result = (int) method.invoke(parentPointer, p1, 2, null, 2);
                                                                                                                                                                               
                                                                                                                                                                               assertTrue(result != 0);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                      public void testAsPathWithNonContainerParentShouldBuildFullPath() {
                                                                                                                                                                          // Setup - create parent that is not a container
                                                                                                                                                                          NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                          when(parent.isContainer()).thenReturn(false);
                                                                                                                                                                          when(parent.asPath()).thenReturn("/parentPath");
                                                                                                                                                                          
                                                                                                                                                                          // Create test node with this parent
                                                                                                                                                                          NodePointer node = new NodePointer(parent) {
                                                                                                                                                                              @Override
                                                                                                                                                                              public boolean isCollection() {
                                                                                                                                                                                  return false;
                                                                                                                                                                              }
                                                                                                                                                                              
                                                                                                                                                                              @Override
                                                                                                                                                                              public QName getName() {
                                                                                                                                                                                  return new QName("testNode");
                                                                                                                                                                              }
                                                                                                                                                                              
                                                                                                                                                                              @Override
                                                                                                                                                                              public boolean isLeaf() {
                                                                                                                                                                                  return false;
                                                                                                                                                                              }
                                                                                                                                                                              
                                                                                                                                                                              @Override
                                                                                                                                                                              public Object getBaseValue() {
                                                                                                                                                                                  return null;
                                                                                                                                                                              }
                                                                                                                                                                              
                                                                                                                                                                              @Override
                                                                                                                                                                              public Object getImmediateNode() {
                                                                                                                                                                                  return null;
                                                                                                                                                                              }
                                                                                                                                                                              
                                                                                                                                                                              @Override
                                                                                                                                                                              public void setValue(Object value) {
                                                                                                                                                                              }
                                                                                                                                                                              
                                                                                                                                                                              @Override
                                                                                                                                                                              public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                                                                                                                                                                  return 0;
                                                                                                                                                                              }
                                                                                                                                                                              
                                                                                                                                                                              @Override
                                                                                                                                                                              public int getLength() {
                                                                                                                                                                                  return 0;
                                                                                                                                                                              }
                                                                                                                                                                          };
                                                                                                                                                                          
                                                                                                                                                                          // Original behavior should build full path
                                                                                                                                                                          String expected = "/parentPath/testNode";
                                                                                                                                                                          String actual = node.asPath();
                                                                                                                                                                          
                                                                                                                                                                          // This will fail on mutant (which would return just "/parentPath")
                                                                                                                                                                          assertEquals(expected, actual);
                                                                                                                                                                      }

    @Test
                                                                                                                                                                 public void testAsPath_WhenParentIsContainer_ShouldReturnParentPath() {
                                                                                                                                                                     // Setup
                                                                                                                                                                     NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                     when(parent.isContainer()).thenReturn(true);
                                                                                                                                                                     when(parent.asPath()).thenReturn("/parent/path");
                                                                                                                                                                     
                                                                                                                                                                     // Create a testable NodePointer instance using the factory method
                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                     Object bean = new Object();
                                                                                                                                                                     NodePointer nodePointer = NodePointer.newChildNodePointer(parent, name, bean);
                                                                                                                                                                     
                                                                                                                                                                     // Exercise
                                                                                                                                                                     String result = nodePointer.asPath();
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertEquals("Should return parent's path when parent is container", 
                                                                                                                                                                                 "/parent/path", result);
                                                                                                                                                                     
                                                                                                                                                                     // Verify interactions
                                                                                                                                                                     verify(parent).isContainer();
                                                                                                                                                                     verify(parent).asPath();
                                                                                                                                                                 }

    @Test(expected = NullPointerException.class)
                                                                                                                                                            public void testAsPath_DetectsNullBufferMutant() {
                                                                                                                                                                // Setup parent that is not a container and returns empty path
                                                                                                                                                                NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                when(parent.isContainer()).thenReturn(false);
                                                                                                                                                                when(parent.asPath()).thenReturn("");
                                                                                                                                                                
                                                                                                                                                                // Create test node pointer with:
                                                                                                                                                                // - parent (not container)
                                                                                                                                                                // - not attribute
                                                                                                                                                                // - not collection
                                                                                                                                                                NodePointer pointer = new NodePointer(parent) {
                                                                                                                                                                    @Override
                                                                                                                                                                    public boolean isCollection() {
                                                                                                                                                                        return false;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public boolean isLeaf() {
                                                                                                                                                                        return false;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public QName getName() {
                                                                                                                                                                        return new QName("test");
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public Object getBaseValue() {
                                                                                                                                                                        return null;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public Object getImmediateNode() {
                                                                                                                                                                        return null;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public int getLength() {
                                                                                                                                                                        return 0;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public void setValue(Object value) {
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    @Override
                                                                                                                                                                    public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                                                                                                                                                        return 0;
                                                                                                                                                                    }
                                                                                                                                                                };
                                                                                                                                                                
                                                                                                                                                                // This will throw NPE with mutant but return "/test" in original
                                                                                                                                                                pointer.asPath();
                                                                                                                                                                
                                                                                                                                                                // If we get here without exception, the test fails (mutant survived)
                                                                                                                                                                // With @Test(expected) we declare we expect NPE for mutant case
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testAsPathWithParentShouldIncludeParentPath() {
                                                                                                                                                           // Setup
                                                                                                                                                           NodePointer parent = mock(NodePointer.class);
                                                                                                                                                           when(parent.isContainer()).thenReturn(false);
                                                                                                                                                           when(parent.asPath()).thenReturn("/parentPath");
                                                                                                                                                           
                                                                                                                                                           NodePointer nodePointer = new NodePointer(parent) {
                                                                                                                                                               @Override
                                                                                                                                                               public boolean isCollection() {
                                                                                                                                                                   return false;
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public QName getName() {
                                                                                                                                                                   return new QName("nodeName");
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public boolean isLeaf() {
                                                                                                                                                                   return false;
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public Object getBaseValue() {
                                                                                                                                                                   return null;
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public Object getImmediateNode() {
                                                                                                                                                                   return null;
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public void setValue(Object value) {
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                                                                                                                                                   return 0;
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public int getLength() {
                                                                                                                                                                   return 0;
                                                                                                                                                               }
                                                                                                                                                           };
                                                                                                                                                           
                                                                                                                                                           // Test
                                                                                                                                                           String result = nodePointer.asPath();
                                                                                                                                                           
                                                                                                                                                           // Verify
                                                                                                                                                           // Original should include parent path, mutant won't
                                                                                                                                                           assertEquals("/parentPath/nodeName", result);
                                                                                                                                                           
                                                                                                                                                           // Verify parent.asPath() was called (wouldn't be called in mutant)
                                                                                                                                                           verify(parent).asPath();
                                                                                                                                                       }

    @Test
                                                                                                                                                   public void testAsPath_WhenParentPathDoesNotEndWithSlash_ShouldAddSlash() {
                                                                                                                                                       // Setup
                                                                                                                                                       NodePointer parent = mock(NodePointer.class);
                                                                                                                                                       when(parent.isContainer()).thenReturn(false);
                                                                                                                                                       when(parent.asPath()).thenReturn("parentPath"); // Doesn't end with '/'
                                                                                                                                                       
                                                                                                                                                       NodePointer nodePointer = new NodePointer(parent) {
                                                                                                                                                           @Override
                                                                                                                                                           public boolean isCollection() {
                                                                                                                                                               return false;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public QName getName() {
                                                                                                                                                               return new QName("nodeName");
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public boolean isLeaf() {
                                                                                                                                                               return false;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public Object getBaseValue() {
                                                                                                                                                               return null;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public Object getImmediateNode() {
                                                                                                                                                               return null;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public int getLength() {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public void setValue(Object value) {
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           @Override
                                                                                                                                                           public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Test
                                                                                                                                                       String result = nodePointer.asPath();
                                                                                                                                                       
                                                                                                                                                       // Verify
                                                                                                                                                       // Original would produce "parentPath/nodeName"
                                                                                                                                                       // Mutant would produce "parentPathnodeName" (no slash added)
                                                                                                                                                       assertEquals("parentPath/nodeName", result);
                                                                                                                                                   }

    @Test
                                                                                                                         public void testAsPathWithAttribute() {
                                                                                                                             // Create test node pointer with mocked parent
                                                                                                                             NodePointer parent = mock(NodePointer.class);
                                                                                                                             when(parent.isContainer()).thenReturn(false);
                                                                                                                             when(parent.asPath()).thenReturn("");
                                                                                                                             
                                                                                                                             // Test with attribute=true
                                                                                                                             NodePointer pointer = new NodePointer(parent) {
                                                                                                                                 @Override
                                                                                                                                 public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                                                                                                                     return 0; // Simple implementation for test
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 @Override
                                                                                                                                 public QName getName() {
                                                                                                                                     return new QName("test");
                                                                                                                                 }
                                                                                                                             
                                                                                                                                 @Override
                                                                                                                                 public void setValue(Object value) {
                                                                                                                                     // Simple implementation for test
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 @Override
                                                                                                                                 public Object getImmediateNode() {
                                                                                                                                     return null; // Simple implementation for test
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 @Override
                                                                                                                                 public Object getBaseValue() {
                                                                                                                                     return null; // Simple implementation for test
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 @Override
                                                                                                                                 public int getLength() {
                                                                                                                                     return 0; // Simple implementation for test
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 @Override
                                                                                                                                 public boolean isCollection() {
                                                                                                                                     return false; // Simple implementation for test
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 @Override
                                                                                                                                 public boolean isLeaf() {
                                                                                                                                     return false; // Simple implementation for test
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             pointer.setAttribute(true);
                                                                                                                             String path = pointer.asPath();
                                                                                                                             // Should contain '@' before name
                                                                                                                             assertTrue("Path should contain '@' for attribute node", path.contains("@test"));
                                                                                                                             
                                                                                                                             // Test with attribute=false
                                                                                                                             pointer.setAttribute(false);
                                                                                                                             path = pointer.asPath();
                                                                                                                             // Should not contain '@' before name
                                                                                                                             assertFalse("Path should not contain '@' for non-attribute node", path.contains("@test"));
                                                                                                                         }

    @Test
                                                                                                    public void testAsPathWithCollectionIndex() {
                                                                                                        // Setup parent mock
                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                        when(parent.isContainer()).thenReturn(false);
                                                                                                        when(parent.asPath()).thenReturn("/parent");
                                                                                                        
                                                                                                        // Setup test node
                                                                                                        NodePointer node = new NodePointer(parent) {
                                                                                                            @Override
                                                                                                            public boolean isCollection() {
                                                                                                                return true;
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public QName getName() {
                                                                                                                return new QName("test");
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public boolean isLeaf() {
                                                                                                                return false;
                                                                                                            }
                                                                                                        
                                                                                                            @Override
                                                                                                            public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                                                                                                return 0; // Simple implementation for test purposes
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public void setValue(Object value) {
                                                                                                                // Simple implementation for test purposes
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public Object getImmediateNode() {
                                                                                                                return null; // Simple implementation for test purposes
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public Object getBaseValue() {
                                                                                                                return null; // Simple implementation for test purposes
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public int getLength() {
                                                                                                                return 0; // Simple implementation for test purposes
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Set index to test (not WHOLE_COLLECTION)
                                                                                                        node.setIndex(2); // Will expect 3 in original (2+1), 2 in mutant
                                                                                                        
                                                                                                        // Execute and verify
                                                                                                        String path = node.asPath();
                                                                                                        assertTrue("Path should contain index+1 for collection", 
                                                                                                                   path.contains("[3]"));
                                                                                                        
                                                                                                        // Additional assertions to verify full path
                                                                                                        assertEquals("/parent/test[3]", path);
                                                                                                    }

    @Test
                                                                                               public void testAsPathWithModifiedParentShouldNotAffectChild() {
                                                                                                   // Create parent pointer with mock behavior
                                                                                                   NodePointer parent = mock(NodePointer.class);
                                                                                                   when(parent.isContainer()).thenReturn(false);
                                                                                                   when(parent.asPath()).thenReturn("/original");
                                                                                                   when(parent.clone()).thenReturn(mock(NodePointer.class));
                                                                                                   
                                                                                                   // Create child pointer using newChildNodePointer
                                                                                                   QName name = new QName("test");
                                                                                                   Object bean = new Object();
                                                                                                   NodePointer child = NodePointer.newChildNodePointer(parent, name, bean);
                                                                                                   child.setAttribute(false);
                                                                                                   child.setIndex(NodePointer.WHOLE_COLLECTION);
                                                                                                   
                                                                                                   // Store original path
                                                                                                   String originalPath = child.asPath();
                                                                                                   
                                                                                                   // Modify parent's path behavior
                                                                                                   when(parent.asPath()).thenReturn("/modified");
                                                                                                   
                                                                                                   // Verify child's path didn't change
                                                                                                   assertEquals("Child path should not change when parent is modified", 
                                                                                                       originalPath, child.asPath());
                                                                                                   
                                                                                                   // Additional verification that we interacted with parent
                                                                                                   verify(parent, atLeastOnce()).asPath();
                                                                                               }

    @Test
                                                                          public void testAsPathWithEqualParentPointers() {
                                                                              // Create parent pointer
                                                                              NodePointer parentPointer = mock(NodePointer.class);
                                                                              when(parentPointer.isContainer()).thenReturn(true);
                                                                              when(parentPointer.asPath()).thenReturn("/parent/path");
                                                                              
                                                                              // Create test pointer with same parent reference
                                                                              NodePointer pointer = new NodePointer(parentPointer) {
                                                                                  @Override
                                                                                  public QName getName() {
                                                                                      return new QName("test");
                                                                                  }
                                                                                  
                                                                                  @Override
                                                                                  public boolean isCollection() {
                                                                                      return false;
                                                                                  }
                                                                                  
                                                                                  @Override
                                                                                  public boolean isLeaf() {
                                                                                      return false;
                                                                                  }
                                                                                  
                                                                                  @Override
                                                                                  public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                                                                      return 0;
                                                                                  }
                                                                                  
                                                                                  @Override
                                                                                  public void setValue(Object value) {
                                                                                      // Implementation required by abstract class
                                                                                  }
                                                                                  
                                                                                  @Override
                                                                                  public Object getImmediateNode() {
                                                                                      return null; // Implementation required by abstract class
                                                                                  }
                                                                                  
                                                                                  @Override
                                                                                  public Object getBaseValue() {
                                                                                      return null; // Implementation required by abstract class
                                                                                  }
                                                                                  
                                                                                  @Override
                                                                                  public int getLength() {
                                                                                      return 0; // Implementation required by abstract class
                                                                                  }
                                                                              };
                                                                              
                                                                              // Set pointer's parent to be the same as parentPointer's parent
                                                                              // This is where the mutation would be caught
                                                                              NodePointer grandParent = mock(NodePointer.class);
                                                                              when(parentPointer.getParent()).thenReturn(grandParent);
                                                                              // Use reflection to set protected parent field
                                                                              try {
                                                                                  Field parentField = NodePointer.class.getDeclaredField("parent");
                                                                                  parentField.setAccessible(true);
                                                                                  parentField.set(pointer, grandParent);
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to set parent field via reflection");
                                                                              }
                                                                              
                                                                              // Should use parent's path directly since parents are equal and it's a container
                                                                              String result = pointer.asPath();
                                                                              assertEquals("/parent/path", result);
                                                                              
                                                                              // Now test with different parents
                                                                              NodePointer differentParent = mock(NodePointer.class);
                                                                              when(differentParent.isContainer()).thenReturn(true);
                                                                              when(differentParent.asPath()).thenReturn("/different/parent/path");
                                                                              // Use reflection to set protected parent field
                                                                              try {
                                                                                  Field parentField = NodePointer.class.getDeclaredField("parent");
                                                                                  parentField.setAccessible(true);
                                                                                  parentField.set(pointer, differentParent);
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to set parent field via reflection");
                                                                              }
                                                                              
                                                                              // Should build new path since parents are different
                                                                              result = pointer.asPath();
                                                                              assertNotEquals("/parent/path", result);
                                                                              assertTrue(result.startsWith("/different/parent/path"));
                                                                          }

    @Test
                                                                      public void testCompareToWithNullParents() {
                                                                          // Create two node pointers with null parents
                                                                          NodePointer pointer1 = new NodePointer(null) {
                                                                              @Override
                                                                              public boolean isLeaf() { return false; }
                                                                              @Override
                                                                              public boolean isCollection() { return false; }
                                                                              @Override
                                                                              public int getLength() { return 0; }
                                                                              @Override
                                                                              public QName getName() { return null; }
                                                                              @Override
                                                                              public Object getBaseValue() { return null; }
                                                                              @Override
                                                                              public Object getImmediateNode() { return null; }
                                                                              @Override
                                                                              public void setValue(Object value) {}
                                                                              @Override
                                                                              public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) { return 0; }
                                                                          };
                                                                          
                                                                          NodePointer pointer2 = new NodePointer(null) {
                                                                              @Override
                                                                              public boolean isLeaf() { return false; }
                                                                              @Override
                                                                              public boolean isCollection() { return false; }
                                                                              @Override
                                                                              public int getLength() { return 0; }
                                                                              @Override
                                                                              public QName getName() { return null; }
                                                                              @Override
                                                                              public Object getBaseValue() { return null; }
                                                                              @Override
                                                                              public Object getImmediateNode() { return null; }
                                                                              @Override
                                                                              public void setValue(Object value) {}
                                                                              @Override
                                                                              public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) { return 0; }
                                                                          };
                                                                          
                                                                          // When comparing two nodes with null parents, should return 0
                                                                          assertEquals(0, pointer1.compareTo(pointer2));
                                                                          
                                                                          // The mutant would return 1 in this case
                                                                      }

    @Test
                                                                public void testAsPath() {
                                                                    final int WHOLE_COLLECTION = -1;
                                                                    
                                                                    // Test with no parent
                                                                    NodePointer pointer = new NodePointer(null) {
                                                                        @Override
                                                                        public boolean isCollection() { return false; }
                                                                        @Override
                                                                        public QName getName() { return new QName("test"); }
                                                                        @Override
                                                                        public boolean isContainer() { return false; }
                                                                        @Override
                                                                        public Object getBaseValue() { return null; }
                                                                        @Override
                                                                        public Object getImmediateNode() { return null; }
                                                                        @Override
                                                                        public void setValue(Object value) {}
                                                                        @Override
                                                                        public int compareChildNodePointers(NodePointer p1, NodePointer p2) { return 0; }
                                                                        @Override
                                                                        public int getLength() { return 0; }
                                                                        @Override
                                                                        public boolean isLeaf() { return true; }
                                                                    };
                                                                    pointer.setIndex(WHOLE_COLLECTION);
                                                                    pointer.setAttribute(false);
                                                                    assertEquals("/test", pointer.asPath());
                                                                
                                                                    // Test with parent and isContainer
                                                                    NodePointer parent = mock(NodePointer.class);
                                                                    when(parent.isContainer()).thenReturn(true);
                                                                    when(parent.asPath()).thenReturn("/parent");
                                                                    pointer = new NodePointer(parent) {
                                                                        @Override public boolean isCollection() { return false; }
                                                                        @Override public QName getName() { return new QName("child"); }
                                                                        @Override public boolean isContainer() { return false; }
                                                                        @Override public Object getBaseValue() { return null; }
                                                                        @Override public Object getImmediateNode() { return null; }
                                                                        @Override public void setValue(Object value) {}
                                                                        @Override public int compareChildNodePointers(NodePointer p1, NodePointer p2) { return 0; }
                                                                        @Override public int getLength() { return 0; }
                                                                        @Override public boolean isLeaf() { return true; }
                                                                    };
                                                                    assertEquals("/parent", pointer.asPath());
                                                                
                                                                    // Test with parent, not container, attribute
                                                                    when(parent.isContainer()).thenReturn(false);
                                                                    pointer.setAttribute(true);
                                                                    assertEquals("/parent/@child", pointer.asPath());
                                                                
                                                                    // Test with parent path already ending with slash
                                                                    when(parent.asPath()).thenReturn("/parent/");
                                                                    assertEquals("/parent/@child", pointer.asPath());
                                                                
                                                                    // Test collection with index
                                                                    NodePointer collectionPointer = new NodePointer(parent) {
                                                                        @Override public boolean isCollection() { return true; }
                                                                        @Override public QName getName() { return new QName("child"); }
                                                                        @Override public boolean isContainer() { return false; }
                                                                        @Override public Object getBaseValue() { return null; }
                                                                        @Override public Object getImmediateNode() { return null; }
                                                                        @Override public void setValue(Object value) {}
                                                                        @Override public int compareChildNodePointers(NodePointer p1, NodePointer p2) { return 0; }
                                                                        @Override public int getLength() { return 0; }
                                                                        @Override public boolean isLeaf() { return false; }
                                                                    };
                                                                    collectionPointer.setAttribute(false);
                                                                    collectionPointer.setIndex(2);
                                                                    assertEquals("/parent/child[3]", collectionPointer.asPath());
                                                                
                                                                    // Test collection with WHOLE_COLLECTION index
                                                                    collectionPointer.setIndex(WHOLE_COLLECTION);
                                                                    assertEquals("/parent/child", collectionPointer.asPath());
                                                                }

    @Test
                                                           public void testAsPathWithCollectionAndZeroIndex() {
                                                               // Setup
                                                               NodePointer parent = mock(NodePointer.class);
                                                               when(parent.isContainer()).thenReturn(false);
                                                               when(parent.asPath()).thenReturn("/parent");
                                                               
                                                               NodePointer pointer = new NodePointer(parent) {
                                                                   @Override
                                                                   public boolean isCollection() {
                                                                       return true;
                                                                   }
                                                                   
                                                                   @Override
                                                                   public QName getName() {
                                                                       return new QName("test");
                                                                   }
                                                                   
                                                                   @Override
                                                                   public int getLength() {
                                                                       return 0; // This would make r == 0 in the original code
                                                                   }
                                                                   
                                                                   @Override
                                                                   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                                                       return 0; // Simple implementation for testing
                                                                   }
                                                                   
                                                                   @Override
                                                                   public Object getBaseValue() {
                                                                       return null;
                                                                   }
                                                                   
                                                                   @Override
                                                                   public Object getImmediateNode() {
                                                                       return null;
                                                                   }
                                                                   
                                                                   @Override
                                                                   public void setValue(Object value) {
                                                                   }
                                                                   
                                                                   @Override
                                                                   public boolean isLeaf() {
                                                                       return false;
                                                                   }
                                                               };
                                                               
                                                               pointer.setIndex(0); // WHOLE_COLLECTION is typically -1, 0 is valid index
                                                               
                                                               // Test
                                                               String result = pointer.asPath();
                                                               
                                                               // Verify - should contain [1] if original behavior (0+1)
                                                               // Mutation would show [-1] or other incorrect value
                                                               assertTrue("Path should contain index notation", result.contains("[1]"));
                                                           }

    @Test
                                  public void testAsPathBufferConditions() {
                                      // Create a mock parent that returns a known path
                                      NodePointer parent = mock(NodePointer.class);
                                      when(parent.asPath()).thenReturn("parentPath");
                                      when(parent.isContainer()).thenReturn(false);
                                      
                                      // Test when buffer doesn't end with '/'
                                      NodePointer pointer = new NodePointer(parent) {
                                          @Override
                                          public boolean isCollection() {
                                              return false;
                                          }
                                          
                                          @Override
                                          public QName getName() {
                                              return new QName("testName");
                                          }
                                          
                                          @Override
                                          public boolean isContainer() {
                                              return false;
                                          }
                                          
                                          @Override
                                          public boolean isLeaf() {
                                              return false;
                                          }
                                          
                                          @Override
                                          public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                              return 0;
                                          }
                                          
                                          @Override
                                          public void setValue(Object value) {
                                              // Implementation required by abstract class
                                          }
                                          
                                          @Override
                                          public Object getImmediateNode() {
                                              return null;
                                          }
                                          
                                          @Override
                                          public Object getBaseValue() {
                                              return null;
                                          }
                                          
                                          @Override
                                          public int getLength() {
                                              return 0;
                                          }
                                      };
                                      
                                      // Should add '/' since parent path doesn't end with it
                                      String result = pointer.asPath();
                                      assertEquals("parentPath/testName", result);
                                      
                                      // Test when buffer ends with '/'
                                      when(parent.asPath()).thenReturn("parentPath/");
                                      result = pointer.asPath();
                                      assertEquals("parentPath/testName", result); // Should not add extra '/'
                                      
                                      // Test empty buffer case
                                      NodePointer noParentPointer = new NodePointer(null) {
                                          @Override
                                          public boolean isCollection() {
                                              return false;
                                          }
                                          
                                          @Override
                                          public QName getName() {
                                              return new QName("testName");
                                          }
                                          
                                          @Override
                                          public boolean isContainer() {
                                              return false;
                                          }
                                          
                                          @Override
                                          public boolean isLeaf() {
                                              return false;
                                          }
                                          
                                          @Override
                                          public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) {
                                              return 0;
                                          }
                                          
                                          @Override
                                          public void setValue(Object value) {
                                              // Implementation required by abstract class
                                          }
                                          
                                          @Override
                                          public Object getImmediateNode() {
                                              return null;
                                          }
                                          
                                          @Override
                                          public Object getBaseValue() {
                                              return null;
                                          }
                                          
                                          @Override
                                          public int getLength() {
                                              return 0;
                                          }
                                      };
                                      
                                      result = noParentPointer.asPath();
                                      assertEquals("/testName", result); // Should add '/' for empty buffer
                                  }

    @Test
                             public void testCloneWithParent() throws Exception {
                                 // Create parent pointer
                                 NodePointer parentPointer = new NodePointer(null) {
                                     // Anonymous subclass to implement abstract methods
                                     @Override public boolean isLeaf() { return false; }
                                     @Override public boolean isCollection() { return false; }
                                     @Override public int getLength() { return 0; }
                                     @Override public QName getName() { return null; }
                                     @Override public Object getBaseValue() { return null; }
                                     @Override public Object getImmediateNode() { return null; }
                                     @Override public void setValue(Object value) {}
                                     @Override public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) { return 0; }
                                 };
                                 
                                 // Create child pointer with parent
                                 NodePointer original = new NodePointer(parentPointer) {
                                     @Override public boolean isLeaf() { return false; }
                                     @Override public boolean isCollection() { return false; }
                                     @Override public int getLength() { return 0; }
                                     @Override public QName getName() { return null; }
                                     @Override public Object getBaseValue() { return null; }
                                     @Override public Object getImmediateNode() { return null; }
                                     @Override public void setValue(Object value) {}
                                     @Override public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) { return 0; }
                                 };
                                 
                                 // Clone the pointer
                                 NodePointer cloned = (NodePointer) original.clone();
                                 
                                 // Verify parent was cloned (should be different object but equal)
                                 assertNotNull("Cloned pointer should not be null", cloned);
                                 assertNotSame("Cloned parent should be a new object", original.getParent(), cloned.getParent());
                                 assertEquals("Cloned parent should equal original parent", original.getParent(), cloned.getParent());
                             }

    @Test
                             public void testCloneWithoutParent() throws Exception {
                                 // Create pointer without parent
                                 NodePointer original = new NodePointer(null) {
                                     @Override public boolean isLeaf() { return false; }
                                     @Override public boolean isCollection() { return false; }
                                     @Override public int getLength() { return 0; }
                                     @Override public QName getName() { return null; }
                                     @Override public Object getBaseValue() { return null; }
                                     @Override public Object getImmediateNode() { return null; }
                                     @Override public void setValue(Object value) {}
                                     @Override public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) { return 0; }
                                 };
                                 
                                 // Clone the pointer
                                 NodePointer cloned = (NodePointer) original.clone();
                                 
                                 // Verify clone worked and parent is still null
                                 assertNotNull("Cloned pointer should not be null", cloned);
                                 assertNull("Cloned pointer's parent should be null", cloned.getParent());
                             }

    @Test
                        public void testCloneCreatesDeepCopyOfParent() throws Exception {
                            // Create parent and child pointers using factory methods
                            NodePointer parent = NodePointer.newNodePointer(null, null, null);
                            NodePointer original = NodePointer.newChildNodePointer(parent, null, null);
                            
                            // Clone the child pointer
                            NodePointer cloned = (NodePointer) original.clone();
                            
                            // Verify clone has its own parent copy (not same reference)
                            assertNotSame("Clone's parent should be a different object", 
                                         original.getParent(), 
                                         cloned.getParent());
                            
                            // Modify original's parent (should not affect clone)
                            original.getParent().setIndex(5);
                            assertNotEquals("Modifying original's parent should not affect clone's parent",
                                           original.getParent().getIndex(),
                                           cloned.getParent().getIndex());
                            
                            // Verify clone's parent is unchanged
                            assertEquals("Clone's parent index should remain default",
                                        0, cloned.getParent().getIndex());
                        }

    @Test
                   public void testCloneWithParent1() throws Exception {
                       // Setup - create parent and child pointers
                       NodePointer parent = mock(NodePointer.class);
                       NodePointer parentClone = mock(NodePointer.class);
                       when(parent.clone()).thenReturn(parentClone);
                       
                       // Create a mock NodePointer for the original since we can't instantiate abstract class
                       NodePointer original = mock(NodePointer.class);
                       when(original.getParent()).thenReturn(parent);
                       when(original.clone()).thenCallRealMethod();
                       
                       // Test cloning
                       NodePointer cloned = (NodePointer) original.clone();
                       
                       // Verify parent was cloned (original behavior)
                       // This would fail with the mutant since it would skip cloning when parent != null
                       assertNotNull(cloned);
                       assertNotSame(original, cloned);
                       verify(parent).clone();  // Verify parent.clone() was called
                       assertSame(parentClone, cloned.getParent());  // Verify cloned parent is set
                   }

    @Test
                   public void testCloneWithoutParent1() throws Exception {
                       // Setup - pointer with no parent using factory method
                       QName name = new QName("test");
                       Object bean = new Object();
                       Locale locale = Locale.getDefault();
                       NodePointer original = NodePointer.newNodePointer(name, bean, locale);
                       
                       // Test cloning
                       NodePointer cloned = (NodePointer) original.clone();
                       
                       // Verify clone was successful and parent remains null
                       assertNotNull(cloned);
                       assertNotSame(original, cloned);
                       assertNull(cloned.getParent());
                   }

    @Test
              public void testClone() throws Exception {
                  // Create parent pointer
                  QName parentName = new QName("parent");
                  Object parentBean = new Object();
                  NodePointer parentPointer = NodePointer.newNodePointer(parentName, parentBean, Locale.US);
                  parentPointer.setIndex(5);
                  
                  // Create original pointer with parent
                  QName originalName = new QName("original");
                  Object originalBean = new Object();
                  NodePointer original = NodePointer.newChildNodePointer(parentPointer, originalName, originalBean);
                  original.setIndex(10);
                  original.setAttribute(true);
                  
                  // Clone the pointer
                  NodePointer cloned = (NodePointer) original.clone();
                  
                  // Verify basic clone properties
                  assertNotNull(cloned);
                  assertNotSame(original, cloned);
                  assertEquals(original.getIndex(), cloned.getIndex());
                  assertEquals(original.isAttribute(), cloned.isAttribute());
                  assertEquals(original.getLocale(), cloned.getLocale());
                  
                  // Verify parent was cloned properly
                  NodePointer clonedParent = cloned.getParent();
                  assertNotNull(clonedParent);
                  assertNotSame(parentPointer, clonedParent);
                  assertEquals(parentPointer.getIndex(), clonedParent.getIndex());
                  
                  // Test cloning without parent
                  QName noParentName = new QName("noParent");
                  Object noParentBean = new Object();
                  NodePointer noParentOriginal = NodePointer.newNodePointer(noParentName, noParentBean, Locale.CANADA);
                  NodePointer noParentClone = (NodePointer) noParentOriginal.clone();
                  assertNotNull(noParentClone);
                  assertNull(noParentClone.getParent());
              }

    @Test
         public void testClone1() throws Exception {
             // Create a parent pointer
             QName name = new QName("test");
             NodePointer parent = NodePointer.newNodePointer(name, new Object(), Locale.getDefault());
             parent.setIndex(5);
             
             // Create child pointer with parent
             NodePointer original = NodePointer.newChildNodePointer(parent, name, new Object());
             original.setIndex(10);
             
             // Test cloning
             NodePointer clone = (NodePointer) original.clone();
             
             // Verify clone is not null
             assertNotNull("Clone should not be null", clone);
             
             // Verify it's a different object
             assertNotSame("Clone should be different object", original, clone);
             
             // Verify values were copied
             assertEquals("Index should be copied", original.getIndex(), clone.getIndex());
             
             // Verify parent was cloned (not same object)
             assertNotNull("Parent should be cloned", clone.getParent());
             assertNotSame("Parent should be different object", parent, clone.getParent());
             
             // Verify parent values were copied
             assertEquals("Parent index should be copied", parent.getIndex(), clone.getParent().getIndex());
             
             // Test with null parent
             NodePointer noParentOriginal = NodePointer.newNodePointer(name, new Object(), Locale.getDefault());
             NodePointer noParentClone = (NodePointer) noParentOriginal.clone();
             assertNull("Clone parent should be null", noParentClone.getParent());
         }

    @Test
    public void testCloneWithParent2() throws Exception {
        // Create parent pointer
        QName name = new QName("test");
        Object bean = new Object();
        Locale locale = Locale.getDefault();
        NodePointer parentPointer = NodePointer.newNodePointer(name, bean, locale);
        parentPointer.setIndex(1);
        
        // Create child pointer with parent
        NodePointer original = NodePointer.newChildNodePointer(parentPointer, name, bean);
        original.setIndex(2);
        
        // Clone the child pointer
        NodePointer cloned = (NodePointer) original.clone();
        
        // Verify clone was created
        assertNotNull(cloned);
        
        // Verify it's a different object
        assertNotSame(original, cloned);
        
        // Verify parent was cloned (should be different object)
        assertNotNull(cloned.getParent());
        assertNotSame(parentPointer, cloned.getParent());
        
        // Verify parent relationship is maintained
        assertEquals(parentPointer.getIndex(), cloned.getParent().getIndex());
        
        // Verify child properties were cloned
        assertEquals(original.getIndex(), cloned.getIndex());
    }


}
