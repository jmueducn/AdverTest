package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
 
public class DOMAttributeIteratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                                                                public void testTestAttr_XmlnsPrefix_ReturnsFalse() throws Exception {
                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    DOMNodePointer nodePointer = mock(DOMNodePointer.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(nodePointer, mock(QName.class));
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock behavior
                                                                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn("xmlns");
                                                                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("someName");
                                                                                                                                                                                    
                                                                                                                                                                                    QName testName = mock(QName.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                                    
                                                                                                                                                                                    assertFalse(result);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testTestAttr_XmlnsLocalName_ReturnsFalse() throws Exception {
                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    DOMNodePointer nodePointer = mock(DOMNodePointer.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(nodePointer, mock(QName.class));
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock attribute methods
                                                                                                                                                                                    when(attr.getPrefix()).thenReturn(null);
                                                                                                                                                                                    when(attr.getLocalName()).thenReturn("xmlns");
                                                                                                                                                                                    
                                                                                                                                                                                    QName testName = mock(QName.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                                    
                                                                                                                                                                                    assertFalse(result);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testTestAttr_WildcardLocalName_EqualPrefix_ReturnsTrue() throws Exception {
                                                                                                                                                                                    // Mock the required objects
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, mock(QName.class));
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock the static calls (requires PowerMock or similar)
                                                                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn("prefix");
                                                                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                    
                                                                                                                                                                                    QName testName = mock(QName.class);
                                                                                                                                                                                    when(testName.getName()).thenReturn("*");
                                                                                                                                                                                    when(testName.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                    
                                                                                                                                                                                    when(parent.getNamespaceURI("prefix")).thenReturn("namespace");
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private testAttr method
                                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                                    
                                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testTestAttr_MatchingLocalName_DifferentPrefix_EqualNamespace_ReturnsTrue() throws Exception {
                                                                                                                                                                                    // Mock the required objects
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, mock(QName.class));
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock the behavior
                                                                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn("attrPrefix");
                                                                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                    
                                                                                                                                                                                    QName testName = mock(QName.class);
                                                                                                                                                                                    when(testName.getName()).thenReturn("localName");
                                                                                                                                                                                    when(testName.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                    
                                                                                                                                                                                    when(parent.getNamespaceURI("attrPrefix")).thenReturn("sameNamespace");
                                                                                                                                                                                    when(parent.getNamespaceURI("testPrefix")).thenReturn("sameNamespace");
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                                    
                                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testTestAttr_MatchingLocalName_DifferentPrefix_DifferentNamespace_ReturnsFalse() throws Exception {
                                                                                                                                                                                    // Setup test objects
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, mock(QName.class));
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock behavior
                                                                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn("attrPrefix");
                                                                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                    
                                                                                                                                                                                    QName testName = mock(QName.class);
                                                                                                                                                                                    when(testName.getName()).thenReturn("localName");
                                                                                                                                                                                    when(testName.getPrefix()).thenReturn("testPrefix");
                                                                                                                                                                                    
                                                                                                                                                                                    when(parent.getNamespaceURI("attrPrefix")).thenReturn("namespace1");
                                                                                                                                                                                    when(parent.getNamespaceURI("testPrefix")).thenReturn("namespace2");
                                                                                                                                                                                    
                                                                                                                                                                                    // Get private method via reflection
                                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test
                                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify
                                                                                                                                                                                    assertFalse(result);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testTestAttr_NullPrefix_EqualLocalName_ReturnsTrue() throws Exception {
                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    DOMNodePointer nodePointer = mock(DOMNodePointer.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock behavior
                                                                                                                                                                                    when(DOMNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                                                                    when(DOMNodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                    
                                                                                                                                                                                    QName testName = mock(QName.class);
                                                                                                                                                                                    when(testName.getName()).thenReturn("localName");
                                                                                                                                                                                    when(testName.getPrefix()).thenReturn(null);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create iterator instance
                                                                                                                                                                                    NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, testName);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private testAttr method
                                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                                    
                                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testTestAttr_NullPrefix_NonEqualLocalName_ReturnsFalse() throws Exception {
                                                                                                                                                                                    // Setup mock objects
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    DOMNodePointer nodePointer = mock(DOMNodePointer.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create iterator
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(nodePointer, null);
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock calls
                                                                                                                                                                                    when(nodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                                                                    when(nodePointer.getLocalName(attr)).thenReturn("localName");
                                                                                                                                                                                    
                                                                                                                                                                                    QName testName = mock(QName.class);
                                                                                                                                                                                    when(testName.getName()).thenReturn("differentName");
                                                                                                                                                                                    when(testName.getPrefix()).thenReturn(null);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                                    
                                                                                                                                                                                    assertFalse(result);
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testGetAttribute_NoPrefix_ReturnsAttributeDirectly() throws Exception {
                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create the iterator instance
                                                                                                                                                                                    NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set up mock behavior
                                                                                                                                                                                    when(name.getPrefix()).thenReturn(null);
                                                                                                                                                                                    when(name.getName()).thenReturn("testName");
                                                                                                                                                                                    when(element.getAttributeNode("testName")).thenReturn(attr);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                    Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Call the method under test
                                                                                                                                                                                    Attr result = (Attr) method.invoke(iterator, element, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify results
                                                                                                                                                                                    assertEquals(attr, result);
                                                                                                                                                                                    verify(element).getAttributeNode("testName");
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testGetAttribute_WithPrefix_NamespaceResolverReturnsNS_ReturnsAttributeNodeNS() throws Exception {
                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                    NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create the iterator under test
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set up mock behavior
                                                                                                                                                                                    when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                    when(name.getName()).thenReturn("localName");
                                                                                                                                                                                    when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                                                                                                    when(nsr.getNamespaceURI("prefix")).thenReturn("namespaceURI");
                                                                                                                                                                                    when(element.getAttributeNodeNS("namespaceURI", "localName")).thenReturn(attr);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                    Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                                        "getAttribute", Element.class, QName.class);
                                                                                                                                                                                    getAttributeMethod.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Call the method under test
                                                                                                                                                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify results
                                                                                                                                                                                    assertEquals(attr, result);
                                                                                                                                                                                    verify(element).getAttributeNodeNS("namespaceURI", "localName");
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testGetAttribute_WithPrefix_NoNamespaceResolver_ParentReturnsNS_ReturnsAttributeNodeNS() throws Exception {
                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Setup mock behavior
                                                                                                                                                                                    when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                    when(name.getName()).thenReturn("localName");
                                                                                                                                                                                    when(parent.getNamespaceResolver()).thenReturn(null);
                                                                                                                                                                                    when(parent.getNamespaceURI("prefix")).thenReturn("namespaceURI");
                                                                                                                                                                                    when(element.getAttributeNodeNS("namespaceURI", "localName")).thenReturn(attr);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get private method via reflection
                                                                                                                                                                                    Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                                        "getAttribute", Element.class, QName.class);
                                                                                                                                                                                    getAttributeMethod.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Execute test
                                                                                                                                                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify results
                                                                                                                                                                                    assertEquals(attr, result);
                                                                                                                                                                                    verify(element).getAttributeNodeNS("namespaceURI", "localName");
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testGetAttribute_WithPrefix_NoNSFound_ReturnsAttributeDirectly() throws Exception {
                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                    NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create the iterator under test
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set up mock behavior
                                                                                                                                                                                    when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                    when(name.getName()).thenReturn("localName");
                                                                                                                                                                                    when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                                                                                                    when(nsr.getNamespaceURI("prefix")).thenReturn(null);
                                                                                                                                                                                    when(parent.getNamespaceURI("prefix")).thenReturn(null);
                                                                                                                                                                                    when(element.getAttributeNode("localName")).thenReturn(attr);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access the private method
                                                                                                                                                                                    Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Call the method under test
                                                                                                                                                                                    Attr result = (Attr) method.invoke(iterator, element, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify results
                                                                                                                                                                                    assertEquals(attr, result);
                                                                                                                                                                                    verify(element).getAttributeNode("localName");
                                                                                                                                                                                }

 @Test
                                                                                                                                                                                public void testGetAttribute_WithPrefix_NSFoundButNoNSAttribute_FallsBackToSearchingAllAttributes() {
                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                    NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                                                                    NamedNodeMap namedNodeMap = mock(NamedNodeMap.class);
                                                                                                                                                                                    Attr attr = mock(Attr.class);
                                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                    
                                                                                                                                                                                    // Setup mock behavior
                                                                                                                                                                                    when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                    when(name.getName()).thenReturn("localName");
                                                                                                                                                                                    when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                                                                                                    when(nsr.getNamespaceURI("prefix")).thenReturn("namespaceURI");
                                                                                                                                                                                    when(element.getAttributeNodeNS("namespaceURI", "localName")).thenReturn(null);
                                                                                                                                                                                    when(element.getAttributes()).thenReturn(namedNodeMap);
                                                                                                                                                                                    when(namedNodeMap.getLength()).thenReturn(1);
                                                                                                                                                                                    when(namedNodeMap.item(0)).thenReturn(attr);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private testAttr method
                                                                                                                                                                                    try {
                                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                                        when(testAttrMethod.invoke(iterator, attr, name)).thenReturn(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to access private getAttribute method
                                                                                                                                                                                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                                                                        getAttributeMethod.setAccessible(true);
                                                                                                                                                                                        Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                                        
                                                                                                                                                                                        assertEquals(attr, result);
                                                                                                                                                                                        verify(element).getAttributeNodeNS("namespaceURI", "localName");
                                                                                                                                                                                        verify(element).getAttributes();
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        fail("Failed to access private method via reflection: " + e.getMessage());
                                                                                                                                                                                    }
                                                                                                                                                                                }

 @Test
                                                                                                                                                                            public void testGetAttribute_WithPrefix_NSFoundButNoMatchingAttributes_ReturnsNull() {
                                                                                                                                                                                // Create mock objects
                                                                                                                                                                                NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                QName name = mock(QName.class);
                                                                                                                                                                                NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                                                                                                Element element = mock(Element.class);
                                                                                                                                                                                NamedNodeMap namedNodeMap = mock(NamedNodeMap.class);
                                                                                                                                                                                Attr attr = mock(Attr.class);
                                                                                                                                                                                
                                                                                                                                                                                // Set up mock behavior
                                                                                                                                                                                when(name.getPrefix()).thenReturn("prefix");
                                                                                                                                                                                when(name.getName()).thenReturn("localName");
                                                                                                                                                                                when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                                                                                                when(nsr.getNamespaceURI("prefix")).thenReturn("namespaceURI");
                                                                                                                                                                                when(element.getAttributeNodeNS("namespaceURI", "localName")).thenReturn(null);
                                                                                                                                                                                when(element.getAttributes()).thenReturn(namedNodeMap);
                                                                                                                                                                                when(namedNodeMap.getLength()).thenReturn(1);
                                                                                                                                                                                when(namedNodeMap.item(0)).thenReturn(attr);
                                                                                                                                                                                
                                                                                                                                                                                // Mock the private testAttr method using reflection
                                                                                                                                                                                try {
                                                                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                                                                    when(testAttrMethod.invoke(any(DOMAttributeIterator.class), eq(attr), eq(name))).thenReturn(false);
                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                    fail("Failed to set up testAttr method mock");
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                                // Create the iterator under test and set up parent node
                                                                                                                                                                                DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                                when(parent.getNode()).thenReturn(element);
                                                                                                                                                                                
                                                                                                                                                                                // Test by checking if iterator has no elements (since no matching attributes)
                                                                                                                                                                                assertFalse(iterator.setPosition(1));  // Should return false as there are no matching attributes
                                                                                                                                                                                
                                                                                                                                                                                // Verify interactions
                                                                                                                                                                                verify(element).getAttributeNodeNS("namespaceURI", "localName");
                                                                                                                                                                                verify(element).getAttributes();
                                                                                                                                                                            }

 @Test(expected = NullPointerException.class)
                                                                                                                                                                            public void testGetAttribute_NameNull_ThrowsNullPointerException() throws Exception {
                                                                                                                                                                                // Create a mock parent NodePointer
                                                                                                                                                                                NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                // Create a mock Element
                                                                                                                                                                                Element element = mock(Element.class);
                                                                                                                                                                                
                                                                                                                                                                                // Create the iterator with a null name
                                                                                                                                                                                DOMAttributeIterator iterator = new DOMAttributeIterator(parent, null);
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to access the private getAttribute method
                                                                                                                                                                                Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Invoke the method which should throw NullPointerException
                                                                                                                                                                                method.invoke(iterator, element, null);
                                                                                                                                                                            }

 @Test(expected = NullPointerException.class)
                                                                                                                                                                        public void testGetAttribute_ElementNull_ThrowsNullPointerException() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            QName name = new QName("test");
                                                                                                                                                                            NodePointer parentPointer = null;
                                                                                                                                                                            DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                            
                                                                                                                                                                            // Get private method via reflection
                                                                                                                                                                            Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                                "getAttribute", Element.class, QName.class);
                                                                                                                                                                            getAttributeMethod.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Test - should throw NullPointerException
                                                                                                                                                                            getAttributeMethod.invoke(iterator, (Element)null, name);
                                                                                                                                                                        }

 @Test
                                                                                                                                                                    public void testTestAttr_TestPrefixNull_AttrPrefixNotNull_EqualNamespaces_ReturnsTrue() throws Exception {
                                                                                                                                                                        // Mock the required objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        QName iteratorQName = mock(QName.class);
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, iteratorQName);
                                                                                                                                                                        
                                                                                                                                                                        // Mock the static calls using regular mocking since we can't mock static methods in Mockito 1.x
                                                                                                                                                                        // (Assuming DOMNodePointer methods are instance methods or we need to adjust approach)
                                                                                                                                                                        // For Java 8 and JUnit 4, we'll modify the approach to not use static mocking
                                                                                                                                                                        
                                                                                                                                                                        // Mock the QName for test
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        when(testName.getName()).thenReturn("localName");
                                                                                                                                                                        when(testName.getPrefix()).thenReturn(null);
                                                                                                                                                                        
                                                                                                                                                                        // Mock the parent behavior
                                                                                                                                                                        when(parent.getNamespaceURI("attrPrefix")).thenReturn("namespace");
                                                                                                                                                                        when(parent.getNamespaceURI(null)).thenReturn("namespace");
                                                                                                                                                                        
                                                                                                                                                                        // Mock the attribute behavior directly since we can't mock static methods
                                                                                                                                                                        when(attr.getLocalName()).thenReturn("localName");
                                                                                                                                                                        when(attr.getPrefix()).thenReturn("attrPrefix");
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                        
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                    }

 @Test
                                                                                                                                        public void testTestAttr_NonMatchingLocalName_ReturnsFalse() throws Exception {
                                                                                                                                            // Create mock objects
                                                                                                                                            org.apache.commons.jxpath.ri.model.NodePointer parentPointer = null;
                                                                                                                                            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                                new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(parentPointer, null);
                                                                                                                                            
                                                                                                                                            // Create mock Attr using DocumentBuilder
                                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                            org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                            org.w3c.dom.Attr attr = document.createAttribute("testName");
                                                                                                                                            
                                                                                                                                            // Use reflection to access private testAttr method
                                                                                                                                            java.lang.reflect.Method testAttrMethod = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                                                .getDeclaredMethod("testAttr", org.w3c.dom.Attr.class, org.apache.commons.jxpath.ri.QName.class);
                                                                                                                                            testAttrMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Setup test QName with non-matching name
                                                                                                                                            org.apache.commons.jxpath.ri.QName testName = 
                                                                                                                                                new org.apache.commons.jxpath.ri.QName("prefix", "differentName");
                                                                                                                                            
                                                                                                                                            // Call the actual method under test using reflection
                                                                                                                                            boolean result = (boolean) testAttrMethod.invoke(pointer, attr, testName);
                                                                                                                                            
                                                                                                                                            // Verify the result
                                                                                                                                            org.junit.Assert.assertFalse(result);
                                                                                                                                        }

 @Test
                                                                                                    public void testTestAttr_MatchingLocalName_EqualPrefix_ReturnsTrue() {
                                                                                                        try {
                                                                                                            // Create mock objects
                                                                                                            NodePointer parentPointer = mock(NodePointer.class);
                                                                                                            Attr attr = mock(Attr.class);
                                                                                                            QName testName = new QName("testPrefix", "testLocalName");
                                                                                                            
                                                                                                            // Setup mock behavior
                                                                                                            when(attr.getLocalName()).thenReturn("testLocalName");
                                                                                                            when(attr.getPrefix()).thenReturn("testPrefix");
                                                                                                            
                                                                                                            // Get private method via reflection
                                                                                                            Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                "testAttr", Attr.class, QName.class);
                                                                                                            testAttrMethod.setAccessible(true);
                                                                                                            
                                                                                                            // Create test instance (constructor requires these parameters)
                                                                                                            DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, testName);
                                                                                                            
                                                                                                            // Invoke the method
                                                                                                            boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                            
                                                                                                            // Assert the result
                                                                                                            assertTrue(result);
                                                                                                        } catch (Exception e) {
                                                                                                            org.junit.Assert.fail("Failed to invoke private method: " + e.getMessage());
                                                                                                        }
                                                                                                    }

 @Test
                                                                                                public void testGetAttributeWithNonNullNamespaceResolver() throws Exception {
                                                                                                    // Setup test data
                                                                                                    QName testQName = new QName("testPrefix", "localName");
                                                                                                    Element mockElement = mock(Element.class);
                                                                                                    NodePointer mockParent = mock(NodePointer.class);
                                                                                                    NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                                                    Attr expectedAttr = mock(Attr.class);
                                                                                                    
                                                                                                    // Mock behavior
                                                                                                    when(testQName.getPrefix()).thenReturn("testPrefix");
                                                                                                    when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                                                    when(mockNsResolver.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                                                                                    when(mockElement.getAttributeNodeNS("testNS", "localName")).thenReturn(expectedAttr);
                                                                                                    
                                                                                                    // Create test instance
                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                                                    
                                                                                                    // Use reflection to access private method since we're testing it directly
                                                                                                    Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                        "getAttribute", Element.class, QName.class);
                                                                                                    getAttributeMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Invoke and verify
                                                                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                                                                    assertSame(expectedAttr, result);
                                                                                                    
                                                                                                    // Verify interactions - original code would call getNamespaceURI, mutant would not
                                                                                                    verify(mockNsResolver).getNamespaceURI("testPrefix");
                                                                                                }

 @Test
                                                                                                public void testGetAttributeWithNullNamespaceResolver() throws Exception {
                                                                                                    // Setup test data
                                                                                                    QName testQName = new QName("testPrefix", "localName");
                                                                                                    Element mockElement = mock(Element.class);
                                                                                                    NodePointer mockParent = mock(NodePointer.class);
                                                                                                    Attr expectedAttr = mock(Attr.class);
                                                                                                    
                                                                                                    // Mock behavior
                                                                                                    when(testQName.getPrefix()).thenReturn("testPrefix");
                                                                                                    when(mockParent.getNamespaceResolver()).thenReturn(null);
                                                                                                    when(mockParent.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                                                    when(mockElement.getAttributeNode("localName")).thenReturn(expectedAttr);
                                                                                                    
                                                                                                    // Create test instance
                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                                                    
                                                                                                    // Use reflection to access private method
                                                                                                    Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                        "getAttribute", Element.class, QName.class);
                                                                                                    getAttributeMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Invoke and verify
                                                                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                                                                    assertSame(expectedAttr, result);
                                                                                                }

 @Test
                                                                                               public void testGetAttribute_NamespaceResolutionFallback() throws Exception {
                                                                                                   // Setup test data
                                                                                                   QName testQName = new QName("testPrefix", "localName");
                                                                                                   Element mockElement = mock(Element.class);
                                                                                                   Attr expectedAttr = mock(Attr.class);
                                                                                                   
                                                                                                   // Mock the name object
                                                                                                   QName name = mock(QName.class);
                                                                                                   when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                   when(name.getName()).thenReturn("localName");
                                                                                                   
                                                                                                   // Mock parent and namespace resolution
                                                                                                   NodePointer parent = mock(NodePointer.class);
                                                                                                   NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                                                   
                                                                                                   // Setup behavior:
                                                                                                   // 1. NamespaceResolver returns null (first resolution fails)
                                                                                                   // 2. Parent has a namespace URI for the prefix
                                                                                                   when(parent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                                                   when(mockNsResolver.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                                                   when(parent.getNamespaceURI("testPrefix")).thenReturn("validNamespace");
                                                                                                   
                                                                                                   // Mock element behavior for NS lookup
                                                                                                   when(mockElement.getAttributeNodeNS("validNamespace", "localName")).thenReturn(expectedAttr);
                                                                                                   
                                                                                                   // Create test instance (using reflection since constructor may be complex)
                                                                                                   DOMAttributeIterator iterator = new DOMAttributeIterator(parent, testQName);
                                                                                                   
                                                                                                   // Use reflection to access private method
                                                                                                   Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                   getAttributeMethod.setAccessible(true);
                                                                                                   
                                                                                                   // Invoke and verify
                                                                                                   Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, name);
                                                                                                   
                                                                                                   // Assertions
                                                                                                   assertSame("Should return attribute from parent namespace resolution", expectedAttr, result);
                                                                                                   
                                                                                                   // Verify interactions
                                                                                                   verify(mockNsResolver).getNamespaceURI("testPrefix");
                                                                                                   verify(parent).getNamespaceURI("testPrefix");
                                                                                                   verify(mockElement).getAttributeNodeNS("validNamespace", "localName");
                                                                                               }

 @Test
                                                                                         public void testGetAttributeWithNamespace() throws Exception {
                                                                                             // Setup test data
                                                                                             String namespaceURI = "uri";
                                                                                             String localName = "localName";
                                                                                             String prefix = "prefix";
                                                                                             QName name = new QName(namespaceURI, localName);
                                                                                             Element element = mock(Element.class);
                                                                                             NodePointer parent = mock(NodePointer.class);
                                                                                             NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                             Attr expectedAttr = mock(Attr.class);
                                                                                             
                                                                                             // Mock behavior
                                                                                             when(name.getPrefix()).thenReturn(prefix);
                                                                                             when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                             when(nsr.getNamespaceURI(prefix)).thenReturn("testNamespace");
                                                                                             when(parent.getNamespaceURI(prefix)).thenReturn("testNamespace");
                                                                                             when(element.getAttributeNodeNS("testNamespace", localName)).thenReturn(expectedAttr);
                                                                                             
                                                                                             // Create test instance
                                                                                             DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                             
                                                                                             // Use reflection to access private method since we're testing it directly
                                                                                             Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                             method.setAccessible(true);
                                                                                             Attr result = (Attr) method.invoke(iterator, element, name);
                                                                                             
                                                                                             // Verify
                                                                                             assertEquals(expectedAttr, result);
                                                                                             verify(element).getAttributeNodeNS("testNamespace", localName);
                                                                                         }

 @Test
                                                                                     public void testGetAttributeWithNamespacedAttrShouldReturnNamespacedAttribute() throws Exception {
                                                                                         // Setup test data
                                                                                         String prefix = "test";
                                                                                         String namespaceUri = "http://example.com/ns";
                                                                                         String localName = "attr";
                                                                                         String qualifiedName = prefix + ":" + localName;
                                                                                         
                                                                                         // Create test element with both namespaced and non-namespaced attributes
                                                                                         Element element = mock(Element.class);
                                                                                         Attr namespacedAttr = mock(Attr.class);
                                                                                         Attr nonNamespacedAttr = mock(Attr.class);
                                                                                         
                                                                                         // Mock QName
                                                                                         QName qname = mock(QName.class);
                                                                                         when(qname.getPrefix()).thenReturn(prefix);
                                                                                         when(qname.getName()).thenReturn(localName);
                                                                                         
                                                                                         // Mock parent and namespace resolver
                                                                                         NodePointer parent = mock(NodePointer.class);
                                                                                         NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                         when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                         when(nsr.getNamespaceURI(prefix)).thenReturn(namespaceUri);
                                                                                         when(parent.getNamespaceURI(prefix)).thenReturn(namespaceUri);
                                                                                         
                                                                                         // Mock element behavior
                                                                                         when(element.getAttributeNodeNS(namespaceUri, localName)).thenReturn(namespacedAttr);
                                                                                         when(element.getAttributeNode(qualifiedName)).thenReturn(nonNamespacedAttr);
                                                                                         
                                                                                         // Create test instance
                                                                                         DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                         
                                                                                         // Use reflection to access private method since we need to test it directly
                                                                                         Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                         getAttributeMethod.setAccessible(true);
                                                                                         
                                                                                         // Test - should return namespaced attribute
                                                                                         Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                         
                                                                                         // Verify
                                                                                         assertEquals("Should return namespaced attribute", namespacedAttr, result);
                                                                                         // The mutant would either return null or nonNamespacedAttr
                                                                                     }

 @Test
                                                                                    public void testGetAttribute_ShouldReturnNamespacedAttr_WhenExists() throws Exception {
                                                                                        // Setup test data
                                                                                        String prefix = "test";
                                                                                        String localName = "attr";
                                                                                        String namespaceUri = "http://test.com";
                                                                                        String attrValue = "value";
                                                                                        
                                                                                        // Create QName mock
                                                                                        QName qname = mock(QName.class);
                                                                                        when(qname.getPrefix()).thenReturn(prefix);
                                                                                        when(qname.getName()).thenReturn(localName);
                                                                                        
                                                                                        // Create namespace resolver mock
                                                                                        NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                        when(nsr.getNamespaceURI(prefix)).thenReturn(namespaceUri);
                                                                                        
                                                                                        // Create parent node pointer mock
                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                        when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                        when(parent.getNamespaceURI(prefix)).thenReturn(null); // primary lookup succeeds
                                                                                        
                                                                                        // Create attribute mock
                                                                                        Attr expectedAttr = mock(Attr.class);
                                                                                        
                                                                                        // Create element mock
                                                                                        Element element = mock(Element.class);
                                                                                        when(element.getAttributeNodeNS(namespaceUri, localName)).thenReturn(expectedAttr);
                                                                                        
                                                                                        // Create test instance
                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                                                                        
                                                                                        // Use reflection to access private method
                                                                                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                        getAttributeMethod.setAccessible(true);
                                                                                        
                                                                                        // Invoke and verify
                                                                                        Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                                                                        assertEquals("Should return the namespaced attribute", expectedAttr, result);
                                                                                        
                                                                                        // For mutant: if(attr == null) would make this return null
                                                                                        // So this test would fail for the mutant
                                                                                    }

 @Test
                                                                                  public void testGetAttribute_ReturnsCorrectAttrWhenNotFirst() throws Exception {
                                                                                      // Setup test data
                                                                                      QName testName = new QName("testLocalName");
                                                                                      Element mockElement = mock(Element.class);
                                                                                      NodePointer mockParent = mock(NodePointer.class);
                                                                                      NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                                      
                                                                                      // Create 3 attributes where the matching one is at position 2
                                                                                      Attr nonMatchingAttr1 = mock(Attr.class);
                                                                                      Attr nonMatchingAttr2 = mock(Attr.class);
                                                                                      Attr matchingAttr = mock(Attr.class);
                                                                                      
                                                                                      // Setup namespace resolution to fail (force fallback path)
                                                                                      when(testName.getPrefix()).thenReturn("testPrefix");
                                                                                      when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                                      when(mockNsResolver.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                                      when(mockParent.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                                      
                                                                                      // Setup element attributes
                                                                                      NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                      when(mockElement.getAttributes()).thenReturn(mockAttributes);
                                                                                      when(mockAttributes.getLength()).thenReturn(3);
                                                                                      
                                                                                      // Setup attribute sequence - matching one is third
                                                                                      when(mockAttributes.item(0)).thenReturn(nonMatchingAttr1);
                                                                                      when(mockAttributes.item(1)).thenReturn(nonMatchingAttr2);
                                                                                      when(mockAttributes.item(2)).thenReturn(matchingAttr);
                                                                                      
                                                                                      // Create test instance
                                                                                      DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testName);
                                                                                      
                                                                                      // Use reflection to access private testAttr method
                                                                                      Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                      testAttrMethod.setAccessible(true);
                                                                                      
                                                                                      // Setup testAttr to only match the third attribute
                                                                                      when((Boolean)testAttrMethod.invoke(iterator, nonMatchingAttr1, testName)).thenReturn(false);
                                                                                      when((Boolean)testAttrMethod.invoke(iterator, nonMatchingAttr2, testName)).thenReturn(false);
                                                                                      when((Boolean)testAttrMethod.invoke(iterator, matchingAttr, testName)).thenReturn(true);
                                                                                      
                                                                                      // Use reflection to access private getAttribute method
                                                                                      Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                      getAttributeMethod.setAccessible(true);
                                                                                      
                                                                                      // Call the method and verify
                                                                                      Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testName);
                                                                                      assertEquals(matchingAttr, result);
                                                                                  }

 @Test
                                                                             public void testGetAttributeShouldNotReturnNonMatchingAttributes() throws Exception {
                                                                                 // Setup test data
                                                                                 QName testQName = new QName("http://test.ns", "testName");
                                                                                 Element mockElement = mock(Element.class);
                                                                                 NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                 Attr matchingAttr = mock(Attr.class);
                                                                                 Attr nonMatchingAttr = mock(Attr.class);
                                                                                 
                                                                                 // Mock behavior
                                                                                 when(mockElement.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                                                 when(mockElement.getAttributes()).thenReturn(mockAttributes);
                                                                                 when(mockAttributes.getLength()).thenReturn(2);
                                                                                 when(mockAttributes.item(0)).thenReturn(nonMatchingAttr);
                                                                                 when(mockAttributes.item(1)).thenReturn(matchingAttr);
                                                                                 
                                                                                 // Create iterator
                                                                                 NodePointer mockNodePointer = mock(NodePointer.class);
                                                                                 DOMAttributeIterator iterator = new DOMAttributeIterator(mockNodePointer, testQName);
                                                                                 
                                                                                 // Get private testAttr method via reflection
                                                                                 Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                 testAttrMethod.setAccessible(true);
                                                                                 
                                                                                 // Mock testAttr behavior - first attr fails, second passes
                                                                                 when(testAttrMethod.invoke(iterator, nonMatchingAttr, testQName)).thenReturn(false);
                                                                                 when(testAttrMethod.invoke(iterator, matchingAttr, testQName)).thenReturn(true);
                                                                                 
                                                                                 // Mock namespace resolution
                                                                                 NodePointer mockParent = mock(NodePointer.class);
                                                                                 NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                                 when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                                 when(mockNsResolver.getNamespaceURI("prefix")).thenReturn("http://test.ns");
                                                                                 when(mockParent.getNamespaceURI("prefix")).thenReturn(null);
                                                                                 
                                                                                 // Set test object state via reflection since fields are private
                                                                                 Field parentField = DOMAttributeIterator.class.getDeclaredField("parent");
                                                                                 parentField.setAccessible(true);
                                                                                 parentField.set(iterator, mockParent);
                                                                                 
                                                                                 Field nameField = DOMAttributeIterator.class.getDeclaredField("name");
                                                                                 nameField.setAccessible(true);
                                                                                 nameField.set(iterator, testQName);
                                                                                 
                                                                                 // Get private getAttribute method via reflection
                                                                                 Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                 getAttributeMethod.setAccessible(true);
                                                                                 
                                                                                 // Call method and verify
                                                                                 Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                                                 
                                                                                 // Original would return matchingAttr, mutant would return nonMatchingAttr
                                                                                 assertEquals("Should return matching attribute", matchingAttr, result);
                                                                             }

 @Test
                                                                         public void testGetAttribute_NoNamespace_ShouldReturnAttribute() throws Exception {
                                                                             // Setup test data
                                                                             QName testName = new QName("", "testAttr"); // No prefix
                                                                             Element mockElement = mock(Element.class);
                                                                             Attr expectedAttr = mock(Attr.class);
                                                                             
                                                                             // Mock behavior
                                                                             when(testName.getPrefix()).thenReturn(null); // No namespace prefix
                                                                             when(mockElement.getAttributeNode("testAttr")).thenReturn(expectedAttr);
                                                                             
                                                                             // Create test instance (using reflection since constructor is complex)
                                                                             NodePointer mockParent = mock(NodePointer.class);
                                                                             DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testName);
                                                                             
                                                                             // Use reflection to access private method
                                                                             Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                 "getAttribute", Element.class, QName.class);
                                                                             getAttributeMethod.setAccessible(true);
                                                                             
                                                                             // Invoke method and verify
                                                                             Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testName);
                                                                             assertEquals("Should return attribute when no namespace is involved", 
                                                                                         expectedAttr, result);
                                                                             
                                                                             // Verify interactions
                                                                             verify(mockElement).getAttributeNode("testAttr");
                                                                         }

 @Test
                                                                   public void testGetAttributeWithNamespaceResolver() throws Exception {
                                                                       // Setup test data
                                                                       String namespaceURI = "http://test.ns";
                                                                       String localName = "test";
                                                                       String prefix = "t";
                                                                       QName testQName = new QName(namespaceURI, localName);
                                                                       Element mockElement = mock(Element.class);
                                                                       NodePointer mockParent = mock(NodePointer.class);
                                                                       NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                       Attr mockAttr = mock(Attr.class);
                                                                       
                                                                       // Mock behavior
                                                                       when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                       when(mockNsResolver.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                                                                       when(mockElement.getAttributeNodeNS(namespaceURI, localName)).thenReturn(mockAttr);
                                                                       
                                                                       // Create test instance
                                                                       DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                       
                                                                       // Use reflection to access private method since we're testing it directly
                                                                       Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                           "getAttribute", Element.class, QName.class);
                                                                       getAttributeMethod.setAccessible(true);
                                                                       
                                                                       // Invoke and verify
                                                                       Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                                       
                                                                       // Assertions
                                                                       assertNotNull("Should find attribute via namespace resolution", result);
                                                                       assertEquals(mockAttr, result);
                                                                       
                                                                       // Verify the mutation would fail here - mutated version would return null 
                                                                       // from namespace resolution and fall through to local name check
                                                                       verify(mockElement, never()).getAttributeNode(localName);
                                                                   }

 @Test
                                                               public void testGetAttribute_NamespaceResolutionWhenResolverReturnsNull() throws Exception {
                                                                   // Setup test data
                                                                   QName name = new QName("prefix", "localName");
                                                                   Element element = mock(Element.class);
                                                                   NodePointer parent = mock(NodePointer.class);
                                                                   NamespaceResolver nsr = null;
                                                                   
                                                                   // Mock behavior
                                                                   when(name.getPrefix()).thenReturn("prefix");
                                                                   when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                   when(parent.getNamespaceURI("prefix")).thenReturn("http://test.ns");
                                                                   
                                                                   // Mock element behavior
                                                                   Attr expectedAttr = mock(Attr.class);
                                                                   when(element.getAttributeNodeNS("http://test.ns", "localName")).thenReturn(expectedAttr);
                                                                   
                                                                   // Create test instance (using reflection since constructor is complex)
                                                                   DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                   
                                                                   // Use reflection to access private method
                                                                   Method getAttribute = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                   getAttribute.setAccessible(true);
                                                                   
                                                                   // Test the method
                                                                   Attr result = (Attr) getAttribute.invoke(iterator, element, name);
                                                                   
                                                                   // Verify the correct namespace URI was used
                                                                   assertEquals(expectedAttr, result);
                                                                   
                                                                   // Verify parent.getNamespaceURI was called (would fail with mutant)
                                                                   verify(parent).getNamespaceURI("prefix");
                                                               }

 @Test
                                                              public void testGetAttributeWithNamespace1() throws Exception {
                                                                  // Setup test data
                                                                  QName name = mock(QName.class);
                                                                  when(name.getPrefix()).thenReturn("testPrefix");
                                                                  when(name.getName()).thenReturn("testName");
                                                                  
                                                                  NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                  when(nsr.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                                                  
                                                                  NodePointer parent = mock(NodePointer.class);
                                                                  when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                  when(parent.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                  
                                                                  Element element = mock(Element.class);
                                                                  Attr expectedAttr = mock(Attr.class);
                                                                  when(element.getAttributeNodeNS("testNS", "testName")).thenReturn(expectedAttr);
                                                                  
                                                                  // Create test instance
                                                                  DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                  
                                                                  // Use reflection to access private method since we're testing it directly
                                                                  Method getAttribute = DOMAttributeIterator.class.getDeclaredMethod(
                                                                      "getAttribute", Element.class, QName.class);
                                                                  getAttribute.setAccessible(true);
                                                                  
                                                                  // Invoke method and verify
                                                                  Attr result = (Attr) getAttribute.invoke(iterator, element, name);
                                                                  assertEquals(expectedAttr, result);
                                                                  
                                                                  // Verify interactions
                                                                  verify(element).getAttributeNodeNS("testNS", "testName");
                                                                  verify(element, never()).getAttributeNode("testName");
                                                              }

 @Test
                                                             public void testGetAttributeWithNamespacedAttribute() throws Exception {
                                                                 // Setup test data
                                                                 String prefix = "test";
                                                                 String namespaceUri = "http://example.com/ns";
                                                                 String localName = "attr";
                                                                 String qualifiedName = prefix + ":" + localName;
                                                                 
                                                                 // Create mock objects
                                                                 Element element = mock(Element.class);
                                                                 QName name = mock(QName.class);
                                                                 NodePointer parent = mock(NodePointer.class);
                                                                 NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                 Attr namespacedAttr = mock(Attr.class);
                                                                 Attr defaultAttr = mock(Attr.class);
                                                                 
                                                                 // Configure mocks
                                                                 when(name.getPrefix()).thenReturn(prefix);
                                                                 when(name.getName()).thenReturn(localName);
                                                                 
                                                                 when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                 when(nsr.getNamespaceURI(prefix)).thenReturn(namespaceUri);
                                                                 when(parent.getNamespaceURI(prefix)).thenReturn(namespaceUri);
                                                                 
                                                                 // Setup two attributes with same local name but different namespaces
                                                                 when(element.getAttributeNodeNS(namespaceUri, localName)).thenReturn(namespacedAttr);
                                                                 when(element.getAttributeNode(localName)).thenReturn(defaultAttr);
                                                                 
                                                                 // Create test instance
                                                                 DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                 
                                                                 // Use reflection to access private method since we're testing it directly
                                                                 Method getAttribute = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                 getAttribute.setAccessible(true);
                                                                 
                                                                 // Test - should return namespaced attribute
                                                                 Attr result = (Attr) getAttribute.invoke(iterator, element, name);
                                                                 
                                                                 // Verify correct attribute was returned
                                                                 assertEquals("Should return namespaced attribute", namespacedAttr, result);
                                                                 
                                                                 // Verify the correct method was called
                                                                 verify(element).getAttributeNodeNS(namespaceUri, localName);
                                                             }

 @Test
                                                       public void testGetAttributeWithNamespacedAttrShouldReturnAttr() throws Exception {
                                                           // Setup test data
                                                           String namespaceURI = "http://test.ns";
                                                           String localName = "testAttr";
                                                           String prefix = "test";
                                                           QName testQName = new QName(namespaceURI, localName);
                                                           Element mockElement = mock(Element.class);
                                                           NodePointer mockParent = mock(NodePointer.class);
                                                           NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                           Attr expectedAttr = mock(Attr.class);
                                                           
                                                           // Mock behavior
                                                           when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                           when(mockNsResolver.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                                                           when(mockElement.getAttributeNodeNS(namespaceURI, localName)).thenReturn(expectedAttr);
                                                           
                                                           // Create test instance
                                                           DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                           
                                                           // Use reflection to access private method
                                                           Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                           getAttributeMethod.setAccessible(true);
                                                           
                                                           // Test the method
                                                           Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                           
                                                           // Verify
                                                           assertSame("Should return the namespaced attribute", expectedAttr, result);
                                                           
                                                           // Verify interactions
                                                           verify(mockElement).getAttributeNodeNS(namespaceURI, localName);
                                                           verify(mockElement, never()).getAttributes(); // Shouldn't fall back to searching all attributes
                                                       }

 @Test
                                                  public void testGetAttributeWithMultipleAttributesAndMatchingNotFirst() throws Exception {
                                                      // Setup test data
                                                      QName testQName = new QName("http://test.ns", "testAttr");
                                                      
                                                      // Mock parent and namespace resolver to return null (forcing fallback path)
                                                      NodePointer parent = mock(NodePointer.class);
                                                      when(parent.getNamespaceResolver()).thenReturn(null);
                                                      
                                                      // Create test element with multiple attributes
                                                      Element element = mock(Element.class);
                                                      
                                                      // Create non-matching attribute (first in list)
                                                      Attr wrongAttr = mock(Attr.class);
                                                      when(wrongAttr.getLocalName()).thenReturn("wrongAttr");
                                                      
                                                      // Create matching attribute (second in list)
                                                      Attr correctAttr = mock(Attr.class);
                                                      when(correctAttr.getLocalName()).thenReturn("testAttr");
                                                      
                                                      // Mock NamedNodeMap to return our test attributes
                                                      NamedNodeMap attributes = mock(NamedNodeMap.class);
                                                      when(attributes.getLength()).thenReturn(2);
                                                      when(attributes.item(0)).thenReturn(wrongAttr);
                                                      when(attributes.item(1)).thenReturn(correctAttr);
                                                      
                                                      // Mock element to return our attributes
                                                      when(element.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                      when(element.getAttributes()).thenReturn(attributes);
                                                      when(element.getAttributeNode(anyString())).thenReturn(null);
                                                      
                                                      // Create real iterator instance instead of mock
                                                      DOMAttributeIterator iterator = new DOMAttributeIterator(parent, testQName);
                                                      
                                                      // Use reflection to call private method
                                                      Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                          "getAttribute", Element.class, QName.class);
                                                      getAttributeMethod.setAccessible(true);
                                                      
                                                      // Call the method and verify it returns the correct attribute
                                                      Attr result = (Attr) getAttributeMethod.invoke(iterator, element, testQName);
                                                      
                                                      // Assert that we got the correct attribute (would fail with mutant)
                                                      assertNotNull("Should find matching attribute", result);
                                                      assertEquals("testAttr", result.getLocalName());
                                                  }

 @Test
                                         public void testGetAttribute_ShouldOnlyReturnMatchingAttributes() throws Exception {
                                             // Setup test data
                                             QName testName = new QName("http://test.ns", "matchedAttr");
                                             QName unmatchedName = new QName("http://test.ns", "unmatchedAttr");
                                             
                                             // Mock dependencies
                                             NodePointer parent = mock(NodePointer.class);
                                             NamespaceResolver nsr = mock(NamespaceResolver.class);
                                             Element element = mock(Element.class);
                                             
                                             // Create test attributes
                                             Attr matchedAttr = mock(Attr.class);
                                             Attr unmatchedAttr = mock(Attr.class);
                                             
                                             // Setup mock behavior
                                             when(parent.getNamespaceResolver()).thenReturn(nsr);
                                             when(nsr.getNamespaceURI("test")).thenReturn("http://test.ns");
                                             when(element.getAttributeNodeNS("http://test.ns", "matchedAttr")).thenReturn(null);
                                             
                                             // Setup NamedNodeMap with both matched and unmatched attributes
                                             NamedNodeMap nnm = mock(NamedNodeMap.class);
                                             when(element.getAttributes()).thenReturn(nnm);
                                             when(nnm.getLength()).thenReturn(2);
                                             when(nnm.item(0)).thenReturn(unmatchedAttr);
                                             when(nnm.item(1)).thenReturn(matchedAttr);
                                             
                                             // Create test instance
                                             DOMAttributeIterator iterator = new DOMAttributeIterator(parent, testName);
                                             
                                             // Use reflection to test private methods
                                             Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                             testAttrMethod.setAccessible(true);
                                             
                                             // Setup mock attribute behavior
                                             when(matchedAttr.getNamespaceURI()).thenReturn("http://test.ns");
                                             when(matchedAttr.getLocalName()).thenReturn("matchedAttr");
                                             when(unmatchedAttr.getNamespaceURI()).thenReturn("http://test.ns");
                                             when(unmatchedAttr.getLocalName()).thenReturn("unmatchedAttr");
                                             
                                             // Call method under test using reflection
                                             Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                             getAttributeMethod.setAccessible(true);
                                             Attr result = (Attr) getAttributeMethod.invoke(iterator, element, testName);
                                             
                                             // Verify - should return matched attribute (would fail with mutant)
                                             assertSame(matchedAttr, result);
                                         }

 @Test
                                     public void testGetAttribute_NoNamespace_AttributeExists() throws Exception {
                                         // Setup test data
                                         QName testQName = new QName(null, "testAttr");
                                         Element mockElement = mock(Element.class);
                                         Attr expectedAttr = mock(Attr.class);
                                         
                                         // Mock behavior
                                         when(testQName.getPrefix()).thenReturn(null);
                                         when(mockElement.getAttributeNode("testAttr")).thenReturn(expectedAttr);
                                         
                                         // Create test instance
                                         NodePointer mockParent = mock(NodePointer.class);
                                         DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                         
                                         // Use reflection to access private method since we're testing it directly
                                         Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                             "getAttribute", Element.class, QName.class);
                                         getAttributeMethod.setAccessible(true);
                                         
                                         // Invoke and verify
                                         Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                         assertEquals("Should return the attribute when it exists with no namespace", 
                                             expectedAttr, result);
                                     }

 @Test
                                   public void testGetAttributeWithNonNullNamespaceResolver1() throws Exception {
                                       // Setup test data
                                       String namespaceURI = "http://test.ns";
                                       String localPart = "test";
                                       String prefix = "prefix";
                                       QName testName = new QName(namespaceURI, localPart);
                                       Element mockElement = mock(Element.class);
                                       NodePointer mockParent = mock(NodePointer.class);
                                       NamespaceResolver mockNsr = mock(NamespaceResolver.class);
                                       Attr expectedAttr = mock(Attr.class);
                                       
                                       // Mock behavior
                                       when(testName.getPrefix()).thenReturn(prefix);
                                       when(mockParent.getNamespaceResolver()).thenReturn(mockNsr);
                                       when(mockNsr.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                                       when(mockElement.getAttributeNodeNS(namespaceURI, localPart)).thenReturn(expectedAttr);
                                       
                                       // Create test instance
                                       DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testName);
                                       
                                       // Use reflection to access private method since we're testing it directly
                                       Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                           "getAttribute", Element.class, QName.class);
                                       getAttributeMethod.setAccessible(true);
                                       
                                       // Invoke and verify
                                       Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testName);
                                       
                                       // This assertion would fail with the mutant since mutant would return null for namespace
                                       // causing it to fall back to getAttributeNode instead of getAttributeNodeNS
                                       assertEquals(expectedAttr, result);
                                       
                                       // Verify the namespace resolver was actually used (wouldn't be called in mutant)
                                       verify(mockNsr).getNamespaceURI(prefix);
                                   }

 @Test
                          public void testGetAttribute_NamespaceResolutionFallback1() throws Exception {
                              // Setup test data
                              QName qname = new QName("prefix", "localName");
                              Element element = mock(Element.class);
                              Attr expectedAttr = mock(Attr.class);
                              
                              // Mock parent NodePointer
                              NodePointer parent = mock(NodePointer.class);
                              
                              // Mock the name object (QName)
                              QName name = mock(QName.class);
                              when(name.getPrefix()).thenReturn("prefix");
                              when(name.getName()).thenReturn("localName");
                              
                              // Mock namespace resolver to return null (first attempt fails)
                              NamespaceResolver nsr = mock(NamespaceResolver.class);
                              when(nsr.getNamespaceURI("prefix")).thenReturn(null);
                              when(parent.getNamespaceResolver()).thenReturn(nsr);
                              
                              // Mock parent to return a test namespace URI
                              when(parent.getNamespaceURI("prefix")).thenReturn("http://test.ns");
                              
                              // Mock element to return null for first getAttributeNodeNS call
                              when(element.getAttributeNodeNS("http://test.ns", "localName")).thenReturn(null);
                              
                              // Mock element to return expectedAttr for local name lookup
                              when(element.getAttributeNode("localName")).thenReturn(expectedAttr);
                              
                              // Create instance of tested class
                              DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                              
                              // Use reflection to access private getAttribute method
                              Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                  "getAttribute", Element.class, QName.class);
                              getAttributeMethod.setAccessible(true);
                              Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                              
                              // Verify behavior - original would use parent.getNamespaceURI when testNS is null
                              // Mutant would skip parent.getNamespaceURI when testNS is null
                              // So we verify the method tried to get attribute by namespace URI
                              verify(element).getAttributeNodeNS("http://test.ns", "localName");
                              
                              // Verify final result is from local name lookup
                              assertEquals(expectedAttr, result);
                              
                              // Verify parent.getNamespaceURI was called (would fail for mutant)
                              verify(parent).getNamespaceURI("prefix");
                          }

 @Test
                      public void testGetAttributeWithNamespaceShouldFindNamespacedAttr() throws Exception {
                          // Setup test data
                          String prefix = "test";
                          String namespaceUri = "http://test.com/ns";
                          String localName = "attr";
                          String attrValue = "value";
                          
                          // Create mock objects
                          QName qname = mock(QName.class);
                          when(qname.getPrefix()).thenReturn(prefix);
                          when(qname.getName()).thenReturn(localName);
                          
                          NodePointer parentPointer = mock(NodePointer.class);
                          NamespaceResolver nsResolver = mock(NamespaceResolver.class);
                          when(parentPointer.getNamespaceResolver()).thenReturn(nsResolver);
                          when(nsResolver.getNamespaceURI(prefix)).thenReturn(namespaceUri);
                          when(parentPointer.getNamespaceURI(prefix)).thenReturn(null);
                          
                          Element element = mock(Element.class);
                          
                          // Create namespaced attribute (should be found by original code)
                          Attr namespacedAttr = mock(Attr.class);
                          when(element.getAttributeNodeNS(namespaceUri, localName)).thenReturn(namespacedAttr);
                          
                          // Create non-namespaced attribute (should be ignored by original code when namespace exists)
                          Attr nonNamespacedAttr = mock(Attr.class);
                          when(element.getAttributeNode(localName)).thenReturn(nonNamespacedAttr);
                          
                          // Create the iterator and test
                          DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, qname);
                          
                          // Use reflection to access private method since it's not exposed
                          Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                          getAttributeMethod.setAccessible(true);
                          
                          // This should return the namespaced attribute with original code
                          // With mutated code (testNS == null), it would return the non-namespaced attribute
                          Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                          
                          // Verify the correct attribute was found
                          assertSame("Should return namespaced attribute when namespace exists", 
                                     namespacedAttr, result);
                          
                          // Verify the non-namespaced attribute search wasn't used
                          verify(element, never()).getAttributeNode(localName);
                      }

 @Test
                    public void testGetAttributeWithNamespacedAttrShouldReturnCorrectNSAttr() throws Exception {
                        // Setup test data
                        String namespaceURI = "http://test.ns";
                        String localName = "attr";
                        String prefix = "prefix";
                        QName name = new QName(namespaceURI, localName);
                        
                        Element element = mock(Element.class);
                        NodePointer parent = mock(NodePointer.class);
                        NamespaceResolver nsr = mock(NamespaceResolver.class);
                        
                        // Mock the name object behavior
                        when(name.getPrefix()).thenReturn(prefix);
                        when(name.getName()).thenReturn(localName);
                        
                        // Mock parent behavior
                        when(parent.getNamespaceResolver()).thenReturn(nsr);
                        when(nsr.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                        when(parent.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                        
                        // Create expected namespaced attribute and a non-namespaced one with same local name
                        Attr expectedAttr = mock(Attr.class);
                        Attr wrongAttr = mock(Attr.class);
                        
                        // Mock element behavior
                        when(element.getAttributeNodeNS(namespaceURI, localName)).thenReturn(expectedAttr);
                        when(element.getAttributeNode(localName)).thenReturn(wrongAttr);
                        
                        // Create test instance
                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                        
                        // Use reflection to access private method since we're testing implementation details
                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                        getAttributeMethod.setAccessible(true);
                        
                        // Invoke the method
                        Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                        
                        // Verify the correct attribute was returned
                        assertSame("Should return the namespaced attribute", expectedAttr, result);
                        assertNotSame("Should not return the non-namespaced attribute", wrongAttr, result);
                        
                        // Verify the proper methods were called
                        verify(element).getAttributeNodeNS(namespaceURI, localName);
                        verify(element, never()).getAttributeNode(localName); // Original shouldn't call this first
                    }

 @Test
               public void testGetAttributeWithNamespacedAttrShouldReturnAttrWhenFound() throws Exception {
                   // Setup test data
                   String namespaceURI = "http://test.ns";
                   String localPart = "testAttr";
                   String prefix = "prefix";
                   QName testQName = new QName(namespaceURI, localPart);
                   Element mockElement = mock(Element.class);
                   NodePointer mockParent = mock(NodePointer.class);
                   NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                   Attr expectedAttr = mock(Attr.class);
                   
                   // Mock behavior
                   when(testQName.getPrefix()).thenReturn(prefix);
                   when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                   when(mockNsResolver.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                   when(mockElement.getAttributeNodeNS(namespaceURI, localPart)).thenReturn(expectedAttr);
                   
                   // Create test instance
                   DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                   
                   // Use reflection to access private method since we're testing it directly
                   Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                   getAttributeMethod.setAccessible(true);
                   
                   // Invoke and verify
                   Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                   
                   // This assertion would pass with original code but fail with mutant
                   assertEquals("Should return the found namespaced attribute", expectedAttr, result);
                   
                   // Verify no unnecessary interactions occurred
                   verify(mockElement, never()).getAttributes();
                   verify(mockElement, never()).getAttributeNode(anyString());
               }

 @Test
          public void testGetAttribute_ShouldFindNonFirstAttribute() throws Exception {
              // Setup test data
              QName testQName = new QName("http://test.ns", "testAttr");
              
              // Create mock objects
              NodePointer parentPointer = mock(NodePointer.class);
              NamespaceResolver nsResolver = mock(NamespaceResolver.class);
              Element element = mock(Element.class);
              NamedNodeMap attributes = mock(NamedNodeMap.class);
              
              // Create test attributes (we need at least 2, with our target being the second one)
              Attr wrongAttr = mock(Attr.class);
              Attr correctAttr = mock(Attr.class);
              
              // Configure mocks
              when(parentPointer.getNamespaceResolver()).thenReturn(nsResolver);
              when(nsResolver.getNamespaceURI("prefix")).thenReturn("http://test.ns");
              when(element.getAttributeNodeNS("http://test.ns", "testAttr")).thenReturn(null);
              when(element.getAttributes()).thenReturn(attributes);
              when(attributes.getLength()).thenReturn(2);
              
              // Important: The mutation will only check index 0, so we put our match at index 1
              when(attributes.item(0)).thenReturn(wrongAttr);
              when(attributes.item(1)).thenReturn(correctAttr);
              
              // Create iterator and set up testAttr method behavior using reflection
              DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, testQName);
              
              // Get the private testAttr method via reflection
              Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod(
                  "testAttr", Attr.class, QName.class);
              testAttrMethod.setAccessible(true);
              
              // Configure testAttr method behavior (correctAttr should match)
              when(testAttrMethod.invoke(iterator, wrongAttr, testQName)).thenReturn(false);
              when(testAttrMethod.invoke(iterator, correctAttr, testQName)).thenReturn(true);
              
              // Get the private getAttribute method via reflection
              Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                  "getAttribute", Element.class, QName.class);
              getAttributeMethod.setAccessible(true);
              
              // Call the method under test
              Attr result = (Attr) getAttributeMethod.invoke(iterator, element, testQName);
              
              // Verify the result
              assertSame("Should return the correct attribute", correctAttr, result);
              
              // Verify interactions
              verify(attributes).item(0);
              verify(attributes).item(1);
          }

 @Test
     public void testGetAttribute_ShouldOnlyReturnMatchingAttributes1() throws Exception {
         // Setup test data
         QName testQName = new QName("http://test.ns", "matchedAttr");
         QName wrongQName = new QName("http://test.ns", "unmatchedAttr");
         
         // Create mock elements and attributes
         Element mockElement = mock(Element.class);
         NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
         
         // Create two attributes - one that should match and one that shouldn't
         Attr matchingAttr = mock(Attr.class);
         Attr nonMatchingAttr = mock(Attr.class);
         
         // Configure mocks
         when(mockElement.getAttributes()).thenReturn(mockAttributes);
         when(mockAttributes.getLength()).thenReturn(2);
         when(mockAttributes.item(0)).thenReturn(nonMatchingAttr);
         when(mockAttributes.item(1)).thenReturn(matchingAttr);
         
         // Mock the attribute names to simulate matching behavior
         when(matchingAttr.getNamespaceURI()).thenReturn("http://test.ns");
         when(matchingAttr.getLocalName()).thenReturn("matchedAttr");
         when(nonMatchingAttr.getNamespaceURI()).thenReturn("http://test.ns");
         when(nonMatchingAttr.getLocalName()).thenReturn("unmatchedAttr");
         
         // Create iterator
         DOMAttributeIterator iterator = new DOMAttributeIterator(mock(NodePointer.class), testQName);
         
         // Use reflection to test private method
         try {
             Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
             getAttributeMethod.setAccessible(true);
             Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
             
             // Verify - should return the matching attribute only
             assertSame("Should return matching attribute", matchingAttr, result);
         } catch (Exception e) {
             fail("Reflection failed: " + e.getMessage());
         }
     }

 @Test
 public void testGetAttribute_NoNamespace_AttributeExists1() throws Exception {
     // Setup test data
     QName testQName = new QName(null, "testAttr");
     Element mockElement = mock(Element.class);
     Attr expectedAttr = mock(Attr.class);
     
     // Mock behavior
     when(testQName.getPrefix()).thenReturn(null);
     when(mockElement.getAttributeNode("testAttr")).thenReturn(expectedAttr);
     
     // Create test instance (using reflection since constructor may be complex)
     NodePointer mockParent = mock(NodePointer.class);
     DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
     
     // Use reflection to access private method
     Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
         "getAttribute", Element.class, QName.class);
     getAttributeMethod.setAccessible(true);
     
     // Invoke method and verify
     Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
     assertEquals("Should return the attribute when it exists without namespace", 
         expectedAttr, result);
     
     // Verify interactions
     verify(mockElement).getAttributeNode("testAttr");
 }

}
