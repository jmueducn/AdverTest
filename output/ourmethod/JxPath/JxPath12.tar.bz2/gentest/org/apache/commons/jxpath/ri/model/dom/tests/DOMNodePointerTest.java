package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testNode_NullTest() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeNameTest_NonElementNode() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                            when(mockTest.getNodeName()).thenReturn(new QName("test"));
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeNameTest_WildcardNullPrefix() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                            when(mockTest.isWildcard()).thenReturn(true);
                                                                                                                                                                            when(mockTest.getNodeName()).thenReturn(new QName(null, "test"));
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeNameTest_MatchingLocalNameAndNamespace() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                            QName testName = new QName("ns", "test");
                                                                                                                                                                            when(mockTest.getNodeName()).thenReturn(testName);
                                                                                                                                                                            when(mockTest.getNamespaceURI()).thenReturn("ns");
                                                                                                                                                                            when(mockTest.isWildcard()).thenReturn(false);
                                                                                                                                                                            
                                                                                                                                                                            // Mock static methods
                                                                                                                                                                            when(DOMNodePointer.getLocalName(mockNode)).thenReturn("test");
                                                                                                                                                                            when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("ns");
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeTypeTest_NodeTypeNode() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                            when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeTypeTest_NodeTypeText() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                            when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_TEXT);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeTypeTest_NodeTypeComment() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                            when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_COMMENT);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeTypeTest_NodeTypePI() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                            when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_PI);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_ProcessingInstructionTest_MatchingTarget() {
                                                                                                                                                                            ProcessingInstruction mockNode = mock(ProcessingInstruction.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                            when(mockNode.getTarget()).thenReturn("target");
                                                                                                                                                                            
                                                                                                                                                                            ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                            when(mockTest.getTarget()).thenReturn("target");
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_ProcessingInstructionTest_NonMatchingTarget() {
                                                                                                                                                                            ProcessingInstruction mockNode = mock(ProcessingInstruction.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                            when(mockNode.getTarget()).thenReturn("target1");
                                                                                                                                                                            
                                                                                                                                                                            ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                            when(mockTest.getTarget()).thenReturn("target2");
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_ProcessingInstructionTest_WrongNodeType() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                            when(mockTest.getTarget()).thenReturn("target");
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_UnknownTestType() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            NodeTest mockTest = mock(NodeTest.class); // Unknown implementation
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testStaticTestNode_HandlesNullTest() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    Node testNode = mock(Node.class);
                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                    
                                                                                                                                                                    // Execute & Verify
                                                                                                                                                                    exception.expect(NullPointerException.class);
                                                                                                                                                                    DOMNodePointer.testNode(testNode, null);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testTestNode_WithDifferentNodeTypes() {
                                                                                                                                                                    // Test with different node types
                                                                                                                                                                    Node elementNode = mock(Node.class);
                                                                                                                                                                    Node textNode = mock(Node.class);
                                                                                                                                                                    Node attrNode = mock(Node.class);
                                                                                                                                                                    
                                                                                                                                                                    // Create anonymous implementations of NodeTest interface
                                                                                                                                                                    NodeTest elementTest = new NodeTest() {
                                                                                                                                                                        public boolean testNode(Node node) {
                                                                                                                                                                            return node == elementNode;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    NodeTest textTest = new NodeTest() {
                                                                                                                                                                        public boolean testNode(Node node) {
                                                                                                                                                                            return node == textNode;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    NodeTest attrTest = new NodeTest() {
                                                                                                                                                                        public boolean testNode(Node node) {
                                                                                                                                                                            return node == attrNode ? false : false;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    assertTrue(DOMNodePointer.testNode(elementNode, elementTest));
                                                                                                                                                                    assertTrue(DOMNodePointer.testNode(textNode, textTest));
                                                                                                                                                                    assertFalse(DOMNodePointer.testNode(attrNode, attrTest));
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testTestNode_HandlesNullTest() {
                                                                                                                                                            // Setup
                                                                                                                                                            Node node = null; // Mock or create a real Node if needed
                                                                                                                                                            Locale locale = Locale.getDefault();
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(node, locale);
                                                                                                                                                            
                                                                                                                                                            // Expected exception setup
                                                                                                                                                            ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                            expectedException.expect(NullPointerException.class);
                                                                                                                                                            
                                                                                                                                                            // Execute
                                                                                                                                                            pointer.testNode(null);
                                                                                                                                                        }

    @Test
                                                                            public void testStaticTestNode_HandlesNullNode() {
                                                                                // Setup
                                                                                org.w3c.dom.Node node = null;
                                                                                org.apache.commons.jxpath.ri.compiler.NodeTest test = new org.apache.commons.jxpath.ri.compiler.NodeTest() {
                                                                                    public boolean isCollection() {
                                                                                        return false;
                                                                                    }
                                                                                    
                                                                                    public boolean isWildcard() {
                                                                                        return false;
                                                                                    }
                                                                                    
                                                                                    public boolean isNodeNameTest() {
                                                                                        return false;
                                                                                    }
                                                                                    
                                                                                    public boolean isNodeTypeTest() {
                                                                                        return false;
                                                                                    }
                                                                                    
                                                                                    public Object getNodeType() {
                                                                                        return null;
                                                                                    }
                                                                                    
                                                                                    public boolean isVariableReference() {
                                                                                        return false;
                                                                                    }
                                                                                    
                                                                                    public String toString() {
                                                                                        return "TestNode";
                                                                                    }
                                                                                };
                                                                                
                                                                                boolean result = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(node, test);
                                                                                
                                                                                // Verify
                                                                                org.junit.Assert.assertFalse(result);
                                                                            }

    @Test
    public void testStaticTestNode_ReturnsTrueWhenTestPasses() {
        // Setup
        javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
        org.w3c.dom.Document document;
        try {
            document = factory.newDocumentBuilder().newDocument();
        } catch (Exception e) {
            throw new RuntimeException("Failed to create document", e);
        }
        org.w3c.dom.Node testNode = document.createElement("test");
        org.apache.commons.jxpath.ri.QName qName = new org.apache.commons.jxpath.ri.QName("test");
        
        // Create a NodeTest that will match our test node
{
{
                return true;
            }
{
                return qName;
            }
{
                return false;
            }
        };
        
        boolean result = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(testNode, nodeTest);
        
        // Verify
        org.junit.Assert.assertTrue(result);
    }

    @Test
    public void testTestNode_DelegatesToStaticMethod() {
        // Setup
        
        // Mock static method
        try (org.mockito.MockedStatic<org.apache.commons.jxpath.ri.model.dom.DOMNodePointer> mocked = 
{
            // Setup mock behavior
            
            // Execute
        }
    }

    @Test
    public void testStaticTestNode_ReturnsFalseWhenTestFails() {
        // Setup
        try (org.mockito.MockedStatic<org.apache.commons.jxpath.ri.model.dom.DOMNodePointer> mocked = 
{
            
            // Exercise
        }
    }


}