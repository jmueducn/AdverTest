package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                               public void testNode_ProcessingInstructionTest_Match() {
                                                                                                                                   ProcessingInstructionTest test = mock(ProcessingInstructionTest.class);
                                                                                                                                   when(test.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                   
                                                                                                                                   ProcessingInstruction pi = mock(ProcessingInstruction.class);
                                                                                                                                   when(pi.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                   
                                                                                                                                   DOMNodePointer piPointer = new DOMNodePointer(pi, null);
                                                                                                                                   assertTrue(piPointer.testNode(test));
                                                                                                                               }

    @Test
                                                                                                                               public void testNode_ProcessingInstructionTest_NoMatch() {
                                                                                                                                   ProcessingInstructionTest test = mock(ProcessingInstructionTest.class);
                                                                                                                                   when(test.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                   
                                                                                                                                   ProcessingInstruction pi = mock(ProcessingInstruction.class);
                                                                                                                                   when(pi.getTarget()).thenReturn("other-target");
                                                                                                                                   
                                                                                                                                   DOMNodePointer piPointer = new DOMNodePointer(pi, null);
                                                                                                                                   assertFalse(piPointer.testNode(test));
                                                                                                                               }

    @Test
                                                                                                                       public void testNode_WhenNodeIsNull() {
                                                                                                                           // Setup
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer((Node)null, Locale.getDefault());
                                                                                                                           NodeTest mockNodeTest = new NodeTest() {
                                                                                                                               public boolean testNode(Node node, NodeTest test) {
                                                                                                                                   return false;
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Execute & Verify
                                                                                                                           assertFalse(pointer.testNode(mockNodeTest));
                                                                                                                       }

    @Test
                                                                                                                       public void testStaticTestNode_WhenNodeIsNull() {
                                                                                                                           NodeTest mockNodeTest = mock(NodeTest.class);
                                                                                                                           assertFalse(DOMNodePointer.testNode(null, mockNodeTest));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NullTest() {
                                                                                                                           Node node = null;
                                                                                                                           Locale locale = Locale.getDefault();
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(node, locale);
                                                                                                                           assertTrue(pointer.testNode(null));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NodeNameTest_NonElementNode() {
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           NodeNameTest test = mock(NodeNameTest.class);
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           
                                                                                                                           assertFalse(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NodeNameTest_WildcardNoPrefix() {
                                                                                                                           // Create and mock the node that will be tested
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                           
                                                                                                                           // Create the pointer with the mocked node
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           
                                                                                                                           // Mock the NodeNameTest
                                                                                                                           NodeNameTest test = mock(NodeNameTest.class);
                                                                                                                           when(test.isWildcard()).thenReturn(true);
                                                                                                                           
                                                                                                                           // Mock the QName
                                                                                                                           QName mockQName = mock(QName.class);
                                                                                                                           when(test.getNodeName()).thenReturn(mockQName);
                                                                                                                           when(mockQName.getPrefix()).thenReturn(null);
                                                                                                                           
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NodeNameTest_WildcardWithPrefix_NamespaceMatch() {
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           
                                                                                                                           NodeNameTest test = mock(NodeNameTest.class);
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                           when(test.isWildcard()).thenReturn(true);
                                                                                                                           when(test.getNamespaceURI()).thenReturn("http://test");
                                                                                                                           
                                                                                                                           QName mockQName = mock(QName.class);
                                                                                                                           when(test.getNodeName()).thenReturn(mockQName);
                                                                                                                           when(mockQName.getPrefix()).thenReturn("test");
                                                                                                                           
                                                                                                                           when(mockNode.getNamespaceURI()).thenReturn("http://test");
                                                                                                                           
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NodeNameTest_WildcardWithPrefix_PrefixMatch() {
                                                                                                                           // Setup mocks
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           NodeNameTest test = mock(NodeNameTest.class);
                                                                                                                           
                                                                                                                           // Configure mock behaviors
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                           when(test.isWildcard()).thenReturn(true);
                                                                                                                           when(test.getNamespaceURI()).thenReturn("http://test");
                                                                                                                           
                                                                                                                           QName mockQName = mock(QName.class);
                                                                                                                           when(test.getNodeName()).thenReturn(mockQName);
                                                                                                                           when(mockQName.getPrefix()).thenReturn("test");
                                                                                                                           
                                                                                                                           // Mock static method calls
                                                                                                                           when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn(null);
                                                                                                                           when(DOMNodePointer.getPrefix(mockNode)).thenReturn("test");
                                                                                                                           
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NodeTypeTest_NodeTypeNode() {
                                                                                                                           // Setup test objects
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                                                           
                                                                                                                           // Mock NodeTypeTest behavior
                                                                                                                           when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                                                                                                           
                                                                                                                           // Test with ELEMENT_NODE
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                           
                                                                                                                           // Test with DOCUMENT_NODE
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                           
                                                                                                                           // Test with invalid node type
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                           assertFalse(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NodeTypeTest_NodeTypeText() {
                                                                                                                           // Setup mock objects
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                                                           
                                                                                                                           when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_TEXT);
                                                                                                                           
                                                                                                                           // Test with TEXT_NODE
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                           
                                                                                                                           // Test with CDATA_SECTION_NODE
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                           
                                                                                                                           // Test with invalid node type
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                           assertFalse(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NodeTypeTest_NodeTypeComment() {
                                                                                                                           // Setup mock objects
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                                                           
                                                                                                                           // Mock behavior
                                                                                                                           when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_COMMENT);
                                                                                                                           
                                                                                                                           // Test with COMMENT_NODE
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                           
                                                                                                                           // Test with invalid node type
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                           assertFalse(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_NodeTypeTest_NodeTypePI() {
                                                                                                                           // Setup mock objects
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           NodeTypeTest test = mock(NodeTypeTest.class);
                                                                                                                           
                                                                                                                           // Mock behavior for PROCESSING_INSTRUCTION_NODE test
                                                                                                                           when(test.getNodeType()).thenReturn(Compiler.NODE_TYPE_PI);
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                           assertTrue(pointer.testNode(test));
                                                                                                                           
                                                                                                                           // Mock behavior for invalid node type test
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                           assertFalse(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_ProcessingInstructionTest_NonPINode() {
                                                                                                                           ProcessingInstructionTest test = mock(ProcessingInstructionTest.class);
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                           
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           assertFalse(pointer.testNode(test));
                                                                                                                       }

    @Test
                                                                                                                       public void testNode_UnknownTestType() {
                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                           NodeTest unknownTest = mock(NodeTest.class);
                                                                                                                           assertFalse(pointer.testNode(unknownTest));
                                                                                                                       }

    @Test
                                                                               public void testNode_WhenTestPasses() {
                                                                                   // Setup
                                                                                   org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                   
                                                                                   
                                                                                   // Execute & Verify
                                                                               }

    @Test
                                                                               public void testNode_WhenTestFails() {
                                                                                   // Setup
                                                                                   org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                       new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, java.util.Locale.getDefault());
                                                                                   
                                                                                   
                                                                                   // Execute & Verify
                                                                               }

    @Test
                                                                               public void testStaticTestNode_WhenTestPasses() {
                                                                               }

    @Test
                                                                               public void testStaticTestNode_WhenTestFails() {
                                                                                   org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                               }

    @Test
                                                                               public void testStaticTestNode_WhenNodeTestThrowsException() {
                                                                                   // Setup
                                                                                   Node mockNode = mock(Node.class);
                                                                                   NodeTest mockNodeTest = mock(NodeTest.class);
                                                                                   ExpectedException exception = ExpectedException.none();
                                                                                   
                                                                                   RuntimeException testException = new RuntimeException("Test exception");
                                                                                   exception.expect(RuntimeException.class);
                                                                                   exception.expectMessage("Test exception");
                                                                                   
                                                                                   // Execute
                                                                                   DOMNodePointer.testNode(mockNode, mockNodeTest);
                                                                               }

    @Test
                                                                               public void testNode_NodeNameTest_LocalNameMatch() throws Exception {
                                                                                   // Create mock objects
                                                                                   NodeNameTest test = mock(NodeNameTest.class);
                                                                                   QName mockQName = mock(QName.class);
                                                                                   
                                                                                   // Create a real element node with the required properties
                                                                                   
                                                                                   // Setup mock behaviors
                                                                                   when(test.isWildcard()).thenReturn(false);
                                                                                   when(test.getNodeName()).thenReturn(mockQName);
                                                                                   when(mockQName.getName()).thenReturn("testName");
                                                                                   when(test.getNamespaceURI()).thenReturn("http://test");
                                                                                   
                                                                               }

    @Test
                                                                               public void testStaticTestNode_WhenNodeTestIsNull() {
                                                                                   
                                                                                   try {
                                                                                       fail("Expected NullPointerException to be thrown");
                                                                                   } catch (NullPointerException e) {
                                                                                       // Expected exception
                                                                                   }
                                                                               }

    @Test
                                       public void testNodeNameTestNamespaceComparison() {
                                           // Setup test objects
                                           Node mockNode = mock(Node.class);
                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                           
                                           NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                                           when(nodeNameTest.getNodeName()).thenReturn(new QName("prefix", "localName"));
                                           when(nodeNameTest.isWildcard()).thenReturn(false);
                                           
                                           // Case 1: nodeNS is not null but matches namespaceURI - should pass original, fail mutant
                                           when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("http://test.com");
                                           when(DOMNodePointer.getLocalName(mockNode)).thenReturn("localName");
                                           when(nodeNameTest.getNamespaceURI()).thenReturn("http://test.com");
                                           
                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                           assertTrue(pointer.testNode(nodeNameTest)); // This will fail with mutant
                                           
                                           // Case 2: nodeNS is null and namespaces match - pass both
                                           when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn(null);
                                           when(nodeNameTest.getNamespaceURI()).thenReturn(null);
                                           assertTrue(pointer.testNode(nodeNameTest)); // Passes both
                                           
                                           // Case 3: nodeNS is null but namespaces don't match - fail both
                                           when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn(null);
                                           when(nodeNameTest.getNamespaceURI()).thenReturn("http://test.com");
                                           assertFalse(pointer.testNode(nodeNameTest)); // Fails both
                                           
                                           // Case 4: nodeNS is not null and namespaces don't match - fail both
                                           when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("http://test1.com");
                                           when(nodeNameTest.getNamespaceURI()).thenReturn("http://test2.com");
                                           assertFalse(pointer.testNode(nodeNameTest)); // Fails both
                                       }

    @Test
                                      public void testNamespaceURICheckWithMutantDetection() throws Exception {
                                          // Get the private equalStrings method via reflection
                                          Method equalStringsMethod = DOMNodePointer.class.getDeclaredMethod("equalStrings", String.class, String.class);
                                          equalStringsMethod.setAccessible(true);
                                          
                                          // Case 1: Equal strings, nodeNS not null - should pass original, fail mutant
                                          String namespace1 = "http://example.com";
                                          String nodeNS1 = "http://example.com";
                                          boolean result1 = (boolean)equalStringsMethod.invoke(null, namespace1, nodeNS1) || nodeNS1 == null;
                                          assertTrue("Should return true when strings are equal regardless of null", result1);
                                          
                                          // Case 2: Unequal strings, nodeNS is null - should pass original, fail mutant
                                          String namespace2 = "http://example.com";
                                          String nodeNS2 = null;
                                          boolean result2 = (boolean)equalStringsMethod.invoke(null, namespace2, nodeNS2) || nodeNS2 == null;
                                          assertTrue("Should return true when nodeNS is null regardless of string equality", result2);
                                          
                                          // Case 3: Equal strings, nodeNS is null - both should pass
                                          String namespace3 = "http://example.com";
                                          String nodeNS3 = "http://example.com";
                                          nodeNS3 = null;
                                          boolean result3 = (boolean)equalStringsMethod.invoke(null, namespace3, nodeNS3) || nodeNS3 == null;
                                          assertTrue("Should return true when both conditions are true", result3);
                                          
                                          // Case 4: Unequal strings, nodeNS not null - both should fail
                                          String namespace4 = "http://example.com";
                                          String nodeNS4 = "http://different.com";
                                          boolean result4 = (boolean)equalStringsMethod.invoke(null, namespace4, nodeNS4) || nodeNS4 == null;
                                          assertFalse("Should return false when neither condition is true", result4);
                                      }

    @Test
                                  public void testNodeNameTestWithNullNamespaceAndMatchingPrefix() {
                                      // Setup test objects
                                      Node node = mock(Node.class);
                                      when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                      when(DOMNodePointer.getLocalName(node)).thenReturn("testName");
                                      when(DOMNodePointer.getNamespaceURI(node)).thenReturn(null);
                                      when(DOMNodePointer.getPrefix(node)).thenReturn("testPrefix");
                                      
                                      // Create NodeNameTest with non-matching namespace but matching prefix
                                      NodeNameTest test = mock(NodeNameTest.class);
                                      when(test.getNodeName()).thenReturn(new QName("testPrefix", "testName"));
                                      when(test.getNamespaceURI()).thenReturn("nonMatchingURI");
                                      when(test.isWildcard()).thenReturn(false);
                                      
                                      // Create DOMNodePointer instance
                                      DOMNodePointer pointer = new DOMNodePointer(node, Locale.getDefault());
                                      
                                      // The original should return true (null namespace + matching prefix)
                                      // The mutant will return false (only checks namespace match)
                                      assertTrue(pointer.testNode(test));
                                  }

    @Test
                             public void testTestNode_ShouldReturnTrueWhenNodeNamespaceIsNull() {
                                 // Setup
                                 Node mockNode = mock(Node.class);
                                 when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn(null);
                                 
                                 NodeTest mockTest = mock(NodeTest.class);
                                 
                                 // Test - should return true when node namespace is null (original behavior)
                                 boolean result = DOMNodePointer.testNode(mockNode, mockTest);
                                 
                                 // Verify - this assertion will fail with the mutant
                                 assertTrue("Should return true when node namespace is null", result);
                                 
                                 // Verify interactions
                                 verify(mockNode, atLeastOnce()).getNamespaceURI();
                             }

    @Test
                             public void testTestNodeNamespaceComparison() {
                                 // Create test objects
                                 Node nodeWithMatchingNS = mock(Node.class);
                                 Node nodeWithNullNS = mock(Node.class);
                                 Node nodeWithDifferentNS = mock(Node.class);
                                 NodeTest test = mock(NodeTest.class);
                                 
                                 // Setup namespace behavior
                                 when(DOMNodePointer.getNamespaceURI(nodeWithMatchingNS)).thenReturn("http://example.com");
                                 when(DOMNodePointer.getNamespaceURI(nodeWithNullNS)).thenReturn(null);
                                 when(DOMNodePointer.getNamespaceURI(nodeWithDifferentNS)).thenReturn("http://different.com");
                                 
                                 // Test case 1: Matching namespace should return true
                                 boolean result1 = DOMNodePointer.testNode(nodeWithMatchingNS, test);
                                 assertTrue("Should return true for matching namespace", result1);
                                 
                                 // Test case 2: Null namespace should return true
                                 boolean result2 = DOMNodePointer.testNode(nodeWithNullNS, test);
                                 assertTrue("Should return true for null namespace", result2);
                                 
                                 // Test case 3: Different namespace should return false
                                 boolean result3 = DOMNodePointer.testNode(nodeWithDifferentNS, test);
                                 assertFalse("Should return false for different namespace", result3);
                             }

    @Test
                         public void testNode_shouldDetectNamespaceMatchingMutant() throws Exception {
                             // Setup test objects
                             Node mockNode = mock(Node.class);
                             when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                             when(DOMNodePointer.getLocalName(mockNode)).thenReturn("testName");
                             when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("testNamespace");
                             
                             NodeNameTest mockTest = mock(NodeNameTest.class);
                             QName mockQName = mock(QName.class);
                             when(mockTest.getNodeName()).thenReturn(mockQName);
                             when(mockQName.getName()).thenReturn("testName");
                             when(mockTest.getNamespaceURI()).thenReturn("testNamespace");
                             when(mockTest.isWildcard()).thenReturn(false);
                             
                             // Create DOMNodePointer instance
                             DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                             
                             // Test case 1: Namespaces match exactly
                             // Original should return true, mutant returns false
                             assertTrue("Should return true when namespaces match", 
                                        pointer.testNode(mockTest));
                             
                             // Test case 2: Node namespace is null but prefixes match
                             when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn(null);
                             when(mockQName.getPrefix()).thenReturn("prefix");
                             when(DOMNodePointer.getPrefix(mockNode)).thenReturn("prefix");
                             
                             // Original should return true, mutant returns false
                             assertTrue("Should return true when nodeNS is null and prefixes match", 
                                        pointer.testNode(mockTest));
                         }

    @Test
                        public void testNodeNameTestWithPrefixMismatch() {
                            // Setup test objects
                            Node node = mock(Node.class);
                            when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                            when(DOMNodePointer.getLocalName(node)).thenReturn("testName");
                            when(DOMNodePointer.getNamespaceURI(node)).thenReturn(null);
                            when(DOMNodePointer.getPrefix(node)).thenReturn("wrongPrefix");
                        
                            NodeNameTest test = mock(NodeNameTest.class);
                            when(test.getNodeName()).thenReturn(new QName("correctPrefix", "testName"));
                            when(test.getNamespaceURI()).thenReturn(null);
                            when(test.isWildcard()).thenReturn(false);
                            
                            DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                        
                            // Execute test
                            boolean result = pointer.testNode(test);
                        
                            // Verify - should be false because prefixes don't match
                            assertFalse("Should return false when prefixes don't match", result);
                        }

    @Test
                   public void testTestNodeWithDifferentPrefixesShouldFail() throws Exception {
                       // Setup
                       Node mockNode = mock(Node.class);
                       NodeTest mockTest = mock(NodeTest.class);
                       
                       // Mock behavior - testNode(node, test) returns true for the static method
                       when(DOMNodePointer.testNode(mockNode, mockTest)).thenReturn(true);
                       
                       // Mock getPrefix to return "actualPrefix"
                       when(DOMNodePointer.getPrefix(mockNode)).thenReturn("actualPrefix");
                       
                       // Create test case where testPrefix is different
                       String testPrefix = "differentPrefix";
                       
                       // Create DOMNodePointer instance to test instance method
                       DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                       
                       // The original code should return false because prefixes don't match
                       // The mutant will return true because it ignores the prefix check
                       boolean result = pointer.testNode(mockTest);
                       
                       // Assert that prefixes don't match (original behavior)
                       assertFalse("Method should return false when prefixes don't match", result);
                       
                       // Verify the prefix check was called (would fail for mutant)
                       verify(mockNode, atLeastOnce()).getPrefix();
                   }

    @Test
               public void testNode_WithUnsupportedTestType_ShouldReturnFalse() {
                   // Setup
                   Node mockNode = mock(Node.class);
                   NodeTest unsupportedTest = mock(NodeTest.class); // Any test type not handled
                   
                   DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                   
                   // Execute
                   boolean result = pointer.testNode(unsupportedTest);
                   
                   // Verify
                   assertFalse("Method should return false for unsupported test types", result);
                   
                   // Additional verification that we didn't process any known test types
                   verify(mockNode, never()).getNodeType();
               }

    @Test
              public void testTestNode_ShouldReturnFalseWhenNodeTestFails() {
                  // Setup
                  Node mockNode = mock(Node.class);
                  NodeTest mockTest = mock(NodeTest.class);
                  
                  // Configure the test to return false for our test case
                  when(DOMNodePointer.testNode(mockNode, mockTest)).thenReturn(false);
                  
                  // Create test instance - using simplest constructor
                  DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                  
                  // Execute and verify
                  assertFalse("Method should return false when node test fails", 
                             pointer.testNode(mockTest));
              }

    @Test
          public void testNamespaceURICheckWithNullNodeNS() {
              // Setup
              String namespaceURI = "http://example.com/ns";
              String nodeNS = null;
              
              // Create mock Node and NodeTest objects since we don't have their implementations
              Node mockNode = mock(Node.class);
              NodeTest mockTest = mock(NodeTest.class);
              
              // Mock the static getNamespaceURI method behavior
              when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn(nodeNS);
              
              // Mock the equalStrings method behavior
              // Since equalStrings is private, we'll assume it returns false when comparing with null
              // (typical string comparison behavior)
              
              // Test the original behavior should return true when nodeNS is null
              boolean originalResult = DOMNodePointer.testNode(mockNode, mockTest);
              assertTrue("Should return true when nodeNS is null", originalResult);
              
              // The mutant would return false here, which would fail this test
          }

    @Test
         public void testNodeNameTestWithNullNamespaceAndMatchingPrefix1() throws Exception {
             // Setup test objects
             Node node = mock(Node.class);
             when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
             
             NodeNameTest test = mock(NodeNameTest.class);
             when(test.getNodeName()).thenReturn(new QName("testPrefix", "localName"));
             when(test.getNamespaceURI()).thenReturn("testNamespace");
             when(test.isWildcard()).thenReturn(true);
             
             // Create test instance
             DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
             
             // Test - should return true because nodeNS is null and prefixes match
             assertTrue(pointer.testNode(test));
             
             // Verify node type was checked
             verify(node).getNodeType();
             
             // Verify test properties were accessed
             verify(test).getNodeName();
             verify(test).getNamespaceURI();
             verify(test).isWildcard();
         }

    @Test
     public void testNodeNameTestWithDifferentNamespacesShouldNotMatch() throws Exception {
         // Setup test objects
         NodeNameTest nodeNameTest = mock(NodeNameTest.class);
         QName testName = mock(QName.class);
         Node node = mock(Node.class);
         
         // Configure mocks for NodeNameTest case
         when(nodeNameTest.getNodeName()).thenReturn(testName);
         when(nodeNameTest.getNamespaceURI()).thenReturn("http://test-namespace");
         when(nodeNameTest.isWildcard()).thenReturn(false);
         when(testName.getName()).thenReturn("testName");
         when(testName.getPrefix()).thenReturn("testPrefix");
         
         // Configure node behavior
         when(node.getNodeType()).thenReturn(Node.ELEMENT_NODE);
         when(DOMNodePointer.getLocalName(node)).thenReturn("testName");
         when(DOMNodePointer.getNamespaceURI(node)).thenReturn("http://different-namespace");
         when(DOMNodePointer.getPrefix(node)).thenReturn("differentPrefix");
         
         // Create test instance
         DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
         
         // Test - should return false since namespaces don't match
         // But mutant will return true
         assertFalse(pointer.testNode(nodeNameTest));
         
         // Additional test case where nodeNS is null but prefixes don't match
         when(DOMNodePointer.getNamespaceURI(node)).thenReturn(null);
         assertFalse(pointer.testNode(nodeNameTest));
     }

    @Test
    public void testNamespaceComparison() {
        // Create test objects
        Node mockNode = mock(Node.class);
        when(mockNode.getNamespaceURI()).thenReturn("http://different.namespace");
        
        // Create test case where namespaces don't match and nodeNS is not null
        // Original should return false, mutant will return true
        boolean result = DOMNodePointer.testNode(mockNode, new NodeTest() {
            public boolean testNode(Node node) {
                return "http://test.namespace".equals(node.getNamespaceURI())
                       || node.getNamespaceURI() == null;
            }
        });
        
        // Assert that the result is false (original behavior)
        assertFalse("Should return false when namespaces don't match and nodeNS is not null", result);
        
        // Additional test case where nodeNS is null (both original and mutant would return true)
        when(mockNode.getNamespaceURI()).thenReturn(null);
        boolean nullResult = DOMNodePointer.testNode(mockNode, new NodeTest() {
            public boolean testNode(Node node) {
                return "http://test.namespace".equals(node.getNamespaceURI())
                       || node.getNamespaceURI() == null;
            }
        });
        
        // This case should pass for both original and mutant
        assertTrue("Should return true when nodeNS is null", nullResult);
    }


}
