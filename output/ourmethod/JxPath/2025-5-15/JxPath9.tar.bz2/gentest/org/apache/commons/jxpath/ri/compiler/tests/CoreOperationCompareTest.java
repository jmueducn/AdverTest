package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.InfoSetUtil;
import org.apache.commons.jxpath.ri.axes.InitialContext;
import org.apache.commons.jxpath.ri.axes.SelfContext;
 
public class CoreOperationCompareTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                  public void testComputeValue_WithInvertFlagTrue_EqualExpressionsReturnsFalse() {
                                                                                                      // Setup
                                                                                                      Expression expr1 = mock(Expression.class);
                                                                                                      Expression expr2 = mock(Expression.class);
                                                                                                      EvalContext context = mock(EvalContext.class);
                                                                                                      
                                                                                                      // Create a concrete subclass or use a spy for the abstract class
                                                                                                      CoreOperationCompare comparator = new CoreOperationCompare(expr1, expr2, true) {
                                                                                                          @Override
                                                                                                          protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                              return true; // Mock the equal method to return true
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          public String getSymbol() {
                                                                                                              return "=="; // Implement the abstract method
                                                                                                          }
                                                                                                      };
                                                                                                      
                                                                                                      // Execute & Verify
                                                                                                      assertEquals(Boolean.FALSE, comparator.computeValue(context));
                                                                                                  }

 @Test
                                                                                                  public void testComputeValue_WithInvertFlagTrue_UnequalExpressionsReturnsTrue() {
                                                                                                      // Setup
                                                                                                      Expression expr1 = mock(Expression.class);
                                                                                                      Expression expr2 = mock(Expression.class);
                                                                                                      EvalContext context = mock(EvalContext.class);
                                                                                                      
                                                                                                      // Create a spy of CoreOperationCompare to test the protected method
                                                                                                      CoreOperationCompare comparator = spy(new CoreOperationCompare(expr1, expr2, true) {
                                                                                                          @Override
                                                                                                          public Object computeValue(EvalContext context) {
                                                                                                              return super.computeValue(context);
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                              return false; // Simulate unequal expressions
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          public String getSymbol() {
                                                                                                              return "!="; // Implement required abstract method
                                                                                                          }
                                                                                                      });
                                                                                                      
                                                                                                      // Execute & Verify
                                                                                                      assertEquals(Boolean.TRUE, comparator.computeValue(context));
                                                                                                  }

 @Test
                                                                                                  public void testGetPrecedence_ReturnsConstantValue() throws Exception {
                                                                                                      // Create mock expressions
                                                                                                      Expression mockExpr1 = mock(Expression.class);
                                                                                                      Expression mockExpr2 = mock(Expression.class);
                                                                                                      
                                                                                                      // Create concrete subclass for testing
                                                                                                      class TestCoreOperationCompare extends CoreOperationCompare {
                                                                                                          public TestCoreOperationCompare(Expression arg1, Expression arg2, boolean invert) {
                                                                                                              super(arg1, arg2, invert);
                                                                                                          }
                                                                                                          
                                                                                                          @Override
                                                                                                          public String getSymbol() {
                                                                                                              return "test"; // Implement required abstract method
                                                                                                          }
                                                                                                      }
                                                                                                      
                                                                                                      // Test with default constructor (invert=false)
                                                                                                      TestCoreOperationCompare instance = new TestCoreOperationCompare(mockExpr1, mockExpr2, false);
                                                                                                      Method getPrecedenceMethod = CoreOperationCompare.class.getDeclaredMethod("getPrecedence");
                                                                                                      getPrecedenceMethod.setAccessible(true);
                                                                                                      assertEquals(2, getPrecedenceMethod.invoke(instance));
                                                                                                      
                                                                                                      // Test with inverted constructor
                                                                                                      TestCoreOperationCompare invertedInstance = new TestCoreOperationCompare(mockExpr1, mockExpr2, true);
                                                                                                      assertEquals(2, getPrecedenceMethod.invoke(invertedInstance));
                                                                                                  }

 @Test(expected = NullPointerException.class)
                                                                                              public void testComputeValue_NullContextThrowsException() {
                                                                                                  // Setup
                                                                                                  Expression expr1 = mock(Expression.class);
                                                                                                  Expression expr2 = mock(Expression.class);
                                                                                                  CoreOperationCompare comparator = new CoreOperationCompare(expr1, expr2) {
                                                                                                      @Override
                                                                                                      public Object computeValue(EvalContext context) {
                                                                                                          return equal(context, args[0], args[1]) ? Boolean.TRUE : Boolean.FALSE;
                                                                                                      }
                                                                                                      
                                                                                                      @Override
                                                                                                      protected int getPrecedence() {
                                                                                                          return 0;
                                                                                                      }
                                                                                                      
                                                                                                      @Override
                                                                                                      protected boolean isSymmetric() {
                                                                                                          return false;
                                                                                                      }
                                                                                                      
                                                                                                      @Override
                                                                                                      public String getSymbol() {
                                                                                                          return "==";
                                                                                                      }
                                                                                                  };
                                                                                                  
                                                                                                  // Execute
                                                                                                  comparator.computeValue(null);
                                                                                              }

 @Test
                                                                                              public void testComputeValue_NullExpressions() {
                                                                                                  // Setup
                                                                                                  Expression nullExpr = null;
                                                                                                  EvalContext context = mock(EvalContext.class);
                                                                                                  
                                                                                                  // Create anonymous implementation of abstract class
                                                                                                  CoreOperationCompare comparator = new CoreOperationCompare(nullExpr, nullExpr) {
                                                                                                      @Override
                                                                                                      public Object computeValue(EvalContext context) {
                                                                                                          return equal(context, args[0], args[1]) ? Boolean.TRUE : Boolean.FALSE;
                                                                                                      }
                                                                                                      
                                                                                                      @Override
                                                                                                      protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                          return left == null && right == null;
                                                                                                      }
                                                                                                      
                                                                                                      @Override
                                                                                                      public String getSymbol() {
                                                                                                          return "=";
                                                                                                      }
                                                                                                  };
                                                                                                  
                                                                                                  // Execute & Verify
                                                                                                  assertEquals(Boolean.TRUE, comparator.computeValue(context));
                                                                                              }

 @Test
                                                                                              public void testGetPrecedence_ConsistentAcrossMultipleCalls() throws Exception {
                                                                                                  // Create mock expressions for constructor
                                                                                                  Expression arg1 = mock(Expression.class);
                                                                                                  Expression arg2 = mock(Expression.class);
                                                                                                  
                                                                                                  // Create concrete subclass for testing
                                                                                                  class TestOperationCompare extends CoreOperationCompare {
                                                                                                      public TestOperationCompare(Expression arg1, Expression arg2) {
                                                                                                          super(arg1, arg2, false);
                                                                                                      }
                                                                                                      
                                                                                                      @Override
                                                                                                      public String getSymbol() {
                                                                                                          return "test";
                                                                                                      }
                                                                                                  }
                                                                                                  
                                                                                                  // Create instance with mock expressions
                                                                                                  TestOperationCompare instance = new TestOperationCompare(arg1, arg2);
                                                                                                  
                                                                                                  // Get the getPrecedence method via reflection
                                                                                                  Method getPrecedenceMethod = CoreOperationCompare.class.getDeclaredMethod("getPrecedence");
                                                                                                  getPrecedenceMethod.setAccessible(true);
                                                                                                  
                                                                                                  // Verify multiple calls return same value
                                                                                                  assertEquals(2, getPrecedenceMethod.invoke(instance));
                                                                                                  assertEquals(2, getPrecedenceMethod.invoke(instance));
                                                                                                  assertEquals(2, getPrecedenceMethod.invoke(instance));
                                                                                              }

 @Test
                                                                                              public void testGetPrecedence_MatchesComparisonOperationExpectation() throws Exception {
                                                                                                  // Verify the precedence is appropriate for comparison operations
                                                                                                  // Typically comparison operators have higher precedence than logical operators
                                                                                                  // but lower than arithmetic operators
                                                                                                  Expression arg1 = mock(Expression.class);
                                                                                                  Expression arg2 = mock(Expression.class);
                                                                                                  
                                                                                                  // Create concrete subclass for testing
                                                                                                  CoreOperationCompare instance = new CoreOperationCompare(arg1, arg2) {
                                                                                                      public Object computeValue(EvalContext context) {
                                                                                                          return null; // Not needed for this test
                                                                                                      }
                                                                                                      public String getSymbol() {
                                                                                                          return "=="; // Dummy implementation for test
                                                                                                      }
                                                                                                  };
                                                                                                  
                                                                                                  // Use reflection to access protected method
                                                                                                  Method getPrecedenceMethod = CoreOperationCompare.class.getDeclaredMethod("getPrecedence");
                                                                                                  getPrecedenceMethod.setAccessible(true);
                                                                                                  int precedence = (int) getPrecedenceMethod.invoke(instance);
                                                                                                  
                                                                                                  assertTrue(precedence > 1); // Should be higher than logical OR
                                                                                                  assertTrue(precedence < 3); // Should be lower than arithmetic
                                                                                              }

 @Test
                                                                                          public void testEqual_WithPointers() throws Exception {
                                                                                              // Create mock Pointer objects
                                                                                              Pointer pointerA = mock(Pointer.class);
                                                                                              Pointer pointerB = mock(Pointer.class);
                                                                                              
                                                                                              // Create mock expressions for comparator
                                                                                              Expression expr1 = mock(Expression.class);
                                                                                              Expression expr2 = mock(Expression.class);
                                                                                              
                                                                                              // Create concrete subclass of CoreOperationCompare for testing
                                                                                              class TestComparator extends CoreOperationCompare {
                                                                                                  public TestComparator(Expression arg1, Expression arg2) {
                                                                                                      super(arg1, arg2);
                                                                                                  }
                                                                                                  
                                                                                                  public TestComparator(Expression arg1, Expression arg2, boolean invert) {
                                                                                                      super(arg1, arg2, invert);
                                                                                                  }
                                                                                                  
                                                                                                  // Implement abstract method
                                                                                                  public String getSymbol() {
                                                                                                      return "==";
                                                                                                  }
                                                                                                  
                                                                                                  // Expose protected method for testing
                                                                                                  public boolean testEqual(Object l, Object r) {
                                                                                                      return equal(l, r);
                                                                                                  }
                                                                                              }
                                                                                              
                                                                                              // Create comparators
                                                                                              TestComparator comparator = new TestComparator(expr1, expr2);
                                                                                              TestComparator invertedComparator = new TestComparator(expr1, expr2, true);
                                                                                              
                                                                                              // Set up mock Pointer values
                                                                                              when(pointerA.getValue()).thenReturn(10);
                                                                                              when(pointerB.getValue()).thenReturn(10);
                                                                                              
                                                                                              // Test equal comparison
                                                                                              assertTrue(comparator.testEqual(pointerA, pointerB));
                                                                                              assertFalse(invertedComparator.testEqual(pointerA, pointerB));
                                                                                              
                                                                                              // Change pointerB value and test again
                                                                                              when(pointerB.getValue()).thenReturn(20);
                                                                                              assertFalse(comparator.testEqual(pointerA, pointerB));
                                                                                              assertTrue(invertedComparator.testEqual(pointerA, pointerB));
                                                                                          }

 @Test
                                                                                          public void testEqual_WithNumbers() throws Exception {
                                                                                              // Create test expressions with all required methods
                                                                                              Expression leftExpr = new Expression() {
                                                                                                  public Object computeValue(EvalContext context) { return null; }
                                                                                                  public Object compute(EvalContext context) { return null; }
                                                                                                  public boolean computeContextDependent() { return false; }
                                                                                              };
                                                                                              Expression rightExpr = new Expression() {
                                                                                                  public Object computeValue(EvalContext context) { return null; }
                                                                                                  public Object compute(EvalContext context) { return null; }
                                                                                                  public boolean computeContextDependent() { return false; }
                                                                                              };
                                                                                              
                                                                                              // Create concrete comparator subclass for testing
                                                                                              class TestComparator extends CoreOperationCompare {
                                                                                                  public TestComparator(Expression left, Expression right) {
                                                                                                      super(left, right);
                                                                                                  }
                                                                                                  public TestComparator(Expression left, Expression right, boolean invert) {
                                                                                                      super(left, right, invert);
                                                                                                  }
                                                                                                  public String getSymbol() {
                                                                                                      return "=";
                                                                                                  }
                                                                                              }
                                                                                              
                                                                                              // Create comparators
                                                                                              TestComparator comparator = new TestComparator(leftExpr, rightExpr);
                                                                                              TestComparator invertedComparator = new TestComparator(leftExpr, rightExpr, true);
                                                                                              
                                                                                              // Get access to protected equal method via reflection
                                                                                              Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                              equalMethod.setAccessible(true);
                                                                                              
                                                                                              // Equal numbers
                                                                                              assertTrue((Boolean)equalMethod.invoke(comparator, 5, 5));
                                                                                              assertTrue((Boolean)equalMethod.invoke(comparator, 5.0, 5));
                                                                                              assertTrue((Boolean)equalMethod.invoke(comparator, 5, 5.0f));
                                                                                              
                                                                                              // Unequal numbers
                                                                                              assertFalse((Boolean)equalMethod.invoke(comparator, 5, 6));
                                                                                              assertFalse((Boolean)equalMethod.invoke(comparator, 5.1, 5));
                                                                                              
                                                                                              // Test with inversion
                                                                                              assertFalse((Boolean)equalMethod.invoke(invertedComparator, 5, 5));
                                                                                              assertTrue((Boolean)equalMethod.invoke(invertedComparator, 5, 6));
                                                                                              
                                                                                              // NaN cases
                                                                                              assertFalse((Boolean)equalMethod.invoke(comparator, Double.NaN, 5));
                                                                                              assertFalse((Boolean)equalMethod.invoke(comparator, 5, Double.NaN));
                                                                                              assertFalse((Boolean)equalMethod.invoke(comparator, Double.NaN, Double.NaN));
                                                                                          }

 @Test
                                                                                          public void testEqual_WithStrings() {
                                                                                              // Create concrete subclass for testing
                                                                                              class TestComparator extends CoreOperationCompare {
                                                                                                  public TestComparator(Expression arg1, Expression arg2) {
                                                                                                      super(arg1, arg2);
                                                                                                  }
                                                                                                  
                                                                                                  public TestComparator(Expression arg1, Expression arg2, boolean invert) {
                                                                                                      super(arg1, arg2, invert);
                                                                                                  }
                                                                                                  
                                                                                                  // Implement required abstract method
                                                                                                  public String getSymbol() {
                                                                                                      return "==";
                                                                                                  }
                                                                                                  
                                                                                                  // Expose protected method for testing
                                                                                                  public boolean testEqual(Object l, Object r) {
                                                                                                      return equal(l, r);
                                                                                                  }
                                                                                              }
                                                                                              
                                                                                              // Create comparators
                                                                                              TestComparator comparator = new TestComparator(null, null);
                                                                                              TestComparator invertedComparator = new TestComparator(null, null, true);
                                                                                              
                                                                                              try {
                                                                                                  // Set invert field for invertedComparator (in case constructor doesn't set it)
                                                                                                  Field invertField = CoreOperationCompare.class.getDeclaredField("invert");
                                                                                                  invertField.setAccessible(true);
                                                                                                  invertField.setBoolean(invertedComparator, true);
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to set invert field: " + e.getMessage());
                                                                                              }
                                                                                              
                                                                                              // String comparisons
                                                                                              assertTrue(comparator.testEqual("test", "test"));
                                                                                              assertFalse(comparator.testEqual("test", "TEST"));
                                                                                              assertTrue(comparator.testEqual("123", 123)); // String and number
                                                                                              
                                                                                              // Test with inversion
                                                                                              assertFalse(invertedComparator.testEqual("test", "test"));
                                                                                              assertTrue(invertedComparator.testEqual("test", "TEST"));
                                                                                          }

 @Test
                                                                                          public void testEqual_WithNullValues() throws Exception {
                                                                                              // Create mock expressions for constructor
                                                                                              Expression arg1 = mock(Expression.class);
                                                                                              Expression arg2 = mock(Expression.class);
                                                                                              
                                                                                              // Create anonymous subclass to make CoreOperationCompare concrete
                                                                                              CoreOperationCompare comparator = new CoreOperationCompare(arg1, arg2, false) {
                                                                                                  @Override
                                                                                                  public Object computeValue(EvalContext context) {
                                                                                                      return null; // Not used in this test
                                                                                                  }
                                                                                                  
                                                                                                  @Override
                                                                                                  public String getSymbol() {
                                                                                                      return "=";
                                                                                                  }
                                                                                              };
                                                                                              
                                                                                              CoreOperationCompare invertedComparator = new CoreOperationCompare(arg1, arg2, true) {
                                                                                                  @Override
                                                                                                  public Object computeValue(EvalContext context) {
                                                                                                      return null; // Not used in this test
                                                                                                  }
                                                                                                  
                                                                                                  @Override
                                                                                                  public String getSymbol() {
                                                                                                      return "!=";
                                                                                                  }
                                                                                              };
                                                                                              
                                                                                              // Get the protected equal method via reflection
                                                                                              Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                              equalMethod.setAccessible(true);
                                                                                              
                                                                                              // Null comparisons
                                                                                              assertTrue((Boolean)equalMethod.invoke(comparator, null, null));
                                                                                              assertFalse((Boolean)equalMethod.invoke(comparator, null, "test"));
                                                                                              assertFalse((Boolean)equalMethod.invoke(comparator, "test", null));
                                                                                              
                                                                                              // Test with inversion
                                                                                              assertFalse((Boolean)equalMethod.invoke(invertedComparator, null, null));
                                                                                              assertTrue((Boolean)equalMethod.invoke(invertedComparator, null, "test"));
                                                                                          }

 @Test
                                                                                          public void testEqual_WithMixedTypes() throws Exception {
                                                                                              // Create mock expressions for constructor
                                                                                              Expression mockExpr1 = mock(Expression.class);
                                                                                              Expression mockExpr2 = mock(Expression.class);
                                                                                              
                                                                                              // Create anonymous subclass to test abstract class
                                                                                              CoreOperationCompare comparator = new CoreOperationCompare(mockExpr1, mockExpr2) {
                                                                                                  public Object computeValue(EvalContext context) { return null; }
                                                                                                  protected int getPrecedence() { return 0; }
                                                                                                  protected boolean isSymmetric() { return false; }
                                                                                                  public String getSymbol() { return "="; }
                                                                                              };
                                                                                              
                                                                                              CoreOperationCompare invertedComparator = new CoreOperationCompare(mockExpr1, mockExpr2, true) {
                                                                                                  public Object computeValue(EvalContext context) { return null; }
                                                                                                  protected int getPrecedence() { return 0; }
                                                                                                  protected boolean isSymmetric() { return false; }
                                                                                                  public String getSymbol() { return "="; }
                                                                                              };
                                                                                              
                                                                                              // Get access to protected equal method
                                                                                              Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                              equalMethod.setAccessible(true);
                                                                                              
                                                                                              // Mixed type comparisons
                                                                                              assertTrue((Boolean)equalMethod.invoke(comparator, "true", true));
                                                                                              assertTrue((Boolean)equalMethod.invoke(comparator, "1", 1));
                                                                                              assertFalse((Boolean)equalMethod.invoke(comparator, "1", 2));
                                                                                              
                                                                                              // Test with inversion
                                                                                              assertFalse((Boolean)equalMethod.invoke(invertedComparator, "true", true));
                                                                                              assertTrue((Boolean)equalMethod.invoke(invertedComparator, "1", 2));
                                                                                          }

 @Test
                                                                                          public void testEqual_WithObjects() throws Exception {
                                                                                              // Create mock expressions since CoreOperationCompare requires them
                                                                                              Expression mockExpr1 = mock(Expression.class);
                                                                                              Expression mockExpr2 = mock(Expression.class);
                                                                                              
                                                                                              // Create concrete subclass to test protected methods
                                                                                              class TestComparator extends CoreOperationCompare {
                                                                                                  public TestComparator(Expression arg1, Expression arg2) {
                                                                                                      super(arg1, arg2);
                                                                                                  }
                                                                                                  
                                                                                                  public TestComparator(Expression arg1, Expression arg2, boolean invert) {
                                                                                                      super(arg1, arg2, invert);
                                                                                                  }
                                                                                                  
                                                                                                  // Implement abstract method
                                                                                                  public String getSymbol() {
                                                                                                      return "==";
                                                                                                  }
                                                                                                  
                                                                                                  // Expose protected method for testing
                                                                                                  public boolean testEqual(Object l, Object r) {
                                                                                                      return equal(l, r);
                                                                                                  }
                                                                                              }
                                                                                              
                                                                                              // Create normal and inverted comparators
                                                                                              TestComparator comparator = new TestComparator(mockExpr1, mockExpr2);
                                                                                              TestComparator invertedComparator = new TestComparator(mockExpr1, mockExpr2, true);
                                                                                              
                                                                                              Object obj1 = new Object();
                                                                                              Object obj2 = new Object();
                                                                                              
                                                                                              // Same object reference
                                                                                              assertTrue(comparator.testEqual(obj1, obj1));
                                                                                              // Different objects
                                                                                              assertFalse(comparator.testEqual(obj1, obj2));
                                                                                              
                                                                                              // Test with inversion
                                                                                              assertFalse(invertedComparator.testEqual(obj1, obj1));
                                                                                              assertTrue(invertedComparator.testEqual(obj1, obj2));
                                                                                          }

 @Test
                                                                                          public void testComputeValue_EqualExpressionsReturnsTrue() {
                                                                                              // Setup
                                                                                              Expression expr1 = mock(Expression.class);
                                                                                              Expression expr2 = mock(Expression.class);
                                                                                              EvalContext context = mock(EvalContext.class);
                                                                                              
                                                                                              // Create concrete subclass of CoreOperationCompare
                                                                                              CoreOperationCompare comparator = new CoreOperationCompare(expr1, expr2) {
                                                                                                  @Override
                                                                                                  public Object computeValue(EvalContext context) {
                                                                                                      return super.computeValue(context);
                                                                                                  }
                                                                                                  
                                                                                                  @Override
                                                                                                  public String getSymbol() {
                                                                                                      return "==";
                                                                                                  }
                                                                                              };
                                                                                              
                                                                                              // Mock the protected equal method using reflection
                                                                                              try {
                                                                                                  Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                                      "equal", EvalContext.class, Expression.class, Expression.class);
                                                                                                  equalMethod.setAccessible(true);
                                                                                                  
                                                                                                  // Mock the behavior of equal method to return true
                                                                                                  CoreOperationCompare spyComparator = spy(comparator);
                                                                                                  when(equalMethod.invoke(spyComparator, context, expr1, expr2)).thenReturn(true);
                                                                                                  
                                                                                                  // Execute & Verify
                                                                                                  assertEquals(Boolean.TRUE, spyComparator.computeValue(context));
                                                                                              } catch (Exception e) {
                                                                                                  fail("Reflection failed: " + e.getMessage());
                                                                                              }
                                                                                          }

 @Test
                                                                                          public void testComputeValue_UnequalExpressionsReturnsFalse() {
                                                                                              // Setup
                                                                                              Expression expr1 = mock(Expression.class);
                                                                                              Expression expr2 = mock(Expression.class);
                                                                                              EvalContext context = mock(EvalContext.class);
                                                                                              
                                                                                              // Create concrete subclass for testing
                                                                                              CoreOperationCompare comparator = new CoreOperationCompare(expr1, expr2) {
                                                                                                  @Override
                                                                                                  public Object computeValue(EvalContext context) {
                                                                                                      return super.computeValue(context);
                                                                                                  }
                                                                                                  
                                                                                                  @Override
                                                                                                  protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                      return false; // Mock unequal comparison
                                                                                                  }
                                                                                                  
                                                                                                  @Override
                                                                                                  public String getSymbol() {
                                                                                                      return "!="; // Implement abstract method
                                                                                                  }
                                                                                              };
                                                                                              
                                                                                              CoreOperationCompare spyComparator = spy(comparator);
                                                                                              
                                                                                              // Setup mock behavior
                                                                                              doCallRealMethod().when(spyComparator).computeValue(context);
                                                                                              
                                                                                              // Execute & Verify
                                                                                              assertEquals(Boolean.FALSE, spyComparator.computeValue(context));
                                                                                          }

 @Test
                                                                                          public void testEqual_WithNullValues1() {
                                                                                              Expression left = mock(Expression.class);
                                                                                              Expression right = mock(Expression.class);
                                                                                              EvalContext context = mock(EvalContext.class);
                                                                                              
                                                                                              when(left.compute(context)).thenReturn(null);
                                                                                              when(right.compute(context)).thenReturn(null);
                                                                                              
                                                                                              CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                                                                  @Override
                                                                                                  public Object computeValue(EvalContext context) {
                                                                                                      return equal(context, left, right);
                                                                                                  }
                                                                                                  
                                                                                                  @Override
                                                                                                  protected int getPrecedence() {
                                                                                                      return 0;
                                                                                                  }
                                                                                                  
                                                                                                  @Override
                                                                                                  protected boolean isSymmetric() {
                                                                                                      return true;
                                                                                                  }
                                                                                                  
                                                                                                  @Override
                                                                                                  public String getSymbol() {
                                                                                                      return "==";
                                                                                                  }
                                                                                              };
                                                                                              Boolean result = (Boolean) comparator.computeValue(context);
                                                                                              assertTrue(result);
                                                                                          }

 @Test
                                                                                  public void testEqual_BasicObjects() {
                                                                                      Expression left = mock(Expression.class);
                                                                                      Expression right = mock(Expression.class);
                                                                                      EvalContext context = mock(EvalContext.class);
                                                                                      
                                                                                      when(left.compute(context)).thenReturn("test");
                                                                                      when(right.compute(context)).thenReturn("test");
                                                                                      
                                                                                      // Create anonymous subclass of CoreOperationCompare for testing
                                                                                      CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                                                          @Override
                                                                                          public Object computeValue(EvalContext context) {
                                                                                              return null;
                                                                                          }
                                                                                          
                                                                                          @Override
                                                                                          public String getSymbol() {
                                                                                              return "==";
                                                                                          }
                                                                                      };
                                                                                      
                                                                                      // Call protected equal method through reflection
                                                                                      try {
                                                                                          Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                              "equal", EvalContext.class, Expression.class, Expression.class);
                                                                                          equalMethod.setAccessible(true);
                                                                                          boolean result = (boolean) equalMethod.invoke(comparator, context, left, right);
                                                                                          assertTrue(result);
                                                                                      } catch (Exception e) {
                                                                                          fail("Failed to invoke equal method: " + e.getMessage());
                                                                                      }
                                                                                  }

 @Test
                                                                                  public void testEqual_WithIterators() {
                                                                                      java.util.Iterator<Object> leftIter = java.util.Arrays.asList((Object)"a", (Object)"b").iterator();
                                                                                      java.util.Iterator<Object> rightIter = java.util.Arrays.asList((Object)"a", (Object)"b").iterator();
                                                                                      
                                                                                      Expression left = mock(Expression.class);
                                                                                      Expression right = mock(Expression.class);
                                                                                      EvalContext context = mock(EvalContext.class);
                                                                                      
                                                                                      when(left.compute(context)).thenReturn(leftIter);
                                                                                      when(right.compute(context)).thenReturn(rightIter);
                                                                                      
                                                                                      // Create concrete subclass of CoreOperationCompare
                                                                                      CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                                                          @Override
                                                                                          public Object computeValue(EvalContext context) {
                                                                                              return null;
                                                                                          }
                                                                                          
                                                                                          @Override
                                                                                          public String getSymbol() {
                                                                                              return "==";
                                                                                          }
                                                                                      };
                                                                                      
                                                                                      // Use reflection to access protected equal() method
                                                                                      try {
                                                                                          Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                              "equal", EvalContext.class, Expression.class, Expression.class);
                                                                                          equalMethod.setAccessible(true);
                                                                                          boolean result = (boolean) equalMethod.invoke(comparator, context, left, right);
                                                                                          assertTrue(result);
                                                                                      } catch (Exception e) {
                                                                                          fail("Failed to invoke equal method: " + e.getMessage());
                                                                                      }
                                                                                  }

 @Test
                                                                              public void testEqual_WithBooleans() throws Exception {
                                                                                  // Create mock expressions for the comparator constructor
                                                                                  Expression arg1 = mock(Expression.class);
                                                                                  Expression arg2 = mock(Expression.class);
                                                                                  
                                                                                  // Create concrete subclass to test protected methods
                                                                                  class TestComparator extends CoreOperationCompare {
                                                                                      public TestComparator(Expression arg1, Expression arg2) {
                                                                                          super(arg1, arg2);
                                                                                      }
                                                                                      
                                                                                      public TestComparator(Expression arg1, Expression arg2, boolean invert) {
                                                                                          super(arg1, arg2, invert);
                                                                                      }
                                                                                      
                                                                                      public boolean testEqual(Object l, Object r) {
                                                                                          return equal(l, r);
                                                                                      }
                                                                                      
                                                                                      @Override
                                                                                      public String getSymbol() {
                                                                                          return "==";
                                                                                      }
                                                                                  }
                                                                                  
                                                                                  // Create normal and inverted comparators
                                                                                  TestComparator comparator = new TestComparator(arg1, arg2);
                                                                                  TestComparator invertedComparator = new TestComparator(arg1, arg2, true);
                                                                                  
                                                                                  // Boolean comparisons
                                                                                  assertTrue(comparator.testEqual(true, true));
                                                                                  assertFalse(comparator.testEqual(true, false));
                                                                                  assertTrue(comparator.testEqual(Boolean.TRUE, true));
                                                                                  assertTrue(comparator.testEqual(Boolean.FALSE, false));
                                                                                  
                                                                                  // Test with inversion
                                                                                  assertFalse(invertedComparator.testEqual(true, true));
                                                                                  assertTrue(invertedComparator.testEqual(true, false));
                                                                              }

 @Test
                                                                      public void testEqual_WithInitialContext() {
                                                                          Expression left = mock(Expression.class);
                                                                          Expression right = mock(Expression.class);
                                                                          EvalContext context = mock(EvalContext.class);
                                                                          EvalContext initialContext = mock(EvalContext.class);
                                                                          
                                                                          when(left.compute(context)).thenReturn("value");
                                                                          when(right.compute(context)).thenReturn("value");
                                                                          
                                                                          // Create concrete subclass of CoreOperationCompare
                                                                          CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                                              @Override
                                                                              public Object computeValue(EvalContext context) {
                                                                                  return Boolean.TRUE;
                                                                              }
                                                                              
                                                                              @Override
                                                                              protected int getPrecedence() {
                                                                                  return 0;
                                                                              }
                                                                              
                                                                              @Override
                                                                              protected boolean isSymmetric() {
                                                                                  return false;
                                                                              }
                                                                              
                                                                              @Override
                                                                              public String getSymbol() {
                                                                                  return "==";
                                                                              }
                                                                          };
                                                                          
                                                                          // Call protected equal method through reflection
                                                                          try {
                                                                              Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                                  "equal", EvalContext.class, Expression.class, Expression.class);
                                                                              equalMethod.setAccessible(true);
                                                                              boolean result = (boolean) equalMethod.invoke(comparator, context, left, right);
                                                                              
                                                                              // Verify the context reset was called
                                                                              verify(initialContext).reset();
                                                                          } catch (Exception e) {
                                                                              fail("Reflection failed: " + e.getMessage());
                                                                          }
                                                                      }

 @Test
                                                                      public void testEqual_WithCollections() {
                                                                          // Create mock objects
                                                                          Expression left = mock(Expression.class);
                                                                          Expression right = mock(Expression.class);
                                                                          EvalContext context = mock(EvalContext.class);
                                                                          
                                                                          // Create test lists
                                                                          java.util.List<Object> leftList = java.util.Arrays.asList("a", "b");
                                                                          java.util.List<Object> rightList = java.util.Arrays.asList("a", "b");
                                                                          
                                                                          // Set up mock behavior
                                                                          when(left.compute(context)).thenReturn(leftList);
                                                                          when(right.compute(context)).thenReturn(rightList);
                                                                          
                                                                          // Create a concrete subclass of CoreOperationCompare to test
                                                                          CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                                              @Override
                                                                              protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                  Object l = left.compute(context);
                                                                                  Object r = right.compute(context);
                                                                                  return equal(l, r);
                                                                              }
                                                                              
                                                                              @Override
                                                                              public String getSymbol() {
                                                                                  return "==";
                                                                              }
                                                                              
                                                                              @Override
                                                                              protected boolean equal(Object l, Object r) {
                                                                                  if (l instanceof java.util.Collection && r instanceof java.util.Collection) {
                                                                                      return ((java.util.Collection<?>) l).containsAll((java.util.Collection<?>) r) && 
                                                                                             ((java.util.Collection<?>) r).containsAll((java.util.Collection<?>) l);
                                                                                  }
                                                                                  return super.equal(l, r);
                                                                              }
                                                                          };
                                                                          
                                                                          // Call the equal method with correct parameters
                                                                      }

 @Test
                                                          public void testEqual_WithDifferentValues() {
                                                              Expression left = mock(Expression.class);
                                                              Expression right = mock(Expression.class);
                                                              EvalContext context = mock(EvalContext.class);
                                                              
                                                              when(left.compute(context)).thenReturn("value1");
                                                              when(right.compute(context)).thenReturn("value2");
                                                              
                                                              // Create concrete subclass for testing
                                                              CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                                  @Override
                                                                  public Object computeValue(EvalContext context) {
                                                                      return null;
                                                                  }
                                                                  
                                                                  @Override
                                                                  public String getSymbol() {
                                                                      return "==";
                                                                  }
                                                              };
                                                              
                                                              // Use reflection to access protected equal method
                                                              try {
                                                                  Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                      "equal", EvalContext.class, Expression.class, Expression.class);
                                                                  equalMethod.setAccessible(true);
                                                                  boolean result = (boolean) equalMethod.invoke(comparator, context, left, right);
                                                                  assertFalse(result);
                                                              } catch (Exception e) {
                                                                  fail("Failed to invoke equal method: " + e.getMessage());
                                                              }
                                                          }

 @Test
                                      public void testEqual_WithMixedTypes1() throws Exception {
                                          // Initialize mocks
                                          Expression left = mock(Expression.class);
                                          Expression right = mock(Expression.class);
                                          EvalContext context = mock(EvalContext.class);
                                          
                                          // Setup test values
                                          Object leftValue = "a";
                                          Object rightValue = "a";
                                          Iterator<Object> leftIter = java.util.Collections.singletonList(leftValue).iterator();
                                          
                                          // Configure mocks
                                          when(left.compute(context)).thenReturn(leftIter);
                                          when(right.compute(context)).thenReturn(rightValue);
                                          
                                          // Create concrete subclass for testing
                                          CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                              public Object computeValue(EvalContext context) {
                                                  Iterator<?> leftIter = (Iterator<?>) left.compute(context);
                                                  Object rightValue = right.compute(context);
                                                  try {
                                                      Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                          "equal", EvalContext.class, Expression.class, Expression.class);
                                                      equalMethod.setAccessible(true);
                                                      return equalMethod.invoke(this, context, left, right);
                                                  } catch (Exception e) {
                                                      throw new RuntimeException(e);
                                                  }
                                              }
                                              public String getSymbol() {
                                                  return "==";
                                              }
                                              protected int getPrecedence() {
                                                  return 0;
                                              }
                                              protected boolean isSymmetric() {
                                                  return true;
                                              }
                                          };
                                          
                                          // Access protected equal method via reflection
                                          java.lang.reflect.Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                              "equal", EvalContext.class, Expression.class, Expression.class);
                                          equalMethod.setAccessible(true);
                                          boolean result = (boolean) equalMethod.invoke(comparator, context, left, right);
                                          
                                          assertTrue(result);
                                      }

 @Test
                              public void testEqual_WithEmptyCollections() {
                                  // Mock setup
                                  Expression left = mock(Expression.class);
                                  Expression right = mock(Expression.class);
                                  EvalContext context = mock(EvalContext.class);
                                  
                                  
                                  // Create concrete subclass to test the abstract class
                                  CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                      @Override
                                      public Object computeValue(EvalContext context) {
                                          return super.computeValue(context);
                                      }
                                  
                                      @Override
                                      public String getSymbol() {
                                          return "==";
                                      }
                                  
                                      @Override
                                      protected int getPrecedence() {
                                          return 0;
                                      }
                                  
                                      @Override
                                      protected boolean isSymmetric() {
                                          return true;
                                      }
                                      
                                      @Override
                                      protected boolean equal(EvalContext context, Expression left, Expression right) {
                                          return super.equal(context, left, right);
                                      }
                                  };
                                  
                                  // Use computeValue instead of directly calling equal
                                  Object result = comparator.computeValue(context);
                                  assertTrue("Empty collections should be considered equal", (Boolean) result);
                              }

 @Test
                          public void testEqual_WithSelfContext() throws Exception {
                              // Mock all necessary objects
                              org.apache.commons.jxpath.ri.compiler.Expression left = mock(org.apache.commons.jxpath.ri.compiler.Expression.class);
                              org.apache.commons.jxpath.ri.compiler.Expression right = mock(org.apache.commons.jxpath.ri.compiler.Expression.class);
                              EvalContext context = mock(EvalContext.class);
                              
                              // Set up mock behavior
                              org.apache.commons.jxpath.ri.compiler.CoreOperationCompare comparator = new org.apache.commons.jxpath.ri.compiler.CoreOperationCompare(left, right) {
                                  @Override
                                  public Object computeValue(EvalContext context) {
                                      return equal(context, left, right);
                                  }
                                  
                                  @Override
                                  protected int getPrecedence() {
                                      return 0;
                                  }
                                  
                                  @Override
                                  protected boolean isSymmetric() {
                                      return false;
                                  }
                                  
                                  @Override
                                  public String getSymbol() {
                                      return "==";
                                  }
                              };
                              
                              // Use reflection to access protected equal method
                              try {
                                  Method equalMethod = org.apache.commons.jxpath.ri.compiler.CoreOperationCompare.class.getDeclaredMethod(
                                      "equal", EvalContext.class, Expression.class, Expression.class);
                                  equalMethod.setAccessible(true);
                                  boolean result = (boolean) equalMethod.invoke(comparator, context, left, right);
                                  
                                  // Assert based on mock setup
                                  assertFalse(result); // Since we didn't set up mock behavior, default should be false
                              } catch (Exception e) {
                                  fail("Failed to invoke protected equal method: " + e.getMessage());
                              }
                          }

 @Test
                      public void testComputeValue_OneNullExpression() {
                          // Setup
                          Expression nullExpr = null;
                          Expression expr2 = mock(Expression.class);
                          EvalContext context = mock(EvalContext.class);
                          
                          // Create a spy of CoreOperationCompare since it's abstract
                          CoreOperationCompare comparator = spy(new CoreOperationCompare(nullExpr, expr2) {
                              @Override
                              public Object computeValue(EvalContext context) {
                                  return Boolean.FALSE; // Added return statement
                              }
                              
                              @Override
                              protected boolean equal(EvalContext context, Expression left, Expression right) {
                                  return false; // default implementation for test
                              }
                              
                              @Override
                              public String getSymbol() {
                                  return "=="; // dummy implementation for test
                              }
                              
                              @Override
                              protected int getPrecedence() {
                                  return 0; // dummy implementation
                              }
                              
                              @Override
                              protected boolean isSymmetric() {
                                  return false; // dummy implementation
                              }
                          });
                          
                          // Execute & Verify
                          assertEquals(Boolean.FALSE, comparator.computeValue(context));
                      }

 @Test
                      public void testEqual_WithDifferentSizedCollections() {
                          // Create mocks
                          Expression left = mock(Expression.class);
                          Expression right = mock(Expression.class);
                          EvalContext context = mock(EvalContext.class);
                          
                          // Create test data
                          List<Object> list1 = java.util.Arrays.asList("a");
                          List<Object> list2 = java.util.Arrays.asList("a", "b");
                          
                          // Setup mock behavior
                          when(left.compute(context)).thenReturn(list1);
                          when(right.compute(context)).thenReturn(list2);
                          
                          // Create concrete subclass for testing
                          CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                              @Override
                              public Object computeValue(EvalContext context) {
                                  Object leftValue = left.compute(context);
                                  Object rightValue = right.compute(context);
                                  return equal(context, leftValue, rightValue);
                              }
                              
                              @Override
                              protected int getPrecedence() {
                                  return 0;
                              }
                              
                              @Override
                              protected boolean isSymmetric() {
                                  return false;
                              }
                              
                              @Override
                              public String getSymbol() {
                                  return "==";
                              }
                              
                              protected boolean equal(EvalContext context, Object left, Object right) {
                                  if (left instanceof Collection && right instanceof Collection) {
                                      Collection<?> leftCol = (Collection<?>) left;
                                      Collection<?> rightCol = (Collection<?>) right;
                                      if (leftCol.size() != rightCol.size()) {
                                          return false;
                                      }
                                      // For this test, we just need to handle different sizes
                                      return false;
                                  }
                                  return left.equals(right);
                              }
                          };
                          
                          // Test the equal method
                          assertFalse((Boolean)comparator.computeValue(context));
                      }

}
