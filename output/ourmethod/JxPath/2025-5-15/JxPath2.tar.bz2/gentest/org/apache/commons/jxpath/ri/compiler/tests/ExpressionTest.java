package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
import org.apache.commons.jxpath.NodeSet;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.util.ValueUtils;
import java.util.Collections;
import java.util.Iterator;
import java.util.Locale;
 
public class ExpressionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                       public void testIterate_WithOtherTypeResult() {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                                                                           Object result = "testValue";
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(result);
                                                                                                                                                                                                                                                           when(expression.iterate(context)).thenCallRealMethod();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                           Iterator<?> iterator = expression.iterate(context);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertNotNull(iterator);
                                                                                                                                                                                                                                                           // ValueUtils.iterate should handle the conversion
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testIterate_WithNullResult() {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(null);
                                                                                                                                                                                                                                                           when(expression.iterate(context)).thenCallRealMethod();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                           Iterator<?> iterator = expression.iterate(context);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertNotNull(iterator);
                                                                                                                                                                                                                                                           assertFalse(iterator.hasNext());
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testIterate_WithPrimitiveTypeResult() {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                                                                           int primitiveResult = 42;
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(primitiveResult);
                                                                                                                                                                                                                                                           when(expression.iterate(context)).thenCallRealMethod();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                           Iterator<?> iterator = expression.iterate(context);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertNotNull(iterator);
                                                                                                                                                                                                                                                           assertTrue(iterator.hasNext());
                                                                                                                                                                                                                                                           assertEquals(42, iterator.next());
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testIterate_WithCollectionResult() {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                                                                           java.util.List<String> collectionResult = java.util.Arrays.asList("a", "b", "c");
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(collectionResult);
                                                                                                                                                                                                                                                           when(expression.iterate(context)).thenCallRealMethod();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                           Iterator<?> iterator = expression.iterate(context);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertNotNull(iterator);
                                                                                                                                                                                                                                                           assertTrue(iterator.hasNext());
                                                                                                                                                                                                                                                           assertEquals("a", iterator.next());
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testIterate_WithArrayResult() {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                                                                           String[] arrayResult = {"x", "y", "z"};
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(arrayResult);
                                                                                                                                                                                                                                                           when(expression.iterate(context)).thenCallRealMethod();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                           Iterator<?> iterator = expression.iterate(context);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertNotNull(iterator);
                                                                                                                                                                                                                                                           assertTrue(iterator.hasNext());
                                                                                                                                                                                                                                                           assertEquals("x", iterator.next());
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testIteratePointers_WhenComputeReturnsNull() {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(null);
                                                                                                                                                                                                                                                           when(expression.iteratePointers(context)).thenCallRealMethod();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                           Iterator result = expression.iteratePointers(context);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertSame(Collections.EMPTY_LIST.iterator(), result);
                                                                                                                                                                                                                                                           assertFalse(result.hasNext());
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                       public void testIteratePointers_WhenComputeReturnsEvalContext() {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                                                                           EvalContext evalContextResult = mock(EvalContext.class);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(evalContextResult);
                                                                                                                                                                                                                                                           when(expression.iteratePointers(context)).thenCallRealMethod();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                           Iterator result = expression.iteratePointers(context);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertSame(evalContextResult, result);
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testIterate_WithEvalContextResult() {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                           EvalContext resultContext = mock(EvalContext.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(resultContext);
                                                                                                                                                                                                           when(expression.iterate(context)).thenCallRealMethod();
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                           Iterator<?> iterator = expression.iterate(context);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                           assertNotNull(iterator);
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testIterate_WithNodeSetResult() {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                           NodeSet nodeSet = mock(NodeSet.class);
                                                                                                                                                                                                           @SuppressWarnings("unchecked")
                                                                                                                                                                                                           Iterator<Pointer> pointersIterator = mock(Iterator.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(nodeSet);
                                                                                                                                                                                                           when(expression.iterate(context)).thenCallRealMethod();
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                           Iterator<?> iterator = expression.iterate(context);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                           assertNotNull(iterator);
                                                                                                                                                                                                           assertTrue(iterator instanceof Iterator); // Changed from ValueIterator to more generic Iterator
                                                                                                                                                                                                           verify(nodeSet).getPointers();
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testIteratePointers_WhenComputeReturnsNodeSet() {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                           NodeSet nodeSet = mock(NodeSet.class);
                                                                                                                                                                                                           NodePointer rootPointer = mock(NodePointer.class);
                                                                                                                                                                                                           EvalContext rootContext = mock(EvalContext.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(nodeSet);
                                                                                                                                                                                                           when(expression.iteratePointers(context)).thenCallRealMethod();
                                                                                                                                                                                                           when(rootContext.getCurrentNodePointer()).thenReturn(rootPointer);
                                                                                                                                                                                                           when(rootPointer.getLocale()).thenReturn(null);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Mock NodeSet behavior
                                                                                                                                                                                                           NodePointer mockPointer = mock(NodePointer.class);
                                                                                                                                                                                                           List<NodePointer> pointersList = Collections.singletonList(mockPointer);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                           Iterator<?> result = expression.iteratePointers(context);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                           assertNotNull(result);
                                                                                                                                                                                                           assertTrue(result instanceof Iterator);
                                                                                                                                                                                                           // Can't verify exact PointerIterator instance, but can verify it's not null
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testIteratePointers_WhenComputeReturnsOtherObject() {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                           NodePointer rootPointer = mock(NodePointer.class);
                                                                                                                                                                                                           EvalContext rootContext = mock(EvalContext.class);
                                                                                                                                                                                                           Object computeResult = new Object();
                                                                                                                                                                                                           
                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(computeResult);
                                                                                                                                                                                                           when(rootContext.getCurrentNodePointer()).thenReturn(rootPointer);
                                                                                                                                                                                                           when(rootPointer.getLocale()).thenReturn(null);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Mock ValueUtils behavior
                                                                                                                                                                                                           Iterator<?> valueUtilsIter = Collections.singletonList("test").iterator();
                                                                                                                                                                                                           when(ValueUtils.iterate(computeResult)).thenReturn(valueUtilsIter);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                           Iterator<?> result = expression.iteratePointers(context);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                           assertNotNull(result);
                                                                                                                                                                                                           assertTrue(result instanceof Iterator);
                                                                                                                                                                                                           // Can't verify exact PointerIterator instance, but can verify it's not null
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testIteratePointers_WhenRootContextIsNull() {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                           Object computeResult = new Object();
                                                                                                                                                                                                           
                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(computeResult);
                                                                                                                                                                                                           when(expression.iteratePointers(context)).thenCallRealMethod();
                                                                                                                                                                                                           when(context.getRootContext()).thenReturn(null);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Expect exception
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                           expression.iteratePointers(context);
                                                                                                                                                                                                       }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                       public void testIteratePointers_WhenCurrentNodePointerIsNull() {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           Expression expression = mock(Expression.class);
                                                                                                                                                                                                           EvalContext context = mock(EvalContext.class);
                                                                                                                                                                                                           Object computeResult = new Object();
                                                                                                                                                                                                           EvalContext rootContext = mock(EvalContext.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           when(expression.compute(context)).thenReturn(computeResult);
                                                                                                                                                                                                           when(rootContext.getCurrentNodePointer()).thenReturn(null);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                           expression.iteratePointers(context);
                                                                                                                                                                                                       }

    @Test(expected = UnsupportedOperationException.class)
                                                                                                                                                                                                       public void testRemove_ShouldThrowUnsupportedOperationException() {
                                                                                                                                                                                                           // Since the class has no constructors and we're testing a method that
                                                                                                                                                                                                           // doesn't depend on any instance state, we can create an anonymous subclass
                                                                                                                                                                                                           Expression expression = new Expression() {
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public boolean isContextDependent() {
                                                                                                                                                                                                                   return false;
                                                                                                                                                                                                               }
                                                                                                                                                                                                       
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public boolean computeContextDependent() {
                                                                                                                                                                                                                   return false;
                                                                                                                                                                                                               }
                                                                                                                                                                                                       
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public Object computeValue(EvalContext context) {
                                                                                                                                                                                                                   return null;
                                                                                                                                                                                                               }
                                                                                                                                                                                                       
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public Object compute(EvalContext context) {
                                                                                                                                                                                                                   return null;
                                                                                                                                                                                                               }
                                                                                                                                                                                                       
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public Iterator iterate(EvalContext context) {
                                                                                                                                                                                                                   return new Iterator() {
                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                       public boolean hasNext() {
                                                                                                                                                                                                                           return false;
                                                                                                                                                                                                                       }
                                                                                                                                                                                                       
                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                       public Object next() {
                                                                                                                                                                                                                           return null;
                                                                                                                                                                                                                       }
                                                                                                                                                                                                       
                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                       public void remove() {
                                                                                                                                                                                                                           throw new UnsupportedOperationException();
                                                                                                                                                                                                                       }
                                                                                                                                                                                                                   };
                                                                                                                                                                                                               }
                                                                                                                                                                                                       
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public Iterator iteratePointers(EvalContext context) {
                                                                                                                                                                                                                   return null;
                                                                                                                                                                                                               }
                                                                                                                                                                                                           };
                                                                                                                                                                                                       
                                                                                                                                                                                                           // Get iterator and call remove to trigger the exception
                                                                                                                                                                                                           Iterator iterator = expression.iterate(null);
                                                                                                                                                                                                           iterator.remove();
                                                                                                                                                                                                       }

    @Test
                                                                                                                                              public void testHasNext_WhenIteratorDoesNotHaveNext_ReturnsFalse() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Expression expression = new Expression() {
                                                                                                                                                      @Override
                                                                                                                                                      public boolean computeContextDependent() {
                                                                                                                                                          return false;
                                                                                                                                                      }
                                                                                                                                                      @Override
                                                                                                                                                      public Object computeValue(EvalContext context) {
                                                                                                                                                          return null;
                                                                                                                                                      }
                                                                                                                                                      @Override
                                                                                                                                                      public Object compute(EvalContext context) {
                                                                                                                                                          return null;
                                                                                                                                                      }
                                                                                                                                                      @Override
                                                                                                                                                      public Iterator iterate(EvalContext context) {
                                                                                                                                                          Iterator<?> mockIterator = mock(Iterator.class);
                                                                                                                                                          when(mockIterator.hasNext()).thenReturn(false);
                                                                                                                                                          return mockIterator;
                                                                                                                                                      }
                                                                                                                                                      @Override
                                                                                                                                                      public Iterator iteratePointers(EvalContext context) {
                                                                                                                                                          return null;
                                                                                                                                                      }
                                                                                                                                                      @Override
                                                                                                                                                      public boolean isContextDependent() {
                                                                                                                                                          return false;
                                                                                                                                                      }
                                                                                                                                                  };
                                                                                                                                                  
                                                                                                                                                  // Create a mock context since it's required by the interface
                                                                                                                                                  EvalContext context = mock(EvalContext.class);
                                                                                                                                                  
                                                                                                                                                  // Get the iterator from the expression
                                                                                                                                                  Iterator<?> iterator = expression.iterate(context);
                                                                                                                                                  
                                                                                                                                                  // Act
                                                                                                                                                  boolean result = iterator.hasNext();
                                                                                                                                                  
                                                                                                                                                  // Assert
                                                                                                                                                  assertFalse(result);
                                                                                                                                              }

    @Test
                                                                                                                                          public void testHasNext_ReturnsIteratorState() {
                                                                                                                                              // Create mock iterator
                                                                                                                                              Iterator<?> mockIterator = mock(Iterator.class);
                                                                                                                                              EvalContext mockContext = mock(EvalContext.class);
                                                                                                                                              
                                                                                                                                              // Create concrete subclass of Expression for testing
                                                                                                                                              Expression expression = new Expression() {
                                                                                                                                                  @Override
                                                                                                                                                  public boolean computeContextDependent() {
                                                                                                                                                      return false;
                                                                                                                                                  }
                                                                                                                                              
                                                                                                                                                  @Override
                                                                                                                                                  public Object computeValue(EvalContext context) {
                                                                                                                                                      return null;
                                                                                                                                                  }
                                                                                                                                              
                                                                                                                                                  @Override
                                                                                                                                                  public Object compute(EvalContext context) {
                                                                                                                                                      return null;
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  // Implement the iterator-related methods
                                                                                                                                                  @Override
                                                                                                                                                  public Iterator<?> iterate(EvalContext context) {
                                                                                                                                                      return mockIterator;
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  @Override
                                                                                                                                                  public Iterator<?> iteratePointers(EvalContext context) {
                                                                                                                                                      return mockIterator;
                                                                                                                                                  }
                                                                                                                                              };
                                                                                                                                              
                                                                                                                                              // Test case 1: iterator has next element
                                                                                                                                              when(mockIterator.hasNext()).thenReturn(true);
                                                                                                                                              Iterator<?> testIterator = expression.iterate(mockContext);
                                                                                                                                              assertTrue("Should return true when iterator has next", testIterator.hasNext());
                                                                                                                                              
                                                                                                                                              // Test case 2: iterator has no next element
                                                                                                                                              when(mockIterator.hasNext()).thenReturn(false);
                                                                                                                                              testIterator = expression.iterate(mockContext);
                                                                                                                                              assertFalse("Should return false when iterator has no next", testIterator.hasNext());
                                                                                                                                              
                                                                                                                                              // Verify interactions
                                                                                                                                              verify(mockIterator, times(2)).hasNext();
                                                                                                                                          }

    @Test
                                                                                                                                      public void testHasNext_WhenIteratorHasNext_ReturnsTrue() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          // Create mock expression
                                                                                                                                          Expression expression = mock(Expression.class);
                                                                                                                                          // Create mock iterator
                                                                                                                                          Iterator<?> mockIterator = mock(Iterator.class);
                                                                                                                                          when(mockIterator.hasNext()).thenReturn(true);
                                                                                                                                          
                                                                                                                                          // Set up expression to return our mock iterator
                                                                                                                                          when(expression.iterate(any(EvalContext.class))).thenReturn(mockIterator);
                                                                                                                                          
                                                                                                                                          // Act - get iterator from expression and check hasNext
                                                                                                                                          Iterator<?> resultIterator = expression.iterate(mock(EvalContext.class));
                                                                                                                                          boolean result = resultIterator.hasNext();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertTrue(result);
                                                                                                                                      }

    @Test
                                                                                                                         public void testHasNextWithPointerObject() {
                                                                                                                             // Setup
                                                                                                                             // Use a concrete implementation of Expression
                                                                                                                             Expression expression = new Expression() {
                                                                                                                                 private Iterator<Object> iterator;
                                                                                                                                 private QName qname;
                                                                                                                                 private Locale locale;
                                                                                                                                 
                                                                                                                                 @Override
                                                                                                                                 public boolean isContextDependent() {
                                                                                                                                     return false;
                                                                                                                                 }
                                                                                                                         
                                                                                                                                 @Override
                                                                                                                                 public boolean computeContextDependent() {
                                                                                                                                     return false;
                                                                                                                                 }
                                                                                                                         
                                                                                                                                 @Override
                                                                                                                                 public Object computeValue(EvalContext context) {
                                                                                                                                     return null;
                                                                                                                                 }
                                                                                                                         
                                                                                                                                 @Override
                                                                                                                                 public Object compute(EvalContext context) {
                                                                                                                                     return null;
                                                                                                                                 }
                                                                                                                         
                                                                                                                                 @Override
                                                                                                                                 public Iterator iterate(EvalContext context) {
                                                                                                                                     return iterator;
                                                                                                                                 }
                                                                                                                         
                                                                                                                                 @Override
                                                                                                                                 public Iterator iteratePointers(EvalContext context) {
                                                                                                                                     return iterator;
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             
                                                                                                                             org.apache.commons.jxpath.Pointer mockPointer = mock(org.apache.commons.jxpath.Pointer.class);
                                                                                                                             
                                                                                                                             // Mock the iterator to return our Pointer
                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                             Iterator<Object> iteratorMock = mock(Iterator.class);
                                                                                                                             when(iteratorMock.hasNext()).thenReturn(true);
                                                                                                                             when(iteratorMock.next()).thenReturn(mockPointer);
                                                                                                                             
                                                                                                                             // Use reflection to set private fields since there are no constructors
                                                                                                                             try {
                                                                                                                                 Field iteratorField = Expression.class.getDeclaredField("iterator");
                                                                                                                                 iteratorField.setAccessible(true);
                                                                                                                                 iteratorField.set(expression, iteratorMock);
                                                                                                                                 
                                                                                                                                 Field qnameField = Expression.class.getDeclaredField("qname");
                                                                                                                                 qnameField.setAccessible(true);
                                                                                                                                 qnameField.set(expression, mock(org.apache.commons.jxpath.ri.QName.class));
                                                                                                                                 
                                                                                                                                 Field localeField = Expression.class.getDeclaredField("locale");
                                                                                                                                 localeField.setAccessible(true);
                                                                                                                                 localeField.set(expression, Locale.getDefault());
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                             }
                                                                                                                             
                                                                                                                             // Test
                                                                                                                             Iterator<?> iterator = expression.iterate(null);
                                                                                                                             assertTrue(iterator.hasNext());
                                                                                                                             Object result = iterator.next();
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             // Original code should return the same Pointer instance
                                                                                                                             assertSame("Should return the same Pointer instance", mockPointer, result);
                                                                                                                             
                                                                                                                             // Mutated code would fail this test by returning a new NodePointer instead
                                                                                                                         }

    @Test
                                                                                                                     public void testHasNext_ReturnsBooleanNotNodePointer() {
                                                                                                                         // Setup mock iterator
                                                                                                                         Iterator<?> mockIterator = mock(Iterator.class);
                                                                                                                         
                                                                                                                         // Create test object that implements hasNext()
                                                                                                                         // Using anonymous class that delegates to our mock iterator
                                                                                                                         Object testObject = new Object() {
                                                                                                                             private Iterator<?> iterator = mockIterator;
                                                                                                                             
                                                                                                                             public boolean hasNext() {
                                                                                                                                 return iterator.hasNext();
                                                                                                                             }
                                                                                                                         };
                                                                                                                         
                                                                                                                         // Inject mock iterator via reflection
                                                                                                                         try {
                                                                                                                             java.lang.reflect.Field field = testObject.getClass().getDeclaredField("iterator");
                                                                                                                             field.setAccessible(true);
                                                                                                                             field.set(testObject, mockIterator);
                                                                                                                         } catch (Exception e) {
                                                                                                                             fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                         }
                                                                                                                         
                                                                                                                         // Test case 1: when iterator has next
                                                                                                                         when(mockIterator.hasNext()).thenReturn(true);
                                                                                                                         boolean result1 = false;
                                                                                                                         try {
                                                                                                                             result1 = (Boolean)testObject.getClass().getMethod("hasNext").invoke(testObject);
                                                                                                                         } catch (Exception e) {
                                                                                                                             fail("Failed to invoke hasNext method: " + e.getMessage());
                                                                                                                         }
                                                                                                                         assertTrue("Return value should be boolean", result1);
                                                                                                                         
                                                                                                                         // Test case 2: when iterator doesn't have next
                                                                                                                         when(mockIterator.hasNext()).thenReturn(false);
                                                                                                                         boolean result2 = true;
                                                                                                                         try {
                                                                                                                             result2 = (Boolean)testObject.getClass().getMethod("hasNext").invoke(testObject);
                                                                                                                         } catch (Exception e) {
                                                                                                                             fail("Failed to invoke hasNext method: " + e.getMessage());
                                                                                                                         }
                                                                                                                         assertFalse("Return value should be boolean", result2);
                                                                                                                         
                                                                                                                         // Verify no interactions that would create NodePointer
                                                                                                                         verify(mockIterator, times(2)).hasNext();
                                                                                                                         verifyNoMoreInteractions(mockIterator);
                                                                                                                     }

    @Test
                                                                                                        public void testHasNextShouldNotModifyIteratorState() {
                                                                                                            // Setup
                                                                                                            Iterator<Object> mockIterator = mock(Iterator.class);
                                                                                                            when(mockIterator.hasNext()).thenReturn(true);
                                                                                                            
                                                                                                            // Create anonymous subclass of Expression for testing
                                                                                                            Expression expression = new Expression() {
                                                                                                                @Override
                                                                                                                public boolean computeContextDependent() {
                                                                                                                    return false;
                                                                                                                }
                                                                                                                
                                                                                                                @Override
                                                                                                                public Object computeValue(EvalContext context) {
                                                                                                                    return null;
                                                                                                                }
                                                                                                                
                                                                                                                @Override
                                                                                                                public Object compute(EvalContext context) {
                                                                                                                    return null;
                                                                                                                }
                                                                                                                
                                                                                                                @Override
                                                                                                                public Iterator iterate(EvalContext context) {
                                                                                                                    return mockIterator;
                                                                                                                }
                                                                                                            };
                                                                                                            
                                                                                                            // Test
                                                                                                            EvalContext mockContext = mock(EvalContext.class);
                                                                                                            Iterator iterator = expression.iterate(mockContext);
                                                                                                            boolean result = iterator.hasNext();
                                                                                                            
                                                                                                            // Verify
                                                                                                            assertTrue(result);
                                                                                                            verify(mockIterator).hasNext();
                                                                                                            verify(mockIterator, never()).remove(); // This will catch the mutant
                                                                                                        }

    @Test
                                                                            public void testHasNextShouldNotCallRemove() {
                                                                                // Setup
                                                                                // Create a concrete subclass of Expression since it's abstract
                                                                                Expression expression = new Expression() {
                                                                                    private Iterator<Object> iterator;
                                                                                    
                                                                                    @Override
                                                                                    public boolean isContextDependent() {
                                                                                        return false;
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public boolean computeContextDependent() {
                                                                                        return false;
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public Object computeValue(EvalContext context) {
                                                                                        return null;
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public Object compute(EvalContext context) {
                                                                                        return null;
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public Iterator iterate(EvalContext context) {
                                                                                        return iterator;
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public Iterator iteratePointers(EvalContext context) {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                
                                                                                Iterator<Object> mockIterator = mock(Iterator.class);
                                                                                
                                                                                // Use reflection to set the private iterator field
                                                                                try {
                                                                                    Field iteratorField = expression.getClass().getDeclaredField("iterator");
                                                                                    iteratorField.setAccessible(true);
                                                                                    iteratorField.set(expression, mockIterator);
                                                                                } catch (NoSuchFieldException e) {
                                                                                    // Try alternative field name if "iterator" doesn't exist
                                                                                    try {
                                                                                        Field iteratorField = expression.getClass().getDeclaredField("iter");
                                                                                        iteratorField.setAccessible(true);
                                                                                        iteratorField.set(expression, mockIterator);
                                                                                    } catch (Exception ex) {
                                                                                        fail("Failed to set up test due to reflection error: " + ex.getMessage());
                                                                                    }
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                }
                                                                                
                                                                                // Stub the iterator behavior
                                                                                when(mockIterator.hasNext()).thenReturn(true);
                                                                                
                                                                                // Test - get iterator and call hasNext()
                                                                                Iterator<?> iter = expression.iterate(null);
                                                                                boolean result = iter.hasNext();
                                                                                
                                                                                // Verify
                                                                                assertTrue(result);
                                                                                verify(mockIterator, times(1)).hasNext();
                                                                                verify(mockIterator, never()).remove();  // This will catch the mutant
                                                                            }

    @Test
                                                                       public void testHasNext_WhenIteratorHasNoNext_ShouldReturnFalse() {
                                                                           // Arrange
                                                                           Iterator<?> mockIterator = mock(Iterator.class);
                                                                           when(mockIterator.hasNext()).thenReturn(false);
                                                                           
                                                                           // Create a test implementation of the class
                                                                           Object expression = new Object() {
                                                                               private final Iterator<?> iterator = mockIterator;
                                                                               
                                                                               public boolean hasNext() {
                                                                                   return iterator.hasNext();
                                                                               }
                                                                           };
                                                                           
                                                                           // Act
                                                                           boolean result = ((java.util.Iterator<?>)expression).hasNext();
                                                                           
                                                                           // Assert
                                                                           assertFalse("Should return false when iterator has no next", result);
                                                                           verify(mockIterator).hasNext();
                                                                       }

    @Test
                                                                       public void testHasNext_WhenIteratorDoesNotHaveNext_ShouldReturnFalse() {
                                                                           // Arrange
                                                                           Iterator<?> mockIterator = mock(Iterator.class);
                                                                           when(mockIterator.hasNext()).thenReturn(false);
                                                                           
                                                                           // Create anonymous subclass of Expression
                                                                           Expression expression = new Expression() {
                                                                               @Override
                                                                               public boolean computeContextDependent() {
                                                                                   return false;
                                                                               }
                                                                               
                                                                               @Override
                                                                               public Object computeValue(EvalContext context) {
                                                                                   return null;
                                                                               }
                                                                               
                                                                               @Override
                                                                               public Object compute(EvalContext context) {
                                                                                   return null;
                                                                               }
                                                                               
                                                                               @Override
                                                                               public Iterator iterate(EvalContext context) {
                                                                                   return mockIterator;
                                                                               }
                                                                           };
                                                                           
                                                                           // Act
                                                                           Iterator<?> resultIterator = expression.iterate(null);
                                                                           boolean result = resultIterator.hasNext();
                                                                           
                                                                           // Assert
                                                                           assertFalse(result);
                                                                           verify(mockIterator).hasNext();
                                                                       }

    @Test
                                                                   public void testHasNext_WhenIteratorHasNext_ShouldReturnTrue() {
                                                                       // Arrange
                                                                       Iterator<?> mockIterator = mock(Iterator.class);
                                                                       when(mockIterator.hasNext()).thenReturn(true);
                                                                       
                                                                       // Create a simple implementation of the Expression class for testing
                                                                       Expression expression = new Expression() {
                                                                           private Iterator<?> iterator = mockIterator;
                                                                           
                                                                           @Override
                                                                           public boolean isContextDependent() {
                                                                               return false;
                                                                           }
                                                                           
                                                                           @Override
                                                                           public boolean computeContextDependent() {
                                                                               return false;
                                                                           }
                                                                           
                                                                           @Override
                                                                           public Object computeValue(EvalContext context) {
                                                                               return null;
                                                                           }
                                                                           
                                                                           @Override
                                                                           public Object compute(EvalContext context) {
                                                                               return null;
                                                                           }
                                                                           
                                                                           @Override
                                                                           public Iterator<?> iterate(EvalContext context) {
                                                                               return iterator;
                                                                           }
                                                                           
                                                                           @Override
                                                                           public Iterator<?> iteratePointers(EvalContext context) {
                                                                               return iterator;
                                                                           }
                                                                       };
                                                                       
                                                                       // Act
                                                                       boolean result = ((java.util.Iterator<?>)expression.iterate(null)).hasNext();
                                                                       
                                                                       // Assert
                                                                       assertTrue("Should return true when iterator has next", result);
                                                                       verify(mockIterator).hasNext();
                                                                   }

    @Test
                                                               public void testHasNext_WhenIteratorHasNext_ShouldReturnTrue1() throws Exception {
                                                                   // Arrange
                                                                   // Create anonymous subclass of Expression since it's abstract
                                                                   Expression expression = new Expression() {
                                                                       @Override
                                                                       public boolean computeContextDependent() {
                                                                           return false;
                                                                       }
                                                                       @Override
                                                                       public Object computeValue(EvalContext context) {
                                                                           return null;
                                                                       }
                                                                       @Override
                                                                       public Object compute(EvalContext context) {
                                                                           return null;
                                                                       }
                                                                       @Override
                                                                       public Iterator<?> iterate(EvalContext context) {
                                                                           return null;
                                                                       }
                                                                       @Override
                                                                       public Iterator<?> iteratePointers(EvalContext context) {
                                                                           return null;
                                                                       }
                                                                   };
                                                                   
                                                                   Iterator<?> mockIterator = mock(Iterator.class);
                                                                   
                                                                   // Use reflection to set the private iterator field
                                                                   Field iteratorField = Expression.class.getDeclaredField("iterator");
                                                                   iteratorField.setAccessible(true);
                                                                   iteratorField.set(expression, mockIterator);
                                                                   
                                                                   when(mockIterator.hasNext()).thenReturn(true);
                                                                   
                                                                   // Use reflection to call the private hasNext method
                                                                   Method hasNextMethod = Expression.class.getDeclaredMethod("hasNext");
                                                                   hasNextMethod.setAccessible(true);
                                                                   
                                                                   // Act
                                                                   boolean result = (boolean) hasNextMethod.invoke(expression);
                                                                   
                                                                   // Assert
                                                                   assertTrue(result);
                                                                   verify(mockIterator).hasNext();
                                                               }

    @Test
                                                      public void testHasNext_ReturnsBooleanNotNodePointer1() {
                                                          // Setup mock iterator
                                                          java.util.Iterator<?> mockIterator = mock(java.util.Iterator.class);
                                                          
                                                          // Create test object with overridden iterate method to return our mock iterator
                                                          org.apache.commons.jxpath.ri.compiler.Expression expression = new org.apache.commons.jxpath.ri.compiler.Expression() {
                                                              // Implement abstract methods with minimal implementations
                                                              public boolean isContextDependent() { return false; }
                                                              public boolean computeContextDependent() { return false; }
                                                              public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) { return null; }
                                                              public Object compute(org.apache.commons.jxpath.ri.EvalContext context) { return null; }
                                                              public java.util.Iterator iterate(org.apache.commons.jxpath.ri.EvalContext context) { 
                                                                  return mockIterator; 
                                                              }
                                                              public java.util.Iterator iteratePointers(org.apache.commons.jxpath.ri.EvalContext context) { 
                                                                  return mockIterator; 
                                                              }
                                                          };
                                                          
                                                          // Create a mock context
                                                          org.apache.commons.jxpath.ri.EvalContext mockContext = mock(org.apache.commons.jxpath.ri.EvalContext.class);
                                                          
                                                          // Test case 1: When iterator has next
                                                          when(mockIterator.hasNext()).thenReturn(true);
                                                          boolean result1 = expression.iterate(mockContext).hasNext();
                                                          assertTrue("Should return true when iterator has next", result1);
                                                          
                                                          // Test case 2: When iterator doesn't have next
                                                          when(mockIterator.hasNext()).thenReturn(false);
                                                          boolean result2 = expression.iterate(mockContext).hasNext();
                                                          assertFalse("Should return false when iterator has no next", result2);
                                                      }

    @Test
                                                  public void testHasNext_ShouldReturnBooleanFromIterator() {
                                                      // Create mock iterator
                                                      Iterator<?> mockIterator = mock(Iterator.class);
                                                      
                                                      // Create test instance - simple iterator wrapper
                                                      Iterator<?> testIterator = new Iterator<Object>() {
                                                          @Override
                                                          public boolean hasNext() {
                                                              return mockIterator.hasNext();
                                                          }
                                                          
                                                          @Override
                                                          public Object next() {
                                                              return null;
                                                          }
                                                          
                                                          @Override
                                                          public void remove() {
                                                          }
                                                      };
                                                      
                                                      // Test case 1: When iterator has next
                                                      when(mockIterator.hasNext()).thenReturn(true);
                                                      boolean result1 = testIterator.hasNext();
                                                      assertTrue("Should return true when iterator has next", result1);
                                                      
                                                      // Test case 2: When iterator doesn't have next
                                                      when(mockIterator.hasNext()).thenReturn(false);
                                                      boolean result2 = testIterator.hasNext();
                                                      assertFalse("Should return false when iterator has no next", result2);
                                                      
                                                      // Verify interactions
                                                      verify(mockIterator, times(2)).hasNext();
                                                  }

    @Test
                                         public void testHasNextShouldNotModifyIterator() {
                                             // Create a mock iterator
                                             Iterator<?> mockIterator = mock(Iterator.class);
                                             
                                             // Set up the mock behavior
                                             when(mockIterator.hasNext()).thenReturn(true);
                                             
                                             // Create the Expression instance that also implements Iterator
                                             Expression expression = new Expression() {
                                                 // Implement abstract methods minimally
                                                 public boolean isContextDependent() { return false; }
                                                 public boolean computeContextDependent() { return false; }
                                                 public Object computeValue(EvalContext context) { return null; }
                                                 public Object compute(EvalContext context) { return null; }
                                                 public Iterator iterate(EvalContext context) { return null; }
                                                 public Iterator iteratePointers(EvalContext context) { return null; }
                                                 
                                                 // Implement Iterator methods
                                                 public boolean hasNext() { 
                                                     try {
                                                         Field iteratorField = Expression.class.getDeclaredField("iterator");
                                                         iteratorField.setAccessible(true);
                                                         Iterator<?> it = (Iterator<?>) iteratorField.get(this);
                                                         return it.hasNext();
                                                     } catch (Exception e) {
                                                         throw new RuntimeException(e);
                                                     }
                                                 }
                                                 public Object next() { return null; }
                                                 public void remove() {}
                                             };
                                             
                                             // Inject the mock iterator using reflection
                                             try {
                                                 Field iteratorField = Expression.class.getDeclaredField("iterator");
                                                 iteratorField.setAccessible(true);
                                                 iteratorField.set(expression, mockIterator);
                                             } catch (Exception e) {
                                                 fail("Failed to set up test due to reflection error: " + e.getMessage());
                                             }
                                             
                                             // Call the method by casting to Iterator
                                             boolean result = ((Iterator<?>)expression).hasNext();
                                             
                                             // Verify the behavior
                                             assertTrue(result);  // Verify correct return value
                                             verify(mockIterator).hasNext();  // Verify hasNext was called
                                             verify(mockIterator, never()).remove();  // Critical assertion - remove should never be called
                                             
                                             // Additional verification that iterator state wasn't modified
                                             when(mockIterator.hasNext()).thenReturn(true);
                                             boolean resultAfter = ((Iterator<?>)expression).hasNext();
                                             assertTrue(resultAfter);  // Should still return same value
                                         }

    @Test
                                     public void testHasNext_ShouldNotModifyIterator() {
                                         // Setup
                                         // Create a concrete subclass of Expression for testing
                                         Expression expression = new Expression() {
                                             @Override
                                             public boolean computeContextDependent() {
                                                 return false;
                                             }
                                             @Override
                                             public Object computeValue(EvalContext context) {
                                                 return null;
                                             }
                                             @Override
                                             public Object compute(EvalContext context) {
                                                 return null;
                                             }
                                         };
                                         
                                         Iterator<Object> mockIterator = mock(Iterator.class);
                                         when(mockIterator.hasNext()).thenReturn(true);
                                         
                                         // Use reflection to set private iterator field since there's no constructor
                                         try {
                                             Field iteratorField = Expression.class.getDeclaredField("iterator");
                                             iteratorField.setAccessible(true);
                                             iteratorField.set(expression, mockIterator);
                                         } catch (NoSuchFieldException e) {
                                             // If iterator field doesn't exist, try alternative approach
                                             try {
                                                 // Try to find the field through parent class or interface
                                                 Field iterableField = Expression.class.getDeclaredField("iterable");
                                                 iterableField.setAccessible(true);
                                                 Iterable<Object> iterable = mock(Iterable.class);
                                                 when(iterable.iterator()).thenReturn(mockIterator);
                                                 iterableField.set(expression, iterable);
                                             } catch (Exception ex) {
                                                 fail("Failed to set up test due to reflection error: " + ex.getMessage());
                                             }
                                         } catch (Exception e) {
                                             fail("Failed to set up test due to reflection error: " + e.getMessage());
                                         }
                                         
                                         // Test
                                         boolean result = false;
                                         try {
                                             Method hasNextMethod = Expression.class.getMethod("hasNext");
                                             result = (boolean) hasNextMethod.invoke(expression);
                                         } catch (Exception e) {
                                             fail("Failed to invoke hasNext method: " + e.getMessage());
                                         }
                                         
                                         // Verify
                                         // 1. Verify iterator's hasNext was called (would fail if mutant is active)
                                         verify(mockIterator).hasNext();
                                         
                                         // 2. Verify no remove operation occurred (would fail if mutant is active)
                                         verify(mockIterator, never()).remove();
                                         
                                         // 3. Verify the return value matches the mock's behavior
                                         assertTrue(result);
                                     }

    @Test
                                public void testHasNext_ReturnsIteratorHasNextValue() {
                                    // Create mock iterator
                                    Iterator<?> mockIterator = mock(Iterator.class);
                                    
                                    // Create instance of Expression (using anonymous class since it's abstract)
                                    Expression expression = new Expression() {
                                        // Override abstract methods with minimal implementations
                                        public boolean isContextDependent() { return false; }
                                        public boolean computeContextDependent() { return false; }
                                        public Object computeValue(EvalContext context) { return null; }
                                        public Object compute(EvalContext context) { return null; }
                                        public Iterator iterate(EvalContext context) { return mockIterator; }
                                        public Iterator iteratePointers(EvalContext context) { return null; }
                                    };
                                    
                                    // Test case 1: When iterator has next
                                    when(mockIterator.hasNext()).thenReturn(true);
                                    assertTrue(expression.iterate(null).hasNext());
                                    
                                    // Test case 2: When iterator doesn't have next
                                    when(mockIterator.hasNext()).thenReturn(false);
                                    assertFalse(expression.iterate(null).hasNext());
                                    
                                    // Verify interactions
                                    verify(mockIterator, times(2)).hasNext();
                                }

    @Test
    public void testHasNext_WhenIteratorHasNext_ShouldReturnTrue2() {
        // Arrange
        // Create anonymous concrete subclass of Expression
        Expression expression = new Expression() {
            @Override
            public boolean computeContextDependent() {
                return false;
            }
            
            @Override
            public Object computeValue(EvalContext context) {
                return null;
            }
            
            @Override
            public Object compute(EvalContext context) {
                return null;
            }
        };
        
        java.util.Iterator<?> iteratorMock = mock(java.util.Iterator.class);
        
        // Use reflection to set private iterator field since there's no setter
        try {
            Field iteratorField = Expression.class.getDeclaredField("iterator");
            iteratorField.setAccessible(true);
            iteratorField.set(expression, iteratorMock);
        } catch (Exception e) {
            fail("Failed to set iterator field via reflection");
        }
        
        when(iteratorMock.hasNext()).thenReturn(true);
        
        // Act
        boolean result = iteratorMock.hasNext();
        
        // Assert
        assertTrue("hasNext() should return true when iterator has next", result);
        
        // Verify interaction
        verify(iteratorMock).hasNext();
    }


}
