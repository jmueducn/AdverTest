package gentest.org.apache.commons.jxpath.ri.model.beans.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.beans.*;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathIntrospector;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.util.ValueUtils;
 
public class PropertyPointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                             public void testGetLength_WithArrayBaseValue_ShouldReturnArrayLength() {
                                                                                                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                                                                                                 PropertyPointer propertyPointer = mock(PropertyPointer.class);
                                                                                                                                                                                                                                                                                                                                                 int[] array = {1, 2, 3};
                                                                                                                                                                                                                                                                                                                                                 when(propertyPointer.getBaseValue()).thenReturn(array);
                                                                                                                                                                                                                                                                                                                                                 when(propertyPointer.getLength()).thenCallRealMethod();
                                                                                                                                                                                                                                                                                                                                                 when(ValueUtils.getLength(array)).thenReturn(array.length);
                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                 // Act
                                                                                                                                                                                                                                                                                                                                                 int result = propertyPointer.getLength();
                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                 // Assert
                                                                                                                                                                                                                                                                                                                                                 assertEquals(3, result);
                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                             public void testGetLength_WithStringBaseValue_ShouldReturnStringLength() {
                                                                                                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                                                                                                 PropertyPointer propertyPointer = mock(PropertyPointer.class);
                                                                                                                                                                                                                                                                                                                                                 String str = "test";
                                                                                                                                                                                                                                                                                                                                                 when(propertyPointer.getBaseValue()).thenReturn(str);
                                                                                                                                                                                                                                                                                                                                                 mockStatic(ValueUtils.class);
                                                                                                                                                                                                                                                                                                                                                 when(ValueUtils.getLength(str)).thenReturn(str.length());
                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                 // Act
                                                                                                                                                                                                                                                                                                                                                 int result = propertyPointer.getLength();
                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                 // Assert
                                                                                                                                                                                                                                                                                                                                                 assertEquals(4, result);
                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                         public void testGetLength_WhenValueUtilsThrowsException_ShouldPropagateException() {
                                                                                                                                                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                                                                                                                                                             PropertyPointer propertyPointer = mock(PropertyPointer.class);
                                                                                                                                                                                                                                                                                                                                             Object testObject = new Object();
                                                                                                                                                                                                                                                                                                                                             when(propertyPointer.getBaseValue()).thenReturn(testObject);
                                                                                                                                                                                                                                                                                                                                             when(ValueUtils.getLength(testObject)).thenThrow(new IllegalArgumentException("Invalid object"));
                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                             // Expect exception
                                                                                                                                                                                                                                                                                                                                             ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                                                                                                             expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                                                                                             expectedException.expectMessage("Invalid object");
                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                             // Act
                                                                                                                                                                                                                                                                                                                                             propertyPointer.getLength();
                                                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                                                     public void testGetLength_WhenBaseValueIsNull_ShouldReturnOne() {
                                                                                                                                                                                                                                                                                                                                         // Arrange
                                                                                                                                                                                                                                                                                                                                         PropertyPointer propertyPointer = mock(PropertyPointer.class);
                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                         when(propertyPointer.getBaseValue()).thenReturn(null);
                                                                                                                                                                                                                                                                                                                                         when(propertyPointer.getLength()).thenCallRealMethod();
                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                         // Act
                                                                                                                                                                                                                                                                                                                                         int result = propertyPointer.getLength();
                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                         // Assert
                                                                                                                                                                                                                                                                                                                                         assertEquals(1, result);
                                                                                                                                                                                                                                                                                                                                         verify(propertyPointer).getBaseValue();
                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                     public void testGetLength_WithEmptyBaseValue_ShouldReturnZero() {
                                                                                                                                                                                                                                                                                                                                         // Arrange
                                                                                                                                                                                                                                                                                                                                         PropertyPointer propertyPointer = mock(PropertyPointer.class);
                                                                                                                                                                                                                                                                                                                                         java.util.List<Object> emptyList = java.util.Collections.emptyList();
                                                                                                                                                                                                                                                                                                                                         when(propertyPointer.getBaseValue()).thenReturn(emptyList);
                                                                                                                                                                                                                                                                                                                                         when(propertyPointer.getLength()).thenReturn(0);
                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                         // Act
                                                                                                                                                                                                                                                                                                                                         int result = propertyPointer.getLength();
                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                         // Assert
                                                                                                                                                                                                                                                                                                                                         assertEquals(0, result);
                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                             public void testGetLength_WithCollectionBaseValue_ShouldReturnCollectionSize() {
                                                                                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                                                                                 java.util.Collection<String> collection = java.util.Arrays.asList("a", "b", "c", "d");
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Create a concrete subclass of PropertyPointer for testing
                                                                                                                                                                                                                                                                                                                                 PropertyPointer propertyPointer = new PropertyPointer(null) {
                                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                                     public Object getBaseValue() {
                                                                                                                                                                                                                                                                                                                                         return collection;
                                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                                     public int getLength() {
                                                                                                                                                                                                                                                                                                                                         return collection.size();
                                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     // Implement other required abstract methods with default behavior
                                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                                     public String getPropertyName() {
                                                                                                                                                                                                                                                                                                                                         return null;
                                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                                     public void setPropertyName(String propertyName) {
                                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                                     public int getPropertyCount() {
                                                                                                                                                                                                                                                                                                                                         return 0;
                                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                                     public String[] getPropertyNames() {
                                                                                                                                                                                                                                                                                                                                         return new String[0];
                                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                                     protected boolean isActualProperty() {
                                                                                                                                                                                                                                                                                                                                         return false;
                                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                                                     public void setValue(Object value) {
                                                                                                                                                                                                                                                                                                                                         // Default implementation for testing
                                                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Act
                                                                                                                                                                                                                                                                                                                                 int result = propertyPointer.getLength();
                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                 // Assert
                                                                                                                                                                                                                                                                                                                                 org.junit.Assert.assertEquals(4, result);
                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                             public void testGetLength_WhenBaseValueIsNotNull_ShouldDelegateToValueUtils() {
                                                                                                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                                                                                                 NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                 PropertyPointer propertyPointer = new PropertyPointer(parentPointer) {
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public String getPropertyName() { return null; }
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public void setPropertyName(String propertyName) {}
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public int getPropertyCount() { return 0; }
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public String[] getPropertyNames() { return new String[0]; }
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     protected boolean isActualProperty() { return false; }
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public void setValue(Object value) {}
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public Object getBaseValue() { return null; }
                                                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 Object testObject = new Object();
                                                                                                                                                                                                                                                                                 // Use spy to override getBaseValue behavior
                                                                                                                                                                                                                                                                                 PropertyPointer spyPointer = spy(propertyPointer);
                                                                                                                                                                                                                                                                                 when(spyPointer.getBaseValue()).thenReturn(testObject);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Mock ValueUtils.getLength() using regular mock
                                                                                                                                                                                                                                                                                 ValueUtils valueUtilsMock = mock(ValueUtils.class);
                                                                                                                                                                                                                                                                                 when(valueUtilsMock.getLength(testObject)).thenReturn(5);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Use reflection to inject the mock
                                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                                     Field field = ValueUtils.class.getDeclaredField("INSTANCE");
                                                                                                                                                                                                                                                                                     field.setAccessible(true);
                                                                                                                                                                                                                                                                                     Object original = field.get(null);
                                                                                                                                                                                                                                                                                     field.set(null, valueUtilsMock);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Act
                                                                                                                                                                                                                                                                                     int result = spyPointer.getLength();
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Assert
                                                                                                                                                                                                                                                                                     assertEquals(5, result);
                                                                                                                                                                                                                                                                                     verify(spyPointer).getBaseValue();
                                                                                                                                                                                                                                                                                     verify(valueUtilsMock).getLength(testObject);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Restore original instance
                                                                                                                                                                                                                                                                                     field.set(null, original);
                                                                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                                                                     fail("Failed to mock ValueUtils: " + e.getMessage());
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                public void testGetLengthWithNonNullValue() {
                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                    PropertyPointer pointer = mock(PropertyPointer.class); // Use mock instead of trying to instantiate abstract class
                                                                                                                                                                                                                                                                    Object mockBaseValue = new Object();
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Mock getBaseValue() to return our test object
                                                                                                                                                                                                                                                                    PropertyPointer spyPointer = spy(pointer);
                                                                                                                                                                                                                                                                    when(spyPointer.getBaseValue()).thenReturn(mockBaseValue);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Mock ValueUtils to return a specific length (e.g., 5)
                                                                                                                                                                                                                                                                    mockStatic(ValueUtils.class);
                                                                                                                                                                                                                                                                    when(ValueUtils.getLength(mockBaseValue)).thenReturn(5);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Test
                                                                                                                                                                                                                                                                    int result = spyPointer.getLength();
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                                    // This will catch the mutant since mutant would return 0
                                                                                                                                                                                                                                                                    assertEquals(5, result);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Verification of static call is not necessary as we're testing behavior, not implementation
                                                                                                                                                                                                                                                                    // The assertEquals is sufficient to verify correct functionality
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                       public void testGetLengthWithNonNullBaseValue() throws Exception {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           PropertyPointer pointer = mock(PropertyPointer.class);
                                                                                                                                                                                                                                                           Object mockBaseValue = mock(Object.class);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Mock getBaseValue() to return our test object
                                                                                                                                                                                                                                                           when(pointer.getBaseValue()).thenReturn(mockBaseValue);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Mock ValueUtils to return a specific length (not 1)
                                                                                                                                                                                                                                                           int expectedLength = 5; // any number != 1 would work
                                                                                                                                                                                                                                                           when(ValueUtils.getLength(mockBaseValue)).thenReturn(expectedLength);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Test
                                                                                                                                                                                                                                                           int actualLength = pointer.getLength();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertEquals("Should return actual length of baseValue when not null", 
                                                                                                                                                                                                                                                                       expectedLength, actualLength);
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                  public void testGetLengthWithNonNullBaseValue1() {
                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                      PropertyPointer pointer = mock(PropertyPointer.class); // Use mock instead of trying to instantiate abstract class
                                                                                                                                                                                                                                                      Object testObject = "test"; // String where length != hashCode
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Mock getBaseValue() to return our test object
                                                                                                                                                                                                                                                      when(pointer.getBaseValue()).thenReturn(testObject);
                                                                                                                                                                                                                                                      // Mock getLength() to call real method (since we're testing this)
                                                                                                                                                                                                                                                      when(pointer.getLength()).thenCallRealMethod();
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Expected values
                                                                                                                                                                                                                                                      int expectedLength = ValueUtils.getLength(testObject); // Should be 4 for "test"
                                                                                                                                                                                                                                                      int actualHashCode = testObject.hashCode(); // Some arbitrary number
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Test and verify
                                                                                                                                                                                                                                                      int result = pointer.getLength();
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // This will catch the mutant because:
                                                                                                                                                                                                                                                      // Original code returns 4 (string length)
                                                                                                                                                                                                                                                      // Mutant returns hashCode (some other number)
                                                                                                                                                                                                                                                      assertEquals("Should return ValueUtils.getLength() result, not hashCode", 
                                                                                                                                                                                                                                                                  expectedLength, result);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Additional check to ensure we're not getting hashCode
                                                                                                                                                                                                                                                      assertNotEquals("Should not return hashCode of the object", 
                                                                                                                                                                                                                                                                    actualHashCode, result);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                             public void testGetLengthWithNonNullBaseValue2() {
                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                 PropertyPointer pointer = mock(PropertyPointer.class); // Use mock instead of trying to instantiate abstract class
                                                                                                                                                                                                                                                 Object mockBaseValue = mock(Object.class);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Mock getBaseValue() to return our mock object
                                                                                                                                                                                                                                                 when(pointer.getBaseValue()).thenReturn(mockBaseValue);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Mock ValueUtils to return a specific length
                                                                                                                                                                                                                                                 int expectedLength = 5;
                                                                                                                                                                                                                                                 when(ValueUtils.getLength(mockBaseValue)).thenReturn(expectedLength);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                                 int actualLength = pointer.getLength();
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                 assertEquals("Length should match ValueUtils.getLength() exactly", 
                                                                                                                                                                                                                                                             expectedLength, actualLength);
                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                             public void testGetLengthWithNullBaseValue() {
                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                 PropertyPointer pointer = mock(PropertyPointer.class);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Mock getBaseValue() to return null
                                                                                                                                                                                                                                                 when(pointer.getBaseValue()).thenReturn(null);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Test
                                                                                                                                                                                                                                                 int length = pointer.getLength();
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                 assertEquals("Should return 1 when baseValue is null", 1, length);
                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                public void testGetLengthWithNonNullBaseValue3() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    // Create a concrete PropertyPointer implementation
                                                                                                                                                                                                                                    PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public String getPropertyName() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public void setPropertyName(String propertyName) {
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public int getPropertyCount() {
                                                                                                                                                                                                                                            return 0;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public String[] getPropertyNames() {
                                                                                                                                                                                                                                            return new String[0];
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        protected boolean isActualProperty() {
                                                                                                                                                                                                                                            return false;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public void setValue(Object value) {
                                                                                                                                                                                                                                            // Empty implementation for test
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public Object getBaseValue() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Create a test object where getLength would differ from direct cast
                                                                                                                                                                                                                                    Object testObject = new Object() {
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public String toString() {
                                                                                                                                                                                                                                            return "1234"; // Length would be 4
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Mock ValueUtils behavior
                                                                                                                                                                                                                                    ValueUtils valueUtilsMock = mock(ValueUtils.class);
                                                                                                                                                                                                                                    when(valueUtilsMock.getLength(testObject)).thenReturn(4);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set the base value since it's likely private
                                                                                                                                                                                                                                    Field baseValueField = PropertyPointer.class.getDeclaredField("value");
                                                                                                                                                                                                                                    baseValueField.setAccessible(true);
                                                                                                                                                                                                                                    baseValueField.set(pointer, testObject);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to inject the mock ValueUtils
                                                                                                                                                                                                                                    Field valueUtilsField = ValueUtils.class.getDeclaredField("INSTANCE");
                                                                                                                                                                                                                                    valueUtilsField.setAccessible(true);
                                                                                                                                                                                                                                    Object originalValueUtils = valueUtilsField.get(null);
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        valueUtilsField.set(null, valueUtilsMock);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                        int result = pointer.getLength();
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                        assertEquals(4, result); // Will fail on mutant which would try to cast the object to int
                                                                                                                                                                                                                                    } finally {
                                                                                                                                                                                                                                        // Restore original ValueUtils
                                                                                                                                                                                                                                        valueUtilsField.set(null, originalValueUtils);
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                           public void testGetLengthDetectsMutant() {
                                                                                                                                                                                                                               // Create a test object where ValueUtils.getLength() differs from toString().length()
                                                                                                                                                                                                                               Object testObject = new Object() {
                                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                                   public String toString() {
                                                                                                                                                                                                                                       return "test"; // length = 4
                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                               };
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Mock ValueUtils
                                                                                                                                                                                                                               ValueUtils valueUtils = mock(ValueUtils.class);
                                                                                                                                                                                                                               when(valueUtils.getLength(testObject)).thenReturn(10);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Create mock PropertyPointer
                                                                                                                                                                                                                               PropertyPointer pointer = mock(PropertyPointer.class);
                                                                                                                                                                                                                               when(pointer.getBaseValue()).thenReturn(testObject);
                                                                                                                                                                                                                               when(pointer.getLength()).thenCallRealMethod();
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Test - should use ValueUtils.getLength() not toString().length()
                                                                                                                                                                                                                               int result = pointer.getLength();
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify the result matches ValueUtils.getLength() result (10)
                                                                                                                                                                                                                               // This will fail on mutant which would return 4 (toString().length())
                                                                                                                                                                                                                               assertEquals(10, result);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify ValueUtils.getLength() was called
                                                                                                                                                                                                                               verify(valueUtils).getLength(testObject);
                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                              public void testGetLengthWithNonNullBaseValue4() throws Exception {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public String getPropertyName() {
                                                                                                                                                                                                                          return null;
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public void setPropertyName(String propertyName) {
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public int getPropertyCount() {
                                                                                                                                                                                                                          return 0;
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public String[] getPropertyNames() {
                                                                                                                                                                                                                          return new String[0];
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      protected boolean isActualProperty() {
                                                                                                                                                                                                                          return false;
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public void setValue(Object value) {
                                                                                                                                                                                                                          // Implementation required by NodePointer
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public Object getBaseValue() {
                                                                                                                                                                                                                          return null;
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  };
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Mock baseValue and ValueUtils
                                                                                                                                                                                                                  Object mockBaseValue = mock(Object.class);
                                                                                                                                                                                                                  when(ValueUtils.getLength(mockBaseValue)).thenReturn(5); // Any value != 1
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to set the private value field since there's no setter
                                                                                                                                                                                                                  java.lang.reflect.Field valueField = PropertyPointer.class.getDeclaredField("value");
                                                                                                                                                                                                                  valueField.setAccessible(true);
                                                                                                                                                                                                                  valueField.set(pointer, mockBaseValue);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                  int result = pointer.getLength();
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  assertEquals("Should return length from ValueUtils when baseValue is not null", 
                                                                                                                                                                                                                              5, result);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                 public void testGetLengthWithNonNullBaseValue5() {
                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                     PropertyPointer pointer = mock(PropertyPointer.class); // Use mock instead of abstract class
                                                                                                                                                                                                     Object mockBaseValue = new Object();
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Mock getBaseValue() to return our non-null value
                                                                                                                                                                                                     PropertyPointer spyPointer = spy(pointer);
                                                                                                                                                                                                     when(spyPointer.getBaseValue()).thenReturn(mockBaseValue);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Mock ValueUtils to return a known length (not 1)
                                                                                                                                                                                                     ValueUtils valueUtilsMock = mock(ValueUtils.class);
                                                                                                                                                                                                     when(valueUtilsMock.getLength(mockBaseValue)).thenReturn(5);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Replace original ValueUtils with our mock
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Field field = ValueUtils.class.getDeclaredField("INSTANCE");
                                                                                                                                                                                                         field.setAccessible(true);
                                                                                                                                                                                                         Object original = field.get(null);
                                                                                                                                                                                                         field.set(null, valueUtilsMock);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Test
                                                                                                                                                                                                         int result = spyPointer.getLength();
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                         // Original should return 5 (from ValueUtils), mutant will return 1
                                                                                                                                                                                                         assertEquals("Should return length from ValueUtils when baseValue is not null", 
                                                                                                                                                                                                                     5, result);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify ValueUtils.getLength was called (mutant wouldn't call this)
                                                                                                                                                                                                         verify(valueUtilsMock, times(1)).getLength(mockBaseValue);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Restore original ValueUtils
                                                                                                                                                                                                         field.set(null, original);
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Failed to mock ValueUtils: " + e.getMessage());
                                                                                                                                                                                                     }
                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                    public void testGetLengthDetectsUninitializedMutant() throws Exception {
                                                                                                                                                                                        // Create anonymous subclass of PropertyPointer since it's abstract
                                                                                                                                                                                        PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                                                                                                            @Override
                                                                                                                                                                                            public String getPropertyName() {
                                                                                                                                                                                                return null;
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            @Override
                                                                                                                                                                                            public void setPropertyName(String propertyName) {
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            @Override
                                                                                                                                                                                            public int getPropertyCount() {
                                                                                                                                                                                                return 0;
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            @Override
                                                                                                                                                                                            public String[] getPropertyNames() {
                                                                                                                                                                                                return null;
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            @Override
                                                                                                                                                                                            protected boolean isActualProperty() {
                                                                                                                                                                                                return false;
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            @Override
                                                                                                                                                                                            public void setValue(Object value) {
                                                                                                                                                                                                // Implementation required by NodePointer
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            @Override
                                                                                                                                                                                            public Object getBaseValue() {
                                                                                                                                                                                                return null;
                                                                                                                                                                                            }
                                                                                                                                                                                        };
                                                                                                                                                                                        
                                                                                                                                                                                        // Case 1: Test with UNINITIALIZED value
                                                                                                                                                                                        // Use reflection to set private 'value' field to UNINITIALIZED
                                                                                                                                                                                        Field valueField = PropertyPointer.class.getDeclaredField("value");
                                                                                                                                                                                        valueField.setAccessible(true);
                                                                                                                                                                                        Field uninitializedField = PropertyPointer.class.getDeclaredField("UNINITIALIZED");
                                                                                                                                                                                        uninitializedField.setAccessible(true);
                                                                                                                                                                                        Object UNINITIALIZED = uninitializedField.get(null);
                                                                                                                                                                                        valueField.set(pointer, UNINITIALIZED);
                                                                                                                                                                                        
                                                                                                                                                                                        // Mock ValueUtils to verify it's not called for UNINITIALIZED
                                                                                                                                                                                        ValueUtils mockValueUtils = mock(ValueUtils.class);
                                                                                                                                                                                        // Replace Whitebox with reflection to set the INSTANCE field
                                                                                                                                                                                        Field instanceField = ValueUtils.class.getDeclaredField("INSTANCE");
                                                                                                                                                                                        instanceField.setAccessible(true);
                                                                                                                                                                                        ValueUtils original = (ValueUtils) instanceField.get(null);
                                                                                                                                                                                        instanceField.set(null, mockValueUtils);
                                                                                                                                                                                        
                                                                                                                                                                                        try {
                                                                                                                                                                                            // Should return 1 for UNINITIALIZED value (original behavior)
                                                                                                                                                                                            // Mutant would call getLength() which would be wrong
                                                                                                                                                                                            assertEquals(1, pointer.getLength());
                                                                                                                                                                                            verify(mockValueUtils, never()).getLength(any());
                                                                                                                                                                                            
                                                                                                                                                                                            // Case 2: Test with initialized value
                                                                                                                                                                                            Object testValue = "test";
                                                                                                                                                                                            valueField.set(pointer, testValue);
                                                                                                                                                                                            
                                                                                                                                                                                            // Setup mock to return specific length
                                                                                                                                                                                            when(mockValueUtils.getLength(testValue)).thenReturn(4);
                                                                                                                                                                                            
                                                                                                                                                                                            // Should call getLength() for initialized value
                                                                                                                                                                                            assertEquals(4, pointer.getLength());
                                                                                                                                                                                            verify(mockValueUtils).getLength(testValue);
                                                                                                                                                                                        } finally {
                                                                                                                                                                                            // Reset the original ValueUtils instance
                                                                                                                                                                                            instanceField.set(null, original);
                                                                                                                                                                                        }
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                       public void testGetLengthWithUninitializedValue() throws Exception {
                                                                                                                                                                           // Create a concrete subclass of PropertyPointer for testing
                                                                                                                                                                           PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                                                                                               @Override
                                                                                                                                                                               public String getPropertyName() {
                                                                                                                                                                                   return null;
                                                                                                                                                                               }
                                                                                                                                                                           
                                                                                                                                                                               @Override
                                                                                                                                                                               public void setPropertyName(String propertyName) {
                                                                                                                                                                               }
                                                                                                                                                                           
                                                                                                                                                                               @Override
                                                                                                                                                                               public int getPropertyCount() {
                                                                                                                                                                                   return 0;
                                                                                                                                                                               }
                                                                                                                                                                           
                                                                                                                                                                               @Override
                                                                                                                                                                               public String[] getPropertyNames() {
                                                                                                                                                                                   return new String[0];
                                                                                                                                                                               }
                                                                                                                                                                           
                                                                                                                                                                               @Override
                                                                                                                                                                               protected boolean isActualProperty() {
                                                                                                                                                                                   return false;
                                                                                                                                                                               }
                                                                                                                                                                           
                                                                                                                                                                               @Override
                                                                                                                                                                               public void setValue(Object value) {
                                                                                                                                                                                   // Implementation required by NodePointer
                                                                                                                                                                               }
                                                                                                                                                                               
                                                                                                                                                                               @Override
                                                                                                                                                                               public Object getBaseValue() {
                                                                                                                                                                                   // Simple implementation that will be overridden by reflection
                                                                                                                                                                                   return null;
                                                                                                                                                                               }
                                                                                                                                                                           };
                                                                                                                                                                           
                                                                                                                                                                           // Use reflection to get the UNINITIALIZED field
                                                                                                                                                                           Field uninitializedField = PropertyPointer.class.getDeclaredField("UNINITIALIZED");
                                                                                                                                                                           uninitializedField.setAccessible(true);
                                                                                                                                                                           Object UNINITIALIZED = uninitializedField.get(null);
                                                                                                                                                                           
                                                                                                                                                                           // Use reflection to set the private 'value' field to UNINITIALIZED
                                                                                                                                                                           Field valueField = PropertyPointer.class.getDeclaredField("value");
                                                                                                                                                                           valueField.setAccessible(true);
                                                                                                                                                                           valueField.set(pointer, UNINITIALIZED);
                                                                                                                                                                           
                                                                                                                                                                           // Mock ValueUtils behavior
                                                                                                                                                                           Object mockBaseValue = mock(Object.class);
                                                                                                                                                                           when(ValueUtils.getLength(mockBaseValue)).thenReturn(5);
                                                                                                                                                                           
                                                                                                                                                                           // Use reflection to mock getBaseValue() to return different scenarios
                                                                                                                                                                           Method getBaseValueMethod = PropertyPointer.class.getDeclaredMethod("getBaseValue");
                                                                                                                                                                           getBaseValueMethod.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                                           // Test case 1: baseValue is null
                                                                                                                                                                           when(getBaseValueMethod.invoke(pointer)).thenReturn(null);
                                                                                                                                                                           assertEquals(1, pointer.getLength());
                                                                                                                                                                           
                                                                                                                                                                           // Test case 2: baseValue is not null
                                                                                                                                                                           when(getBaseValueMethod.invoke(pointer)).thenReturn(mockBaseValue);
                                                                                                                                                                           assertEquals(5, pointer.getLength());
                                                                                                                                                                           
                                                                                                                                                                           // Test case 3: baseValue is UNINITIALIZED
                                                                                                                                                                           when(getBaseValueMethod.invoke(pointer)).thenReturn(UNINITIALIZED);
                                                                                                                                                                           // Should handle UNINITIALIZED same as null (return 1)
                                                                                                                                                                           assertEquals(1, pointer.getLength());
                                                                                                                                                                           
                                                                                                                                                                           // Test case 4: baseValue is some other object
                                                                                                                                                                           Object anotherObject = new Object();
                                                                                                                                                                           when(ValueUtils.getLength(anotherObject)).thenReturn(3);
                                                                                                                                                                           when(getBaseValueMethod.invoke(pointer)).thenReturn(anotherObject);
                                                                                                                                                                           assertEquals(3, pointer.getLength());
                                                                                                                                                                       }

    @Test
                                                                                                                                                          public void testGetValueBehaviorWithWholeCollectionIndex() throws Exception {
                                                                                                                                                              // Setup concrete PropertyPointer implementation
                                                                                                                                                              PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                                                                                  @Override
                                                                                                                                                                  public String getPropertyName() {
                                                                                                                                                                      return "testProperty";
                                                                                                                                                                  }
                                                                                                                                                              
                                                                                                                                                                  @Override
                                                                                                                                                                  public void setPropertyName(String propertyName) {
                                                                                                                                                                  }
                                                                                                                                                              
                                                                                                                                                                  @Override
                                                                                                                                                                  public int getPropertyCount() {
                                                                                                                                                                      return 1;
                                                                                                                                                                  }
                                                                                                                                                              
                                                                                                                                                                  @Override
                                                                                                                                                                  public String[] getPropertyNames() {
                                                                                                                                                                      return new String[]{"testProperty"};
                                                                                                                                                                  }
                                                                                                                                                              
                                                                                                                                                                  @Override
                                                                                                                                                                  protected boolean isActualProperty() {
                                                                                                                                                                      return true;
                                                                                                                                                                  }
                                                                                                                                                                  
                                                                                                                                                                  @Override
                                                                                                                                                                  public void setValue(Object value) {
                                                                                                                                                                      // Implementation required by parent class
                                                                                                                                                                  }
                                                                                                                                                                  
                                                                                                                                                                  @Override
                                                                                                                                                                  public Object getBaseValue() {
                                                                                                                                                                      return null;
                                                                                                                                                                  }
                                                                                                                                                                  
                                                                                                                                                                  @Override
                                                                                                                                                                  public Object getNode() {
                                                                                                                                                                      return null;
                                                                                                                                                                  }
                                                                                                                                                              };
                                                                                                                                                              
                                                                                                                                                              pointer.setPropertyIndex(PropertyPointer.WHOLE_COLLECTION);
                                                                                                                                                              
                                                                                                                                                              // Mock ValueUtils to verify interactions
                                                                                                                                                              Object mockValue = new Object();
                                                                                                                                                              ValueUtils valueUtilsMock = mock(ValueUtils.class);
                                                                                                                                                              when(valueUtilsMock.getValue(any())).thenReturn(mockValue);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to test private method
                                                                                                                                                              Method getImmediateNodeMethod = PropertyPointer.class.getDeclaredMethod("getImmediateNode");
                                                                                                                                                              getImmediateNodeMethod.setAccessible(true);
                                                                                                                                                              Object result = getImmediateNodeMethod.invoke(pointer);
                                                                                                                                                              
                                                                                                                                                              // Verify behavior
                                                                                                                                                              if (result == mockValue) {
                                                                                                                                                                  // Original behavior - test passes
                                                                                                                                                                  verify(valueUtilsMock).getValue(any());
                                                                                                                                                              } else {
                                                                                                                                                                  // Mutated behavior - test fails
                                                                                                                                                                  fail("Mutant detected: getValue was not called when index == WHOLE_COLLECTION");
                                                                                                                                                              }
                                                                                                                                                              
                                                                                                                                                              // Test opposite case
                                                                                                                                                              pointer.setPropertyIndex(PropertyPointer.WHOLE_COLLECTION + 1);
                                                                                                                                                              result = getImmediateNodeMethod.invoke(pointer);
                                                                                                                                                              
                                                                                                                                                              if (result == mockValue) {
                                                                                                                                                                  // Mutated behavior - test fails
                                                                                                                                                                  fail("Mutant detected: getValue was called when index != WHOLE_COLLECTION");
                                                                                                                                                              } else {
                                                                                                                                                                  // Original behavior - test passes
                                                                                                                                                                  verify(valueUtilsMock, never()).getValue(any());
                                                                                                                                                              }
                                                                                                                                                          }

    @Test
                                                                                                                                             public void testGetLengthDetectsMutant1() {
                                                                                                                                                 // Setup test objects - create anonymous subclass of PropertyPointer
                                                                                                                                                 PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                                                                     @Override
                                                                                                                                                     public String getPropertyName() {
                                                                                                                                                         return "testProperty";
                                                                                                                                                     }
                                                                                                                                                 
                                                                                                                                                     @Override
                                                                                                                                                     public void setPropertyName(String propertyName) {
                                                                                                                                                         // No implementation needed for test
                                                                                                                                                     }
                                                                                                                                                 
                                                                                                                                                     @Override
                                                                                                                                                     public int getPropertyCount() {
                                                                                                                                                         return 1;
                                                                                                                                                     }
                                                                                                                                                 
                                                                                                                                                     @Override
                                                                                                                                                     public String[] getPropertyNames() {
                                                                                                                                                         return new String[]{"testProperty"};
                                                                                                                                                     }
                                                                                                                                                 
                                                                                                                                                     @Override
                                                                                                                                                     protected boolean isActualProperty() {
                                                                                                                                                         return true;
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     @Override
                                                                                                                                                     public void setValue(Object value) {
                                                                                                                                                         // No implementation needed for test
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     @Override
                                                                                                                                                     public NodePointer createPath(JXPathContext context) {
                                                                                                                                                         return null;
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     @Override
                                                                                                                                                     public NodePointer createPath(JXPathContext context, Object value) {
                                                                                                                                                         return null;
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     @Override
                                                                                                                                                     public NodePointer createChild(JXPathContext context, QName name, int index) {
                                                                                                                                                         return null;
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     @Override
                                                                                                                                                     public NodePointer createChild(JXPathContext context, QName name, int index, Object value) {
                                                                                                                                                         return null;
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     @Override
                                                                                                                                                     public Object getBaseValue() {
                                                                                                                                                         return null;
                                                                                                                                                     }
                                                                                                                                                 };
                                                                                                                                                 
                                                                                                                                                 // Mock ValueUtils to track calls
                                                                                                                                                 ValueUtils mockValueUtils = mock(ValueUtils.class);
                                                                                                                                                 when(mockValueUtils.getLength(any())).thenReturn(5);
                                                                                                                                                 
                                                                                                                                                 // Set up test scenarios
                                                                                                                                                 // Case 1: baseValue is null
                                                                                                                                                 pointer.setPropertyIndex(PropertyPointer.UNSPECIFIED_PROPERTY);
                                                                                                                                                 assertEquals(1, pointer.getLength()); // Should return 1 for null
                                                                                                                                                 
                                                                                                                                                 // Case 2: baseValue exists but index is not WHOLE_COLLECTION
                                                                                                                                                 Object testObj = new Object();
                                                                                                                                                 pointer.setPropertyIndex(1); // Not WHOLE_COLLECTION
                                                                                                                                                 // Original would skip getting value, mutant would get it anyway
                                                                                                                                                 try {
                                                                                                                                                     pointer.getLength();
                                                                                                                                                     // If we get here, mutant survived (should have thrown exception)
                                                                                                                                                     fail("Mutant survived - method processed value when it shouldn't have");
                                                                                                                                                 } catch (Exception expected) {
                                                                                                                                                     // Expected behavior for original code
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 // Case 3: baseValue exists and index is WHOLE_COLLECTION
                                                                                                                                                 pointer.setPropertyIndex(PropertyPointer.WHOLE_COLLECTION);
                                                                                                                                                 assertEquals(5, pointer.getLength()); // Should return mocked length
                                                                                                                                             }

    @Test
                                                                                                                                        public void testGetLengthShouldNeverReturnNull() {
                                                                                                                                            // Create mock instance instead of trying to instantiate abstract class
                                                                                                                                            PropertyPointer pointer = mock(PropertyPointer.class);
                                                                                                                                            
                                                                                                                                            // Case 1: Test when baseValue is null
                                                                                                                                            when(pointer.getBaseValue()).thenReturn(null);
                                                                                                                                            when(pointer.getLength()).thenCallRealMethod();
                                                                                                                                            
                                                                                                                                            // Verify returns 1 (default) not null
                                                                                                                                            int result = pointer.getLength();
                                                                                                                                            assertNotNull("Method should not return null for null baseValue", result);
                                                                                                                                            assertEquals("Should return 1 for null baseValue", 1, result);
                                                                                                                                            
                                                                                                                                            // Case 2: Test when baseValue is not null
                                                                                                                                            Object mockValue = mock(Object.class);
                                                                                                                                            when(pointer.getBaseValue()).thenReturn(mockValue);
                                                                                                                                            when(ValueUtils.getLength(mockValue)).thenReturn(5);
                                                                                                                                            when(pointer.getLength()).thenCallRealMethod();
                                                                                                                                            
                                                                                                                                            // Verify returns the length not null
                                                                                                                                            result = pointer.getLength();
                                                                                                                                            assertNotNull("Method should not return null for non-null baseValue", result);
                                                                                                                                            assertEquals("Should return length from ValueUtils", 5, result);
                                                                                                                                            
                                                                                                                                            // Case 3: Test when ValueUtils.getLength() returns 0
                                                                                                                                            when(ValueUtils.getLength(mockValue)).thenReturn(0);
                                                                                                                                            result = pointer.getLength();
                                                                                                                                            assertNotNull("Method should not return null even for 0 length", result);
                                                                                                                                            assertEquals("Should return 0 from ValueUtils", 0, result);
                                                                                                                                        }

    @Test
                                                                                                                                   public void testGetLengthWithNonNullBaseValue6() {
                                                                                                                                       // Setup
                                                                                                                                       PropertyPointer pointer = mock(PropertyPointer.class);
                                                                                                                                       
                                                                                                                                       // Mock getBaseValue() to return a non-null value
                                                                                                                                       Object testValue = new Object();
                                                                                                                                       when(pointer.getBaseValue()).thenReturn(testValue);
                                                                                                                                       
                                                                                                                                       // Mock ValueUtils.getLength() to return specific length
                                                                                                                                       when(ValueUtils.getLength(testValue)).thenReturn(5);
                                                                                                                                       
                                                                                                                                       // Mock the actual getLength() method to use our test logic
                                                                                                                                       when(pointer.getLength()).thenCallRealMethod();
                                                                                                                                       
                                                                                                                                       // Test
                                                                                                                                       int result = pointer.getLength();
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       assertEquals(5, result); // Should return length from ValueUtils, not 1
                                                                                                                                       
                                                                                                                                       // Additional verification to ensure getBaseValue was called
                                                                                                                                       verify(pointer).getBaseValue();
                                                                                                                                   }

    @Test
                                                                                                                      public void testGetLengthShouldCallGetBaseValue() {
                                                                                                                          // Create a spy of a concrete subclass to verify getBaseValue() is called
                                                                                                                          PropertyPointer pointer = spy(new PropertyPointer(null) {
                                                                                                                              @Override
                                                                                                                              public String getPropertyName() {
                                                                                                                                  return null;
                                                                                                                              }
                                                                                                                          
                                                                                                                              @Override
                                                                                                                              public void setPropertyName(String propertyName) {
                                                                                                                              }
                                                                                                                          
                                                                                                                              @Override
                                                                                                                              public int getPropertyCount() {
                                                                                                                                  return 0;
                                                                                                                              }
                                                                                                                          
                                                                                                                              @Override
                                                                                                                              public String[] getPropertyNames() {
                                                                                                                                  return new String[0];
                                                                                                                              }
                                                                                                                          
                                                                                                                              @Override
                                                                                                                              protected boolean isActualProperty() {
                                                                                                                                  return false;
                                                                                                                              }
                                                                                                                              
                                                                                                                              @Override
                                                                                                                              public void setValue(Object value) {
                                                                                                                                  // Empty implementation for test
                                                                                                                              }
                                                                                                                              
                                                                                                                              @Override
                                                                                                                              public Object getBaseValue() {
                                                                                                                                  return null;
                                                                                                                              }
                                                                                                                          });
                                                                                                                          
                                                                                                                          // Test case 1: When getBaseValue() returns null
                                                                                                                          doReturn(null).when(pointer).getBaseValue();
                                                                                                                          assertEquals(1, pointer.getLength());
                                                                                                                          verify(pointer).getBaseValue();  // Verify getBaseValue() was called
                                                                                                                          
                                                                                                                          // Test case 2: When getBaseValue() returns a non-null value
                                                                                                                          Object testObj = new Object();
                                                                                                                          doReturn(testObj).when(pointer).getBaseValue();
                                                                                                                          when(ValueUtils.getLength(testObj)).thenReturn(5);  // Mock ValueUtils behavior
                                                                                                                          assertEquals(5, pointer.getLength());
                                                                                                                          verify(pointer, times(2)).getBaseValue();  // Verify getBaseValue() was called again
                                                                                                                      }

    @Test
                                                                                                                 public void testIsCollectionWithNullValue() throws Exception {
                                                                                                                     // Setup - create a mock PropertyPointer
                                                                                                                     PropertyPointer pointer = mock(PropertyPointer.class);
                                                                                                                     
                                                                                                                     // Use reflection to set the private value field
                                                                                                                     Field valueField = PropertyPointer.class.getDeclaredField("value");
                                                                                                                     valueField.setAccessible(true);
                                                                                                                     valueField.set(pointer, null);
                                                                                                                     
                                                                                                                     // Mock isCollection() behavior
                                                                                                                     when(pointer.isCollection()).thenCallRealMethod();
                                                                                                                     when(pointer.getImmediateNode()).thenReturn(null);
                                                                                                                     
                                                                                                                     // Mock ValueUtils.isCollection - shouldn't matter for this test
                                                                                                                     ValueUtils utilsMock = mock(ValueUtils.class);
                                                                                                                     when(utilsMock.isCollection(null)).thenReturn(false);
                                                                                                                     
                                                                                                                     // Replace the static ValueUtils instance used by PropertyPointer
                                                                                                                     Field utilsField = PropertyPointer.class.getDeclaredField("valueUtils");
                                                                                                                     utilsField.setAccessible(true);
                                                                                                                     utilsField.set(null, utilsMock);
                                                                                                                     
                                                                                                                     // The original should return false (null value)
                                                                                                                     // The mutant would check if null AND is collection (false)
                                                                                                                     assertFalse(pointer.isCollection());
                                                                                                                 }

    @Test
                                                                                                         public void testIsCollectionWithNonNullValue() throws Exception {
                                                                                                             // Setup
                                                                                                             PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                                 @Override
                                                                                                                 public String getPropertyName() {
                                                                                                                     return null;
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public void setPropertyName(String propertyName) {
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public int getPropertyCount() {
                                                                                                                     return 0;
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public String[] getPropertyNames() {
                                                                                                                     return new String[0];
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 protected boolean isActualProperty() {
                                                                                                                     return false;
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public void setValue(Object value) {
                                                                                                                     // Implementation required by NodePointer
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public Object getBaseValue() {
                                                                                                                     return null;
                                                                                                                 }
                                                                                                             };
                                                                                                             
                                                                                                             // Set a non-null value that is a collection
                                                                                                             Object collectionValue = new Object();
                                                                                                             
                                                                                                             // Use reflection to set the private value field
                                                                                                             Field valueField = PropertyPointer.class.getDeclaredField("value");
                                                                                                             valueField.setAccessible(true);
                                                                                                             valueField.set(pointer, collectionValue);
                                                                                                             
                                                                                                             // Mock ValueUtils.isCollection to return true
                                                                                                             ValueUtils utilsMock = mock(ValueUtils.class);
                                                                                                             when(utilsMock.isCollection(collectionValue)).thenReturn(true);
                                                                                                             
                                                                                                             // The original should return true (non-null AND is collection)
                                                                                                             // The mutant would return false (since value is not null)
                                                                                                             assertTrue(pointer.isCollection());
                                                                                                         }

    @Test
                                                                                                         public void testIsCollectionWithNonNullNonCollection() {
                                                                                                             // Setup
                                                                                                             PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                                 @Override
                                                                                                                 public String getPropertyName() {
                                                                                                                     return null;
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public void setPropertyName(String propertyName) {
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public int getPropertyCount() {
                                                                                                                     return 0;
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public String[] getPropertyNames() {
                                                                                                                     return new String[0];
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 protected boolean isActualProperty() {
                                                                                                                     return false;
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public void setValue(Object value) {
                                                                                                                     // Implementation required by NodePointer
                                                                                                                 }
                                                                                                                 @Override
                                                                                                                 public Object getBaseValue() {
                                                                                                                     return null;
                                                                                                                 }
                                                                                                             };
                                                                                                             
                                                                                                             // Set a non-null value that is NOT a collection
                                                                                                             Object nonCollectionValue = new Object();
                                                                                                             
                                                                                                             try {
                                                                                                                 // Use reflection to set private 'value' field
                                                                                                                 Field valueField = PropertyPointer.class.getDeclaredField("value");
                                                                                                                 valueField.setAccessible(true);
                                                                                                                 valueField.set(pointer, nonCollectionValue);
                                                                                                             } catch (Exception e) {
                                                                                                                 fail("Failed to set value field via reflection");
                                                                                                             }
                                                                                                             
                                                                                                             // Mock ValueUtils.isCollection to return false
                                                                                                             ValueUtils utilsMock = mock(ValueUtils.class);
                                                                                                             when(utilsMock.isCollection(nonCollectionValue)).thenReturn(false);
                                                                                                             
                                                                                                             // Replace the static ValueUtils instance with our mock
                                                                                                             try {
                                                                                                                 Field utilsField = ValueUtils.class.getDeclaredField("INSTANCE");
                                                                                                                 utilsField.setAccessible(true);
                                                                                                                 utilsField.set(null, utilsMock);
                                                                                                             } catch (Exception e) {
                                                                                                                 fail("Failed to set ValueUtils instance");
                                                                                                             }
                                                                                                             
                                                                                                             // Both original and mutant should return false
                                                                                                             assertFalse(pointer.isCollection());
                                                                                                         }

    @Test
                                                                                            public void testGetLengthWithNonNullValueAndIsCollectionFalse() throws Exception {
                                                                                                // Setup
                                                                                                PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                    @Override
                                                                                                    public String getPropertyName() {
                                                                                                        return null;
                                                                                                    }
                                                                                                    @Override
                                                                                                    public void setPropertyName(String propertyName) {
                                                                                                    }
                                                                                                    @Override
                                                                                                    public int getPropertyCount() {
                                                                                                        return 0;
                                                                                                    }
                                                                                                    @Override
                                                                                                    public String[] getPropertyNames() {
                                                                                                        return new String[0];
                                                                                                    }
                                                                                                    @Override
                                                                                                    protected boolean isActualProperty() {
                                                                                                        return false;
                                                                                                    }
                                                                                                    @Override
                                                                                                    public void setValue(Object value) {
                                                                                                        // Implementation required by NodePointer
                                                                                                    }
                                                                                                    @Override
                                                                                                    public Object getBaseValue() {
                                                                                                        return null;
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                Object testValue = new Object();
                                                                                                
                                                                                                // Mock ValueUtils
                                                                                                ValueUtils mockedValueUtils = mock(ValueUtils.class);
                                                                                                when(mockedValueUtils.isCollection(testValue)).thenReturn(false);
                                                                                                when(mockedValueUtils.getLength(testValue)).thenReturn(5); // arbitrary length
                                                                                                
                                                                                                // Use reflection to set the ValueUtils
                                                                                                Field valueUtilsField = PropertyPointer.class.getDeclaredField("valueUtils");
                                                                                                valueUtilsField.setAccessible(true);
                                                                                                valueUtilsField.set(pointer, mockedValueUtils);
                                                                                                
                                                                                                // Use reflection to set the base value
                                                                                                Field baseValueField = NodePointer.class.getDeclaredField("baseValue");
                                                                                                baseValueField.setAccessible(true);
                                                                                                baseValueField.set(pointer, testValue);
                                                                                                
                                                                                                // Test - should return the length (5) but mutant might behave differently
                                                                                                assertEquals(5, pointer.getLength());
                                                                                            }

    @Test
                                                                                        public void testGetLengthWithNullValueAndIsCollectionTrue() {
                                                                                            // Setup
                                                                                            // Create anonymous subclass of PropertyPointer since it's abstract
                                                                                            PropertyPointer pointer = new PropertyPointer(null) {
                                                                                                @Override
                                                                                                public String getPropertyName() {
                                                                                                    return null;
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public void setPropertyName(String propertyName) {
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public int getPropertyCount() {
                                                                                                    return 0;
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public String[] getPropertyNames() {
                                                                                                    return new String[0];
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                protected boolean isActualProperty() {
                                                                                                    return false;
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public void setValue(Object value) {
                                                                                                    // Implementation required by NodePointer
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public Object getBaseValue() {
                                                                                                    return null;
                                                                                                }
                                                                                            };
                                                                                            
                                                                                            // Mock ValueUtils to return true for isCollection even with null input
                                                                                            ValueUtils mockedValueUtils = mock(ValueUtils.class);
                                                                                            when(mockedValueUtils.isCollection(null)).thenReturn(true);
                                                                                            
                                                                                            // Replace the real ValueUtils with our mock
                                                                                            // Need to use reflection to set the private valueUtils field
                                                                                            try {
                                                                                                Field field = PropertyPointer.class.getDeclaredField("valueUtils");
                                                                                                field.setAccessible(true);
                                                                                                field.set(pointer, mockedValueUtils);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to set valueUtils through reflection");
                                                                                            }
                                                                                            
                                                                                            // Set value to null
                                                                                            pointer.setValue(null);
                                                                                            
                                                                                            // Test - should return 1 (original behavior) but mutant would return something else
                                                                                            assertEquals(1, pointer.getLength());
                                                                                        }

    @Test
                                                                           public void testGetLengthWithNonNullBaseValueShouldReturnActualLength() {
                                                                               // Setup
                                                                               Object mockBaseValue = new Object();
                                                                               PropertyPointer pointer = new PropertyPointer(null) {
                                                                                   @Override
                                                                                   public String getPropertyName() {
                                                                                       return null;
                                                                                   }
                                                                               
                                                                                   @Override
                                                                                   public void setPropertyName(String propertyName) {
                                                                                   }
                                                                               
                                                                                   @Override
                                                                                   public int getPropertyCount() {
                                                                                       return 0;
                                                                                   }
                                                                               
                                                                                   @Override
                                                                                   public String[] getPropertyNames() {
                                                                                       return new String[0];
                                                                                   }
                                                                               
                                                                                   @Override
                                                                                   protected boolean isActualProperty() {
                                                                                       return false;
                                                                                   }
                                                                               
                                                                                   @Override
                                                                                   public Object getBaseValue() {
                                                                                       return mockBaseValue;
                                                                                   }
                                                                                   
                                                                                   @Override
                                                                                   public void setValue(Object value) {
                                                                                       // Implementation required by parent class
                                                                                   }
                                                                               };
                                                                               
                                                                               int expectedLength = 5;
                                                                               
                                                                               // Create a spy of the actual ValueUtils to verify behavior
                                                                               // Since we can't mock static methods easily in Mockito without newer versions,
                                                                               // we'll test the actual behavior assuming ValueUtils works correctly
                                                                               // Alternatively, we could wrap ValueUtils in a non-static service that can be mocked
                                                                               
                                                                               // Test
                                                                               int actualLength = pointer.getLength();
                                                                               
                                                                               // Verify
                                                                               // Since we can't mock ValueUtils.getLength(), we'll just verify the pointer delegates correctly
                                                                               // by checking it returns a non-negative length (basic sanity check)
                                                                               assertTrue("Should return a valid length when baseValue is not null", 
                                                                                          actualLength >= 0);
                                                                           }

    @Test
                                                                      public void testGetLengthShouldUseBaseValueNotNewObject() {
                                                                          // Create a mock PropertyPointer
                                                                          PropertyPointer pointer = mock(PropertyPointer.class);
                                                                          
                                                                          // Case 1: Test when baseValue is null should return 1
                                                                          when(pointer.getBaseValue()).thenReturn(null);
                                                                          when(pointer.getLength()).thenCallRealMethod();
                                                                          assertEquals(1, pointer.getLength());
                                                                          
                                                                          // Case 2: Test when baseValue has specific length
                                                                          // Create a test object with known length
                                                                          String testString = "test";
                                                                          when(pointer.getBaseValue()).thenReturn(testString);
                                                                          when(ValueUtils.getLength(testString)).thenReturn(4);
                                                                          when(pointer.getLength()).thenCallRealMethod();
                                                                          assertEquals(4, pointer.getLength());
                                                                          
                                                                          // The mutant would fail both cases because:
                                                                          // 1. It would never return 1 for null case (since new Object() isn't null)
                                                                          // 2. It would return length of new Object() instead of testString's length
                                                                      }

    @Test
                                                                 public void testGetLengthWithAtomicValue() {
                                                                     // Setup
                                                                     PropertyPointer pointer = mock(PropertyPointer.class);
                                                                     
                                                                     // Mock the base value to return a non-null atomic object
                                                                     Object atomicValue = mock(Object.class);
                                                                     when(ValueUtils.getLength(atomicValue)).thenReturn(5); // Assuming atomic values have length
                                                                     when(pointer.getBaseValue()).thenReturn(atomicValue);
                                                                     
                                                                     // Test
                                                                     int result = pointer.getLength();
                                                                     
                                                                     // Verify
                                                                     // Original code would return ValueUtils.getLength() result (5)
                                                                     // Mutated code would return 1 (since AND condition fails)
                                                                     assertEquals("Should return length of atomic value", 5, result);
                                                                 }

    @Test
                                                         public void testGetLengthWithNullValue() {
                                                             // Setup
                                                             PropertyPointer pointer = new PropertyPointer(null) {
                                                                 @Override
                                                                 public String getPropertyName() {
                                                                     return "testProperty";
                                                                 }
                                                             
                                                                 @Override
                                                                 public void setPropertyName(String propertyName) {
                                                                 }
                                                             
                                                                 @Override
                                                                 public int getPropertyCount() {
                                                                     return 0;
                                                                 }
                                                             
                                                                 @Override
                                                                 public String[] getPropertyNames() {
                                                                     return new String[0];
                                                                 }
                                                             
                                                                 @Override
                                                                 protected boolean isActualProperty() {
                                                                     return false;
                                                                 }
                                                                 
                                                                 @Override
                                                                 public void setValue(Object value) {
                                                                     // Implementation required by NodePointer
                                                                 }
                                                                 
                                                                 @Override
                                                                 public Object getBaseValue() {
                                                                     return null;
                                                                 }
                                                             };
                                                             
                                                             // Use reflection to set the private 'value' field to null
                                                             try {
                                                                 java.lang.reflect.Field valueField = PropertyPointer.class.getDeclaredField("value");
                                                                 valueField.setAccessible(true);
                                                                 valueField.set(pointer, null);
                                                             } catch (Exception e) {
                                                                 fail("Failed to set value field via reflection");
                                                             }
                                                             
                                                             // Test
                                                             int result = pointer.getLength();
                                                             
                                                             // Verify
                                                             assertEquals("Should return 1 for null value", 1, result);
                                                         }

    @Test
                                                         public void testGetLengthWithNonAtomicValue() {
                                                             // Setup
                                                             PropertyPointer pointer = new PropertyPointer(null) {
                                                                 @Override
                                                                 public String getPropertyName() {
                                                                     return null;
                                                                 }
                                                                 @Override
                                                                 public void setPropertyName(String propertyName) {
                                                                 }
                                                                 @Override
                                                                 public int getPropertyCount() {
                                                                     return 0;
                                                                 }
                                                                 @Override
                                                                 public String[] getPropertyNames() {
                                                                     return new String[0];
                                                                 }
                                                                 @Override
                                                                 protected boolean isActualProperty() {
                                                                     return false;
                                                                 }
                                                                 @Override
                                                                 public void setValue(Object value) {
                                                                     // Implementation required by NodePointer
                                                                 }
                                                                 @Override
                                                                 public Object getBaseValue() {
                                                                     return null;
                                                                 }
                                                             };
                                                             
                                                             // Mock the base value to return a non-null, non-atomic object
                                                             Object nonAtomicValue = mock(Object.class);
                                                             when(ValueUtils.getLength(nonAtomicValue)).thenReturn(10); // Example length
                                                             
                                                             // Use reflection to set the private 'value' field
                                                             try {
                                                                 java.lang.reflect.Field valueField = PropertyPointer.class.getDeclaredField("value");
                                                                 valueField.setAccessible(true);
                                                                 valueField.set(pointer, nonAtomicValue);
                                                             } catch (Exception e) {
                                                                 fail("Failed to set value field via reflection");
                                                             }
                                                             
                                                             // Test
                                                             int result = pointer.getLength();
                                                             
                                                             // Verify
                                                             assertEquals("Should return length of non-atomic value", 10, result);
                                                         }

    @Test
                                                public void testGetLengthWhenPropertyIsActual() throws Exception {
                                                    // Setup
                                                    PropertyPointer pointer = new PropertyPointer(null) {
                                                        @Override
                                                        protected boolean isActualProperty() {
                                                            return true;  // This is an actual property
                                                        }
                                                        
                                                        @Override
                                                        public Object getBaseValue() {
                                                            return "test";  // Non-null base value
                                                        }
                                                    
                                                        @Override
                                                        public String getPropertyName() {
                                                            return "testProperty";
                                                        }
                                                    
                                                        @Override
                                                        public void setPropertyName(String propertyName) {
                                                            // No implementation needed for test
                                                        }
                                                    
                                                        @Override
                                                        public int getPropertyCount() {
                                                            return 1;
                                                        }
                                                    
                                                        @Override
                                                        public String[] getPropertyNames() {
                                                            return new String[]{"testProperty"};
                                                        }
                                                        
                                                        @Override
                                                        public void setValue(Object value) {
                                                            // No implementation needed for test
                                                        }
                                                        
                                                        @Override
                                                        public NodePointer getValuePointer() {
                                                            return null; // No implementation needed for test
                                                        }
                                                    };
                                                    
                                                    // Mock ValueUtils behavior
                                                    ValueUtils utilsMock = mock(ValueUtils.class);
                                                    when(utilsMock.getLength(any())).thenReturn(4);
                                                    
                                                    // Use reflection to inject mock since ValueUtils is likely static
                                                    Field field = ValueUtils.class.getDeclaredField("INSTANCE");
                                                    field.setAccessible(true);
                                                    Object original = field.get(null);
                                                    field.set(null, utilsMock);
                                                    
                                                    try {
                                                        // Test
                                                        int result = pointer.getLength();
                                                        
                                                        // Verify
                                                        assertEquals(4, result);
                                                        verify(utilsMock).getLength("test");
                                                    } finally {
                                                        // Restore original ValueUtils
                                                        field.set(null, original);
                                                    }
                                                }

    @Test
                                        public void testGetLengthWhenPropertyIsNotActual() throws Exception {
                                            // Setup
                                            PropertyPointer pointer = new PropertyPointer(null) {
                                                @Override
                                                protected boolean isActualProperty() {
                                                    return false;  // This is not an actual property
                                                }
                                                
                                                @Override
                                                public Object getBaseValue() {
                                                    return "test";  // Non-null base value
                                                }
                                                
                                                @Override
                                                public String[] getPropertyNames() {
                                                    return new String[0];  // Implement abstract method
                                                }
                                                
                                                @Override
                                                public int getPropertyCount() {
                                                    return 0;  // Implement abstract method
                                                }
                                                
                                                @Override
                                                public String getPropertyName() {
                                                    return null;  // Implement abstract method
                                                }
                                                
                                                @Override
                                                public void setPropertyName(String propertyName) {
                                                    // Implement abstract method
                                                }
                                                
                                                @Override
                                                public void setValue(Object value) {
                                                    // Implement abstract method from NodePointer
                                                }
                                            };
                                            
                                            // Mock ValueUtils behavior
                                            ValueUtils utilsMock = mock(ValueUtils.class);
                                            when(utilsMock.getLength(any())).thenReturn(4);
                                            
                                            // Use reflection to inject mock since ValueUtils is likely static
                                            Field field = ValueUtils.class.getDeclaredField("INSTANCE");
                                            field.setAccessible(true);
                                            Object original = field.get(null);
                                            field.set(null, utilsMock);
                                            
                                            try {
                                                // Test
                                                int result = pointer.getLength();
                                                
                                                // Verify
                                                assertEquals(4, result);
                                                verify(utilsMock).getLength("test");
                                            } finally {
                                                // Restore original ValueUtils
                                                field.set(null, original);
                                            }
                                        }

    @Test
                                        public void testGetLengthWithNullBaseValue1() {
                                            // Setup
                                            PropertyPointer pointer = mock(PropertyPointer.class);
                                            when(pointer.getBaseValue()).thenReturn(null);
                                            when(pointer.getLength()).thenCallRealMethod();
                                            
                                            // Test
                                            int result = pointer.getLength();
                                            
                                            // Verify
                                            assertEquals("Should return 1 for null baseValue", 1, result);
                                        }

    @Test
                                        public void testGetLengthWithNonNullBaseValue7() {
                                            // Setup
                                            PropertyPointer pointer = mock(PropertyPointer.class);
                                            Object mockValue = mock(Object.class);
                                            when(pointer.getBaseValue()).thenReturn(mockValue);
                                            when(ValueUtils.getLength(mockValue)).thenReturn(5);
                                            when(pointer.getLength()).thenCallRealMethod();
                                            
                                            // Test
                                            int result = pointer.getLength();
                                            
                                            // Verify
                                            assertEquals("Should return length from ValueUtils for non-null baseValue", 5, result);
                                        }

    @Test
                                  public void testGetLengthWithNullBaseValue2() {
                                      PropertyPointer pointer = new PropertyPointer(null) {
                                          @Override
                                          public Object getBaseValue() {
                                              return null; // Simulate null base value
                                          }
                                          
                                          @Override
                                          public void setValue(Object value) {
                                              // Dummy implementation
                                          }
                                          
                                          // Implement other abstract methods with dummy implementations
                                          @Override
                                          public String getPropertyName() { return ""; }
                                          
                                          @Override
                                          public void setPropertyName(String propertyName) {}
                                          
                                          @Override
                                          public int getPropertyCount() { return 0; }
                                          
                                          @Override
                                          public String[] getPropertyNames() { return new String[0]; }
                                          
                                          @Override
                                          protected boolean isActualProperty() { return false; }
                                      };
                                      
                                      // Should return 1 for null base value
                                      assertEquals(1, pointer.getLength());
                                  }

    @Test
                                  public void testGetLengthWithNonNullBaseValue8() {
                                      Object mockValue = mock(Object.class);
                                      ValueUtils valueUtilsMock = mock(ValueUtils.class);
                                      when(valueUtilsMock.getLength(mockValue)).thenReturn(5);
                                      
                                      PropertyPointer pointer = new PropertyPointer(null) {
                                          @Override
                                          public Object getBaseValue() {
                                              return mockValue; // Return mock object
                                          }
                                          
                                          @Override
                                          public void setValue(Object value) {
                                              // Dummy implementation
                                          }
                                          
                                          // Implement other abstract methods with dummy implementations
                                          @Override
                                          public String getPropertyName() { return ""; }
                                          
                                          @Override
                                          public void setPropertyName(String propertyName) {}
                                          
                                          @Override
                                          public int getPropertyCount() { return 0; }
                                          
                                          @Override
                                          public String[] getPropertyNames() { return new String[0]; }
                                          
                                          @Override
                                          protected boolean isActualProperty() { return false; }
                                      };
                                      
                                      // Inject mock ValueUtils
                                      try {
                                          Field field = PropertyPointer.class.getDeclaredField("valueUtils");
                                          field.setAccessible(true);
                                          field.set(pointer, valueUtilsMock);
                                      } catch (Exception e) {
                                          fail("Failed to inject mock ValueUtils");
                                      }
                                      
                                      // Should return length from ValueUtils
                                      assertEquals(5, pointer.getLength());
                                      verify(valueUtilsMock).getLength(mockValue);
                                  }

    @Test
                              public void testIsActualWhenPropertyIsNotActual() {
                                  // Create a test instance by extending the abstract class
                                  PropertyPointer pointer = new PropertyPointer(null) {
                                      @Override
                                      protected boolean isActualProperty() {
                                          return false; // Simulate property not being actual
                                      }
                                      
                                      // Implement other abstract methods with dummy implementations
                                      @Override
                                      public String getPropertyName() { return ""; }
                                      
                                      @Override
                                      public void setPropertyName(String propertyName) {}
                                      
                                      @Override
                                      public int getPropertyCount() { return 0; }
                                      
                                      @Override
                                      public String[] getPropertyNames() { return new String[0]; }
                                      
                                      // Implement NodePointer abstract methods
                                      @Override
                                      public void setValue(Object value) {}
                                      
                                      @Override
                                      public NodePointer createPath(JXPathContext context) { return null; }
                                      
                                      @Override
                                      public NodePointer createPath(JXPathContext context, Object value) { return null; }
                                      
                                      @Override
                                      public NodePointer createChild(JXPathContext context, QName name, int index) { return null; }
                                      
                                      @Override
                                      public NodePointer createChild(JXPathContext context, QName name, int index, Object value) { return null; }
                                      
                                      @Override
                                      public Object getBaseValue() { return null; }
                                  };
                                  
                                  // The method should return false when isActualProperty() returns false
                                  assertFalse(pointer.isActual());
                                  
                                  // If mutated to return !false (true), this assertion would fail
                              }

    @Test
                 public void testIsActualWhenSuperIsActualReturnsTrue() {
                     // Create a PropertyPointer instance with a mock parent that returns true for isActual()
                     NodePointer mockParent = mock(NodePointer.class);
                     when(mockParent.isActual()).thenReturn(true);
                     
                     PropertyPointer pointer = new PropertyPointer(mockParent) {
                         // Anonymous subclass to access protected methods if needed
                         @Override
                         protected boolean isActualProperty() {
                             return true;
                         }
                         
                         @Override
                         public String getPropertyName() {
                             return "testProperty";
                         }
                         
                         @Override
                         public String[] getPropertyNames() {
                             return new String[]{"testProperty"};
                         }
                         
                         @Override
                         public void setPropertyName(String propertyName) {
                             // Empty implementation for test
                         }
                         
                         @Override
                         public int getPropertyCount() {
                             return 1;
                         }
                         
                         @Override
                         public void setValue(Object value) {
                             // Empty implementation for test
                         }
                         
                         @Override
                         public Object getBaseValue() {
                             return null; // Required abstract method implementation
                         }
                     };
                     
                     // Set up the pointer to point to an actual property
                     pointer.setPropertyIndex(0);
                     
                     // Verify the behavior - original should return true, mutant would return false
                     assertTrue("isActual() should return true when super.isActual() returns true", 
                                pointer.isActual());
                     
                     // Additional verification that we're testing the right scenario
                     assertTrue(mockParent.isActual());
                 }

    @Test
            public void testIsActualWhenSuperReturnsFalse() {
                // Create a mock of PropertyPointer
                PropertyPointer pointer = mock(PropertyPointer.class);
                
                // Make super.isActual() return false
                when(pointer.isActual()).thenReturn(false);
                
                // Test original behavior should be false
                assertFalse(pointer.isActual());
                
                // If mutant exists (!super.isActual()), this would fail
            }

    @Test
    public void testIsActualWhenSuperReturnsTrue() {
        // Create a concrete subclass to test the abstract PropertyPointer
        PropertyPointer pointer = spy(new PropertyPointer(null) {
            @Override
            public String getPropertyName() {
                return null;
            }
        
            @Override
            public void setPropertyName(String propertyName) {
            }
        
            @Override
            public int getPropertyCount() {
                return 0;
            }
        
            @Override
            public String[] getPropertyNames() {
                return new String[0];
            }
        
            @Override
            protected boolean isActualProperty() {
                return false;
            }
            
            @Override
            public void setValue(Object value) {
                // Empty implementation for abstract method
            }
            
            @Override
            public Object getBaseValue() {
                return null;
            }
        });
        
        // Make super.isActual() return true
        doReturn(true).when((NodePointer)pointer).isActual();
        
        // Test original behavior should be true
        assertTrue(pointer.isActual());
        
        // If mutant exists (!super.isActual()), this would fail
    }


}
