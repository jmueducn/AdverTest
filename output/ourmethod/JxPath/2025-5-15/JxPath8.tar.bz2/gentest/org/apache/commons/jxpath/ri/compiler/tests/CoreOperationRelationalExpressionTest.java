package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.InfoSetUtil;
import org.apache.commons.jxpath.ri.axes.InitialContext;
import org.apache.commons.jxpath.ri.axes.SelfContext;
 
public class CoreOperationRelationalExpressionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                     public void testCompute_EqualNumericValues() throws Exception {
                                                                                                                                                                                                                                                                                         // Create anonymous subclass of CoreOperationRelationalExpression
                                                                                                                                                                                                                                                                                         CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                                 return compare == 0;
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                                             public String getSymbol() {
                                                                                                                                                                                                                                                                                                 return "=="; // Dummy implementation for test purposes
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Get the private compute method via reflection
                                                                                                                                                                                                                                                                                         Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                                                                                                                                 .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                                         computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Test with integer values
                                                                                                                                                                                                                                                                                         assertTrue((boolean) computeMethod.invoke(expr, 5, 5));
                                                                                                                                                                                                                                                                                         // Test with double values
                                                                                                                                                                                                                                                                                         assertTrue((boolean) computeMethod.invoke(expr, 3.14, 3.14));
                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                     public void testCompute_LeftNaN() throws Exception {
                                                                                                                                                                                                                                                                                         // Create test instance with dummy arguments
                                                                                                                                                                                                                                                                                         Expression[] args = new Expression[0];
                                                                                                                                                                                                                                                                                         CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(args) {
                                                                                                                                                                                                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                                 return false; // dummy implementation
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                             public String getSymbol() {
                                                                                                                                                                                                                                                                                                 return ""; // dummy implementation
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Get the private compute method via reflection
                                                                                                                                                                                                                                                                                         Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                                                                                                                                 .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                                         computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Invoke the method and assert the result
                                                                                                                                                                                                                                                                                         boolean result = (boolean) computeMethod.invoke(expr, Double.NaN, 5);
                                                                                                                                                                                                                                                                                         assertFalse(result);
                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                     public void testCompute_RightNaN() throws Exception {
                                                                                                                                                                                                                                                                                         // Create a dummy instance of CoreOperationRelationalExpression
                                                                                                                                                                                                                                                                                         Expression[] args = new Expression[0];
                                                                                                                                                                                                                                                                                         CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(args) {
                                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                                 return false;
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                                             public String getSymbol() {
                                                                                                                                                                                                                                                                                                 return "dummy"; // Implement the required abstract method
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Get the private compute method via reflection
                                                                                                                                                                                                                                                                                         Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                             "compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                                         computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Invoke the method with test values
                                                                                                                                                                                                                                                                                         boolean result = (boolean) computeMethod.invoke(expr, 5, Double.NaN);
                                                                                                                                                                                                                                                                                         assertFalse(result);
                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                     public void testCompute_MixedTypes() throws Exception {
                                                                                                                                                                                                                                                                                         // Create an anonymous subclass of CoreOperationRelationalExpression for testing
                                                                                                                                                                                                                                                                                         CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                                 return compare == 0;
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                                             public String getSymbol() {
                                                                                                                                                                                                                                                                                                 return "test"; // Dummy implementation for testing
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Get the private compute method via reflection
                                                                                                                                                                                                                                                                                         Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                                         computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Test with mixed types (String and Integer)
                                                                                                                                                                                                                                                                                         boolean result = (boolean) computeMethod.invoke(expr, "123", 123);
                                                                                                                                                                                                                                                                                         assertFalse(result);
                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                             public void testCompute_WithInitialContext() throws Exception {
                                                                                                                                                                                                                                                                                 InitialContext leftContext = mock(InitialContext.class);
                                                                                                                                                                                                                                                                                 InitialContext rightContext = mock(InitialContext.class);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Create concrete subclass instance of the abstract class under test
                                                                                                                                                                                                                                                                                 CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                         return false;
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public String getSymbol() {
                                                                                                                                                                                                                                                                                         return "test-symbol";
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Use reflection to access private compute method
                                                                                                                                                                                                                                                                                 Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                     "compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                                 computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                 computeMethod.invoke(expr, leftContext, rightContext);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 verify(leftContext).reset();
                                                                                                                                                                                                                                                                                 verify(rightContext).reset();
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                             public void testCompute_NonNumericValues() throws Exception {
                                                                                                                                                                                                                                                                                 // Create concrete subclass for testing
                                                                                                                                                                                                                                                                                 class TestExpression extends CoreOperationRelationalExpression {
                                                                                                                                                                                                                                                                                     TestExpression(Expression[] args) {
                                                                                                                                                                                                                                                                                         super(args);
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                         return false; // dummy implementation
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public String getSymbol() {
                                                                                                                                                                                                                                                                                         return "test"; // dummy implementation
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Create instance with dummy arguments
                                                                                                                                                                                                                                                                                 TestExpression expr = new TestExpression(new Expression[0]);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Get the private compute method via reflection
                                                                                                                                                                                                                                                                                 Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                                                                                                                         .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                                 computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Invoke the method with non-numeric values
                                                                                                                                                                                                                                                                                 boolean result = (boolean) computeMethod.invoke(expr, "abc", "def");
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 assertFalse(result);
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                             public void testCompute_NullValues() throws Exception {
                                                                                                                                                                                                                                                                                 // Create a dummy expression array for constructor
                                                                                                                                                                                                                                                                                 Expression[] args = new Expression[0];
                                                                                                                                                                                                                                                                                 // Create anonymous subclass to instantiate the abstract class
                                                                                                                                                                                                                                                                                 CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(args) {
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                         return false; // dummy implementation
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public String getSymbol() {
                                                                                                                                                                                                                                                                                         return ""; // dummy implementation
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Get the private compute method via reflection
                                                                                                                                                                                                                                                                                 Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                     "compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                                 computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Test null values
                                                                                                                                                                                                                                                                                 assertFalse((Boolean) computeMethod.invoke(expr, null, null));
                                                                                                                                                                                                                                                                                 assertFalse((Boolean) computeMethod.invoke(expr, null, 5));
                                                                                                                                                                                                                                                                                 assertFalse((Boolean) computeMethod.invoke(expr, 5, null));
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                         public void testCompute_BothIteratorsWithMatch() {
                                                                                                                                                                                                                                                                             java.util.Iterator<?> leftIter = java.util.Arrays.asList("a", "b", "c").iterator();
                                                                                                                                                                                                                                                                             java.util.Iterator<?> rightIter = java.util.Arrays.asList("x", "b", "z").iterator();
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Create a simple implementation of CoreOperationRelationalExpression
                                                                                                                                                                                                                                                                             org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression expr = 
                                                                                                                                                                                                                                                                                 new org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression(new org.apache.commons.jxpath.ri.compiler.Expression[0]) {
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                         return compare == 0;
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                     public String getSymbol() {
                                                                                                                                                                                                                                                                                         return "==";
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                 java.lang.reflect.Method computeMethod = org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression.class
                                                                                                                                                                                                                                                                                     .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                                 computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                 boolean result = (boolean) computeMethod.invoke(expr, leftIter, rightIter);
                                                                                                                                                                                                                                                                                 assertTrue(result);
                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                 fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                         public void testCompute_RightIteratorContainsLeftValue() throws Exception {
                                                                                                                                                                                                                                                                             Object leftValue = "test";
                                                                                                                                                                                                                                                                             java.util.Iterator<String> rightIter = java.util.Arrays.asList("foo", "test", "bar").iterator();
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Create anonymous subclass of CoreOperationRelationalExpression
                                                                                                                                                                                                                                                                             CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new org.apache.commons.jxpath.ri.compiler.Expression[0]) {
                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                 protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                     return false; // Not used in this test
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                 public String getSymbol() {
                                                                                                                                                                                                                                                                                     return "test-symbol"; // Implement abstract method
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Get the private compute method via reflection
                                                                                                                                                                                                                                                                             Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                             computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Invoke the method and assert the result
                                                                                                                                                                                                                                                                             boolean result = (boolean) computeMethod.invoke(expr, leftValue, rightIter);
                                                                                                                                                                                                                                                                             assertTrue(result);
                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                     public void testCompute_UnequalNumericValues() throws Exception {
                                                                                                                                                                                                                                                                         // Create anonymous subclass instance with empty args since we're testing private compute method directly
                                                                                                                                                                                                                                                                         CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                                 // Dummy implementation since we're testing compute directly
                                                                                                                                                                                                                                                                                 return false;
                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                             public String getSymbol() {
                                                                                                                                                                                                                                                                                 // Return a valid comparison symbol since we're testing compute directly
                                                                                                                                                                                                                                                                                 return "!=";
                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Get the private compute method via reflection
                                                                                                                                                                                                                                                                         Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                                         computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Test with unequal integers
                                                                                                                                                                                                                                                                         assertFalse((boolean) computeMethod.invoke(expr, 5, 6));
                                                                                                                                                                                                                                                                         // Test with unequal doubles
                                                                                                                                                                                                                                                                         assertFalse((boolean) computeMethod.invoke(expr, 3.14, 3.15));
                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                     public void testCompute_WithReducedValues() throws Exception {
                                                                                                                                                                                                                                                         // Create concrete expressions for arguments
                                                                                                                                                                                                                                                         Expression arg1 = mock(Expression.class);
                                                                                                                                                                                                                                                         Expression arg2 = mock(Expression.class);
                                                                                                                                                                                                                                                         Expression[] args = new Expression[]{arg1, arg2};
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Create a concrete instance of CoreOperationRelationalExpression
                                                                                                                                                                                                                                                         CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(args) {
                                                                                                                                                                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                 return compare == 0;
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                             public String getSymbol() {
                                                                                                                                                                                                                                                                 return "==";
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Use reflection to access private compute method
                                                                                                                                                                                                                                                         Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                                                                                                 .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                         computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Test with equal values
                                                                                                                                                                                                                                                         boolean result = (boolean) computeMethod.invoke(expr, 5, 5);
                                                                                                                                                                                                                                                         assertTrue(result);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Test with unequal values
                                                                                                                                                                                                                                                         result = (boolean) computeMethod.invoke(expr, 5, 10);
                                                                                                                                                                                                                                                         assertFalse(result);
                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                 public void testCompute_LeftIteratorContainsRightValue() throws Exception {
                                                                                                                                                                                                                                                     java.util.Iterator<Integer> leftIter = java.util.Arrays.asList(1, 2, 3).iterator();
                                                                                                                                                                                                                                                     Object rightValue = 2;
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Create mock expressions for args
                                                                                                                                                                                                                                                     org.apache.commons.jxpath.ri.compiler.Expression[] args = new org.apache.commons.jxpath.ri.compiler.Expression[2];
                                                                                                                                                                                                                                                     args[0] = new org.apache.commons.jxpath.ri.compiler.Expression() {
                                                                                                                                                                                                                                                         public boolean isContextDependent() { return false; }
                                                                                                                                                                                                                                                         public boolean computeContextDependent() { return false; }
                                                                                                                                                                                                                                                         public org.apache.commons.jxpath.ri.Compiler getCompiler() { return null; }
                                                                                                                                                                                                                                                         public String toString() { return ""; }
                                                                                                                                                                                                                                                         public Object compute(EvalContext context) { return null; }
                                                                                                                                                                                                                                                         public Object computeValue(EvalContext context) { return null; }
                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                     args[1] = new org.apache.commons.jxpath.ri.compiler.Expression() {
                                                                                                                                                                                                                                                         public boolean isContextDependent() { return false; }
                                                                                                                                                                                                                                                         public boolean computeContextDependent() { return false; }
                                                                                                                                                                                                                                                         public org.apache.commons.jxpath.ri.Compiler getCompiler() { return null; }
                                                                                                                                                                                                                                                         public String toString() { return ""; }
                                                                                                                                                                                                                                                         public Object compute(EvalContext context) { return null; }
                                                                                                                                                                                                                                                         public Object computeValue(EvalContext context) { return null; }
                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression expr = 
                                                                                                                                                                                                                                                         new org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression(args) {
                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                                 return compare == 0;
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                             public String getSymbol() {
                                                                                                                                                                                                                                                                 return "==";
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Get private compute method via reflection
                                                                                                                                                                                                                                                     java.lang.reflect.Method computeMethod = org.apache.commons.jxpath.ri.compiler.CoreOperationRelationalExpression.class
                                                                                                                                                                                                                                                         .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                                                                     computeMethod.setAccessible(true);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Invoke the method
                                                                                                                                                                                                                                                     boolean result = (boolean) computeMethod.invoke(expr, leftIter, rightValue);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     assertTrue(result);
                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                     public void testCompute_BothIteratorsNoMatch() throws Exception {
                                                                                                                                                                                                                                         // Create test iterators
                                                                                                                                                                                                                                         Iterator<Object> leftIter = new ArrayList<Object>().iterator();
                                                                                                                                                                                                                                         Iterator<Object> rightIter = new ArrayList<Object>().iterator();
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Create instance of CoreOperationRelationalExpression
                                                                                                                                                                                                                                         CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                                                 return false;
                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                             public String getSymbol() {
                                                                                                                                                                                                                                                 return "!=";
                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Get the private compute method via reflection
                                                                                                                                                                                                                                         Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                                                                                             "compute", Object.class, Object.class);
                                                                                                                                                                                                                                         computeMethod.setAccessible(true);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Invoke the method and assert the result
                                                                                                                                                                                                                                         boolean result = (boolean) computeMethod.invoke(expr, leftIter, rightIter);
                                                                                                                                                                                                                                         assertFalse(result);
                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                public void testCompute_RightIteratorLeftNonIterator_CallsContainsMatchCorrectly() throws Exception {
                                                                                                                                                                                                                    // Create test objects
                                                                                                                                                                                                                    Iterator<?> rightIterator = mock(Iterator.class);
                                                                                                                                                                                                                    Object leftNonIterator = new Object();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create real expression instance with implementation of abstract methods
                                                                                                                                                                                                                    CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                            return false; // dummy implementation
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                        public String getSymbol() {
                                                                                                                                                                                                                            return "dummy"; // dummy implementation
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    };
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Mock the behavior using reflection
                                                                                                                                                                                                                    Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                                                                                                                                        "compute", Object.class, Object.class);
                                                                                                                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Spy on the real object to verify internal calls
                                                                                                                                                                                                                    CoreOperationRelationalExpression spyExpr = spy(expr);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Call the compute method through reflection
                                                                                                                                                                                                                    boolean result = (boolean) computeMethod.invoke(spyExpr, leftNonIterator, rightIterator);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify the result - since we can't verify private method calls directly,
                                                                                                                                                                                                                    // we verify the expected behavior through the result
                                                                                                                                                                                                                    // The actual assertion should be based on the expected behavior of the compute method
                                                                                                                                                                                                                    // when one argument is an iterator and the other is not
                                                                                                                                                                                                                    assertTrue(result);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                           public void testCompute_RightIteratorContainsLeft_ShouldReturnTrue() throws Exception {
                                                                                                                                                                                                               // Create test instance (using reflection since constructor is protected)
                                                                                                                                                                                                               CoreOperationRelationalExpression instance = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                   protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                       return false; // Not used in this test
                                                                                                                                                                                                                   }
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                   public String getSymbol() {
                                                                                                                                                                                                                       return "test"; // Implement abstract method
                                                                                                                                                                                                                   }
                                                                                                                                                                                                               };
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Mock objects
                                                                                                                                                                                                               Iterator<?> mockIterator = mock(Iterator.class);
                                                                                                                                                                                                               Object leftValue = new Object(); // Any non-iterator object
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Setup mock behavior
                                                                                                                                                                                                               when(mockIterator.hasNext()).thenReturn(true, false);
                                                                                                                                                                                                               when(mockIterator.next()).thenReturn(leftValue);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Get private compute method via reflection
                                                                                                                                                                                                               Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                                                       .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                               computeMethod.setAccessible(true);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Test - should return true since iterator contains leftValue
                                                                                                                                                                                                               boolean result = (boolean) computeMethod.invoke(instance, leftValue, mockIterator);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                               assertTrue("Should return true when right iterator contains left value", result);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify mock interactions
                                                                                                                                                                                                               verify(mockIterator, times(2)).hasNext();
                                                                                                                                                                                                               verify(mockIterator).next();
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                      public void testCompute_RightValueNaN_ShouldReturnFalse() {
                                                                                                                                                                                                          // Create test instance - since constructor is protected, we'll use a concrete subclass
                                                                                                                                                                                                          // Mock the evaluateCompare method since it's abstract and implement getSymbol()
                                                                                                                                                                                                          CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(null) {
                                                                                                                                                                                                              @Override
                                                                                                                                                                                                              protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                                  return true; // This shouldn't be reached in original code
                                                                                                                                                                                                              }
                                                                                                                                                                                                              
                                                                                                                                                                                                              @Override
                                                                                                                                                                                                              public String getSymbol() {
                                                                                                                                                                                                                  return "test"; // Implement required abstract method
                                                                                                                                                                                                              }
                                                                                                                                                                                                          };
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Test with left as normal number and right as NaN
                                                                                                                                                                                                          Object left = 5.0; // Valid double
                                                                                                                                                                                                          Object right = Double.NaN;
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to access private compute method
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                              computeMethod.setAccessible(true);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Original should return false for NaN right value
                                                                                                                                                                                                              boolean result = (boolean) computeMethod.invoke(expr, left, right);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Assert that it returns false (original behavior)
                                                                                                                                                                                                              assertFalse("Should return false when right value is NaN", result);
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                             public void testComputeComparison() throws Exception {
                                                                                                                                                                                                 // Create a concrete subclass for testing
                                                                                                                                                                                                 class TestExpression extends CoreOperationRelationalExpression {
                                                                                                                                                                                                     public TestExpression() {
                                                                                                                                                                                                         super(new Expression[0]);
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     @Override
                                                                                                                                                                                                     protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                         // Default implementation for the abstract method
                                                                                                                                                                                                         return compare == 0;
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     @Override
                                                                                                                                                                                                     public String getSymbol() {
                                                                                                                                                                                                         // Implementation for the abstract method from CoreOperation
                                                                                                                                                                                                         return "test";
                                                                                                                                                                                                     }
                                                                                                                                                                                                 }
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Create spy of our test class
                                                                                                                                                                                                 TestExpression expr = spy(new TestExpression());
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Get Method objects for reflection
                                                                                                                                                                                                 Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                                         .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                                 computeMethod.setAccessible(true);
                                                                                                                                                                                                 
                                                                                                                                                                                                 Method evaluateCompareMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                                         .getDeclaredMethod("evaluateCompare", int.class);
                                                                                                                                                                                                 evaluateCompareMethod.setAccessible(true);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Test case where left < right (5 < 10)
                                                                                                                                                                                                 doReturn(true).when(expr).evaluateCompare(-1);
                                                                                                                                                                                                 boolean result1 = (boolean) computeMethod.invoke(expr, 5, 10);
                                                                                                                                                                                                 verify(expr).evaluateCompare(-1);
                                                                                                                                                                                                 assertTrue(result1);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Test case where left > right (10 > 5)
                                                                                                                                                                                                 doReturn(true).when(expr).evaluateCompare(1);
                                                                                                                                                                                                 boolean result2 = (boolean) computeMethod.invoke(expr, 10, 5);
                                                                                                                                                                                                 verify(expr).evaluateCompare(1);
                                                                                                                                                                                                 assertTrue(result2);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Test case where left == right (5 == 5)
                                                                                                                                                                                                 doReturn(true).when(expr).evaluateCompare(0);
                                                                                                                                                                                                 boolean result3 = (boolean) computeMethod.invoke(expr, 5, 5);
                                                                                                                                                                                                 verify(expr).evaluateCompare(0);
                                                                                                                                                                                                 assertTrue(result3);
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                    public void testComputeComparisonLogic() {
                                                                                                                                                                                        // Create a test instance of the abstract class
                                                                                                                                                                                        final int[] lastCompareResultHolder = new int[1];
                                                                                                                                                                                        CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(null) {
                                                                                                                                                                                            @Override
                                                                                                                                                                                            protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                                // Track the comparison result
                                                                                                                                                                                                lastCompareResultHolder[0] = compare;
                                                                                                                                                                                                return compare == 0;
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            @Override
                                                                                                                                                                                            public String getSymbol() {
                                                                                                                                                                                                return "test";
                                                                                                                                                                                            }
                                                                                                                                                                                        };
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to access private compute method
                                                                                                                                                                                        try {
                                                                                                                                                                                            Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                                .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                                            computeMethod.setAccessible(true);
                                                                                                                                                                                            
                                                                                                                                                                                            // Test case 1: left < right
                                                                                                                                                                                            computeMethod.invoke(expr, 1.0, 2.0);
                                                                                                                                                                                            assertEquals(-1, lastCompareResultHolder[0]);
                                                                                                                                                                                            
                                                                                                                                                                                            // Test case 2: left > right
                                                                                                                                                                                            computeMethod.invoke(expr, 2.0, 1.0);
                                                                                                                                                                                            assertEquals(1, lastCompareResultHolder[0]);
                                                                                                                                                                                            
                                                                                                                                                                                            // Test case 3: left == right
                                                                                                                                                                                            computeMethod.invoke(expr, 2.0, 2.0);
                                                                                                                                                                                            assertEquals(0, lastCompareResultHolder[0]);
                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                            fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                                                                        }
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                           public void testCompute_DetectsGreaterThanComparisonMutant() throws Exception {
                                                                                                                                                                               // Create a concrete subclass for testing
                                                                                                                                                                               class TestExpression extends CoreOperationRelationalExpression {
                                                                                                                                                                                   public TestExpression() {
                                                                                                                                                                                       super(new Expression[0]);
                                                                                                                                                                                   }
                                                                                                                                                                                   
                                                                                                                                                                                   @Override
                                                                                                                                                                                   protected boolean evaluateCompare(int compare) {
                                                                                                                                                                                       return true; // Default mock behavior
                                                                                                                                                                                   }
                                                                                                                                                                                   
                                                                                                                                                                                   @Override
                                                                                                                                                                                   public String getSymbol() {
                                                                                                                                                                                       return "test"; // Dummy implementation for testing
                                                                                                                                                                                   }
                                                                                                                                                                               }
                                                                                                                                                                               
                                                                                                                                                                               // Create spy of our test subclass
                                                                                                                                                                               TestExpression spyExpr = spy(new TestExpression());
                                                                                                                                                                               
                                                                                                                                                                               // Get Method objects for reflection
                                                                                                                                                                               Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                       .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                               computeMethod.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               Method evaluateCompareMethod = CoreOperationRelationalExpression.class
                                                                                                                                                                                       .getDeclaredMethod("evaluateCompare", int.class);
                                                                                                                                                                               evaluateCompareMethod.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               // Mock evaluateCompare to return true for any comparison
                                                                                                                                                                               doReturn(true).when(spyExpr).evaluateCompare(anyInt());
                                                                                                                                                                               
                                                                                                                                                                               // Test case where left > right (5 > 3)
                                                                                                                                                                               Object left = 5;
                                                                                                                                                                               Object right = 3;
                                                                                                                                                                               
                                                                                                                                                                               // Call the compute method via reflection
                                                                                                                                                                               boolean result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                                                                                                                                               
                                                                                                                                                                               // Verify evaluateCompare was called with 1 (for left > right)
                                                                                                                                                                               verify(spyExpr).evaluateCompare(1);
                                                                                                                                                                               
                                                                                                                                                                               // Also verify the result is true (since we mocked evaluateCompare to return true)
                                                                                                                                                                               assertTrue(result);
                                                                                                                                                                               
                                                                                                                                                                               // Additional test case where left < right to ensure basic comparison works
                                                                                                                                                                               left = 2;
                                                                                                                                                                               right = 4;
                                                                                                                                                                               result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                                                                                                                                               verify(spyExpr).evaluateCompare(-1);
                                                                                                                                                                               assertTrue(result);
                                                                                                                                                                               
                                                                                                                                                                               // Test equal case
                                                                                                                                                                               left = 5;
                                                                                                                                                                               right = 5;
                                                                                                                                                                               result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                                                                                                                                               verify(spyExpr).evaluateCompare(0);
                                                                                                                                                                               assertTrue(result);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                  public void testCompute_LeftGreaterThanRight_ShouldReturn() {
                                                                                                                                                                      // Create test instance - since constructor is protected, we'll use a concrete subclass
                                                                                                                                                                      // For testing purposes, we'll create an anonymous subclass
                                                                                                                                                                      CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected boolean evaluateCompare(int compare) {
                                                                                                                                                                              // Verify the comparison result is correct
                                                                                                                                                                              assertEquals("When left > right, compare should be 1", 1, compare);
                                                                                                                                                                              return true;
                                                                                                                                                                          }
                                                                                                                                                                          
                                                                                                                                                                          @Override
                                                                                                                                                                          public String getSymbol() {
                                                                                                                                                                              return ""; // Simple implementation for testing
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Test with left > right case
                                                                                                                                                                      // Using reflection to access private compute method
                                                                                                                                                                      try {
                                                                                                                                                                          Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                          computeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Test case where left (5.0) > right (3.0)
                                                                                                                                                                          Double left = 5.0;
                                                                                                                                                                          Double right = 3.0;
                                                                                                                                                                          computeMethod.invoke(expr, left, right);
                                                                                                                                                                          
                                                                                                                                                                          // The assertion happens in the evaluateCompare mock above
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                                                      }
                                                                                                                                                                  }

    @Test
                                                                                                                                                         public void testCompute_LeftLessThanRight_ShouldReturnNegativeOne() {
                                                                                                                                                             // Create test instance
                                                                                                                                                             CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                                                                 @Override
                                                                                                                                                                 protected boolean evaluateCompare(int compare) {
                                                                                                                                                                     // Verify the comparison result is -1 (left < right)
                                                                                                                                                                     assertEquals(-1, compare);
                                                                                                                                                                     return true;
                                                                                                                                                                 }
                                                                                                                                                                 
                                                                                                                                                                 @Override
                                                                                                                                                                 public String getSymbol() {
                                                                                                                                                                     return ""; // Simple implementation for testing
                                                                                                                                                                 }
                                                                                                                                                             };
                                                                                                                                                             
                                                                                                                                                             // Test with left < right
                                                                                                                                                             Double left = 5.0;
                                                                                                                                                             Double right = 10.0;
                                                                                                                                                             
                                                                                                                                                             // Use reflection to access private compute method
                                                                                                                                                             try {
                                                                                                                                                                 Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                                 computeMethod.setAccessible(true);
                                                                                                                                                                 boolean result = (boolean) computeMethod.invoke(expr, left, right);
                                                                                                                                                                 
                                                                                                                                                                 // Verify the overall result (depends on evaluateCompare implementation)
                                                                                                                                                                 assertTrue(result);
                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                 fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                                             }
                                                                                                                                                         }

    @Test
                                                                                                                                                public void testCompute_DetectsGreaterThanMutation() {
                                                                                                                                                    // Create a test instance of the class (anonymous subclass since it's abstract)
                                                                                                                                                    CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(null) {
                                                                                                                                                        @Override
                                                                                                                                                        protected boolean evaluateCompare(int compare) {
                                                                                                                                                            // Track the comparison result
                                                                                                                                                            lastCompareResult = compare;
                                                                                                                                                            return compare == 0;
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public String getSymbol() {
                                                                                                                                                            return "test";
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        int lastCompareResult;
                                                                                                                                                    };
                                                                                                                                                    
                                                                                                                                                    // Test data where left > right
                                                                                                                                                    Double left = 5.0;
                                                                                                                                                    Double right = 3.0;
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access private compute method
                                                                                                                                                    try {
                                                                                                                                                        Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                                                        computeMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Execute the test
                                                                                                                                                        computeMethod.invoke(expr, left, right);
                                                                                                                                                        
                                                                                                                                                        // Verify the comparison result was 1 (left > right)
                                                                                                                                                        Field lastCompareField = expr.getClass().getDeclaredField("lastCompareResult");
                                                                                                                                                        lastCompareField.setAccessible(true);
                                                                                                                                                        int actualCompare = lastCompareField.getInt(expr);
                                                                                                                                                        
                                                                                                                                                        assertEquals("Comparison result should be 1 when left > right", 1, actualCompare);
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                       public void testComputeComparisonLogicDetectsMutant() throws Exception {
                                                                                                                           // Create test instance - we'll use a concrete subclass since CoreOperationRelationalExpression is abstract
                                                                                                                           class TestExpression extends CoreOperationRelationalExpression {
                                                                                                                               private int lastCompareResult;
                                                                                                                               
                                                                                                                               TestExpression(Expression[] args) {
                                                                                                                                   super(args);
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               protected boolean evaluateCompare(int compare) {
                                                                                                                                   // Track the comparison result
                                                                                                                                   lastCompareResult = compare;
                                                                                                                                   return compare == 0; // return true only if equal for this test
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               public String getSymbol() {
                                                                                                                                   return "test";
                                                                                                                               }
                                                                                                                               
                                                                                                                               public int getLastCompareResult() {
                                                                                                                                   return lastCompareResult;
                                                                                                                               }
                                                                                                                           }
                                                                                                                           
                                                                                                                           TestExpression expr = new TestExpression(new Expression[0]);
                                                                                                                           
                                                                                                                           // Get private compute method via reflection
                                                                                                                           Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                                   .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                           computeMethod.setAccessible(true);
                                                                                                                           
                                                                                                                           // Test case 1: left < right
                                                                                                                           Object left = 5.0;
                                                                                                                           Object right = 10.0;
                                                                                                                           computeMethod.invoke(expr, left, right);
                                                                                                                           assertEquals(-1, expr.getLastCompareResult());  // Should be -1 for less-than
                                                                                                                           
                                                                                                                           // Test case 2: left > right
                                                                                                                           left = 15.0;
                                                                                                                           right = 10.0;
                                                                                                                           computeMethod.invoke(expr, left, right);
                                                                                                                           assertEquals(1, expr.getLastCompareResult());  // Should be 1 for greater-than
                                                                                                                           
                                                                                                                           // Test case 3: left == right
                                                                                                                           left = 10.0;
                                                                                                                           right = 10.0;
                                                                                                                           computeMethod.invoke(expr, left, right);
                                                                                                                           assertEquals(0, expr.getLastCompareResult());  // Should be 0 for equal
                                                                                                                       }

    @Test
                                                                                                              public void testCompute_RightIteratorContainsLeft_ShouldReturnTrue1() {
                                                                                                                  // Create test objects
                                                                                                                  java.util.Iterator<Object> rightIterator = java.util.Arrays.<Object>asList("match").iterator();
                                                                                                                  Object left = "match";
                                                                                                                  
                                                                                                                  // Mock the expression class
                                                                                                                  CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                                      @Override
                                                                                                                      public String getSymbol() {
                                                                                                                          return "=="; // Dummy implementation
                                                                                                                      }
                                                                                                                      
                                                                                                                      @Override
                                                                                                                      protected boolean evaluateCompare(int compare) {
                                                                                                                          return false; // Not relevant for this test
                                                                                                                      }
                                                                                                                  };
                                                                                                                  
                                                                                                                  // Use reflection to access private compute method
                                                                                                                  try {
                                                                                                                      java.lang.reflect.Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                          .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                                      computeMethod.setAccessible(true);
                                                                                                                      
                                                                                                                      // Test the method - should return true since right iterator contains left
                                                                                                                      boolean result = (boolean) computeMethod.invoke(expr, left, rightIterator);
                                                                                                                      
                                                                                                                      // Assert - this will catch the mutant which would return false
                                                                                                                      assertTrue("Should return true when right iterator contains left", result);
                                                                                                                  } catch (Exception e) {
                                                                                                                      fail("Reflection failed: " + e.getMessage());
                                                                                                                  }
                                                                                                              }

    @Test
                                                                                                     public void testComputeWithEqualValuesDetectsMutant() throws Exception {
                                                                                                         // Create concrete subclass to test
                                                                                                         class TestExpression extends CoreOperationRelationalExpression {
                                                                                                             public TestExpression() {
                                                                                                                 super(new Expression[0]);
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             protected boolean evaluateCompare(int compare) {
                                                                                                                 return true; // default implementation for test
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             public String getSymbol() {
                                                                                                                 return "test"; // dummy implementation for test
                                                                                                             }
                                                                                                         }
                                                                                                         
                                                                                                         // Create spy of concrete class
                                                                                                         TestExpression spyExpr = spy(new TestExpression());
                                                                                                         
                                                                                                         // Mock evaluateCompare to verify parameter
                                                                                                         doReturn(true).when(spyExpr).evaluateCompare(anyInt());
                                                                                                         
                                                                                                         // Get private compute method via reflection
                                                                                                         Method computeMethod = CoreOperationRelationalExpression.class
                                                                                                                 .getDeclaredMethod("compute", Object.class, Object.class);
                                                                                                         computeMethod.setAccessible(true);
                                                                                                         
                                                                                                         // Test with equal double values
                                                                                                         Double left = 5.0;
                                                                                                         Double right = 5.0;
                                                                                                         
                                                                                                         // Call the compute method via reflection
                                                                                                         boolean result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                                                                         
                                                                                                         // Verify evaluateCompare was called with 0 (for equal values)
                                                                                                         verify(spyExpr).evaluateCompare(0);
                                                                                                         
                                                                                                         // Additional assertion to ensure the test would fail with mutant
                                                                                                         assertTrue(result);
                                                                                                     }

    @Test
                                                                                            public void testCompute_RightIteratorLeftValue_ShouldDetectMutant() throws Exception {
                                                                                                // Setup
                                                                                                CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                                                    @Override
                                                                                                    protected boolean evaluateCompare(int compare) {
                                                                                                        return false; // Not relevant for this test
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public String getSymbol() {
                                                                                                        return "test"; // Required abstract method implementation
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                // Create a mock iterator that will contain our test value
                                                                                                Iterator<?> mockIterator = mock(Iterator.class);
                                                                                                when(mockIterator.hasNext()).thenReturn(true, false);
                                                                                                when(mockIterator.next()).thenReturn("testValue");
                                                                                                
                                                                                                // Use reflection to test private compute method
                                                                                                Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                                                    "compute", Object.class, Object.class);
                                                                                                computeMethod.setAccessible(true);
                                                                                                
                                                                                                // Test
                                                                                                boolean result = (boolean) computeMethod.invoke(expr, "testValue", mockIterator);
                                                                                                
                                                                                                // Verify
                                                                                                assertTrue("Should return true when left value exists in right iterator", result);
                                                                                                
                                                                                                // Reset mock for null test
                                                                                                reset(mockIterator);
                                                                                                when(mockIterator.hasNext()).thenReturn(true, false);
                                                                                                when(mockIterator.next()).thenReturn("otherValue");
                                                                                                
                                                                                                // Test with null
                                                                                                result = (boolean) computeMethod.invoke(expr, "testValue", mockIterator);
                                                                                                assertFalse("Should return false when left value doesn't exist in right iterator", result);
                                                                                            }

    @Test
                                                                       public void testComputeDetectsArgumentOrderMutant() {
                                                                           // Create a test instance with mocked behavior
                                                                           CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[2]) {
                                                                               @Override
                                                                               protected boolean evaluateCompare(int compare) {
                                                                                   // Track the comparison result
                                                                                   return compare == -1; // Only return true if left < right
                                                                               }
                                                                               
                                                                               @Override
                                                                               public String getSymbol() {
                                                                                   return "<"; // Implement abstract method
                                                                               }
                                                                           };
                                                                           
                                                                           // Create mock expressions for args
                                                                           Expression arg0 = new Expression() {
                                                                               @Override
                                                                               public Object compute(EvalContext context) {
                                                                                   return 1;
                                                                               }
                                                                               
                                                                               @Override
                                                                               public Object computeValue(EvalContext context) {
                                                                                   return compute(context);
                                                                               }
                                                                               
                                                                               @Override
                                                                               public boolean computeContextDependent() {
                                                                                   return false;
                                                                               }
                                                                           };
                                                                           
                                                                           Expression arg1 = new Expression() {
                                                                               @Override
                                                                               public Object compute(EvalContext context) {
                                                                                   return 2;
                                                                               }
                                                                               
                                                                               @Override
                                                                               public Object computeValue(EvalContext context) {
                                                                                   return compute(context);
                                                                               }
                                                                               
                                                                               @Override
                                                                               public boolean computeContextDependent() {
                                                                                   return false;
                                                                               }
                                                                           };
                                                                           
                                                                           // Set the arguments using reflection since args is protected
                                                                           Field argsField = null;
                                                                           try {
                                                                               argsField = CoreOperationRelationalExpression.class.getSuperclass().getDeclaredField("args");
                                                                               argsField.setAccessible(true);
                                                                               argsField.set(expr, new Expression[]{arg0, arg1});
                                                                           } catch (Exception e) {
                                                                               fail("Failed to set arguments via reflection");
                                                                           }
                                                                           
                                                                           // Mock the context
                                                                           EvalContext context = mock(EvalContext.class);
                                                                           
                                                                           // The original behavior should compare 1 (left) with 2 (right)
                                                                           boolean result = (Boolean)expr.computeValue(context);
                                                                           
                                                                           // Verify the comparison direction
                                                                           // Original would evaluate 1 < 2 → true
                                                                           assertTrue("Test should detect argument order swap", result);
                                                                           
                                                                           // Additional verification that args were processed correctly
                                                                           try {
                                                                               Expression[] args = (Expression[]) argsField.get(expr);
                                                                               assertEquals(1, args[0].compute(context));
                                                                               assertEquals(2, args[1].compute(context));
                                                                           } catch (Exception e) {
                                                                               fail("Failed to verify arguments via reflection");
                                                                           }
                                                                       }

    @Test
                                                              public void testFindMatchWithIterators() throws Exception {
                                                                  // Create test class instance
                                                                  CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                      @Override
                                                                      protected boolean evaluateCompare(int compare) {
                                                                          return compare == 0; // Mock comparison to return true only for equality
                                                                      }
                                                                      
                                                                      @Override
                                                                      public String getSymbol() {
                                                                          return "==";
                                                                      }
                                                                  };
                                                                  
                                                                  // Create mock iterators with test data
                                                                  java.util.Iterator<Integer> leftIter = java.util.Arrays.asList(1, 2, 3).iterator();
                                                                  java.util.Iterator<Integer> rightIter = java.util.Arrays.asList(1, 2, 3).iterator();
                                                                  
                                                                  // Get private compute method via reflection
                                                                  java.lang.reflect.Method computeMethod = CoreOperationRelationalExpression.class
                                                                          .getDeclaredMethod("compute", Object.class, Object.class);
                                                                  computeMethod.setAccessible(true);
                                                                  
                                                                  // Test the compute method with iterators
                                                                  boolean result = (boolean) computeMethod.invoke(expr, leftIter, rightIter);
                                                                  
                                                                  // Verify the result
                                                                  assertTrue("Iterator comparison should return true for equal sequences", result);
                                                                  
                                                                  // Additional test with unequal iterators
                                                                  java.util.Iterator<Integer> rightIter2 = java.util.Arrays.asList(1, 2, 4).iterator();
                                                                  boolean result2 = (boolean) computeMethod.invoke(expr, leftIter, rightIter2);
                                                                  assertFalse("Iterator comparison should return false for unequal sequences", result2);
                                                              }

    @Test
                                                              public void testContainsMatchWithIterator() throws Exception {
                                                                  // Create test class instance
                                                                  CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                                                      @Override
                                                                      protected boolean evaluateCompare(int compare) {
                                                                          return compare == 0;
                                                                      }
                                                                      
                                                                      @Override
                                                                      public String getSymbol() {
                                                                          return "==";
                                                                      }
                                                                  };
                                                                  
                                                                  // Get private compute method via reflection
                                                                  Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                                      "compute", Object.class, Object.class);
                                                                  computeMethod.setAccessible(true);
                                                                  
                                                                  // Test containsMatch path
                                                                  java.util.Iterator<Integer> iter = java.util.Arrays.asList(1, 2, 3).iterator();
                                                                  boolean result = (boolean) computeMethod.invoke(expr, iter, 2); // Should find 2 in iterator
                                                                  assertTrue("Should find matching value in iterator", result);
                                                                  
                                                                  boolean result2 = (boolean) computeMethod.invoke(expr, iter, 4); // Should not find 4
                                                                  assertFalse("Should not find non-matching value in iterator", result2);
                                                              }

    @Test
                                                     public void testComputeWithNumericValuesDetectsReturnMutation() throws Exception {
                                                         // Create a concrete subclass for testing
                                                         class TestExpression extends CoreOperationRelationalExpression {
                                                             public TestExpression(Expression[] args) {
                                                                 super(args);
                                                             }
                                                             
                                                             @Override
                                                             protected boolean evaluateCompare(int compare) {
                                                                 return false; // Default implementation, will be mocked
                                                             }
                                                             
                                                             @Override
                                                             public String getSymbol() {
                                                                 return "test"; // Dummy implementation for testing
                                                             }
                                                         }
                                                         
                                                         // Create instance and get method references via reflection
                                                         TestExpression expr = new TestExpression(new Expression[0]);
                                                         Method computeMethod = TestExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                                         computeMethod.setAccessible(true);
                                                         Method evaluateCompareMethod = TestExpression.class.getDeclaredMethod("evaluateCompare", int.class);
                                                         evaluateCompareMethod.setAccessible(true);
                                                         
                                                         // Create spy to verify evaluateCompare calls
                                                         TestExpression spyExpr = spy(expr);
                                                         
                                                         // Mock evaluateCompare to return true for equal values (0 comparison)
                                                         doReturn(true).when(spyExpr).evaluateCompare(0);
                                                         doReturn(false).when(spyExpr).evaluateCompare(anyInt());
                                                         
                                                         // Test equal values - should call evaluateCompare(0)
                                                         Object left = 5.0;
                                                         Object right = 5.0;
                                                         boolean result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                         assertTrue(result);
                                                         verify(spyExpr).evaluateCompare(0);
                                                         
                                                         // Test unequal values - should call evaluateCompare with -1 or 1
                                                         left = 4.0;
                                                         right = 5.0;
                                                         result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                         assertFalse(result);
                                                         verify(spyExpr).evaluateCompare(-1);
                                                         
                                                         left = 5.0;
                                                         right = 4.0;
                                                         result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                         assertFalse(result);
                                                         verify(spyExpr).evaluateCompare(1);
                                                         
                                                         // Test with NaN values
                                                         left = Double.NaN;
                                                         right = 5.0;
                                                         result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                         assertFalse(result);
                                                         
                                                         left = 5.0;
                                                         right = Double.NaN;
                                                         result = (boolean) computeMethod.invoke(spyExpr, left, right);
                                                         assertFalse(result);
                                                     }

    @Test
                                            public void testComputeDetectsReturnTrueMutation() throws Exception {
                                                // Create a test instance (we'll need to extend the abstract class)
                                                CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(null) {
                                                    @Override
                                                    protected boolean evaluateCompare(int compare) {
                                                        // Original behavior - return true when comparison is equal
                                                        return compare == 0;
                                                    }
                                                    
                                                    @Override
                                                    public String getSymbol() {
                                                        return "==";
                                                    }
                                                };
                                                
                                                // Get the private compute method via reflection
                                                Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                                    "compute", Object.class, Object.class);
                                                computeMethod.setAccessible(true);
                                                
                                                // Test case where evaluateCompare should return true (equal values)
                                                Object left = 5.0;
                                                Object right = 5.0;
                                                
                                                // The original method should return true for equal values
                                                // The mutant would return false here
                                                boolean result = (boolean) computeMethod.invoke(expr, left, right);
                                                assertTrue("Method should return true for equal values", result);
                                                
                                                // Additional test cases to cover other paths
                                                // Test with Iterator case
                                                java.util.Iterator<?> it1 = java.util.Arrays.asList(1, 2, 3).iterator();
                                                java.util.Iterator<?> it2 = java.util.Arrays.asList(1, 2, 3).iterator();
                                                boolean iteratorResult = (boolean) computeMethod.invoke(expr, it1, it2);
                                                assertTrue("Method should return true for matching iterators", iteratorResult);
                                                
                                                // Test with one Iterator case
                                                java.util.Iterator<?> it3 = java.util.Arrays.asList(5).iterator();
                                                Object value = 5;
                                                boolean containsResult = (boolean) computeMethod.invoke(expr, it3, value);
                                                assertTrue("Method should return true when iterator contains value", containsResult);
                                            }

    @Test
                               public void testComputeReturnsPrimitiveBoolean() throws Exception {
                                   // Create a mock CoreOperationRelationalExpression that returns true for evaluateCompare
                                   CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                                       @Override
                                       protected boolean evaluateCompare(int compare) {
                                           return true;
                                       }
                                       
                                       @Override
                                       public String getSymbol() {
                                           return "test-symbol";
                                       }
                                   };
                                   
                                   // Use reflection to access the private compute method
                                   Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod("compute", Object.class, Object.class);
                                   computeMethod.setAccessible(true);
                                   
                                   // Test with simple numeric values that will trigger the evaluateCompare path
                                   Object result = computeMethod.invoke(expr, 5, 5);
                                   
                                   // Verify the result is exactly a primitive boolean true
                                   assertTrue(result instanceof Boolean);
                                   assertSame(Boolean.TRUE, result); // This will fail if mutated to return new Boolean(true)
                                   
                                   // Additional verification that it's not a new Boolean instance
                                   assertTrue(result == Boolean.TRUE);
                               }

    @Test
                          public void testComputeWithNaNValues() throws Exception {
                              // Create an instance of the class under test
                              CoreOperationRelationalExpression instance = new CoreOperationRelationalExpression(new Expression[0]) {
                                  @Override
                                  protected boolean evaluateCompare(int compare) {
                                      return compare == 0; // dummy implementation
                                  }
                                  
                                  @Override
                                  public String getSymbol() {
                                      return "test"; // dummy implementation
                                  }
                              };
                              
                              // Get the private compute method via reflection
                              Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                                  "compute", Object.class, Object.class);
                              computeMethod.setAccessible(true);
                              
                              // Test case 1: left is NaN
                              Object leftNaN = Double.NaN;
                              Object rightValid = 5.0;
                              boolean result1 = (boolean) computeMethod.invoke(instance, leftNaN, rightValid);
                              assertFalse("Should return false when left is NaN", result1);
                              
                              // Test case 2: right is NaN
                              Object leftValid = 10.0;
                              Object rightNaN = Double.NaN;
                              boolean result2 = (boolean) computeMethod.invoke(instance, leftValid, rightNaN);
                              assertFalse("Should return false when right is NaN", result2);
                              
                              // Test case 3: both are NaN
                              boolean result3 = (boolean) computeMethod.invoke(instance, leftNaN, rightNaN);
                              assertFalse("Should return false when both values are NaN", result3);
                          }

    @Test
                 public void testCompute_LeftNaN_ReturnsFalse() throws Exception {
                     // Create test instance - since constructor is protected, we'll use a concrete subclass
                     CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(new Expression[0]) {
                         @Override
                         protected boolean evaluateCompare(int compare) {
                             return false; // Not relevant for this test
                         }
                         
                         @Override
                         public String getSymbol() {
                             return "test-symbol"; // Required abstract method implementation
                         }
                     };
                     
                     // Create test objects
                     Object left = new Object() {
                         @Override
                         public String toString() {
                             return "NaN"; // Will cause InfoSetUtil.doubleValue() to return NaN
                         }
                     };
                     Object right = 10.0; // Any valid number
                     
                     // Use reflection to access private compute method
                     Method computeMethod = CoreOperationRelationalExpression.class.getDeclaredMethod(
                         "compute", Object.class, Object.class);
                     computeMethod.setAccessible(true);
                     
                     // Test the behavior
                     boolean result = (boolean) computeMethod.invoke(expr, left, right);
                     
                     // Assert that we get false when left is NaN
                     assertFalse("Method should return false when left parameter converts to NaN", result);
                 }

    @Test
    public void testComputeWithNonCollectionIterable() throws Exception {
        // Create a custom Iterable that's not a Collection
        Iterable<Object> customIterable = new Iterable<Object>() {
            private final List<Object> items = java.util.Arrays.asList(1, 2, 3);
            
            @Override
            public Iterator<Object> iterator() {
                return items.iterator();
            }
        };
        
        // Create a real instance of CoreOperationRelationalExpression
        CoreOperationRelationalExpression expr = new CoreOperationRelationalExpression(
            new org.apache.commons.jxpath.ri.compiler.Expression[0]) {
            @Override
            protected boolean evaluateCompare(int compare) {
                return compare == 0;
            }
            
            @Override
            public String getSymbol() {
                return "==";
            }
        };
        
        // Get private compute method via reflection
        java.lang.reflect.Method computeMethod = CoreOperationRelationalExpression.class
                .getDeclaredMethod("compute", Object.class, Object.class);
        computeMethod.setAccessible(true);
        
        // Get private reduce method via reflection
        java.lang.reflect.Method reduceMethod = CoreOperationRelationalExpression.class
                .getDeclaredMethod("reduce", Object.class);
        reduceMethod.setAccessible(true);
        
        // Mock the reduce behavior by replacing the method temporarily
        java.lang.reflect.Method originalReduce = CoreOperationRelationalExpression.class
                .getDeclaredMethod("reduce", Object.class);
        originalReduce.setAccessible(true);
        
        try {
            // Replace reduce method to return our custom iterable
            CoreOperationRelationalExpression.class.getDeclaredMethod("reduce", Object.class)
                .setAccessible(true);
            
            // Test with the custom iterable as left operand
            boolean result = (boolean) computeMethod.invoke(expr, customIterable, 2);
            assertTrue(result);
            
            // Test with custom iterable as right operand
            result = (boolean) computeMethod.invoke(expr, 2, customIterable);
            assertTrue(result);
            
            // Test with two custom iterables
            result = (boolean) computeMethod.invoke(expr, customIterable, customIterable);
            assertTrue(result);
        } finally {
            // Restore original method
            originalReduce.setAccessible(false);
        }
    }


}
