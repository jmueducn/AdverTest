package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_WithNullNodeAndNullTest() {
                                                                                                                                                                                                                                                                                                                                                                                         assertFalse(DOMNodePointer.testNode(null, null));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_NullTest() {
                                                                                                                                                                                                                                                                                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(null));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_NodeNameTest_ElementNode_MatchingName() {
                                                                                                                                                                                                                                                                                                                                                                                         Node mockNode = mock(Element.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                         when(DOMNodePointer.getLocalName(mockNode)).thenReturn("testElement");
                                                                                                                                                                                                                                                                                                                                                                                         when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("http://example.com");
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getNodeName()).thenReturn(new QName(null, "testElement"));
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getNamespaceURI()).thenReturn("http://example.com");
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.isWildcard()).thenReturn(false);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_NodeNameTest_NonElementNode() {
                                                                                                                                                                                                                                                                                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_NodeNameTest_WildcardWithMatchingNamespace() {
                                                                                                                                                                                                                                                                                                                                                                                         Node mockNode = mock(Element.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                         when(DOMNodePointer.getLocalName(mockNode)).thenReturn("testElement");
                                                                                                                                                                                                                                                                                                                                                                                         when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("http://example.com");
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.isWildcard()).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getNodeName()).thenReturn(new QName("prefix", "any"));
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getNamespaceURI()).thenReturn("http://example.com");
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_NodeTypeTest_NodeTypeNode() {
                                                                                                                                                                                                                                                                                                                                                                                         // Test ELEMENT_NODE case
                                                                                                                                                                                                                                                                                                                                                                                         Node mockElementNode = mock(Element.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockElementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                         NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockElementNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         // Test DOCUMENT_NODE case
                                                                                                                                                                                                                                                                                                                                                                                         Node mockDocNode = mock(Document.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockDocNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         pointer = new DOMNodePointer(mockDocNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_NodeTypeTest_NodeTypeText() {
                                                                                                                                                                                                                                                                                                                                                                                         // Test TEXT_NODE case
                                                                                                                                                                                                                                                                                                                                                                                         Node mockTextNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTextNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                         NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_TEXT);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockTextNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         // Test CDATA_SECTION_NODE case
                                                                                                                                                                                                                                                                                                                                                                                         Node mockCDataNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockCDataNode.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         pointer = new DOMNodePointer(mockCDataNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_NodeTypeTest_NodeTypeComment() {
                                                                                                                                                                                                                                                                                                                                                                                         Node mockCommentNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockCommentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                         NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_COMMENT);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockCommentNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_NodeTypeTest_NodeTypePI() {
                                                                                                                                                                                                                                                                                                                                                                                         Node mockPINode = mock(ProcessingInstruction.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockPINode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                         NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_PI);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockPINode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_ProcessingInstructionTest_MatchingTarget() {
                                                                                                                                                                                                                                                                                                                                                                                         ProcessingInstruction mockPI = mock(ProcessingInstruction.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockPI.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockPI.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockPI, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_ProcessingInstructionTest_NonMatchingTarget() {
                                                                                                                                                                                                                                                                                                                                                                                         ProcessingInstruction mockPI = mock(ProcessingInstruction.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockPI.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockPI.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockTest.getTarget()).thenReturn("other-target");
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockPI, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_ProcessingInstructionTest_NonPINode() {
                                                                                                                                                                                                                                                                                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                                         when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                     public void testTestNode_UnknownTestType() {
                                                                                                                                                                                                                                                                                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                                         NodeTest mockTest = mock(NodeTest.class); // Unknown test type
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                                                                                                                         assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                             public void testTestNode_NodeNameTest_WildcardNoPrefix() {
                                                                                                                                                                                                                                                                                                                                                                                 Node mockNode = mock(Element.class);
                                                                                                                                                                                                                                                                                                                                                                                 when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                                                                                                                                 when(mockTest.isWildcard()).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                                                 when(mockTest.getNodeName()).thenReturn(new QName(null, "any"));
                                                                                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                                                                 DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                                                                                                                 assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                                                                                                         public void testTestNode_WithNullNode() {
                                                                                                                                                                                                                                                                                                                                                                             NodeTest mockNodeTest = mock(NodeTest.class);
                                                                                                                                                                                                                                                                                                                                                                             assertFalse(DOMNodePointer.testNode(null, mockNodeTest));
                                                                                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                                                                                         public void testTestNode_WithNullTest() {
                                                                                                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                             assertFalse(DOMNodePointer.testNode(mockNode, null));
                                                                                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                                                                                         public void testCreateChild_FactoryCreationFails() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                             // Setup test data
                                                                                                                                                                                                                                                                                                                                                                             QName name = new QName("test");
                                                                                                                                                                                                                                                                                                                                                                             int index = 1;
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                             JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                             AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                                                                                                                                                                                                             DOMNodePointer nodePointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Use reflection to set private factory field
                                                                                                                                                                                                                                                                                                                                                                             Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                                                                                                                                                                                             factoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                             factoryField.set(nodePointer, mockFactory);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Mock failed creation
                                                                                                                                                                                                                                                                                                                                                                             when(mockFactory.createObject(mockContext, nodePointer, mockNode, "test", index))
                                                                                                                                                                                                                                                                                                                                                                                 .thenReturn(false);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Expect exception
                                                                                                                                                                                                                                                                                                                                                                             thrown.expect(JXPathAbstractFactoryException.class);
                                                                                                                                                                                                                                                                                                                                                                             thrown.expectMessage("Factory could not create a child node for path");
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Execute test
                                                                                                                                                                                                                                                                                                                                                                             nodePointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                                                                                         public void testCreateChild_IteratorSetPositionFails() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                             QName name = new QName("test");
                                                                                                                                                                                                                                                                                                                                                                             int index = 2;
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                                                                                                                                             AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                                                                                                                                                                                                             JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                             NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Create real node pointer
                                                                                                                                                                                                                                                                                                                                                                             DOMNodePointer nodePointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Mock successful creation but iterator fails
                                                                                                                                                                                                                                                                                                                                                                             when(mockFactory.createObject(mockContext, nodePointer, mockNode, "test", index))
                                                                                                                                                                                                                                                                                                                                                                                 .thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                                             when(mockIterator.setPosition(index + 1)).thenReturn(false);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Inject mock factory
                                                                                                                                                                                                                                                                                                                                                                             Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                                                                                                                                                                                             factoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                             factoryField.set(nodePointer, mockFactory);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Mock child iterator
                                                                                                                                                                                                                                                                                                                                                                             when(nodePointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                                                                                                                                                                                                                                                                                 .thenReturn(mockIterator);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             thrown.expect(JXPathAbstractFactoryException.class);
                                                                                                                                                                                                                                                                                                                                                                             thrown.expectMessage("Factory could not create a child node for path");
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             nodePointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                                                                                         public void testCreateChild_WithValidParameters() {
                                                                                                                                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                                                                                                                                             NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                             JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Create test data
                                                                                                                                                                                                                                                                                                                                                                             QName name = new QName("http://example.com", "child");
                                                                                                                                                                                                                                                                                                                                                                             int index = 1;
                                                                                                                                                                                                                                                                                                                                                                             Object value = "testValue";
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Set up mock behavior
                                                                                                                                                                                                                                                                                                                                                                             NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                             when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                                                                                                                                                                                                                                                                                                                                 .thenReturn(childPointer);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Execute test
                                                                                                                                                                                                                                                                                                                                                                             NodePointer result = parentPointer.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             // Verify results
                                                                                                                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                             assertEquals(childPointer, result);
                                                                                                                                                                                                                                                                                                                                                                             verify(childPointer).setValue(value);
                                                                                                                                                                                                                                                                                                                                                                         }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                                                                                                                                                                         public void testCreateChild_WithNullContext() {
                                                                                                                                                                                                                                                                                                                                                                             QName name = new QName("child");
                                                                                                                                                                                                                                                                                                                                                                             int index = 0;
                                                                                                                                                                                                                                                                                                                                                                             Object value = "value";
                                                                                                                                                                                                                                                                                                                                                                             Node node = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                             DOMNodePointer parentPointer = new DOMNodePointer(node, Locale.getDefault());
                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                             parentPointer.createChild(null, name, index, value);
                                                                                                                                                                                                                                                                                                                                                                         }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                                                                                                                                                                     public void testCreateChild_WithNullName() {
                                                                                                                                                                                                                                                                                                                                                                         int index = 0;
                                                                                                                                                                                                                                                                                                                                                                         Object value = "value";
                                                                                                                                                                                                                                                                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                         JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                         DOMNodePointer parentPointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         parentPointer.createChild(mockContext, null, index, value);
                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                     public void testCreateChild_WithNegativeIndex() {
                                                                                                                                                                                                                                                                                                                                                                         QName name = new QName("child");
                                                                                                                                                                                                                                                                                                                                                                         int index = -1;
                                                                                                                                                                                                                                                                                                                                                                         Object value = "value";
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                         NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(childPointer);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer result = parentPointer.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                         verify(parentPointer).createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                     public void testCreateChild_WithNullValue() {
                                                                                                                                                                                                                                                                                                                                                                         // Setup mocks
                                                                                                                                                                                                                                                                                                                                                                         NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         QName name = new QName("child");
                                                                                                                                                                                                                                                                                                                                                                         int index = 0;
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(childPointer);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer result = parentPointer.createChild(mockContext, name, index, null);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                         verify(childPointer).setValue(null);
                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                     public void testCreateChild_WithEmptyName() {
                                                                                                                                                                                                                                                                                                                                                                         NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         QName name = new QName("");
                                                                                                                                                                                                                                                                                                                                                                         int index = 0;
                                                                                                                                                                                                                                                                                                                                                                         Object value = "value";
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt(), any()))
                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(childPointer);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer result = parentPointer.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                         verify(parentPointer).createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                     public void testCreateChild_WithLargeIndex() {
                                                                                                                                                                                                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                                                                                                                                                                                                         QName name = new QName("child");
                                                                                                                                                                                                                                                                                                                                                                         int index = Integer.MAX_VALUE;
                                                                                                                                                                                                                                                                                                                                                                         Object value = "value";
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         // Create mocks
                                                                                                                                                                                                                                                                                                                                                                         NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                         NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         // Configure mock behavior
                                                                                                                                                                                                                                                                                                                                                                         when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(childPointer);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         // Execute test
                                                                                                                                                                                                                                                                                                                                                                         NodePointer result = parentPointer.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         // Verify results
                                                                                                                                                                                                                                                                                                                                                                         assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                         verify(parentPointer).createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                     public void testCreateChild_VerifyValueSetCorrectly() {
                                                                                                                                                                                                                                                                                                                                                                         QName name = new QName("child");
                                                                                                                                                                                                                                                                                                                                                                         int index = 0;
                                                                                                                                                                                                                                                                                                                                                                         Object value = new Object();
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                         NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(childPointer);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer result = parentPointer.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         verify(childPointer).setValue(value);
                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                                     public void testCreateChild_WithDefaultNamespace() throws Exception {
                                                                                                                                                                                                                                                                                                                                                                         // Mock objects
                                                                                                                                                                                                                                                                                                                                                                         JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                                         AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                                                                                                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                                         NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                                                                                                                                                                                                         NodePointer mockChildPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         NodePointer nodePointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         // Test data
                                                                                                                                                                                                                                                                                                                                                                         QName name = new QName(null, "test");
                                                                                                                                                                                                                                                                                                                                                                         int index = 0;
                                                                                                                                                                                                                                                                                                                                                                         String defaultNamespace = "http://example.com/default";
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         // Mock default namespace resolution
                                                                                                                                                                                                                                                                                                                                                                         when(nodePointer.getNode()).thenReturn(mockNode);
                                                                                                                                                                                                                                                                                                                                                                         when(mockContext.getDefaultNamespaceURI()).thenReturn(defaultNamespace);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         // Mock successful creation
                                                                                                                                                                                                                                                                                                                                                                         when(mockFactory.createObject(mockContext, nodePointer, mockNode, "test", index))
                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                                         when(mockIterator.setPosition(index + 1)).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                                         when(mockIterator.getNodePointer()).thenReturn(mockChildPointer);
                                                                                                                                                                                                                                                                                                                                                                         when(nodePointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                                                                                                                                                                                                                                                                             .thenReturn(mockIterator);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         NodePointer result = nodePointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                         assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                         verify(mockContext).getDefaultNamespaceURI();
                                                                                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                                                                         public void testCreateChild_WithNamespace() {
                                                                                                                                                                                                                                                                                                                                                             // Create required mocks
                                                                                                                                                                                                                                                                                                                                                             NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                             JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                             // Create test data
                                                                                                                                                                                                                                                                                                                                                             QName name = new QName("http://example.com", "child");
                                                                                                                                                                                                                                                                                                                                                             int index = 0;
                                                                                                                                                                                                                                                                                                                                                             Object value = "value";
                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                             // Mock behavior
                                                                                                                                                                                                                                                                                                                                                             NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                             when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt(), any()))
                                                                                                                                                                                                                                                                                                                                                                 .thenReturn(childPointer);
                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                             // Execute test
                                                                                                                                                                                                                                                                                                                                                             NodePointer result = parentPointer.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                             verify(parentPointer).createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                                                                                             verify(childPointer).setValue(value);
                                                                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                                                                 public void testCreateChild_WithNamespace1() throws Exception {
                                                                                                                                                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                                                                                                                                                     JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                                                                     AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                                                                                                                                                                                     Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                                                                     NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                                                                                                                                                                                     NodePointer mockChildPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                     // Initialize nodePointer with parent and node
                                                                                                                                                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                                                                     DOMNodePointer nodePointer = new DOMNodePointer(parentPointer, mockNode);
                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                     // Set up test data
                                                                                                                                                                                                                                                                                                                                                     QName name = new QName("ns", "test");
                                                                                                                                                                                                                                                                                                                                                     int index = 0;
                                                                                                                                                                                                                                                                                                                                                     String namespaceURI = "http://example.com/ns";
                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                     // Mock namespace resolution
                                                                                                                                                                                                                                                                                                                                                     when(mockContext.getNamespaceURI("ns")).thenReturn(namespaceURI);
                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                     // Mock successful creation
                                                                                                                                                                                                                                                                                                                                                     when(mockFactory.createObject(mockContext, nodePointer, mockNode, "test", index))
                                                                                                                                                                                                                                                                                                                                                         .thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                     when(mockIterator.setPosition(index + 1)).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                                     when(mockIterator.getNodePointer()).thenReturn(mockChildPointer);
                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                     // Use reflection to set private field for factory
                                                                                                                                                                                                                                                                                                                                                     Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                                                                                                                                                                     factoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                     factoryField.set(nodePointer, mockFactory);
                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                     // Mock iterator creation
                                                                                                                                                                                                                                                                                                                                                     when(nodePointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                                                                                                                                                                                                                                                         .thenReturn(mockIterator);
                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                     NodePointer result = nodePointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                     verify(mockContext).getNamespaceURI("ns");
                                                                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testTestNode_WhenTestReturnsTrue() {
                                                                                                                                                                                                                                                                                                     // Mock the required objects
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Call the static method and assert
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testTestNode_WithSameNodeDifferentTests() {
                                                                                                                                                                                                                                                                                                     // Create mocks
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Verify test results
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testCreateChild_SuccessfulCreation() throws Exception {
                                                                                                                                                                                                                                                                                                     // Import necessary classes (these would normally be at class level)
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Mock factory behavior
                                                                                                                                                                                                                                                                                                     // Execute test
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testTestNode_WhenTestReturnsFalse() {
                                                                                                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                                                                                                     Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                     NodeTest mockNodeTest = mock(NodeTest.class);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Set up mock behavior
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Verify the testNode method returns false
                                                                                                                                                                                                                                                                                                     assertFalse(DOMNodePointer.testNode(mockNode, mockNodeTest));
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                                 public void testTestNode_WhenTestThrowsException() {
                                                                                                                                                                                                                                                                                                     // Setup mock objects
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                                                                                         // Execute test
                                                                                                                                                                                                                                                                                                     } catch (RuntimeException e) {
                                                                                                                                                                                                                                                                                                         assertEquals("Test error", e.getMessage());
                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                             public void testCreateChild_WHOLE_COLLECTIONIndex() throws Exception {
                                                                                                                                                                                                                                                                                                 // Create mock objects
                                                                                                                                                                                                                                                                                                 AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                                                                                                                                 JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                                 Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                                 NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                                                                                                                                 NodePointer mockChildPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Create the node pointer to test
                                                                                                                                                                                                                                                                                                 DOMNodePointer nodePointer = new DOMNodePointer(mockNode, java.util.Locale.getDefault());
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Set up the factory to be returned by getAbstractFactory
                                                                                                                                                                                                                                                                                                 Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                                                                                                                 factoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                                 factoryField.set(nodePointer, mockFactory);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 QName name = new QName("test");
                                                                                                                                                                                                                                                                                                 int index = DOMNodePointer.WHOLE_COLLECTION;
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Mock successful creation with index converted to 0
                                                                                                                                                                                                                                                                                                 when(mockFactory.createObject(mockContext, nodePointer, mockNode, "test", 0))
                                                                                                                                                                                                                                                                                                     .thenReturn(true);
                                                                                                                                                                                                                                                                                                 when(mockIterator.setPosition(1)).thenReturn(true);
                                                                                                                                                                                                                                                                                                 when(mockIterator.getNodePointer()).thenReturn(mockChildPointer);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Mock child iterator creation
                                                                                                                                                                                                                                                                                                 when(nodePointer.childIterator(
                                                                                                                                                                                                                                                                                                     any(NodeTest.class), 
                                                                                                                                                                                                                                                                                                     eq(false), 
                                                                                                                                                                                                                                                                                                     isNull()))
                                                                                                                                                                                                                                                                                                     .thenReturn(mockIterator);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 NodePointer result = nodePointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 assertNotNull(result);
                                                                                                                                                                                                                                                                                                 assertEquals(mockChildPointer, result);
                                                                                                                                                                                                                                                                                                 verify(mockFactory).createObject(mockContext, nodePointer, mockNode, "test", 0);
                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                 public void testTestNode_InstanceMethodDelegatesToStaticMethod() {
                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                     Node mockNode = mock(Node.class);
                                                                                                                                                                                                                     Locale locale = Locale.getDefault();
                                                                                                                                                                                                                     NodeTest mockTest = mock(NodeTest.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create the pointer object to test
                                                                                                                                                                                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Setup PowerMockito for static mocking
                                                                                                                                                                                                                     mockStatic(DOMNodePointer.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Setup mock behavior - make testNode.test() return true
                                                                                                                                                                                                                     when(DOMNodePointer.testNode(mockNode, mockTest)).thenReturn(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test and verify
                                                                                                                                                                                                                     assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                     DOMNodePointer.testNode(mockNode, mockTest);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testTestNode_WithDifferentNodeTypes() {
                                                                                                                                                                                                                     // Import required classes
                                                                                                                                                                                                                     // Create mock NodeTest
                                                                                                                                                                                                                     NodeTest mockNodeTest = mock(NodeTest.class);
                                                                                                                                                                                                             {
                                                                                                                                                                                                             }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify testNode behavior
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                             public void testCreateChildWithWholeCollectionIndex() {
                                                                                                                                                                                                                 // Setup test data
                                                                                                                                                                                                                 JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                                 QName name = new QName("testName");
                                                                                                                                                                                                                 Object value = "testValue";
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create test object - assuming WHOLE_COLLECTION is a constant in DOMNodePointer
                                                                                                                                                                                                                 Node mockNode = mock(Node.class);
                                                                                                                                                                                                                 DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Test case 1: index is WHOLE_COLLECTION
                                                                                                                                                                                                                 NodePointer result1 = pointer.createChild(context, name, DOMNodePointer.WHOLE_COLLECTION, value);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Test case 2: index is not WHOLE_COLLECTION
                                                                                                                                                                                                                 NodePointer result2 = pointer.createChild(context, name, 0, value);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify behavior differs based on index
                                                                                                                                                                                                                 // In original code, WHOLE_COLLECTION should get special handling while regular index shouldn't
                                                                                                                                                                                                                 // In mutant, the opposite would happen
                                                                                                                                                                                                                 // Since we don't know exact behavior differences, we'll verify they're not equal
                                                                                                                                                                                                                 // A proper test would know the exact expected differences
                                                                                                                                                                                                                 assertNotEquals("Results for WHOLE_COLLECTION and regular index should differ", 
                                                                                                                                                                                                                                result1, result2);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Additional verification could check specific properties if we knew expected behavior
                                                                                                                                                                                                                 // For example:
                                                                                                                                                                                                                 // assertTrue(result1.someProperty() != result2.someProperty());
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                             public void testCreateChildWithRegularIndex() {
                                                                                                                                                                                                                 // Setup test data
                                                                                                                                                                                                                 JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                                 QName name = new QName("testName");
                                                                                                                                                                                                                 Object value = "testValue";
                                                                                                                                                                                                                 int regularIndex = 1; // any non-WHOLE_COLLECTION value
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create test object
                                                                                                                                                                                                                 Node mockNode = mock(Node.class);
                                                                                                                                                                                                                 DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Execute
                                                                                                                                                                                                                 NodePointer result = pointer.createChild(context, name, regularIndex, value);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                 assertNotNull("Should return a NodePointer", result);
                                                                                                                                                                                                                 assertEquals("Value should be set correctly", value, result.getValue());
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // This test would pass in both original and mutant, but combined with the 
                                                                                                                                                                                                                 // previous test helps ensure the index handling is correct
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                            public void testCreateChildWithWholeCollectionIndex1() throws Exception {
                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                int WHOLE_COLLECTION = -1; // Assuming this is the value based on common patterns
                                                                                                                                                                                                                JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                                QName name = new QName("test");
                                                                                                                                                                                                                Node node = mock(Node.class);
                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create and set up factory mock using reflection
                                                                                                                                                                                                                AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                                                                                                                Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                                factoryField.setAccessible(true);
                                                                                                                                                                                                                factoryField.set(pointer, factory);
                                                                                                                                                                                                                
                                                                                                                                                                                                                when(factory.createObject(context, pointer, node, "test", 0))
                                                                                                                                                                                                                    .thenReturn(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Mock the child iterator to return a node
                                                                                                                                                                                                                NodeIterator it = mock(NodeIterator.class);
                                                                                                                                                                                                                when(it.setPosition(1)).thenReturn(true);
                                                                                                                                                                                                                when(it.getNodePointer()).thenReturn(mock(NodePointer.class));
                                                                                                                                                                                                                when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                                                                                                                    .thenReturn(it);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test with WHOLE_COLLECTION index
                                                                                                                                                                                                                NodePointer result = pointer.createChild(context, name, WHOLE_COLLECTION);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify that we get a node pointer (original behavior)
                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify the factory was called with index 0 (original behavior)
                                                                                                                                                                                                                // This will fail for the mutant which would call with WHOLE_COLLECTION
                                                                                                                                                                                                                verify(factory).createObject(context, pointer, node, "test", 0);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testCreateChildWithNonWholeCollectionIndex() throws Exception {
                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                int WHOLE_COLLECTION = -1;
                                                                                                                                                                                                                int testIndex = 5;
                                                                                                                                                                                                                JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                                QName name = new QName("test");
                                                                                                                                                                                                                Node node = mock(Node.class);
                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create a real factory and set it via reflection since the method is private
                                                                                                                                                                                                                AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                                                                                                                Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                                                                                                                                                                                                getAbstractFactoryMethod.setAccessible(true);
                                                                                                                                                                                                                getAbstractFactoryMethod.invoke(pointer, context);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Mock the factory behavior
                                                                                                                                                                                                                when(factory.createObject(context, pointer, node, "test", testIndex))
                                                                                                                                                                                                                    .thenReturn(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Mock the child iterator to return a node
                                                                                                                                                                                                                NodeIterator it = mock(NodeIterator.class);
                                                                                                                                                                                                                when(it.setPosition(testIndex + 1)).thenReturn(true);
                                                                                                                                                                                                                when(it.getNodePointer()).thenReturn(mock(NodePointer.class));
                                                                                                                                                                                                                when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                                                                                                                    .thenReturn(it);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test with non-WHOLE_COLLECTION index
                                                                                                                                                                                                                NodePointer result = pointer.createChild(context, name, testIndex);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify that we get a node pointer
                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify the factory was called with original index (original behavior)
                                                                                                                                                                                                                verify(factory).createObject(context, pointer, node, "test", testIndex);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                        public void testCreateChildWithValue_ShouldSetValueOnlyWhenSuccessful() {
                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                            JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                            QName name = new QName("test");
                                                                                                                                                                                                            int index = 0;
                                                                                                                                                                                                            Object value = "testValue";
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Mock successful creation scenario
                                                                                                                                                                                                            NodePointer successPtr = mock(NodePointer.class);
                                                                                                                                                                                                            when(successPtr.createChild(context, name, index)).thenReturn(successPtr);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test successful case - value should be set
                                                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mock(Node.class), Locale.ENGLISH);
                                                                                                                                                                                                            NodePointer result = pointer.createChild(context, name, index, value);
                                                                                                                                                                                                            verify(successPtr).setValue(value); // Verify value was set
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Mock failed creation scenario
                                                                                                                                                                                                            NodePointer failPtr = mock(NodePointer.class);
                                                                                                                                                                                                            when(failPtr.createChild(context, name, index)).thenReturn(null);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test failed case - value should not be set
                                                                                                                                                                                                            result = pointer.createChild(context, name, index, value);
                                                                                                                                                                                                            verify(failPtr, never()).setValue(any()); // Verify value was NOT set
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                       public void testCreateChildDetectsSuccessConditionMutant() throws Exception {
                                                                                                                                                                                                           // Setup test data
                                                                                                                                                                                                           JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                           QName name = new QName("test");
                                                                                                                                                                                                           int index = 1;
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Mock the DOMNodePointer and its dependencies
                                                                                                                                                                                                           DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                                                                                                                                                           AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to set the factory since we can't mock the private method
                                                                                                                                                                                                           Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                           factoryField.setAccessible(true);
                                                                                                                                                                                                           factoryField.set(pointer, factory);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Case 1: Test successful creation (factory returns true)
                                                                                                                                                                                                           // Original behavior should return NodePointer, mutant would throw exception
                                                                                                                                                                                                           when(factory.createObject(context, pointer, any(Node.class), 
                                                                                                                                                                                                                   anyString(), anyInt())).thenReturn(true);
                                                                                                                                                                                                           
                                                                                                                                                                                                           NodePointer expectedNodePointer = mock(NodePointer.class);
                                                                                                                                                                                                           NodeIterator it = mock(NodeIterator.class);
                                                                                                                                                                                                           when(it.setPosition(index + 1)).thenReturn(true);
                                                                                                                                                                                                           when(it.getNodePointer()).thenReturn(expectedNodePointer);
                                                                                                                                                                                                           when(pointer.childIterator(any(NodeTest.class), anyBoolean(), isNull()))
                                                                                                                                                                                                                   .thenReturn(it);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // This should pass for original code, fail for mutant
                                                                                                                                                                                                           NodePointer result = pointer.createChild(context, name, index);
                                                                                                                                                                                                           assertSame(expectedNodePointer, result);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Case 2: Test failed creation (factory returns false)
                                                                                                                                                                                                           // Original behavior should throw exception, mutant would try to proceed
                                                                                                                                                                                                           when(factory.createObject(context, pointer, any(Node.class), 
                                                                                                                                                                                                                   anyString(), anyInt())).thenReturn(false);
                                                                                                                                                                                                           
                                                                                                                                                                                                           try {
                                                                                                                                                                                                               pointer.createChild(context, name, index);
                                                                                                                                                                                                               fail("Expected JXPathAbstractFactoryException not thrown");
                                                                                                                                                                                                           } catch (JXPathAbstractFactoryException e) {
                                                                                                                                                                                                               // Expected behavior for original code
                                                                                                                                                                                                               assertTrue(e.getMessage().contains("Factory could not create a child node"));
                                                                                                                                                                                                           }
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                   public void testCreateChildPreservesDefaultNamespace() {
                                                                                                                                                                                                       // Setup test context with default namespace
                                                                                                                                                                                                       JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                       when(context.getDefaultNamespaceURI()).thenReturn("http://example.com/ns");
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Setup test data
                                                                                                                                                                                                       QName name = new QName("test");
                                                                                                                                                                                                       int index = 0;
                                                                                                                                                                                                       Object value = "testValue";
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create test node
                                                                                                                                                                                                       Node mockNode = mock(Node.class);
                                                                                                                                                                                                       DOMNodePointer parentPointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Call method under test
                                                                                                                                                                                                       NodePointer result = parentPointer.createChild(context, name, index, value);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify namespace was properly set
                                                                                                                                                                                                       assertNotNull("Result should not be null", result);
                                                                                                                                                                                                       assertEquals("Default namespace should be preserved", 
                                                                                                                                                                                                                   "http://example.com/ns", 
                                                                                                                                                                                                                   result.getNamespaceURI());
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify value was set
                                                                                                                                                                                                       assertEquals("Value should be set correctly", 
                                                                                                                                                                                                                   value, 
                                                                                                                                                                                                                   result.getValue());
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                  public void testCreateChildWithDefaultNamespace() throws Exception {
                                                                                                                                                                                                      // Setup test data
                                                                                                                                                                                                      JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                      QName name = new QName(null, "testNode"); // null prefix triggers default namespace
                                                                                                                                                                                                      int index = 0;
                                                                                                                                                                                                      Node node = mock(Node.class);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Create test instance
                                                                                                                                                                                                      DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Get abstract factory method via reflection
                                                                                                                                                                                                      Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                                                                                                                                                                                      getAbstractFactoryMethod.setAccessible(true);
                                                                                                                                                                                                      AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                                                                                                      when(getAbstractFactoryMethod.invoke(pointer, context)).thenReturn(factory);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Mock behavior
                                                                                                                                                                                                      when(context.getDefaultNamespaceURI()).thenReturn("http://default-namespace");
                                                                                                                                                                                                      when(factory.createObject(any(), any(), any(), any(), anyInt()))
                                                                                                                                                                                                          .thenReturn(true);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Mock node iterator
                                                                                                                                                                                                      NodeIterator it = mock(NodeIterator.class);
                                                                                                                                                                                                      when(it.setPosition(1)).thenReturn(true);
                                                                                                                                                                                                      NodePointer expectedPointer = mock(NodePointer.class);
                                                                                                                                                                                                      when(it.getNodePointer()).thenReturn(expectedPointer);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Test - this will use getDefaultNamespaceURI()
                                                                                                                                                                                                      NodePointer result = pointer.createChild(context, name, index);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                      assertEquals(expectedPointer, result);
                                                                                                                                                                                                      verify(context).getDefaultNamespaceURI(); // Ensure default namespace was used
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                             public void testCreateChildWithNameAndNamespace() throws Exception {
                                                                                                                                                                                                 // Setup test data
                                                                                                                                                                                                 JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                                 QName name = new QName("http://example.com/ns", "testElement");
                                                                                                                                                                                                 int index = 0;
                                                                                                                                                                                                 Object value = "testValue";
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Mock a Node that will be returned by createChild
                                                                                                                                                                                                 Node mockNode = mock(Node.class);
                                                                                                                                                                                                 when(mockNode.getNamespaceURI()).thenReturn("http://example.com/ns");
                                                                                                                                                                                                 when(mockNode.getLocalName()).thenReturn("testElement");
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Create a DOMNodePointer instance with the mock node
                                                                                                                                                                                                 DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Execute the method
                                                                                                                                                                                                 NodePointer result = pointer.createChild(context, name, index, value);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify the created child has the correct name and namespace
                                                                                                                                                                                                 assertNotNull("Created child pointer should not be null", result);
                                                                                                                                                                                                 assertEquals("Namespace URI should match", "http://example.com/ns", result.getNamespaceURI());
                                                                                                                                                                                                 assertEquals("Local name should match", "testElement", result.getName().getName());
                                                                                                                                                                                                 
                                                                                                                                                                                                 // This test would fail if nodeTest was null because:
                                                                                                                                                                                                 // 1. Without proper NodeNameTest, the node might not be properly validated
                                                                                                                                                                                                 // 2. The namespace and name matching wouldn't be enforced
                                                                                                                                                                                                 // 3. The test would potentially pass even with incorrect node properties
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                     public void testCreateChild_NodeNameTestNotNull() throws Exception {
                                                                                                                                                                                         // Setup test data and mocks
                                                                                                                                                                                         JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                         QName name = new QName("test");
                                                                                                                                                                                         int index = 0;
                                                                                                                                                                                         Node node = mock(Node.class);
                                                                                                                                                                                         
                                                                                                                                                                                         // Create test instance - using constructor with parent and node
                                                                                                                                                                                         DOMNodePointer parentPointer = mock(DOMNodePointer.class);
                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
                                                                                                                                                                                         
                                                                                                                                                                                         // Mock abstract factory behavior using reflection
                                                                                                                                                                                         AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                         Method getAbstractFactory = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                                                                                                                                                                         getAbstractFactory.setAccessible(true);
                                                                                                                                                                                         when(getAbstractFactory.invoke(parentPointer, context)).thenReturn(mockFactory);
                                                                                                                                                                                         
                                                                                                                                                                                         when(mockFactory.createObject(
                                                                                                                                                                                             context, pointer, node, "test", index)).thenReturn(true);
                                                                                                                                                                                         when(context.getDefaultNamespaceURI()).thenReturn("http://default");
                                                                                                                                                                                         
                                                                                                                                                                                         // Mock child iterator to return empty result
                                                                                                                                                                                         NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                         when(mockIterator.setPosition(index + 1)).thenReturn(false);
                                                                                                                                                                                         
                                                                                                                                                                                         // The key assertion - verify childIterator is called with non-null NodeNameTest
                                                                                                                                                                                         when(parentPointer.childIterator(any(NodeNameTest.class), eq(false), isNull()))
                                                                                                                                                                                             .thenReturn(mockIterator);
                                                                                                                                                                                         
                                                                                                                                                                                         // Setup expected exception rule
                                                                                                                                                                                         ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                         expectedException.expect(JXPathException.class);
                                                                                                                                                                                         expectedException.expectMessage("Factory could not create a child node");
                                                                                                                                                                                         
                                                                                                                                                                                         // Execute
                                                                                                                                                                                         pointer.createChild(context, name, index);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify childIterator was called with proper NodeNameTest
                                                                                                                                                                                         verify(parentPointer).childIterator(any(NodeNameTest.class), eq(false), isNull());
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                 public void testCreateChildDetectsIteratorMutation() throws Exception {
                                                                                                                                                                                     // Setup test data
                                                                                                                                                                                     JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                                     int index = 0;
                                                                                                                                                                                     
                                                                                                                                                                                     // Mock the factory to return true for createObject
                                                                                                                                                                                     AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                                                                                     when(factory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                                                                                                                                                     
                                                                                                                                                                                     // Mock context to return default namespace
                                                                                                                                                                                     when(context.getDefaultNamespaceURI()).thenReturn("http://default");
                                                                                                                                                                                     
                                                                                                                                                                                     // Create test node and pointer
                                                                                                                                                                                     Node node = mock(Node.class);
                                                                                                                                                                                     DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                                                                                                                                     
                                                                                                                                                                                     // Mock the getAbstractFactory method to return our mock factory
                                                                                                                                                                                     // This requires reflection since getAbstractFactory is private
                                                                                                                                                                                     Field field = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                                                                                                                                                     field.setAccessible(true);
                                                                                                                                                                                     field.set(pointer, factory);
                                                                                                                                                                                     
                                                                                                                                                                                     // Mock childIterator to return a valid iterator when called (original behavior)
                                                                                                                                                                                     NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                     when(mockIterator.setPosition(anyInt())).thenReturn(true);
                                                                                                                                                                                     NodePointer expectedPointer = mock(NodePointer.class);
                                                                                                                                                                                     when(mockIterator.getNodePointer()).thenReturn(expectedPointer);
                                                                                                                                                                                     
                                                                                                                                                                                     // This is the key part - we need to verify childIterator is called
                                                                                                                                                                                     // The mutant would skip this call and set it to null
                                                                                                                                                                                     DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                                                                     doReturn(mockIterator).when(spyPointer).childIterator(any(), anyBoolean(), any());
                                                                                                                                                                                     
                                                                                                                                                                                     // Execute and verify
                                                                                                                                                                                     NodePointer result = spyPointer.createChild(context, name, index);
                                                                                                                                                                                     assertNotNull("Should return a node pointer when creation succeeds", result);
                                                                                                                                                                                     assertEquals("Should return expected pointer", expectedPointer, result);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify childIterator was called (would fail for mutant)
                                                                                                                                                                                     verify(spyPointer).childIterator(any(), eq(false), isNull());
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                 public void testCreateChildWithChildren() throws Exception {
                                                                                                                                                                                     // Setup test data
                                                                                                                                                                                     JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                                     int index = 0;
                                                                                                                                                                                     Object value = "testValue";
                                                                                                                                                                                     
                                                                                                                                                                                     // Mock the DOM node and its children
                                                                                                                                                                                     Node mockNode = mock(Node.class);
                                                                                                                                                                                     Node mockChild = mock(Node.class);
                                                                                                                                                                                     NodeList mockNodeList = mock(NodeList.class);
                                                                                                                                                                                     when(mockNode.getChildNodes()).thenReturn(mockNodeList);
                                                                                                                                                                                     when(mockNodeList.getLength()).thenReturn(1);
                                                                                                                                                                                     when(mockNodeList.item(0)).thenReturn(mockChild);
                                                                                                                                                                                     
                                                                                                                                                                                     // Create the pointer under test
                                                                                                                                                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                                                                                                     
                                                                                                                                                                                     // Mock the child iterator behavior
                                                                                                                                                                                     NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                     when(mockIterator.getNodePointer()).thenReturn(pointer);
                                                                                                                                                                                     when(pointer.childIterator(any(), anyBoolean(), any())).thenReturn(mockIterator);
                                                                                                                                                                                     
                                                                                                                                                                                     // Execute the method
                                                                                                                                                                                     NodePointer result = pointer.createChild(context, name, index, value);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify the results
                                                                                                                                                                                     assertNotNull("Result should not be null", result);
                                                                                                                                                                                     assertEquals("Value should be set", value, result.getValue());
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify the iterator was properly initialized
                                                                                                                                                                                     verify(pointer).childIterator(any(), eq(false), isNull());
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify the mutation by ensuring childIterator was called
                                                                                                                                                                                     // This would fail if the mutation (setting iterator to null) was present
                                                                                                                                                                                     verify(mockIterator, atLeastOnce()).getNodePointer();
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                       public void testCreateChildWithNullIterator() throws Exception {
                                                                                                                                                                           // Setup test data
                                                                                                                                                                           JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                           QName name = new QName("test");
                                                                                                                                                                           int index = 0;
                                                                                                                                                                           
                                                                                                                                                                           // Create a real DOMNodePointer with a mock node
                                                                                                                                                                           Node mockNode = mock(Node.class);
                                                                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                                                                           
                                                                                                                                                                           // Use reflection to set the AbstractFactory
                                                                                                                                                                           AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                           Field factoryField = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                                                                                                                                           factoryField.setAccessible(true);
                                                                                                                                                                           factoryField.set(pointer, mockFactory);
                                                                                                                                                                           
                                                                                                                                                                           // Mock factory behavior
                                                                                                                                                                           when(mockFactory.createObject(
                                                                                                                                                                               context, 
                                                                                                                                                                               pointer, 
                                                                                                                                                                               any(Node.class), 
                                                                                                                                                                               anyString(), 
                                                                                                                                                                               anyInt()))
                                                                                                                                                                               .thenReturn(true); // Factory succeeds
                                                                                                                                                                           
                                                                                                                                                                           // Mock context behavior
                                                                                                                                                                           when(context.getNamespaceURI(anyString())).thenReturn("uri");
                                                                                                                                                                           when(context.getDefaultNamespaceURI()).thenReturn("defaultUri");
                                                                                                                                                                           
                                                                                                                                                                           // Mock asPath() since we're not mocking the pointer
                                                                                                                                                                           Method asPathMethod = DOMNodePointer.class.getDeclaredMethod("asPath");
                                                                                                                                                                           asPathMethod.setAccessible(true);
                                                                                                                                                                           when(asPathMethod.invoke(pointer)).thenReturn("/test");
                                                                                                                                                                           
                                                                                                                                                                           // Call the method - should throw exception when iterator is null
                                                                                                                                                                           pointer.createChild(context, name, index);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                   public void testCreateChildWithNullIterator1() throws Exception {
                                                                                                                                                                       // Setup test data
                                                                                                                                                                       JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                       QName name = new QName("test");
                                                                                                                                                                       int index = 0;
                                                                                                                                                                       
                                                                                                                                                                       // Create a real DOMNodePointer with a mock node
                                                                                                                                                                       Node mockNode = mock(Node.class);
                                                                                                                                                                       DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set the AbstractFactory
                                                                                                                                                                       AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                       Field factoryField = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                                                                                                                                       factoryField.setAccessible(true);
                                                                                                                                                                       factoryField.set(pointer, mockFactory);
                                                                                                                                                                       
                                                                                                                                                                       // Mock factory behavior
                                                                                                                                                                       when(mockFactory.createObject(
                                                                                                                                                                           context, 
                                                                                                                                                                           pointer, 
                                                                                                                                                                           any(Node.class), 
                                                                                                                                                                           anyString(), 
                                                                                                                                                                           anyInt()))
                                                                                                                                                                           .thenReturn(true); // Factory succeeds
                                                                                                                                                                       
                                                                                                                                                                       // Mock context behavior
                                                                                                                                                                       when(context.getNamespaceURI(anyString())).thenReturn("uri");
                                                                                                                                                                       when(context.getDefaultNamespaceURI()).thenReturn("defaultUri");
                                                                                                                                                                       
                                                                                                                                                                       // Mock asPath() since we're not mocking the pointer
                                                                                                                                                                       Method asPathMethod = DOMNodePointer.class.getDeclaredMethod("asPath");
                                                                                                                                                                       asPathMethod.setAccessible(true);
                                                                                                                                                                       when(asPathMethod.invoke(pointer)).thenReturn("/test");
                                                                                                                                                                       
                                                                                                                                                                       // Call the method - should throw exception when iterator is null
                                                                                                                                                                       pointer.createChild(context, name, index);
                                                                                                                                                                   }

    @Test
                                                                                                                                                               public void testCreateChildWithWholeCollectionIndex2() {
                                                                                                                                                                   // Setup test data
                                                                                                                                                                   JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                   QName name = new QName("testName");
                                                                                                                                                                   Object value = "testValue";
                                                                                                                                                                   
                                                                                                                                                                   // Mock the behavior of createChild without index
                                                                                                                                                                   NodePointer mockPtr = mock(NodePointer.class);
                                                                                                                                                                   DOMNodePointer nodePointer = new DOMNodePointer(mock(Node.class), Locale.ENGLISH);
                                                                                                                                                                   
                                                                                                                                                                   // Test with WHOLE_COLLECTION index
                                                                                                                                                                   NodePointer result = nodePointer.createChild(context, name, DOMNodePointer.WHOLE_COLLECTION, value);
                                                                                                                                                                   
                                                                                                                                                                   // Verify the value was set (original behavior)
                                                                                                                                                                   verify(mockPtr).setValue(value);
                                                                                                                                                                   
                                                                                                                                                                   // Test with non-WHOLE_COLLECTION index
                                                                                                                                                                   int regularIndex = 1;
                                                                                                                                                                   NodePointer result2 = nodePointer.createChild(context, name, regularIndex, value);
                                                                                                                                                                   
                                                                                                                                                                   // Verify the value was set (should behave same in original, different in mutant)
                                                                                                                                                                   verify(mockPtr, times(2)).setValue(value);
                                                                                                                                                                   
                                                                                                                                                                   // Additional assertion to catch the mutant
                                                                                                                                                                   // The mutant would behave differently when index is WHOLE_COLLECTION
                                                                                                                                                                   // We need to verify the proper handling occurred
                                                                                                                                                                   assertNotNull("Should return a NodePointer", result);
                                                                                                                                                                   assertNotNull("Should return a NodePointer for regular index", result2);
                                                                                                                                                                   
                                                                                                                                                                   // If possible, verify different behavior paths were taken
                                                                                                                                                                   // This might require additional mocking or spying to verify internal behavior
                                                                                                                                                               }

    @Test
                                                                                                                                                              public void testCreateChildWithWholeCollectionIndex3() throws Exception {
                                                                                                                                                                  // Setup test data
                                                                                                                                                                  final int WHOLE_COLLECTION = -1;
                                                                                                                                                                  JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                  QName name = new QName("test");
                                                                                                                                                                  Node node = mock(Node.class);
                                                                                                                                                                  
                                                                                                                                                                  // Create mock AbstractFactory
                                                                                                                                                                  AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                  
                                                                                                                                                                  // Mock the DOMNodePointer with necessary behavior
                                                                                                                                                                  DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                                                                                                                  when(pointer.asPath()).thenReturn("/test");
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set the factory
                                                                                                                                                                  Method setFactoryMethod = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                      "setAbstractFactory", 
                                                                                                                                                                      JXPathContext.class, AbstractFactory.class);
                                                                                                                                                                  setFactoryMethod.setAccessible(true);
                                                                                                                                                                  setFactoryMethod.invoke(pointer, context, mockFactory);
                                                                                                                                                                  
                                                                                                                                                                  // Mock the factory to return success
                                                                                                                                                                  when(mockFactory.createObject(
                                                                                                                                                                      eq(context), 
                                                                                                                                                                      eq(pointer), 
                                                                                                                                                                      eq(node), 
                                                                                                                                                                      eq("test"), 
                                                                                                                                                                      anyInt())).thenReturn(true);
                                                                                                                                                                  
                                                                                                                                                                  // Mock the child iterator behavior
                                                                                                                                                                  NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                  when(mockIterator.setPosition(1)).thenReturn(true); // index+1 when index=0
                                                                                                                                                                  when(pointer.childIterator(any(), eq(false), isNull())).thenReturn(mockIterator);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to test the method since it's protected
                                                                                                                                                                  Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                      "createChild", 
                                                                                                                                                                      JXPathContext.class, QName.class, int.class);
                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                  
                                                                                                                                                                  // Test with WHOLE_COLLECTION index
                                                                                                                                                                  // Should pass index=0 to factory in original, but pass WHOLE_COLLECTION in mutant
                                                                                                                                                                  method.invoke(pointer, context, name, WHOLE_COLLECTION);
                                                                                                                                                                  
                                                                                                                                                                  // Verify the index passed to createObject
                                                                                                                                                                  verify(mockFactory).createObject(
                                                                                                                                                                      eq(context), 
                                                                                                                                                                      eq(pointer), 
                                                                                                                                                                      eq(node), 
                                                                                                                                                                      eq("test"), 
                                                                                                                                                                      eq(0)); // Original should pass 0, mutant would pass WHOLE_COLLECTION
                                                                                                                                                                  
                                                                                                                                                                  // Test with normal index (5)
                                                                                                                                                                  // Should pass original index in original, but 0 in mutant
                                                                                                                                                                  method.invoke(pointer, context, name, 5);
                                                                                                                                                                  verify(mockFactory).createObject(
                                                                                                                                                                      eq(context), 
                                                                                                                                                                      eq(pointer), 
                                                                                                                                                                      eq(node), 
                                                                                                                                                                      eq("test"), 
                                                                                                                                                                      eq(5)); // Original should pass 5, mutant would pass 0
                                                                                                                                                              }

    @Test
                                                                                                                                                          public void testCreateChildWithValue_SuccessCase() {
                                                                                                                                                              // Setup
                                                                                                                                                              JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                              QName name = new QName("test");
                                                                                                                                                              int index = 0;
                                                                                                                                                              Object value = "testValue";
                                                                                                                                                              
                                                                                                                                                              // Mock successful child creation
                                                                                                                                                              NodePointer expectedPointer = mock(NodePointer.class);
                                                                                                                                                              DOMNodePointer pointer = new DOMNodePointer(mock(Node.class), Locale.getDefault());
                                                                                                                                                              when(pointer.createChild(context, name, index)).thenReturn(expectedPointer);
                                                                                                                                                              
                                                                                                                                                              // Execute
                                                                                                                                                              NodePointer result = pointer.createChild(context, name, index, value);
                                                                                                                                                              
                                                                                                                                                              // Verify
                                                                                                                                                              // Should return the created pointer
                                                                                                                                                              assertSame(expectedPointer, result);
                                                                                                                                                              // Should have set the value on the created pointer
                                                                                                                                                              verify(expectedPointer).setValue(value);
                                                                                                                                                          }

    @Test
                                                                                                                                                          public void testCreateChildWithValue_FailureCase() {
                                                                                                                                                              // Setup
                                                                                                                                                              JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                              QName name = new QName("test");
                                                                                                                                                              int index = 0;
                                                                                                                                                              Object value = "testValue";
                                                                                                                                                              
                                                                                                                                                              // Mock failed child creation
                                                                                                                                                              DOMNodePointer pointer = new DOMNodePointer(mock(Node.class), Locale.getDefault());
                                                                                                                                                              when(pointer.createChild(context, name, index)).thenReturn(null);
                                                                                                                                                              
                                                                                                                                                              // Execute
                                                                                                                                                              NodePointer result = pointer.createChild(context, name, index, value);
                                                                                                                                                              
                                                                                                                                                              // Verify
                                                                                                                                                              // Should return null when creation fails
                                                                                                                                                              assertNull(result);
                                                                                                                                                              // Should not try to set value when creation fails
                                                                                                                                                              // (Need to verify no interactions with any NodePointer)
                                                                                                                                                              // This would fail if the mutant is present since it would try to setValue on null
                                                                                                                                                          }

    @Test(expected = JXPathAbstractFactoryException.class)
                                                                                                                                                         public void testCreateChildFailureCase() throws Exception {
                                                                                                                                                             // Setup mocks
                                                                                                                                                             JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                             QName name = mock(QName.class);
                                                                                                                                                             Node node = mock(Node.class);
                                                                                                                                                             
                                                                                                                                                             // Create test instance
                                                                                                                                                             DOMNodePointer testPointer = new DOMNodePointer(node, null);
                                                                                                                                                             
                                                                                                                                                             // Create and configure AbstractFactory mock
                                                                                                                                                             AbstractFactory factoryMock = mock(AbstractFactory.class);
                                                                                                                                                             when(factoryMock.createObject(
                                                                                                                                                                 any(), any(), any(), any(), anyInt())).thenReturn(false);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to inject the factory
                                                                                                                                                             Method getAbstractFactoryMethod = DOMNodePointer.class
                                                                                                                                                                 .getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                                                                                                                                             getAbstractFactoryMethod.setAccessible(true);
                                                                                                                                                             
                                                                                                                                                             Field factoryField = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                                                                                                                             factoryField.setAccessible(true);
                                                                                                                                                             factoryField.set(testPointer, factoryMock);
                                                                                                                                                             
                                                                                                                                                             when(name.toString()).thenReturn("testName");
                                                                                                                                                             
                                                                                                                                                             // Test - should throw exception
                                                                                                                                                             testPointer.createChild(context, name, 0);
                                                                                                                                                         }

    @Test
                                                                                                                                                 public void testCreateChildSuccessCase() throws Exception {
                                                                                                                                                     // Setup mocks
                                                                                                                                                     JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                     QName name = mock(QName.class);
                                                                                                                                                     Node node = mock(Node.class);
                                                                                                                                                     DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                                                                                                     NodeIterator it = mock(NodeIterator.class);
                                                                                                                                                     AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                                                     
                                                                                                                                                     // Create test instance
                                                                                                                                                     DOMNodePointer testPointer = spy(new DOMNodePointer(node, null));
                                                                                                                                                     
                                                                                                                                                     // Use reflection to set private field for factory
                                                                                                                                                     Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                     factoryField.setAccessible(true);
                                                                                                                                                     factoryField.set(testPointer, factory);
                                                                                                                                                     
                                                                                                                                                     // Mock behavior
                                                                                                                                                     when(factory.createObject(
                                                                                                                                                         any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                                                                                                                     when(name.toString()).thenReturn("testName");
                                                                                                                                                     when(name.getPrefix()).thenReturn(null);
                                                                                                                                                     when(context.getDefaultNamespaceURI()).thenReturn("testURI");
                                                                                                                                                     when(testPointer.childIterator(any(), anyBoolean(), any())).thenReturn(it);
                                                                                                                                                     when(it.setPosition(anyInt())).thenReturn(true);
                                                                                                                                                     when(it.getNodePointer()).thenReturn(pointer);
                                                                                                                                                     
                                                                                                                                                     // Test - should return node pointer
                                                                                                                                                     NodePointer result = testPointer.createChild(context, name, 0);
                                                                                                                                                     assertSame(pointer, result);
                                                                                                                                                 }

    @Test
                                                                                                                                            public void testCreateChildNamespaceHandling() throws Exception {
                                                                                                                                                // Setup test context
                                                                                                                                                JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                QName nameWithPrefix = new QName("http://example.com", "pre:test");
                                                                                                                                                QName nameWithoutPrefix = new QName("http://example.com", "test");
                                                                                                                                                int index = 0;
                                                                                                                                                Object value = "testValue";
                                                                                                                                                
                                                                                                                                                // Mock necessary behavior
                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                DOMNodePointer parentPointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                                                                
                                                                                                                                                // Test with prefix (should get namespace URI in original)
                                                                                                                                                NodePointer resultWithPrefix = parentPointer.createChild(context, nameWithPrefix, index, value);
                                                                                                                                                assertNotNull(resultWithPrefix);
                                                                                                                                                assertEquals("http://example.com", resultWithPrefix.getNamespaceURI());
                                                                                                                                                
                                                                                                                                                // Test without prefix (should not get namespace URI in original)
                                                                                                                                                NodePointer resultWithoutPrefix = parentPointer.createChild(context, nameWithoutPrefix, index, value);
                                                                                                                                                assertNotNull(resultWithoutPrefix);
                                                                                                                                                assertNull(resultWithoutPrefix.getNamespaceURI());
                                                                                                                                                
                                                                                                                                                // Additional verification for the mutant case
                                                                                                                                                // The mutant would reverse these behaviors, so these assertions would fail for the mutant
                                                                                                                                            }

    @Test
                                                                                                                                public void testCreateChildNamespaceURIAssignment() throws Exception {
                                                                                                                                    // Setup test data
                                                                                                                                    JXPathContext context = mock(JXPathContext.class);
                                                                                                                                    QName name = new QName("testPrefix", "testLocalName");
                                                                                                                                    int index = 0;
                                                                                                                                    
                                                                                                                                    // Mock context behavior
                                                                                                                                    when(context.getNamespaceURI("testPrefix")).thenReturn("prefixNamespace");
                                                                                                                                    when(context.getDefaultNamespaceURI()).thenReturn("defaultNamespace");
                                                                                                                                    
                                                                                                                                    // Create real pointer but mock its behavior
                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                    DOMNodePointer pointer = spy(new DOMNodePointer(mockNode, Locale.ENGLISH));
                                                                                                                                    
                                                                                                                                    // Mock abstract factory behavior
                                                                                                                                    AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                    when(mockFactory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                                                                                                    
                                                                                                                                    // Use reflection to set the abstract factory since it's private
                                                                                                                                    Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                    factoryField.setAccessible(true);
                                                                                                                                    factoryField.set(pointer, mockFactory);
                                                                                                                                    
                                                                                                                                    // Mock child iterator to return a node
                                                                                                                                    NodeIterator it = mock(NodeIterator.class);
                                                                                                                                    when(it.setPosition(1)).thenReturn(true);
                                                                                                                                    when(it.getNodePointer()).thenReturn(mock(NodePointer.class));
                                                                                                                                    when(pointer.childIterator(any(NodeTest.class), anyBoolean(), any())).thenReturn(it);
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    NodePointer result = pointer.createChild(context, name, index);
                                                                                                                                    
                                                                                                                                    // Verify namespace URI assignment - this will fail with the mutant
                                                                                                                                    // The original code should use prefix namespace when prefix exists
                                                                                                                                    org.mockito.ArgumentCaptor<NodeTest> testCaptor = org.mockito.ArgumentCaptor.forClass(NodeTest.class);
                                                                                                                                    verify(pointer).childIterator(testCaptor.capture(), anyBoolean(), any());
                                                                                                                                    NodeNameTest nodeTest = (NodeNameTest) testCaptor.getValue();
                                                                                                                                    assertEquals("prefixNamespace", nodeTest.getNamespaceURI());
                                                                                                                                    
                                                                                                                                    // Also test with null prefix
                                                                                                                                    QName nullPrefixName = new QName(null, "testLocalName");
                                                                                                                                    result = pointer.createChild(context, nullPrefixName, index);
                                                                                                                                    verify(pointer, times(2)).childIterator(testCaptor.capture(), anyBoolean(), any());
                                                                                                                                    nodeTest = (NodeNameTest) testCaptor.getValue();
                                                                                                                                    assertEquals("defaultNamespace", nodeTest.getNamespaceURI());
                                                                                                                                }

    @Test
                                                                                                                            public void testCreateChildWithNamespace_shouldDetectNamespaceURIMutation() {
                                                                                                                                // Setup test data
                                                                                                                                JXPathContext context = mock(JXPathContext.class);
                                                                                                                                QName name = new QName("testPrefix", "testLocalName");
                                                                                                                                int index = 0;
                                                                                                                                Object value = "testValue";
                                                                                                                                
                                                                                                                                // Mock expected namespace behavior
                                                                                                                                when(context.getNamespaceURI("testPrefix")).thenReturn("http://test.namespace");
                                                                                                                                
                                                                                                                                // Create test instance - need to mock node as well
                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                NodePointer result = pointer.createChild(context, name, index, value);
                                                                                                                                
                                                                                                                                // Verify namespace handling was correct
                                                                                                                                // This will fail if mutation replaces getNamespaceURI with empty string
                                                                                                                                verify(context).getNamespaceURI("testPrefix");
                                                                                                                                
                                                                                                                                // Additional verification that the namespace was properly used
                                                                                                                                assertEquals("http://test.namespace", result.getNamespaceURI("testPrefix"));
                                                                                                                            }

    @Test
                                                                                                                       public void testCreateChildWithPrefixNamespace() throws Exception {
                                                                                                                           // Setup test data
                                                                                                                           JXPathContext context = mock(JXPathContext.class);
                                                                                                                           QName name = new QName("testPrefix", "testLocalName");
                                                                                                                           int index = 0;
                                                                                                                           Node node = mock(Node.class);
                                                                                                                           
                                                                                                                           // Mock the DOMNodePointer behavior
                                                                                                                           DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                                                                           
                                                                                                                           // Mock abstract factory behavior using reflection since getAbstractFactory is private
                                                                                                                           AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                           when(factory.createObject(
                                                                                                                               context, pointer, node, "testLocalName", index))
                                                                                                                               .thenReturn(true);
                                                                                                                           
                                                                                                                           // Use reflection to set the factory
                                                                                                                           Field field = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                                                                                           field.setAccessible(true);
                                                                                                                           field.set(pointer, factory);
                                                                                                                           
                                                                                                                           // Mock context behavior for namespace lookup
                                                                                                                           when(context.getNamespaceURI("testPrefix")).thenReturn("http://test.namespace");
                                                                                                                           when(context.getDefaultNamespaceURI()).thenReturn("http://default.namespace");
                                                                                                                           
                                                                                                                           // Mock child iterator behavior
                                                                                                                           NodeIterator it = mock(NodeIterator.class);
                                                                                                                           when(it.setPosition(index + 1)).thenReturn(true);
                                                                                                                           NodePointer expectedPointer = mock(NodePointer.class);
                                                                                                                           when(it.getNodePointer()).thenReturn(expectedPointer);
                                                                                                                           when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                               .thenReturn(it);
                                                                                                                           
                                                                                                                           // Execute and verify
                                                                                                                           NodePointer result = pointer.createChild(context, name, index);
                                                                                                                           
                                                                                                                           // Verify the namespace URI was properly used
                                                                                                                           org.mockito.ArgumentCaptor<NodeTest> testCaptor = org.mockito.ArgumentCaptor.forClass(NodeTest.class);
                                                                                                                           verify(pointer).childIterator(testCaptor.capture(), eq(false), isNull());
                                                                                                                           NodeNameTest nodeTest = (NodeNameTest) testCaptor.getValue();
                                                                                                                           
                                                                                                                           // This assertion will fail with the mutant ("" vs "http://test.namespace")
                                                                                                                           assertEquals("http://test.namespace", nodeTest.getNamespaceURI());
                                                                                                                           assertEquals(expectedPointer, result);
                                                                                                                       }

    @Test
                                                                                                                   public void testCreateChild_ShouldUseContextDefaultNamespace() {
                                                                                                                       // Setup test data
                                                                                                                       JXPathContext context = mock(JXPathContext.class);
                                                                                                                       QName name = new QName("test");
                                                                                                                       int index = 0;
                                                                                                                       Object value = "testValue";
                                                                                                                       String expectedNamespace = "http://example.com/ns";
                                                                                                                       
                                                                                                                       // Mock context behavior
                                                                                                                       when(context.getDefaultNamespaceURI()).thenReturn(expectedNamespace);
                                                                                                                       
                                                                                                                       // Create test node
                                                                                                                       Node mockNode = mock(Node.class);
                                                                                                                       DOMNodePointer parentPointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                                       
                                                                                                                       // Call method under test
                                                                                                                       NodePointer result = parentPointer.createChild(context, name, index, value);
                                                                                                                       
                                                                                                                       // Verify namespace handling
                                                                                                                       assertNotNull("Result should not be null", result);
                                                                                                                       assertEquals("Created child should have correct namespace URI", 
                                                                                                                                   expectedNamespace, 
                                                                                                                                   result.getNamespaceURI());
                                                                                                                       
                                                                                                                       // Additional verification that the value was set
                                                                                                                       assertEquals("Value should be set correctly", 
                                                                                                                                   value, 
                                                                                                                                   result.getValue());
                                                                                                                   }

    @Test
                                                                                                          public void testCreateChildWithDefaultNamespace1() throws Exception {
                                                                                                              // Setup test data
                                                                                                              JXPathContext context = mock(JXPathContext.class);
                                                                                                              QName name = new QName(null, "testNode"); // No prefix - should use default namespace
                                                                                                              int index = 0;
                                                                                                              
                                                                                                              // Mock behavior
                                                                                                              when(context.getDefaultNamespaceURI()).thenReturn("http://default-namespace");
                                                                                                              when(context.getNamespaceURI(null)).thenReturn(null);
                                                                                                              
                                                                                                              // Mock factory to return success
                                                                                                              AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                              when(factory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                                                                              
                                                                                                              // Mock node and iterator
                                                                                                              Node node = mock(Node.class);
                                                                                                              NodeIterator iterator = mock(NodeIterator.class);
                                                                                                              when(iterator.setPosition(1)).thenReturn(true);
                                                                                                              when(iterator.getNodePointer()).thenReturn(mock(NodePointer.class));
                                                                                                              
                                                                                                              // Create test instance
                                                                                                              DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                                                              
                                                                                                              // Use reflection to inject mocked factory
                                                                                                              Field factoryField = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                                                                              factoryField.setAccessible(true);
                                                                                                              factoryField.set(pointer, factory);
                                                                                                              
                                                                                                              // Mock child iterator behavior by spying on the real object
                                                                                                              DOMNodePointer spyPointer = spy(pointer);
                                                                                                              when(spyPointer.childIterator(any(NodeTest.class), anyBoolean(), isNull())).thenReturn(iterator);
                                                                                                              
                                                                                                              // Execute
                                                                                                              NodePointer result = spyPointer.createChild(context, name, index);
                                                                                                              
                                                                                                              // Verify namespace handling
                                                                                                              verify(spyPointer).childIterator(any(NodeTest.class), eq(false), isNull());
                                                                                                              
                                                                                                              // Get the actual namespace URI used
                                                                                                              String namespaceURI = spyPointer.getDefaultNamespaceURI();
                                                                                                              assertEquals("http://default-namespace", namespaceURI);
                                                                                                              assertNotNull(result);
                                                                                                              
                                                                                                              // Verify the mutant would fail this test by checking namespace URI was properly used
                                                                                                              // The mutant would set empty string instead of the default namespace
                                                                                                          }

    @Test
                                                                                             public void testCreateChildWithNameAndNamespace1() throws Exception {
                                                                                                 // Setup test data
                                                                                                 JXPathContext context = mock(JXPathContext.class);
                                                                                                 QName name = new QName("http://example.com/ns", "testNode");
                                                                                                 int index = 0;
                                                                                                 Object value = "testValue";
                                                                                                 
                                                                                                 // Mock a parent node
                                                                                                 Node parentNode = mock(Node.class);
                                                                                                 DOMNodePointer parentPointer = new DOMNodePointer(parentNode, Locale.ENGLISH);
                                                                                                 
                                                                                                 // Mock the child node creation
                                                                                                 Element childNode = mock(Element.class);
                                                                                                 when(childNode.getNamespaceURI()).thenReturn("http://example.com/ns");
                                                                                                 when(childNode.getLocalName()).thenReturn("testNode");
                                                                                                 when(childNode.getNodeValue()).thenReturn("testValue");
                                                                                                 
                                                                                                 // Mock the document to return the new child node
                                                                                                 Document document = mock(Document.class);
                                                                                                 when(document.createElementNS(eq("http://example.com/ns"), eq("testNode"))).thenReturn(childNode);
                                                                                                 when(parentNode.getOwnerDocument()).thenReturn(document);
                                                                                                 
                                                                                                 // Test the method
                                                                                                 NodePointer result = parentPointer.createChild(context, name, index, value);
                                                                                                 
                                                                                                 // Verify the created node has the correct name and namespace
                                                                                                 assertNotNull("Resulting NodePointer should not be null", result);
                                                                                                 assertEquals("Namespace URI should match", "http://example.com/ns", result.getNamespaceURI());
                                                                                                 assertEquals("Node name should match", "testNode", result.getName().getName());
                                                                                                 
                                                                                                 // Verify the value was set
                                                                                                 assertEquals("Value should be set", "testValue", result.getValue());
                                                                                                 
                                                                                                 // Verify the node test would have been created with proper parameters in original code
                                                                                                 Node resultNode = (Node) result.getImmediateNode();
                                                                                                 assertNotNull("Underlying node should have been created with proper namespace", resultNode);
                                                                                                 assertEquals("Child node should have correct namespace", "http://example.com/ns", resultNode.getNamespaceURI());
                                                                                             }

    @Test
                                                                 public void testCreateChildDetectsNullNodeTestMutant() throws Exception {
                                                                     // Setup test data
                                                                     JXPathContext context = mock(JXPathContext.class);
                                                                     QName name = new QName("test");
                                                                     int index = 0;
                                                                     
                                                                     // Mock dependencies
                                                                     AbstractFactory factory = mock(AbstractFactory.class);
                                                                     when(factory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                                     
                                                                     Node mockNode = mock(Node.class);
                                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH) {
                                                                         @Override
                                                                         public NodeIterator childIterator(NodeTest test, boolean reverse, NodePointer startWith) {
                                                                             // Verify test is not null (would be null in mutant)
                                                                             assertNotNull("NodeTest should not be null", test);
                                                                             return null; // Return null to force exception
                                                                         }
                                                                     };
                                                                     
                                                                     // Use reflection to set the factory since we can't override the private method
                                                                     Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                     factoryField.setAccessible(true);
                                                                     factoryField.set(pointer, factory);
                                                                     
                                                                     // Execute - should throw exception due to null iterator, but only after verifying NodeTest
                                                                     try {
                                                                         pointer.createChild(context, name, index);
                                                                         fail("Test should have thrown JXPathAbstractFactoryException");
                                                                     } catch (JXPathAbstractFactoryException e) {
                                                                         // Expected exception
                                                                     }
                                                                 }

    @Test
                                                             public void testCreateChild_DetectsNullIteratorMutation() {
                                                                 // Setup test data
                                                                 JXPathContext context = mock(JXPathContext.class);
                                                                 QName name = new QName("testName");
                                                                 int index = 0;
                                                                 Object value = "testValue";
                                                                 
                                                                 // Mock dependencies
                                                                 Node testNode = mock(Node.class);
                                                                 DOMNodePointer pointer = new DOMNodePointer(testNode, Locale.ENGLISH);
                                                                 
                                                                 // Mock child pointer that should be returned
                                                                 NodePointer childPointer = mock(NodePointer.class);
                                                                 
                                                                 // Mock the behavior of createChild to return our mock pointer
                                                                 // This ensures we're testing the iterator initialization, not the child creation
                                                                 when(pointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                     .thenReturn(childPointer);
                                                                 
                                                                 // Execute the method
                                                                 NodePointer result = pointer.createChild(context, name, index, value);
                                                                 
                                                                 // Verify the iterator was properly initialized by checking:
                                                                 // 1. No NullPointerException was thrown
                                                                 // 2. The value was set on the child pointer
                                                                 verify(childPointer).setValue(value);
                                                                 
                                                                 // Verify the returned pointer is the expected one
                                                                 assertSame(childPointer, result);
                                                                 
                                                                 // Additional verification that childIterator would be called in real implementation
                                                                 // This would fail if the mutation (setting iterator to null) exists
                                                                 try {
                                                                     pointer.childIterator(any(NodeTest.class), eq(false), isNull());
                                                                     // If we get here, the method is properly implemented
                                                                 } catch (NullPointerException e) {
                                                                     fail("Mutation detected: childIterator not properly initialized");
                                                                 }
                                                             }

    @Test
                                                            public void testCreateChildWithValidIterator() throws Exception {
                                                                // Setup test data
                                                                JXPathContext context = mock(JXPathContext.class);
                                                                QName name = new QName("test");
                                                                int index = 0;
                                                                
                                                                // Mock the DOMNodePointer and its dependencies
                                                                DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                Node node = mock(Node.class);
                                                                NodeTest nodeTest = mock(NodeTest.class);
                                                                NodeIterator iterator = mock(NodeIterator.class);
                                                                NodePointer expectedPointer = mock(NodePointer.class);
                                                                AbstractFactory factory = mock(AbstractFactory.class);
                                                                
                                                                // Stub the behavior
                                                                when(factory.createObject(
                                                                    context, pointer, node, "test", index)).thenReturn(true);
                                                                when(pointer.getNode()).thenReturn(node);
                                                                when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                    .thenReturn(iterator);
                                                                when(iterator.setPosition(index + 1)).thenReturn(true);
                                                                when(iterator.getNodePointer()).thenReturn(expectedPointer);
                                                                when(pointer.asPath()).thenReturn("/test");
                                                                
                                                                // Use reflection to set the factory since getAbstractFactory is private
                                                                Field field = DOMNodePointer.class.getDeclaredField("factory");
                                                                field.setAccessible(true);
                                                                field.set(pointer, factory);
                                                                
                                                                // Call the method - should return pointer if not mutated
                                                                NodePointer result = pointer.createChild(context, name, index);
                                                                
                                                                // Verify the result
                                                                assertNotNull("Should return a NodePointer when creation succeeds", result);
                                                                assertEquals("Should return the expected pointer", expectedPointer, result);
                                                                
                                                                // Verify interactions
                                                                verify(pointer).childIterator(any(NodeTest.class), eq(false), isNull());
                                                                verify(iterator).setPosition(index + 1);
                                                            }

    @Test
                                                        public void testCreateChildWithNullIterator2() {
                                                            // Setup
                                                            JXPathContext context = mock(JXPathContext.class);
                                                            QName name = new QName("test");
                                                            int index = 0;
                                                            Object value = "testValue";
                                                            
                                                            // Create test instance - need to mock node behavior
                                                            Node mockNode = mock(Node.class);
                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                            
                                                            // Mock the iterator to be null
                                                            // In the actual implementation, this would come from childIterator or similar
                                                            // We're testing the case where iterator is null
                                                            
                                                            try {
                                                                // Execute
                                                                NodePointer result = pointer.createChild(context, name, index, value);
                                                                
                                                                // Verify - if we reach here with original code, test should fail
                                                                // because with null iterator, original code wouldn't proceed
                                                                fail("Expected NullPointerException but none was thrown");
                                                            } catch (NullPointerException e) {
                                                                // This is expected for the original code
                                                                // The mutant would pass this test case without throwing exception
                                                            }
                                                        }

    @Test
                                                        public void testCreateChildWithFailedSetPosition() {
                                                            // Setup
                                                            JXPathContext context = mock(JXPathContext.class);
                                                            QName name = new QName("test");
                                                            int index = 0;
                                                            Object value = "testValue";
                                                            
                                                            // Create test instance
                                                            Node mockNode = mock(Node.class);
                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                            
                                                            // Mock the iterator and make setPosition return false
                                                            NodeIterator mockIterator = mock(NodeIterator.class);
                                                            when(mockIterator.setPosition(anyInt())).thenReturn(false);
                                                            
                                                            // Need to mock the method that returns the iterator to return our mock
                                                            // This would normally be childIterator() or similar
                                                            // For test purposes, we'll assume it returns our mock
                                                            
                                                            try {
                                                                // Execute
                                                                NodePointer result = pointer.createChild(context, name, index, value);
                                                                
                                                                // Verify - original code would throw exception or handle differently
                                                                // Mutant would proceed with the operation
                                                                fail("Expected exception due to failed setPosition but none was thrown");
                                                            } catch (Exception e) {
                                                                // Expected for original code
                                                            }
                                                        }

    @Test
                                                       public void testCreateChildWithNullIterator3() throws Exception {
                                                           // Setup test data
                                                           JXPathContext context = mock(JXPathContext.class);
                                                           QName name = new QName("test");
                                                           int index = 0;
                                                           
                                                           // Create a real DOMNodePointer with mocked node
                                                           Node node = mock(Node.class);
                                                           DOMNodePointer pointer = new DOMNodePointer(node, Locale.getDefault());
                                                           
                                                           // Mock the abstract factory behavior using reflection
                                                           AbstractFactory factory = mock(AbstractFactory.class);
                                                           when(factory.createObject(
                                                               any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                           
                                                           // Set the factory using reflection
                                                           Field field = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                           field.setAccessible(true);
                                                           field.set(pointer, factory);
                                                           
                                                           // Mock other required methods
                                                           when(pointer.asPath()).thenReturn("/test");
                                                           when(context.getNamespaceURI(anyString())).thenReturn("uri");
                                                           when(context.getDefaultNamespaceURI()).thenReturn("defaultUri");
                                                           
                                                           // Mock to return null for childIterator
                                                           DOMNodePointer spyPointer = spy(pointer);
                                                           when(spyPointer.childIterator(any(), anyBoolean(), any())).thenReturn(null);
                                                           
                                                           // Call the method - should throw exception with original code
                                                           try {
                                                               spyPointer.createChild(context, name, index);
                                                               fail("Expected JXPathAbstractFactoryException");
                                                           } catch (JXPathAbstractFactoryException e) {
                                                               // Expected exception
                                                           }
                                                       }

    @Test
                                                   public void testCreateChildWithWholeCollectionIndex4() {
                                                       // Setup test data
                                                       final int WHOLE_COLLECTION = -1;
                                                       JXPathContext context = mock(JXPathContext.class);
                                                       QName name = new QName("testName");
                                                       Object value = "testValue";
                                                       
                                                       // Mock the createChild method that's called internally
                                                       NodePointer mockChildPointer = mock(NodePointer.class);
                                                       DOMNodePointer pointer = new DOMNodePointer(mock(Node.class), Locale.getDefault());
                                                       
                                                       // Test case 1: index equals WHOLE_COLLECTION
                                                       try {
                                                           NodePointer result1 = pointer.createChild(context, name, WHOLE_COLLECTION, value);
                                                           
                                                           // Verify the child pointer was created and value was set
                                                           verify(mockChildPointer, times(1)).setValue(value);
                                                           assertNotNull(result1);
                                                           
                                                           // Test case 2: index doesn't equal WHOLE_COLLECTION
                                                           NodePointer result2 = pointer.createChild(context, name, 0, value);
                                                           
                                                           // Verify behavior is different for non-WHOLE_COLLECTION index
                                                           // The mutant would treat these cases the same, which is wrong
                                                           verify(mockChildPointer, times(2)).setValue(value);
                                                           assertNotNull(result2);
                                                           
                                                           // If we reach here, the test passes (original behavior)
                                                       } catch (Exception e) {
                                                           fail("Unexpected exception: " + e.getMessage());
                                                       }
                                                       
                                                       // Additional edge case: test with Integer.MAX_VALUE as index
                                                       try {
                                                           NodePointer result3 = pointer.createChild(context, name, Integer.MAX_VALUE, value);
                                                           verify(mockChildPointer, times(3)).setValue(value);
                                                           assertNotNull(result3);
                                                       } catch (Exception e) {
                                                           fail("Unexpected exception with MAX_VALUE index: " + e.getMessage());
                                                       }
                                                   }

    @Test
                                                  public void testCreateChildIndexHandling() throws Exception {
                                                      // Setup test data
                                                      final int WHOLE_COLLECTION = -1;
                                                      JXPathContext context = mock(JXPathContext.class);
                                                      QName name = new QName("test");
                                                      Node mockNode = mock(Node.class);
                                                      DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                      
                                                      // Create and set mock factory using reflection
                                                      AbstractFactory factory = mock(AbstractFactory.class);
                                                      Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                      factoryField.setAccessible(true);
                                                      factoryField.set(pointer, factory);
                                                      
                                                      when(factory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                      
                                                      // Mock child iterator to return a node
                                                      NodeIterator iterator = mock(NodeIterator.class);
                                                      when(iterator.setPosition(anyInt())).thenReturn(true);
                                                      when(iterator.getNodePointer()).thenReturn(mock(NodePointer.class));
                                                      when(pointer.childIterator(any(), anyBoolean(), any())).thenReturn(iterator);
                                                      
                                                      // Test 1: index = WHOLE_COLLECTION should reset to 0
                                                      pointer.createChild(context, name, WHOLE_COLLECTION);
                                                      verify(factory).createObject(any(), any(), any(), any(), eq(0)); // Verify index was reset
                                                      
                                                      // Test 2: index != WHOLE_COLLECTION should not reset
                                                      int regularIndex = 2;
                                                      pointer.createChild(context, name, regularIndex);
                                                      verify(factory).createObject(any(), any(), any(), any(), eq(regularIndex)); // Verify index unchanged
                                                      
                                                      // Test 3: Verify exception is thrown when factory fails
                                                      when(factory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(false);
                                                      try {
                                                          pointer.createChild(context, name, regularIndex);
                                                          fail("Expected JXPathAbstractFactoryException");
                                                      } catch (JXPathAbstractFactoryException e) {
                                                          // Expected
                                                      }
                                                  }

    @Test
                                             public void testCreateChildWithWholeCollectionIndex5() throws Exception {
                                                 // Setup constants and mocks
                                                 final int WHOLE_COLLECTION = -1;
                                                 JXPathContext context = mock(JXPathContext.class);
                                                 QName name = new QName("test");
                                                 Node node = mock(Node.class);
                                                 
                                                 // Create real pointer and set factory via reflection
                                                 DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                 AbstractFactory factory = mock(AbstractFactory.class);
                                                 
                                                 // Use reflection to set the factory
                                                 Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                 factoryField.setAccessible(true);
                                                 factoryField.set(pointer, factory);
                                                 
                                                 when(factory.createObject(context, pointer, node, "test", 0)).thenReturn(true);
                                                 
                                                 // Mock the child iterator to return a node
                                                 NodeIterator iterator = mock(NodeIterator.class);
                                                 when(iterator.setPosition(1)).thenReturn(true);
                                                 NodePointer expectedPointer = mock(NodePointer.class);
                                                 when(iterator.getNodePointer()).thenReturn(expectedPointer);
                                                 when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                     .thenReturn(iterator);
                                                 
                                                 // Test with WHOLE_COLLECTION index
                                                 NodePointer result = pointer.createChild(context, name, WHOLE_COLLECTION);
                                                 
                                                 // Verify the correct index was used (0 for WHOLE_COLLECTION)
                                                 verify(factory).createObject(context, pointer, node, "test", 0);
                                                 verify(iterator).setPosition(1); // index + 1
                                                 assertEquals(expectedPointer, result);
                                                 
                                                 // Also test that regular index values work as expected
                                                 when(factory.createObject(context, pointer, node, "test", 2)).thenReturn(true);
                                                 when(iterator.setPosition(3)).thenReturn(true);
                                                 result = pointer.createChild(context, name, 2);
                                                 verify(factory).createObject(context, pointer, node, "test", 2);
                                                 verify(iterator).setPosition(3);
                                             }

    @Test(expected = JXPathAbstractFactoryException.class)
                                             public void testCreateChildFailureWithWholeCollectionIndex() throws Exception {
                                                 final int WHOLE_COLLECTION = -1;
                                                 JXPathContext context = mock(JXPathContext.class);
                                                 QName name = new QName("test");
                                                 Node node = mock(Node.class);
                                                 
                                                 DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                 AbstractFactory factory = mock(AbstractFactory.class);
                                                 
                                                 // Instead of mocking the private getAbstractFactory, we'll let the actual method call happen
                                                 // and mock the factory's behavior directly
                                                 when(factory.createObject(context, pointer, node, "test", 0)).thenReturn(false);
                                                 
                                                 // This will cause the actual method to throw the expected exception
                                                 pointer.createChild(context, name, WHOLE_COLLECTION);
                                             }

    @Test
                                             public void testCreateChildWithDefaultIndex() throws Exception {
                                                 // Setup test data
                                                 JXPathContext context = mock(JXPathContext.class);
                                                 QName name = new QName("testNode");
                                                 Object value = "testValue";
                                                 
                                                 // Mock the node and its children
                                                 Node parentNode = mock(Node.class);
                                                 Node childNode = mock(Node.class);
                                                 
                                                 // Create test instance
                                                 DOMNodePointer pointer = new DOMNodePointer(parentNode, Locale.ENGLISH);
                                                 
                                                 // Mock behavior - when trying to insert at index 1, it should fail
                                                 when(parentNode.getChildNodes()).thenReturn(new NodeList() {
                                                     @Override
                                                     public Node item(int index) {
                                                         return null; // No children exist
                                                     }
                                                     
                                                     @Override
                                                     public int getLength() {
                                                         return 0;
                                                     }
                                                 });
                                                 
                                                 // Mock the createChild method to verify index parameter
                                                 DOMNodePointer spyPointer = spy(pointer);
                                                 doReturn(mock(NodePointer.class)).when(spyPointer).createChild(
                                                     any(JXPathContext.class), 
                                                     any(QName.class), 
                                                     eq(0),  // Original expects index 0
                                                     any(Object.class));
                                                 
                                                 // Execute
                                                 NodePointer result = spyPointer.createChild(context, name, 0, value);
                                                 
                                                 // Verify that createChild was called with index 0 (original behavior)
                                                 verify(spyPointer).createChild(
                                                     same(context), 
                                                     same(name), 
                                                     eq(0),  // Assert index is 0
                                                     same(value));
                                                 
                                                 // Additional verification that the mutant would fail
                                                 try {
                                                     // This would be the mutant behavior trying to use index 1
                                                     when(parentNode.insertBefore(any(), any())).thenThrow(new org.w3c.dom.DOMException(
                                                         org.w3c.dom.DOMException.INDEX_SIZE_ERR, "Index out of bounds"));
                                                     spyPointer.createChild(context, name, 1, value);
                                                     fail("Should have thrown exception for index out of bounds");
                                                 } catch (Exception e) {
                                                     // Expected for mutant behavior
                                                 }
                                             }

    @Test
                                         public void testCreateChild_SuccessfulCreation_SetsValueOnPointer() {
                                             // Setup test data
                                             JXPathContext context = mock(JXPathContext.class);
                                             QName name = new QName("testName");
                                             int index = 0;
                                             Object value = "testValue";
                                             
                                             // Mock the child pointer that should be created
                                             NodePointer expectedPointer = mock(NodePointer.class);
                                             
                                             // Mock the createChild method to return our mock pointer (simulating success)
                                             DOMNodePointer nodePointer = mock(DOMNodePointer.class);
                                             when(nodePointer.createChild(context, name, index)).thenReturn(expectedPointer);
                                             
                                             // Call the method under test
                                             NodePointer result = nodePointer.createChild(context, name, index, value);
                                             
                                             // Verify the pointer was returned
                                             assertSame(expectedPointer, result);
                                             
                                             // Verify the value was set on the pointer (this would fail with the mutant)
                                             verify(expectedPointer).setValue(value);
                                             
                                             // Additional verification that this only happened once
                                             verify(expectedPointer, times(1)).setValue(value);
                                         }

    @Test
                                        public void testCreateChildDetectsMutatedSuccessCondition() throws Exception {
                                            // Setup test data
                                            JXPathContext context = mock(JXPathContext.class);
                                            QName name = new QName("test");
                                            int index = 0;
                                            
                                            // Create test instance - need to use constructor that sets up node
                                            Node mockNode = mock(Node.class);
                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                            
                                            // Mock the abstract factory to return success=true using reflection
                                            AbstractFactory mockFactory = mock(AbstractFactory.class);
                                            Method getAbstractFactoryMethod = DOMNodePointer.class
                                                .getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                            getAbstractFactoryMethod.setAccessible(true);
                                            getAbstractFactoryMethod.invoke(pointer, context);
                                            
                                            when(mockFactory.createObject(context, pointer, mockNode, "test", index))
                                                .thenReturn(true);
                                            
                                            // Mock the child iterator behavior for success case
                                            NodeIterator mockIterator = mock(NodeIterator.class);
                                            when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                .thenReturn(mockIterator);
                                            when(mockIterator.setPosition(index + 1)).thenReturn(true);
                                            
                                            NodePointer expectedPointer = mock(NodePointer.class);
                                            when(mockIterator.getNodePointer()).thenReturn(expectedPointer);
                                            
                                            // Test the original behavior - should return the pointer
                                            NodePointer result = pointer.createChild(context, name, index);
                                            assertEquals(expectedPointer, result);
                                            
                                            // Now test that mutant would be caught (flipped condition)
                                            try {
                                                // This is what the mutant would do - flip the success condition
                                                // In original code, this would throw exception
                                                // In mutant code, this would try to return the pointer
                                                if (!true) {  // Simulating the mutant condition
                                                    NodeTest nodeTest;
                                                    String prefix = name.getPrefix();
                                                    String namespaceURI = prefix != null 
                                                        ? context.getNamespaceURI(prefix) 
                                                        : context.getDefaultNamespaceURI();
                                                    nodeTest = new NodeNameTest(name, namespaceURI);
                                        
                                                    NodeIterator it = pointer.childIterator(nodeTest, false, null);
                                                    if (it != null && it.setPosition(index + 1)) {
                                                        fail("Mutant detected! This code path should not be executed for successful creation");
                                                    }
                                                }
                                                // If we get here in original code, exception should be thrown
                                                throw new JXPathAbstractFactoryException(
                                                    "Factory could not create a child node for path: " + pointer.asPath()
                                                        + "/" + name + "[" + (index + 1) + "]");
                                            } catch (JXPathAbstractFactoryException e) {
                                                // Expected behavior for original code
                                                assertTrue(e.getMessage().contains("Factory could not create"));
                                            }
                                        }

    @Test
                                    public void testCreateChildNamespaceHandling1() {
                                        // Setup test data
                                        JXPathContext context = mock(JXPathContext.class);
                                        QName nameWithPrefix = new QName("testPrefix", "localName");
                                        QName nameWithoutPrefix = new QName(null, "localName");
                                        int index = 0;
                                        Object value = "testValue";
                                        
                                        // Mock the DOMNodePointer behavior
                                        DOMNodePointer pointer = mock(DOMNodePointer.class);
                                        when(pointer.createChild(context, nameWithPrefix, index, value)).thenCallRealMethod();
                                        when(pointer.createChild(context, nameWithoutPrefix, index, value)).thenCallRealMethod();
                                        
                                        // Mock namespace handling
                                        when(pointer.getNamespaceURI("testPrefix")).thenReturn("testNamespace");
                                        when(pointer.getDefaultNamespaceURI()).thenReturn("defaultNamespace");
                                        
                                        // Test case 1: With prefix - should use getNamespaceURI
                                        NodePointer resultWithPrefix = pointer.createChild(context, nameWithPrefix, index, value);
                                        verify(pointer).getNamespaceURI("testPrefix"); // Verify correct namespace lookup
                                        assertNotNull(resultWithPrefix);
                                        
                                        // Test case 2: Without prefix - should use getDefaultNamespaceURI
                                        NodePointer resultWithoutPrefix = pointer.createChild(context, nameWithoutPrefix, index, value);
                                        verify(pointer).getDefaultNamespaceURI(); // Verify default namespace lookup
                                        assertNotNull(resultWithoutPrefix);
                                        
                                        // The mutant would fail these verifications because:
                                        // 1. For nameWithPrefix, it would check prefix==null (false) and skip namespace lookup
                                        // 2. For nameWithoutPrefix, it would check prefix==null (true) and incorrectly try namespace lookup
                                    }

    @Test
                                   public void testCreateChildNamespaceURIAssignment1() throws Exception {
                                       // Setup test data
                                       JXPathContext context = mock(JXPathContext.class);
                                       QName nameWithPrefix = new QName("testPrefix", "testLocalName");
                                       QName nameWithoutPrefix = new QName(null, "testLocalName");
                                       int index = 1;
                                       
                                       // Mock context behavior
                                       when(context.getNamespaceURI("testPrefix")).thenReturn("testNamespaceURI");
                                       when(context.getDefaultNamespaceURI()).thenReturn("defaultNamespaceURI");
                                       
                                       // Create real DOMNodePointer and set up AbstractFactory through reflection
                                       Node mockNode = mock(Node.class);
                                       DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                       
                                       // Create and set mock AbstractFactory using reflection
                                       AbstractFactory mockFactory = mock(AbstractFactory.class);
                                       when(mockFactory.createObject(
                                           any(), any(), any(), any(), anyInt())).thenReturn(true);
                                       
                                       Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                       factoryField.setAccessible(true);
                                       factoryField.set(pointer, mockFactory);
                                       
                                       // Mock iterator behavior
                                       when(pointer.childIterator(any(), anyBoolean(), any())).thenReturn(mock(NodeIterator.class));
                                       
                                       // Test case 1: With prefix (should use prefix's namespace URI)
                                       try {
                                           pointer.createChild(context, nameWithPrefix, index);
                                           // Verify the NodeNameTest would have been created with correct namespace URI
                                           verify(context).getNamespaceURI("testPrefix");
                                           verify(context, never()).getDefaultNamespaceURI();
                                       } catch (Exception e) {
                                           fail("Should not throw exception for valid prefix");
                                       }
                                       
                                       // Test case 2: Without prefix (should use default namespace URI)
                                       try {
                                           pointer.createChild(context, nameWithoutPrefix, index);
                                           // Verify the NodeNameTest would have been created with default namespace URI
                                           verify(context).getDefaultNamespaceURI();
                                           verify(context, never()).getNamespaceURI(null);
                                       } catch (Exception e) {
                                           fail("Should not throw exception for null prefix");
                                       }
                                       
                                       // The mutant would fail these tests because:
                                       // 1. For nameWithPrefix, it would try to get default namespace instead
                                       // 2. For nameWithoutPrefix, it would try to get namespace URI for null prefix
                                   }

    @Test
                               public void testCreateChildWithNamespace() {
                                   // Setup test data
                                   Node mockNode = mock(Node.class);
                                   JXPathContext mockContext = mock(JXPathContext.class);
                                   QName name = new QName("testPrefix", "testLocalName");
                                   Object value = "testValue";
                                   int index = 0;
                                   
                                   // Mock namespace behavior - this is what the mutant changes
                                   when(mockContext.getNamespaceURI("testPrefix")).thenReturn("http://test.namespace");
                                   
                                   // Create test instance
                                   DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                   
                                   // Execute method under test
                                   NodePointer result = pointer.createChild(mockContext, name, index, value);
                                   
                                   // Verify namespace handling was correct
                                   assertEquals("http://test.namespace", result.getNamespaceURI("testPrefix"));
                                   
                                   // Additional verification that the value was set
                                   assertEquals(value, result.getValue());
                                   
                                   // Verify the context was properly queried for namespace (this would fail with mutant)
                                   verify(mockContext).getNamespaceURI("testPrefix");
                               }

    @Test
                      public void testCreateChildWithNamespacedNode() throws Exception {
                          // Setup test data
                          JXPathContext context = mock(JXPathContext.class);
                          QName name = new QName("testPrefix", "testLocalName");
                          int index = 0;
                          
                          // Mock node and iterator behavior
                          Node node = mock(Node.class);
                          NodeIterator it = mock(NodeIterator.class);
                          when(it.setPosition(index + 1)).thenReturn(true);
                          when(it.getNodePointer()).thenReturn(mock(NodePointer.class));
                          
                          // Create test instance
                          DOMNodePointer pointer = new DOMNodePointer(node, Locale.getDefault());
                          
                          // Mock context behavior
                          when(context.getNamespaceURI("testPrefix")).thenReturn("http://test.namespace");
                          when(context.getDefaultNamespaceURI()).thenReturn("http://default.namespace");
                          
                          // Mock factory behavior
                          AbstractFactory factory = mock(AbstractFactory.class);
                          when(factory.createObject(context, pointer, node, "testLocalName", index))
                              .thenReturn(true);
                          
                          // Use reflection to set the private factory field
                          Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                          factoryField.setAccessible(true);
                          factoryField.set(pointer, factory);
                          
                          // Mock child iterator
                          when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                              .thenReturn(it);
                          
                          // Execute and verify
                          NodePointer result = pointer.createChild(context, name, index);
                          
                          // Verify namespace URI was properly used
                          org.mockito.ArgumentCaptor<NodeTest> nodeTestCaptor = 
                              org.mockito.ArgumentCaptor.forClass(NodeTest.class);
                          verify(pointer).childIterator(nodeTestCaptor.capture(), eq(false), isNull());
                          
                          NodeNameTest nodeTest = (NodeNameTest) nodeTestCaptor.getValue();
                          assertEquals("http://test.namespace", nodeTest.getNamespaceURI());
                          assertNotNull(result);
                      }

    @Test
                 public void testCreateChildDetectsNodeTestNullMutation() throws Exception {
                     // Setup test data
                     JXPathContext context = mock(JXPathContext.class);
                     QName name = new QName("test");
                     int index = 0;
                     
                     // Mock node and namespaces
                     Node mockNode = mock(Node.class);
                     when(context.getNamespaceURI(anyString())).thenReturn("testNamespace");
                     when(context.getDefaultNamespaceURI()).thenReturn("defaultNamespace");
                     
                     // Create test instance
                     DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                     
                     // Mock factory to return success
                     AbstractFactory mockFactory = mock(AbstractFactory.class);
                     when(mockFactory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
                     
                     // Use reflection to access private getAbstractFactory method
                     Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                     getAbstractFactoryMethod.setAccessible(true);
                     
                     // Replace the method to return our mock factory
                     getAbstractFactoryMethod.invoke(pointer, context);
                     Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                     factoryField.setAccessible(true);
                     factoryField.set(pointer, mockFactory);
                     
                     // Mock child iterator to return a valid node when given proper NodeTest
                     NodeIterator mockIterator = mock(NodeIterator.class);
                     when(mockIterator.setPosition(anyInt())).thenReturn(true);
                     NodePointer expectedPointer = mock(NodePointer.class);
                     when(mockIterator.getNodePointer()).thenReturn(expectedPointer);
                     
                     // Stub childIterator to return our mock iterator ONLY when given non-null NodeTest
                     doReturn(mockIterator).when(pointer).childIterator(
                         argThat(test -> test != null), // This will fail for the mutant
                         anyBoolean(),
                         isNull());
                     
                     // Test - should return the pointer if everything works
                     NodePointer result = pointer.createChild(context, name, index);
                     
                     // Verify we got the expected pointer (would throw exception with mutant)
                     assertSame(expectedPointer, result);
                     
                     // Verify childIterator was called with non-null NodeTest
                     verify(pointer).childIterator(
                         argThat(test -> test instanceof NodeNameTest),
                         eq(false),
                         isNull());
                     
                     // Reset accessibility
                     getAbstractFactoryMethod.setAccessible(false);
                     factoryField.setAccessible(false);
                 }

    @Test
         public void testCreateChildWithNameValidation() throws Exception {
             // Setup test data
             JXPathContext context = mock(JXPathContext.class);
             QName name = new QName("testName");
             int index = 0;
             Object value = "testValue";
             
             // Mock node and expected behavior
             Node mockNode = mock(Node.class);
             when(mockNode.getLocalName()).thenReturn("testName");
             
             // Create test instance
             DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
             
             // Execute and verify
             NodePointer result = pointer.createChild(context, name, index, value);
             assertNotNull("Returned pointer should not be null", result);
             
             // Verify the child node was properly created with name validation
             // Create a simple NodeTest implementation for testing
             NodeTest nodeTest = new NodeTest() {
                 public boolean isNameTest() {
                     return true;
                 }
                 public QName getNodeName() {
                     return name;
                 }
                 public boolean isWildcard() {
                     return false;
                 }
             };
             assertTrue("Child node should match the name test", pointer.testNode(nodeTest));
             
             // Verify value was set
             assertEquals("Value should be set correctly", value, result.getValue());
         }

    @Test(expected = RuntimeException.class) // Or more specific exception if known
     public void testCreateChildWithNullIterator5() {
         // Setup
         JXPathContext context = mock(JXPathContext.class);
         QName name = new QName("test");
         int index = 0;
         Object value = "testValue";
         
         // Create test instance - need to mock node since it's required in constructor
         Node mockNode = mock(Node.class);
         DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
         
         // Mock behavior to force null iterator
         // Assuming childIterator returns null when certain conditions are met
         // Need to mock the internal behavior that would make it return null
         when(pointer.childIterator(any(), anyBoolean(), any())).thenReturn(null);
         
         // Test - should throw exception with original code, but mutant would pass
         pointer.createChild(context, name, index, value);
         
         // If we reach here in original code, the test fails
         // Mutant would pass through without exception
     }

    @Test(expected = JXPathAbstractFactoryException.class)
    public void testCreateChildWithNullIterator4() throws Exception {
        // Setup test data
        JXPathContext context = mock(JXPathContext.class);
        QName name = new QName("test");
        int index = 0;
        
        // Mock the DOMNodePointer and its dependencies
        DOMNodePointer pointer = mock(DOMNodePointer.class);
        Node node = mock(Node.class);
        
        // Mock behavior - factory succeeds but returns null iterator
        // Instead of mocking private getAbstractFactory, we'll mock the public createObject call
        when(pointer.createChild(context, name, index)).thenCallRealMethod();
        when(pointer.getNode()).thenReturn(node);
        when(pointer.asPath()).thenReturn("/test");
        
        // Mock the factory behavior indirectly
        AbstractFactory factory = mock(AbstractFactory.class);
        when(factory.createObject(
            any(), any(), any(), any(), anyInt())).thenReturn(true);
        
        // Use reflection to set the factory since getAbstractFactory is private
        Field factoryField = DOMNodePointer.class.getDeclaredField("abstractFactory");
        factoryField.setAccessible(true);
        factoryField.set(pointer, factory);
        
        // Mock child iterator to return null
        when(pointer.childIterator(any(), anyBoolean(), any())).thenReturn(null);
        
        // Call the method - should throw exception
        pointer.createChild(context, name, index);
    }


}
