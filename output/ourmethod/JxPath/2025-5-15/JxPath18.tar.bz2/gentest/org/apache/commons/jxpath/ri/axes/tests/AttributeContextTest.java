package gentest.org.apache.commons.jxpath.ri.axes.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.axes.*;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class AttributeContextTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                   public void testNextNode_WithNodeTypeTest_NodeTypeNode_UsesWildcard() {
                                                                       // Define required mocks
                                                                       NodeTest nodeTest = mock(NodeTest.class);
                                                                       NodeTypeTest nodeTypeTest = mock(NodeTypeTest.class);
                                                                       NodePointer nodePointer = mock(NodePointer.class);
                                                                       NodeIterator iterator = mock(NodeIterator.class);
                                                                       EvalContext parentContext = mock(EvalContext.class);
                                                                       
                                                                       // Define WILDCARD_TEST constant
                                                                       NodeNameTest WILDCARD_TEST = new NodeNameTest(null);
                                                                       
                                                                       // Setup mock behavior
                                                                       when(nodeTest instanceof NodeTypeTest).thenReturn(true);
                                                                       when((NodeTypeTest)nodeTest).thenReturn(nodeTypeTest);
                                                                       when(nodeTypeTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                                                       when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                                                                       when(nodePointer.attributeIterator(WILDCARD_TEST.getNodeName())).thenReturn(iterator);
                                                                       when(iterator.setPosition(1)).thenReturn(true);
                                                                       when(iterator.getNodePointer()).thenReturn(nodePointer);
                                                                       
                                                                       // Create test object
                                                                       AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                       
                                                                       // Test and verify
                                                                       boolean result = attributeContext.nextNode();
                                                                       assertTrue(result);
                                                                   }

    @Test
                                                                   public void testNextNode_WithUnsupportedNodeTest_ReturnsFalse() {
                                                                       // Create a mock NodeTest that isn't NodeNameTest or NodeTypeTest
                                                                       NodeTest nodeTest = mock(NodeTest.class);
                                                                       
                                                                       // Create mock parent context
                                                                       EvalContext parentContext = mock(EvalContext.class);
                                                                       NodePointer nodePointer = mock(NodePointer.class);
                                                                       when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                                                                       
                                                                       // Create attribute context with unsupported node test
                                                                       AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                       
                                                                       // Test nextNode() should return false for unsupported node test
                                                                       boolean result = attributeContext.nextNode();
                                                                       
                                                                       assertFalse(result);
                                                                   }

    @Test
                                                               public void testNextNode_WithNodeNameTest_SuccessfulIteration() {
                                                                   // Create all required mock objects
                                                                   NodeTest nodeTest = mock(NodeTest.class);
                                                                   NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                                                                   NodePointer nodePointer = mock(NodePointer.class);
                                                                   NodeIterator iterator = mock(NodeIterator.class);
                                                                   EvalContext parentContext = mock(EvalContext.class);
                                                                   
                                                                   // Setup mock behavior
                                                                   nodeTest = nodeNameTest;
                                                                   QName attrQName = new QName("attrName");
                                                                   when(nodeNameTest.getNodeName()).thenReturn(attrQName);
                                                                   when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                                                                   when(nodePointer.attributeIterator(attrQName)).thenReturn(iterator);
                                                                   when(iterator.setPosition(1)).thenReturn(true);
                                                                   when(iterator.getNodePointer()).thenReturn(nodePointer);
                                                                   
                                                                   AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                   boolean result = attributeContext.nextNode();
                                                                   
                                                                   assertTrue(result);
                                                                   verify(iterator).setPosition(1);
                                                               }

    @Test
                                                               public void testNextNode_IteratorNullAfterSetup_ReturnsFalse() {
                                                                   // Create mock objects
                                                                   NodeTest nodeTest = mock(NodeTest.class);
                                                                   NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                                                                   NodePointer nodePointer = mock(NodePointer.class);
                                                                   EvalContext parentContext = mock(EvalContext.class);
                                                                   
                                                                   // Create QName for attribute name
                                                                   QName attrName = new QName("attrName");
                                                                   
                                                                   // Setup mock behavior
                                                                   when(nodeTest instanceof NodeNameTest).thenReturn(true);
                                                                   when(((NodeNameTest)nodeTest)).thenReturn(nodeNameTest);
                                                                   when(nodeNameTest.getNodeName()).thenReturn(attrName);
                                                                   when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                                                                   when(nodePointer.attributeIterator(attrName)).thenReturn(null);
                                                                   
                                                                   // Create test object
                                                                   AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                   
                                                                   // Test and verify
                                                                   boolean result = attributeContext.nextNode();
                                                                   assertFalse(result);
                                                               }

    @Test
                                                               public void testNextNode_IteratorSetPositionFails_ReturnsFalse() {
                                                                   // Create mocks
                                                                   NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                                                                   NodePointer nodePointer = mock(NodePointer.class);
                                                                   NodeIterator iterator = mock(NodeIterator.class);
                                                                   
                                                                   // Setup parent context mock
                                                                   EvalContext parentContext = mock(EvalContext.class);
                                                                   when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                                                                   
                                                                   // Setup node test behavior
                                                                   QName qname = new QName("attrName");
                                                                   when(nodeNameTest.getNodeName()).thenReturn(qname);
                                                                   
                                                                   // Setup iterator behavior
                                                                   when(nodePointer.attributeIterator(qname)).thenReturn(iterator);
                                                                   when(iterator.setPosition(1)).thenReturn(false);
                                                                   
                                                                   // Create test object and verify
                                                                   AttributeContext attributeContext = new AttributeContext(parentContext, nodeNameTest);
                                                                   boolean result = attributeContext.nextNode();
                                                                   
                                                                   assertFalse(result);
                                                               }

    @Test
                                                               public void testNextNode_SubsequentCalls_UseExistingIterator() {
                                                                   // Setup mocks
                                                                   NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                                                                   NodeTest nodeTest = mock(NodeTest.class);
                                                                   NodePointer nodePointer = mock(NodePointer.class);
                                                                   NodeIterator iterator = mock(NodeIterator.class);
                                                                   EvalContext parentContext = mock(EvalContext.class);
                                                                   
                                                                   // Create QName for attribute
                                                                   QName attrQName = new QName(null, "attrName");
                                                                   
                                                                   // Mock nodeTest to behave like NodeNameTest
                                                                   when(nodeTest instanceof NodeNameTest).thenReturn(true);
                                                                   when(nodeNameTest.getNodeName()).thenReturn(attrQName);
                                                                   when(nodeTest).thenReturn(nodeNameTest);
                                                                   
                                                                   // Mock iterator behavior
                                                                   when(iterator.setPosition(1)).thenReturn(true);
                                                                   when(iterator.setPosition(2)).thenReturn(true);
                                                                   when(iterator.getNodePointer()).thenReturn(nodePointer);
                                                                   
                                                                   // Mock parent context to return nodePointer
                                                                   when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                                                                   
                                                                   // Mock nodePointer to return our iterator
                                                                   when(nodePointer.attributeIterator(attrQName)).thenReturn(iterator);
                                                                   
                                                                   // Create test context
                                                                   AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                   
                                                                   // First call sets up iterator
                                                                   assertTrue(attributeContext.nextNode());
                                                                   // Second call uses existing iterator
                                                                   assertTrue(attributeContext.nextNode());
                                                                   
                                                                   // Verify iterator was only created once
                                                                   verify(nodePointer, times(1)).attributeIterator(attrQName);
                                                                   verify(iterator).setPosition(1);
                                                                   verify(iterator).setPosition(2);
                                                               }

    @Test
                                                               public void testNextNode_AfterReset_ReinitializesIterator() {
                                                                   // Create all required mock objects
                                                                   NodeTest nodeTest = mock(NodeTest.class);
                                                                   NodeNameTest nodeNameTest = mock(NodeNameTest.class);
                                                                   NodePointer nodePointer = mock(NodePointer.class);
                                                                   NodeIterator iterator = mock(NodeIterator.class);
                                                                   EvalContext parentContext = mock(EvalContext.class);
                                                                   
                                                                   // Create QName for attribute
                                                                   QName attrQName = new QName("attrName");
                                                                   
                                                                   // Set up mock behavior
                                                                   when(nodeTest instanceof NodeNameTest).thenReturn(true);
                                                                   when(((NodeNameTest) nodeTest).getNodeName()).thenReturn(attrQName);
                                                                   when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                                                                   when(nodePointer.attributeIterator(attrQName)).thenReturn(iterator);
                                                                   when(iterator.setPosition(1)).thenReturn(true);
                                                                   when(iterator.getNodePointer()).thenReturn(nodePointer);
                                                                   
                                                                   // Create test object
                                                                   AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                                   
                                                                   // First call
                                                                   assertTrue(attributeContext.nextNode());
                                                                   
                                                                   // Reset
                                                                   attributeContext.reset();
                                                                   
                                                                   // Second call should reinitialize
                                                                   assertTrue(attributeContext.nextNode());
                                                                   
                                                                   // Verify attributeIterator was called twice
                                                                   verify(nodePointer, times(2)).attributeIterator(attrQName);
                                                               }

    @Test
                                                           public void testNextNode_WithNodeTypeTest_NonNodeType_ReturnsFalse() {
                                                               NodeTypeTest nodeTypeTest = mock(NodeTypeTest.class);
                                                               NodeTest nodeTest = mock(NodeTest.class);
                                                               EvalContext parentContext = mock(EvalContext.class);
                                                               NodePointer nodePointer = mock(NodePointer.class);
                                                               
                                                               // Define the node type constant directly
                                                               final int NODE_TYPE_ELEMENT = 1;
                                                               
                                                               // Setup mocks correctly
                                                               when(nodeTest instanceof NodeTypeTest).thenReturn(true);
                                                               when(((NodeTypeTest)nodeTest).getNodeType()).thenReturn(NODE_TYPE_ELEMENT);
                                                               
                                                               when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                                                               
                                                               AttributeContext attributeContext = new AttributeContext(parentContext, nodeTest);
                                                               boolean result = attributeContext.nextNode();
                                                               
                                                               assertFalse(result);
                                                           }

    @Test
                                                      public void testNextNode_DetectsCurrentNodePointerMutation() {
                                                          // Setup test objects and mocks
                                                          EvalContext parentContext = mock(EvalContext.class);
                                                          NodeTest nodeTest = mock(NodeNameTest.class);
                                                          NodeIterator iterator = mock(NodeIterator.class);
                                                          NodePointer expectedPointer = mock(NodePointer.class);
                                                          QName testQName = new QName("testAttribute");
                                                          
                                                          // Create the object under test
                                                          AttributeContext context = new AttributeContext(parentContext, nodeTest);
                                                          
                                                          // Configure mocks
                                                          when(((NodeNameTest)nodeTest).getNodeName()).thenReturn(testQName);
                                                          NodePointer parentPointer = mock(NodePointer.class);
                                                          when(parentContext.getCurrentNodePointer()).thenReturn(parentPointer);
                                                          when(parentPointer.attributeIterator(testQName)).thenReturn(iterator);
                                                          when(iterator.setPosition(anyInt())).thenReturn(true);
                                                          when(iterator.getNodePointer()).thenReturn(expectedPointer);
                                                          
                                                          // Execute the method
                                                          boolean result = context.nextNode();
                                                          
                                                          // Verify results - both the return value and the side effect
                                                          assertTrue("Method should return true for successful iteration", result);
                                                          
                                                          // This assertion will catch the mutant - original would have non-null pointer
                                                          assertNotNull("currentNodePointer should be set after successful iteration", 
                                                              context.getCurrentNodePointer());
                                                          
                                                          // Additional verification that we got the expected pointer
                                                          assertEquals("currentNodePointer should match iterator's node pointer", 
                                                              expectedPointer, context.getCurrentNodePointer());
                                                      }

    @Test
                                                 public void testNextNode_ShouldSetCurrentNodePointerFromIterator_NotParentContext() {
                                                     // Setup test data and mocks
                                                     QName testQName = new QName("testAttr");
                                                     NodeTest nodeTest = mock(NodeNameTest.class);
                                                     when(((NodeNameTest) nodeTest).getNodeName()).thenReturn(testQName);
                                                     
                                                     EvalContext parentContext = mock(EvalContext.class);
                                                     NodePointer parentNodePointer = mock(NodePointer.class);
                                                     when(parentContext.getCurrentNodePointer()).thenReturn(parentNodePointer);
                                                     
                                                     NodeIterator iterator = mock(NodeIterator.class);
                                                     NodePointer iteratorNodePointer = mock(NodePointer.class);
                                                     when(iterator.getNodePointer()).thenReturn(iteratorNodePointer);
                                                     when(iterator.setPosition(anyInt())).thenReturn(true);
                                                     when(parentNodePointer.attributeIterator(eq(testQName))).thenReturn(iterator);
                                                     
                                                     // Create test instance
                                                     AttributeContext context = new AttributeContext(parentContext, nodeTest);
                                                     
                                                     // Call method under test
                                                     boolean result = context.nextNode();
                                                     
                                                     // Verify behavior
                                                     assertTrue(result);
                                                     
                                                     // This is the key assertion that catches the mutant
                                                     // Original code would set currentNodePointer to iterator's node pointer
                                                     // Mutant would set it to parentContext's node pointer
                                                     assertEquals(iteratorNodePointer, context.getCurrentNodePointer());
                                                     
                                                     // Additional verification that parent's node pointer is different
                                                     assertNotEquals(parentNodePointer, context.getCurrentNodePointer());
                                                 }

    @Test
                                            public void testNextNode_DetectsReturnTrueMutant() throws Exception {
                                                // Setup test objects
                                                EvalContext parentContext = mock(EvalContext.class);
                                                NodeTest nodeTest = mock(NodeNameTest.class);
                                                NodeIterator iterator = mock(NodeIterator.class);
                                                NodePointer nodePointer = mock(NodePointer.class);
                                                
                                                // Create QName for attribute
                                                QName testAttr = new QName("testAttr");
                                                
                                                // Create AttributeContext instance
                                                AttributeContext context = new AttributeContext(parentContext, nodeTest);
                                                
                                                // Mock behavior
                                                when(((NodeNameTest)nodeTest).getNodeName()).thenReturn(testAttr);
                                                when(parentContext.getCurrentNodePointer()).thenReturn(mock(NodePointer.class));
                                                when(parentContext.getCurrentNodePointer().attributeIterator(eq(testAttr))).thenReturn(iterator);
                                                when(iterator.setPosition(anyInt())).thenReturn(false); // Simulate end of iteration
                                                when(iterator.getPosition()).thenReturn(0); // Initial position
                                                
                                                // Get iterator field via reflection
                                                Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                                                iteratorField.setAccessible(true);
                                                
                                                // Set iterator to null after iteration attempt
                                                // This is the key scenario to detect the mutant
                                                when(iterator.setPosition(1)).thenAnswer(invocation -> {
                                                    iteratorField.set(context, null); // Simulate iterator becoming null via reflection
                                                    return false;
                                                });
                                                
                                                // First call initializes iterator
                                                assertTrue(context.nextNode());
                                                
                                                // Second call should return true (successful iteration end) in original,
                                                // but mutant would return false because iterator is now null
                                                assertTrue("Should return true for successful iteration end", context.nextNode());
                                                
                                                // Verify the mutation would fail this test since mutant would return false
                                            }

    @Test
                                       public void testNextNode_ShouldSetCurrentNodePointerToActualNodeNotParent() {
                                           // Setup test objects
                                           EvalContext parentContext = mock(EvalContext.class);
                                           NodeTest nodeTest = mock(NodeNameTest.class);
                                           NodeIterator mockIterator = mock(NodeIterator.class);
                                           NodePointer expectedNodePointer = mock(NodePointer.class);
                                           NodePointer parentNodePointer = mock(NodePointer.class);
                                           QName testQName = new QName("testAttr");
                                           
                                           // Configure mocks
                                           when(((NodeNameTest)nodeTest).getNodeName()).thenReturn(testQName);
                                           when(parentContext.getCurrentNodePointer()).thenReturn(mock(NodePointer.class));
                                           when(parentContext.getCurrentNodePointer().attributeIterator(any(QName.class))).thenReturn(mockIterator);
                                           when(mockIterator.setPosition(1)).thenReturn(true);
                                           when(mockIterator.getNodePointer()).thenReturn(expectedNodePointer);
                                           when(expectedNodePointer.getParent()).thenReturn(parentNodePointer);
                                           
                                           // Create test instance
                                           AttributeContext context = new AttributeContext(parentContext, nodeTest);
                                           
                                           // Execute test
                                           boolean result = context.nextNode();
                                           
                                           // Verify results
                                           assertTrue(result);
                                           
                                           // The key assertion - verify we got the actual node pointer, not its parent
                                           // This will fail if the mutant is present (which would return the parent)
                                           NodePointer actualNodePointer = context.getCurrentNodePointer();
                                           assertSame(expectedNodePointer, actualNodePointer);
                                           
                                           // Additional verification that we didn't get the parent
                                           assertNotSame(parentNodePointer, actualNodePointer);
                                       }

    @Test
                                  public void testNextNode_ShouldReturnTrueWhenPositionSetButPointerNull_DetectsMutant() {
                                      // Setup
                                      EvalContext parentContext = mock(EvalContext.class);
                                      NodeTest nodeTest = mock(NodeNameTest.class);
                                      NodePointer currentNodePointer = mock(NodePointer.class);
                                      NodeIterator iterator = mock(NodeIterator.class);
                                      
                                      AttributeContext context = new AttributeContext(parentContext, nodeTest);
                                      
                                      // Mock behavior
                                      when(parentContext.getCurrentNodePointer()).thenReturn(currentNodePointer);
                                      when(currentNodePointer.attributeIterator(any(QName.class))).thenReturn(iterator);
                                      when(iterator.setPosition(anyInt())).thenReturn(true);
                                      when(iterator.getNodePointer()).thenReturn(null); // This is the key difference
                                      
                                      // First call initializes the iterator
                                      context.nextNode();
                                      
                                      // Test - should return true when position set successfully, regardless of pointer null
                                      assertTrue("Should return true when position set successfully, regardless of pointer null", 
                                                 context.nextNode());
                                      
                                      // Verify the mutant would fail this test (mutant would return false)
                                  }

    @Test
                             public void testNextNode_ShouldReturnTrueWhenSuccessRegardlessOfPosition() {
                                 // Setup mocks
                                 NodeNameTest mockNodeTest = mock(NodeNameTest.class);
                                 NodeIterator mockIterator = mock(NodeIterator.class);
                                 NodePointer mockNodePointer = mock(NodePointer.class);
                                 EvalContext mockParentContext = mock(EvalContext.class);
                                 NodePointer mockCurrentNodePointer = mock(NodePointer.class);
                                 
                                 // Create QName for attribute name
                                 QName testQName = new QName("testAttr");
                                 
                                 // Configure mocks
                                 when(mockNodeTest.getNodeName()).thenReturn(testQName);
                                 when(mockParentContext.getCurrentNodePointer()).thenReturn(mockCurrentNodePointer);
                                 when(mockCurrentNodePointer.attributeIterator(eq(testQName))).thenReturn(mockIterator);
                                 when(mockIterator.setPosition(anyInt())).thenReturn(true);
                                 when(mockIterator.getNodePointer()).thenReturn(mockNodePointer);
                                 when(mockIterator.getPosition()).thenReturn(0); // Position is 0
                                 
                                 // Create test object
                                 AttributeContext context = new AttributeContext(mockParentContext, mockNodeTest);
                                 
                                 // Test - should return true regardless of position
                                 assertTrue(context.nextNode());
                                 
                                 // Verify position is indeed 0 to ensure we're testing the right case
                                 verify(mockIterator).getPosition();
                             }

    @Test
                        public void testNextNode_DetectsReturnTrueMutant1() {
                            // Setup test objects
                            EvalContext parentContext = mock(EvalContext.class);
                            NodeTest nodeTest = mock(NodeNameTest.class);
                            NodePointer nodePointer = mock(NodePointer.class);
                            NodeIterator iterator = mock(NodeIterator.class);
                            
                            // Create test instance
                            AttributeContext context = new AttributeContext(parentContext, nodeTest);
                            
                            // Set up initial conditions
                            when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                            QName testQName = new QName("testAttr");
                            when(((NodeNameTest)nodeTest).getNodeName()).thenReturn(testQName);
                            when(nodePointer.attributeIterator(eq(testQName))).thenReturn(iterator);
                            
                            // First call to nextNode() initializes iterator
                            assertTrue(context.nextNode());
                            
                            // Set up iterator to fail on setPosition but be non-null
                            when(iterator.setPosition(anyInt())).thenReturn(false);
                            when(iterator.getPosition()).thenReturn(0);
                            
                            // This should return false (original behavior) but mutant would return true
                            assertFalse("Mutant detected - should return false when setPosition fails", 
                                       context.nextNode());
                            
                            // Verify iterator was used correctly
                            verify(iterator).setPosition(1);
                        }

    @Test
                   public void testNextNode_ShouldReturnTrueWhenIteratorAdvancesAtPositionZero() throws Exception {
                       // Setup test objects
                       EvalContext parentContext = mock(EvalContext.class);
                       NodeTest nodeTest = mock(NodeNameTest.class);
                       NodePointer nodePointer = mock(NodePointer.class);
                       NodeIterator iterator = mock(NodeIterator.class);
                       
                       // Create QName for attribute
                       QName testAttr = new QName("testAttr");
                       
                       // Create the test instance
                       AttributeContext context = new AttributeContext(parentContext, nodeTest);
                       
                       // Mock behavior - first call to setStarted=false path
                       when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                       when(((NodeNameTest)nodeTest).getNodeName()).thenReturn(testAttr);
                       when(nodePointer.attributeIterator(testAttr)).thenReturn(iterator);
                       
                       // Mock iterator behavior - successful advance but position=0
                       when(iterator.setPosition(1)).thenReturn(true);
                       when(iterator.getPosition()).thenReturn(0);
                       when(iterator.getNodePointer()).thenReturn(nodePointer);
                       
                       // Set initial state using reflection
                       Field setStartedField = AttributeContext.class.getDeclaredField("setStarted");
                       setStartedField.setAccessible(true);
                       setStartedField.setBoolean(context, false);
                       
                       // Execute and verify
                       assertTrue("Should return true when iterator advances successfully, even at position 0", 
                                 context.nextNode());
                       
                       // Verify the position was incremented
                       verify(iterator).setPosition(1);
                       verify(iterator).getNodePointer();
                   }

    @Test
              public void testNextNode_DetectsMutantWhenIteratorExistsButIterationFails() throws Exception {
                  // Setup test objects
                  EvalContext parentContext = mock(EvalContext.class);
                  NodeTest nodeTest = mock(NodeNameTest.class);
                  NodePointer nodePointer = mock(NodePointer.class);
                  NodeIterator iterator = mock(NodeIterator.class);
                  
                  // Create test instance
                  AttributeContext context = new AttributeContext(parentContext, nodeTest);
                  
                  // Set initial state using reflection
                  Field setStartedField = AttributeContext.class.getDeclaredField("setStarted");
                  setStartedField.setAccessible(true);
                  setStartedField.setBoolean(context, true); // Skip initialization phase
                  
                  Field iteratorField = AttributeContext.class.getDeclaredField("iterator");
                  iteratorField.setAccessible(true);
                  iteratorField.set(context, iterator); // Set iterator to exist
                  
                  // Mock behavior
                  when(iterator.setPosition(anyInt())).thenReturn(false); // Simulate failed iteration
                  when(parentContext.getCurrentNodePointer()).thenReturn(nodePointer);
                  when(nodePointer.attributeIterator(any(QName.class))).thenReturn(iterator);
                  
                  // Execute and verify
                  assertFalse("Should return false when iteration fails", context.nextNode());
                  
                  // This would catch the mutant because:
                  // Original: returns false (correct)
                  // Mutant: returns iterator!=null (true) - incorrect
              }

    @Test
         public void testNextNode_DetectsReturnTrueMutant2() {
             // Setup test context
             EvalContext parentContext = mock(EvalContext.class);
             NodeTest nodeTest = mock(NodeNameTest.class);
             NodePointer parentPointer = mock(NodePointer.class);
             NodeIterator iterator = mock(NodeIterator.class);
             
             // Create QName for attribute
             QName testAttr = new QName("testAttr");
             
             // Create the object to test
             AttributeContext context = new AttributeContext(parentContext, nodeTest);
             
             // Mock the behavior
             when(parentContext.getCurrentNodePointer()).thenReturn(parentPointer);
             when(((NodeNameTest)nodeTest).getNodeName()).thenReturn(testAttr);
             when(parentPointer.attributeIterator(eq(testAttr))).thenReturn(iterator);
             
             // Setup iterator to succeed setPosition but return null pointer
             when(iterator.setPosition(anyInt())).thenReturn(true);
             when(iterator.getNodePointer()).thenReturn(null);
             
             // Execute the test
             boolean result = context.nextNode();
             
             // Verify the mutant would fail here - original returns true, mutant returns false
             assertTrue("Should return true when setPosition succeeds, regardless of node pointer", result);
             
             // Additional verification
             verify(iterator).setPosition(1);
             verify(iterator).getNodePointer();
         }

    @Test
    public void testNextNode_ShouldReturnTrueWhenIteratorAdvances_EvenAtPositionZero() {
        // Setup test objects and mocks
        NodeNameTest nodeTest = mock(NodeNameTest.class);
        EvalContext parentContext = mock(EvalContext.class);
        NodePointer parentPointer = mock(NodePointer.class);
        NodeIterator iterator = mock(NodeIterator.class);
        
        // Configure mocks
        when(parentContext.getCurrentNodePointer()).thenReturn(parentPointer);
        QName testQName = new QName("testAttribute");
        when(nodeTest.getNodeName()).thenReturn(testQName);
        when(parentPointer.attributeIterator(testQName)).thenReturn(iterator);
        
        // Configure iterator to report success but position 0
        when(iterator.setPosition(1)).thenReturn(true);
        when(iterator.getPosition()).thenReturn(0);
        when(iterator.getNodePointer()).thenReturn(mock(NodePointer.class));
        
        // Create test instance
        AttributeContext context = new AttributeContext(parentContext, nodeTest);
        
        // First call should initialize and advance
        assertTrue(context.nextNode());
        
        // Second call should test the mutant - original would return true,
        // mutant would return false because position is 0
        assertTrue("Should return true when iterator advances, regardless of position", 
                   context.nextNode());
    }


}
