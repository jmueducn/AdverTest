package gentest.org.apache.commons.jxpath.ri.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class NamespaceResolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                            public void testGetNamespaceURI_WithParentResolver() {
                                // Test parent resolver functionality
                                NamespaceResolver parent = new NamespaceResolver();
                                parent.registerNamespace("parent", "http://parent.example.com");
                                
                                NamespaceResolver child = new NamespaceResolver(parent);
                                
                                String result = child.getNamespaceURI("parent");
                                assertEquals("http://parent.example.com", result);
                            }

    @Test
                            public void testGetNamespaceURI_PriorityOfLocalOverParent() {
                                // Local registration should override parent
                                NamespaceResolver parent = new NamespaceResolver();
                                parent.registerNamespace("test", "http://parent.example.com");
                                
                                NamespaceResolver child = new NamespaceResolver(parent);
                                child.registerNamespace("test", "http://child.example.com");
                                
                                String result = child.getNamespaceURI("test");
                                assertEquals("http://child.example.com", result);
                            }

    @Test
                            public void testSeal_NoParent() {
                                // Test sealing a resolver with no parent
                                NamespaceResolver resolver = new NamespaceResolver();
                                resolver.seal();
                                
                                assertTrue(resolver.isSealed());
                            }

    @Test
                            public void testSeal_WithParent() {
                                // Test sealing a resolver with parent
                                NamespaceResolver parent = mock(NamespaceResolver.class);
                                NamespaceResolver resolver = new NamespaceResolver(parent);
                                
                                resolver.seal();
                                
                                assertTrue(resolver.isSealed());
                                verify(parent).seal(); // Verify parent was sealed
                            }

    @Test
                            public void testSeal_AlreadySealed() {
                                // Test sealing an already sealed resolver
                                NamespaceResolver resolver = new NamespaceResolver();
                                resolver.seal(); // First seal
                                
                                // Should not throw exception when sealing again
                                resolver.seal();
                                
                                assertTrue(resolver.isSealed());
                            }

    @Test
                            public void testSeal_WithParentChain() {
                                // Test sealing with multiple levels of parents
                                NamespaceResolver grandParent = mock(NamespaceResolver.class);
                                NamespaceResolver parent = new NamespaceResolver(grandParent);
                                NamespaceResolver resolver = new NamespaceResolver(parent);
                                
                                resolver.seal();
                                
                                assertTrue(resolver.isSealed());
                                assertTrue(parent.isSealed());
                                verify(grandParent).seal();
                            }

    @Test
                            public void testSeal_WithNullParent() {
                                // Test that null parent doesn't cause issues
                                NamespaceResolver resolver = new NamespaceResolver(null);
                                
                                resolver.seal();
                                
                                assertTrue(resolver.isSealed());
                            }

    @Test
                            public void testSeal_VerifyStateAfterSealing() {
                                // Test that other operations are blocked after sealing
                                NamespaceResolver resolver = new NamespaceResolver();
                                resolver.seal();
                                
                                // Verify that sealed state prevents modifications
                                try {
                                    resolver.registerNamespace("prefix", "uri");
                                    fail("Should have thrown IllegalStateException");
                                } catch (IllegalStateException e) {
                                    // Expected
                                }
                            }

    @Test
                            public void testClone_CreatesNewInstance() throws Exception {
                                NamespaceResolver original = new NamespaceResolver();
                                NamespaceResolver cloned = (NamespaceResolver) original.clone();
                                
                                assertNotNull(cloned);
                                assertNotSame(original, cloned);
                            }

    @Test
                            public void testClone_SealedFlagReset() throws Exception {
                                NamespaceResolver original = new NamespaceResolver();
                                original.seal();
                                
                                NamespaceResolver cloned = (NamespaceResolver) original.clone();
                                
                                assertTrue(original.isSealed());
                                assertFalse(cloned.isSealed());
                            }

    @Test
                    public void testGetPrefix_FoundInCurrentNode() {
                        // Setup mock objects
                        NodePointer pointer = mock(NodePointer.class);
                        NodeIterator ni = mock(NodeIterator.class);
                        NodePointer nsPointer = mock(NodePointer.class);
                        
                        // Setup mock behavior
                        when(pointer.namespaceIterator()).thenReturn(ni);
                        when(ni.setPosition(1)).thenReturn(true);
                        when(ni.getNodePointer()).thenReturn(nsPointer);
                        when(nsPointer.getNamespaceURI()).thenReturn("testURI");
                        when(nsPointer.getName()).thenReturn(new QName("testPrefix"));
                        
                        // Create resolver and set context pointer
                        NamespaceResolver resolver = new NamespaceResolver();
                        resolver.setNamespaceContextPointer(pointer);
                        
                        // Test
                        String result = resolver.getPrefix("testURI");
                        
                        // Verify
                        assertEquals("testPrefix", result);
                        verify(pointer, never()).getParent();
                    }

    @Test
                    public void testGetPrefix_FoundInParentNode() {
                        // Create mock objects
                        NodePointer pointer = mock(NodePointer.class);
                        NodePointer parentPointer = mock(NodePointer.class);
                        NodePointer nsPointer = mock(NodePointer.class);
                        NodeIterator ni = mock(NodeIterator.class);
                        
                        // Setup mock behavior for current node (no match)
                        when(pointer.namespaceIterator()).thenReturn(ni);
                        when(ni.setPosition(1)).thenReturn(true).thenReturn(false);
                        when(ni.getNodePointer()).thenReturn(nsPointer);
                        when(nsPointer.getNamespaceURI()).thenReturn("otherURI");
                        
                        // Setup mock behavior for parent node (match)
                        when(pointer.getParent()).thenReturn(parentPointer);
                        when(parentPointer.namespaceIterator()).thenReturn(ni);
                        when(nsPointer.getNamespaceURI()).thenReturn("testURI");
                        when(nsPointer.getName()).thenReturn(new QName("parentPrefix"));
                        
                        // Create resolver and set context pointer
                        NamespaceResolver resolver = new NamespaceResolver();
                        resolver.setNamespaceContextPointer(pointer);
                        
                        // Test
                        String result = resolver.getPrefix("testURI");
                        
                        // Verify
                        assertEquals("parentPrefix", result);
                        verify(pointer).getParent();
                    }

    @Test
                    public void testGetPrefix_EmptyPrefixSkipped() {
                        // Create mock objects
                        NodePointer pointer = mock(NodePointer.class);
                        NodeIterator ni = mock(NodeIterator.class);
                        NodePointer nsPointer = mock(NodePointer.class);
                        
                        // Setup mock behavior
                        when(pointer.namespaceIterator()).thenReturn(ni);
                        when(ni.setPosition(1)).thenReturn(true).thenReturn(true).thenReturn(false);
                        when(ni.getNodePointer()).thenReturn(nsPointer);
                        
                        // First namespace has matching URI but empty prefix
                        when(nsPointer.getNamespaceURI()).thenReturn("testURI");
                        when(nsPointer.getName()).thenReturn(new QName(""));
                        
                        // Second namespace has matching URI with valid prefix
                        when(nsPointer.getNamespaceURI()).thenReturn("testURI");
                        when(nsPointer.getName()).thenReturn(new QName("validPrefix"));
                        
                        // Create resolver and set namespace context
                        NamespaceResolver resolver = new NamespaceResolver();
                        resolver.setNamespaceContextPointer(pointer);
                        
                        // Test
                        String result = resolver.getPrefix("testURI");
                        
                        // Verify
                        assertEquals("validPrefix", result);
                    }

    @Test
                    public void testGetPrefix_NotFoundReturnsNull() {
                        // Create mock objects
                        NodePointer pointer = mock(NodePointer.class);
                        NodePointer nsPointer = mock(NodePointer.class);
                        NodeIterator ni = mock(NodeIterator.class);
                        
                        // Setup mock behavior (no matching URI)
                        when(pointer.namespaceIterator()).thenReturn(ni);
                        when(ni.setPosition(1)).thenReturn(true).thenReturn(false);
                        when(ni.getNodePointer()).thenReturn(nsPointer);
                        when(nsPointer.getNamespaceURI()).thenReturn("otherURI");
                        when(pointer.getParent()).thenReturn(null); // No parent
                        
                        // Create resolver and set the namespace context pointer
                        NamespaceResolver resolver = new NamespaceResolver();
                        resolver.setNamespaceContextPointer(pointer);
                        
                        // Test
                        String result = resolver.getPrefix("testURI");
                        
                        // Verify
                        assertNull(result);
                    }

    @Test
                    public void testGetPrefix_MultipleNamespacesInNode() {
                        // Setup mocks
                        NodePointer pointer = mock(NodePointer.class);
                        NodeIterator ni = mock(NodeIterator.class);
                        NamespaceResolver resolver = new NamespaceResolver();
                        resolver.setNamespaceContextPointer(pointer);
                        
                        // Setup mock behavior for multiple namespaces
                        when(pointer.namespaceIterator()).thenReturn(ni);
                        when(ni.setPosition(1)).thenReturn(true);
                        when(ni.setPosition(2)).thenReturn(true);
                        when(ni.setPosition(3)).thenReturn(false);
                        
                        NodePointer nsPointer1 = mock(NodePointer.class);
                        NodePointer nsPointer2 = mock(NodePointer.class);
                        
                        when(ni.getNodePointer()).thenReturn(nsPointer1).thenReturn(nsPointer2);
                        
                        // First namespace doesn't match
                        when(nsPointer1.getNamespaceURI()).thenReturn("otherURI1");
                        
                        // Second namespace matches
                        when(nsPointer2.getNamespaceURI()).thenReturn("testURI");
                        when(nsPointer2.getName()).thenReturn(new QName("correctPrefix"));
                        
                        // Test
                        String result = resolver.getPrefix("testURI");
                        
                        // Verify
                        assertEquals("correctPrefix", result);
                    }

    @Test
                    public void testGetPrefix_NullPointerReturnsNull() {
                        NamespaceResolver resolver = new NamespaceResolver();
                        resolver.setNamespaceContextPointer(null);
                        
                        String result = resolver.getPrefix("testURI");
                        
                        assertNull(result);
                    }

    @Test
                    public void testGetPrefix_NullNamespaceURIReturnsNull() {
                        NamespaceResolver resolver = new NamespaceResolver();
                        String result = resolver.getPrefix(null);
                        
                        assertNull(result);
                    }

    @Test
                    public void testGetPrefix_EmptyNamespaceURIReturnsNull() {
                        NamespaceResolver resolver = new NamespaceResolver();
                        String result = resolver.getPrefix("");
                        
                        assertNull(result);
                    }

    @Test
                    public void testGetNamespaceURI_ExternallyRegisteredExists() {
                        // Create resolver instance
                        NamespaceResolver resolver = new NamespaceResolver();
                        
                        // Setup resolver to return a URI for the prefix
                        resolver.registerNamespace("test", "http://example.com");
                        
                        String result = resolver.getNamespaceURI("test");
                        assertEquals("http://example.com", result);
                    }

    @Test
                    public void testGetNamespaceURI_ExternallyRegisteredNullPointerNull() {
                        // No external registration and no pointer
                        NamespaceResolver resolver = new NamespaceResolver();
                        String result = resolver.getNamespaceURI("nonexistent");
                        assertNull(result);
                    }

    @Test
                    public void testGetNamespaceURI_ExternallyRegisteredNullPointerReturnsURI() {
                        // Setup resolver and mock pointer
                        NamespaceResolver resolver = new NamespaceResolver();
                        NodePointer mockPointer = mock(NodePointer.class);
                        
                        // Setup pointer to return a URI when external registration is null
                        resolver.setNamespaceContextPointer(mockPointer);
                        when(mockPointer.getNamespaceURI("test")).thenReturn("http://pointer.example.com");
                        
                        String result = resolver.getNamespaceURI("test");
                        assertEquals("http://pointer.example.com", result);
                    }

    @Test
                    public void testGetNamespaceURI_ExternallyRegisteredNullPointerReturnsNull() {
                        // Setup resolver and mock pointer
                        NamespaceResolver resolver = new NamespaceResolver();
                        NodePointer mockPointer = mock(NodePointer.class);
                        
                        // Setup pointer but it returns null
                        resolver.setNamespaceContextPointer(mockPointer);
                        when(mockPointer.getNamespaceURI("test")).thenReturn(null);
                        
                        String result = resolver.getNamespaceURI("test");
                        assertNull(result);
                    }

    @Test
                    public void testGetNamespaceURI_NullPrefix() {
                        NamespaceResolver resolver = new NamespaceResolver();
                        String result = resolver.getNamespaceURI(null);
                        assertNull(result);
                    }

    @Test
                    public void testGetNamespaceURI_EmptyPrefix() {
                        // Test with empty string prefix
                        NamespaceResolver resolver = new NamespaceResolver();
                        resolver.registerNamespace("", "http://default.example.com");
                        
                        String result = resolver.getNamespaceURI("");
                        assertEquals("http://default.example.com", result);
                    }

    @Test
                    public void testGetExternallyRegisteredNamespaceURI_WhenPrefixExistsInCurrentMap() throws Exception {
                        // Setup
                        NamespaceResolver resolver = new NamespaceResolver();
                        
                        // Access protected namespaceMap field via reflection
                        Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        namespaceMapField.setAccessible(true);
                        Map<String, String> namespaceMap = new HashMap<>();
                        namespaceMap.put("test", "http://example.com");
                        namespaceMapField.set(resolver, namespaceMap);
                        
                        // Access protected method via reflection
                        Method method = NamespaceResolver.class.getDeclaredMethod(
                            "getExternallyRegisteredNamespaceURI", String.class);
                        method.setAccessible(true);
                        
                        // Test
                        String result = (String) method.invoke(resolver, "test");
                        
                        // Verify
                        assertEquals("http://example.com", result);
                    }

    @Test
                    public void testGetExternallyRegisteredNamespaceURI_WhenPrefixDoesNotExistAndNoParent() throws Exception {
                        // Setup
                        NamespaceResolver resolver = new NamespaceResolver();
                        
                        // Use reflection to access protected method
                        Method method = NamespaceResolver.class.getDeclaredMethod(
                            "getExternallyRegisteredNamespaceURI", String.class);
                        method.setAccessible(true);
                        
                        // Test
                        String result = (String) method.invoke(resolver, "nonexistent");
                        
                        // Verify
                        assertNull(result);
                    }

    @Test
                    public void testGetExternallyRegisteredNamespaceURI_WhenPrefixDoesNotExistInCurrentButExistsInParent() throws Exception {
                        // Setup
                        NamespaceResolver parent = new NamespaceResolver();
                        Map<String, String> parentMap = new HashMap<>();
                        parentMap.put("parent", "http://parent.com");
                        Field parentNamespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        parentNamespaceMapField.setAccessible(true);
                        parentNamespaceMapField.set(parent, parentMap);
                        
                        NamespaceResolver child = new NamespaceResolver(parent);
                        Field childNamespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        childNamespaceMapField.setAccessible(true);
                        childNamespaceMapField.set(child, new HashMap<>());
                        
                        // Test
                        Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                        method.setAccessible(true);
                        String result = (String) method.invoke(child, "parent");
                        
                        // Verify
                        assertEquals("http://parent.com", result);
                    }

    @Test
                    public void testGetExternallyRegisteredNamespaceURI_WhenPrefixDoesNotExistInCurrentButParentReturnsNull() throws Exception {
                        // Setup
                        NamespaceResolver parent = new NamespaceResolver();
                        Field parentNamespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        parentNamespaceMapField.setAccessible(true);
                        parentNamespaceMapField.set(parent, new HashMap<>());
                        
                        NamespaceResolver child = new NamespaceResolver(parent);
                        Field childNamespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        childNamespaceMapField.setAccessible(true);
                        childNamespaceMapField.set(child, new HashMap<>());
                        
                        // Test
                        Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                        method.setAccessible(true);
                        String result = (String) method.invoke(child, "nonexistent");
                        
                        // Verify
                        assertNull(result);
                    }

    @Test
                    public void testGetExternallyRegisteredNamespaceURI_WhenNamespaceMapIsNull() throws Exception {
                        // Setup
                        NamespaceResolver resolver = new NamespaceResolver();
                        
                        // Set namespaceMap to null using reflection
                        Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        namespaceMapField.setAccessible(true);
                        namespaceMapField.set(resolver, null);
                        
                        // Get the method using reflection
                        Method method = NamespaceResolver.class.getDeclaredMethod(
                            "getExternallyRegisteredNamespaceURI", String.class);
                        method.setAccessible(true);
                        
                        // Test
                        String result = (String) method.invoke(resolver, "test");
                        
                        // Verify
                        assertNull(result);
                    }

    @Test
                    public void testGetExternallyRegisteredNamespaceURI_WithNullPrefix() throws Exception {
                        // Setup
                        NamespaceResolver resolver = new NamespaceResolver();
                        
                        // Get the namespaceMap field using reflection
                        Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        namespaceMapField.setAccessible(true);
                        Map<String, String> namespaceMap = new HashMap<>();
                        namespaceMap.put(null, "http://null.com");
                        namespaceMapField.set(resolver, namespaceMap);
                        
                        // Get the method using reflection
                        Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                        method.setAccessible(true);
                        
                        // Test
                        String result = (String) method.invoke(resolver, (String) null);
                        
                        // Verify
                        assertEquals("http://null.com", result);
                    }

    @Test
                    public void testGetExternallyRegisteredNamespaceURI_WithEmptyPrefix() throws Exception {
                        // Setup
                        NamespaceResolver resolver = new NamespaceResolver();
                        
                        // Use reflection to access the protected namespaceMap field
                        Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        namespaceMapField.setAccessible(true);
                        @SuppressWarnings("unchecked")
                        Map<String, String> namespaceMap = (Map<String, String>) namespaceMapField.get(resolver);
                        namespaceMap = new HashMap<>();
                        namespaceMap.put("", "http://empty.com");
                        namespaceMapField.set(resolver, namespaceMap);
                        
                        // Use reflection to access the protected method
                        Method method = NamespaceResolver.class.getDeclaredMethod(
                            "getExternallyRegisteredNamespaceURI", String.class);
                        method.setAccessible(true);
                        
                        // Test
                        String result = (String) method.invoke(resolver, "");
                        
                        // Verify
                        assertEquals("http://empty.com", result);
                    }

    @Test
                    public void testGetExternallyRegisteredNamespaceURI_WithMultiLevelParentHierarchy() throws Exception {
                        // Setup
                        NamespaceResolver grandParent = new NamespaceResolver();
                        Map<String, String> grandParentMap = new HashMap<>();
                        grandParentMap.put("ancestor", "http://ancestor.com");
                        
                        // Use reflection to set the protected namespaceMap
                        Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                        namespaceMapField.setAccessible(true);
                        namespaceMapField.set(grandParent, grandParentMap);
                        
                        NamespaceResolver parent = new NamespaceResolver(grandParent);
                        NamespaceResolver child = new NamespaceResolver(parent);
                        
                        // Test using reflection to call protected method
                        Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                        method.setAccessible(true);
                        String result = (String) method.invoke(child, "ancestor");
                        
                        // Verify
                        assertEquals("http://ancestor.com", result);
                    }

    @Test
                public void testGetPrefix_WithParentResolver() throws Exception {
                    // Setup
                    String namespaceURI = "http://example.com";
                    String parentPrefix = "parent";
                    NamespaceResolver parent = mock(NamespaceResolver.class);
                    when(parent.getPrefix(namespaceURI)).thenReturn(parentPrefix);
                    NamespaceResolver resolver = new NamespaceResolver(parent);
                    
                    NodePointer mockPointer = mock(NodePointer.class);
                    resolver.setNamespaceContextPointer(mockPointer);
                    
                    NamespaceResolver spyResolver = spy(resolver);
                    
                    // Use reflection to access protected method
                    Method getExternallyRegisteredPrefix = NamespaceResolver.class.getDeclaredMethod(
                        "getExternallyRegisteredPrefix", String.class);
                    getExternallyRegisteredPrefix.setAccessible(true);
                    
                    // Mock the protected method behavior
                    when(getExternallyRegisteredPrefix.invoke(spyResolver, namespaceURI))
                        .thenReturn(null);
                    
                    // Test
                    String result = spyResolver.getPrefix(namespaceURI);
                    
                    // Verify
                    // Should first check local resolver, then delegate to parent if needed
                    verify(spyResolver).getPrefix(namespaceURI);
                    verify(parent).getPrefix(namespaceURI);
                }

    @Test
                public void testGetExternallyRegisteredPrefix_ReverseMapNull_BuildsReverseMap() throws Exception {
                    // Setup
                    NamespaceResolver resolver = new NamespaceResolver();
                    
                    // Use reflection to access and modify protected namespaceMap
                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                    namespaceMapField.setAccessible(true);
                    Map<String, String> namespaceMap = new HashMap<>();
                    namespaceMap.put("prefix1", "uri1");
                    namespaceMap.put("prefix2", "uri2");
                    namespaceMapField.set(resolver, namespaceMap);
                    
                    // Use reflection to call protected method
                    Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                    method.setAccessible(true);
                    String result = (String) method.invoke(resolver, "uri1");
                    
                    // Verify
                    Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                    reverseMapField.setAccessible(true);
                    Map<String, String> reverseMap = (Map<String, String>) reverseMapField.get(resolver);
                    
                    assertNotNull(reverseMap);
                    assertEquals("prefix1", result);
                    assertEquals("prefix2", reverseMap.get("uri2"));
                }

    @Test
                public void testGetExternallyRegisteredPrefix_NamespaceExistsInReverseMap() throws Exception {
                    // Setup
                    NamespaceResolver resolver = new NamespaceResolver();
                    
                    // Use reflection to access protected reverseMap field
                    Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                    reverseMapField.setAccessible(true);
                    Map<String, String> reverseMap = new HashMap<>();
                    reverseMap.put("uri1", "prefix1");
                    reverseMapField.set(resolver, reverseMap);
                    
                    // Use reflection to access protected method
                    Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                    method.setAccessible(true);
                    
                    // Test
                    String result = (String) method.invoke(resolver, "uri1");
                    
                    // Verify
                    assertEquals("prefix1", result);
                }

    @Test
                public void testGetExternallyRegisteredPrefix_NamespaceNotExistsNoParent() throws Exception {
                    // Setup
                    NamespaceResolver resolver = new NamespaceResolver();
                    
                    // Use reflection to access protected reverseMap field
                    Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                    reverseMapField.setAccessible(true);
                    Map<String, String> reverseMap = new HashMap<>();
                    reverseMap.put("uri1", "prefix1");
                    reverseMapField.set(resolver, reverseMap);
                    
                    // Use reflection to invoke protected method
                    Method method = NamespaceResolver.class.getDeclaredMethod(
                        "getExternallyRegisteredPrefix", String.class);
                    method.setAccessible(true);
                    
                    // Test
                    String result = (String) method.invoke(resolver, "nonExistingUri");
                    
                    // Verify
                    assertNull(result);
                }

    @Test
                public void testGetExternallyRegisteredPrefix_NullNamespaceURI() throws Exception {
                    // Setup
                    NamespaceResolver resolver = new NamespaceResolver();
                    
                    // Use reflection to access protected reverseMap field
                    Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                    reverseMapField.setAccessible(true);
                    Map<String, String> reverseMap = new HashMap<>();
                    reverseMap.put("uri1", "prefix1");
                    reverseMapField.set(resolver, reverseMap);
                    
                    // Use reflection to access protected method
                    Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                    method.setAccessible(true);
                    
                    // Test
                    String result = (String) method.invoke(resolver, (Object) null);
                    
                    // Verify
                    assertNull(result);
                }

    @Test
                public void testGetExternallyRegisteredPrefix_EmptyNamespaceMap() throws Exception {
                    // Setup
                    NamespaceResolver resolver = new NamespaceResolver();
                    
                    // Set empty namespaceMap using reflection
                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                    namespaceMapField.setAccessible(true);
                    namespaceMapField.set(resolver, new HashMap<>());
                    
                    // Test using reflection to call protected method
                    Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                    method.setAccessible(true);
                    String result = (String) method.invoke(resolver, "anyUri");
                    
                    // Verify
                    assertNull(result);
                    
                    // Check reverseMap using reflection
                    Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                    reverseMapField.setAccessible(true);
                    Map reverseMap = (Map) reverseMapField.get(resolver);
                    
                    assertNotNull(reverseMap);
                    assertTrue(reverseMap.isEmpty());
                }

    @Test
                public void testGetExternallyRegisteredPrefix_NamespaceMapWithNullValues() throws Exception {
                    // Setup
                    NamespaceResolver resolver = new NamespaceResolver();
                    
                    // Use reflection to access protected namespaceMap
                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                    namespaceMapField.setAccessible(true);
                    Map<String, String> namespaceMap = new HashMap<>();
                    namespaceMap.put("prefix1", null);
                    namespaceMap.put(null, "uri2");
                    namespaceMapField.set(resolver, namespaceMap);
                    
                    // Get protected method
                    Method getExternallyRegisteredPrefix = NamespaceResolver.class.getDeclaredMethod(
                        "getExternallyRegisteredPrefix", String.class);
                    getExternallyRegisteredPrefix.setAccessible(true);
                    
                    // Test
                    String result1 = (String) getExternallyRegisteredPrefix.invoke(resolver, (String) null);
                    String result2 = (String) getExternallyRegisteredPrefix.invoke(resolver, "uri2");
                    
                    // Verify
                    Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                    reverseMapField.setAccessible(true);
                    assertNotNull(reverseMapField.get(resolver));
                    assertNull(result1);
                    assertNull(result2); // Because reverseMap would contain (null, "prefix1") and ("uri2", null)
                }

    @Test
                public void testClone_WithNullFields() throws Exception {
                    NamespaceResolver original = new NamespaceResolver();
                    
                    // Use reflection to set protected fields to null
                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                    namespaceMapField.setAccessible(true);
                    namespaceMapField.set(original, null);
                    
                    Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                    reverseMapField.setAccessible(true);
                    reverseMapField.set(original, null);
                    
                    Field pointerField = NamespaceResolver.class.getDeclaredField("pointer");
                    pointerField.setAccessible(true);
                    pointerField.set(original, null);
                    
                    NamespaceResolver cloned = (NamespaceResolver) original.clone();
                    
                    // Use reflection to verify null fields in cloned object
                    assertNull(namespaceMapField.get(cloned));
                    assertNull(reverseMapField.get(cloned));
                    assertNull(pointerField.get(cloned));
                    assertFalse(cloned.isSealed());
                }

    @Test
                public void testClone_IndependentFromOriginal() throws Exception {
                    NamespaceResolver original = new NamespaceResolver();
                    original.registerNamespace("pre1", "uri1");
                    
                    NamespaceResolver cloned = (NamespaceResolver) original.clone();
                    
                    // Modify clone
                    cloned.registerNamespace("pre2", "uri2");
                    
                    // Original should not be affected
                    assertEquals("uri1", original.getNamespaceURI("pre1"));
                    assertNull(original.getNamespaceURI("pre2"));
                }

    @Test
                public void testGetPrefix_WhenExternallyRegisteredPrefixIsNullAndPointerIsNull() {
                    // Setup
                    NamespaceResolver resolver = new NamespaceResolver();
                    NamespaceResolver spyResolver = spy(resolver);
                    String namespaceURI = "http://example.com";
                    
                    // Mock protected method using reflection
                    try {
                        Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                        method.setAccessible(true);
                        when(method.invoke(spyResolver, namespaceURI)).thenReturn(null);
                    } catch (Exception e) {
                        fail("Failed to mock protected method");
                    }
                    
                    // Test
                    String result = spyResolver.getPrefix(namespaceURI);
                    
                    // Verify
                    assertNull(result);
                    verify(spyResolver, never()).getPrefix(anyString());
                }

    @Test
            public void testGetPrefix_WhenNamespaceURIisNull() {
                // Setup
                NamespaceResolver resolver = new NamespaceResolver();
                NamespaceResolver spyResolver = spy(resolver);
                
                // Test
                String result = spyResolver.getPrefix(null);
                
                // Verify
                assertNull(result);
            }

    @Test
            public void testGetPrefix_WhenExternallyRegisteredPrefixExists() throws Exception {
                // Setup
                String namespaceURI = "http://example.com";
                String expectedPrefix = "ex";
                NamespaceResolver resolver = new NamespaceResolver();
                
                // Use reflection to set the protected field
                Field field = NamespaceResolver.class.getDeclaredField("externallyRegisteredPrefixes");
                field.setAccessible(true);
                @SuppressWarnings("unchecked")
                Map<String, String> prefixes = (Map<String, String>) field.get(resolver);
                prefixes.put(namespaceURI, expectedPrefix);
                
                // Test using public method
                String result = resolver.getPrefix(namespaceURI);
                
                // Verify
                assertEquals(expectedPrefix, result);
            }

    @Test
            public void testGetPrefix_WhenExternallyRegisteredPrefixIsNullAndPointerExists() throws Exception {
                // Setup
                NamespaceResolver resolver = new NamespaceResolver();
                NodePointer mockPointer = mock(NodePointer.class);
                String namespaceURI = "http://example.com";
                String expectedPrefix = "ptr";
                
                resolver.setNamespaceContextPointer(mockPointer);
                
                // Create a spy
                NamespaceResolver spyResolver = spy(resolver);
                
                // Mock the pointer behavior
                when(mockPointer.getNamespaceURI()).thenReturn(namespaceURI);
                
                // Mock the static getPrefix method behavior
                Method getPrefixMethod = NamespaceResolver.class.getDeclaredMethod(
                    "getPrefix", NodePointer.class, String.class);
                getPrefixMethod.setAccessible(true);
                when(getPrefixMethod.invoke(null, mockPointer, namespaceURI)).thenReturn(expectedPrefix);
                
                // Set up protected method to return null
                Method getExternallyRegisteredPrefix = NamespaceResolver.class.getDeclaredMethod(
                    "getExternallyRegisteredPrefix", String.class);
                getExternallyRegisteredPrefix.setAccessible(true);
                when(getExternallyRegisteredPrefix.invoke(spyResolver, namespaceURI)).thenReturn(null);
                
                // Test
                String result = spyResolver.getPrefix(namespaceURI);
                
                // Verify
                assertEquals(expectedPrefix, result);
                verify(mockPointer).getNamespaceURI();
                verify(getExternallyRegisteredPrefix).invoke(spyResolver, namespaceURI);
            }

    @Test
        public void testClone_CopiesFieldValues() throws Exception {
            // Setup original with some values
            NamespaceResolver parent = mock(NamespaceResolver.class);
            HashMap<String, String> namespaceMap = new HashMap<>();
            namespaceMap.put("prefix", "uri");
            HashMap<String, String> reverseMap = new HashMap<>();
            reverseMap.put("uri", "prefix");
            NodePointer pointer = mock(NodePointer.class);
            
            NamespaceResolver original = new NamespaceResolver(parent);
            // Use reflection to set protected fields
            Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
            namespaceMapField.setAccessible(true);
            namespaceMapField.set(original, namespaceMap);
            
            Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
            reverseMapField.setAccessible(true);
            reverseMapField.set(original, reverseMap);
            
            Field pointerField = NamespaceResolver.class.getDeclaredField("pointer");
            pointerField.setAccessible(true);
            pointerField.set(original, pointer);
            
            original.seal(); // seal the original
            
            // Clone it
            NamespaceResolver cloned = (NamespaceResolver) original.clone();
            
            // Verify fields are copied using reflection
            Field parentField = NamespaceResolver.class.getDeclaredField("parent");
            parentField.setAccessible(true);
            assertSame(parent, parentField.get(cloned));
            
            namespaceMapField.setAccessible(true);
            assertSame(namespaceMap, namespaceMapField.get(cloned));
            
            reverseMapField.setAccessible(true);
            assertSame(reverseMap, reverseMapField.get(cloned));
            
            pointerField.setAccessible(true);
            assertSame(pointer, pointerField.get(cloned));
            
            assertFalse(cloned.isSealed()); // sealed should be false in clone
            assertTrue(original.isSealed()); // original should remain sealed
        }

    @Test
    public void testGetPrefix_WhenSealed() {
        // Setup
        NamespaceResolver resolver = new NamespaceResolver();
        String namespaceURI = "http://example.com";
        resolver.seal();
        NamespaceResolver spyResolver = spy(resolver);
        
        // Test
        String result = spyResolver.getPrefix(namespaceURI);
        
        // Verify
        // Use reflection to verify protected method call
        try {
            Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
            method.setAccessible(true);
            // Invoke the method to ensure it's called
            String prefixResult = (String) method.invoke(spyResolver, namespaceURI);
            // Verify the result matches what we got from getPrefix()
            assertEquals(result, prefixResult);
        } catch (Exception e) {
            fail("Failed to verify getExternallyRegisteredPrefix call: " + e.getMessage());
        }
    }

    @Test
    public void testGetExternallyRegisteredPrefix_DelegatesToParentWhenNotFound() throws Exception {
        // Setup
        NamespaceResolver parent = mock(NamespaceResolver.class);
        
        // Use reflection to set up expectation on protected method
        Method parentMethod = NamespaceResolver.class.getDeclaredMethod(
            "getExternallyRegisteredPrefix", String.class);
        parentMethod.setAccessible(true);
        when(parentMethod.invoke(parent, "parentUri")).thenReturn("parentPrefix");
        
        NamespaceResolver resolver = new NamespaceResolver(parent);
        
        // Use reflection to access protected reverseMap field
        Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
        reverseMapField.setAccessible(true);
        Map<String, String> reverseMap = new HashMap<>();
        reverseMap.put("uri1", "prefix1");
        reverseMapField.set(resolver, reverseMap);
        
        // Use reflection to call protected method
        Method method = NamespaceResolver.class.getDeclaredMethod(
            "getExternallyRegisteredPrefix", String.class);
        method.setAccessible(true);
        
        // Test
        String result = (String) method.invoke(resolver, "parentUri");
        
        // Verify
        assertEquals("parentPrefix", result);
        verify(parentMethod.invoke(parent, "parentUri"));
    }


}
