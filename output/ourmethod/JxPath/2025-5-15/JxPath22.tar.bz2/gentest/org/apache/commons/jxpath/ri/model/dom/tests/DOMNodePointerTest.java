package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                               public void testGetNamespaceURI_WithElementNodeAndNamespace() {
                                                                                                   Element mockElement = mock(Element.class);
                                                                                                   when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                   when(mockElement.getNamespaceURI()).thenReturn("http://example.com/ns");
                                                                                                   
                                                                                                   DOMNodePointer elementPointer = new DOMNodePointer(mockElement, null);
                                                                                                   assertEquals("http://example.com/ns", elementPointer.getNamespaceURI());
                                                                                               }

 @Test
                                                                                               public void testGetNamespaceURI_WithElementNodeNoNamespace() {
                                                                                                   Element mockElement = mock(Element.class);
                                                                                                   when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                   when(mockElement.getNamespaceURI()).thenReturn(null);
                                                                                                   
                                                                                                   DOMNodePointer elementPointer = new DOMNodePointer(mockElement, null);
                                                                                                   assertNull(elementPointer.getNamespaceURI());
                                                                                               }

 @Test
                                                                                               public void testGetNamespaceURI_WithDefaultXMLNamespace() {
                                                                                                   Element mockElement = mock(Element.class);
                                                                                                   when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                   when(mockElement.getNamespaceURI()).thenReturn(DOMNodePointer.XML_NAMESPACE_URI);
                                                                                                   
                                                                                                   DOMNodePointer elementPointer = new DOMNodePointer(mockElement, null);
                                                                                                   assertEquals(DOMNodePointer.XML_NAMESPACE_URI, elementPointer.getNamespaceURI());
                                                                                               }

 @Test
                                                                                               public void testGetNamespaceURI_WithXMLNSNamespace() {
                                                                                                   Element mockElement = mock(Element.class);
                                                                                                   when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                   when(mockElement.getNamespaceURI()).thenReturn(DOMNodePointer.XMLNS_NAMESPACE_URI);
                                                                                                   
                                                                                                   DOMNodePointer elementPointer = new DOMNodePointer(mockElement, null);
                                                                                                   assertEquals(DOMNodePointer.XMLNS_NAMESPACE_URI, elementPointer.getNamespaceURI());
                                                                                               }

 @Test
                                                                                               public void testGetNamespaceURI_WithMockedStaticHelper() {
                                                                                                   // This test verifies the delegation to the static helper
                                                                                                   Node testNode = mock(Node.class);
                                                                                                   when(testNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                   when(testNode.getNamespaceURI()).thenReturn("test-namespace");
                                                                                                   
                                                                                                   DOMNodePointer testPointer = new DOMNodePointer(testNode, null);
                                                                                                   assertEquals("test-namespace", testPointer.getNamespaceURI());
                                                                                               }

 @Test
                                                                                               public void testGetValue_CommentNodeWithText() {
                                                                                                   // Setup
                                                                                                   Node mockNode = mock(Node.class);
                                                                                                   when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                   
                                                                                                   Comment mockComment = mock(Comment.class);
                                                                                                   when(mockComment.getData()).thenReturn("  test comment  ");
                                                                                                   when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                   
                                                                                                   DOMNodePointer pointer = new DOMNodePointer(mockComment, null);
                                                                                                   
                                                                                                   // Test & Verify
                                                                                                   assertEquals("test comment", pointer.getValue());
                                                                                               }

 @Test
                                                                                               public void testGetValue_CommentNodeWithNullText() {
                                                                                                   // Setup
                                                                                                   Comment mockComment = mock(Comment.class);
                                                                                                   when(mockComment.getData()).thenReturn(null);
                                                                                                   when(mockComment.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                   
                                                                                                   DOMNodePointer pointer = new DOMNodePointer(mockComment, null);
                                                                                                   
                                                                                                   // Test & Verify
                                                                                                   assertEquals("", pointer.getValue());
                                                                                               }

 @Test
                                                                                               public void testGetValue_CommentNodeWithEmptyText() {
                                                                                                   // Setup
                                                                                                   Comment mockComment = mock(Comment.class);
                                                                                                   when(mockComment.getData()).thenReturn("");
                                                                                                   when(mockComment.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                   
                                                                                                   DOMNodePointer pointer = new DOMNodePointer(mockComment, null);
                                                                                                   
                                                                                                   // Test & Verify
                                                                                                   assertEquals("", pointer.getValue());
                                                                                               }

 @Test
                                                                                               public void testGetValue_CommentNodeWithWhitespaceText() {
                                                                                                   // Setup
                                                                                                   Comment mockComment = mock(Comment.class);
                                                                                                   when(mockComment.getData()).thenReturn("   \t\n  ");
                                                                                                   when(mockComment.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                   
                                                                                                   DOMNodePointer pointer = new DOMNodePointer(mockComment, null);
                                                                                                   
                                                                                                   // Test & Verify
                                                                                                   assertEquals("", pointer.getValue());
                                                                                               }

 @Test
                                                                                       public void testGetNamespaceURI_WithNonElementNode() {
                                                                                           Node mockNode = mock(Node.class);
                                                                                           when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                           assertNull(pointer.getNamespaceURI());
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_WithNullNode() {
                                                                                           DOMNodePointer nullPointer = new DOMNodePointer((Node)null, null);
                                                                                           assertNull(nullPointer.getNamespaceURI());
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_FindInAttributes() {
                                                                                           // Setup document structure
                                                                                           Node mockNode = mock(Node.class);
                                                                                           Document mockDocument = mock(Document.class);
                                                                                           Element mockElement = mock(Element.class);
                                                                                           Attr mockAttr = mock(Attr.class);
                                                                                           
                                                                                           when(mockNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                           when(mockDocument.getDocumentElement()).thenReturn(mockElement);
                                                                                           when(mockElement.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
                                                                                           when(mockAttr.getValue()).thenReturn("http://found.com");
                                                                                           
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockDocument, null);
                                                                                           
                                                                                           assertEquals("http://found.com", pointer.getNamespaceURI("test"));
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_FindInParentAttributes() {
                                                                                           // Setup parent-child structure
                                                                                           Node mockNode = mock(Node.class);
                                                                                           Node mockParent = mock(Node.class);
                                                                                           Attr mockAttr = mock(Attr.class);
                                                                                           
                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                           when(mockNode.getParentNode()).thenReturn(mockParent);
                                                                                           when(mockParent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                           when(((Element)mockParent).getAttributeNode("xmlns:test")).thenReturn(mockAttr);
                                                                                           when(mockAttr.getValue()).thenReturn("http://parent.com");
                                                                                           
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                           assertEquals("http://parent.com", pointer.getNamespaceURI("test"));
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_UnknownNamespace() throws Exception {
                                                                                           // Setup mock node
                                                                                           Element mockNode = mock(Element.class);
                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                           when(mockNode.getParentNode()).thenReturn(null);
                                                                                           
                                                                                           // Create pointer with mock node
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                           
                                                                                           // Access private namespaces field
                                                                                           Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                                                                           namespacesField.setAccessible(true);
                                                                                           
                                                                                           // Test with unknown namespace
                                                                                           assertNull(pointer.getNamespaceURI("unknown"));
                                                                                           
                                                                                           // Verify it was cached as UNKNOWN_NAMESPACE
                                                                                           Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
                                                                                           assertEquals(DOMNodePointer.UNKNOWN_NAMESPACE, namespaces.get("unknown"));
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_EmptyNamespace() {
                                                                                           // Setup mocks
                                                                                           Node mockNode = mock(Node.class);
                                                                                           Attr mockAttr = mock(Attr.class);
                                                                                           
                                                                                           // Setup empty namespace in attribute
                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                           when(((Element)mockNode).getAttributeNode("xmlns:empty")).thenReturn(mockAttr);
                                                                                           when(mockAttr.getValue()).thenReturn("");
                                                                                           
                                                                                           // Create pointer with mock node
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                           
                                                                                           assertNull(pointer.getNamespaceURI("empty"));
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_DocumentNodeWithElement() {
                                                                                           // Import required classes
                                                                                           org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                           org.w3c.dom.Document mockDocument = mock(org.w3c.dom.Document.class);
                                                                                           org.w3c.dom.Element mockElement = mock(org.w3c.dom.Element.class);
                                                                                           org.w3c.dom.Attr mockAttr = mock(org.w3c.dom.Attr.class);
                                                                                           
                                                                                           // Setup document with element
                                                                                           when(mockNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                           when(mockDocument.getDocumentElement()).thenReturn(mockElement);
                                                                                           when(mockElement.getAttributeNode("xmlns:doc")).thenReturn(mockAttr);
                                                                                           when(mockAttr.getValue()).thenReturn("http://document.com");
                                                                                           
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockDocument, null);
                                                                                           
                                                                                           assertEquals("http://document.com", pointer.getNamespaceURI("doc"));
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_RelativeURI() {
                                                                                           // Setup mocks
                                                                                           Node mockNode = mock(Node.class);
                                                                                           Attr mockAttr = mock(Attr.class);
                                                                                           
                                                                                           // Create pointer with mock node
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                           
                                                                                           // Setup relative URI (TBD case mentioned in comments)
                                                                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                           when(((Element)mockNode).getAttributeNode("xmlns:relative")).thenReturn(mockAttr);
                                                                                           when(mockAttr.getValue()).thenReturn("relative/path");
                                                                                           
                                                                                           assertEquals("relative/path", pointer.getNamespaceURI("relative"));
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_WithDocumentNode() {
                                                                                           // Create mock objects
                                                                                           Document mockDocument = mock(Document.class);
                                                                                           Element mockElement = mock(Element.class);
                                                                                           
                                                                                           // Set up mock behavior
                                                                                           when(mockDocument.getDocumentElement()).thenReturn(mockElement);
                                                                                           when(mockElement.getNamespaceURI()).thenReturn("http://example.com");
                                                                                           
                                                                                           // Create pointer and test
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockDocument, null);
                                                                                           String result = pointer.getNamespaceURI();
                                                                                           
                                                                                           // Verify
                                                                                           assertEquals("http://example.com", result);
                                                                                           verify(mockDocument).getDocumentElement();
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_WithElementHavingNamespace() {
                                                                                           Element mockElement = mock(Element.class);
                                                                                           when(mockElement.getNamespaceURI()).thenReturn("http://example.com");
                                                                                           
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockElement, null);
                                                                                           String result = pointer.getNamespaceURI();
                                                                                           
                                                                                           assertEquals("http://example.com", result);
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_WithNullNamespaceAndNoPrefix() {
                                                                                           // Create mock Element
                                                                                           Element mockElement = mock(Element.class);
                                                                                           when(mockElement.getNamespaceURI()).thenReturn(null);
                                                                                           when(mockElement.getParentNode()).thenReturn(null);
                                                                                           when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                           
                                                                                           // Create spy pointer
                                                                                           DOMNodePointer spyPointer = spy(new DOMNodePointer(mockElement, null));
                                                                                           doReturn(null).when(spyPointer).getPrefix(mockElement);
                                                                                           
                                                                                           String result = spyPointer.getNamespaceURI();
                                                                                           
                                                                                           assertNull(result);
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_WithNullNamespaceAndPrefix() {
                                                                                           // Create mock objects
                                                                                           Element mockElement = mock(Element.class);
                                                                                           Element mockParentElement = mock(Element.class);
                                                                                           Attr mockAttr = mock(Attr.class);
                                                                                           
                                                                                           // Setup mock behavior
                                                                                           when(mockElement.getNamespaceURI()).thenReturn(null);
                                                                                           when(mockElement.getParentNode()).thenReturn(mockParentElement);
                                                                                           when(mockParentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                           when(mockParentElement.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
                                                                                           when(mockAttr.getValue()).thenReturn("http://test.com");
                                                                                           
                                                                                           // Mock getPrefix() behavior
                                                                                           DOMNodePointer spyPointer = spy(new DOMNodePointer(mockElement, null));
                                                                                           doReturn("test").when(spyPointer).getPrefix(mockElement);
                                                                                           
                                                                                           String result = spyPointer.getNamespaceURI();
                                                                                           
                                                                                           assertEquals("http://test.com", result);
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_WithEmptyStringNamespace() {
                                                                                           // Create mock Element
                                                                                           Element mockElement = mock(Element.class);
                                                                                           when(mockElement.getNamespaceURI()).thenReturn("");
                                                                                           
                                                                                           // Create DOMNodePointer with mock element
                                                                                           DOMNodePointer pointer = new DOMNodePointer(mockElement, null);
                                                                                           String result = pointer.getNamespaceURI();
                                                                                           
                                                                                           // Verify empty string namespace URI is converted to null
                                                                                           assertNull(result);
                                                                                       }

 @Test
                                                                                       public void testGetNamespaceURI_WithNoNamespaceFound() {
                                                                                           // Create mock elements
                                                                                           Element mockElement = mock(Element.class);
                                                                                           Element mockParentElement = mock(Element.class);
                                                                                           
                                                                                           // Set up mock behavior
                                                                                           when(mockElement.getNamespaceURI()).thenReturn(null);
                                                                                           when(mockElement.getParentNode()).thenReturn(mockParentElement);
                                                                                           when(mockParentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                           when(mockParentElement.getAttributeNode("xmlns:test")).thenReturn(null);
                                                                                           
                                                                                           // Mock getPrefix() behavior
                                                                                           DOMNodePointer spyPointer = spy(new DOMNodePointer(mockElement, null));
                                                                                           doReturn("test").when(spyPointer).getPrefix(mockElement);
                                                                                           
                                                                                           String result = spyPointer.getNamespaceURI();
                                                                                           
                                                                                           assertNull(result);
                                                                                       }

 @Test
                                                                                   public void testGetValue_NonCommentNode() {
                                                                                       // Setup
                                                                                       Node mockNode = mock(Node.class);
                                                                                       when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                       
                                                                                       DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                       
                                                                                       // Since stringValue is private, we can't mock it directly
                                                                                       // Instead, we'll let the actual method execute and verify the behavior
                                                                                       // The actual stringValue implementation will be called
                                                                                       
                                                                                       // Test & Verify
                                                                                       // The actual value will depend on the node's content
                                                                                       // Since we're mocking the node, we need to set up its expected behavior
                                                                                       when(mockNode.getNodeValue()).thenReturn("element value");
                                                                                       assertEquals("element value", pointer.getValue());
                                                                                   }

 @Test
                                                                                   public void testGetValue_NullNode() {
                                                                                       // Setup
                                                                                       DOMNodePointer pointer = new DOMNodePointer((Node)null, null);
                                                                                       
                                                                                       // Test & Verify
                                                                                       // The actual behavior of stringValue(null) should be tested
                                                                                       // rather than trying to mock the private method
                                                                                       assertEquals("", pointer.getValue());
                                                                                   }

 @Test
                                                                                   public void testGetValue_TextNode() {
                                                                                       // Setup
                                                                                       Node mockNode = mock(Node.class);
                                                                                       when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                       when(mockNode.getNodeValue()).thenReturn("text content");
                                                                                       
                                                                                       DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                       
                                                                                       // Test & Verify
                                                                                       assertEquals("text content", pointer.getValue());
                                                                                   }

 @Test
                                                                                   public void testGetNamespaceURI_NullOrEmptyPrefix() throws Exception {
                                                                                       // Create a mock node
                                                                                       javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                       javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                       org.w3c.dom.Document document = builder.newDocument();
                                                                                       org.w3c.dom.Element element = document.createElement("test");
                                                                                       document.appendChild(element);
                                                                                       
                                                                                       // Create pointer instance
                                                                                       org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                           new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(document, java.util.Locale.getDefault());
                                                                                       
                                                                                       // Set default namespace using reflection
                                                                                       java.lang.reflect.Field defaultNamespaceField = 
                                                                                           org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredField("defaultNamespace");
                                                                                       defaultNamespaceField.setAccessible(true);
                                                                                       defaultNamespaceField.set(pointer, "http://default.com");
                                                                                       
                                                                                       // Test null prefix
                                                                                       assertEquals("http://default.com", pointer.getNamespaceURI((String)null));
                                                                                       
                                                                                       // Test empty prefix
                                                                                       assertEquals("http://default.com", pointer.getNamespaceURI(""));
                                                                                   }

 @Test
                                                                                   public void testGetNamespaceURI_XmlPrefix() throws Exception {
                                                                                       javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                       javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                       org.w3c.dom.Document document = builder.newDocument();
                                                                                       org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                           new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(document, java.util.Locale.getDefault());
                                                                                       assertEquals("http://www.w3.org/XML/1998/namespace", 
                                                                                           pointer.getNamespaceURI("xml"));
                                                                                   }

 @Test
                                                                                   public void testGetNamespaceURI_XmlnsPrefix() throws Exception {
                                                                                       javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                       javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                       org.w3c.dom.Document document = builder.newDocument();
                                                                                       org.w3c.dom.Element element = document.createElement("test");
                                                                                       org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                           new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(element, java.util.Locale.getDefault());
                                                                                       assertEquals("http://www.w3.org/2000/xmlns/", 
                                                                                           pointer.getNamespaceURI("xmlns"));
                                                                                   }

 @Test
                                                                                   public void testGetNamespaceURI_WithNamespaceInGrandparent() {
                                                                                       // Create all required mock objects
                                                                                       Node mockElement = mock(Node.class);
                                                                                       Node mockParentElement = mock(Node.class);
                                                                                       Element mockGrandparent = mock(Element.class);
                                                                                       Attr mockAttr = mock(Attr.class);
                                                                                       
                                                                                       // Set up mock behavior
                                                                                       when(mockElement.getNamespaceURI()).thenReturn(null);
                                                                                       when(mockElement.getParentNode()).thenReturn(mockParentElement);
                                                                                       when(mockParentElement.getParentNode()).thenReturn(mockGrandparent);
                                                                                       when(mockParentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                       when(mockGrandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                       when(mockGrandparent.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
                                                                                       when(mockAttr.getValue()).thenReturn("http://grandparent.com");
                                                                                       
                                                                                       // Mock getPrefix() behavior
                                                                                       DOMNodePointer spyPointer = spy(new DOMNodePointer(mockElement, null));
                                                                                       doReturn("test").when(spyPointer).getPrefix(mockElement);
                                                                                       
                                                                                       String result = spyPointer.getNamespaceURI();
                                                                                       
                                                                                       assertEquals("http://grandparent.com", result);
                                                                                   }

 @Test
                                                                                   public void testGetNamespaceURI_WithNonElementParentNodes() {
                                                                                       // Create all mock objects
                                                                                       Node mockElement = mock(Node.class);
                                                                                       Node mockTextNode = mock(Node.class);
                                                                                       Element mockParentElement = mock(Element.class);  // Changed to Element
                                                                                       Attr mockAttr = mock(Attr.class);
                                                                                       
                                                                                       // Set up mock behaviors
                                                                                       when(mockElement.getNamespaceURI()).thenReturn(null);
                                                                                       when(mockElement.getParentNode()).thenReturn(mockTextNode);
                                                                                       when(mockTextNode.getParentNode()).thenReturn(mockParentElement);
                                                                                       when(mockTextNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                       when(mockParentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                       when(mockParentElement.getAttributeNode("xmlns:test")).thenReturn(mockAttr);
                                                                                       when(mockAttr.getValue()).thenReturn("http://parent.com");
                                                                                       
                                                                                       // Mock getPrefix() behavior
                                                                                       DOMNodePointer spyPointer = spy(new DOMNodePointer(mockElement, null));
                                                                                       doReturn("test").when(spyPointer).getPrefix(mockElement);
                                                                                       
                                                                                       String result = spyPointer.getNamespaceURI();
                                                                                       
                                                                                       assertEquals("http://parent.com", result);
                                                                                   }

 @Test
                                                                           public void testGetNamespaceURI_CachedNamespace() throws Exception {
                                                                               // Create test node and pointer
                                                                               javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                               javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                               org.w3c.dom.Document document = builder.newDocument();
                                                                               org.w3c.dom.Element element = document.createElement("testElement");
                                                                               DOMNodePointer pointer = new DOMNodePointer(element, Locale.getDefault());
                                                                               
                                                                               // Setup cached namespace using reflection
                                                                               Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                                                               namespacesField.setAccessible(true);
                                                                               Map<String, String> namespaces = new HashMap<>();
                                                                               namespaces.put("test", "http://cached.com");
                                                                               namespacesField.set(pointer, namespaces);
                                                                               
                                                                               assertEquals("http://cached.com", pointer.getNamespaceURI("test"));
                                                                           }

 @Test
                                                                           public void testGetNamespaceURI_ElementNode() throws Exception {
                                                                               // Setup element node mock
                                                                               Node elementNode = mock(Node.class);
                                                                               when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                               when(elementNode.getNamespaceURI()).thenReturn("http://test.com/ns");
                                                                               
                                                                               DOMNodePointer pointer = new DOMNodePointer(elementNode, null);
                                                                               
                                                                               // Should return namespace URI for element node
                                                                               assertEquals("http://test.com/ns", pointer.getNamespaceURI());
                                                                           }

 @Test
                                                                           public void testGetNamespaceURI_NonElementNode() throws Exception {
                                                                               // Setup non-element node (e.g. ATTRIBUTE_NODE)
                                                                               Node attrNode = mock(Node.class);
                                                                               when(attrNode.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
                                                                               // Even if it has namespace URI, shouldn't return it for non-element
                                                                               when(attrNode.getNamespaceURI()).thenReturn("http://test.com/ns");
                                                                               
                                                                               DOMNodePointer pointer = new DOMNodePointer(attrNode, null);
                                                                               
                                                                               // Should return null for non-element nodes
                                                                               assertNull(pointer.getNamespaceURI());
                                                                           }

 @Test
                                                                       public void testGetNamespaceURI_ShouldFindNamespaceOnElementNode() throws Exception {
                                                                           // Setup test data - create element hierarchy with namespace declaration
                                                                           String testPrefix = "test";
                                                                           String expectedNamespace = "http://test.com/ns";
                                                                           
                                                                           // Create mock nodes
                                                                           Element grandparent = mock(Element.class);
                                                                           Element parent = mock(Element.class);
                                                                           Element child = mock(Element.class);
                                                                           
                                                                           // Setup node type behavior
                                                                           when(grandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                           when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                           when(child.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                           
                                                                           // Setup parent-child relationships
                                                                           when(child.getParentNode()).thenReturn(parent);
                                                                           when(parent.getParentNode()).thenReturn(grandparent);
                                                                           
                                                                           // Create namespace attribute
                                                                           Attr namespaceAttr = mock(Attr.class);
                                                                           when(namespaceAttr.getValue()).thenReturn(expectedNamespace);
                                                                           
                                                                           // Only the parent element has the namespace declaration
                                                                           when(parent.getAttributeNode("xmlns:" + testPrefix)).thenReturn(namespaceAttr);
                                                                           
                                                                           // Create DOMNodePointer with child node
                                                                           DOMNodePointer pointer = new DOMNodePointer(child, Locale.ROOT);
                                                                           
                                                                           // Test - should find namespace on parent element
                                                                           String result = pointer.getNamespaceURI(testPrefix);
                                                                           
                                                                           // Verify
                                                                           assertEquals("Should find namespace declared on element node", 
                                                                                       expectedNamespace, result);
                                                                           
                                                                           // Additional verification that we checked the right nodes
                                                                           verify(parent).getAttributeNode("xmlns:" + testPrefix);
                                                                           verify(grandparent, never()).getAttributeNode(anyString());
                                                                       }

 @Test
                                                                      public void testGetNamespaceURI_ShouldFindNamespaceFromElementAncestor() throws Exception {
                                                                          // Create a document with namespace declaration on a parent element
                                                                          javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                          javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                          org.w3c.dom.Document doc = builder.newDocument();
                                                                          
                                                                          org.w3c.dom.Element grandparent = doc.createElement("grandparent");
                                                                          grandparent.setAttribute("xmlns:test", "http://test-namespace");
                                                                          org.w3c.dom.Element parent = doc.createElement("parent");
                                                                          grandparent.appendChild(parent);
                                                                          org.w3c.dom.Element child = doc.createElement("child");
                                                                          parent.appendChild(child);
                                                                          doc.appendChild(grandparent);
                                                                      
                                                                          // Create node pointer for the child element (which should inherit namespace)
                                                                          DOMNodePointer pointer = new DOMNodePointer(child, java.util.Locale.getDefault());
                                                                      
                                                                          // The method should find the namespace from grandparent element
                                                                          String result = pointer.getNamespaceURI();
                                                                      
                                                                          // Verify it found the namespace (mutant would skip element nodes and return null)
                                                                          assertEquals("http://test-namespace", result);
                                                                          
                                                                          // Additional verification that we're testing the right path
                                                                          assertNotNull("Should have found namespace from element ancestor", result);
                                                                      }

 @Test
                                                                      public void testGetNamespaceURI_NonElementNode_ShouldReturnNull() {
                                                                          // Create a mock Node that's not an ELEMENT_NODE
                                                                          Node mockNode = mock(Node.class);
                                                                          when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE); // Not ELEMENT_NODE
                                                                          
                                                                          // Create the DOMNodePointer with our mock node
                                                                          DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                          
                                                                          // The original should return null for non-element nodes
                                                                          // The mutant would try to process it and might return something else
                                                                          assertNull(pointer.getNamespaceURI());
                                                                          
                                                                          // Verify the node type was checked (would fail for mutant)
                                                                          verify(mockNode).getNodeType();
                                                                      }

 @Test
                                                                      public void testGetNamespaceURI_ElementNode_ShouldReturnURI() {
                                                                          // Create a mock ELEMENT_NODE with a namespace URI
                                                                          Node mockNode = mock(Node.class);
                                                                          when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                          when(mockNode.getNamespaceURI()).thenReturn("http://example.com/ns");
                                                                          
                                                                          DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                          
                                                                          // Both original and mutant should return the namespace for element nodes
                                                                          assertEquals("http://example.com/ns", pointer.getNamespaceURI());
                                                                      }

 @Test
                                                                  public void testGetNamespaceURI_NonElementParentNode() throws Exception {
                                                                      // Create a document structure with a text node parent that has xmlns attribute
                                                                      Document doc = mock(Document.class);
                                                                      Element docElement = mock(Element.class);
                                                                      when(doc.getDocumentElement()).thenReturn(docElement);
                                                                      
                                                                      // Mock the element we're testing
                                                                      Element testElement = mock(Element.class);
                                                                      when(testElement.getNamespaceURI()).thenReturn(null);
                                                                      when(testElement.getParentNode()).thenReturn(doc); // Parent is Document
                                                                      
                                                                      // Create a text node between document and our element
                                                                      Node textNode = mock(Node.class);
                                                                      when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                      when(testElement.getParentNode()).thenReturn(textNode);
                                                                      when(textNode.getParentNode()).thenReturn(doc);
                                                                      
                                                                      // Set up the xmlns attribute on the document element
                                                                      Attr xmlnsAttr = mock(Attr.class);
                                                                      when(xmlnsAttr.getValue()).thenReturn("http://test.com");
                                                                      when(docElement.getAttributeNode("xmlns")).thenReturn(xmlnsAttr);
                                                                      
                                                                      // The original code should skip the text node and find the xmlns on document element
                                                                      // The mutant would try to process the text node (which would throw ClassCastException)
                                                                      DOMNodePointer pointer = new DOMNodePointer(testElement, Locale.ENGLISH);
                                                                      String result = pointer.getNamespaceURI(testElement);
                                                                      
                                                                      assertEquals("http://test.com", result);
                                                                  }

 @Test
                                                                 public void testGetNamespaceURI_ShouldOnlyProcessElementNodes() throws Exception {
                                                                     // Setup test document with element and non-element nodes
                                                                     Element element = mock(Element.class);
                                                                     Node textNode = mock(Node.class);
                                                                     Node commentNode = mock(Node.class);
                                                                     
                                                                     // Configure element node
                                                                     when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                     when(element.getParentNode()).thenReturn(null);
                                                                     
                                                                     // Configure text node (non-element) with a parent
                                                                     when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                     when(textNode.getParentNode()).thenReturn(element);
                                                                     
                                                                     // Configure comment node (non-element) with a parent
                                                                     when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                     when(commentNode.getParentNode()).thenReturn(element);
                                                                     
                                                                     // Create DOMNodePointer starting from non-element node
                                                                     DOMNodePointer pointer = new DOMNodePointer(textNode, Locale.ENGLISH);
                                                                     
                                                                     // Test with a prefix that would require searching up the node hierarchy
                                                                     String result = pointer.getNamespaceURI("test");
                                                                     
                                                                     // Verify that non-element nodes were not processed for namespace lookup
                                                                     // The original code would return UNKNOWN_NAMESPACE (null) since it only checks element nodes
                                                                     // The mutated code would incorrectly process text/comment nodes if they had attributes
                                                                     assertNull("Should return null for unknown namespace", result);
                                                                 }

 @Test
                                                                 public void testGetNamespaceURI_ElementNode_ShouldReturnNamespaceURI() throws Exception {
                                                                     // Setup test data
                                                                     String expectedNamespace = "http://example.com/ns";
                                                                     Element mockElement = mock(Element.class);
                                                                     when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                     when(mockElement.getNamespaceURI()).thenReturn(expectedNamespace);
                                                                     
                                                                     // Create test instance
                                                                     DOMNodePointer pointer = new DOMNodePointer(mockElement, null);
                                                                     
                                                                     // Execute and verify
                                                                     String actualNamespace = pointer.getNamespaceURI();
                                                                     assertEquals("Should return namespace URI for element node", 
                                                                                  expectedNamespace, actualNamespace);
                                                                     
                                                                     // Verify interactions
                                                                     verify(mockElement).getNodeType();
                                                                     verify(mockElement).getNamespaceURI();
                                                                 }

 @Test
                                                             public void testGetNamespaceURI_ShouldFindNamespaceInElementNode() {
                                                                 // Setup test data
                                                                 String prefix = "test";
                                                                 String expectedNamespace = "http://test.com/ns";
                                                                 String qname = "xmlns:" + prefix;
                                                                 
                                                                 // Mock node hierarchy with namespace attribute
                                                                 Node mockNode = mock(Node.class);
                                                                 Node mockParent = mock(Node.class);
                                                                 Element mockElement = mock(Element.class);
                                                                 Attr mockAttr = mock(Attr.class);
                                                                 
                                                                 when(mockNode.getParentNode()).thenReturn(mockParent);
                                                                 when(mockParent.getParentNode()).thenReturn(null);
                                                                 when(mockNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                 when(mockParent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                 
                                                                 when(mockElement.getAttributeNode(qname)).thenReturn(mockAttr);
                                                                 when(mockAttr.getValue()).thenReturn(expectedNamespace);
                                                                 
                                                                 // Mock document structure
                                                                 Document mockDoc = mock(Document.class);
                                                                 when(mockDoc.getDocumentElement()).thenReturn(mockElement);
                                                                 
                                                                 // Create test instance
                                                                 DOMNodePointer pointer = new DOMNodePointer(mockDoc, Locale.ENGLISH);
                                                                 
                                                                 // Execute test
                                                                 String result = pointer.getNamespaceURI(prefix);
                                                                 
                                                                 // Verify
                                                                 assertEquals("Should find namespace in element node", 
                                                                             expectedNamespace, result);
                                                                 
                                                                 // Verify the node type check was performed (would fail with mutant)
                                                                 verify(mockParent).getNodeType();
                                                             }

 @Test
                                                                 public void testGetNamespaceURI_ShouldFindAncestorNamespace() throws Exception {
                                                                     // Create a mock element without namespace URI
                                                                     Element childElement = mock(Element.class);
                                                                     when(childElement.getNamespaceURI()).thenReturn(null);
                                                                     when(childElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                     
                                                                     // Create a mock parent element with namespace declaration
                                                                     Element parentElement = mock(Element.class);
                                                                     when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                     when(childElement.getParentNode()).thenReturn(parentElement);
                                                                     
                                                                     // Mock the namespace attribute
                                                                     Attr namespaceAttr = mock(Attr.class);
                                                                     when(namespaceAttr.getValue()).thenReturn("http://example.com");
                                                                     when(parentElement.getAttributeNode("xmlns")).thenReturn(namespaceAttr);
                                                                     
                                                                     // Create DOMNodePointer instance
                                                                     DOMNodePointer pointer = new DOMNodePointer(childElement, null);
                                                                     
                                                                     // Test the method
                                                                     String result = pointer.getNamespaceURI();
                                                                     
                                                                     // Verify the result - should get namespace from ancestor
                                                                     assertEquals("http://example.com", result);
                                                                     
                                                                     // Verify interactions
                                                                     verify(childElement).getNamespaceURI();
                                                                     verify(parentElement).getAttributeNode("xmlns");
                                                                 }

 @Test
                                                                public void testGetNamespaceURIWithSpecificQName() {
                                                                    // Create test data
                                                                    String testNamespace = "http://test.example.com";
                                                                    String testQName = "xmlns:test";
                                                                    
                                                                    // Mock the node and its attribute
                                                                    Node mockNode = mock(Node.class);
                                                                    Element mockElement = mock(Element.class);
                                                                    Attr mockAttr = mock(Attr.class);
                                                                    
                                                                    // Setup behavior
                                                                    when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                    when(mockNode.getNamespaceURI()).thenReturn(null);
                                                                    when(mockNode.getPrefix()).thenReturn("test");
                                                                    when(mockNode.getLocalName()).thenReturn("testElement");
                                                                    
                                                                    // Setup attribute behavior - this is what the mutant breaks
                                                                    when(mockElement.getAttributeNode(testQName)).thenReturn(mockAttr);
                                                                    when(mockAttr.getValue()).thenReturn(testNamespace);
                                                                    
                                                                    // Create DOMNodePointer instance
                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                    
                                                                    // Test the method
                                                                    String result = pointer.getNamespaceURI("test");
                                                                    
                                                                    // Verify the correct namespace was found
                                                                    assertEquals(testNamespace, result);
                                                                    
                                                                    // Verify the attribute was looked up with correct qname
                                                                    verify(mockElement).getAttributeNode(testQName);
                                                                }

 @Test
                                                           public void testGetNamespaceURI_WithPrefixDefinedInAttributes_ShouldReturnCorrectNamespace() throws Exception {
                                                               // Setup test data
                                                               String prefix = "test";
                                                               String expectedNamespace = "http://test.example.com";
                                                               String qname = "xmlns:" + prefix;
                                                               
                                                               // Mock node hierarchy with namespace attribute
                                                               Element childElement = mock(Element.class);
                                                               Attr namespaceAttr = mock(Attr.class);
                                                               when(namespaceAttr.getValue()).thenReturn(expectedNamespace);
                                                               when(childElement.getAttributeNode(qname)).thenReturn(namespaceAttr);
                                                               
                                                               Document document = mock(Document.class);
                                                               when(document.getDocumentElement()).thenReturn(childElement);
                                                               
                                                               // Create test instance
                                                               DOMNodePointer pointer = new DOMNodePointer(document, Locale.ENGLISH);
                                                               
                                                               // Execute and verify
                                                               String result = pointer.getNamespaceURI(prefix);
                                                               assertEquals("Should return namespace URI from attribute", 
                                                                            expectedNamespace, result);
                                                               
                                                               // Verify the namespace was cached using reflection
                                                               Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                                               namespacesField.setAccessible(true);
                                                               Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
                                                               
                                                               assertNotNull("Namespaces cache should exist", namespaces);
                                                               assertEquals("Namespace should be cached", 
                                                                            expectedNamespace, namespaces.get(prefix));
                                                           }

 @Test
                                                           public void testGetNamespaceURI_ShouldFindNamespaceFromAncestor() throws Exception {
                                                               // Create a document with parent-child elements where namespace is defined on parent
                                                               javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                               javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                               org.w3c.dom.Document doc = builder.newDocument();
                                                               
                                                               // Create parent element with namespace declaration
                                                               org.w3c.dom.Element parent = doc.createElement("parent");
                                                               parent.setAttribute("xmlns", "http://example.com/ns");
                                                               
                                                               // Create child element without direct namespace
                                                               org.w3c.dom.Element child = doc.createElement("child");
                                                               parent.appendChild(child);
                                                               doc.appendChild(parent);
                                                               
                                                               // Create DOMNodePointer for testing
                                                               DOMNodePointer pointer = new DOMNodePointer(child, java.util.Locale.getDefault());
                                                               
                                                               // Test - should find namespace from parent's xmlns attribute
                                                               String result = pointer.getNamespaceURI();
                                                               
                                                               // Verify the namespace was correctly found from ancestor
                                                               assertEquals("http://example.com/ns", result);
                                                               
                                                               // This test will fail on the mutant because:
                                                               // - Original code: looks for "xmlns" attribute in parent and finds it
                                                               // - Mutant code: looks for "" attribute in parent and fails to find it
                                                               // - Thus mutant would return null instead of the namespace URI
                                                           }

 @Test
                                                       public void testGetNamespaceURI_DetectsNamespaceFromAttributes() throws Exception {
                                                           // Create a mock Element with namespace attributes
                                                           Element mockElement = mock(Element.class);
                                                           Attr mockAttr = mock(Attr.class);
                                                           
                                                           // Setup the expected behavior
                                                           when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                           when(mockElement.getAttributeNode("xmlns")).thenReturn(mockAttr);
                                                           when(mockAttr.getValue()).thenReturn("http://example.com/ns");
                                                           
                                                           // Create the DOMNodePointer with our mock element
                                                           DOMNodePointer pointer = new DOMNodePointer(mockElement, Locale.ENGLISH);
                                                           
                                                           // Test the method - should return namespace from attribute
                                                           String result = pointer.getNamespaceURI();
                                                           
                                                           // Verify it correctly gets namespace from attributes
                                                           assertEquals("http://example.com/ns", result);
                                                           
                                                           // Verify interactions - this would fail with the mutant
                                                           verify(mockElement).getAttributeNode("xmlns");
                                                       }

 @Test
                                                       public void testGetNamespaceURI_WithParentNamespace() throws Exception {
                                                           // Create a document with parent-child structure where namespace is defined in parent
                                                           Document doc = mock(Document.class);
                                                           Element parentElement = mock(Element.class);
                                                           Element childElement = mock(Element.class);
                                                           
                                                           // Setup document structure
                                                           when(doc.getDocumentElement()).thenReturn(parentElement);
                                                           
                                                           // Setup namespace behavior
                                                           when(childElement.getNamespaceURI()).thenReturn(null);
                                                           when(childElement.getParentNode()).thenReturn(parentElement);
                                                           when(childElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                           
                                                           // Setup parent element to have xmlns attribute
                                                           Attr namespaceAttr = mock(Attr.class);
                                                           when(namespaceAttr.getValue()).thenReturn("http://test.namespace");
                                                           when(parentElement.getAttributeNode("xmlns")).thenReturn(namespaceAttr);
                                                           when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                           
                                                           // Create DOMNodePointer with child element
                                                           DOMNodePointer pointer = new DOMNodePointer(childElement, Locale.ENGLISH);
                                                           
                                                           // Test - should get namespace from parent
                                                           String result = pointer.getNamespaceURI();
                                                           
                                                           // Verify
                                                           assertEquals("http://test.namespace", result);
                                                           
                                                           // Also verify the attribute lookup was attempted (would fail with mutant)
                                                           verify(parentElement).getAttributeNode("xmlns");
                                                       }

 @Test
                                                      public void testGetNamespaceURI_ShouldFindNamespaceFromAttribute() throws Exception {
                                                          // Setup test data
                                                          String prefix = "test";
                                                          String expectedNamespace = "http://test.com/ns";
                                                          String qname = "xmlns:" + prefix;
                                                          
                                                          // Create mock nodes
                                                          Element element = mock(Element.class);
                                                          Attr attr = mock(Attr.class);
                                                          when(attr.getValue()).thenReturn(expectedNamespace);
                                                          when(element.getAttributeNode(qname)).thenReturn(attr);
                                                          when(element.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                          
                                                          Document document = mock(Document.class);
                                                          when(document.getDocumentElement()).thenReturn(element);
                                                          
                                                          // Create DOMNodePointer instance
                                                          DOMNodePointer pointer = new DOMNodePointer(document, Locale.ENGLISH);
                                                          
                                                          // First call - should lookup from attribute
                                                          String result = pointer.getNamespaceURI(prefix);
                                                          
                                                          // Verify attribute lookup was performed
                                                          verify(element, times(1)).getAttributeNode(qname);
                                                          
                                                          // Verify correct namespace is returned
                                                          assertEquals(expectedNamespace, result);
                                                          
                                                          // Second call - should use cached value
                                                          result = pointer.getNamespaceURI(prefix);
                                                          assertEquals(expectedNamespace, result);
                                                          
                                                          // Verify attribute lookup was only called once (proves caching worked)
                                                          verify(element, times(1)).getAttributeNode(qname);
                                                      }

 @Test
                                                      public void testGetNamespaceURIWithNamespaceAttribute() {
                                                          // Setup - create a node with namespace attribute
                                                          Node mockNode = mock(Node.class);
                                                          Attr mockAttr = mock(Attr.class);
                                                          
                                                          when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                          when(mockNode.getAttributes()).thenReturn(mock(NamedNodeMap.class));
                                                          when(mockNode.getAttributes().getNamedItem("xmlns")).thenReturn(mockAttr);
                                                          when(mockAttr.getNodeValue()).thenReturn("http://example.com/ns");
                                                          
                                                          DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                          
                                                          // Test - should return the namespace URI from the attribute
                                                          String result = pointer.getNamespaceURI();
                                                          
                                                          // Verify - original would return the namespace, mutant would return null
                                                          assertEquals("http://example.com/ns", result);
                                                      }

 @Test
                                                      public void testGetNamespaceURIWithoutNamespaceAttribute() {
                                                          // Setup - create a node without namespace attribute
                                                          Node mockNode = mock(Node.class);
                                                          
                                                          when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                          when(mockNode.getAttributes()).thenReturn(mock(NamedNodeMap.class));
                                                          when(mockNode.getAttributes().getNamedItem("xmlns")).thenReturn(null);
                                                          
                                                          DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                          
                                                          // Test - should return null when no namespace attribute exists
                                                          String result = pointer.getNamespaceURI();
                                                          
                                                          // Verify - original would return null, mutant would try to process null attribute
                                                          assertNull(result);
                                                      }

 @Test
                                                  public void testGetNamespaceURI_ShouldReturnNamespaceFromParentAttribute() throws Exception {
                                                      // Create a parent element with namespace declaration
                                                      Element parent = mock(Element.class);
                                                      Attr namespaceAttr = mock(Attr.class);
                                                      when(namespaceAttr.getValue()).thenReturn("http://test.namespace");
                                                      
                                                      // Create test element with no namespace URI but with prefix
                                                      Element element = mock(Element.class);
                                                      when(element.getNamespaceURI()).thenReturn(null);
                                                      when(element.getParentNode()).thenReturn(parent);
                                                      
                                                      // Mock the attribute lookup
                                                      when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                      when(parent.getAttributeNode("xmlns:test")).thenReturn(namespaceAttr);
                                                      
                                                      // Mock the prefix lookup
                                                      DOMNodePointer pointer = new DOMNodePointer(element, Locale.ENGLISH);
                                                      when(DOMNodePointer.getPrefix(element)).thenReturn("test");
                                                      
                                                      // Test the method
                                                      String result = pointer.getNamespaceURI();
                                                      
                                                      // Verify the correct namespace URI is returned from parent's attribute
                                                      assertEquals("http://test.namespace", result);
                                                      
                                                      // Verify the attribute was accessed
                                                      verify(parent).getAttributeNode("xmlns:test");
                                                  }

 @Test
                                                 public void testGetNamespaceURI_WithValidXmlnsAttribute_ShouldReturnAttributeValue() throws Exception {
                                                     // Setup test data
                                                     String prefix = "test";
                                                     String expectedNamespace = "http://example.com/ns";
                                                     String qname = "xmlns:" + prefix;
                                                     
                                                     // Create mock nodes
                                                     Element mockElement = mock(Element.class);
                                                     Attr mockAttr = mock(Attr.class);
                                                     Document mockDocument = mock(Document.class);
                                                     
                                                     // Mock behavior
                                                     when(mockDocument.getDocumentElement()).thenReturn(mockElement);
                                                     when(mockElement.getAttributeNode(qname)).thenReturn(mockAttr);
                                                     when(mockAttr.getValue()).thenReturn(expectedNamespace);
                                                     
                                                     // Create test instance
                                                     DOMNodePointer pointer = new DOMNodePointer(mockDocument, Locale.ENGLISH);
                                                     
                                                     // First call - should hit mocks and cache the result
                                                     String result1 = pointer.getNamespaceURI(prefix);
                                                     
                                                     // Verify results
                                                     assertEquals("Should return namespace from xmlns attribute", 
                                                                 expectedNamespace, result1);
                                                     
                                                     // Verify attribute was checked
                                                     verify(mockElement).getAttributeNode(qname);
                                                     verify(mockAttr).getValue();
                                                     
                                                     // Second call - should use cached value
                                                     String result2 = pointer.getNamespaceURI(prefix);
                                                     assertEquals("Second call should return same cached value",
                                                                 expectedNamespace, result2);
                                                     
                                                     // Verify mocks weren't called again
                                                     verifyNoMoreInteractions(mockElement, mockAttr);
                                                 }

 @Test
                                                 public void testGetNamespaceURI_WithNullAttribute() {
                                                     // Setup
                                                     Node mockNode = mock(Node.class);
                                                     when(mockNode.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
                                                     when(mockNode.getNamespaceURI()).thenReturn(null);
                                                     
                                                     // Create DOMNodePointer with the mock node
                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                     
                                                     // Test - should handle null attribute properly
                                                     String result = pointer.getNamespaceURI();
                                                     
                                                     // Verify - either returns null or default namespace
                                                     // The mutant would either throw exception or return wrong value here
                                                     assertNull("Should return null for null attribute namespace", result);
                                                     
                                                     // Verify node interactions
                                                     verify(mockNode).getNodeType();
                                                     verify(mockNode).getNamespaceURI();
                                                 }

 @Test
                                                 public void testGetNamespaceURI_WithNonNullAttribute() {
                                                     // Setup
                                                     Node mockNode = mock(Node.class);
                                                     when(mockNode.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
                                                     when(mockNode.getNamespaceURI()).thenReturn("http://example.com/ns");
                                                     
                                                     // Create DOMNodePointer with the mock node
                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                     
                                                     // Test
                                                     String result = pointer.getNamespaceURI();
                                                     
                                                     // Verify
                                                     assertEquals("Should return correct namespace URI", 
                                                                 "http://example.com/ns", result);
                                                     
                                                     // Verify node interactions
                                                     verify(mockNode).getNodeType();
                                                     verify(mockNode).getNamespaceURI();
                                                 }

 @Test
                                                 public void testGetNamespaceURI_ShouldCheckParentNodesWhenNoAttribute() throws Exception {
                                                     // Setup test data
                                                     Element childElement = mock(Element.class);
                                                     Element parentElement = mock(Element.class);
                                                     Attr parentAttr = mock(Attr.class);
                                                     
                                                     // Mock behavior
                                                     when(childElement.getNamespaceURI()).thenReturn(null);
                                                     when(childElement.getParentNode()).thenReturn(parentElement);
                                                     when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                     
                                                     // Mock that child has no attribute but parent does
                                                     when(childElement.getAttributeNode(anyString())).thenReturn(null);
                                                     when(parentElement.getAttributeNode("xmlns:test")).thenReturn(parentAttr);
                                                     when(parentAttr.getValue()).thenReturn("http://parent.example.com");
                                                     
                                                     // Create test object
                                                     DOMNodePointer pointer = new DOMNodePointer(childElement, null);
                                                     
                                                     // Test and verify
                                                     String result = pointer.getNamespaceURI();
                                                     
                                                     // Verify parent node was checked
                                                     verify(childElement).getAttributeNode("xmlns");
                                                     verify(parentElement).getAttributeNode("xmlns");
                                                     
                                                     // Verify we got the parent's namespace
                                                     assertEquals("http://parent.example.com", result);
                                                 }

 @Test
                                                 public void testGetNamespaceURI_ShouldNotUseNullAttributeValue() throws Exception {
                                                     // Setup test data
                                                     Element element = mock(Element.class);
                                                     
                                                     // Mock behavior - element has no namespace URI and no attributes
                                                     when(element.getNamespaceURI()).thenReturn(null);
                                                     when(element.getAttributeNode(anyString())).thenReturn(null);
                                                     when(element.getParentNode()).thenReturn(null);
                                                     
                                                     // Create test object
                                                     DOMNodePointer pointer = new DOMNodePointer(element, null);
                                                     
                                                     // Test and verify
                                                     String result = pointer.getNamespaceURI();
                                                     
                                                     // Verify we didn't try to use a null attribute value
                                                     assertNull(result);
                                                 }

 @Test
                                            public void testGetNamespaceURI_NonExistentAttribute_ReturnsUnknownNamespace() throws Exception {
                                                // Setup test data
                                                String prefix = "test";
                                                String qname = "xmlns:" + prefix;
                                                
                                                // Mock document structure
                                                Document doc = mock(Document.class);
                                                Element rootElement = mock(Element.class);
                                                when(doc.getDocumentElement()).thenReturn(rootElement);
                                                
                                                // Mock element behavior - no attributes exist
                                                when(rootElement.getAttributeNode(qname)).thenReturn(null);
                                                when(rootElement.getParentNode()).thenReturn(null);
                                                
                                                // Create test instance
                                                DOMNodePointer pointer = new DOMNodePointer(doc, Locale.ENGLISH);
                                                
                                                // Execute test
                                                String result = pointer.getNamespaceURI(prefix);
                                                
                                                // Verify behavior
                                                // Original code would return UNKNOWN_NAMESPACE when attr is null
                                                // Mutant would either throw NPE or return wrong value
                                                assertNull("Should return null for UNKNOWN_NAMESPACE", result);
                                                
                                                // Verify the namespace was cached
                                                Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                                namespacesField.setAccessible(true);
                                                @SuppressWarnings("unchecked")
                                                Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
                                                assertEquals(NodePointer.UNKNOWN_NAMESPACE, namespaces.get(prefix));
                                            }

 @Test
                                            public void testGetNamespaceURI_WithAttributeNode() throws Exception {
                                                // Setup mock attribute node with namespace
                                                Attr mockAttr = mock(Attr.class);
                                                when(mockAttr.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
                                                when(mockAttr.getNamespaceURI()).thenReturn("http://test.namespace");
                                                
                                                // Create DOMNodePointer with the mock attribute node
                                                DOMNodePointer pointer = new DOMNodePointer(mockAttr, null);
                                                
                                                // Verify namespace URI is correctly returned
                                                assertEquals("http://test.namespace", pointer.getNamespaceURI());
                                            }

 @Test
                                            public void testGetNamespaceURI_WithElementNode() throws Exception {
                                                // Setup mock element node with namespace
                                                Node mockElement = mock(Node.class);
                                                when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                when(mockElement.getNamespaceURI()).thenReturn("http://test.namespace");
                                                
                                                // Create DOMNodePointer with the mock element node
                                                DOMNodePointer pointer = new DOMNodePointer(mockElement, null);
                                                
                                                // Verify namespace URI is correctly returned
                                                assertEquals("http://test.namespace", pointer.getNamespaceURI());
                                            }

 @Test
                                            public void testGetNamespaceURI_WithNullNamespace() throws Exception {
                                                // Setup mock node with null namespace
                                                Node mockNode = mock(Node.class);
                                                when(mockNode.getNamespaceURI()).thenReturn(null);
                                                
                                                // Create DOMNodePointer with the mock node
                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                
                                                // Verify null is returned when no namespace exists
                                                assertNull(pointer.getNamespaceURI());
                                            }

 @Test
                                        public void testGetNamespaceURI_ShouldFindNamespaceFromParentAttribute() throws Exception {
                                            // Create a parent element with xmlns attribute
                                            Element parentElement = mock(Element.class);
                                            Attr xmlnsAttr = mock(Attr.class);
                                            when(xmlnsAttr.getValue()).thenReturn("http://test.namespace");
                                            when(parentElement.getAttributeNode("xmlns:test")).thenReturn(xmlnsAttr);
                                            when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                            when(parentElement.getNamespaceURI()).thenReturn(null);
                                            
                                            // Create child element with no direct namespace
                                            Element childElement = mock(Element.class);
                                            when(childElement.getParentNode()).thenReturn(parentElement);
                                            when(childElement.getNamespaceURI()).thenReturn(null);
                                            when(childElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                            
                                            // Mock the prefix lookup
                                            when(DOMNodePointer.getPrefix(childElement)).thenReturn("test");
                                            
                                            // Create the pointer
                                            DOMNodePointer pointer = new DOMNodePointer(childElement, Locale.ENGLISH);
                                            
                                            // Test - should find namespace from parent's attribute
                                            String result = pointer.getNamespaceURI();
                                            
                                            // Verify
                                            assertEquals("http://test.namespace", result);
                                            
                                            // Verify parent lookup was attempted
                                            verify(parentElement).getAttributeNode("xmlns:test");
                                        }

 @Test
                                       public void testGetNamespaceURI_WithValidXmlnsAttribute_ShouldReturnAttributeValue1() throws Exception {
                                           // Setup test data
                                           String prefix = "test";
                                           String expectedNamespace = "http://example.com/ns";
                                           String qname = "xmlns:" + prefix;
                                           
                                           // Mock the attribute that should be found
                                           Attr mockAttr = mock(Attr.class);
                                           when(mockAttr.getValue()).thenReturn(expectedNamespace);
                                           
                                           // Mock the element that contains the attribute
                                           Element mockElement = mock(Element.class);
                                           when(mockElement.getAttributeNode(qname)).thenReturn(mockAttr);
                                           when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                           
                                           // Mock the document node
                                           Node mockNode = mock(Node.class);
                                           when(mockNode.getParentNode()).thenReturn(null);
                                           when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                           
                                           // Create DOMNodePointer with our test node
                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                           
                                           // Test - this should return the attribute value in original code
                                           // but would return UNKNOWN_NAMESPACE in mutated code
                                           String result = pointer.getNamespaceURI(prefix);
                                           
                                           // Verify the attribute was accessed (would fail in mutant)
                                           verify(mockElement).getAttributeNode(qname);
                                           
                                           // Assert we got the expected namespace (would fail in mutant)
                                           assertEquals("Should return namespace from xmlns: attribute", 
                                                       expectedNamespace, result);
                                           
                                           // Use reflection to verify it was cached
                                           Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                           namespacesField.setAccessible(true);
                                           Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
                                           assertNotNull(namespaces);
                                           assertEquals("Namespace should be cached", 
                                                       expectedNamespace, namespaces.get(prefix));
                                       }

 @Test
                                   public void testGetNamespaceURI_WithNamespaceAttribute_ShouldReturnCorrectURI() throws Exception {
                                       // Create a mock node with namespace attributes
                                       Node mockNode = mock(Node.class);
                                       Attr mockAttr = mock(Attr.class);
                                       
                                       // Setup behavior
                                       when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                       when(mockNode.getAttributes()).thenReturn(new NamedNodeMap() {
                                           @Override
                                           public Node getNamedItem(String name) {
                                               return "xmlns".equals(name) ? mockAttr : null;
                                           }
                                           // Other required methods of NamedNodeMap (simplified for test)
                                           public int getLength() { return 1; }
                                           public Node item(int index) { return index == 0 ? mockAttr : null; }
                                           public Node getNamedItemNS(String namespaceURI, String localName) { return null; }
                                           public Node setNamedItem(Node arg) { return null; }
                                           public Node removeNamedItem(String name) { return null; }
                                           public Node setNamedItemNS(Node arg) { return null; }
                                           public Node removeNamedItemNS(String namespaceURI, String localName) { return null; }
                                       });
                                       
                                       when(mockAttr.getNodeName()).thenReturn("xmlns");
                                       when(mockAttr.getValue()).thenReturn("http://example.com/ns");
                                       
                                       // Create DOMNodePointer instance
                                       DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                       
                                       // Test the method
                                       String result = pointer.getNamespaceURI();
                                       
                                       // Verify - this will catch the mutant which would return null
                                       assertEquals("http://example.com/ns", result);
                                   }

 @Test
                                       public void testGetNamespaceURI_WithParentNamespaceDeclaration() {
                                           // Create test elements
                                           Element parentElement = mock(Element.class);
                                           Element testElement = mock(Element.class);
                                           Attr namespaceAttr = mock(Attr.class);
                                           
                                           // Setup mock behavior
                                           when(testElement.getNamespaceURI()).thenReturn(null);
                                           when(testElement.getParentNode()).thenReturn(parentElement);
                                           when(testElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                           
                                           when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                           when(parentElement.getAttributeNode("xmlns:test")).thenReturn(namespaceAttr);
                                           when(namespaceAttr.getValue()).thenReturn("http://example.com/ns");
                                           
                                           // Setup DOMNodePointer
                                           DOMNodePointer pointer = new DOMNodePointer(testElement, null);
                                           
                                           // The mutation would return null here instead of the namespace URI
                                           String result = pointer.getNamespaceURI();
                                           
                                           // Verify the correct namespace URI is returned
                                           assertEquals("http://example.com/ns", result);
                                           
                                           // Verify the attribute value was accessed (would fail with mutant)
                                           verify(namespaceAttr).getValue();
                                       }

 @Test
                                  public void testGetNamespaceURI_WithValidXmlnsAttribute_ShouldReturnAttributeValue2() throws Exception {
                                      // Setup test document with xmlns attribute
                                      Document doc = mock(Document.class);
                                      Element element = mock(Element.class);
                                      Attr attr = mock(Attr.class);
                                      
                                      when(doc.getDocumentElement()).thenReturn(element);
                                      when(element.getAttributeNode("xmlns:test")).thenReturn(attr);
                                      when(attr.getValue()).thenReturn("http://test-namespace");
                                      
                                      // Create test pointer
                                      DOMNodePointer pointer = new DOMNodePointer(doc, Locale.US);
                                      
                                      // Call method with prefix that should find the attribute
                                      String result = pointer.getNamespaceURI("test");
                                      
                                      // Verify results
                                      assertEquals("http://test-namespace", result);
                                      
                                      // Verify namespace was cached
                                      Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                      namespacesField.setAccessible(true);
                                      Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
                                      assertEquals("http://test-namespace", namespaces.get("test"));
                                  }

 @Test
                                  public void testGetNamespaceURI_WithAttributeNode_ShouldReturnActualNamespaceURI() {
                                      // Create a mock attribute node with namespace URI
                                      String expectedNamespaceURI = "http://example.com/ns";
                                      Attr mockAttr = mock(Attr.class);
                                      when(mockAttr.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
                                      when(mockAttr.getNamespaceURI()).thenReturn(expectedNamespaceURI);
                                      
                                      // Create DOMNodePointer instance with the mock node
                                      DOMNodePointer pointer = new DOMNodePointer(mockAttr, null);
                                      
                                      // Verify the namespace URI is correctly returned
                                      assertEquals("Should return the actual namespace URI of the attribute",
                                                  expectedNamespaceURI, 
                                                  pointer.getNamespaceURI());
                                  }

 @Test
                             public void testGetNamespaceURI_WithValidXmlnsAttribute_ReturnsAttributeValue() throws Exception {
                                 // Setup test data
                                 String prefix = "test";
                                 String expectedNamespace = "http://example.com/ns";
                                 String qname = "xmlns:" + prefix;
                                 
                                 // Create mock elements
                                 Element mockElement = mock(Element.class);
                                 Attr mockAttr = mock(Attr.class);
                                 Document mockDocument = mock(Document.class);
                                 
                                 // Configure mocks
                                 when(mockDocument.getDocumentElement()).thenReturn(mockElement);
                                 when(mockElement.getAttributeNode(qname)).thenReturn(mockAttr);
                                 when(mockAttr.getValue()).thenReturn(expectedNamespace);
                                 
                                 // Create test instance
                                 DOMNodePointer pointer = new DOMNodePointer(mockDocument, Locale.ENGLISH);
                                 
                                 // Execute test - first call should populate cache
                                 String result = pointer.getNamespaceURI(prefix);
                                 
                                 // Verify results
                                 assertEquals("Should return namespace from attribute value", 
                                             expectedNamespace, result);
                                 
                                 // Reset mocks to verify caching
                                 reset(mockElement, mockAttr);
                                 
                                 // Second call should use cache and not hit mocks
                                 result = pointer.getNamespaceURI(prefix);
                                 assertEquals("Should return cached namespace value", 
                                             expectedNamespace, result);
                                 
                                 // Verify no interactions with mocks on second call
                                 verifyNoInteractions(mockElement);
                                 verifyNoInteractions(mockAttr);
                             }

 @Test
                             public void testGetNamespaceURI_ShouldReturnNamespaceFromParentAttribute1() throws Exception {
                                 // Setup test data
                                 Element childElement = mock(Element.class);
                                 Element parentElement = mock(Element.class);
                                 Attr namespaceAttr = mock(Attr.class);
                                 
                                 // Mock behavior
                                 when(childElement.getNamespaceURI()).thenReturn(null);
                                 when(childElement.getParentNode()).thenReturn(parentElement);
                                 when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                 when(parentElement.getAttributeNode("xmlns:test")).thenReturn(namespaceAttr);
                                 when(namespaceAttr.getValue()).thenReturn("http://example.com/ns");
                                 
                                 // Mock static method getPrefix
                                 mockStatic(DOMNodePointer.class);
                                 when(DOMNodePointer.getPrefix(childElement)).thenReturn("test");
                                 
                                 // Create test instance
                                 DOMNodePointer pointer = new DOMNodePointer(childElement, Locale.ENGLISH);
                                 
                                 // Execute and verify
                                 String result = pointer.getNamespaceURI();
                                 assertEquals("http://example.com/ns", result);
                                 
                                 // Verify the mutation would fail here - mutant would return null
                                 // because it sets uri="" instead of getting the attribute value
                             }

 @Test
                             public void testGetNamespaceURI_ElementNodeWithNamespace() throws Exception {
                                 // Create a mock Element node with namespace
                                 Element elementWithNS = mock(Element.class);
                                 when(elementWithNS.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                 when(elementWithNS.getNamespaceURI()).thenReturn("http://example.com/ns");
                                 
                                 // Create DOMNodePointer instance
                                 DOMNodePointer pointer = new DOMNodePointer(elementWithNS, null);
                                 
                                 // Test should fail if break statement is commented out in the implementation
                                 assertEquals("http://example.com/ns", pointer.getNamespaceURI());
                             }

 @Test
                             public void testGetNamespaceURI_AttributeNodeWithNamespace() throws Exception {
                                 // Create a mock Attribute node with namespace
                                 Node attrWithNS = mock(Node.class);
                                 when(attrWithNS.getNodeType()).thenReturn(Node.ATTRIBUTE_NODE);
                                 when(attrWithNS.getNamespaceURI()).thenReturn("http://example.com/attr-ns");
                                 
                                 // Create DOMNodePointer instance
                                 DOMNodePointer pointer = new DOMNodePointer(attrWithNS, null);
                                 
                                 // Test should fail if break statement is commented out in the implementation
                                 assertEquals("http://example.com/attr-ns", pointer.getNamespaceURI());
                             }

 @Test
                             public void testGetNamespaceURI_ElementNodeWithoutNamespace() throws Exception {
                                 // Create a mock Element node without namespace
                                 Element elementNoNS = mock(Element.class);
                                 when(elementNoNS.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                 when(elementNoNS.getNamespaceURI()).thenReturn(null);
                                 
                                 // Create DOMNodePointer instance
                                 DOMNodePointer pointer = new DOMNodePointer(elementNoNS, null);
                                 
                                 // Test should fail if break statement is commented out in the implementation
                                 assertNull(pointer.getNamespaceURI());
                             }

 @Test
                         public void testGetNamespaceURI_ShouldReturnFirstMatchingNamespace() throws Exception {
                             // Create a mock node hierarchy with multiple namespace declarations
                             Element grandParent = mock(Element.class);
                             Element parent = mock(Element.class);
                             Element child = mock(Element.class);
                             
                             // Setup namespace attributes at different levels
                             Attr grandParentAttr = mock(Attr.class);
                             when(grandParentAttr.getValue()).thenReturn("grandParentURI");
                             when(grandParent.getAttributeNode("xmlns:test")).thenReturn(grandParentAttr);
                             
                             Attr parentAttr = mock(Attr.class);
                             when(parentAttr.getValue()).thenReturn("parentURI");
                             when(parent.getAttributeNode("xmlns:test")).thenReturn(parentAttr);
                             
                             // Setup node relationships
                             when(child.getParentNode()).thenReturn(parent);
                             when(parent.getParentNode()).thenReturn(grandParent);
                             when(grandParent.getParentNode()).thenReturn(null);
                             
                             // Setup test node behavior
                             when(child.getNamespaceURI()).thenReturn(null);
                             when(child.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                             
                             // Create DOMNodePointer instance
                             DOMNodePointer pointer = new DOMNodePointer(child, Locale.ENGLISH);
                             
                             // Test - should return the first found namespace (parentURI)
                             String result = pointer.getNamespaceURI();
                             
                             // Verify it returns the first matching namespace (not grandParentURI)
                             assertEquals("parentURI", result);
                             
                             // Verify the search stopped after finding parent's namespace
                             verify(child).getAttributeNode("xmlns:test");
                             verify(parent).getAttributeNode("xmlns:test");
                             verify(grandParent, never()).getAttributeNode("xmlns:test");
                         }

 @Test
                        public void testGetNamespaceURI_ShouldReturnFirstFoundNamespace() throws Exception {
                            // Setup node hierarchy with multiple namespace definitions
                            Element grandParent = mock(Element.class);
                            Element parent = mock(Element.class);
                            Element child = mock(Element.class);
                            
                            // Setup namespace attributes
                            Attr grandParentAttr = mock(Attr.class);
                            when(grandParentAttr.getValue()).thenReturn("grandParentNS");
                            Attr parentAttr = mock(Attr.class);
                            when(parentAttr.getValue()).thenReturn("parentNS");
                            
                            // Mock node relationships
                            when(child.getParentNode()).thenReturn(parent);
                            when(parent.getParentNode()).thenReturn(grandParent);
                            
                            // Mock attribute lookups
                            when(grandParent.getAttributeNode("xmlns:test")).thenReturn(grandParentAttr);
                            when(parent.getAttributeNode("xmlns:test")).thenReturn(parentAttr);
                            when(child.getAttributeNode("xmlns:test")).thenReturn(null);
                            
                            // Mock node types
                            when(grandParent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                            when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                            when(child.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                            
                            // Create test instance
                            DOMNodePointer pointer = new DOMNodePointer(child, Locale.getDefault());
                            
                            // Test - should return parentNS (first found) not grandParentNS
                            String result = pointer.getNamespaceURI("test");
                            
                            // Verify
                            assertEquals("parentNS", result);
                            
                            // Verify the namespace was cached using reflection
                            Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                            namespacesField.setAccessible(true);
                            Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
                            assertEquals("parentNS", namespaces.get("test"));
                        }

 @Test
                        public void testGetNamespaceURI_ShouldReturnCorrectNamespace_WhenMultipleAttributesExist() {
                            // Create mock nodes and attributes
                            Node mockNode = mock(Node.class);
                            NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                            Attr mockNamespaceAttr = mock(Attr.class);
                            Attr mockOtherAttr = mock(Attr.class);
                            
                            // Setup behavior
                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                            when(mockNode.getAttributes()).thenReturn(mockAttributes);
                            when(mockAttributes.getLength()).thenReturn(2);
                            
                            // First attribute is the namespace we want
                            when(mockAttributes.item(0)).thenReturn(mockNamespaceAttr);
                            when(mockNamespaceAttr.getNodeName()).thenReturn("xmlns:test");
                            when(mockNamespaceAttr.getNodeValue()).thenReturn("http://desired-namespace");
                            
                            // Second attribute is a different namespace that should be skipped
                            when(mockAttributes.item(1)).thenReturn(mockOtherAttr);
                            when(mockOtherAttr.getNodeName()).thenReturn("xmlns:other");
                            when(mockOtherAttr.getNodeValue()).thenReturn("http://wrong-namespace");
                            
                            // Create DOMNodePointer instance
                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                            
                            // Test - should return the first namespace URI
                            String result = pointer.getNamespaceURI();
                            
                            // Verify - with the mutation (continue instead of break), 
                            // it might return the wrong namespace
                            assertEquals("http://desired-namespace", result);
                            
                            // Verify interactions
                            verify(mockNode).getNodeType();
                            verify(mockNode).getAttributes();
                            verify(mockAttributes, times(2)).getLength();
                            verify(mockAttributes).item(0);
                            verify(mockNamespaceAttr).getNodeName();
                            verify(mockNamespaceAttr).getNodeValue();
                        }

 @Test
                    public void testGetNamespaceURI_ShouldReturnFirstFoundNamespace_NotContinueSearching() {
                        // Setup test data
                        String prefix = "test";
                        String expectedNamespace = "http://first-found.com";
                        String otherNamespace = "http://should-not-return.com";
                        
                        // Mock document structure with multiple matching attributes
                        Document mockDocument = mock(Document.class);
                        Element mockRootElement = mock(Element.class);
                        Element mockParentElement = mock(Element.class);
                        
                        // Mock attributes at different levels
                        Attr firstAttr = mock(Attr.class);
                        when(firstAttr.getValue()).thenReturn(expectedNamespace);
                        Attr secondAttr = mock(Attr.class);
                        when(secondAttr.getValue()).thenReturn(otherNamespace);
                        
                        // Mock element hierarchy
                        when(mockDocument.getDocumentElement()).thenReturn(mockRootElement);
                        when(mockRootElement.getParentNode()).thenReturn(mockParentElement);
                        when(mockRootElement.getAttributeNode("xmlns:" + prefix)).thenReturn(firstAttr);
                        when(mockParentElement.getAttributeNode("xmlns:" + prefix)).thenReturn(secondAttr);
                        when(mockRootElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                        when(mockParentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                        
                        // Create test instance
                        DOMNodePointer pointer = new DOMNodePointer(mockDocument, Locale.ENGLISH);
                        
                        // Execute test
                        String result = pointer.getNamespaceURI(prefix);
                        
                        // Verify - should return first found namespace, not continue searching
                        assertEquals(expectedNamespace, result);
                        
                        // Additional verification that we didn't continue searching
                        verify(mockParentElement, never()).getAttributeNode("xmlns:" + prefix);
                    }

 @Test
                    public void testGetNamespaceURI_ShouldReturnFirstFoundNamespace1() throws Exception {
                        // Create a 3-level node hierarchy with namespace declarations at each level
                        Element grandParent = mock(Element.class);
                        Element parent = mock(Element.class);
                        Element child = mock(Element.class);
                        
                        // Setup namespace attributes
                        Attr grandParentAttr = mock(Attr.class);
                        when(grandParentAttr.getValue()).thenReturn("grandParentNS");
                        Attr parentAttr = mock(Attr.class);
                        when(parentAttr.getValue()).thenReturn("parentNS");
                        Attr childAttr = mock(Attr.class);
                        when(childAttr.getValue()).thenReturn("childNS");
                        
                        // Setup node relationships
                        when(child.getParentNode()).thenReturn(parent);
                        when(parent.getParentNode()).thenReturn(grandParent);
                        when(grandParent.getParentNode()).thenReturn(null);
                        
                        // Setup namespace lookups - all nodes have xmlns:test attributes
                        when(child.getAttributeNode("xmlns:test")).thenReturn(childAttr);
                        when(parent.getAttributeNode("xmlns:test")).thenReturn(parentAttr);
                        when(grandParent.getAttributeNode("xmlns:test")).thenReturn(grandParentAttr);
                        
                        // Setup element behavior
                        when(child.getNamespaceURI()).thenReturn(null);
                        when(child.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                        when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                        when(grandParent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                        
                        // The method should return the first found namespace (childNS)
                        String result = DOMNodePointer.getNamespaceURI(child);
                        
                        // Verify it returns the first found namespace (childNS) not parentNS or grandParentNS
                        assertEquals("childNS", result);
                        
                        // Verify the search stopped after finding the first match
                        verify(child).getAttributeNode("xmlns:test");
                        verify(parent, never()).getAttributeNode("xmlns:test");
                        verify(grandParent, never()).getAttributeNode("xmlns:test");
                    }

 @Test
                       public void testGetNamespaceURI_ShouldFindParentNamespace() throws Exception {
                           // Create mock nodes
                           Node childNode = mock(Node.class);
                           Node parentNode = mock(Node.class);
                           
                           // Set up namespace behavior
                           when(childNode.getNamespaceURI()).thenReturn(null);
                           when(childNode.getParentNode()).thenReturn(parentNode);
                           when(parentNode.getNamespaceURI()).thenReturn("http://parent-namespace");
                           
                           // Create test object
                           DOMNodePointer pointer = new DOMNodePointer(childNode, null);
                           
                           // Verify it gets namespace from parent
                           assertEquals("http://parent-namespace", pointer.getNamespaceURI());
                           
                           // Verify parent node was actually accessed
                           verify(childNode).getParentNode();
                       }

 @Test
                       public void testGetNamespaceURI_ShouldFindOwnNamespace() throws Exception {
                           // Create mock node with its own namespace
                           Node node = mock(Node.class);
                           when(node.getNamespaceURI()).thenReturn("http://own-namespace");
                           
                           // Create test object
                           DOMNodePointer pointer = new DOMNodePointer(node, null);
                           
                           // Verify it gets the node's own namespace
                           assertEquals("http://own-namespace", pointer.getNamespaceURI());
                       }

 @Test
                   public void testGetNamespaceURI_ShouldFindNamespaceInParentNode() throws Exception {
                       // Create a mock element hierarchy where the namespace is defined in a parent
                       Element grandParent = mock(Element.class);
                       Element parent = mock(Element.class);
                       Element child = mock(Element.class);
                       
                       // Setup the hierarchy
                       when(child.getParentNode()).thenReturn(parent);
                       when(parent.getParentNode()).thenReturn(grandParent);
                       
                       // Child has no namespace URI or xmlns attribute
                       when(child.getNamespaceURI()).thenReturn(null);
                       when(child.getAttributeNode(anyString())).thenReturn(null);
                       
                       // Parent has no namespace URI but has xmlns attribute
                       when(parent.getNamespaceURI()).thenReturn(null);
                       Attr xmlnsAttr = mock(Attr.class);
                       when(xmlnsAttr.getValue()).thenReturn("http://example.com");
                       when(parent.getAttributeNode("xmlns")).thenReturn(xmlnsAttr);
                       
                       // Grandparent has no relevant attributes
                       when(grandParent.getNamespaceURI()).thenReturn(null);
                       when(grandParent.getAttributeNode(anyString())).thenReturn(null);
                       
                       // Create DOMNodePointer with child node
                       DOMNodePointer pointer = new DOMNodePointer(child, Locale.ENGLISH);
                       
                       // Test - should find namespace from parent's xmlns attribute
                       String result = pointer.getNamespaceURI();
                       
                       // Verify the mutation would fail this test (mutant would return null)
                       assertEquals("http://example.com", result);
                       
                       // Verify the hierarchy was traversed
                       verify(child).getParentNode();
                       verify(parent).getParentNode();
                   }

 @Test
                  public void testGetNamespaceURI_ShouldTraverseParentNodes_WhenNamespaceNotInCurrentNode() throws Exception {
                      // Setup DOM hierarchy where namespace is defined in parent but not current node
                      String testPrefix = "test";
                      String expectedNamespace = "http://test.com/ns";
                      
                      // Create parent element with namespace declaration
                      Element parentElement = mock(Element.class);
                      Attr parentAttr = mock(Attr.class);
                      when(parentAttr.getValue()).thenReturn(expectedNamespace);
                      when(parentElement.getAttributeNode("xmlns:" + testPrefix)).thenReturn(parentAttr);
                      when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                      
                      // Create child element (current node) without namespace declaration
                      Element childElement = mock(Element.class);
                      when(childElement.getAttributeNode("xmlns:" + testPrefix)).thenReturn(null);
                      when(childElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                      when(childElement.getParentNode()).thenReturn(parentElement);
                      
                      // Create DOMNodePointer with child node as current node
                      DOMNodePointer pointer = new DOMNodePointer(childElement, Locale.ENGLISH);
                      
                      // Test - original should find namespace in parent, mutant will return UNKNOWN_NAMESPACE
                      String result = pointer.getNamespaceURI(testPrefix);
                      
                      // Verify
                      assertEquals("Should find namespace declared in parent node", 
                                  expectedNamespace, result);
                      
                      // Also verify it was cached using reflection
                      Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                      namespacesField.setAccessible(true);
                      @SuppressWarnings("unchecked")
                      Map<String, String> namespaces = (Map<String, String>) namespacesField.get(pointer);
                      assertEquals("Namespace should be cached", 
                                  expectedNamespace, namespaces.get(testPrefix));
                  }

 @Test
                  public void testGetNamespaceURI_ShouldFindParentNamespace1() throws Exception {
                      // Create a mock DOM structure where namespace is only in parent
                      Node grandParent = mock(Node.class);
                      Node parent = mock(Node.class);
                      Node child = mock(Node.class);
                      
                      // Setup namespace behavior
                      when(grandParent.getNamespaceURI()).thenReturn("grandParentNS");
                      when(parent.getNamespaceURI()).thenReturn(null);
                      when(child.getNamespaceURI()).thenReturn(null);
                      
                      // Setup parent-child relationships
                      when(parent.getParentNode()).thenReturn(grandParent);
                      when(child.getParentNode()).thenReturn(parent);
                      
                      // For the mutant case (getFirstChild)
                      Node dummyChild = mock(Node.class);
                      when(parent.getFirstChild()).thenReturn(dummyChild);
                      when(dummyChild.getNamespaceURI()).thenReturn("dummyNS");
                      
                      // Create the pointer with child node
                      DOMNodePointer pointer = new DOMNodePointer(child, null);
                      
                      // Test - should get namespace from grandParent
                      String result = pointer.getNamespaceURI();
                      
                      // Verify
                      assertEquals("grandParentNS", result);
                      
                      // The mutant would return "dummyNS" or null instead
                  }

 @Test
                  public void testGetNamespaceURI_WithLocalNamespace() throws Exception {
                      // Create a node with its own namespace
                      Node node = mock(Node.class);
                      when(node.getNamespaceURI()).thenReturn("localNS");
                      when(node.getParentNode()).thenReturn(null);
                      
                      DOMNodePointer pointer = new DOMNodePointer(node, null);
                      
                      String result = pointer.getNamespaceURI();
                      
                      assertEquals("localNS", result);
                  }

 @Test
                  public void testGetNamespaceURI_NoNamespaceFound() throws Exception {
                      // Create a node with no namespace in hierarchy
                      Node node = mock(Node.class);
                      when(node.getNamespaceURI()).thenReturn(null);
                      when(node.getParentNode()).thenReturn(null);
                      
                      DOMNodePointer pointer = new DOMNodePointer(node, null);
                      
                      String result = pointer.getNamespaceURI();
                      
                      assertNull(result);
                  }

 @Test
              public void testGetNamespaceURI_ShouldFindNamespaceInParentNode1() throws Exception {
                  // Create a DOM structure with namespace declared in parent
                  Document doc = mock(Document.class);
                  Element parentElement = mock(Element.class);
                  Element childElement = mock(Element.class);
                  
                  // Setup parent-child relationship
                  when(doc.getDocumentElement()).thenReturn(parentElement);
                  when(parentElement.getFirstChild()).thenReturn(childElement);
                  when(childElement.getParentNode()).thenReturn(parentElement);
                  
                  // Setup namespace attribute in parent
                  Attr namespaceAttr = mock(Attr.class);
                  when(namespaceAttr.getValue()).thenReturn("http://test-namespace");
                  when(parentElement.getAttributeNode("xmlns:test")).thenReturn(namespaceAttr);
                  
                  // Create DOMNodePointer pointing to child element
                  DOMNodePointer pointer = new DOMNodePointer(childElement, Locale.ENGLISH);
                  
                  // Test - should find namespace by searching parent
                  String result = pointer.getNamespaceURI("test");
                  
                  // Verify
                  assertEquals("http://test-namespace", result);
                  
                  // Additional verification that would catch the mutant
                  verify(parentElement, times(1)).getAttributeNode("xmlns:test");
                  verify(childElement, never()).getFirstChild(); // Mutant would call this
              }

 @Test
              public void testGetNamespaceURI_ShouldFindNamespaceInParent() throws Exception {
                  // Create a 3-level hierarchy where namespace is declared at grandparent level
                  // parent -> child -> grandchild (current node)
                  
                  // Mock nodes
                  Element grandparent = mock(Element.class);
                  Element parent = mock(Element.class);
                  Element current = mock(Element.class);
                  
                  // Setup namespace behavior
                  when(current.getNamespaceURI()).thenReturn(null);
                  when(parent.getNamespaceURI()).thenReturn(null);
                  
                  // Setup parent/child relationships
                  when(current.getParentNode()).thenReturn(parent);
                  when(parent.getParentNode()).thenReturn(grandparent);
                  
                  // Setup namespace attribute in grandparent
                  Attr namespaceAttr = mock(Attr.class);
                  when(namespaceAttr.getValue()).thenReturn("http://test.ns");
                  when(grandparent.getAttributeNode("xmlns")).thenReturn(namespaceAttr);
                  
                  // Setup node types
                  when(current.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                  when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                  when(grandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                  
                  // Test
                  String result = DOMNodePointer.getNamespaceURI(current);
                  
                  // Verify - original should find the namespace in grandparent
                  assertEquals("http://test.ns", result);
                  
                  // The mutant would fail here because it would look at children instead of parents
                  // and wouldn't find the namespace declaration
              }

 @Test
                 public void testGetNamespaceURI_ShouldTraverseParentNodesNotSiblings() {
                     // Create mock nodes with a parent-child-sibling structure
                     Node grandParent = mock(Node.class);
                     Node parent = mock(Node.class);
                     Node child = mock(Node.class);
                     Node sibling = mock(Node.class);
                     
                     // Setup namespace URIs
                     when(grandParent.getNamespaceURI()).thenReturn("grandParentNS");
                     when(parent.getNamespaceURI()).thenReturn("parentNS");
                     when(child.getNamespaceURI()).thenReturn(null);
                     when(sibling.getNamespaceURI()).thenReturn("siblingNS");
                     
                     // Setup parent-child relationships
                     when(child.getParentNode()).thenReturn(parent);
                     when(parent.getParentNode()).thenReturn(grandParent);
                     
                     // Setup sibling relationships
                     when(child.getNextSibling()).thenReturn(sibling);
                     
                     // Create DOMNodePointer with child node
                     DOMNodePointer pointer = new DOMNodePointer(child, null);
                     
                     // Test - should return parent's namespace (parentNS), not sibling's
                     // If it returns siblingNS, the mutant is alive
                     assertEquals("parentNS", pointer.getNamespaceURI());
                 }

 @Test
             public void testGetNamespaceURI_ShouldFindNamespaceInParentElement() {
                 // Setup DOM structure:
                 // <parent xmlns:test="http://test.com">
                 //   <child/>
                 // </parent>
                 
                 // Mock elements
                 Element parent = mock(Element.class);
                 Element child = mock(Element.class);
                 Document document = mock(Document.class);
                 Attr namespaceAttr = mock(Attr.class);
                 
                 // Mock behavior
                 when(namespaceAttr.getValue()).thenReturn("http://test.com");
                 when(parent.getAttributeNode("xmlns:test")).thenReturn(namespaceAttr);
                 when(child.getParentNode()).thenReturn(parent);
                 when(child.getNextSibling()).thenReturn(null); // No siblings
                 when(document.getDocumentElement()).thenReturn(parent);
                 
                 // Create test instance
                 DOMNodePointer pointer = new DOMNodePointer(child, Locale.ENGLISH);
                 
                 // Test - should find namespace in parent
                 String result = pointer.getNamespaceURI("test");
                 
                 // Verify
                 assertEquals("http://test.com", result);
                 
                 // Additional verification that we checked parent
                 verify(child).getParentNode();
                 verify(child, never()).getNextSibling(); // Original doesn't check siblings
             }

 @Test
            public void testGetNamespaceURI_DetectsParentNamespaceDeclaration() throws Exception {
                // Create a document with parent-child structure where namespace is defined in parent
                javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                org.w3c.dom.Document doc = builder.newDocument();
                
                // Create parent element with namespace declaration
                org.w3c.dom.Element parent = doc.createElement("parent");
                parent.setAttribute("xmlns:test", "http://test-namespace");
                
                // Create child element that should inherit the namespace
                org.w3c.dom.Element child = doc.createElement("test:child");
                parent.appendChild(child);
                doc.appendChild(parent);
                
                // Create DOMNodePointer pointing to the child element
                DOMNodePointer pointer = new DOMNodePointer(child, Locale.getDefault());
                
                // Test that namespace URI is correctly found by looking up parent chain
                String result = pointer.getNamespaceURI();
                
                // Assert that we get the namespace from parent's xmlns attribute
                assertEquals("http://test-namespace", result);
                
                // This test will fail with the mutant since it checks siblings instead of parents
                // and won't find the namespace declaration in the parent
            }

 @Test
            public void testGetNamespaceURI_ShouldTraverseParentWhenNodeHasNoNamespace() {
                // Create mock nodes
                Node childNode = mock(Node.class);
                Node parentNode = mock(Node.class);
                
                // Set up behavior - child has no namespace, parent does
                when(childNode.getNamespaceURI()).thenReturn(null);
                when(parentNode.getNamespaceURI()).thenReturn("http://parent.namespace");
                when(childNode.getParentNode()).thenReturn(parentNode);
                
                // Create test object
                DOMNodePointer pointer = new DOMNodePointer(childNode, null);
                
                // Test - should get namespace from parent
                assertEquals("http://parent.namespace", pointer.getNamespaceURI());
                
                // Verify parent node was accessed
                verify(childNode).getParentNode();
            }

 @Test
            public void testGetNamespaceURI_ShouldReturnDirectNamespaceWhenPresent() {
                Node node = mock(Node.class);
                when(node.getNamespaceURI()).thenReturn("http://direct.namespace");
                
                DOMNodePointer pointer = new DOMNodePointer(node, null);
                
                assertEquals("http://direct.namespace", pointer.getNamespaceURI());
                
                // Verify no parent access occurred
                verify(node, never()).getParentNode();
            }

 @Test
            public void testGetNamespaceURI_ShouldReturnNullForRootNodeWithNoNamespace() {
                Node rootNode = mock(Node.class);
                when(rootNode.getNamespaceURI()).thenReturn(null);
                when(rootNode.getParentNode()).thenReturn(null);
                
                DOMNodePointer pointer = new DOMNodePointer(rootNode, null);
                
                assertNull(pointer.getNamespaceURI());
            }

 @Test
        public void testGetNamespaceURI_ShouldFindNamespaceInParentNode2() throws Exception {
            // Create a DOM structure with namespace in parent node
            Document doc = mock(Document.class);
            Element root = mock(Element.class);
            Element child = mock(Element.class);
            
            // Setup document structure
            when(doc.getDocumentElement()).thenReturn(root);
            when(child.getParentNode()).thenReturn(root);
            
            // Setup namespace attribute in root
            Attr namespaceAttr = mock(Attr.class);
            when(namespaceAttr.getValue()).thenReturn("http://test.com/ns");
            when(root.getAttributeNode("xmlns:test")).thenReturn(namespaceAttr);
            
            // Setup node types
            when(root.getNodeType()).thenReturn(Node.ELEMENT_NODE);
            when(child.getNodeType()).thenReturn(Node.ELEMENT_NODE);
            
            // Create pointer with child node
            DOMNodePointer pointer = new DOMNodePointer(child, Locale.ENGLISH);
            
            // Test - should find namespace in parent
            String result = pointer.getNamespaceURI("test");
            
            // Verify
            assertEquals("http://test.com/ns", result);
            
            // Also verify we tried to get parent node (would fail with mutation)
            verify(child, atLeastOnce()).getParentNode();
        }

 @Test
        public void testGetNamespaceURI_ShouldFindNamespaceInParentNode3() throws Exception {
            // Create a child element without namespace
            Element childElement = mock(Element.class);
            when(childElement.getNamespaceURI()).thenReturn(null);
            when(childElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
            
            // Create xmlns attribute in parent
            Attr xmlnsAttr = mock(Attr.class);
            when(xmlnsAttr.getValue()).thenReturn("http://parent-namespace");
            
            // Create parent element with namespace
            Element parentElement = mock(Element.class);
            when(parentElement.getAttributeNode("xmlns")).thenReturn(xmlnsAttr);
            when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
            
            // Set up parent-child relationship
            when(childElement.getParentNode()).thenReturn(parentElement);
            
            // Test the method
            String result = DOMNodePointer.getNamespaceURI(childElement);
            
            // Verify it found the parent's namespace
            assertEquals("http://parent-namespace", result);
            
            // Verify parent node was accessed (would fail for mutant)
            verify(childElement).getParentNode();
        }

 @Test
           public void testGetNamespaceURI_CommentNode() {
               // Create a mock Comment node
               Comment commentNode = mock(Comment.class);
               when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
               
               // Create the DOMNodePointer instance with the comment node
               DOMNodePointer pointer = new DOMNodePointer(commentNode, null);
               
               // The original method should handle comment nodes specially
               // (likely returning null or empty string, but depends on implementation)
               // The mutant will skip this special handling
               
               // Call the method and verify behavior
               String result = pointer.getNamespaceURI();
               
               // Assert that comment nodes are handled properly
               // Since we don't know the exact expected behavior, we'll assume it should return null
               // for comment nodes (common behavior for namespace URIs of comment nodes)
               assertNull("Comment nodes should return null namespace URI", result);
               
               // Verify the node type was checked (would fail for mutant)
               verify(commentNode).getNodeType();
           }

 @Test
       public void testGetNamespaceURIWithCommentNode() {
           // Create mock comment node with namespace attributes
           Node commentNode = mock(Node.class);
           when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
           
           // Create mock parent element with namespace declaration
           Element parentElement = mock(Element.class);
           Attr namespaceAttr = mock(Attr.class);
           when(namespaceAttr.getValue()).thenReturn("http://test.com");
           
           // Setup behavior
           when(commentNode.getParentNode()).thenReturn(parentElement);
           when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
           when(parentElement.getAttributeNode("xmlns")).thenReturn(namespaceAttr);
           
           // Call the method - should process comment node and find namespace from parent
           String result = DOMNodePointer.getNamespaceURI(commentNode);
           
           // Verify the method properly handled the comment node by checking parent's namespace
           assertEquals("http://test.com", result);
           
           // Verify the comment node type was checked (would fail for mutant)
           verify(commentNode).getNodeType();
       }

 @Test
      public void testGetNamespaceURI_WithCommentNode_ShouldSkipProcessing() throws Exception {
          // Create a mock document structure with a comment node containing xmlns attribute
          Document doc = mock(Document.class);
          Element rootElement = mock(Element.class);
          Comment commentNode = mock(Comment.class);
          Node parentNode = mock(Node.class);
          
          // Setup behavior
          when(doc.getDocumentElement()).thenReturn(rootElement);
          when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
          when(commentNode.getParentNode()).thenReturn(parentNode);
          when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
          
          // Create attribute that should be found if comment nodes are processed
          Attr xmlnsAttr = mock(Attr.class);
          when(xmlnsAttr.getValue()).thenReturn("http://test.com");
          when(rootElement.getAttributeNode("xmlns:test")).thenReturn(xmlnsAttr);
          
          // Create the DOMNodePointer with comment node
          DOMNodePointer pointer = new DOMNodePointer(commentNode, Locale.ENGLISH);
          
          // Test - should skip comment node and find namespace from parent
          String result = pointer.getNamespaceURI("test");
          
          // Verify it got the namespace from parent element, not comment node
          assertEquals("http://test.com", result);
      }

 @Test
      public void testGetNamespaceURIWithCommentNode1() {
          // Create a mock Comment node
          Comment commentNode = mock(Comment.class);
          when(commentNode.getData()).thenReturn("some comment data");
          when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
          
          // Create a DOMNodePointer instance with the mock node
          DOMNodePointer pointer = new DOMNodePointer(commentNode, null);
          
          // The mutation would cause null to be used instead of comment data,
          // so we test that the method properly handles comment data
          String result = pointer.getNamespaceURI();
          
          // Verify the method interacted with the comment node as expected
          verify(commentNode).getData();
          
          // The actual assertion depends on the expected behavior with comment nodes,
          // but we know the mutation would skip processing the comment data
          // If the original method uses the comment data in namespace resolution,
          // this test would fail when the mutation is present
          assertNotNull("Namespace URI should not be null for comment node", result);
      }

 @Test
  public void testGetNamespaceURIWithCommentNode2() throws Exception {
      // Setup test data
      String testCommentData = "test-comment-data";
      String testPrefix = "test-prefix";
      String expectedNamespace = "http://test-namespace";
      
      // Create mock Comment node
      Comment commentNode = mock(Comment.class);
      when(commentNode.getData()).thenReturn(testCommentData);
      when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
      
      // Create mock Element node (parent) with namespace declaration
      Element elementNode = mock(Element.class);
      Attr namespaceAttr = mock(Attr.class);
      when(namespaceAttr.getValue()).thenReturn(expectedNamespace);
      when(elementNode.getAttributeNode("xmlns:" + testPrefix)).thenReturn(namespaceAttr);
      when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
      
      // Set up node hierarchy
      when(commentNode.getParentNode()).thenReturn(elementNode);
      
      // Create DOMNodePointer instance
      DOMNodePointer pointer = new DOMNodePointer(commentNode, Locale.ENGLISH);
      
      // Test - should use comment data in namespace resolution
      String result = pointer.getNamespaceURI(testPrefix);
      
      // Verify
      assertEquals("Namespace URI should match expected value", 
                   expectedNamespace, result);
      verify(commentNode).getData(); // Ensure comment data was accessed
  }

 @Test
  public void testGetNamespaceURI_WithCommentNode() {
      // Create a mock Comment node
      Comment commentNode = mock(Comment.class);
      when(commentNode.getData()).thenReturn("some comment data");
      
      // Create a mock Element node for parent
      Element parentElement = mock(Element.class);
      when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
      when(parentElement.getNamespaceURI()).thenReturn(null);
      
      // Set up parent-child relationship
      when(commentNode.getParentNode()).thenReturn(parentElement);
      
      // Create the DOMNodePointer with the comment node
      DOMNodePointer pointer = new DOMNodePointer(commentNode, Locale.ENGLISH);
      
      // Test the method
      String result = pointer.getNamespaceURI();
      
      // Verify behavior
      // The original code would process the comment node properly
      // The mutant would set text to null, potentially causing issues
      // We verify the method doesn't throw exceptions and handles comment nodes
      assertNotNull(result); // or appropriate assertion based on expected behavior
      verify(commentNode, atLeastOnce()).getData(); // Verify interaction with comment node
  }

 @Test
     public void testGetNamespaceURIWithCommentNode3() {
         // Create a mock Comment node with specific content
         Comment comment = mock(Comment.class);
         when(comment.getData()).thenReturn("someNamespaceData");
         when(comment.getNodeType()).thenReturn(Node.COMMENT_NODE);
         
         // Create DOMNodePointer with the comment node
         DOMNodePointer pointer = new DOMNodePointer(comment, null);
         
         // The actual behavior should process the comment data
         // The mutation would ignore it and return different result
         String result = pointer.getNamespaceURI();
         
         // Verify the method processes the comment content
         // The exact assertion depends on how comment data affects namespace URI
         // Here we assume it should not be empty/null when comment has content
         assertNotNull("Namespace URI should not be null for comment with content", result);
         assertFalse("Namespace URI should not be empty for comment with content", result.isEmpty());
         
         // Alternatively, if we know the expected transformation of comment data:
         // String expected = processCommentData("someNamespaceData");
         // assertEquals(expected, result);
     }

 @Test
 public void testGetNamespaceURIWithCommentNode4() throws Exception {
     // Setup test data
     String prefix = "test";
     String expectedNamespace = "http://test.com/ns";
     
     // Create mock nodes
     Document mockDocument = mock(Document.class);
     Element mockElement = mock(Element.class);
     Comment mockComment = mock(Comment.class);
     Attr mockAttr = mock(Attr.class);
     
     // Configure mocks
     when(mockDocument.getDocumentElement()).thenReturn(mockElement);
     when(mockComment.getParentNode()).thenReturn(mockElement);
     when(mockElement.getParentNode()).thenReturn(mockDocument);
     when(mockElement.getAttributeNode("xmlns:" + prefix)).thenReturn(mockAttr);
     when(mockAttr.getValue()).thenReturn(expectedNamespace);
     
     // The key part - test comment node behavior
     when(mockComment.getNodeType()).thenReturn(Node.COMMENT_NODE);
     when(mockComment.getData()).thenReturn("Some namespace related comment");
     
     // Create test instance
     DOMNodePointer pointer = new DOMNodePointer(mockComment, Locale.ENGLISH);
     
     // Test
     String result = pointer.getNamespaceURI(prefix);
     
     // Verify
     assertEquals("Should return namespace from attribute", expectedNamespace, result);
     verify(mockComment).getData(); // Ensure comment data is actually read
 }

 @Test
 public void testGetNamespaceURI_CommentNode_ShouldReturnCommentData() throws Exception {
     // Create mock comment node with data
     Comment comment = mock(Comment.class);
     when(comment.getData()).thenReturn("This is a comment");
     when(comment.getNodeType()).thenReturn(Node.COMMENT_NODE);
     
     // Create mock parent element with namespace
     Element parentElement = mock(Element.class);
     when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
     when(parentElement.getNamespaceURI()).thenReturn("http://example.com");
     
     // Set parent-child relationship
     when(comment.getParentNode()).thenReturn(parentElement);
     
     // Create DOMNodePointer instance
     DOMNodePointer pointer = new DOMNodePointer(comment, Locale.ENGLISH);
     
     // Test - should return parent's namespace URI
     String result = pointer.getNamespaceURI();
     
     // Verify comment data was accessed (would fail with mutant)
     verify(comment).getData();
     
     // Assert correct namespace URI from parent
     assertEquals("http://example.com", result);
 }

}
