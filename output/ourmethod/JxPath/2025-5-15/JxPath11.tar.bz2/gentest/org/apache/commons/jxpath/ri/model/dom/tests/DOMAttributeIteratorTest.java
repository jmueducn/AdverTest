package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
 
public class DOMAttributeIteratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testTestAttr_ExactMatch_DifferentPrefix_DifferentNamespace_ReturnsFalse() {
                                                                                                                                                                            // Setup mock objects
                                                                                                                                                                            Attr attr = mock(Attr.class);
                                                                                                                                                                            QName name = mock(QName.class);
                                                                                                                                                                            NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                            DOMAttributeIterator iterator = mock(DOMAttributeIterator.class);
                                                                                                                                                                            
                                                                                                                                                                            // Mock behavior for attribute
                                                                                                                                                                            when(DOMNodePointer.getPrefix(attr)).thenReturn("pre1");
                                                                                                                                                                            when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                            
                                                                                                                                                                            // Mock behavior for name
                                                                                                                                                                            when(name.getName()).thenReturn("local");
                                                                                                                                                                            
                                                                                                                                                                            // Create test QName with different prefix
                                                                                                                                                                            QName testName = mock(QName.class);
                                                                                                                                                                            when(testName.getPrefix()).thenReturn("pre2");
                                                                                                                                                                            
                                                                                                                                                                            // Mock namespace resolution
                                                                                                                                                                            when(parent.getNamespaceURI("pre1")).thenReturn("http://namespace1");
                                                                                                                                                                            when(parent.getNamespaceURI("pre2")).thenReturn("http://namespace2");
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to test private method
                                                                                                                                                                            try {
                                                                                                                                                                                Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                                testAttrMethod.setAccessible(true);
                                                                                                                                                                                boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                                assertFalse(result);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to invoke testAttr method: " + e.getMessage());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                    public void testTestAttr_XmlnsPrefix_ReturnsFalse() throws Exception {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        
                                                                                                                                                                        // Create iterator instance
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                        
                                                                                                                                                                        // Set up mocks
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("xmlns");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("something");
                                                                                                                                                                        
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                        
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttr_WildcardMatch_EqualPrefix_ReturnsTrue() throws Exception {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        
                                                                                                                                                                        // Create iterator instance
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Set up mock behaviors
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("pre");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                        when(name.getName()).thenReturn("*");
                                                                                                                                                                        
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        when(testName.getPrefix()).thenReturn("pre");
                                                                                                                                                                        
                                                                                                                                                                        // Mock namespace resolution
                                                                                                                                                                        when(parent.getNamespaceURI("pre")).thenReturn("http://example.com");
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private testAttr method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                        
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttr_ExactMatch_EqualPrefix_ReturnsTrue() throws Exception {
                                                                                                                                                                        // Mock the attribute
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        
                                                                                                                                                                        // Mock the QName for the iterator
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        when(name.getName()).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        // Mock the parent NodePointer
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        
                                                                                                                                                                        // Create the iterator instance
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Set up attribute mocks
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("pre");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        // Create and mock the test QName
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        when(testName.getPrefix()).thenReturn("pre");
                                                                                                                                                                        when(testName.getName()).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private testAttr method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                        
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttr_ExactMatch_DifferentPrefix_SameNamespace_ReturnsTrue() throws Exception {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        
                                                                                                                                                                        // Create iterator with mocked parent and name
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Set up mock behaviors
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("pre1");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                        when(name.getName()).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        when(testName.getPrefix()).thenReturn("pre2");
                                                                                                                                                                        
                                                                                                                                                                        when(parent.getNamespaceURI("pre1")).thenReturn("http://same-namespace");
                                                                                                                                                                        when(parent.getNamespaceURI("pre2")).thenReturn("http://same-namespace");
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private testAttr method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                        
                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttr_NoMatch_ReturnsFalse() throws Exception {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Set up mock behavior
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("pre");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local1");
                                                                                                                                                                        when(name.getName()).thenReturn("local2");
                                                                                                                                                                        
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private testAttr method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                        
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttr_NullPrefix_NoNamespace_ReturnsTrue() throws Exception {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Set up mock behavior
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                        when(name.getName()).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        when(testName.getPrefix()).thenReturn(null);
                                                                                                                                                                        when(testName.getName()).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Test and verify
                                                                                                                                                                        assertTrue((Boolean) testAttrMethod.invoke(iterator, attr, testName));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttr_NullTestPrefix_NodePrefixNotNull_ReturnsFalse() throws Exception {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Setup mock behavior
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn("pre");
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                        when(name.getName()).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        when(testName.getPrefix()).thenReturn(null);
                                                                                                                                                                        when(testName.getName()).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private testAttr method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                        
                                                                                                                                                                        // Test and verify
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testTestAttr_TestPrefixNotNull_NodePrefixNull_ReturnsFalse() throws Exception {
                                                                                                                                                                        // Create mock objects
                                                                                                                                                                        Attr attr = mock(Attr.class);
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Setup mock behavior
                                                                                                                                                                        when(DOMNodePointer.getPrefix(attr)).thenReturn(null);
                                                                                                                                                                        when(DOMNodePointer.getLocalName(attr)).thenReturn("local");
                                                                                                                                                                        when(name.getName()).thenReturn("local");
                                                                                                                                                                        
                                                                                                                                                                        QName testName = mock(QName.class);
                                                                                                                                                                        when(testName.getPrefix()).thenReturn("pre");
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private testAttr method
                                                                                                                                                                        Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                                                        testAttrMethod.setAccessible(true);
                                                                                                                                                                        boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                                                        
                                                                                                                                                                        assertFalse(result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAttribute_WithNamespacePrefix_NamespaceFoundInResolver() throws Exception {
                                                                                                                                                                        // Setup
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                                                                                        Element element = mock(Element.class);
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        when(name.getPrefix()).thenReturn("test");
                                                                                                                                                                        when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                                                                                        when(nsr.getNamespaceURI("test")).thenReturn("http://test.com");
                                                                                                                                                                        when(name.getName()).thenReturn("attrName");
                                                                                                                                                                        
                                                                                                                                                                        Attr expectedAttr = mock(Attr.class);
                                                                                                                                                                        when(element.getAttributeNodeNS("http://test.com", "attrName")).thenReturn(expectedAttr);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                            "getAttribute", Element.class, QName.class);
                                                                                                                                                                        getAttributeMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Test
                                                                                                                                                                        Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                        
                                                                                                                                                                        // Verify
                                                                                                                                                                        assertEquals(expectedAttr, result);
                                                                                                                                                                        verify(element).getAttributeNodeNS("http://test.com", "attrName");
                                                                                                                                                                        verify(element, never()).getAttributeNode(anyString());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAttribute_WithNamespacePrefix_NamespaceFoundInParent() throws Exception {
                                                                                                                                                                        // Setup
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                                                                                        Element element = mock(Element.class);
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        when(name.getPrefix()).thenReturn("test");
                                                                                                                                                                        when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                                                                                        when(nsr.getNamespaceURI("test")).thenReturn(null);
                                                                                                                                                                        when(parent.getNamespaceURI("test")).thenReturn("http://parent.com");
                                                                                                                                                                        when(name.getName()).thenReturn("attrName");
                                                                                                                                                                        
                                                                                                                                                                        Attr expectedAttr = mock(Attr.class);
                                                                                                                                                                        when(element.getAttributeNodeNS("http://parent.com", "attrName")).thenReturn(expectedAttr);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                            "getAttribute", Element.class, QName.class);
                                                                                                                                                                        getAttributeMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Test
                                                                                                                                                                        Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                        
                                                                                                                                                                        // Verify
                                                                                                                                                                        assertEquals(expectedAttr, result);
                                                                                                                                                                        verify(element).getAttributeNodeNS("http://parent.com", "attrName");
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAttribute_WithNamespacePrefix_NoNamespaceFound() throws Exception {
                                                                                                                                                                        // Setup
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                                                                                        Element element = mock(Element.class);
                                                                                                                                                                        
                                                                                                                                                                        when(name.getPrefix()).thenReturn("test");
                                                                                                                                                                        when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                                                                                        when(nsr.getNamespaceURI("test")).thenReturn(null);
                                                                                                                                                                        when(parent.getNamespaceURI("test")).thenReturn(null);
                                                                                                                                                                        when(name.getName()).thenReturn("attrName");
                                                                                                                                                                        
                                                                                                                                                                        Attr expectedAttr = mock(Attr.class);
                                                                                                                                                                        when(element.getAttributeNode("attrName")).thenReturn(expectedAttr);
                                                                                                                                                                        
                                                                                                                                                                        // Create iterator instance
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                            "getAttribute", Element.class, QName.class);
                                                                                                                                                                        getAttributeMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Test
                                                                                                                                                                        Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                        
                                                                                                                                                                        // Verify
                                                                                                                                                                        assertEquals(expectedAttr, result);
                                                                                                                                                                        verify(element).getAttributeNode("attrName");
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetAttribute_WithNamespacePrefix_ParserDoesNotSupportNS() throws Exception {
                                                                                                                                                                        // Setup mocks
                                                                                                                                                                        QName name = mock(QName.class);
                                                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                        NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                                                                                        Element element = mock(Element.class);
                                                                                                                                                                        
                                                                                                                                                                        // Setup behavior
                                                                                                                                                                        when(name.getPrefix()).thenReturn("test");
                                                                                                                                                                        when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                                                                                        when(nsr.getNamespaceURI("test")).thenReturn("http://test.com");
                                                                                                                                                                        when(name.getName()).thenReturn("attrName");
                                                                                                                                                                        
                                                                                                                                                                        // Mock attribute node map
                                                                                                                                                                        NamedNodeMap nnm = mock(NamedNodeMap.class);
                                                                                                                                                                        when(element.getAttributes()).thenReturn(nnm);
                                                                                                                                                                        when(nnm.getLength()).thenReturn(2);
                                                                                                                                                                        
                                                                                                                                                                        Attr wrongAttr = mock(Attr.class);
                                                                                                                                                                        Attr correctAttr = mock(Attr.class);
                                                                                                                                                                        when(nnm.item(0)).thenReturn(wrongAttr);
                                                                                                                                                                        when(nnm.item(1)).thenReturn(correctAttr);
                                                                                                                                                                        
                                                                                                                                                                        // Create real iterator instance
                                                                                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to test private method if absolutely necessary
                                                                                                                                                                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                                                        getAttributeMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Test
                                                                                                                                                                        Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                        
                                                                                                                                                                        // Verify
                                                                                                                                                                        assertEquals(correctAttr, result);
                                                                                                                                                                        verify(element).getAttributeNodeNS("http://test.com", "attrName");
                                                                                                                                                                        verify(element).getAttributes();
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testGetAttribute_WithoutNamespacePrefix() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                    when(name.getPrefix()).thenReturn(null);
                                                                                                                                                                    when(name.getName()).thenReturn("simpleAttr");
                                                                                                                                                                    
                                                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                                                    Attr expectedAttr = mock(Attr.class);
                                                                                                                                                                    when(element.getAttributeNode("simpleAttr")).thenReturn(expectedAttr);
                                                                                                                                                                    
                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                    Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                        "getAttribute", Element.class, QName.class);
                                                                                                                                                                    getAttributeMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals(expectedAttr, result);
                                                                                                                                                                    verify(element).getAttributeNode("simpleAttr");
                                                                                                                                                                    verify(element, never()).getAttributeNodeNS(anyString(), anyString());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetAttribute_AttributeNotFound() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    QName name = mock(QName.class);
                                                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                                                    NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, name);
                                                                                                                                                                    
                                                                                                                                                                    when(name.getPrefix()).thenReturn(null);
                                                                                                                                                                    when(name.getName()).thenReturn("nonExisting");
                                                                                                                                                                    when(element.getAttributeNode("nonExisting")).thenReturn(null);
                                                                                                                                                                    
                                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                                    Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                                                                        "getAttribute", Element.class, QName.class);
                                                                                                                                                                    getAttributeMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetAttribute_NullElement() throws Exception {
                                                                                                                                                                    NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                    QName name = new QName("test");
                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                                                                                    
                                                                                                                                                                    // Get the private method via reflection
                                                                                                                                                                    Method getAttributeMethod = DOMAttributeIterator.class
                                                                                                                                                                            .getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                                                    getAttributeMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Invoke the method with null element
                                                                                                                                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, (Element) null, name);
                                                                                                                                                                    
                                                                                                                                                                    // Verify the result is null when passing null element
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetAttribute_NullQName() throws Exception {
                                                                                                                                                                    NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                    Element element = mock(Element.class);
                                                                                                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(parentPointer, new QName("test"));
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                    Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    method.invoke(iterator, element, null);
                                                                                                                                                                }

    @Test
                                                                                                                            public void testTestAttr_XmlnsLocalName_ReturnsFalse() {
                                                                                                                                // Create mock objects
                                                                                                                                Attr attr = mock(Attr.class);
                                                                                                                                DOMAttributeIterator iterator = mock(DOMAttributeIterator.class);
                                                                                                                                NodePointer parent = mock(NodePointer.class);
                                                                                                                                
                                                                                                                                // Mock behavior using regular mocks instead of static mocking
                                                                                                                                when(attr.getPrefix()).thenReturn(null);
                                                                                                                                when(attr.getLocalName()).thenReturn("xmlns");
                                                                                                                                
                                                                                                                                QName testName = new QName("test");
                                                                                                                                
                                                                                                                                // Use reflection to test private method
                                                                                                                                try {
                                                                                                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                                                                                                    testAttrMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    boolean result = (boolean) testAttrMethod.invoke(iterator, attr, testName);
                                                                                                                                    assertFalse(result);
                                                                                                                                } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                                                                                                    fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                               public void testGetAttributeWithPrefixShouldAttemptNamespaceResolution() throws Exception {
                                                                                                                   // Setup test data
                                                                                                                   String namespaceURI = "http://example.com";
                                                                                                                   String localName = "localName";
                                                                                                                   String prefix = "prefix";
                                                                                                                   QName nameWithPrefix = new QName(namespaceURI, localName);
                                                                                                                   // Set prefix using reflection since QName doesn't have a direct setter
                                                                                                                   Field prefixField = QName.class.getDeclaredField("prefix");
                                                                                                                   prefixField.setAccessible(true);
                                                                                                                   prefixField.set(nameWithPrefix, prefix);
                                                                                                                   
                                                                                                                   Element mockElement = mock(Element.class);
                                                                                                                   NodePointer mockParent = mock(NodePointer.class);
                                                                                                                   NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                                                                   
                                                                                                                   // Configure mocks
                                                                                                                   when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                                                                   when(mockNsResolver.getNamespaceURI("prefix")).thenReturn("http://example.com");
                                                                                                                   when(mockElement.getAttributeNodeNS("http://example.com", "localName")).thenReturn(null);
                                                                                                                   
                                                                                                                   // Create test instance
                                                                                                                   DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, nameWithPrefix);
                                                                                                                   
                                                                                                                   // Use reflection to access private method
                                                                                                                   Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                       "getAttribute", Element.class, QName.class);
                                                                                                                   getAttributeMethod.setAccessible(true);
                                                                                                                   
                                                                                                                   // This is the critical test - with the mutant, namespace resolution would be skipped
                                                                                                                   // because the condition is reversed
                                                                                                                   Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, nameWithPrefix);
                                                                                                                   
                                                                                                                   // Verify namespace resolution was attempted
                                                                                                                   verify(mockNsResolver).getNamespaceURI("prefix");
                                                                                                                   verify(mockElement).getAttributeNodeNS("http://example.com", "localName");
                                                                                                                   
                                                                                                                   // Also verify fallback behavior
                                                                                                                   verify(mockElement).getAttributeNode("localName");
                                                                                                               }

    @Test
                                                                                                           public void testGetAttributeWithNamespaceResolver() throws Exception {
                                                                                                               // Setup test data
                                                                                                               String prefix = "test";
                                                                                                               String namespaceUri = "http://example.com/ns";
                                                                                                               String localName = "attr";
                                                                                                               String qName = prefix + ":" + localName;
                                                                                                               
                                                                                                               // Mock the dependencies
                                                                                                               Element element = mock(Element.class);
                                                                                                               QName name = mock(QName.class);
                                                                                                               NodePointer parent = mock(NodePointer.class);
                                                                                                               NamespaceResolver nsResolver = mock(NamespaceResolver.class);
                                                                                                               Attr expectedAttr = mock(Attr.class);
                                                                                                               
                                                                                                               // Configure mocks
                                                                                                               when(name.getPrefix()).thenReturn(prefix);
                                                                                                               when(name.getName()).thenReturn(qName);
                                                                                                               when(parent.getNamespaceResolver()).thenReturn(nsResolver);
                                                                                                               when(nsResolver.getNamespaceURI(prefix)).thenReturn(namespaceUri);
                                                                                                               when(element.getAttributeNodeNS(namespaceUri, qName)).thenReturn(expectedAttr);
                                                                                                               
                                                                                                               // Create test instance (using constructor we saw in class info)
                                                                                                               DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                               
                                                                                                               // Use reflection to access private method since it's private
                                                                                                               Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                                   "getAttribute", Element.class, QName.class);
                                                                                                               getAttributeMethod.setAccessible(true);
                                                                                                               
                                                                                                               // Invoke the method
                                                                                                               Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                                               
                                                                                                               // Verify the behavior
                                                                                                               assertEquals(expectedAttr, result);
                                                                                                               verify(parent).getNamespaceResolver();  // This is the key check for the mutant
                                                                                                               verify(nsResolver).getNamespaceURI(prefix);
                                                                                                               verify(element).getAttributeNodeNS(namespaceUri, qName);
                                                                                                           }

    @Test
                                                                                                          public void testGetAttribute_NamespaceResolverNull_ShouldFallbackToSimpleLookup() {
                                                                                                              // Setup test data
                                                                                                              QName testQName = new QName("testPrefix", "localName");
                                                                                                              Element mockElement = mock(Element.class);
                                                                                                              NodePointer mockParent = mock(NodePointer.class);
                                                                                                              
                                                                                                              // Mock behavior
                                                                                                              when(testQName.getPrefix()).thenReturn("testPrefix");
                                                                                                              when(mockParent.getNamespaceResolver()).thenReturn(null);
                                                                                                              when(mockParent.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                                                              when(mockElement.getAttributeNode("localName")).thenReturn(mock(Attr.class));
                                                                                                              
                                                                                                              // Create test instance
                                                                                                              DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                                                              
                                                                                                              // Use reflection to access private method
                                                                                                              try {
                                                                                                                  Method getAttribute = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                                                  getAttribute.setAccessible(true);
                                                                                                                  Attr result = (Attr) getAttribute.invoke(iterator, mockElement, testQName);
                                                                                                                  
                                                                                                                  // Verify the correct path was taken
                                                                                                                  verify(mockElement, never()).getAttributeNodeNS(anyString(), anyString());
                                                                                                                  verify(mockElement).getAttributeNode("localName");
                                                                                                                  assertNotNull("Should return attribute from simple lookup", result);
                                                                                                              } catch (Exception e) {
                                                                                                                  fail("Reflection failed: " + e.getMessage());
                                                                                                              }
                                                                                                          }

    @Test
                                                                                                    public void testGetAttribute_NamespaceResolution_NullTestNS() throws Exception {
                                                                                                        // Setup test data
                                                                                                        QName testQName = new QName("http://test.ns", "test");
                                                                                                        Element mockElement = mock(Element.class);
                                                                                                        NodePointer mockParent = mock(NodePointer.class);
                                                                                                        NamespaceResolver mockNsr = mock(NamespaceResolver.class);
                                                                                                        
                                                                                                        // Mock behavior
                                                                                                        when(mockParent.getNamespaceResolver()).thenReturn(mockNsr);
                                                                                                        when(mockNsr.getNamespaceURI("prefix")).thenReturn(null);
                                                                                                        when(mockParent.getNamespaceURI("prefix")).thenReturn("http://correct.ns");
                                                                                                        
                                                                                                        // Create test instance (using reflection since constructor may not be accessible)
                                                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                                                        
                                                                                                        // Use reflection to access private method
                                                                                                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                            "getAttribute", Element.class, QName.class);
                                                                                                        getAttributeMethod.setAccessible(true);
                                                                                                        
                                                                                                        // The test - we expect the method to use the parent's namespace URI when nsr returns null
                                                                                                        // The mutant would skip getting from parent when testNS is null
                                                                                                        Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                                                                        
                                                                                                        // Verify the parent's namespace URI was queried (wouldn't happen with the mutant)
                                                                                                        verify(mockParent).getNamespaceURI("prefix");
                                                                                                        
                                                                                                        // Additional verification - the method should proceed with namespace-aware lookup
                                                                                                        verify(mockElement).getAttributeNodeNS("http://correct.ns", "test");
                                                                                                    }

    @Test
                                                                                               public void testGetAttributeWithNamespaceShouldUseNamespaceLookup() throws Exception {
                                                                                                   // Setup test data
                                                                                                   QName name = mock(QName.class);
                                                                                                   when(name.getPrefix()).thenReturn("testPrefix");
                                                                                                   when(name.getName()).thenReturn("testName");
                                                                                                   
                                                                                                   Element element = mock(Element.class);
                                                                                                   NodePointer parent = mock(NodePointer.class);
                                                                                                   NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                                   
                                                                                                   // Mock namespace resolution
                                                                                                   when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                                   when(nsr.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                                                                                   when(parent.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                                                   
                                                                                                   // Mock attribute lookup
                                                                                                   Attr expectedAttr = mock(Attr.class);
                                                                                                   when(element.getAttributeNodeNS("testNS", "testName")).thenReturn(expectedAttr);
                                                                                                   
                                                                                                   // Create test instance
                                                                                                   DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                                   
                                                                                                   // Use reflection to call private method
                                                                                                   Method method = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                       "getAttribute", Element.class, QName.class);
                                                                                                   method.setAccessible(true);
                                                                                                   Attr result = (Attr) method.invoke(iterator, element, name);
                                                                                                   
                                                                                                   // Verify the correct path was taken
                                                                                                   assertEquals(expectedAttr, result);
                                                                                                   verify(element).getAttributeNodeNS("testNS", "testName");
                                                                                                   // The mutant would skip this verification and go straight to getAttributeNode
                                                                                               }

    @Test
                                                                                          public void testGetAttributeWithNamespacedAttribute() throws Exception {
                                                                                              // Setup test data
                                                                                              String namespaceURI = "http://example.com/ns";
                                                                                              String prefix = "test";
                                                                                              String localName = "attr";
                                                                                              String qualifiedName = prefix + ":" + localName;
                                                                                              
                                                                                              // Mock the dependencies
                                                                                              Element element = mock(Element.class);
                                                                                              QName name = mock(QName.class);
                                                                                              NodePointer parent = mock(NodePointer.class);
                                                                                              NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                                              
                                                                                              // Create test attribute (namespaced)
                                                                                              Attr namespacedAttr = mock(Attr.class);
                                                                                              when(namespacedAttr.getNamespaceURI()).thenReturn(namespaceURI);
                                                                                              when(namespacedAttr.getLocalName()).thenReturn(localName);
                                                                                              
                                                                                              // Create test attribute (non-namespaced)
                                                                                              Attr nonNamespacedAttr = mock(Attr.class);
                                                                                              when(nonNamespacedAttr.getNamespaceURI()).thenReturn(null);
                                                                                              when(nonNamespacedAttr.getName()).thenReturn(localName);
                                                                                              
                                                                                              // Setup mock behavior
                                                                                              when(name.getPrefix()).thenReturn(prefix);
                                                                                              when(name.getName()).thenReturn(localName);
                                                                                              when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                                              when(nsr.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                                                                                              when(element.getAttributeNodeNS(namespaceURI, localName)).thenReturn(namespacedAttr);
                                                                                              when(element.getAttributeNode(localName)).thenReturn(nonNamespacedAttr);
                                                                                              
                                                                                              // Create instance
                                                                                              DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                                              
                                                                                              // Use reflection to access private method
                                                                                              Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                                  "getAttribute", Element.class, QName.class);
                                                                                              getAttributeMethod.setAccessible(true);
                                                                                              Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                                              
                                                                                              // Verify the correct namespaced attribute was returned
                                                                                              assertNotNull("Should return an attribute", result);
                                                                                              assertEquals("Should return the namespaced attribute", 
                                                                                                          namespaceURI, result.getNamespaceURI());
                                                                                              assertEquals("Should return the correct local name", 
                                                                                                          localName, result.getLocalName());
                                                                                              
                                                                                              // The mutant would return nonNamespacedAttr instead
                                                                                          }

    @Test
                                                                                     public void testGetAttributeWithExistingNamespacedAttr() {
                                                                                         // Setup test data
                                                                                         QName testQName = new QName("http://test.ns", "testAttr");
                                                                                         Element mockElement = mock(Element.class);
                                                                                         NodePointer mockParent = mock(NodePointer.class);
                                                                                         NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                                         Attr mockAttr = mock(Attr.class);
                                                                                         
                                                                                         // Mock behavior
                                                                                         when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                                         when(mockNsResolver.getNamespaceURI("prefix")).thenReturn("http://test.ns");
                                                                                         when(mockElement.getAttributeNodeNS("http://test.ns", "testAttr")).thenReturn(mockAttr);
                                                                                         
                                                                                         // Create test instance
                                                                                         DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                                         
                                                                                         // Use reflection to access private method since we're testing it directly
                                                                                         try {
                                                                                             Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                                             method.setAccessible(true);
                                                                                             Attr result = (Attr) method.invoke(iterator, mockElement, testQName);
                                                                                             
                                                                                             // Assertions - original would return mockAttr, mutant would return null
                                                                                             assertNotNull("Should return the found attribute", result);
                                                                                             assertEquals(mockAttr, result);
                                                                                         } catch (Exception e) {
                                                                                             fail("Reflection failed: " + e.getMessage());
                                                                                         }
                                                                                     }

    @Test
                                                                                public void testGetAttribute_ShouldNotThrowExceptionWhenAccessingAttributes() {
                                                                                    // Setup test data
                                                                                    QName testQName = new QName("test");
                                                                                    Element mockElement = mock(Element.class);
                                                                                    NodePointer mockParent = mock(NodePointer.class);
                                                                                    NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                                    
                                                                                    // Create a mock NamedNodeMap with 1 attribute
                                                                                    NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                    when(mockAttributes.getLength()).thenReturn(1);
                                                                                    Attr mockAttr = mock(Attr.class);
                                                                                    when(mockAttributes.item(0)).thenReturn(mockAttr);
                                                                                    
                                                                                    // Configure mocks
                                                                                    when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                                    when(mockNsResolver.getNamespaceURI("test")).thenReturn("testNS");
                                                                                    when(mockElement.getAttributeNodeNS("testNS", "test")).thenReturn(null);
                                                                                    when(mockElement.getAttributes()).thenReturn(mockAttributes);
                                                                                    
                                                                                    // Create test instance
                                                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                                    
                                                                                    try {
                                                                                        // Use reflection to access private method
                                                                                        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                            "getAttribute", Element.class, QName.class);
                                                                                        getAttributeMethod.setAccessible(true);
                                                                                        
                                                                                        // This should not throw an exception with original code
                                                                                        // Mutant would throw IndexOutOfBoundsException on the extra loop iteration
                                                                                        Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                                                        
                                                                                        // Verify behavior
                                                                                        assertNull(result); // In our setup, no matching attribute is found
                                                                                    } catch (Exception e) {
                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                           public void testGetAttributeWithPrefixShouldAttemptNamespaceResolution1() throws Exception {
                                                                               // Setup test data
                                                                               String namespaceURI = "http://example.com";
                                                                               String localName = "localName";
                                                                               String prefix = "prefix";
                                                                               QName nameWithPrefix = new QName(namespaceURI, localName);
                                                                               
                                                                               // Mock setup
                                                                               Element mockElement = mock(Element.class);
                                                                               NodePointer mockParent = mock(NodePointer.class);
                                                                               NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                               
                                                                               // Mock behavior
                                                                               when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                               when(mockNsResolver.getNamespaceURI(prefix)).thenReturn(namespaceURI);
                                                                               when(mockElement.getAttributeNodeNS(namespaceURI, localName)).thenReturn(mock(Attr.class));
                                                                               
                                                                               // Create test instance
                                                                               DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, nameWithPrefix);
                                                                               
                                                                               // Use reflection to access private method
                                                                               Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                                   "getAttribute", Element.class, QName.class);
                                                                               getAttributeMethod.setAccessible(true);
                                                                               
                                                                               // Call method under test
                                                                               Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, nameWithPrefix);
                                                                               
                                                                               // Verify behavior
                                                                               verify(mockParent).getNamespaceResolver();
                                                                               verify(mockNsResolver).getNamespaceURI(prefix);
                                                                               verify(mockElement).getAttributeNodeNS(namespaceURI, localName);
                                                                               assertNotNull("Should find namespaced attribute", result);
                                                                           }

    @Test
                                                                       public void testGetAttributeWithNamespaceResolver1() throws Exception {
                                                                           // Setup test data
                                                                           String prefix = "test";
                                                                           String namespaceUri = "http://example.com/ns";
                                                                           String localName = "attr";
                                                                           String qName = prefix + ":" + localName;
                                                                           
                                                                           // Create mock objects
                                                                           Element mockElement = mock(Element.class);
                                                                           QName mockQName = mock(QName.class);
                                                                           NodePointer mockParent = mock(NodePointer.class);
                                                                           NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                                           Attr mockAttr = mock(Attr.class);
                                                                           
                                                                           // Configure mocks
                                                                           when(mockQName.getPrefix()).thenReturn(prefix);
                                                                           when(mockQName.getName()).thenReturn(localName);
                                                                           when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                                           when(mockNsResolver.getNamespaceURI(prefix)).thenReturn(namespaceUri);
                                                                           when(mockElement.getAttributeNodeNS(namespaceUri, localName)).thenReturn(mockAttr);
                                                                           
                                                                           // Create test instance (using constructor we saw in class definition)
                                                                           DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, mockQName);
                                                                           
                                                                           // Use reflection to access private method since it's not exposed publicly
                                                                           Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                               "getAttribute", Element.class, QName.class);
                                                                           getAttributeMethod.setAccessible(true);
                                                                           
                                                                           // Invoke the method
                                                                           Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, mockQName);
                                                                           
                                                                           // Verify behavior
                                                                           assertEquals(mockAttr, result);
                                                                           verify(mockParent).getNamespaceResolver();  // This will fail with the mutant
                                                                           verify(mockNsResolver).getNamespaceURI(prefix);
                                                                           verify(mockElement).getAttributeNodeNS(namespaceUri, localName);
                                                                       }

    @Test
                                                                      public void testGetAttribute_WithNullNamespaceResolver_ShouldFallbackToLocalName() throws Exception {
                                                                          // Setup test data
                                                                          QName testQName = new QName("testPrefix", "localName");
                                                                          Element mockElement = mock(Element.class);
                                                                          NodePointer mockParent = mock(NodePointer.class);
                                                                          NamespaceResolver nullNsResolver = null;
                                                                          Attr expectedAttr = mock(Attr.class);
                                                                          
                                                                          // Mock behavior
                                                                          when(testQName.getPrefix()).thenReturn("testPrefix");
                                                                          when(mockParent.getNamespaceResolver()).thenReturn(nullNsResolver);
                                                                          when(mockParent.getNamespaceURI("testPrefix")).thenReturn(null);
                                                                          when(mockElement.getAttributeNode("localName")).thenReturn(expectedAttr);
                                                                          
                                                                          // Create test instance (using reflection since constructor may be private)
                                                                          DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                                          Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                                          getAttributeMethod.setAccessible(true);
                                                                          
                                                                          // Execute and verify
                                                                          Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                                          assertSame("Should return attribute matched by local name when namespace resolver is null", 
                                                                                    expectedAttr, result);
                                                                          
                                                                          // Verify interactions
                                                                          verify(mockElement, never()).getAttributeNodeNS(anyString(), anyString());
                                                                          verify(mockElement).getAttributeNode("localName");
                                                                      }

    @Test
                                                                    public void testGetAttribute_NamespaceResolution_ShouldKeepOriginalNamespace() throws Exception {
                                                                        // Setup test data
                                                                        QName name = new QName("http://correct-namespace", "localName");
                                                                        // Set prefix separately if needed (depends on QName implementation)
                                                                        Element element = mock(Element.class);
                                                                        NodePointer parent = mock(NodePointer.class);
                                                                        NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                        
                                                                        // Mock behavior
                                                                        when(name.getPrefix()).thenReturn("prefix");
                                                                        when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                        when(nsr.getNamespaceURI("prefix")).thenReturn("http://correct-namespace");
                                                                        // Parent returns different namespace to detect the mutation
                                                                        when(parent.getNamespaceURI("prefix")).thenReturn("http://wrong-namespace");
                                                                        
                                                                        // Mock element behavior
                                                                        Attr expectedAttr = mock(Attr.class);
                                                                        when(element.getAttributeNodeNS("http://correct-namespace", "localName"))
                                                                            .thenReturn(expectedAttr);
                                                                        
                                                                        // Create test instance (assuming constructor sets parent and name)
                                                                        DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                        
                                                                        // Use reflection to access private method since it's not exposed
                                                                        Method getAttribute = DOMAttributeIterator.class.getDeclaredMethod(
                                                                            "getAttribute", Element.class, QName.class);
                                                                        getAttribute.setAccessible(true);
                                                                        
                                                                        // Execute and verify
                                                                        Attr result = (Attr) getAttribute.invoke(iterator, element, name);
                                                                        assertEquals(expectedAttr, result);
                                                                        
                                                                        // The test will fail with the mutant because:
                                                                        // Original: keeps "http://correct-namespace" from resolver
                                                                        // Mutant: replaces it with "http://wrong-namespace" from parent
                                                                        // Thus getAttributeNodeNS will return null and test will fail
                                                                    }

    @Test
                                                               public void testGetAttributeWithNamespaceShouldUseNamespaceLookup1() throws Exception {
                                                                   // Setup test data
                                                                   QName name = new QName("http://example.com", "local");
                                                                   Element element = mock(Element.class);
                                                                   NodePointer parent = mock(NodePointer.class);
                                                                   NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                                   
                                                                   // Mock behavior
                                                                   when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                                   when(nsr.getNamespaceURI("prefix")).thenReturn("http://example.com");
                                                                   when(parent.getNamespaceURI("prefix")).thenReturn("http://example.com");
                                                                   
                                                                   // Create test attribute with namespace
                                                                   Attr namespacedAttr = mock(Attr.class);
                                                                   when(element.getAttributeNodeNS("http://example.com", "local")).thenReturn(namespacedAttr);
                                                                   
                                                                   // Create test object
                                                                   DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                   
                                                                   // Use reflection to access private method
                                                                   Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                       "getAttribute", Element.class, QName.class);
                                                                   getAttributeMethod.setAccessible(true);
                                                                   
                                                                   // Call method under test - should use namespace-aware path
                                                                   Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                   
                                                                   // Verify the correct path was taken
                                                                   assertSame(namespacedAttr, result);
                                                                   verify(element).getAttributeNodeNS("http://example.com", "local");
                                                                   verify(element, never()).getAttributeNode("local");
                                                               }

    @Test
                                                               public void testGetAttributeWithoutNamespaceShouldUseSimpleLookup() throws Exception {
                                                                   // Setup test data
                                                                   QName name = new QName(null, "local");
                                                                   Element element = mock(Element.class);
                                                                   NodePointer parent = mock(NodePointer.class);
                                                                   
                                                                   // Mock behavior - no prefix case
                                                                   when(name.getPrefix()).thenReturn(null);
                                                                   
                                                                   // Create test attribute without namespace
                                                                   Attr simpleAttr = mock(Attr.class);
                                                                   when(element.getAttributeNode("local")).thenReturn(simpleAttr);
                                                                   
                                                                   // Create test object
                                                                   DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                                   
                                                                   // Use reflection to access private method
                                                                   Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                       "getAttribute", Element.class, QName.class);
                                                                   getAttributeMethod.setAccessible(true);
                                                                   
                                                                   // Call method under test - should use simple path
                                                                   Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                                   
                                                                   // Verify the correct path was taken
                                                                   assertSame(simpleAttr, result);
                                                                   verify(element).getAttributeNode("local");
                                                                   verify(element, never()).getAttributeNodeNS(anyString(), anyString());
                                                               }

    @Test
                                                          public void testGetAttributeWithNamespacedAttributeShouldFindNamespacedAttr() throws Exception {
                                                              // Setup test data
                                                              QName name = mock(QName.class);
                                                              when(name.getPrefix()).thenReturn("test");
                                                              when(name.getName()).thenReturn("attrName");
                                                              
                                                              NamespaceResolver nsr = mock(NamespaceResolver.class);
                                                              when(nsr.getNamespaceURI("test")).thenReturn("http://test.ns");
                                                              
                                                              NodePointer parent = mock(NodePointer.class);
                                                              when(parent.getNamespaceResolver()).thenReturn(nsr);
                                                              when(parent.getNamespaceURI("test")).thenReturn(null);
                                                              
                                                              // Create two attributes - one with namespace, one without
                                                              Attr namespacedAttr = mock(Attr.class);
                                                              Attr nonNamespacedAttr = mock(Attr.class);
                                                              
                                                              Element element = mock(Element.class);
                                                              when(element.getAttributeNodeNS("http://test.ns", "attrName")).thenReturn(namespacedAttr);
                                                              when(element.getAttributeNode("attrName")).thenReturn(nonNamespacedAttr);
                                                              
                                                              NamedNodeMap attributesMap = mock(NamedNodeMap.class);
                                                              when(element.getAttributes()).thenReturn(attributesMap);
                                                              when(attributesMap.getLength()).thenReturn(0); // No fallback needed
                                                              
                                                              // Create test instance
                                                              DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                                              
                                                              // Use reflection to access private method
                                                              Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                                  "getAttribute", Element.class, QName.class);
                                                              getAttributeMethod.setAccessible(true);
                                                              
                                                              // Test the method - should return namespaced attribute
                                                              Attr result = (Attr) getAttributeMethod.invoke(iterator, element, name);
                                                              
                                                              // Verify the mutation would fail this test
                                                              // Original code should return namespacedAttr
                                                              // Mutated code would return nonNamespacedAttr
                                                              assertSame("Should return namespaced attribute", namespacedAttr, result);
                                                          }

    @Test
                                                     public void testGetAttributeWithExistingAttrShouldReturnAttr() throws Exception {
                                                         // Setup test data
                                                         QName testQName = new QName("http://test.ns", "testAttr");
                                                         Element mockElement = mock(Element.class);
                                                         NodePointer mockParent = mock(NodePointer.class);
                                                         NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
                                                         Attr mockAttr = mock(Attr.class);
                                                         
                                                         // Mock behavior for name
                                                         QName mockName = mock(QName.class);
                                                         when(mockName.getPrefix()).thenReturn("testPrefix");
                                                         when(mockName.getName()).thenReturn("testAttr");
                                                         
                                                         // Mock namespace resolution
                                                         when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
                                                         when(mockNsResolver.getNamespaceURI("testPrefix")).thenReturn("http://test.ns");
                                                         when(mockParent.getNamespaceURI("testPrefix")).thenReturn("http://test.ns");
                                                         
                                                         // Mock element behavior - attribute exists
                                                         when(mockElement.getAttributeNodeNS("http://test.ns", "testAttr")).thenReturn(mockAttr);
                                                         
                                                         // Create test instance
                                                         DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, mockName);
                                                         
                                                         // Use reflection to access private method since we're testing it directly
                                                         Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                         getAttributeMethod.setAccessible(true);
                                                         
                                                         // Call the method and verify
                                                         Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                         
                                                         // Assertion that will catch the mutant
                                                         assertNotNull("Method should return the attribute when it exists", result);
                                                         assertEquals("Returned attribute should match the expected one", mockAttr, result);
                                                     }

    @Test
                                                public void testGetAttribute_ShouldNotThrowExceptionWhenIteratingAttributes() throws Exception {
                                                    // Setup test data
                                                    QName testQName = new QName("test");
                                                    Element mockElement = mock(Element.class);
                                                    NodePointer mockParent = mock(NodePointer.class);
                                                    NamespaceResolver mockNsr = mock(NamespaceResolver.class);
                                                    NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                    Attr mockAttr1 = mock(Attr.class);
                                                    Attr mockAttr2 = mock(Attr.class);
                                                    
                                                    // Configure mocks
                                                    when(mockElement.getAttributeNodeNS(anyString(), anyString())).thenReturn(null);
                                                    when(mockElement.getAttributes()).thenReturn(mockAttributes);
                                                    when(mockAttributes.getLength()).thenReturn(2);
                                                    when(mockAttributes.item(0)).thenReturn(mockAttr1);
                                                    when(mockAttributes.item(1)).thenReturn(mockAttr2);
                                                    
                                                    when(mockParent.getNamespaceResolver()).thenReturn(mockNsr);
                                                    when(mockNsr.getNamespaceURI(anyString())).thenReturn("test-ns");
                                                    when(mockParent.getNamespaceURI(anyString())).thenReturn("test-ns");
                                                    
                                                    // Create test instance
                                                    DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                                    
                                                    // Use reflection to access private testAttr method
                                                    Method testAttrMethod = DOMAttributeIterator.class.getDeclaredMethod("testAttr", Attr.class, QName.class);
                                                    testAttrMethod.setAccessible(true);
                                                    when(testAttrMethod.invoke(iterator, mockAttr1, testQName)).thenReturn(false);
                                                    when(testAttrMethod.invoke(iterator, mockAttr2, testQName)).thenReturn(true);
                                                    
                                                    // Use reflection to access private getAttribute method
                                                    Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                                    getAttributeMethod.setAccessible(true);
                                                    
                                                    // Test - should not throw ArrayIndexOutOfBoundsException
                                                    Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
                                                    
                                                    // Verify
                                                    assertNotNull(result);
                                                    assertEquals(mockAttr2, result);
                                                    verify(mockAttributes, times(2)).item(anyInt()); // Verify only valid indices accessed
                                                }

    @Test
                                           public void testGetAttributeWithPrefixMutation() throws Exception {
                                               // Setup test data
                                               QName nameWithPrefix = mock(QName.class);
                                               when(nameWithPrefix.getPrefix()).thenReturn("testPrefix");
                                               when(nameWithPrefix.getName()).thenReturn("testName");
                                               
                                               QName nameWithoutPrefix = mock(QName.class);
                                               when(nameWithoutPrefix.getPrefix()).thenReturn(null);
                                               when(nameWithoutPrefix.getName()).thenReturn("testName");
                                               
                                               Element element = mock(Element.class);
                                               Attr expectedAttr = mock(Attr.class);
                                               
                                               // Mock namespace resolver behavior
                                               NodePointer parent = mock(NodePointer.class);
                                               NamespaceResolver nsr = mock(NamespaceResolver.class);
                                               when(parent.getNamespaceResolver()).thenReturn(nsr);
                                               when(nsr.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                               when(parent.getNamespaceURI("testPrefix")).thenReturn("testNS");
                                               
                                               // Mock element behavior for namespaced attribute
                                               when(element.getAttributeNodeNS("testNS", "testName")).thenReturn(expectedAttr);
                                               
                                               // Mock element behavior for non-namespaced attribute
                                               when(element.getAttributeNode("testName")).thenReturn(expectedAttr);
                                               
                                               // Create test object
                                               DOMAttributeIterator iterator = new DOMAttributeIterator(parent, nameWithPrefix);
                                               
                                               // Get private method via reflection
                                               Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                                                   "getAttribute", Element.class, QName.class);
                                               getAttributeMethod.setAccessible(true);
                                               
                                               // Test case 1: With prefix - should use namespace resolution
                                               Attr resultWithPrefix = (Attr) getAttributeMethod.invoke(iterator, element, nameWithPrefix);
                                               assertEquals(expectedAttr, resultWithPrefix);
                                               
                                               // Verify namespace resolution was attempted
                                               verify(nsr).getNamespaceURI("testPrefix");
                                               
                                               // Test case 2: Without prefix - should skip namespace resolution
                                               Attr resultWithoutPrefix = (Attr) getAttributeMethod.invoke(iterator, element, nameWithoutPrefix);
                                               assertEquals(expectedAttr, resultWithoutPrefix);
                                               
                                               // Verify namespace resolution was NOT attempted
                                               verify(nsr, never()).getNamespaceURI(isNull());
                                               
                                               // The mutant would fail these tests because:
                                               // 1. For nameWithPrefix, it would skip namespace resolution (wrong)
                                               // 2. For nameWithoutPrefix, it would attempt namespace resolution (wrong)
                                           }

    @Test
                                      public void testGetAttributeWithNamespacedAttrShouldUseNamespaceResolver() {
                                          // Setup test data
                                          QName name = new QName("prefix", "localName");
                                          Element element = mock(Element.class);
                                          NodePointer parent = mock(NodePointer.class);
                                          NamespaceResolver nsResolver = mock(NamespaceResolver.class);
                                          Attr expectedAttr = mock(Attr.class);
                                          
                                          // Mock behavior
                                          when(name.getPrefix()).thenReturn("prefix");
                                          when(parent.getNamespaceResolver()).thenReturn(nsResolver);
                                          when(nsResolver.getNamespaceURI("prefix")).thenReturn("http://test.ns");
                                          when(element.getAttributeNodeNS("http://test.ns", "localName")).thenReturn(expectedAttr);
                                          
                                          // Create test instance
                                          DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                                          
                                          // Use reflection to call private method
                                          try {
                                              Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                              method.setAccessible(true);
                                              Attr result = (Attr) method.invoke(iterator, element, name);
                                              
                                              // Verify
                                              assertEquals(expectedAttr, result);
                                              verify(parent).getNamespaceResolver();
                                              verify(nsResolver).getNamespaceURI("prefix");
                                          } catch (Exception e) {
                                              fail("Reflection failed: " + e.getMessage());
                                          }
                                      }

    @Test
                                 public void testGetAttribute_NamespaceResolverNull_ShouldFallbackToDefaultLookup() {
                                     // Setup test data
                                     QName testQName = new QName("testPrefix", "testName");
                                     Element mockElement = mock(Element.class);
                                     NodePointer mockParent = mock(NodePointer.class);
                                     Attr expectedAttr = mock(Attr.class);
                                     
                                     // Mock behavior
                                     when(mockParent.getNamespaceResolver()).thenReturn(null); // This is the key mutation trigger
                                     when(mockElement.getAttributeNodeNS("", "testName")).thenReturn(null);
                                     when(mockElement.getAttributeNode("testName")).thenReturn(expectedAttr);
                                     
                                     // Create test instance
                                     DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
                                     
                                     // Use reflection to access private method for testing
                                     try {
                                         Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                         method.setAccessible(true);
                                         Attr result = (Attr) method.invoke(iterator, mockElement, testQName);
                                         
                                         // Verify the fallback behavior was used (original behavior)
                                         assertEquals(expectedAttr, result);
                                         verify(mockElement).getAttributeNode("testName");
                                     } catch (Exception e) {
                                         fail("Reflection failed: " + e.getMessage());
                                     }
                                 }

    @Test
                            public void testGetAttributeNamespaceResolution() throws Exception {
                                // Setup test data
                                QName qname = new QName("prefix", "localName");
                                Element element = mock(Element.class);
                                NodePointer parent = mock(NodePointer.class);
                                NamespaceResolver nsr = mock(NamespaceResolver.class);
                                
                                // Mock behavior
                                when(qname.getPrefix()).thenReturn("prefix");
                                when(parent.getNamespaceResolver()).thenReturn(nsr);
                                
                                // Case 1: nsr returns null namespace, parent returns "parentNS"
                                when(nsr.getNamespaceURI("prefix")).thenReturn(null);
                                when(parent.getNamespaceURI("prefix")).thenReturn("parentNS");
                                
                                // Original: should use parentNS (since testNS was null)
                                // Mutant: should keep null (since testNS was null)
                                Attr expectedAttr = mock(Attr.class);
                                when(element.getAttributeNodeNS("parentNS", "localName")).thenReturn(expectedAttr);
                                
                                DOMAttributeIterator iterator = new DOMAttributeIterator(parent, qname);
                                
                                // Use reflection to access private method
                                Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                                getAttributeMethod.setAccessible(true);
                                Attr result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                
                                // This assertion will fail for the mutant
                                assertEquals(expectedAttr, result);
                                
                                // Case 2: nsr returns "resolvedNS", parent returns "parentNS"
                                when(nsr.getNamespaceURI("prefix")).thenReturn("resolvedNS");
                                
                                // Original: should keep resolvedNS
                                // Mutant: should override with parentNS
                                when(element.getAttributeNodeNS("resolvedNS", "localName")).thenReturn(expectedAttr);
                                when(element.getAttributeNodeNS("parentNS", "localName")).thenReturn(null);
                                
                                result = (Attr) getAttributeMethod.invoke(iterator, element, qname);
                                
                                // This assertion will fail for the mutant
                                assertEquals(expectedAttr, result);
                            }

    @Test
                       public void testGetAttributeWithNamespaceShouldUseNamespaceAwareLookup() {
                           // Setup test data
                           QName name = new QName("http://test.ns", "test");
                           Element element = mock(Element.class);
                           NodePointer parent = mock(NodePointer.class);
                           NamespaceResolver nsr = mock(NamespaceResolver.class);
                           Attr expectedAttr = mock(Attr.class);
                           
                           // Mock behavior
                           when(parent.getNamespaceResolver()).thenReturn(nsr);
                           when(nsr.getNamespaceURI("prefix")).thenReturn("http://test.ns");
                           when(element.getAttributeNodeNS("http://test.ns", "test")).thenReturn(expectedAttr);
                           
                           // Create test instance
                           DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                           
                           // Use reflection to access private method (since we need to test it directly)
                           try {
                               Method getAttribute = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                               getAttribute.setAccessible(true);
                               Attr result = (Attr) getAttribute.invoke(iterator, element, name);
                               
                               // Verify the namespace-aware lookup was attempted
                               verify(element).getAttributeNodeNS("http://test.ns", "test");
                               assertEquals(expectedAttr, result);
                           } catch (Exception e) {
                               fail("Reflection failed: " + e.getMessage());
                           }
                       }

    @Test
                   public void testGetAttributeWithNamespaceShouldReturnCorrectAttribute() {
                       // Setup test data
                       Element element = mock(Element.class);
                       QName name = mock(QName.class);
                       NodePointer parent = mock(NodePointer.class);
                       NamespaceResolver nsr = mock(NamespaceResolver.class);
                       
                       // Create namespace-qualified attribute and non-qualified attribute
                       Attr nsAttr = mock(Attr.class);
                       Attr nonNsAttr = mock(Attr.class);
                       
                       // Mock behavior
                       when(name.getPrefix()).thenReturn("testPrefix");
                       when(name.getName()).thenReturn("testName");
                       when(parent.getNamespaceResolver()).thenReturn(nsr);
                       when(nsr.getNamespaceURI("testPrefix")).thenReturn("http://test.ns");
                       when(parent.getNamespaceURI("testPrefix")).thenReturn(null);
                       
                       // Mock element behavior for namespace lookup
                       when(element.getAttributeNodeNS("http://test.ns", "testName")).thenReturn(nsAttr);
                       // This is what the mutant would return instead
                       when(element.getAttributeNode("testName")).thenReturn(nonNsAttr);
                       
                       // Create test instance
                       DOMAttributeIterator iterator = new DOMAttributeIterator(parent, name);
                       
                       // Use reflection to access private method since we're testing it directly
                       try {
                           Method method = DOMAttributeIterator.class.getDeclaredMethod("getAttribute", Element.class, QName.class);
                           method.setAccessible(true);
                           Attr result = (Attr) method.invoke(iterator, element, name);
                           
                           // Verify the correct attribute was returned (should be nsAttr)
                           assertEquals("Should return namespace-qualified attribute", nsAttr, result);
                           assertNotEquals("Should not return non-namespace attribute", nonNsAttr, result);
                       } catch (Exception e) {
                           fail("Failed to invoke private method: " + e.getMessage());
                       }
                   }

    @Test
         public void testGetAttributeWithExistingAttrShouldReturnAttr1() throws Exception {
             // Setup test data
             String namespaceURI = "http://test.ns";
             String localName = "testAttr";
             String prefix = "test";
             // Create QName with namespaceURI and localName
             QName testQName = new QName(namespaceURI, localName);
             
             Element mockElement = mock(Element.class);
             NodePointer mockParent = mock(NodePointer.class);
             NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
             Attr mockAttr = mock(Attr.class);
             
             // Mock behavior
             when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
             when(mockNsResolver.getNamespaceURI("test")).thenReturn("http://test.ns");
             when(mockElement.getAttributeNodeNS("http://test.ns", "testAttr")).thenReturn(mockAttr);
             
             // Create test instance
             DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
             
             // Use reflection to access private method since we're testing it directly
             Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
                 "getAttribute", Element.class, QName.class);
             getAttributeMethod.setAccessible(true);
             
             // Invoke and verify
             Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
             assertNotNull("Should return the attribute when it exists", result);
             assertEquals(mockAttr, result);
         }

    @Test
    public void testGetAttribute_ShouldNotThrowExceptionWhenNoMatchingAttributes() throws Exception {
        // Setup test data
        QName testQName = new QName("http://test.ns", "testAttr");
        Element mockElement = mock(Element.class);
        NodePointer mockParent = mock(NodePointer.class);
        NamespaceResolver mockNsResolver = mock(NamespaceResolver.class);
        
        // Mock behavior for namespace resolution path
        when(testQName.getPrefix()).thenReturn("test");
        when(mockParent.getNamespaceResolver()).thenReturn(mockNsResolver);
        when(mockNsResolver.getNamespaceURI("test")).thenReturn(null);
        when(mockParent.getNamespaceURI("test")).thenReturn(null);
        
        // Setup attributes that won't match
        NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
        when(mockAttributes.getLength()).thenReturn(2);
        when(mockAttributes.item(0)).thenReturn(mock(Attr.class));
        when(mockAttributes.item(1)).thenReturn(mock(Attr.class));
        when(mockElement.getAttributes()).thenReturn(mockAttributes);
        
        // Create iterator instance
        DOMAttributeIterator iterator = new DOMAttributeIterator(mockParent, testQName);
        
        // Use reflection to access private getAttribute method
        Method getAttributeMethod = DOMAttributeIterator.class.getDeclaredMethod(
            "getAttribute", Element.class, QName.class);
        getAttributeMethod.setAccessible(true);
        
        // Test - should return null without throwing exceptions
        Attr result = (Attr) getAttributeMethod.invoke(iterator, mockElement, testQName);
        assertNull(result);
        
        // Verify the loop ran exactly twice (for 2 attributes)
        verify(mockAttributes, times(2)).item(anyInt());
    }


}
