package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testGetBaseValue_WithNullNode() {
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer((Node)null, Locale.US);
                                                                                                                                                                            assertNull(pointer.getBaseValue());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetBaseValue_WithMockNode() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                                                                                                                                                            assertSame(mockNode, pointer.getBaseValue());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetImmediateNode_WithNonNullNode() {
                                                                                                                                                                            // Setup
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                                                                                            
                                                                                                                                                                            // Exercise
                                                                                                                                                                            Node result = (Node) pointer.getImmediateNode();
                                                                                                                                                                            
                                                                                                                                                                            // Verify
                                                                                                                                                                            assertSame("Should return the same node that was set in constructor", 
                                                                                                                                                                                      mockNode, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetImmediateNode_WithNullNode() {
                                                                                                                                                                            // Setup
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(null, Locale.ENGLISH);
                                                                                                                                                                            
                                                                                                                                                                            // Exercise
                                                                                                                                                                            Node result = (Node) pointer.getImmediateNode();
                                                                                                                                                                            
                                                                                                                                                                            // Verify
                                                                                                                                                                            assertNull("Should return null when constructed with null node", result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetImmediateNode_WithParentPointer() {
                                                                                                                                                                            // Setup
                                                                                                                                                                            Node mockParentNode = mock(Node.class);
                                                                                                                                                                            Node mockChildNode = mock(Node.class);
                                                                                                                                                                            DOMNodePointer parentPointer = new DOMNodePointer(mockParentNode, Locale.ENGLISH);
                                                                                                                                                                            DOMNodePointer childPointer = new DOMNodePointer(parentPointer, mockChildNode);
                                                                                                                                                                            
                                                                                                                                                                            // Exercise
                                                                                                                                                                            Node result = (Node) childPointer.getImmediateNode();
                                                                                                                                                                            
                                                                                                                                                                            // Verify
                                                                                                                                                                            assertSame("Should return the child node, not the parent node",
                                                                                                                                                                                      mockChildNode, result);
                                                                                                                                                                            assertNotSame("Should not return the parent node",
                                                                                                                                                                                         mockParentNode, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetImmediateNode_WithIdConstructor() {
                                                                                                                                                                            // Setup
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            String testId = "testId";
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH, testId);
                                                                                                                                                                            
                                                                                                                                                                            // Exercise
                                                                                                                                                                            Node result = (Node) pointer.getImmediateNode();
                                                                                                                                                                            
                                                                                                                                                                            // Verify
                                                                                                                                                                            assertSame("Should return the node regardless of ID being set",
                                                                                                                                                                                      mockNode, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testGetImmediateNode_AfterModification() {
                                                                                                                                                                            // Setup
                                                                                                                                                                            Node initialNode = mock(Node.class);
                                                                                                                                                                            Node modifiedNode = mock(Node.class);
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(initialNode, Locale.ENGLISH);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to modify the private node field for testing purposes
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field field = DOMNodePointer.class.getDeclaredField("node");
                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                field.set(pointer, modifiedNode);
                                                                                                                                                                                
                                                                                                                                                                                // Exercise
                                                                                                                                                                                Node result = (Node) pointer.getImmediateNode();
                                                                                                                                                                                
                                                                                                                                                                                // Verify
                                                                                                                                                                                assertSame("Should return the modified node", modifiedNode, result);
                                                                                                                                                                                assertNotSame("Should not return the initial node", initialNode, result);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testGetDefaultNamespaceURI_WhenDefaultNamespaceIsAlreadySet() {
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                    
                                                                                                                                                                    try {
                                                                                                                                                                        Field defaultNamespaceField = DOMNodePointer.class.getDeclaredField("defaultNamespace");
                                                                                                                                                                        defaultNamespaceField.setAccessible(true);
                                                                                                                                                                        defaultNamespaceField.set(pointer, "http://example.com");
                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                        fail("Failed to set defaultNamespace field via reflection");
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    assertEquals("http://example.com", pointer.getDefaultNamespaceURI());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetDefaultNamespaceURI_WhenNodeIsDocumentWithXmlns() {
                                                                                                                                                                    Document mockDocument = mock(Document.class);
                                                                                                                                                                    Element mockElement = mock(Element.class);
                                                                                                                                                                    Attr mockAttr = mock(Attr.class);
                                                                                                                                                                    
                                                                                                                                                                    when(mockDocument.getDocumentElement()).thenReturn(mockElement);
                                                                                                                                                                    when(mockElement.getAttributeNode("xmlns")).thenReturn(mockAttr);
                                                                                                                                                                    when(mockAttr.getValue()).thenReturn("http://doc.example.com");
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockDocument, null);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals("http://doc.example.com", pointer.getDefaultNamespaceURI());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetDefaultNamespaceURI_WhenNodeIsElementWithXmlns() {
                                                                                                                                                                    // Import these at class level: 
                                                                                                                                                                    // import org.w3c.dom.Node;
                                                                                                                                                                    // import org.w3c.dom.Element;
                                                                                                                                                                    // import org.w3c.dom.Attr;
                                                                                                                                                                    
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    Attr mockAttr = mock(Attr.class);
                                                                                                                                                                    
                                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                    when(((Element)mockNode).getAttributeNode("xmlns")).thenReturn(mockAttr);
                                                                                                                                                                    when(mockAttr.getValue()).thenReturn("http://element.example.com");
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals("http://element.example.com", pointer.getDefaultNamespaceURI());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetDefaultNamespaceURI_WhenXmlnsFoundInParent() {
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    Node mockParent = mock(Node.class);
                                                                                                                                                                    Attr mockAttr = mock(Attr.class);
                                                                                                                                                                    
                                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(mockParent);
                                                                                                                                                                    when(mockParent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                    when(((Element)mockParent).getAttributeNode("xmlns")).thenReturn(mockAttr);
                                                                                                                                                                    when(mockAttr.getValue()).thenReturn("http://parent.example.com");
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals("http://parent.example.com", pointer.getDefaultNamespaceURI());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetDefaultNamespaceURI_WhenNoXmlnsFound() {
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(null);
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                    assertNull(pointer.getDefaultNamespaceURI());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetDefaultNamespaceURI_WhenDocumentHasNoDocumentElement() {
                                                                                                                                                                    Document mockDocument = mock(Document.class);
                                                                                                                                                                    when(mockDocument.getDocumentElement()).thenReturn(null);
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockDocument, null);
                                                                                                                                                                    
                                                                                                                                                                    assertNull(pointer.getDefaultNamespaceURI());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testIsLanguage_WhenCurrentLanguageMatchesExactly() throws Exception {
                                                                                                                                                                    // Create a DOMNodePointer instance
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                                                                                                                                                    
                                                                                                                                                                    // Create a spy of the pointer
                                                                                                                                                                    DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to mock the protected getLanguage() method
                                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                                    when(getLanguageMethod.invoke(spyPointer)).thenReturn("en-US");
                                                                                                                                                                    
                                                                                                                                                                    assertTrue(spyPointer.isLanguage("en"));
                                                                                                                                                                    assertTrue(spyPointer.isLanguage("EN"));
                                                                                                                                                                    assertTrue(spyPointer.isLanguage("en-US"));
                                                                                                                                                                    assertTrue(spyPointer.isLanguage("EN-us"));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testIsLanguage_WhenCurrentLanguageDoesNotMatch() throws Exception {
                                                                                                                                                                    // Create a DOMNodePointer instance with required parameters
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    Locale locale = Locale.ENGLISH;
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                                                    
                                                                                                                                                                    // Create spy and mock protected getLanguage() method
                                                                                                                                                                    DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                                    when(getLanguageMethod.invoke(spyPointer)).thenReturn("fr-FR");
                                                                                                                                                                    
                                                                                                                                                                    assertFalse(spyPointer.isLanguage("en"));
                                                                                                                                                                    assertFalse(spyPointer.isLanguage("fr-CA"));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testIsLanguage_WithDifferentCaseSensitivity() throws Exception {
                                                                                                                                                                    // Create a DOMNodePointer instance with required parameters
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    Locale locale = Locale.US;
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                                                    
                                                                                                                                                                    // Create spy and mock getLanguage() using reflection
                                                                                                                                                                    DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                                    when(getLanguageMethod.invoke(spyPointer)).thenReturn("eN-uS");
                                                                                                                                                                    
                                                                                                                                                                    assertTrue(spyPointer.isLanguage("EN"));
                                                                                                                                                                    assertTrue(spyPointer.isLanguage("en-us"));
                                                                                                                                                                    assertTrue(spyPointer.isLanguage("En"));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_AttributeInCurrentElement() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                    org.w3c.dom.Document doc = builder.newDocument();
                                                                                                                                                                    org.w3c.dom.Element element = doc.createElement("test");
                                                                                                                                                                    element.setAttribute("attr1", "value1");
                                                                                                                                                                    
                                                                                                                                                                    // Create DOMNodePointer instance to access protected method
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(element, java.util.Locale.getDefault());
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    java.lang.reflect.Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                        "findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    String result = (String) method.invoke(pointer, element, "attr1");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("value1", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_AttributeInParentElement() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                    org.w3c.dom.Document doc = builder.newDocument();
                                                                                                                                                                    org.w3c.dom.Element parent = doc.createElement("parent");
                                                                                                                                                                    parent.setAttribute("attr1", "parentValue");
                                                                                                                                                                    org.w3c.dom.Element child = doc.createElement("child");
                                                                                                                                                                    parent.appendChild(child);
                                                                                                                                                                    
                                                                                                                                                                    // Create DOMNodePointer instance to access protected method
                                                                                                                                                                    org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                                                        new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(child, java.util.Locale.getDefault());
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    java.lang.reflect.Method method = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                                                                        .getDeclaredMethod("findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(pointer, child, "attr1");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("parentValue", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_AttributeInGrandparentElement() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                    org.w3c.dom.Document doc = builder.newDocument();
                                                                                                                                                                    org.w3c.dom.Element grandparent = doc.createElement("grandparent");
                                                                                                                                                                    grandparent.setAttribute("attr1", "grandparentValue");
                                                                                                                                                                    org.w3c.dom.Element parent = doc.createElement("parent");
                                                                                                                                                                    grandparent.appendChild(parent);
                                                                                                                                                                    org.w3c.dom.Element child = doc.createElement("child");
                                                                                                                                                                    parent.appendChild(child);
                                                                                                                                                                    
                                                                                                                                                                    // Create DOMNodePointer instance to access protected method
                                                                                                                                                                    org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                                                        new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(child, java.util.Locale.getDefault());
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    java.lang.reflect.Method method = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                                                                        .getDeclaredMethod("findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(pointer, child, "attr1");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("grandparentValue", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_AttributeNotFound() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                    org.w3c.dom.Document doc = builder.newDocument();
                                                                                                                                                                    org.w3c.dom.Element element = doc.createElement("test");
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    java.lang.reflect.Method method = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                                                                        .getDeclaredMethod("findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(null, element, "nonexistent");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_EmptyAttributeValue() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                    org.w3c.dom.Document doc = builder.newDocument();
                                                                                                                                                                    org.w3c.dom.Element element = doc.createElement("test");
                                                                                                                                                                    element.setAttribute("attr1", "");
                                                                                                                                                                    
                                                                                                                                                                    // Get the protected method via reflection
                                                                                                                                                                    java.lang.reflect.Method method = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                                                                        .getDeclaredMethod("findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(null, element, "attr1");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_NonElementNodesInHierarchy() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                    org.w3c.dom.Document doc = builder.newDocument();
                                                                                                                                                                    org.w3c.dom.Element parent = doc.createElement("parent");
                                                                                                                                                                    parent.setAttribute("attr1", "parentValue");
                                                                                                                                                                    org.w3c.dom.Node textNode = doc.createTextNode("some text");
                                                                                                                                                                    parent.appendChild(textNode);
                                                                                                                                                                    
                                                                                                                                                                    // Get the protected method via reflection
                                                                                                                                                                    java.lang.reflect.Method method = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                                                                        .getDeclaredMethod("findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(null, textNode, "attr1");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("parentValue", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_NullNode() throws Exception {
                                                                                                                                                                    // Get the protected method using reflection
                                                                                                                                                                    Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test with null node
                                                                                                                                                                    String result = (String) method.invoke(null, null, "attr1");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_NullAttributeName() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    Node node = mock(Node.class);
                                                                                                                                                                    
                                                                                                                                                                    // Get the protected method via reflection
                                                                                                                                                                    Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                        "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(null, node, null);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testAsPath_WithId() {
                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US, "testId");
                                                                                                                                                                assertEquals("id(\'testId\')", pointer.asPath());
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testAsPath_TextNode() {
                                                                                                                                                            // Create mock objects
                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                            DOMNodePointer parentPointer = mock(DOMNodePointer.class);
                                                                                                                                                            
                                                                                                                                                            // Set up mock behavior
                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                            when(parentPointer.asPath()).thenReturn("/parent/path");
                                                                                                                                                            
                                                                                                                                                            // Create test object
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(parentPointer, mockNode);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to set private field since getRelativePositionOfTextNode() is private
                                                                                                                                                            try {
                                                                                                                                                                Field field = DOMNodePointer.class.getDeclaredField("relativePositionOfTextNode");
                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                field.set(pointer, 1);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to set relativePositionOfTextNode via reflection");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Verify result
                                                                                                                                                            assertEquals("/parent/path/text()[1]", pointer.asPath());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testAsPath_CDATASectionNode() {
                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                            DOMNodePointer parentPointer = mock(DOMNodePointer.class);
                                                                                                                                                            when(parentPointer.asPath()).thenReturn("/parent/path");
                                                                                                                                                            
                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(parentPointer, mockNode);
                                                                                                                                                            
                                                                                                                                                            try {
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod("getRelativePositionOfTextNode");
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                when(method.invoke(pointer)).thenReturn(1);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to mock getRelativePositionOfTextNode");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            assertEquals("/parent/path/text()[1]", pointer.asPath());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testAsPath_ProcessingInstructionNode() {
                                                                                                                                                            // Create parent pointer mock
                                                                                                                                                            DOMNodePointer parentPointer = mock(DOMNodePointer.class);
                                                                                                                                                            when(parentPointer.asPath()).thenReturn("/parent/path");
                                                                                                                                                            
                                                                                                                                                            // Create processing instruction node mock
                                                                                                                                                            ProcessingInstruction piNode = mock(ProcessingInstruction.class);
                                                                                                                                                            when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                            when(piNode.getTarget()).thenReturn("target");
                                                                                                                                                            
                                                                                                                                                            // Create the pointer under test
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(parentPointer, piNode);
                                                                                                                                                            
                                                                                                                                                            // Mock the relative position method using reflection since it's private
                                                                                                                                                            try {
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod("getRelativePositionOfPI", String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                when(method.invoke(pointer, "target")).thenReturn(1);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to setup private method mock: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            assertEquals("/parent/path/processing-instruction(\'target\')[1]", pointer.asPath());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testAsPath_DocumentNode() {
                                                                                                                                                            // Create mock Node
                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            // Create mock parent pointer
                                                                                                                                                            NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                            when(parentPointer.asPath()).thenReturn("/parent/path");
                                                                                                                                                            
                                                                                                                                                            // Create DOMNodePointer with mocked parent and node
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(parentPointer, mockNode);
                                                                                                                                                            
                                                                                                                                                            // Document node should just return parent path
                                                                                                                                                            assertEquals("/parent/path", pointer.asPath());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testAsPath_ElementNode_NonDOMNodePointerParent() {
                                                                                                                                                            // Setup
                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            NodePointer nonDomParent = mock(NodePointer.class);
                                                                                                                                                            when(nonDomParent.asPath()).thenReturn("/parent/path");
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(nonDomParent, mockNode);
                                                                                                                                                            
                                                                                                                                                            // Test & Verify
                                                                                                                                                            assertEquals("/parent/path", pointer.asPath());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetValue_CommentNodeWithText() {
                                                                                                                                                            // Create mock Comment object
                                                                                                                                                            org.w3c.dom.Comment comment = mock(org.w3c.dom.Comment.class);
                                                                                                                                                            when(comment.getNodeType()).thenReturn(org.w3c.dom.Node.COMMENT_NODE);
                                                                                                                                                            when(comment.getData()).thenReturn("  test comment  ");
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(comment, null);
                                                                                                                                                            assertEquals("test comment", pointer.getValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetValue_CommentNodeWithNullText() {
                                                                                                                                                            org.w3c.dom.Comment comment = mock(org.w3c.dom.Comment.class);
                                                                                                                                                            when(comment.getNodeType()).thenReturn(org.w3c.dom.Node.COMMENT_NODE);
                                                                                                                                                            when(comment.getData()).thenReturn(null);
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(comment, null);
                                                                                                                                                            assertEquals("", pointer.getValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetValue_CommentNodeWithEmptyText() {
                                                                                                                                                            // Create mock Comment node
                                                                                                                                                            Comment comment = mock(Comment.class);
                                                                                                                                                            when(comment.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                            when(comment.getData()).thenReturn("");
                                                                                                                                                            
                                                                                                                                                            // Create pointer and test
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(comment, null);
                                                                                                                                                            assertEquals("", pointer.getValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetValue_UnknownNodeTypeDelegatesToStringValue() {
                                                                                                                                                            Node unknownNode = mock(Node.class);
                                                                                                                                                            when(unknownNode.getNodeType()).thenReturn((short) 999); // Unknown node type
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(unknownNode, null);
                                                                                                                                                            
                                                                                                                                                            // Since stringValue is private, we need to test the behavior indirectly
                                                                                                                                                            // by verifying that for unknown node types, it delegates to stringValue
                                                                                                                                                            // which will return the node's string representation
                                                                                                                                                            when(unknownNode.getNodeValue()).thenReturn("unknown value");
                                                                                                                                                            
                                                                                                                                                            assertEquals("unknown value", pointer.getValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testStringValue_CommentNode() throws Exception {
                                                                                                                                                            Node commentNode = mock(Node.class);
                                                                                                                                                            when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(commentNode, null);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private stringValue method
                                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                                            String result = (String) stringValueMethod.invoke(pointer, commentNode);
                                                                                                                                                            
                                                                                                                                                            assertEquals("", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testStringValue_TextNode_Trim() throws Exception {
                                                                                                                                                            // Import required classes
                                                                                                                                                            org.w3c.dom.Node parentNode = mock(org.w3c.dom.Node.class);
                                                                                                                                                            org.w3c.dom.Text textNode = mock(org.w3c.dom.Text.class);
                                                                                                                                                            
                                                                                                                                                            when(textNode.getNodeType()).thenReturn(org.w3c.dom.Node.TEXT_NODE);
                                                                                                                                                            when(textNode.getNodeValue()).thenReturn("  some text  ");
                                                                                                                                                            when(textNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(textNode, null);
                                                                                                                                                            
                                                                                                                                                            // Since stringValue is private, we need to either:
                                                                                                                                                            // 1. Use public getValue() method which internally calls stringValue
                                                                                                                                                            // 2. Use reflection to access private method
                                                                                                                                                            
                                                                                                                                                            // Option 1: Using public getValue()
                                                                                                                                                            Object result = pointer.getValue();
                                                                                                                                                            assertEquals("some text", result.toString());
                                                                                                                                                            
                                                                                                                                                            // Option 2: Using reflection (if you specifically need to test stringValue)
                                                                                                                                                            /*
                                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", org.w3c.dom.Node.class);
                                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                                            String result = (String) stringValueMethod.invoke(pointer, textNode);
                                                                                                                                                            assertEquals("some text", result);
                                                                                                                                                            */
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testStringValue_TextNode_NullValue() throws Exception {
                                                                                                                                                            // Import required classes
                                                                                                                                                            org.w3c.dom.Node textNode = mock(org.w3c.dom.Text.class);
                                                                                                                                                            when(textNode.getNodeType()).thenReturn(org.w3c.dom.Node.TEXT_NODE);
                                                                                                                                                            when(textNode.getNodeValue()).thenReturn(null);
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(textNode, null);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private method
                                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", org.w3c.dom.Node.class);
                                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                                            String result = (String) stringValueMethod.invoke(pointer, textNode);
                                                                                                                                                            
                                                                                                                                                            assertEquals("", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testStringValue_CDATASection() throws Exception {
                                                                                                                                                            Node cdataNode = mock(Node.class);
                                                                                                                                                            when(cdataNode.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                                                                                                                            when(cdataNode.getNodeValue()).thenReturn("<![CDATA[content]]>");
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(cdataNode, null);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private stringValue method
                                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                                            String result = (String) stringValueMethod.invoke(pointer, cdataNode);
                                                                                                                                                            
                                                                                                                                                            assertEquals("<![CDATA[content]]>", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testStringValue_ProcessingInstruction_Trim() {
                                                                                                                                                            ProcessingInstruction piNode = mock(ProcessingInstruction.class);
                                                                                                                                                            when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                            when(piNode.getData()).thenReturn("  instruction data  ");
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(piNode, null);
                                                                                                                                                            String result = (String) pointer.getValue();
                                                                                                                                                            
                                                                                                                                                            assertEquals("instruction data", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testStringValue_ProcessingInstruction_NullData() throws Exception {
                                                                                                                                                            ProcessingInstruction piNode = mock(ProcessingInstruction.class);
                                                                                                                                                            when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                            when(piNode.getData()).thenReturn(null);
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(piNode, null);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private stringValue method
                                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                                            String result = (String) stringValueMethod.invoke(pointer, piNode);
                                                                                                                                                            
                                                                                                                                                            assertEquals("", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testStringValue_ElementWithNoChildren() throws Exception {
                                                                                                                                                            Node elementNode = mock(Node.class);
                                                                                                                                                            when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            NodeList emptyList = mock(NodeList.class);
                                                                                                                                                            when(elementNode.getChildNodes()).thenReturn(emptyList);
                                                                                                                                                            when(emptyList.getLength()).thenReturn(0);
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(elementNode, null);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private stringValue method
                                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                                            String result = (String) stringValueMethod.invoke(pointer, elementNode);
                                                                                                                                                            
                                                                                                                                                            assertEquals("", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetDefaultNamespaceURI_WhenXmlnsIsEmptyString() {
                                                                                                                                                            // Create mock objects
                                                                                                                                                            org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                                                            org.w3c.dom.Element mockElement = mock(org.w3c.dom.Element.class);
                                                                                                                                                            org.w3c.dom.Attr mockAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                            
                                                                                                                                                            // Setup stubbing
                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                                                            when(((org.w3c.dom.Element)mockNode).getAttributeNode("xmlns")).thenReturn(mockAttr);
                                                                                                                                                            when(mockAttr.getValue()).thenReturn("");
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                            
                                                                                                                                                            assertNull(pointer.getDefaultNamespaceURI());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetDefaultNamespaceURI_WhenNodeIsNull() {
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer((Node)null, Locale.getDefault());
                                                                                                                                                            String result = pointer.getDefaultNamespaceURI();
                                                                                                                                                            assertNull(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetDefaultNamespaceURI_WhenXmlnsAttributeExistsButValueIsNull() {
                                                                                                                                                            // Create mock objects
                                                                                                                                                            org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                                                            org.w3c.dom.Attr mockAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                            org.w3c.dom.Element mockElement = mock(org.w3c.dom.Element.class);
                                                                                                                                                            
                                                                                                                                                            // Set up mock behavior
                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                                                            when(((org.w3c.dom.Element)mockNode).getAttributeNode("xmlns")).thenReturn(mockAttr);
                                                                                                                                                            when(mockAttr.getValue()).thenReturn(null);
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                            
                                                                                                                                                            assertNull(pointer.getDefaultNamespaceURI());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetBaseValue_WithElementNode() throws Exception {
                                                                                                                                                            // Import required classes
                                                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                            org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                            org.w3c.dom.Element element = document.createElement("testElement");
                                                                                                                                                            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(element, java.util.Locale.US);
                                                                                                                                                            assertSame(element, pointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetBaseValue_WithParentPointerConstructor() throws Exception {
                                                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                            org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                            
                                                                                                                                                            org.w3c.dom.Element parentElement = document.createElement("parent");
                                                                                                                                                            org.w3c.dom.Element childElement = document.createElement("child");
                                                                                                                                                            parentElement.appendChild(childElement);
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer parentPointer = new DOMNodePointer(parentElement, java.util.Locale.US);
                                                                                                                                                            DOMNodePointer childPointer = new DOMNodePointer(parentPointer, childElement);
                                                                                                                                                            
                                                                                                                                                            assertSame(childElement, childPointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetBaseValue_WithIdConstructor() throws Exception {
                                                                                                                                                            // Setup DOM objects
                                                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                            org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                            org.w3c.dom.Element element = document.createElement("elementWithId");
                                                                                                                                                            String id = "testId";
                                                                                                                                                            
                                                                                                                                                            // Create pointer and test
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(element, Locale.US, id);
                                                                                                                                                            assertSame(element, pointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetBaseValue_ConsistencyAcrossMultipleCalls() throws Exception {
                                                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                            org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                            org.w3c.dom.Element element = document.createElement("consistentElement");
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(element, Locale.US);
                                                                                                                                                            
                                                                                                                                                            // Multiple calls should return same reference
                                                                                                                                                            assertSame(pointer.getBaseValue(), pointer.getBaseValue());
                                                                                                                                                            assertSame(pointer.getBaseValue(), pointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testGetValue_CommentNodeWithWhitespaceText() {
                                                                                                                                                        // Create mock Comment node
                                                                                                                                                        org.w3c.dom.Comment comment = mock(org.w3c.dom.Comment.class);
                                                                                                                                                        when(comment.getNodeType()).thenReturn(org.w3c.dom.Node.COMMENT_NODE);
                                                                                                                                                        when(comment.getData()).thenReturn("   \t\n  ");
                                                                                                                                                        
                                                                                                                                                        // Test the pointer
                                                                                                                                                        DOMNodePointer pointer = new DOMNodePointer(comment, null);
                                                                                                                                                        assertEquals("", pointer.getValue());
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testGetBaseValue_WithTextNode() throws Exception {
                                                                                                                                                        // Create document and text node
                                                                                                                                                        javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                        javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                        org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                        
                                                                                                                                                        org.w3c.dom.Text textNode = document.createTextNode("test text");
                                                                                                                                                        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                                            new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(textNode, java.util.Locale.US);
                                                                                                                                                        assertSame(textNode, pointer.getBaseValue());
                                                                                                                                                    }

                                                                                                                                                public void testIsLanguage_WithNullInput() throws Exception {
                                                                                                                                                    // Create a mock Node and DOMNodePointer instance
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                                                                                                                                    
                                                                                                                                                    // Create a spy of the pointer
                                                                                                                                                    DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to mock the protected getLanguage() method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    spyPointer.isLanguage(null);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testFindEnclosingAttribute_MultipleAttributesInHierarchy() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                    org.w3c.dom.Document doc = builder.newDocument();
                                                                                                                                                    org.w3c.dom.Element grandparent = doc.createElement("grandparent");
                                                                                                                                                    grandparent.setAttribute("attr1", "grandparentValue");
                                                                                                                                                    org.w3c.dom.Element parent = doc.createElement("parent");
                                                                                                                                                    parent.setAttribute("attr1", "parentValue");
                                                                                                                                                    grandparent.appendChild(parent);
                                                                                                                                                    org.w3c.dom.Element child = doc.createElement("child");
                                                                                                                                                    parent.appendChild(child);
                                                                                                                                                    
                                                                                                                                                    // Create DOMNodePointer instance
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(child, Locale.getDefault());
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                    String result = (String) method.invoke(pointer, child, "attr1");
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertEquals("parentValue", result); // Should return the closest one
                                                                                                                                                }

    @Test
                                                                                                                                                public void testFindEnclosingAttribute_WithMockedNodes() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node childNode = mock(Node.class);
                                                                                                                                                    Node parentNode = mock(Node.class);
                                                                                                                                                    Element parentElement = mock(Element.class);
                                                                                                                                                    
                                                                                                                                                    when(childNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                    when(childNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                    when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                    when(parentNode.getParentNode()).thenReturn(null);
                                                                                                                                                    when(parentNode instanceof Element).thenReturn(true);
                                                                                                                                                    when(((Element)parentNode).getAttribute("attr1")).thenReturn("mockValue");
                                                                                                                                                    
                                                                                                                                                    // Create DOMNodePointer instance
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(childNode, Locale.getDefault());
                                                                                                                                                    
                                                                                                                                                    // Get the protected method via reflection
                                                                                                                                                    Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test
                                                                                                                                                    String result = (String) method.invoke(null, childNode, "attr1");
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertEquals("mockValue", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenNodeHasDirectLangAttribute() throws Exception {
                                                                                                                                                    // Create mock objects
                                                                                                                                                    org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                                                    org.w3c.dom.Attr mockLangAttr = mock(org.w3c.dom.Attr.class);
                                                                                                                                                    org.w3c.dom.NamedNodeMap mockAttributes = mock(org.w3c.dom.NamedNodeMap.class);
                                                                                                                                                    
                                                                                                                                                    // Set up mock behavior
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                    when(mockAttributes.getNamedItem("xml:lang")).thenReturn(mockLangAttr);
                                                                                                                                                    when(mockLangAttr.getNodeValue()).thenReturn("en-US");
                                                                                                                                                    
                                                                                                                                                    // Create pointer and test
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String result = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertEquals("en-US", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenParentNodeHasLangAttribute() throws Exception {
                                                                                                                                                    // Create mock objects
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Node mockParentNode = mock(Node.class);
                                                                                                                                                    Attr mockLangAttr = mock(Attr.class);
                                                                                                                                                    NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                                                                                    NamedNodeMap mockParentAttributes = mock(NamedNodeMap.class);
                                                                                                                                                    
                                                                                                                                                    // Setup mock behavior
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                    when(mockAttributes.getNamedItem("xml:lang")).thenReturn(null);
                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                    
                                                                                                                                                    when(mockParentNode.getAttributes()).thenReturn(mockParentAttributes);
                                                                                                                                                    when(mockParentAttributes.getNamedItem("xml:lang")).thenReturn(mockLangAttr);
                                                                                                                                                    when(mockLangAttr.getNodeValue()).thenReturn("fr");
                                                                                                                                                    
                                                                                                                                                    // Create pointer and test
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String result = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    assertEquals("fr", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenNoLangAttributeInHierarchy() throws Exception {
                                                                                                                                                    // Setup mocks
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                                                                                    
                                                                                                                                                    // Configure mock behavior
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                    when(mockAttributes.getNamedItem("xml:lang")).thenReturn(null);
                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(null); // No parent
                                                                                                                                                    
                                                                                                                                                    // Create test object
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Execute test
                                                                                                                                                    String result = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    // Verify result
                                                                                                                                                    assertNull(result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenNodeHasEmptyLangAttribute() throws Exception {
                                                                                                                                                    // Create mock objects
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                                                                                    Attr mockLangAttr = mock(Attr.class);
                                                                                                                                                    
                                                                                                                                                    // Set up mock behavior
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                    when(mockAttributes.getNamedItem("xml:lang")).thenReturn(mockLangAttr);
                                                                                                                                                    when(mockLangAttr.getNodeValue()).thenReturn("");
                                                                                                                                                    
                                                                                                                                                    // Create pointer and test
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String result = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertEquals("", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenNodeHasNoAttributes() throws Exception {
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(null); // No attributes at all
                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(null);
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String result = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    assertNull(result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenLangAttributeIsInGrandparent() throws Exception {
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Node mockParentNode = mock(Node.class);
                                                                                                                                                    Node mockGrandparentNode = mock(Node.class);
                                                                                                                                                    Node mockLangAttr = mock(Node.class);
                                                                                                                                                    
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mock(NamedNodeMap.class));
                                                                                                                                                    when(mockNode.getAttributes().getNamedItem("xml:lang")).thenReturn(null);
                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                    
                                                                                                                                                    when(mockParentNode.getAttributes()).thenReturn(mock(NamedNodeMap.class));
                                                                                                                                                    when(mockParentNode.getAttributes().getNamedItem("xml:lang")).thenReturn(null);
                                                                                                                                                    when(mockParentNode.getParentNode()).thenReturn(mockGrandparentNode);
                                                                                                                                                    
                                                                                                                                                    when(mockGrandparentNode.getAttributes()).thenReturn(mock(NamedNodeMap.class));
                                                                                                                                                    when(mockGrandparentNode.getAttributes().getNamedItem("xml:lang")).thenReturn(mockLangAttr);
                                                                                                                                                    when(mockLangAttr.getNodeValue()).thenReturn("de");
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String result = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    assertEquals("de", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenNodeIsNull() throws Exception {
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer((Node)null, (Locale)null);
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    Object result = getLanguageMethod.invoke(pointer);
                                                                                                                                                    // Optional: add assertions about the result if needed
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetValue_TextNodeDelegatesToStringValue() {
                                                                                                                                                    org.w3c.dom.Text textNode = mock(org.w3c.dom.Text.class);
                                                                                                                                                    when(textNode.getNodeType()).thenReturn(org.w3c.dom.Node.TEXT_NODE);
                                                                                                                                                    when(textNode.getNodeValue()).thenReturn("text content");
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(textNode, null);
                                                                                                                                                    
                                                                                                                                                    assertEquals("text content", pointer.getValue());
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetValue_WithNullNode() {
                                                                                                                                                    Locale locale = Locale.getDefault();
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer((Node)null, locale);
                                                                                                                                                    pointer.getValue();
                                                                                                                                                }

    @Test
                                                                                                                                                public void testStringValue_UnknownNodeType() throws Exception {
                                                                                                                                                    Node unknownNode = mock(Node.class);
                                                                                                                                                    when(unknownNode.getNodeType()).thenReturn((short) 999); // Unknown node type
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(unknownNode, Locale.getDefault());
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access private stringValue method
                                                                                                                                                    Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                    stringValueMethod.setAccessible(true);
                                                                                                                                                    String result = (String) stringValueMethod.invoke(pointer, unknownNode);
                                                                                                                                                    
                                                                                                                                                    assertEquals("", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WhenCurrentLanguageStartsWithGivenLang() throws Exception {
                                                                                                                                                    // Create a DOMNodePointer instance
                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                    org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                    org.w3c.dom.Element element = document.createElement("test");
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(element, Locale.US);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set the language value
                                                                                                                                                    java.lang.reflect.Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                                                                                    languageField.setAccessible(true);
                                                                                                                                                    languageField.set(pointer, "en-US-Windows");
                                                                                                                                                    
                                                                                                                                                    assertTrue(pointer.isLanguage("en"));
                                                                                                                                                    assertTrue(pointer.isLanguage("en-US"));
                                                                                                                                                    assertFalse(pointer.isLanguage("fr"));
                                                                                                                                                }

    @Test
                                                                                                                        public void testAsPath_ElementNode_WithParent_DefaultNamespace() throws Exception {
                                                                                                                            // Define Node.ELEMENT_NODE constant
                                                                                                                            final short ELEMENT_NODE = 1;
                                                                                                                            
                                                                                                                            // Create mock objects
                                                                                                                            org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                            NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                            // Set up parent pointer's path
                                                                                                                            when(parentPointer.asPath()).thenReturn("/parent/path");
                                                                                                                            
                                                                                                                            // Set up node type
                                                                                                                            when(mockNode.getNodeType()).thenReturn(ELEMENT_NODE);
                                                                                                                            
                                                                                                                            // Create pointer under test
                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(parentPointer, mockNode);
                                                                                                                            
                                                                                                                            // Set up namespace behavior
                                                                                                                            when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("defaultURI");
                                                                                                                            
                                                                                                                            // Set up node name and position using reflection for private method
                                                                                                                            Method getRelativePositionByName = DOMNodePointer.class.getDeclaredMethod("getRelativePositionByName");
                                                                                                                            getRelativePositionByName.setAccessible(true);
                                                                                                                            when(getRelativePositionByName.invoke(pointer)).thenReturn(1);
                                                                                                                            
                                                                                                                            when(DOMNodePointer.getLocalName(mockNode)).thenReturn("localName");
                                                                                                                            
                                                                                                                            // Verify the path construction
                                                                                                                            assertEquals("/parent/path/localName[1]", pointer.asPath());
                                                                                                                        }

    @Test
                                                                                                                        public void testAsPath_ElementNode_WithParent_PrefixedNamespace() {
                                                                                                                            // Setup mocks
                                                                                                                            
                                                                                                                            // Configure parent pointer behavior
                                                                                                                            
                                                                                                                            // Configure node behavior
                                                                                                                            
                                                                                                                            // Create pointer under test
                                                                                                                            // Configure namespace resolver behavior
                                                                                                                            
                                                                                                                            // Configure position behavior
                                                                                                                            
                                                                                                                            // Use reflection to set relative position since it's private
                                                                                                                            try {
                                                                                                                                java.lang.reflect.Field field = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredField("relativePositionByName");
                                                                                                                                field.setAccessible(true);
                                                                                                                            } catch (Exception e) {
                                                                                                                                org.junit.Assert.fail("Failed to set relative position via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                        }

    @Test
                                                                                                                        public void testAsPath_ElementNode_WithParent_NoPrefix() {
                                                                                                                            // Create mock objects
                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                            Node mockParentNode = mock(Node.class);
                                                                                                                            // Create parent pointer with a known path
                                                                                                                            DOMNodePointer parentPointer = new DOMNodePointer(mockParentNode, Locale.getDefault());
                                                                                                                            // Use reflection to set the asPath result since we can't mock it directly
                                                                                                                            try {
                                                                                                                                Field asPathField = DOMNodePointer.class.getDeclaredField("asPath");
                                                                                                                                asPathField.setAccessible(true);
                                                                                                                                asPathField.set(parentPointer, "/parent/path");
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set asPath field via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Initialize pointer under test
                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(parentPointer, mockNode);
                                                                                                                            
                                                                                                                            // Set up mock behaviors
                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                            
                                                                                                                            // Set parent's namespace resolver
                                                                                                                            try {
                                                                                                                                Field nsResolverField = DOMNodePointer.class.getDeclaredField("namespaceResolver");
                                                                                                                                nsResolverField.setAccessible(true);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set namespace resolver via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Use reflection to set the relative position since it's private
                                                                                                                            try {
                                                                                                                                Field field = DOMNodePointer.class.getDeclaredField("relativePosition");
                                                                                                                                field.setAccessible(true);
                                                                                                                                field.set(pointer, 3);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set relative position via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Mock static method behavior using spy
                                                                                                                            DOMNodePointer spyPointer = spy(pointer);
                                                                                                                            when(spyPointer.getNamespaceURI()).thenReturn("customURI");
                                                                                                                            when(spyPointer.getLocalName(mockNode)).thenReturn("localName");
                                                                                                                            
                                                                                                                            // Verify the path construction
                                                                                                                            assertEquals("/parent/path/node()[3]", spyPointer.asPath());
                                                                                                                        }

    @Test
                                                                                                                        public void testAsPath_ElementNode_NoParent() {
                                                                                                                            // Setup mocks
                                                                                                                            org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                            // Configure mocks
                                                                                                                            when(mockNode.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                            
                                                                                                                            // Create test object - using parent=null since we're testing no parent case
                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(null, mockNode);
                                                                                                                            
                                                                                                                            // Use reflection to set private fields since we can't mock them directly
                                                                                                                            try {
                                                                                                                                Field nsResolverField = DOMNodePointer.class.getDeclaredField("namespaceResolver");
                                                                                                                                nsResolverField.setAccessible(true);
                                                                                                                                
                                                                                                                                Field relativePositionField = DOMNodePointer.class.getDeclaredField("relativePositionByName");
                                                                                                                                relativePositionField.setAccessible(true);
                                                                                                                                relativePositionField.set(pointer, 1);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set private fields via reflection: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Mock static method call
                                                                                                                            mockStatic(DOMNodePointer.class);
                                                                                                                            when(DOMNodePointer.getLocalName(mockNode)).thenReturn("localName");
                                                                                                                            
                                                                                                                            // Mock namespace resolution
                                                                                                                            
                                                                                                                            // Test and verify
                                                                                                                            assertEquals("/localName[1]", pointer.asPath());
                                                                                                                            
                                                                                                                            // Clean up static mocking
                                                                                                                            DOMNodePointer.getLocalName(mockNode);
                                                                                                                            reset(DOMNodePointer.class);
                                                                                                                        }

    @Test
                                                                                                                        public void testAsPath_ElementNode_ParentEndsWithSlash() {
                                                                                                                            // Create mock objects
                                                                                                                            org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                            DOMNodePointer parentWithSlash = mock(DOMNodePointer.class);
                                                                                                                            // Set up mock behavior
                                                                                                                            when(mockNode.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                            when(parentWithSlash.asPath()).thenReturn("/parent/path/");
                                                                                                                            
                                                                                                                            // Create real pointer with mocked parent
                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(parentWithSlash, mockNode);
                                                                                                                            
                                                                                                                            // Mock namespace behavior
                                                                                                                            when(pointer.getNamespaceURI()).thenReturn("defaultURI");
                                                                                                                            
                                                                                                                            // Use reflection to set private field for relative position
                                                                                                                            try {
                                                                                                                                Field field = DOMNodePointer.class.getDeclaredField("relativePositionByName");
                                                                                                                                field.setAccessible(true);
                                                                                                                                field.set(pointer, 1);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set relative position via reflection: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Mock static method call using CALLS_REAL_METHODS for the spy
                                                                                                                            DOMNodePointer spyPointer = spy(pointer);
                                                                                                                            when(spyPointer.getLocalName(mockNode)).thenReturn("localName");
                                                                                                                            
                                                                                                                            assertEquals("/parent/path/localName[1]", spyPointer.asPath());
                                                                                                                        }

    @Test
                                                                                                                        public void testGetValue_ElementNodeDelegatesToStringValue() throws Exception {
                                                                                                                            // Create a real element node instead of mocking
                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                            org.w3c.dom.Document document = builder.newDocument();
                                                                                                                            org.w3c.dom.Element element = document.createElement("test");
                                                                                                                            element.appendChild(document.createTextNode("element value"));
                                                                                                                            
                                                                                                                            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(element, null);
                                                                                                                            
                                                                                                                            // Test that getValue() returns the expected string value
                                                                                                                            assertEquals("element value", pointer.getValue());
                                                                                                                        }

    @Test
                                                                                                                        public void testStringValue_ElementWithChildren() throws Exception {
                                                                                                                            // Mock the element node
                                                                                                                            org.w3c.dom.Node elementNode = mock(org.w3c.dom.Node.class);
                                                                                                                            when(elementNode.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                            
                                                                                                                            // Mock child nodes
                                                                                                                            org.w3c.dom.NodeList childNodes = mock(org.w3c.dom.NodeList.class);
                                                                                                                            when(elementNode.getChildNodes()).thenReturn(childNodes);
                                                                                                                            when(childNodes.getLength()).thenReturn(3);
                                                                                                                            
                                                                                                                            // First child - text node
                                                                                                                            org.w3c.dom.Text textChild = mock(org.w3c.dom.Text.class);
                                                                                                                            when(childNodes.item(0)).thenReturn(textChild);
                                                                                                                            when(textChild.getNodeType()).thenReturn(org.w3c.dom.Node.TEXT_NODE);
                                                                                                                            when(textChild.getNodeValue()).thenReturn("text");
                                                                                                                            
                                                                                                                            // Second child - element node
                                                                                                                            org.w3c.dom.Node elementChild = mock(org.w3c.dom.Node.class);
                                                                                                                            when(childNodes.item(1)).thenReturn(elementChild);
                                                                                                                            when(elementChild.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                            org.w3c.dom.NodeList emptyList = mock(org.w3c.dom.NodeList.class);
                                                                                                                            when(elementChild.getChildNodes()).thenReturn(emptyList);
                                                                                                                            when(emptyList.getLength()).thenReturn(0);
                                                                                                                            
                                                                                                                            // Third child - processing instruction
                                                                                                                            org.w3c.dom.ProcessingInstruction piChild = mock(org.w3c.dom.ProcessingInstruction.class);
                                                                                                                            when(childNodes.item(2)).thenReturn(piChild);
                                                                                                                            when(piChild.getNodeType()).thenReturn(org.w3c.dom.Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                            when(piChild.getData()).thenReturn("data");
                                                                                                                            
                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(elementNode, null);
                                                                                                                            
                                                                                                                            // Use reflection to access private stringValue method
                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", org.w3c.dom.Node.class);
                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                            String result = (String) stringValueMethod.invoke(pointer, elementNode);
                                                                                                                            
                                                                                                                            assertEquals("textdata", result);
                                                                                                                        }

    @Test
                                                                                                                        public void testIsLanguage_WhenCurrentLanguageIsNull_DelegatesToSuper() {
                                                                                                                            // Create a DOMNodePointer instance with mock node and locale
                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                            Locale locale = Locale.ENGLISH;
                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                            
                                                                                                                            // Create a spy of the pointer
                                                                                                                            DOMNodePointer spyPointer = spy(pointer);
                                                                                                                            
                                                                                                                            // Mock protected getLanguage() method to return null
                                                                                                                            try {
                                                                                                                                Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                getLanguageMethod.setAccessible(true);
                                                                                                                                // Use reflection to set the return value
                                                                                                                                when((String)getLanguageMethod.invoke(spyPointer)).thenReturn(null);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to mock protected getLanguage() method");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Mock super.isLanguage() behavior
                                                                                                                            when(spyPointer.isLanguage("en")).thenCallRealMethod();
                                                                                                                            when(spyPointer.isLanguage("fr")).thenCallRealMethod();
                                                                                                                            doReturn(true).when((NodePointer)spyPointer).isLanguage("en");
                                                                                                                            doReturn(false).when((NodePointer)spyPointer).isLanguage("fr");
                                                                                                                            
                                                                                                                            assertTrue(spyPointer.isLanguage("en"));
                                                                                                                            assertFalse(spyPointer.isLanguage("fr"));
                                                                                                                        }

    @Test
                                        public void testIsLanguage_WithEmptyString() throws Exception {
                                            // Create a mock Node and Locale
                                            Node mockNode = mock(Node.class);
                                            Locale locale = Locale.US;
                                            
                                            // Create a DOMNodePointer instance
                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                            
                                            // Create spy
                                            DOMNodePointer spyPointer = spy(pointer);
                                            
                                            // Create a mock for the protected getLanguage() method
                                            Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                            getLanguageMethod.setAccessible(true);
                                            
                                            // First test case: current language is "en-US"
                                            when(getLanguageMethod.invoke(spyPointer)).thenReturn("en-US");
                                            assertFalse(spyPointer.isLanguage(""));
                                            
                                            // Second test case: current language is empty
                                            when(getLanguageMethod.invoke(spyPointer)).thenReturn("");
                                            assertTrue(spyPointer.isLanguage(""));
                                        }

    @Test
                                        public void testStringValue_TextNode_PreserveWhitespace() throws Exception {
                                            // Create mock document
                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                            org.w3c.dom.Document document = builder.newDocument();
                                            
                                            // Create parent element with xml:space="preserve"
                                            org.w3c.dom.Element parent = document.createElement("parent");
                                            parent.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
                                            
                                            // Create text node with whitespace
                                            org.w3c.dom.Text textNode = document.createTextNode("  text with spaces  ");
                                            parent.appendChild(textNode);
                                            
                                            // Create DOMNodePointer
                                            DOMNodePointer pointer = new DOMNodePointer(parent, java.util.Locale.getDefault());
                                            
                                            // Use reflection to access private stringValue method
                                            java.lang.reflect.Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", org.w3c.dom.Node.class);
                                            stringValueMethod.setAccessible(true);
                                            
                                            // Invoke the method
                                            String result = (String) stringValueMethod.invoke(pointer, textNode);
                                            
                                            // Verify whitespace is preserved
                                            assertEquals("  text with spaces  ", result);
                                        }


}
