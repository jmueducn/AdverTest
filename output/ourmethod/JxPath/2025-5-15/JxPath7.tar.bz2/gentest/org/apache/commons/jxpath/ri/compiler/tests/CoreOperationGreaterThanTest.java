package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
 
public class CoreOperationGreaterThanTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testGetSymbol_ReturnsGreaterThanSymbol() {
                // Arrange
                Expression mockExpr1 = mock(Expression.class);
                Expression mockExpr2 = mock(Expression.class);
                CoreOperationGreaterThan operation = new CoreOperationGreaterThan(mockExpr1, mockExpr2);
                
                // Act
                String result = operation.getSymbol();
                
                // Assert
                assertEquals(">", result);
            }

    @Test
            public void testGetSymbol_ReturnsConsistentValue() {
                // Arrange
                Expression mockExpr1 = mock(Expression.class);
                Expression mockExpr2 = mock(Expression.class);
                CoreOperationGreaterThan operation = new CoreOperationGreaterThan(mockExpr1, mockExpr2);
                
                // Act & Assert
                assertEquals(">", operation.getSymbol());
                assertEquals(">", operation.getSymbol()); // Multiple calls return same value
                assertEquals(">", operation.getSymbol());
            }

    @Test
            public void testGetSymbol_ReturnsNonNull() {
                // Arrange
                Expression mockExpr1 = mock(Expression.class);
                Expression mockExpr2 = mock(Expression.class);
                CoreOperationGreaterThan operation = new CoreOperationGreaterThan(mockExpr1, mockExpr2);
                
                // Act
                String result = operation.getSymbol();
                
                // Assert
                assertNotNull(result);
            }

    @Test
    public void testEvaluateCompare_PositiveNumber() throws Exception {
        CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
        
        // Get the protected method via reflection
        Method evaluateCompare = CoreOperationGreaterThan.class.getDeclaredMethod(
            "evaluateCompare", int.class);
        evaluateCompare.setAccessible(true);
        
        // Test with various positive numbers
        assertTrue((Boolean)evaluateCompare.invoke(operation, 1));
        assertTrue((Boolean)evaluateCompare.invoke(operation, 100));
        assertTrue((Boolean)evaluateCompare.invoke(operation, Integer.MAX_VALUE));
    }

    @Test
    public void testEvaluateCompare_NegativeNumber() throws Exception {
        CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
        
        // Get the protected evaluateCompare method
        Method evaluateCompareMethod = CoreOperationGreaterThan.class.getDeclaredMethod("evaluateCompare", int.class);
        evaluateCompareMethod.setAccessible(true);
        
        // Test with various negative numbers
        assertFalse((Boolean) evaluateCompareMethod.invoke(operation, -1));
        assertFalse((Boolean) evaluateCompareMethod.invoke(operation, -100));
        assertFalse((Boolean) evaluateCompareMethod.invoke(operation, Integer.MIN_VALUE));
    }

    @Test
    public void testEvaluateCompare_Zero() throws Exception {
        CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
        Method method = CoreOperationGreaterThan.class.getDeclaredMethod("evaluateCompare", int.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(operation, 0);
        assertFalse(result);
    }

    @Test
    public void testEvaluateCompare_BoundaryValues() throws Exception {
        CoreOperationGreaterThan operation = new CoreOperationGreaterThan(null, null);
        
        // Get the protected method using reflection
        Method evaluateCompare = CoreOperationGreaterThan.class.getDeclaredMethod("evaluateCompare", int.class);
        evaluateCompare.setAccessible(true);
        
        // Test just above and below zero
        assertTrue((Boolean)evaluateCompare.invoke(operation, 1));
        assertFalse((Boolean)evaluateCompare.invoke(operation, -1));
        
        // Test max and min integer values
        assertTrue((Boolean)evaluateCompare.invoke(operation, Integer.MAX_VALUE));
        assertFalse((Boolean)evaluateCompare.invoke(operation, Integer.MIN_VALUE));
        
        // Test values close to zero (note: these were duplicates of max/min, changed to test near-zero)
        assertTrue((Boolean)evaluateCompare.invoke(operation, 1));
        assertFalse((Boolean)evaluateCompare.invoke(operation, -1));
    }


}
