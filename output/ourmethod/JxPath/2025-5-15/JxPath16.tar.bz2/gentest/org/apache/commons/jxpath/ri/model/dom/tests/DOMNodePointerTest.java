package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NullTest() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(null));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NodeNameTest_NonElementNode() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getNodeName()).thenReturn(new QName("test"));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NodeNameTest_WildcardNoPrefix() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                when(mockTest.isWildcard()).thenReturn(true);
                                                                                                                                                                                                                                                                when(mockTest.getNodeName()).thenReturn(new QName(null, "test"));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NodeNameTest_MatchingNameAndNamespace() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                when(DOMNodePointer.getLocalName(mockNode)).thenReturn("test");
                                                                                                                                                                                                                                                                when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("http://example.com");
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getNodeName()).thenReturn(new QName("prefix", "test"));
                                                                                                                                                                                                                                                                when(mockTest.getNamespaceURI()).thenReturn("http://example.com");
                                                                                                                                                                                                                                                                when(mockTest.isWildcard()).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NodeNameTest_MatchingNameNullNamespace() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                when(DOMNodePointer.getLocalName(mockNode)).thenReturn("test");
                                                                                                                                                                                                                                                                when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn(null);
                                                                                                                                                                                                                                                                when(DOMNodePointer.getPrefix(mockNode)).thenReturn("prefix");
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getNodeName()).thenReturn(new QName("prefix", "test"));
                                                                                                                                                                                                                                                                when(mockTest.getNamespaceURI()).thenReturn(null);
                                                                                                                                                                                                                                                                when(mockTest.isWildcard()).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NodeTypeTest_NodeType() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NodeTypeTest_TextType() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_TEXT);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NodeTypeTest_CommentType() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_COMMENT);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_NodeTypeTest_PIType() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_PI);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_ProcessingInstructionTest_MatchingTarget() {
                                                                                                                                                                                                                                                                ProcessingInstruction mockPI = mock(ProcessingInstruction.class);
                                                                                                                                                                                                                                                                when(mockPI.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                when(mockPI.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockPI, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_ProcessingInstructionTest_NonMatchingTarget() {
                                                                                                                                                                                                                                                                ProcessingInstruction mockPI = mock(ProcessingInstruction.class);
                                                                                                                                                                                                                                                                when(mockPI.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                when(mockPI.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getTarget()).thenReturn("other-target");
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockPI, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_ProcessingInstructionTest_NonPINode() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                when(mockTest.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testTestNode_UnknownTestType() {
                                                                                                                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                NodeTest mockTest = mock(NodeTest.class);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                    public void testTestNode_WithNullNode() {
                                                                                                                                                                                                                                                        NodeTest mockTest = mock(NodeTest.class);
                                                                                                                                                                                                                                                        assertFalse(DOMNodePointer.testNode(null, mockTest));
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testTestNode_WithNullTest() {
                                                                                                                                                                                                                                                        Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                        assertFalse(DOMNodePointer.testNode(mockNode, null));
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_AttributeFoundInCurrentNode() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        String attrName = "testAttr";
                                                                                                                                                                                                                                                        String expectedValue = "testValue";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element mockElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(mockElement.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                                                                                                                        when(mockNode.getParentNode()).thenReturn(null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access the protected method
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, mockNode, attrName);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertEquals(expectedValue, result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_AttributeFoundInParentNode() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        String attrName = "testAttr";
                                                                                                                                                                                                                                                        String expectedValue = "parentValue";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node childNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(childNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element childElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(childElement.getAttribute(attrName)).thenReturn("");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node parentNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element parentElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(parentElement.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        when(childNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                                                                                                                        when(parentNode.getParentNode()).thenReturn(null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, childNode, attrName);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertEquals(expectedValue, result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_AttributeNotFound() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        String attrName = "nonExistentAttr";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element mockElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(mockElement.getAttribute(attrName)).thenReturn("");
                                                                                                                                                                                                                                                        when(mockNode.getParentNode()).thenReturn(null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                            "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, mockNode, attrName);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertNull(result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_NonElementNodesInHierarchy() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        String attrName = "testAttr";
                                                                                                                                                                                                                                                        String expectedValue = "foundValue";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node textNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node parentNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element parentElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(parentElement.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        when(textNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                                                                                                                        when(parentNode.getParentNode()).thenReturn(null);
                                                                                                                                                                                                                                                        when(parentNode).thenReturn(parentElement);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, textNode, attrName);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertEquals(expectedValue, result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_NullNodeInput() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        String attrName = "testAttr";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Get the protected method via reflection
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, null, attrName);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertNull(result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_NullAttrNameInput() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Get the protected method via reflection
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                            "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, mockNode, null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertNull(result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_EmptyAttrNameInput() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element mockElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(mockElement.getAttribute("")).thenReturn("someValue");
                                                                                                                                                                                                                                                        when(mockNode.getParentNode()).thenReturn(null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Get the protected method via reflection
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, mockNode, "");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertEquals("someValue", result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_AttributeInGrandParentNode() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        String attrName = "testAttr";
                                                                                                                                                                                                                                                        String expectedValue = "grandParentValue";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node childNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(childNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element childElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(childElement.getAttribute(attrName)).thenReturn("");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node parentNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element parentElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(parentElement.getAttribute(attrName)).thenReturn("");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node grandParentNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(grandParentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element grandParentElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(grandParentElement.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        when(childNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                                                                                                                        when(parentNode.getParentNode()).thenReturn(grandParentNode);
                                                                                                                                                                                                                                                        when(grandParentNode.getParentNode()).thenReturn(null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, childNode, attrName);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertEquals(expectedValue, result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testFindEnclosingAttribute_MultipleAttributesInHierarchy() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        String attrName = "testAttr";
                                                                                                                                                                                                                                                        String expectedValue = "firstFoundValue";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node childNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(childNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element childElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(childElement.getAttribute(attrName)).thenReturn("");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node parentNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element parentElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(parentElement.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Node grandParentNode = mock(Node.class);
                                                                                                                                                                                                                                                        when(grandParentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Element grandParentElement = mock(Element.class);
                                                                                                                                                                                                                                                        when(grandParentElement.getAttribute(attrName)).thenReturn("shouldNotReturnThis");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        when(childNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                                                                                                                        when(parentNode.getParentNode()).thenReturn(grandParentNode);
                                                                                                                                                                                                                                                        when(grandParentNode.getParentNode()).thenReturn(null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access the protected method
                                                                                                                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                                                                                                        String result = (String) method.invoke(null, childNode, attrName);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                        assertEquals(expectedValue, result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                        public void testTestNode_WhenTestReturnsFalse() {
                                                                                                                                                                                                            // Create mocks
                                                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                                                            NodeTest mockTest = mock(NodeTest.class);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Set up mock behavior to return false
                                                                                                                                                                                                            when(DOMNodePointer.testNode(mockNode, mockTest)).thenReturn(false);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test static method
                                                                                                                                                                                                            org.junit.Assert.assertFalse(org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(mockNode, mockTest));
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                    public void testTestNode_WhenTestReturnsTrue() {
                                                                                                                                                                                                        // Create mock objects
                                                                                                                                                                                                        Node mockNode = mock(Node.class);
                                                                                                                                                                                                        NodeTest mockTest = mock(NodeTest.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Set up mock behavior - make testNode return true
                                                                                                                                                                                                        when(DOMNodePointer.testNode(mockNode, mockTest)).thenReturn(true);
                                                                                                                                                                                                    
                                                                                                                                                                                                        // Call the static method and assert
                                                                                                                                                                                                        assertTrue(DOMNodePointer.testNode(mockNode, mockTest));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testTestNode_WithDifferentPointerInstances() throws Exception {
                                                                                                                                                                    // Create mock document
                                                                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                    org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                                    
                                                                                                                                                                    // Create test nodes
                                                                                                                                                                    final org.w3c.dom.Node node1 = document.createElement("test1");
                                                                                                                                                                    final org.w3c.dom.Node node2 = document.createElement("test2");
                                                                                                                                                                    
                                                                                                                                                                    // Create NodeTest that returns different results for different nodes
                                                                                                                                                                    org.apache.commons.jxpath.ri.compiler.NodeTest mockTest = new org.apache.commons.jxpath.ri.compiler.NodeTest() {
                                                                                                                                                                        public boolean isWildcard() {
                                                                                                                                                                            return false;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        public org.apache.commons.jxpath.ri.QName getName() {
                                                                                                                                                                            return null;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        public boolean testNode(org.apache.commons.jxpath.ri.model.NodePointer pointer) {
                                                                                                                                                                            if (pointer.getNode() == node1) {
                                                                                                                                                                                return true;
                                                                                                                                                                            } else if (pointer.getNode() == node2) {
                                                                                                                                                                                return false;
                                                                                                                                                                            }
                                                                                                                                                                            return false;
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        public double getPriority() {
                                                                                                                                                                            return 0.5; // Default priority
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public String toString() {
                                                                                                                                                                            return "TestNode";
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        public boolean isCollection() {
                                                                                                                                                                            return false;
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        public boolean isLeaf() {
                                                                                                                                                                            return false;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    // Create pointers
                                                                                                                                                                    org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer1 = 
                                                                                                                                                                        new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node1, null);
                                                                                                                                                                    org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer2 = 
                                                                                                                                                                        new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node2, null);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    assertTrue(pointer1.testNode(mockTest));
                                                                                                                                                                    assertFalse(pointer2.testNode(mockTest));
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testTestNode_InstanceMethodDelegatesToStaticMethod() {
                                                                                                                                                            // Create mock objects
                                                                                                                                                            org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                                                            org.apache.commons.jxpath.ri.compiler.NodeTest mockTest = mock(org.apache.commons.jxpath.ri.compiler.NodeTest.class);
                                                                                                                                                            
                                                                                                                                                            // Create pointer instance
                                                                                                                                                            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                                                new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, java.util.Locale.getDefault());
                                                                                                                                                            
                                                                                                                                                            // Mock the static method
                                                                                                                                                            try (org.mockito.MockedStatic<org.apache.commons.jxpath.ri.model.dom.DOMNodePointer> mocked = 
                                                                                                                                                                    mockStatic(org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class)) {
                                                                                                                                                                mocked.when(() -> org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(mockNode, mockTest))
                                                                                                                                                                    .thenReturn(true);
                                                                                                                                                                
                                                                                                                                                                // Test and assert
                                                                                                                                                                assertTrue(pointer.testNode(mockTest));
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testTestNode_WithExceptionInTest() {
                                                                                                                                                        // Setup mock objects
                                                                                                                                                        Node mockNode = mock(Node.class);
                                                                                                                                                        NodeTest mockTest = mock(NodeTest.class);
                                                                                                                                                        
                                                                                                                                                        // Configure mock to throw exception
                                                                                                                                                        when(mockTest.toString()).thenReturn("Test error");
                                                                                                                                                        when(DOMNodePointer.testNode(mockNode, mockTest))
                                                                                                                                                            .thenThrow(new RuntimeException("Test error"));
                                                                                                                                                        
                                                                                                                                                        // Verify exception
                                                                                                                                                        try {
                                                                                                                                                            DOMNodePointer.testNode(mockNode, mockTest);
                                                                                                                                                            fail("Expected RuntimeException");
                                                                                                                                                        } catch (RuntimeException e) {
                                                                                                                                                            assertEquals("Test error", e.getMessage());
                                                                                                                                                        }
                                                                                                                                                    }

    @Test
                                                                                        public void testTestNode_WithDifferentNodeTypes() {
                                                                                            // Mock objects
                                                                                            org.w3c.dom.Element elementNode = mock(org.w3c.dom.Element.class);
                                                                                            org.w3c.dom.Text textNode = mock(org.w3c.dom.Text.class);
                                                                                            org.w3c.dom.Comment commentNode = mock(org.w3c.dom.Comment.class);
                                                                                            // Mock NodeTest behavior to test for element nodes
                                                                                            
                                                                                            // Create DOMNodePointer for element node
                                                                                            DOMNodePointer pointer = 
                                                                                                new DOMNodePointer(elementNode, java.util.Locale.getDefault());
                                                                                            
                                                                                            // Verify test results using instance method
                                                                                            
                                                                                            // Test other nodes by creating new pointers
                                                                                            DOMNodePointer textPointer = 
                                                                                                new DOMNodePointer(textNode, java.util.Locale.getDefault());
                                                                                            
                                                                                            DOMNodePointer commentPointer = 
                                                                                                new DOMNodePointer(commentNode, java.util.Locale.getDefault());
                                                                                        }

    @Test
                                                                                   public void testIsLanguage_ShouldCheckCurrentLanguage_WhenGetLanguageReturnsNonNull() throws Exception {
                                                                                       // Arrange
                                                                                       Node mockNode = mock(Node.class);
                                                                                       DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                                                                       
                                                                                       // Use reflection to set the language value
                                                                                       Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                       languageField.setAccessible(true);
                                                                                       languageField.set(pointer, "en-US");
                                                                                       
                                                                                       // Act & Assert
                                                                                       // Test with matching language prefix
                                                                                       assertTrue(pointer.isLanguage("en"));
                                                                                       
                                                                                       // Test with non-matching language prefix
                                                                                       assertFalse(pointer.isLanguage("fr"));
                                                                                   }

    @Test
                                                                              public void testIsLanguage_CurrentLanguageNotNull_ShouldCompareLanguages() throws Exception {
                                                                                  // Setup
                                                                                  Node mockNode = mock(Node.class);
                                                                                  DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                                                                  
                                                                                  // Set protected language field using reflection
                                                                                  Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                  languageField.setAccessible(true);
                                                                                  languageField.set(pointer, "en-US");
                                                                                  
                                                                                  // Test with matching language prefix
                                                                                  boolean result1 = pointer.isLanguage("EN");
                                                                                  assertTrue("Should return true when language matches", result1);
                                                                                  
                                                                                  // Test with non-matching language prefix
                                                                                  boolean result2 = pointer.isLanguage("FR");
                                                                                  assertFalse("Should return false when language doesn't match", result2);
                                                                                  
                                                                                  // Verify the mutant would fail these assertions
                                                                                  // because it would always call super.isLanguage() instead
                                                                              }

    @Test
                                                                         public void testIsLanguageDetectsMutant() {
                                                                             // Setup
                                                                             DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                             
                                                                             // Use reflection to set the language since getLanguage() is protected
                                                                             try {
                                                                                 Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                 languageField.setAccessible(true);
                                                                                 languageField.set(pointer, "EN-US");
                                                                             } catch (Exception e) {
                                                                                 fail("Failed to set language field via reflection");
                                                                             }
                                                                             
                                                                             // Mock the super.isLanguage() to always return false to isolate our test
                                                                             when(pointer.isLanguage(anyString())).thenCallRealMethod();
                                                                             
                                                                             // Test case 1: Partial match with different case - should pass original but fail mutant
                                                                             assertTrue("Should match case-insensitive partial language", 
                                                                                 pointer.isLanguage("en"));
                                                                             
                                                                             // Test case 2: Full match with different case - should pass original but fail mutant
                                                                             assertTrue("Should match case-insensitive full language", 
                                                                                 pointer.isLanguage("en-us"));
                                                                             
                                                                             // Test case 3: Non-matching language - should fail both
                                                                             assertFalse("Should not match different language", 
                                                                                 pointer.isLanguage("fr"));
                                                                         }

    @Test
                                                                    public void testIsLanguageDetectsMutant1() throws Exception {
                                                                        // Create a real DOMNodePointer with a mock node
                                                                        Node mockNode = mock(Node.class);
                                                                        DOMNodePointer pointer = spy(new DOMNodePointer(mockNode, Locale.US));
                                                                        
                                                                        // Use reflection to set the language field
                                                                        Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                        languageField.setAccessible(true);
                                                                        
                                                                        // Test case 1: Matching language prefix (should return true)
                                                                        languageField.set(pointer, "en-US");
                                                                        assertTrue(pointer.isLanguage("en"));
                                                                        
                                                                        // Test case 2: Non-matching language (should return false)
                                                                        assertFalse(pointer.isLanguage("fr"));
                                                                        
                                                                        // Test case 3: getLanguage() returns null (should delegate to parent)
                                                                        languageField.set(pointer, null);
                                                                        DOMNodePointer parentPointer = mock(DOMNodePointer.class);
                                                                        when(parentPointer.isLanguage(anyString())).thenReturn(false);
                                                                        
                                                                        Field parentField = NodePointer.class.getDeclaredField("parent");
                                                                        parentField.setAccessible(true);
                                                                        parentField.set(pointer, parentPointer);
                                                                        
                                                                        assertFalse(pointer.isLanguage("en"));
                                                                        
                                                                        // The mutant would fail these tests because:
                                                                        // 1. It would always delegate to parent due to getLanguage() returning null
                                                                        // 2. The language comparison would never happen
                                                                        // 3. The results would depend solely on parent implementation
                                                                    }

    @Test
                                                               public void testIsLanguageWithActualLanguageAttribute() throws Exception {
                                                                   // Setup test node with language attribute
                                                                   Element mockElement = mock(Element.class);
                                                                   when(mockElement.getAttribute("lang")).thenReturn("en-US");
                                                                   
                                                                   Node mockNode = mock(Node.class);
                                                                   when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                   when(((Element)mockNode).getAttribute("lang")).thenReturn("en-US");
                                                                   
                                                                   // Create test subclass that exposes getLanguage()
                                                                   class TestDOMNodePointer extends DOMNodePointer {
                                                                       public TestDOMNodePointer(Node node, Locale locale) {
                                                                           super(node, locale);
                                                                       }
                                                                       
                                                                       @Override
                                                                       public String getLanguage() {
                                                                           return super.getLanguage();
                                                                       }
                                                                   }
                                                                   
                                                                   // Create pointer with test subclass
                                                                   TestDOMNodePointer pointer = new TestDOMNodePointer(mockNode, Locale.US);
                                                                   
                                                                   // Test original behavior - should return true for matching language prefix
                                                                   assertTrue(pointer.isLanguage("en"));
                                                                   
                                                                   // Now test with node that has no language attribute
                                                                   when(mockElement.getAttribute("lang")).thenReturn("");
                                                                   when(((Element)mockNode).getAttribute("lang")).thenReturn("");
                                                                   
                                                                   // Should return false when no language is set
                                                                   assertFalse(pointer.isLanguage("en"));
                                                                   
                                                                   // Additional edge case - empty language parameter
                                                                   assertFalse(pointer.isLanguage(""));
                                                               }

    @Test
                                                          public void testIsLanguageWithEmptyOrNullAttributes() throws Exception {
                                                              // Setup
                                                              Node mockNode = mock(Node.class);
                                                              DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                              
                                                              // Use reflection to set language field
                                                              Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                              languageField.setAccessible(true);
                                                              
                                                              // Test null language case - should delegate to parent
                                                              languageField.set(pointer, null);
                                                              assertFalse(pointer.isLanguage("en"));
                                                              
                                                              // Test empty string case - should not match any language
                                                              languageField.set(pointer, "");
                                                              assertFalse(pointer.isLanguage("en"));
                                                              
                                                              // Test valid language case - should match prefix
                                                              languageField.set(pointer, "en-US");
                                                              assertTrue(pointer.isLanguage("en"));
                                                              
                                                              // Test whitespace case - should not match any language
                                                              languageField.set(pointer, "   ");
                                                              assertFalse(pointer.isLanguage("en"));
                                                          }

    @Test
                                                      public void testIsLanguage_WhenLanguageExists_ShouldCompareStrings() {
                                                          // Setup
                                                          Node mockNode = mock(Node.class);
                                                          DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH) {
                                                              @Override
                                                              protected String getLanguage() {
                                                                  // Original should return actual language, mutant returns null
                                                                  return "en-US"; // non-null value to test the comparison logic
                                                              }
                                                          };
                                                          
                                                          // Test cases where comparison should happen
                                                          assertTrue(pointer.isLanguage("en")); // should match prefix
                                                          assertTrue(pointer.isLanguage("EN")); // should be case insensitive
                                                          assertFalse(pointer.isLanguage("fr")); // should not match different language
                                                          
                                                          // The mutant would fail these assertions because it would always delegate to super
                                                      }

    @Test
                                                    public void testIsLanguage_ShouldCompareLanguages_WhenCurrentLanguageExists() {
                                                        // Create a test subclass that exposes getLanguage()
                                                        class TestDOMNodePointer extends DOMNodePointer {
                                                            private final String language;
                                                            
                                                            public TestDOMNodePointer(Node node, Locale locale, String language) {
                                                                super(node, locale);
                                                                this.language = language;
                                                            }
                                                            
                                                            @Override
                                                            protected String getLanguage() {
                                                                return language;
                                                            }
                                                        }
                                                        
                                                        // Setup
                                                        Node mockNode = mock(Node.class);
                                                        DOMNodePointer pointer = new TestDOMNodePointer(mockNode, Locale.ENGLISH, "en-US");
                                                        
                                                        // Test cases where comparison should happen
                                                        assertTrue(pointer.isLanguage("en"));      // Should match prefix
                                                        assertTrue(pointer.isLanguage("EN"));     // Should be case insensitive
                                                        assertFalse(pointer.isLanguage("fr"));    // Should not match different language
                                                    }

    @Test
                                           public void testIsLanguageWhenCurrentLanguageIsNull() {
                                               // Setup
                                               Node mockNode = mock(Node.class);
                                               DOMNodePointer pointer = spy(new DOMNodePointer(mockNode, Locale.ENGLISH));
                                               
                                               // Use reflection to set language to null
                                               try {
                                                   Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                   languageField.setAccessible(true);
                                                   languageField.set(pointer, null);
                                               } catch (Exception e) {
                                                   fail("Failed to set language field via reflection");
                                               }
                                               
                                               // Mock parent behavior
                                               DOMNodePointer parent = mock(DOMNodePointer.class);
                                               when(parent.isLanguage("en")).thenReturn(true);
                                               when(pointer.getParent()).thenReturn(parent);
                                               
                                               // Test - should delegate to parent when current language is null
                                               boolean result = pointer.isLanguage("en");
                                               
                                               // Verify
                                               assertTrue(result);
                                               verify(parent).isLanguage("en");
                                               
                                               // Also verify no NPE was thrown (implicit in reaching assertions)
                                           }

    @Test
                                      public void testIsLanguage_NullCase() throws Exception {
                                          // Create mock Node
                                          Node mockNode = mock(Node.class);
                                          // Create DOMNodePointer instance
                                          DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                          
                                          // Use reflection to set language behavior since getLanguage() is protected
                                          Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                          getLanguageMethod.setAccessible(true);
                                          
                                          // Mock the getLanguage() to return null
                                          when(getLanguageMethod.invoke(pointer)).thenReturn(null);
                                          
                                          // Test that isLanguage returns false when getLanguage() is null
                                          assertFalse(pointer.isLanguage("EN"));
                                      }

    @Test
                                      public void testIsLanguage_ExactMatch() {
                                          // Create mock Node
                                          Node mockNode = mock(Node.class);
                                          // Create DOMNodePointer with English locale
                                          DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                          
                                          // Use reflection to set the language since getLanguage() is protected
                                          try {
                                              Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                              getLanguageMethod.setAccessible(true);
                                              Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                              languageField.setAccessible(true);
                                              languageField.set(pointer, "EN");
                                          } catch (Exception e) {
                                              fail("Failed to set language through reflection: " + e.getMessage());
                                          }
                                          
                                          // Should pass both original and mutant for exact match
                                          assertTrue(pointer.isLanguage("EN"));
                                      }

    @Test
                                  public void testIsLanguage_StartsWithBehavior() {
                                      // Create mock objects
                                      Node mockNode = mock(Node.class);
                                      
                                      // Create a real DOMNodePointer instance
                                      DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US) {
                                          // Override protected method to return our test value
                                          @Override
                                          protected String getLanguage() {
                                              return "EN-US";
                                          }
                                      };
                                      
                                      // Test case that should pass original but fail mutant
                                      assertTrue(pointer.isLanguage("EN"));  // Original: true, Mutant: false
                                      
                                      // Test case that should fail original but pass mutant
                                      assertFalse(pointer.isLanguage("US")); // Original: false, Mutant: true
                                  }

    @Test
                                  public void testIsLanguage_EndsWithBehavior() {
                                      // Create required mocks and objects
                                      Node mockNode = mock(Node.class);
                                      Locale locale = Locale.US;
                                      DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                      
                                      // Create a spy and use reflection to set the language value
                                      DOMNodePointer spyPointer = spy(pointer);
                                      try {
                                          Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                          getLanguageMethod.setAccessible(true);
                                          when(getLanguageMethod.invoke(spyPointer)).thenReturn("US-EN");
                                      } catch (Exception e) {
                                          fail("Failed to set up language mock via reflection: " + e.getMessage());
                                      }
                                      
                                      // Test case that should fail original but pass mutant
                                      assertFalse(spyPointer.isLanguage("EN")); // Original: false, Mutant: true
                                      
                                      // Test case that should pass original but fail mutant
                                      assertTrue(spyPointer.isLanguage("US"));  // Original: true, Mutant: false
                                  }

    @Test
                             public void testFindEnclosingAttribute_DetectsElementCastMutation() throws Exception {
                                 // Create a mock DOM structure
                                 Node mockElement = mock(Node.class);
                                 Node mockParent = mock(Node.class);
                                 
                                 // Set up the element node behavior
                                 when(mockElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                 when(mockElement.getParentNode()).thenReturn(mockParent);
                                 
                                 // Set up the parent node behavior (non-element)
                                 when(mockParent.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                 
                                 // Use reflection to access the protected method
                                 Method method = DOMNodePointer.class.getDeclaredMethod(
                                     "findEnclosingAttribute", Node.class, String.class);
                                 method.setAccessible(true);
                                 
                                 // The method should try to cast the element node and get its attribute
                                 // Original version would succeed, mutated version will throw NPE
                                 method.invoke(null, mockElement, "testAttr");
                                 
                                 // If we reach here, the test fails (mutant survived)
                                 // The expected NPE will be thrown by the mutated version
                             }

    @Test
                        public void testFindEnclosingAttributeShouldReturnAttributeValueWhenExists() throws Exception {
                            // Setup test data
                            String attrName = "testAttr";
                            String expectedValue = "testValue";
                            
                            // Create mock nodes
                            Node childNode = mock(Node.class);
                            Element parentElement = mock(Element.class);
                            
                            // Mock behavior
                            when(childNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                            when(childNode.getParentNode()).thenReturn(parentElement);
                            when(parentElement.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                            when(parentElement.getAttribute(attrName)).thenReturn(expectedValue);
                            
                            // Get the protected method via reflection
                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                "findEnclosingAttribute", Node.class, String.class);
                            method.setAccessible(true);
                            
                            // Test and verify
                            String result = (String) method.invoke(null, childNode, attrName);
                            assertEquals("Method should return attribute value when found in parent element", 
                                        expectedValue, result);
                            
                            // Verify interactions
                            verify(parentElement).getAttribute(attrName);
                        }

    @Test
                   public void testFindEnclosingAttribute_NonEmptyAttr_ShouldReturnValue() throws Exception {
                       // Setup
                       Node mockNode = mock(Node.class);
                       Node mockParent = mock(Node.class);
                       Element mockElement = mock(Element.class);
                       
                       when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                       when(mockNode.getParentNode()).thenReturn(mockParent);
                       when(mockParent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                       when(mockParent.getParentNode()).thenReturn(null);
                       
                       // Casting workaround for mock
                       when(((Element)mockNode).getAttribute("testAttr")).thenReturn("validValue");
                       when(((Element)mockParent).getAttribute("testAttr")).thenReturn("");
                       
                       // Use reflection to access protected method
                       Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                       method.setAccessible(true);
                       
                       // Test
                       String result = (String) method.invoke(null, mockNode, "testAttr");
                       
                       // Verify - original would return "validValue", mutant would return null
                       assertEquals("validValue", result);
                   }

    @Test
                   public void testFindEnclosingAttribute_EmptyAttr_ShouldReturnNull() throws Exception {
                       // Setup
                       Node mockNode = mock(Node.class);
                       Element mockElement = mock(Element.class);
                       
                       when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                       when(mockNode.getParentNode()).thenReturn(null);
                       
                       // Casting workaround for mock
                       when(((Element)mockNode).getAttribute("testAttr")).thenReturn("");
                       
                       // Use reflection to access protected method
                       Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                       method.setAccessible(true);
                       
                       // Test
                       String result = (String) method.invoke(null, mockNode, "testAttr");
                       
                       // Verify - original would return null, mutant would return ""
                       assertNull(result);
                   }

    @Test
                   public void testFindEnclosingAttribute_NoAttr_ShouldReturnNull() throws Exception {
                       // Setup
                       Node mockNode = mock(Node.class);
                       Element mockElement = mock(Element.class);
                       
                       when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                       when(mockNode.getParentNode()).thenReturn(null);
                       
                       // Casting workaround for mock
                       when(((Element)mockNode).getAttribute("testAttr")).thenReturn(null);
                       
                       // Use reflection to access protected method
                       Method method = DOMNodePointer.class.getDeclaredMethod(
                           "findEnclosingAttribute", Node.class, String.class);
                       method.setAccessible(true);
                       
                       // Test
                       String result = (String) method.invoke(null, mockNode, "testAttr");
                       
                       // Verify - both would return null
                       assertNull(result);
                   }

    @Test
                   public void testFindEnclosingAttribute_MultipleLevels_ShouldFindFirstNonEmpty() throws Exception {
                       // Setup a 3-level hierarchy
                       Node mockNode = mock(Node.class);
                       Node mockParent1 = mock(Node.class);
                       Node mockParent2 = mock(Node.class);
                       
                       when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                       when(mockNode.getParentNode()).thenReturn(mockParent1);
                       
                       when(mockParent1.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                       when(mockParent1.getParentNode()).thenReturn(mockParent2);
                       
                       when(mockParent2.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                       when(mockParent2.getParentNode()).thenReturn(null);
                       
                       // Casting workaround for mock
                       when(((Element)mockNode).getAttribute("testAttr")).thenReturn("");
                       when(((Element)mockParent1).getAttribute("testAttr")).thenReturn("validValue");
                       when(((Element)mockParent2).getAttribute("testAttr")).thenReturn("anotherValue");
                       
                       // Use reflection to access protected method
                       Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                       method.setAccessible(true);
                       String result = (String) method.invoke(null, mockNode, "testAttr");
                       
                       // Verify - original would return "validValue", mutant would return ""
                       assertEquals("validValue", result);
                   }

    @Test
              public void testFindEnclosingAttributeReturnsActualAttributeValue() throws Exception {
                  // Create test DOM structure
                  Element grandparent = mock(Element.class);
                  Element parent = mock(Element.class);
                  Element child = mock(Element.class);
                  Node textNode = mock(Node.class);
                  
                  // Setup node relationships
                  when(child.getParentNode()).thenReturn(parent);
                  when(parent.getParentNode()).thenReturn(grandparent);
                  when(grandparent.getParentNode()).thenReturn(null);
                  
                  // Setup node types
                  when(child.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                  when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                  when(grandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                  when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                  
                  // Setup attribute behavior
                  String attrName = "testAttr";
                  String expectedValue = "testValue";
                  when(grandparent.getAttribute(attrName)).thenReturn("");
                  when(parent.getAttribute(attrName)).thenReturn(expectedValue);
                  
                  // Get the protected method via reflection
                  Method method = DOMNodePointer.class.getDeclaredMethod(
                      "findEnclosingAttribute", Node.class, String.class);
                  method.setAccessible(true);
                  
                  // Test - should find the attribute on parent node
                  String result = (String) method.invoke(null, child, attrName);
                  
                  // Verify - should return the actual attribute value, not null
                  assertEquals("Method should return the found attribute value", 
                              expectedValue, result);
                  
                  // Additional verification that we checked the right nodes
                  verify(parent).getAttribute(attrName);
                  verify(grandparent, never()).getAttribute(attrName);
              }

    @Test
         public void testFindEnclosingAttributeShouldTraverseParentNodes() throws Exception {
             // Create a 3-level DOM structure where the attribute exists in the grandparent
             String attrName = "testAttr";
             String expectedValue = "expectedValue";
             
             // Mock the grandparent node (has the attribute)
             Element grandparent = mock(Element.class);
             when(grandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
             when(grandparent.getAttribute(attrName)).thenReturn(expectedValue);
             when(grandparent.getParentNode()).thenReturn(null);
             
             // Mock the parent node (no attribute)
             Element parent = mock(Element.class);
             when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
             when(parent.getAttribute(attrName)).thenReturn("");
             when(parent.getParentNode()).thenReturn(grandparent);
             
             // Mock the child node (no attribute, starting point)
             Element child = mock(Element.class);
             when(child.getNodeType()).thenReturn(Node.ELEMENT_NODE);
             when(child.getAttribute(attrName)).thenReturn("");
             when(child.getParentNode()).thenReturn(parent);
             
             // Use reflection to access the protected method
             Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
             method.setAccessible(true);
             String result = (String) method.invoke(null, child, attrName);
             
             // Verify the original behavior (traverses parents)
             assertEquals("Should find attribute in ancestor node", expectedValue, result);
             
             // Verify parent nodes were accessed (would fail with mutant)
             verify(child).getParentNode();
             verify(parent).getParentNode();
         }

    @Test
    public void testFindEnclosingAttribute_LanguageDetection() throws Exception {
        // Create test DOM structure
        Document doc = mock(Document.class);
        Element grandparent = mock(Element.class);
        Element parent = mock(Element.class);
        Element child = mock(Element.class);
        
        // Set up mock behavior
        when(child.getNodeType()).thenReturn(Node.ELEMENT_NODE);
        when(child.getParentNode()).thenReturn(parent);
        when(child.getAttribute("lang")).thenReturn("");
        
        when(parent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
        when(parent.getParentNode()).thenReturn(grandparent);
        when(parent.getAttribute("lang")).thenReturn("en-US");
        
        when(grandparent.getNodeType()).thenReturn(Node.ELEMENT_NODE);
        when(grandparent.getParentNode()).thenReturn(doc);
        when(grandparent.getAttribute("lang")).thenReturn("");
        
        when(doc.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
        when(doc.getParentNode()).thenReturn(null);
    
        // Get the protected method via reflection
        Method findEnclosingAttribute = DOMNodePointer.class.getDeclaredMethod(
            "findEnclosingAttribute", Node.class, String.class);
        findEnclosingAttribute.setAccessible(true);
        
        // Test language attribute detection
        String result = (String) findEnclosingAttribute.invoke(null, child, "lang");
        
        // Verify the method found the correct language attribute
        assertEquals("en-US", result);
        
        // Test case where no language attribute exists
        result = (String) findEnclosingAttribute.invoke(null, child, "nonexistent");
        assertNull(result);
        
        // Test case starting from node with direct language attribute
        when(child.getAttribute("lang")).thenReturn("fr-FR");
        result = (String) findEnclosingAttribute.invoke(null, child, "lang");
        assertEquals("fr-FR", result);
        
        // Test case with null starting node
        result = (String) findEnclosingAttribute.invoke(null, null, "lang");
        assertNull(result);
    }


}
