package gentest.org.apache.commons.jxpath.ri.axes.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.axes.*;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.commons.jxpath.BasicNodeSet;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class UnionContextTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                              public void testSetPosition_EmptyContexts_ReturnsFalse() {
                                                                                                                                                                  // Arrange
                                                                                                                                                                  UnionContext emptyContext = new UnionContext(null, new EvalContext[0]);
                                                                                                                                                                  
                                                                                                                                                                  // Act & Assert
                                                                                                                                                                  assertFalse(emptyContext.setPosition(1));
                                                                                                                                                              }

    @Test
                                                                                                                                                              public void testSetPosition_NegativePosition_ReturnsFalse() {
                                                                                                                                                                  // Arrange
                                                                                                                                                                  EvalContext parentContext = mock(EvalContext.class);
                                                                                                                                                                  EvalContext[] contexts = new EvalContext[1];
                                                                                                                                                                  contexts[0] = mock(EvalContext.class);
                                                                                                                                                                  BasicNodeSet nodeSet = new BasicNodeSet();
                                                                                                                                                                  UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                                                                                  
                                                                                                                                                                  // Mock the behavior
                                                                                                                                                                  NodePointer ptr = mock(NodePointer.class);
                                                                                                                                                                  when(contexts[0].nextSet()).thenReturn(true, false);
                                                                                                                                                                  when(contexts[0].nextNode()).thenReturn(true, false);
                                                                                                                                                                  when(contexts[0].getCurrentNodePointer()).thenReturn(ptr);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set the nodeSet since it's likely a private field
                                                                                                                                                                  try {
                                                                                                                                                                      Field nodeSetField = UnionContext.class.getDeclaredField("nodeSet");
                                                                                                                                                                      nodeSetField.setAccessible(true);
                                                                                                                                                                      nodeSetField.set(unionContext, nodeSet);
                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                      fail("Failed to set nodeSet field via reflection");
                                                                                                                                                                  }
                                                                                                                                                                  
                                                                                                                                                                  // Act & Assert
                                                                                                                                                                  assertFalse(unionContext.setPosition(-1));
                                                                                                                                                              }

    @Test
                                                                                                                                                          public void testSetPosition_ContextThrowsException_PropagatesException() {
                                                                                                                                                              // Arrange
                                                                                                                                                              EvalContext parentContext = mock(EvalContext.class);
                                                                                                                                                              EvalContext[] contexts = new EvalContext[1];
                                                                                                                                                              contexts[0] = mock(EvalContext.class);
                                                                                                                                                              when(contexts[0].nextSet()).thenThrow(new RuntimeException("Test exception"));
                                                                                                                                                              
                                                                                                                                                              UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                                                                              
                                                                                                                                                              try {
                                                                                                                                                                  // Act
                                                                                                                                                                  unionContext.setPosition(1);
                                                                                                                                                                  fail("Expected RuntimeException to be thrown");
                                                                                                                                                              } catch (RuntimeException e) {
                                                                                                                                                                  // Assert
                                                                                                                                                                  assertEquals("Test exception", e.getMessage());
                                                                                                                                                              }
                                                                                                                                                          }

    @Test
                                                                                                                      public void testSetPosition_SubsequentCalls_DoesNotPrepareAgain() {
                                                                                                                          // Arrange
                                                                                                                          EvalContext parentContext = mock(EvalContext.class);
                                                                                                                          EvalContext[] contexts = new EvalContext[1];
                                                                                                                          contexts[0] = mock(EvalContext.class);
                                                                                                                          BasicNodeSet nodeSet = mock(BasicNodeSet.class);
                                                                                                                          UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                                          
                                                                                                                          // Set up nodeSet for unionContext using reflection
                                                                                                                          try {
                                                                                                                              Field nodeSetField = UnionContext.class.getSuperclass().getDeclaredField("nodeSet");
                                                                                                                              nodeSetField.setAccessible(true);
                                                                                                                              nodeSetField.set(unionContext, nodeSet);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set nodeSet field via reflection");
                                                                                                                          }
                                                                                                                       
                                                                                                                          // First call prepares
                                                                                                                          NodePointer ptr = mock(NodePointer.class);
                                                                                                                          when(contexts[0].nextSet()).thenReturn(true, false);
                                                                                                                          when(contexts[0].nextNode()).thenReturn(true, false);
                                                                                                                          when(contexts[0].getCurrentNodePointer()).thenReturn(ptr);
                                                                                                                          unionContext.setPosition(1);
                                                                                                                          
                                                                                                                          // Reset mock to verify no more interactions
                                                                                                                          reset(contexts[0], nodeSet);
                                                                                                                          
                                                                                                                          // Act & Assert
                                                                                                                          assertTrue(unionContext.setPosition(2));
                                                                                                                          
                                                                                                                          // Verify no preparation happened again
                                                                                                                          verify(contexts[0], never()).nextSet();
                                                                                                                          verify(nodeSet, never()).add(any(NodePointer.class));
                                                                                                                      }

    @Test
                                                                                                                      public void testSetPosition_DuplicatePointers_OnlyAddsUnique() {
                                                                                                                          // Arrange
                                                                                                                          NodePointer ptr = mock(NodePointer.class);
                                                                                                                          EvalContext parentContext = mock(EvalContext.class);
                                                                                                                          EvalContext[] contexts = new EvalContext[2];
                                                                                                                          contexts[0] = mock(EvalContext.class);
                                                                                                                          contexts[1] = mock(EvalContext.class);
                                                                                                                          
                                                                                                                          BasicNodeSet nodeSet = mock(BasicNodeSet.class);
                                                                                                                          UnionContext unionContext = new UnionContext(parentContext, contexts);
                                                                                                                          
                                                                                                                          // Use reflection to set the nodeSet field since it's private
                                                                                                                          try {
                                                                                                                              Field field = UnionContext.class.getDeclaredField("nodeSet");
                                                                                                                              field.setAccessible(true);
                                                                                                                              field.set(unionContext, nodeSet);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set nodeSet field via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          when(contexts[0].nextSet()).thenReturn(true, false);
                                                                                                                          when(contexts[0].nextNode()).thenReturn(true, true, false);
                                                                                                                          when(contexts[0].getCurrentNodePointer()).thenReturn(ptr, ptr); // Same pointer twice
                                                                                                                          
                                                                                                                          when(contexts[1].nextSet()).thenReturn(true, false);
                                                                                                                          when(contexts[1].nextNode()).thenReturn(true, false);
                                                                                                                          when(contexts[1].getCurrentNodePointer()).thenReturn(ptr); // Same pointer again
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          unionContext.setPosition(1);
                                                                                                                          
                                                                                                                          // Verify pointer only added once despite appearing multiple times
                                                                                                                          verify(nodeSet, times(1)).add(ptr);
                                                                                                                      }

    @Test
                                                                             public void testSetPosition_ShouldProcessAllNodesInAllSets() {
                                                                                 // Setup test data - create contexts with multiple sets and nodes
                                                                                 EvalContext mockContext1 = mock(EvalContext.class);
                                                                                 EvalContext mockContext2 = mock(EvalContext.class);
                                                                                 
                                                                                 // Mock behavior for context1 - has 2 sets with 2 nodes each
                                                                                 when(mockContext1.nextSet())
                                                                                     .thenReturn(true)  // first set
                                                                                     .thenReturn(true)  // second set
                                                                                     .thenReturn(false); // no more sets
                                                                                 when(mockContext1.nextNode())
                                                                                     .thenReturn(true)  // first node in first set
                                                                                     .thenReturn(true)  // second node in first set
                                                                                     .thenReturn(false) // end of first set
                                                                                     .thenReturn(true)  // first node in second set
                                                                                     .thenReturn(true)  // second node in second set
                                                                                     .thenReturn(false); // end of second set
                                                                                 
                                                                                 // Mock behavior for context2 - has 1 set with 3 nodes
                                                                                 when(mockContext2.nextSet())
                                                                                     .thenReturn(true)  // first set
                                                                                     .thenReturn(false); // no more sets
                                                                                 when(mockContext2.nextNode())
                                                                                     .thenReturn(true)  // first node
                                                                                     .thenReturn(true)  // second node
                                                                                     .thenReturn(true)  // third node
                                                                                     .thenReturn(false); // end of set
                                                                                 
                                                                                 // Create test pointers to return
                                                                                 NodePointer ptr1 = mock(NodePointer.class);
                                                                                 NodePointer ptr2 = mock(NodePointer.class);
                                                                                 NodePointer ptr3 = mock(NodePointer.class);
                                                                                 NodePointer ptr4 = mock(NodePointer.class);
                                                                                 NodePointer ptr5 = mock(NodePointer.class);
                                                                                 NodePointer ptr6 = mock(NodePointer.class);
                                                                                 NodePointer ptr7 = mock(NodePointer.class);
                                                                                 
                                                                                 when(mockContext1.getCurrentNodePointer())
                                                                                     .thenReturn(ptr1)  // first set first node
                                                                                     .thenReturn(ptr2)  // first set second node
                                                                                     .thenReturn(ptr3)  // second set first node
                                                                                     .thenReturn(ptr4); // second set second node
                                                                                 when(mockContext2.getCurrentNodePointer())
                                                                                     .thenReturn(ptr5)  // first node
                                                                                     .thenReturn(ptr6)  // second node
                                                                                     .thenReturn(ptr7); // third node
                                                                                 
                                                                                 // Create UnionContext with our test contexts
                                                                                 EvalContext[] contexts = {mockContext1, mockContext2};
                                                                                 UnionContext unionContext = new UnionContext(null, contexts);
                                                                                 
                                                                                 // Execute
                                                                                 unionContext.setPosition(0);
                                                                                 
                                                                                 // Verify - should contain all 7 pointers
                                                                                 BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                                                                 assertEquals(7, nodeSet.getPointers().size());
                                                                                 assertTrue(nodeSet.getPointers().contains(ptr1));
                                                                                 assertTrue(nodeSet.getPointers().contains(ptr2));
                                                                                 assertTrue(nodeSet.getPointers().contains(ptr3));
                                                                                 assertTrue(nodeSet.getPointers().contains(ptr4));
                                                                                 assertTrue(nodeSet.getPointers().contains(ptr5));
                                                                                 assertTrue(nodeSet.getPointers().contains(ptr6));
                                                                                 assertTrue(nodeSet.getPointers().contains(ptr7));
                                                                             }

    @Test
                                                                        public void testSetPosition_DetectsNullPointerMutant() {
                                                                            // Setup test data and mocks
                                                                            EvalContext mockContext1 = mock(EvalContext.class);
                                                                            EvalContext mockContext2 = mock(EvalContext.class);
                                                                            NodePointer expectedPointer1 = mock(NodePointer.class);
                                                                            NodePointer expectedPointer2 = mock(NodePointer.class);
                                                                            
                                                                            // Configure mock behaviors
                                                                            when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                                                                            when(mockContext1.nextNode()).thenReturn(true).thenReturn(false);
                                                                            when(mockContext1.getCurrentNodePointer()).thenReturn(expectedPointer1);
                                                                            
                                                                            when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
                                                                            when(mockContext2.nextNode()).thenReturn(true).thenReturn(false);
                                                                            when(mockContext2.getCurrentNodePointer()).thenReturn(expectedPointer2);
                                                                            
                                                                            EvalContext[] contexts = new EvalContext[]{mockContext1, mockContext2};
                                                                            UnionContext unionContext = new UnionContext(null, contexts);
                                                                            
                                                                            // Reset prepared flag to ensure preparation happens using reflection
                                                                            try {
                                                                                Field preparedField = UnionContext.class.getDeclaredField("prepared");
                                                                                preparedField.setAccessible(true);
                                                                                preparedField.setBoolean(unionContext, false);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set prepared field via reflection");
                                                                            }
                                                                            
                                                                            // Execute
                                                                            unionContext.setPosition(0);
                                                                            
                                                                            // Verify the node set contains the expected pointers (not null)
                                                                            BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                                                            assertFalse("Node set should not be empty", nodeSet.getPointers().isEmpty());
                                                                            for (Object obj : nodeSet.getPointers()) {
                                                                                Pointer ptr = (Pointer) obj;
                                                                                assertNotNull("Node set should not contain null pointers", ptr);
                                                                            }
                                                                            
                                                                            // Verify we got exactly our expected pointers
                                                                            assertEquals(2, nodeSet.getPointers().size());
                                                                            assertTrue(nodeSet.getPointers().contains(expectedPointer1));
                                                                            assertTrue(nodeSet.getPointers().contains(expectedPointer2));
                                                                        }

    @Test
                                                                   public void testSetPosition_DetectsDuplicatePointerMutation() {
                                                                       // Setup test data with duplicate pointers
                                                                       EvalContext mockContext1 = mock(EvalContext.class);
                                                                       EvalContext mockContext2 = mock(EvalContext.class);
                                                                       NodePointer ptr1 = mock(NodePointer.class);
                                                                       NodePointer ptr2 = mock(NodePointer.class);
                                                                       
                                                                       // Mock context behavior to return duplicate pointers
                                                                       when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                                                                       when(mockContext1.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false);
                                                                       when(mockContext1.getCurrentNodePointer()).thenReturn(ptr1).thenReturn(ptr2);
                                                                       
                                                                       when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
                                                                       when(mockContext2.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false);
                                                                       when(mockContext2.getCurrentNodePointer()).thenReturn(ptr1).thenReturn(ptr2); // Same pointers again
                                                                       
                                                                       EvalContext[] contexts = new EvalContext[]{mockContext1, mockContext2};
                                                                       UnionContext unionContext = new UnionContext(null, contexts);
                                                                       
                                                                       // Reset prepared flag to force preparation using reflection
                                                                       try {
                                                                           Field preparedField = UnionContext.class.getDeclaredField("prepared");
                                                                           preparedField.setAccessible(true);
                                                                           preparedField.setBoolean(unionContext, false);
                                                                       } catch (Exception e) {
                                                                           fail("Failed to set prepared field via reflection");
                                                                       }
                                                                       
                                                                       // Execute
                                                                       unionContext.setPosition(0);
                                                                       
                                                                       // Verify - should only contain 2 unique pointers despite 4 being encountered
                                                                       BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                                                       assertEquals(2, nodeSet.getPointers().size()); // This would fail with mutant
                                                                       assertTrue(nodeSet.getPointers().contains(ptr1));
                                                                       assertTrue(nodeSet.getPointers().contains(ptr2));
                                                                   }

    @Test
                                                               public void testSetPosition_ShouldFilterDuplicatePointers() throws Exception {
                                                                   // Setup test data with duplicate pointers
                                                                   EvalContext mockContext1 = mock(EvalContext.class);
                                                                   EvalContext mockContext2 = mock(EvalContext.class);
                                                                   
                                                                   NodePointer duplicatePointer = mock(NodePointer.class);
                                                                   
                                                                   // Mock context1 behavior - returns two sets, each with the duplicate pointer
                                                                   when(mockContext1.nextSet()).thenReturn(true).thenReturn(true).thenReturn(false);
                                                                   when(mockContext1.nextNode()).thenReturn(true).thenReturn(false)  // first set
                                                                                                .thenReturn(true).thenReturn(false); // second set
                                                                   when(mockContext1.getCurrentNodePointer()).thenReturn(duplicatePointer);
                                                                   
                                                                   // Mock context2 behavior - returns one set with the duplicate pointer
                                                                   when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
                                                                   when(mockContext2.nextNode()).thenReturn(true).thenReturn(false);
                                                                   when(mockContext2.getCurrentNodePointer()).thenReturn(duplicatePointer);
                                                                   
                                                                   EvalContext[] contexts = {mockContext1, mockContext2};
                                                                   UnionContext unionContext = new UnionContext(null, contexts);
                                                                   
                                                                   // Execute
                                                                   unionContext.setPosition(0);
                                                                   
                                                                   // Verify - should only contain one instance of the pointer despite multiple occurrences
                                                                   BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                                                   assertEquals(1, nodeSet.getPointers().size());
                                                                   assertTrue(nodeSet.getPointers().contains(duplicatePointer));
                                                                   
                                                                   // This test will fail on the mutant version since it will add the pointer 3 times
                                                               }

    @Test
                                                             public void testSetPosition_DetectsDuplicatePointerMutation1() {
                                                                 // Create mock context that will return duplicate pointers
                                                                 EvalContext mockContext1 = mock(EvalContext.class);
                                                                 NodePointer duplicatePointer = mock(NodePointer.class);
                                                                 
                                                                 // Set up mock behavior - return same pointer twice
                                                                 when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                                                                 when(mockContext1.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false);
                                                                 when(mockContext1.getCurrentNodePointer())
                                                                     .thenReturn(duplicatePointer)
                                                                     .thenReturn(duplicatePointer);
                                                                 
                                                                 EvalContext[] contexts = new EvalContext[]{mockContext1};
                                                                 UnionContext unionContext = new UnionContext(null, contexts);
                                                                 
                                                                 // Call setPosition which should process the contexts
                                                                 unionContext.setPosition(0);
                                                                 
                                                                 // Get the underlying node set
                                                                 BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                                                 
                                                                 // Verify no duplicates were added (original behavior)
                                                                 // The mutant would have size 2 here
                                                                 assertEquals(1, nodeSet.getPointers().size());
                                                                 
                                                                 // Verify the pointer was only added once
                                                                 // This would fail for the mutant which would add it twice
                                                                 int count = 0;
                                                                 for (Object p : nodeSet.getPointers()) {
                                                                     if (p == duplicatePointer) {
                                                                         count++;
                                                                     }
                                                                 }
                                                                 assertEquals(1, count);
                                                             }

    @Test
                                                        public void testSetPosition_DetectsNullPointerMutation() throws Exception {
                                                            // Setup test data
                                                            NodePointer mockPointer1 = mock(NodePointer.class);
                                                            NodePointer mockPointer2 = mock(NodePointer.class);
                                                            
                                                            // Create mock contexts that will return these pointers
                                                            EvalContext mockContext1 = mock(EvalContext.class);
                                                            when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                                                            when(mockContext1.nextNode()).thenReturn(true).thenReturn(false);
                                                            when(mockContext1.getCurrentNodePointer()).thenReturn(mockPointer1);
                                                            
                                                            EvalContext mockContext2 = mock(EvalContext.class);
                                                            when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
                                                            when(mockContext2.nextNode()).thenReturn(true).thenReturn(false);
                                                            when(mockContext2.getCurrentNodePointer()).thenReturn(mockPointer2);
                                                            
                                                            EvalContext[] contexts = {mockContext1, mockContext2};
                                                            
                                                            // Create UnionContext instance
                                                            UnionContext unionContext = new UnionContext(null, contexts);
                                                            
                                                            // Verify initial state using reflection
                                                            Field preparedField = UnionContext.class.getDeclaredField("prepared");
                                                            preparedField.setAccessible(true);
                                                            assertFalse((boolean) preparedField.get(unionContext)); // Ensure we start unprepared
                                                            
                                                            // Execute
                                                            unionContext.setPosition(0);
                                                            
                                                            // Get the node set (need to cast as we know it's BasicNodeSet)
                                                            BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                                            
                                                            // Verify results - this will catch the mutant
                                                            assertEquals(2, nodeSet.getPointers().size());
                                                            assertTrue(nodeSet.getPointers().contains(mockPointer1));
                                                            assertTrue(nodeSet.getPointers().contains(mockPointer2));
                                                            
                                                            // Also verify prepared flag was set using reflection
                                                            assertTrue((boolean) preparedField.get(unionContext));
                                                        }

    @Test
                                               public void testSetPosition_pointerInsertionOrder() throws Exception {
                                                   // Setup test data
                                                   EvalContext mockContext1 = mock(EvalContext.class);
                                                   EvalContext mockContext2 = mock(EvalContext.class);
                                                   NodePointer ptr1 = mock(NodePointer.class);
                                                   NodePointer ptr2 = mock(NodePointer.class);
                                                   
                                                   // Mock context behavior to return two different pointers in sequence
                                                   when(mockContext1.nextSet()).thenReturn(true, false);
                                                   when(mockContext1.nextNode()).thenReturn(true, true, false);
                                                   when(mockContext1.getCurrentNodePointer()).thenReturn(ptr1, ptr2);
                                                   
                                                   // Create UnionContext with our mock contexts
                                                   EvalContext[] contexts = {mockContext1, mockContext2};
                                                   UnionContext unionContext = new UnionContext(null, contexts);
                                                   
                                                   // Reset prepared flag to force preparation using reflection
                                                   Field preparedField = UnionContext.class.getDeclaredField("prepared");
                                                   preparedField.setAccessible(true);
                                                   preparedField.setBoolean(unionContext, false);
                                                   
                                                   // Call setPosition which will trigger preparation
                                                   unionContext.setPosition(0);
                                                   
                                                   // Get the internal node set
                                                   BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                                   
                                                   // Verify pointers were added in correct order (ptr1 before ptr2)
                                                   // This would fail if mutant (add(0,ptr)) was present as order would be reversed
                                                   java.util.Iterator<NodePointer> iterator = nodeSet.getPointers().iterator();
                                                   assertEquals(ptr1, iterator.next());
                                                   assertEquals(ptr2, iterator.next());
                                                   
                                                   // Also verify no duplicates were added (original functionality)
                                                   assertFalse(iterator.hasNext());
                                               }

    @Test
                                          public void testSetPosition_DetectsDuplicatePointerAddition() {
                                              // Setup test contexts with some nodes
                                              NodePointer ptr1 = mock(NodePointer.class);
                                              NodePointer ptr2 = mock(NodePointer.class);
                                              
                                              EvalContext ctx1 = mock(EvalContext.class);
                                              when(ctx1.nextSet()).thenReturn(true, false);
                                              when(ctx1.nextNode()).thenReturn(true, false);
                                              when(ctx1.getCurrentNodePointer()).thenReturn(ptr1);
                                              
                                              EvalContext ctx2 = mock(EvalContext.class);
                                              when(ctx2.nextSet()).thenReturn(true, false);
                                              when(ctx2.nextNode()).thenReturn(true, false);
                                              when(ctx2.getCurrentNodePointer()).thenReturn(ptr2);
                                              
                                              EvalContext[] contexts = new EvalContext[]{ctx1, ctx2};
                                              
                                              // Create UnionContext instance
                                              UnionContext unionContext = new UnionContext(null, contexts);
                                              
                                              // Verify initial state using reflection
                                              try {
                                                  Field preparedField = UnionContext.class.getDeclaredField("prepared");
                                                  preparedField.setAccessible(true);
                                                  assertFalse((boolean) preparedField.get(unionContext));
                                              } catch (Exception e) {
                                                  fail("Failed to access private field 'prepared'");
                                              }
                                              
                                              // Call setPosition which should prepare the node set
                                              unionContext.setPosition(0);
                                              
                                              // Get the node set and verify its contents
                                              BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                              
                                              // Original behavior: 2 unique pointers (ptr1, ptr2)
                                              // Mutated behavior: 4 pointers (ptr1, ptr1, ptr2, ptr2)
                                              assertEquals("Node set should contain exactly 2 unique pointers", 2, nodeSet.getPointers().size());
                                              
                                              // Verify each pointer appears exactly once
                                              int ptr1Count = 0, ptr2Count = 0;
                                              for (Object p : nodeSet.getPointers()) {
                                                  NodePointer pointer = (NodePointer) p;
                                                  if (pointer == ptr1) ptr1Count++;
                                                  if (pointer == ptr2) ptr2Count++;
                                              }
                                              assertEquals("ptr1 should appear exactly once", 1, ptr1Count);
                                              assertEquals("ptr2 should appear exactly once", 1, ptr2Count);
                                          }

    @Test
                                          public void testSetPosition_SortsPointers() {
                                              // Create mock contexts with nodes in unsorted order
                                              EvalContext context1 = mock(EvalContext.class);
                                              EvalContext context2 = mock(EvalContext.class);
                                              EvalContext[] contexts = new EvalContext[]{context1, context2};
                                              
                                              // Create test node pointers with comparable values
                                              NodePointer ptr3 = mock(NodePointer.class);
                                              NodePointer ptr1 = mock(NodePointer.class);
                                              NodePointer ptr2 = mock(NodePointer.class);
                                              
                                              // Setup mock behavior for context1
                                              when(context1.nextSet()).thenReturn(true).thenReturn(false);
                                              when(context1.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false);
                                              when(context1.getCurrentNodePointer())
                                                  .thenReturn(ptr3)  // Will be last after sorting
                                                  .thenReturn(ptr1); // Will be first after sorting
                                                  
                                              // Setup mock behavior for context2
                                              when(context2.nextSet()).thenReturn(true).thenReturn(false);
                                              when(context2.nextNode()).thenReturn(true).thenReturn(false);
                                              when(context2.getCurrentNodePointer()).thenReturn(ptr2); // Middle value
                                              
                                              // Setup comparable behavior for pointers
                                              when(ptr1.compareTo(ptr2)).thenReturn(-1);
                                              when(ptr1.compareTo(ptr3)).thenReturn(-1);
                                              when(ptr2.compareTo(ptr1)).thenReturn(1);
                                              when(ptr2.compareTo(ptr3)).thenReturn(-1);
                                              when(ptr3.compareTo(ptr1)).thenReturn(1);
                                              when(ptr3.compareTo(ptr2)).thenReturn(1);
                                              
                                              // Create test instance
                                              UnionContext unionContext = new UnionContext(null, contexts);
                                              
                                              // Call setPosition which should trigger preparation
                                              unionContext.setPosition(0);
                                              
                                              // Get the resulting node set
                                              BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                              
                                              // Verify pointers are in sorted order (ptr1, ptr2, ptr3)
                                              ArrayList<Pointer> pointers = new ArrayList<>(nodeSet.getPointers());
                                              assertEquals(3, pointers.size());
                                              assertSame(ptr1, pointers.get(0)); // First after sorting
                                              assertSame(ptr2, pointers.get(1)); // Second after sorting
                                              assertSame(ptr3, pointers.get(2)); // Third after sorting
                                              
                                              // This test will fail if sortPointers is commented out (mutant)
                                          }

    @Test
                                    public void testSetPosition_DetectsEmptyIteratorMutant() {
                                        // Setup test contexts with nodes
                                        NodePointer mockPointer1 = mock(NodePointer.class);
                                        NodePointer mockPointer2 = mock(NodePointer.class);
                                        
                                        EvalContext mockContext1 = mock(EvalContext.class);
                                        when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                                        when(mockContext1.nextNode()).thenReturn(true).thenReturn(false);
                                        when(mockContext1.getCurrentNodePointer()).thenReturn(mockPointer1);
                                        
                                        EvalContext mockContext2 = mock(EvalContext.class);
                                        when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
                                        when(mockContext2.nextNode()).thenReturn(true).thenReturn(false);
                                        when(mockContext2.getCurrentNodePointer()).thenReturn(mockPointer2);
                                        
                                        EvalContext[] contexts = {mockContext1, mockContext2};
                                        UnionContext unionContext = new UnionContext(null, contexts);
                                        
                                        // Mock parent behavior
                                        UnionContext spyUnionContext = spy(unionContext);
                                        when(spyUnionContext.getNodeSet()).thenReturn(new BasicNodeSet());
                                        doReturn(true).when(spyUnionContext).setPosition(anyInt());
                                        
                                        // Execute
                                        boolean result = spyUnionContext.setPosition(0);
                                        
                                        // Verify nodeSet contains expected pointers
                                        BasicNodeSet nodeSet = (BasicNodeSet) spyUnionContext.getNodeSet();
                                        assertEquals(2, nodeSet.getPointers().size());
                                        assertTrue(nodeSet.getPointers().contains(mockPointer1));
                                        assertTrue(nodeSet.getPointers().contains(mockPointer2));
                                        
                                        // Verify parent method was called
                                        assertTrue(result);
                                        verify(spyUnionContext).setPosition(0);
                                    }

    @Test
                               public void testSetPosition_ShouldNotAddDuplicatePointers() {
                                   // Setup test data
                                   NodePointer ptr1 = mock(NodePointer.class);
                                   NodePointer ptr2 = mock(NodePointer.class);
                                   
                                   // Create mock contexts that will return these pointers
                                   EvalContext ctx1 = mock(EvalContext.class);
                                   when(ctx1.nextSet()).thenReturn(true).thenReturn(false);
                                   when(ctx1.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false);
                                   when(ctx1.getCurrentNodePointer()).thenReturn(ptr1).thenReturn(ptr2);
                                   
                                   EvalContext ctx2 = mock(EvalContext.class);
                                   when(ctx2.nextSet()).thenReturn(true).thenReturn(false);
                                   when(ctx2.nextNode()).thenReturn(true).thenReturn(false);
                                   when(ctx2.getCurrentNodePointer()).thenReturn(ptr1); // duplicate pointer
                                   
                                   EvalContext[] contexts = new EvalContext[]{ctx1, ctx2};
                                   UnionContext unionContext = new UnionContext(null, contexts);
                                   
                                   // Get the nodeSet to verify later
                                   BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                                   
                                   // Act
                                   unionContext.setPosition(0);
                                   
                                   // Assert
                                   // Should contain exactly 2 unique pointers (ptr1 and ptr2)
                                   assertEquals(2, nodeSet.getPointers().size());
                                   assertTrue(nodeSet.getPointers().contains(ptr1));
                                   assertTrue(nodeSet.getPointers().contains(ptr2));
                                   
                                   // Verify each pointer appears exactly once
                                   int ptr1Count = 0, ptr2Count = 0;
                                   for (Object p : nodeSet.getPointers()) {
                                       NodePointer pointer = (NodePointer) p;
                                       if (pointer == ptr1) ptr1Count++;
                                       if (pointer == ptr2) ptr2Count++;
                                   }
                                   assertEquals(1, ptr1Count);
                                   assertEquals(1, ptr2Count);
                               }

    @Test
                           public void testSetPosition_AddsPointersToNodeSet() throws Exception {
                               // Setup test data
                               NodePointer mockPointer1 = mock(NodePointer.class);
                               NodePointer mockPointer2 = mock(NodePointer.class);
                               
                               EvalContext mockContext1 = mock(EvalContext.class);
                               when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                               when(mockContext1.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false);
                               when(mockContext1.getCurrentNodePointer())
                                   .thenReturn(mockPointer1)
                                   .thenReturn(mockPointer2);
                               
                               EvalContext mockContext2 = mock(EvalContext.class);
                               when(mockContext2.nextSet()).thenReturn(false); // empty context
                               
                               EvalContext[] contexts = new EvalContext[]{mockContext1, mockContext2};
                               UnionContext unionContext = new UnionContext(null, contexts);
                               
                               // Access private field to verify later
                               Field preparedField = UnionContext.class.getDeclaredField("prepared");
                               preparedField.setAccessible(true);
                               preparedField.set(unionContext, false);
                               
                               Field nodeSetField = UnionContext.class.getSuperclass().getDeclaredField("nodeSet");
                               nodeSetField.setAccessible(true);
                               BasicNodeSet nodeSet = (BasicNodeSet) nodeSetField.get(unionContext);
                               
                               // Execute
                               unionContext.setPosition(0);
                               
                               // Verify
                               assertEquals(2, nodeSet.getPointers().size());
                               assertTrue(nodeSet.getPointers().contains(mockPointer1));
                               assertTrue(nodeSet.getPointers().contains(mockPointer2));
                           }

    @Test
                          public void testSetPositionProcessesAllNodes() {
                              // Setup test data
                              EvalContext parentContext = mock(EvalContext.class);
                              EvalContext[] contexts = new EvalContext[1];
                              EvalContext context = mock(EvalContext.class);
                              contexts[0] = context;
                              
                              // Create test object
                              UnionContext unionContext = new UnionContext(parentContext, contexts);
                              
                              // Mock behavior
                              when(context.nextSet()).thenReturn(true).thenReturn(false); // One set
                              when(context.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false); // Two nodes
                              
                              NodePointer ptr1 = mock(NodePointer.class);
                              NodePointer ptr2 = mock(NodePointer.class);
                              when(context.getCurrentNodePointer())
                                  .thenReturn(ptr1)  // First node
                                  .thenReturn(ptr2); // Second node
                              
                              BasicNodeSet mockNodeSet = mock(BasicNodeSet.class);
                              when(unionContext.getNodeSet()).thenReturn(mockNodeSet);
                              
                              // Execute
                              unionContext.setPosition(0);
                              
                              // Verify all nodes were processed
                              verify(context, times(3)).nextNode(); // Called until returns false
                              verify(context, times(2)).getCurrentNodePointer(); // Only for true returns
                              
                              // Verify nodes were added to set
                              verify(mockNodeSet).add(ptr1);
                              verify(mockNodeSet).add(ptr2);
                              
                              // Verify parent called
                              verify(parentContext).setPosition(0);
                          }

    @Test
                         public void testSetPositionNextNodeCalledExactlyWhenNeeded() throws Exception {
                             // Setup test data
                             EvalContext mockContext1 = mock(EvalContext.class);
                             EvalContext mockContext2 = mock(EvalContext.class);
                             EvalContext[] contexts = {mockContext1, mockContext2};
                             UnionContext unionContext = new UnionContext(null, contexts);
                             
                             // Setup mock behavior
                             when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                             when(mockContext1.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false);
                             
                             when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
                             when(mockContext2.nextNode()).thenReturn(true).thenReturn(false);
                             
                             // Execute test
                             unionContext.setPosition(0);
                             
                             // Verify nextNode() calls - should be called exactly 3 times (2 for ctx1, 1 for ctx2)
                             verify(mockContext1, times(2)).nextNode();  // 2 nodes in first context
                             verify(mockContext2, times(1)).nextNode(); // 1 node in second context
                             
                             // Verify no extra calls were made due to || false
                             // This would fail if the mutant was present because the condition would be evaluated more times
                             verifyNoMoreInteractions(mockContext1, mockContext2);
                         }

    @Test
                        public void testSetPositionWithDuplicatePointers() {
                            // Create mock context with duplicate pointers
                            EvalContext mockContext1 = mock(EvalContext.class);
                            EvalContext mockContext2 = mock(EvalContext.class);
                            
                            NodePointer duplicatePointer = mock(NodePointer.class);
                            
                            // Setup context1 to return the duplicate pointer
                            when(mockContext1.nextSet()).thenReturn(true, false);
                            when(mockContext1.nextNode()).thenReturn(true, false);
                            when(mockContext1.getCurrentNodePointer()).thenReturn(duplicatePointer);
                            
                            // Setup context2 to return the same duplicate pointer
                            when(mockContext2.nextSet()).thenReturn(true, false);
                            when(mockContext2.nextNode()).thenReturn(true, false);
                            when(mockContext2.getCurrentNodePointer()).thenReturn(duplicatePointer);
                            
                            EvalContext[] contexts = {mockContext1, mockContext2};
                            UnionContext unionContext = new UnionContext(null, contexts);
                            
                            // Call setPosition which should prepare the node set
                            unionContext.setPosition(0);
                            
                            // Get the prepared node set
                            BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                            
                            // Original behavior: should contain only one instance of the pointer
                            // Mutant behavior: would contain two instances
                            assertEquals(1, nodeSet.getPointers().size());
                            
                            // Verify the pointer was added
                            assertTrue(nodeSet.getPointers().contains(duplicatePointer));
                        }

    @Test
                       public void testSetPosition_ShouldOnlyAddUniquePointers() throws Exception {
                           // Setup test data
                           EvalContext mockContext1 = mock(EvalContext.class);
                           EvalContext mockContext2 = mock(EvalContext.class);
                           NodePointer duplicatePointer = mock(NodePointer.class);
                           
                           // Mock context behavior
                           when(mockContext1.nextSet()).thenReturn(true, false);
                           when(mockContext1.nextNode()).thenReturn(true, false);
                           when(mockContext1.getCurrentNodePointer()).thenReturn(duplicatePointer);
                           
                           when(mockContext2.nextSet()).thenReturn(true, false);
                           when(mockContext2.nextNode()).thenReturn(true, false);
                           when(mockContext2.getCurrentNodePointer()).thenReturn(duplicatePointer);
                           
                           EvalContext[] contexts = {mockContext1, mockContext2};
                           UnionContext unionContext = new UnionContext(null, contexts);
                           
                           // Use reflection to set prepared=false since it's private
                           Field preparedField = UnionContext.class.getDeclaredField("prepared");
                           preparedField.setAccessible(true);
                           preparedField.set(unionContext, false);
                           
                           // Get the node set to verify later
                           BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                           
                           // Execute
                           unionContext.setPosition(0);
                           
                           // Verify only one instance of duplicatePointer was added
                           assertEquals(1, nodeSet.getPointers().size());
                           assertTrue(nodeSet.getPointers().contains(duplicatePointer));
                           
                           // Verify the pointers collection was properly processed
                           // This would fail if the mutant was active since it would expose the trivial change
                       }

    @Test
                      public void testSetPosition_UniquePointersOnly() throws Exception {
                          // Setup test data
                          EvalContext mockContext1 = mock(EvalContext.class);
                          EvalContext mockContext2 = mock(EvalContext.class);
                          NodePointer mockPointer = mock(NodePointer.class);
                          
                          // Configure context behavior
                          when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
                          when(mockContext1.nextNode()).thenReturn(true).thenReturn(true).thenReturn(false);
                          when(mockContext1.getCurrentNodePointer()).thenReturn(mockPointer).thenReturn(mockPointer); // same pointer twice
                          
                          when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
                          when(mockContext2.nextNode()).thenReturn(true).thenReturn(false);
                          when(mockContext2.getCurrentNodePointer()).thenReturn(mockPointer); // same pointer again
                          
                          EvalContext[] contexts = {mockContext1, mockContext2};
                          UnionContext unionContext = new UnionContext(null, contexts);
                          
                          // Set prepared to false to trigger the preparation logic
                          Field preparedField = UnionContext.class.getDeclaredField("prepared");
                          preparedField.setAccessible(true);
                          preparedField.set(unionContext, false);
                          
                          // Get the node set to verify results
                          Field nodeSetField = UnionContext.class.getSuperclass().getDeclaredField("nodeSet");
                          nodeSetField.setAccessible(true);
                          BasicNodeSet nodeSet = (BasicNodeSet) nodeSetField.get(unionContext);
                          
                          // Execute
                          unionContext.setPosition(0);
                          
                          // Verify - pointer should only be added once despite appearing multiple times
                          assertEquals(1, nodeSet.getPointers().size());
                          assertSame(mockPointer, nodeSet.getPointers().get(0));
                      }

    @Test
                     public void testSetPositionCollectsAllUniquePointers() throws Exception {
                         // Create mock contexts with multiple node pointers
                         EvalContext context1 = mock(EvalContext.class);
                         EvalContext context2 = mock(EvalContext.class);
                         
                         NodePointer ptr1 = mock(NodePointer.class);
                         NodePointer ptr2 = mock(NodePointer.class);
                         NodePointer ptr3 = mock(NodePointer.class);
                         
                         // Setup context1 to return ptr1 and ptr2
                         when(context1.nextSet()).thenReturn(true, false);
                         when(context1.nextNode()).thenReturn(true, true, false);
                         when(context1.getCurrentNodePointer()).thenReturn(ptr1, ptr2);
                         
                         // Setup context2 to return ptr2 (duplicate) and ptr3
                         when(context2.nextSet()).thenReturn(true, false);
                         when(context2.nextNode()).thenReturn(true, true, false);
                         when(context2.getCurrentNodePointer()).thenReturn(ptr2, ptr3);
                         
                         EvalContext[] contexts = {context1, context2};
                         UnionContext unionContext = new UnionContext(null, contexts);
                         
                         // Call setPosition which should trigger the preparation
                         unionContext.setPosition(0);
                         
                         // Get the node set that should contain all unique pointers
                         BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                         
                         // Verify all pointers were collected (original behavior)
                         // Mutant would fail here as it would only have ptr3
                         assertEquals(3, nodeSet.getPointers().size());
                         assertTrue(nodeSet.getPointers().contains(ptr1));
                         assertTrue(nodeSet.getPointers().contains(ptr2));
                         assertTrue(nodeSet.getPointers().contains(ptr3));
                     }

    @Test
                   public void testSetPosition_DetectsPointerAddMutant() throws Exception {
                       // Setup test data with duplicate pointers
                       NodePointer ptr1 = mock(NodePointer.class);
                       NodePointer ptr2 = mock(NodePointer.class);
                       
                       // Create contexts that will return these pointers (with some duplicates)
                       EvalContext ctx1 = mock(EvalContext.class);
                       when(ctx1.nextSet()).thenReturn(true, false);
                       when(ctx1.nextNode()).thenReturn(true, true, false); // two nodes
                       when(ctx1.getCurrentNodePointer()).thenReturn(ptr1, ptr2);
                       
                       EvalContext ctx2 = mock(EvalContext.class);
                       when(ctx2.nextSet()).thenReturn(true, false);
                       when(ctx2.nextNode()).thenReturn(true, true, false); // two nodes
                       when(ctx2.getCurrentNodePointer()).thenReturn(ptr1, ptr2); // same pointers
                       
                       EvalContext[] contexts = new EvalContext[]{ctx1, ctx2};
                       UnionContext unionContext = new UnionContext(null, contexts);
                       
                       // Access node set to verify later
                       BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
                       
                       // Act - set position (which triggers preparation)
                       unionContext.setPosition(0);
                       
                       // Assert - verify correct pointers were collected
                       // Original: should have 2 unique pointers (ptr1, ptr2)
                       // Mutant: would remove pointers, resulting in empty set
                       assertEquals("Should contain exactly 2 unique pointers", 2, nodeSet.getPointers().size());
                       assertTrue("Should contain ptr1", nodeSet.getPointers().contains(ptr1));
                       assertTrue("Should contain ptr2", nodeSet.getPointers().contains(ptr2));
                       
                       // Verify preparation happened using reflection
                       Field preparedField = UnionContext.class.getDeclaredField("prepared");
                       preparedField.setAccessible(true);
                       boolean prepared = (boolean) preparedField.get(unionContext);
                       assertTrue("Should be prepared after first call", prepared);
                   }

    @Test
          public void testSetPosition_SortsPointersBeforeAddingToNodeSet() {
              // Setup test data - create mock contexts with nodes in unsorted order
              EvalContext ctx1 = mock(EvalContext.class);
              EvalContext ctx2 = mock(EvalContext.class);
              NodePointer ptr1 = mock(NodePointer.class);
              NodePointer ptr2 = mock(NodePointer.class);
              NodePointer ptr3 = mock(NodePointer.class);
              
              // Mock context behavior to return nodes in unsorted order (3,1,2)
              when(ctx1.nextSet()).thenReturn(true, false);
              when(ctx1.nextNode()).thenReturn(true, true, true, false);
              when(ctx1.getCurrentNodePointer()).thenReturn(ptr3, ptr1, ptr2);
              
              // Second context has no nodes
              when(ctx2.nextSet()).thenReturn(false);
              
              EvalContext[] contexts = new EvalContext[]{ctx1, ctx2};
              BasicNodeSet nodeSet = new BasicNodeSet();
              
              // Create UnionContext with our test contexts
              UnionContext unionContext = new UnionContext(null, contexts);
              
              // Use reflection to access the private nodeSet field for verification
              try {
                  Field nodeSetField = UnionContext.class.getDeclaredField("nodeSet");
                  nodeSetField.setAccessible(true);
                  nodeSetField.set(unionContext, nodeSet);
              } catch (Exception e) {
                  fail("Failed to set nodeSet field via reflection: " + e.getMessage());
              }
              
              // Execute
              unionContext.setPosition(0);
              
              // Verify the pointers were added in sorted order (1,2,3)
              assertEquals(3, nodeSet.getPointers().size());
              assertTrue(nodeSet.getPointers().contains(ptr1));
              assertTrue(nodeSet.getPointers().contains(ptr2));
              assertTrue(nodeSet.getPointers().contains(ptr3));
              
              // Verify the first pointer is ptr1 (sorted order)
              assertEquals(ptr1, nodeSet.getPointers().get(0));
          }

    @Test
      public void testSetPosition_DetectsSortPointersMutant() {
          // Setup test data
          EvalContext mockContext1 = mock(EvalContext.class);
          EvalContext mockContext2 = mock(EvalContext.class);
          NodePointer pointer1 = mock(NodePointer.class);
          NodePointer pointer2 = mock(NodePointer.class);
          NodePointer pointer3 = mock(NodePointer.class);
          
          // Mock context behavior to return some nodes
          when(mockContext1.nextSet()).thenReturn(true, false);
          when(mockContext1.nextNode()).thenReturn(true, true, false);
          when(mockContext1.getCurrentNodePointer()).thenReturn(pointer2, pointer1);
          
          when(mockContext2.nextSet()).thenReturn(true, false);
          when(mockContext2.nextNode()).thenReturn(true, false);
          when(mockContext2.getCurrentNodePointer()).thenReturn(pointer3);
          
          EvalContext[] contexts = {mockContext1, mockContext2};
          UnionContext unionContext = new UnionContext(null, contexts);
          
          // Mock parent behavior
          BasicNodeSet parentNodeSet = new BasicNodeSet();
          when(unionContext.getNodeSet()).thenReturn(parentNodeSet);
          
          // Execute
          unionContext.setPosition(0);
          
          // Verify - original should have 3 sorted pointers, mutant would have 0
          assertEquals(3, parentNodeSet.getPointers().size());
          
          // Verify pointers are present and sorted (order matters)
          // Note: Actual sorting behavior depends on sortPointers implementation,
          // but we know they shouldn't be empty
          List<Pointer> resultPointers = parentNodeSet.getPointers();
          assertTrue(resultPointers.contains(pointer1));
          assertTrue(resultPointers.contains(pointer2));
          assertTrue(resultPointers.contains(pointer3));
          
          // Additional verification that the pointers are in the set
          // (mutant would clear them before adding)
          assertFalse(resultPointers.isEmpty());
      }

    @Test
    public void testSetPosition_AddsNodesToNodeSet() {
        // Setup test data
        NodePointer mockPointer1 = mock(NodePointer.class);
        NodePointer mockPointer2 = mock(NodePointer.class);
        
        // Create mock contexts that will return our test pointers
        EvalContext mockContext1 = mock(EvalContext.class);
        when(mockContext1.nextSet()).thenReturn(true).thenReturn(false);
        when(mockContext1.nextNode()).thenReturn(true).thenReturn(false);
        when(mockContext1.getCurrentNodePointer()).thenReturn(mockPointer1);
        
        EvalContext mockContext2 = mock(EvalContext.class);
        when(mockContext2.nextSet()).thenReturn(true).thenReturn(false);
        when(mockContext2.nextNode()).thenReturn(true).thenReturn(false);
        when(mockContext2.getCurrentNodePointer()).thenReturn(mockPointer2);
        
        EvalContext[] contexts = {mockContext1, mockContext2};
        EvalContext parentContext = mock(EvalContext.class);
        
        // Create instance
        UnionContext unionContext = new UnionContext(parentContext, contexts);
        
        // Use reflection to set prepared to false
        try {
            Field preparedField = UnionContext.class.getDeclaredField("prepared");
            preparedField.setAccessible(true);
            preparedField.setBoolean(unionContext, false);
        } catch (Exception e) {
            fail("Failed to set prepared field via reflection");
        }
        
        // Get the node set before calling setPosition
        BasicNodeSet nodeSet = (BasicNodeSet) unionContext.getNodeSet();
        int initialSize = nodeSet.getPointers().size();
        
        // Call the method
        unionContext.setPosition(0);
        
        // Verify results
        // The original code should add 2 nodes, mutant would remove them
        assertEquals("Node set should contain added nodes", 
                     initialSize + 2, nodeSet.getPointers().size());
        assertTrue("Node set should contain first pointer", 
                   nodeSet.getPointers().contains(mockPointer1));
        assertTrue("Node set should contain second pointer", 
                   nodeSet.getPointers().contains(mockPointer2));
    }


}
