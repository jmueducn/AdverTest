package gentest.org.apache.commons.jxpath.ri.model.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.*;
import java.util.Locale;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.JXPathContextReferenceImpl;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
 
public class NodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                    public void testCompareNodePointers_EqualParentsDifferentChildren() {
                                                                                                                                        NodePointer p1 = mock(NodePointer.class);
                                                                                                                                        NodePointer p2 = mock(NodePointer.class);
                                                                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                                                                        
                                                                                                                                        when(p1.getParent()).thenReturn(parent);
                                                                                                                                        when(p2.getParent()).thenReturn(parent);
                                                                                                                                        when(parent.equals(parent)).thenReturn(true);
                                                                                                                                        when(parent.compareChildNodePointers(p1, p2)).thenReturn(-1);
                                                                                                                                        
                                                                                                                                        // Create a concrete NodePointer instance using available factory method
                                                                                                                                        NodePointer testPointer = NodePointer.newNodePointer(null, null, null);
                                                                                                                                        
                                                                                                                                        // Use reflection to access the private compareNodePointers method
                                                                                                                                        try {
                                                                                                                                            Method method = NodePointer.class.getDeclaredMethod("compareNodePointers", 
                                                                                                                                                NodePointer.class, int.class, NodePointer.class, int.class);
                                                                                                                                            method.setAccessible(true);
                                                                                                                                            int result = (int) method.invoke(testPointer, p1, 2, p2, 2);
                                                                                                                                            assertEquals(-1, result);
                                                                                                                                        } catch (Exception e) {
                                                                                                                                            fail("Failed to invoke compareNodePointers method: " + e.getMessage());
                                                                                                                                        }
                                                                                                                                    }

    @Test
                                                                                                                                public void testCompareNodePointers_EqualPointersSameDepth() throws Exception {
                                                                                                                                    NodePointer pointer = mock(NodePointer.class);
                                                                                                                                    when(pointer.equals(pointer)).thenReturn(true);
                                                                                                                                    when(pointer.getParent()).thenReturn(null);
                                                                                                                                    
                                                                                                                                    // Get the private method via reflection
                                                                                                                                    Method compareNodePointers = NodePointer.class.getDeclaredMethod(
                                                                                                                                        "compareNodePointers", 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class, 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class
                                                                                                                                    );
                                                                                                                                    compareNodePointers.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Invoke the method on the pointer instance
                                                                                                                                    int result = (int) compareNodePointers.invoke(pointer, pointer, 2, pointer, 2);
                                                                                                                                    
                                                                                                                                    assertEquals(0, result);
                                                                                                                                }

    @Test
                                                                                                                                public void testCompareNodePointers_NullPointersSameDepth() throws Exception {
                                                                                                                                    NodePointer pointer = new NodePointer(null, null) {
                                                                                                                                        @Override
                                                                                                                                        public boolean isLeaf() { return false; }
                                                                                                                                        @Override
                                                                                                                                        public boolean isCollection() { return false; }
                                                                                                                                        @Override
                                                                                                                                        public int getLength() { return 0; }
                                                                                                                                        @Override
                                                                                                                                        public QName getName() { return null; }
                                                                                                                                        @Override
                                                                                                                                        public Object getBaseValue() { return null; }
                                                                                                                                        @Override
                                                                                                                                        public Object getImmediateNode() { return null; }
                                                                                                                                        @Override
                                                                                                                                        public void setValue(Object value) {}
                                                                                                                                        @Override
                                                                                                                                        public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) { return 0; }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                        "compareNodePointers", 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class, 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class
                                                                                                                                    );
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    
                                                                                                                                    int result = (int) method.invoke(pointer, null, 1, null, 1);
                                                                                                                                    assertEquals(0, result);
                                                                                                                                }

    @Test
                                                                                                                                public void testCompareNodePointers_DifferentDepthsP1Shallower() throws Exception {
                                                                                                                                    NodePointer p1 = mock(NodePointer.class);
                                                                                                                                    NodePointer p2 = mock(NodePointer.class);
                                                                                                                                    NodePointer p2Parent = mock(NodePointer.class);
                                                                                                                                    NodePointer testPointer = mock(NodePointer.class);
                                                                                                                                    
                                                                                                                                    when(p2.getParent()).thenReturn(p2Parent);
                                                                                                                                    when(p1.equals(p2Parent)).thenReturn(false);
                                                                                                                                    when(p1.compareChildNodePointers(any(), any())).thenReturn(1);
                                                                                                                                    
                                                                                                                                    // Use reflection to access private method
                                                                                                                                    Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                        "compareNodePointers", 
                                                                                                                                        NodePointer.class, int.class, NodePointer.class, int.class
                                                                                                                                    );
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    int result = (int) method.invoke(testPointer, p1, 1, p2, 2);
                                                                                                                                    
                                                                                                                                    assertTrue(result != 0);
                                                                                                                                }

    @Test
                                                                                                                                public void testCompareNodePointers_DifferentDepthsP2Shallower() throws Exception {
                                                                                                                                    NodePointer p1 = mock(NodePointer.class);
                                                                                                                                    NodePointer p2 = mock(NodePointer.class);
                                                                                                                                    NodePointer p1Parent = mock(NodePointer.class);
                                                                                                                                    
                                                                                                                                    when(p1.getParent()).thenReturn(p1Parent);
                                                                                                                                    when(p1Parent.equals(p2)).thenReturn(false);
                                                                                                                                    when(p1Parent.compareChildNodePointers(any(), any())).thenReturn(-1);
                                                                                                                                    
                                                                                                                                    // Create a concrete NodePointer using the factory method
                                                                                                                                    NodePointer testPointer = NodePointer.newNodePointer(null, null, null);
                                                                                                                                    
                                                                                                                                    // Use reflection to access private method
                                                                                                                                    Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                        "compareNodePointers", 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class, 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class
                                                                                                                                    );
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    int result = (int) method.invoke(testPointer, p1, 2, p2, 1);
                                                                                                                                    
                                                                                                                                    assertTrue(result != 0);
                                                                                                                                }

    @Test
                                                                                                                                public void testCompareNodePointers_DepthOneReturnsZero() throws Exception {
                                                                                                                                    NodePointer p1 = mock(NodePointer.class);
                                                                                                                                    NodePointer p2 = mock(NodePointer.class);
                                                                                                                                    NodePointer testPointer = mock(NodePointer.class);
                                                                                                                                    
                                                                                                                                    Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                        "compareNodePointers", 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class, 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class
                                                                                                                                    );
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    int result = (int) method.invoke(testPointer, p1, 1, p2, 1);
                                                                                                                                    
                                                                                                                                    assertEquals(0, result);
                                                                                                                                }

    @Test
                                                                                                                                public void testCompareNodePointers_RecursiveComparison() throws Exception {
                                                                                                                                    NodePointer p1 = mock(NodePointer.class);
                                                                                                                                    NodePointer p2 = mock(NodePointer.class);
                                                                                                                                    NodePointer p1Parent = mock(NodePointer.class);
                                                                                                                                    NodePointer p2Parent = mock(NodePointer.class);
                                                                                                                                    NodePointer testPointer = mock(NodePointer.class);
                                                                                                                                    
                                                                                                                                    when(p1.getParent()).thenReturn(p1Parent);
                                                                                                                                    when(p2.getParent()).thenReturn(p2Parent);
                                                                                                                                    when(p1Parent.equals(p2Parent)).thenReturn(false);
                                                                                                                                    when(p1Parent.compareChildNodePointers(p1, p2)).thenReturn(1);
                                                                                                                                    
                                                                                                                                    // Use reflection to access private method
                                                                                                                                    Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                        "compareNodePointers", 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class, 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class
                                                                                                                                    );
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    int result = (int) method.invoke(testPointer, p1, 2, p2, 2);
                                                                                                                                    
                                                                                                                                    assertEquals(1, result);
                                                                                                                                }

    @Test
                                                                                                                                public void testCompareNodePointers_OneNullPointer() throws Exception {
                                                                                                                                    NodePointer p1 = mock(NodePointer.class);
                                                                                                                                    NodePointer nullPointer = null;
                                                                                                                                    
                                                                                                                                    // Get the private method via reflection
                                                                                                                                    Method compareMethod = NodePointer.class.getDeclaredMethod(
                                                                                                                                        "compareNodePointers", 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class, 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class
                                                                                                                                    );
                                                                                                                                    compareMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Invoke the method
                                                                                                                                    int result = (int) compareMethod.invoke(
                                                                                                                                        null, // static method
                                                                                                                                        nullPointer, 
                                                                                                                                        2, 
                                                                                                                                        p1, 
                                                                                                                                        2
                                                                                                                                    );
                                                                                                                                    
                                                                                                                                    assertTrue(result != 0);
                                                                                                                                }

    @Test
                                                                                                                                public void testCompareNodePointers_DifferentDepthsWithEqualParents() throws Exception {
                                                                                                                                    NodePointer p1 = mock(NodePointer.class);
                                                                                                                                    NodePointer p2 = mock(NodePointer.class);
                                                                                                                                    NodePointer p2Parent = mock(NodePointer.class);
                                                                                                                                    NodePointer testPointer = mock(NodePointer.class);
                                                                                                                                    
                                                                                                                                    when(p2.getParent()).thenReturn(p2Parent);
                                                                                                                                    when(p1.equals(p2Parent)).thenReturn(true);
                                                                                                                                    
                                                                                                                                    // Use reflection to access private method
                                                                                                                                    Method method = NodePointer.class.getDeclaredMethod(
                                                                                                                                        "compareNodePointers", 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class, 
                                                                                                                                        NodePointer.class, 
                                                                                                                                        int.class
                                                                                                                                    );
                                                                                                                                    method.setAccessible(true);
                                                                                                                                    int result = (int) method.invoke(testPointer, p1, 1, p2, 2);
                                                                                                                                    
                                                                                                                                    assertEquals(-1, result);
                                                                                                                                }

    @Test
                                                                                                                           public void testCompareNodePointers_DetectsDepth1Mutation() throws Exception {
                                                                                                                               // Create mock NodePointer objects
                                                                                                                               NodePointer p1 = mock(NodePointer.class);
                                                                                                                               NodePointer p2 = mock(NodePointer.class);
                                                                                                                               NodePointer parent1 = mock(NodePointer.class);
                                                                                                                               NodePointer parent2 = mock(NodePointer.class);
                                                                                                                               
                                                                                                                               // Set up the test scenario:
                                                                                                                               // - depth1 = 2 (not 1)
                                                                                                                               // - pointers are not equal
                                                                                                                               // - parents are not equal
                                                                                                                               when(p1.getParent()).thenReturn(parent1);
                                                                                                                               when(p2.getParent()).thenReturn(parent2);
                                                                                                                               when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
                                                                                                                               
                                                                                                                               // Get the private method via reflection
                                                                                                                               Method compareNodePointersMethod = NodePointer.class.getDeclaredMethod(
                                                                                                                                   "compareNodePointers", NodePointer.class, int.class, NodePointer.class, int.class);
                                                                                                                               compareNodePointersMethod.setAccessible(true);
                                                                                                                               
                                                                                                                               // Call the method - should NOT return 0 since depth is not 1
                                                                                                                               // and pointers are not equal
                                                                                                                               int result = (int) compareNodePointersMethod.invoke(null, p1, 2, p2, 2);
                                                                                                                               
                                                                                                                               // Verify the mutation would be caught:
                                                                                                                               // Original code should return 1 (from parent comparison)
                                                                                                                               // Mutated code would return 0 (due to 'if (true)')
                                                                                                                               assertNotEquals("Should not return 0 when depth is not 1", 0, result);
                                                                                                                               
                                                                                                                               // Additional verification that parent comparison was called
                                                                                                                               verify(parent1).compareChildNodePointers(p1, p2);
                                                                                                                           }

    @Test
                                                                                                                      public void testCompareNodePointers_DetectsMutant_WhenParentsDiffer() throws Exception {
                                                                                                                          // Create mock parent nodes that will compare differently
                                                                                                                          NodePointer parent1 = mock(NodePointer.class);
                                                                                                                          NodePointer parent2 = mock(NodePointer.class);
                                                                                                                          
                                                                                                                          // Setup mock behavior - parents compare as different
                                                                                                                          when(parent1.compareChildNodePointers(any(), any())).thenReturn(-1);
                                                                                                                          when(parent2.compareChildNodePointers(any(), any())).thenReturn(1);
                                                                                                                          
                                                                                                                          // Create test nodes with these parents
                                                                                                                          NodePointer p1 = mock(NodePointer.class);
                                                                                                                          NodePointer p2 = mock(NodePointer.class);
                                                                                                                          when(p1.getParent()).thenReturn(parent1);
                                                                                                                          when(p2.getParent()).thenReturn(parent2);
                                                                                                                          
                                                                                                                          // Nodes themselves are different but not null
                                                                                                                          when(p1.equals(p2)).thenReturn(false);
                                                                                                                          
                                                                                                                          // Test with depth > 1
                                                                                                                          int depth1 = 2;
                                                                                                                          int depth2 = 2;
                                                                                                                          
                                                                                                                          // Use reflection to access private compareNodePointers method
                                                                                                                          Method compareMethod = NodePointer.class.getDeclaredMethod(
                                                                                                                              "compareNodePointers", 
                                                                                                                              NodePointer.class, 
                                                                                                                              int.class, 
                                                                                                                              NodePointer.class, 
                                                                                                                              int.class
                                                                                                                          );
                                                                                                                          compareMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // The original code should return -1 based on parent comparison
                                                                                                                          // The mutant will keep comparing p1 vs p2 at same depth
                                                                                                                          int result = (int) compareMethod.invoke(null, p1, depth1, p2, depth2);
                                                                                                                          
                                                                                                                          // Verify the result is based on parent comparison
                                                                                                                          assertEquals(-1, result);
                                                                                                                          
                                                                                                                          // Verify parent comparison was called (would fail with mutant)
                                                                                                                          verify(parent1).compareChildNodePointers(p1, p2);
                                                                                                                      }

    @Test
                                                                                                                 public void testCompareNodePointers_DetectsDepthMutation() throws Exception {
                                                                                                                     // Create mock parent pointers
                                                                                                                     NodePointer parent1 = mock(NodePointer.class);
                                                                                                                     NodePointer parent2 = mock(NodePointer.class);
                                                                                                                     
                                                                                                                     // Create test pointers with parents
                                                                                                                     NodePointer p2 = mock(NodePointer.class);
                                                                                                                     when(p2.getParent()).thenReturn(parent2);
                                                                                                                     when(p2.equals(any())).thenReturn(false);
                                                                                                                     
                                                                                                                     NodePointer p1 = mock(NodePointer.class);
                                                                                                                     when(p1.getParent()).thenReturn(parent1);
                                                                                                                     when(p1.equals(p2)).thenReturn(false);
                                                                                                                     
                                                                                                                     // Set up parent comparison behavior
                                                                                                                     when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
                                                                                                                     
                                                                                                                     // Get private method through reflection
                                                                                                                     Method compareNodePointers = NodePointer.class.getDeclaredMethod(
                                                                                                                         "compareNodePointers", 
                                                                                                                         NodePointer.class, 
                                                                                                                         int.class, 
                                                                                                                         NodePointer.class, 
                                                                                                                         int.class
                                                                                                                     );
                                                                                                                     compareNodePointers.setAccessible(true);
                                                                                                                     
                                                                                                                     // Test with depths > 1
                                                                                                                     int result = (int) compareNodePointers.invoke(
                                                                                                                         null, // static method
                                                                                                                         p1, 
                                                                                                                         2, 
                                                                                                                         p2, 
                                                                                                                         2
                                                                                                                     );
                                                                                                                     
                                                                                                                     // Verify the correct comparison result
                                                                                                                     assertEquals(1, result);
                                                                                                                     
                                                                                                                     // Verify parent comparison was called
                                                                                                                     verify(parent1).compareChildNodePointers(p1, p2);
                                                                                                                 }

    @Test
                                                                                                            public void testCompareNodePointersDetectsParameterSwapMutant() throws Exception {
                                                                                                                // Create mock parent nodes with order-sensitive comparison
                                                                                                                NodePointer parent1 = mock(NodePointer.class);
                                                                                                                NodePointer parent2 = mock(NodePointer.class);
                                                                                                                
                                                                                                                // Setup mock behavior - return different values based on parameter order
                                                                                                                when(parent1.compareChildNodePointers(parent1, parent2)).thenReturn(1);
                                                                                                                when(parent1.compareChildNodePointers(parent2, parent1)).thenReturn(-1);
                                                                                                                
                                                                                                                // Create test nodes with same depth > 1
                                                                                                                NodePointer p1 = mock(NodePointer.class);
                                                                                                                NodePointer p2 = mock(NodePointer.class);
                                                                                                                
                                                                                                                // Setup parent relationships
                                                                                                                when(p1.getParent()).thenReturn(parent1);
                                                                                                                when(p2.getParent()).thenReturn(parent2);
                                                                                                                
                                                                                                                // Setup depth conditions
                                                                                                                int depth = 2; // >1 to reach the mutated code
                                                                                                                
                                                                                                                // Get the private method via reflection
                                                                                                                Method compareNodePointersMethod = NodePointer.class.getDeclaredMethod(
                                                                                                                    "compareNodePointers", 
                                                                                                                    NodePointer.class, 
                                                                                                                    int.class, 
                                                                                                                    NodePointer.class, 
                                                                                                                    int.class
                                                                                                                );
                                                                                                                compareNodePointersMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Test original behavior - should return 1 based on our mock setup
                                                                                                                int result = (int) compareNodePointersMethod.invoke(
                                                                                                                    null, // static method
                                                                                                                    p1, 
                                                                                                                    depth, 
                                                                                                                    p2, 
                                                                                                                    depth
                                                                                                                );
                                                                                                                
                                                                                                                // Assert the expected result would be different if parameters were swapped
                                                                                                                assertEquals(1, result);
                                                                                                                
                                                                                                                // Verify the mock interactions
                                                                                                                verify(parent1).compareChildNodePointers(p1, p2);
                                                                                                            }

    @Test
                                                                                                       public void testCompareNodePointers_DetectsMutantWhenRecursiveComparisonNonZero() throws Exception {
                                                                                                           // Create mock nodes with different comparison behaviors
                                                                                                           NodePointer p1 = mock(NodePointer.class);
                                                                                                           NodePointer p2 = mock(NodePointer.class);
                                                                                                           NodePointer parent1 = mock(NodePointer.class);
                                                                                                           NodePointer parent2 = mock(NodePointer.class);
                                                                                                           
                                                                                                           // Set up parent relationships
                                                                                                           when(p1.getParent()).thenReturn(parent1);
                                                                                                           when(p2.getParent()).thenReturn(parent2);
                                                                                                           
                                                                                                           // Set up recursive comparison to return non-zero (1)
                                                                                                           when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
                                                                                                           
                                                                                                           // Set up child comparison to return different value (-1)
                                                                                                           when(p1.compareChildNodePointers(p1, p2)).thenReturn(-1);
                                                                                                           
                                                                                                           // Get the private method via reflection
                                                                                                           Method compareNodePointers = NodePointer.class.getDeclaredMethod(
                                                                                                               "compareNodePointers", 
                                                                                                               NodePointer.class, 
                                                                                                               int.class, 
                                                                                                               NodePointer.class, 
                                                                                                               int.class
                                                                                                           );
                                                                                                           compareNodePointers.setAccessible(true);
                                                                                                           
                                                                                                           // Test with equal depths > 1
                                                                                                           int result = (int) compareNodePointers.invoke(
                                                                                                               p1, // using p1 as instance since method is non-static
                                                                                                               p1, 
                                                                                                               2, 
                                                                                                               p2, 
                                                                                                               2
                                                                                                           );
                                                                                                           
                                                                                                           // Original would return 1 (from recursive comparison)
                                                                                                           // Mutant would return -1 (from child comparison)
                                                                                                           assertEquals("Should return recursive comparison result when non-zero", 1, result);
                                                                                                       }

    @Test
                                                                                                  public void testCompareNodePointers_DetectsNegativeComparison() throws Exception {
                                                                                                      // Create parent pointers
                                                                                                      NodePointer grandParent1 = mock(NodePointer.class);
                                                                                                      NodePointer grandParent2 = mock(NodePointer.class);
                                                                                                      
                                                                                                      // Create parent pointers with different parents
                                                                                                      NodePointer parent1 = mock(NodePointer.class);
                                                                                                      when(parent1.getParent()).thenReturn(grandParent1);
                                                                                                      NodePointer parent2 = mock(NodePointer.class);
                                                                                                      when(parent2.getParent()).thenReturn(grandParent2);
                                                                                                      
                                                                                                      // Create test pointers
                                                                                                      NodePointer p1 = mock(NodePointer.class);
                                                                                                      when(p1.getParent()).thenReturn(parent1);
                                                                                                      NodePointer p2 = mock(NodePointer.class);
                                                                                                      when(p2.getParent()).thenReturn(parent2);
                                                                                                      
                                                                                                      // Setup mock behavior
                                                                                                      // Make the recursive call return negative
                                                                                                      when(grandParent1.compareChildNodePointers(parent1, parent2)).thenReturn(-1);
                                                                                                      
                                                                                                      // Create a real NodePointer instance to access the private method
                                                                                                      NodePointer testPointer = new NodePointer(null, Locale.getDefault()) {
                                                                                                          @Override
                                                                                                          public boolean isLeaf() { return false; }
                                                                                                          @Override
                                                                                                          public boolean isCollection() { return false; }
                                                                                                          @Override
                                                                                                          public int getLength() { return 0; }
                                                                                                          @Override
                                                                                                          public QName getName() { return null; }
                                                                                                          @Override
                                                                                                          public Object getBaseValue() { return null; }
                                                                                                          @Override
                                                                                                          public Object getImmediateNode() { return null; }
                                                                                                          @Override
                                                                                                          public void setValue(Object value) {}
                                                                                                          @Override
                                                                                                          public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) { return 0; }
                                                                                                      };
                                                                                                      
                                                                                                      // Use reflection to access private method
                                                                                                      Method method = NodePointer.class.getDeclaredMethod("compareNodePointers", 
                                                                                                          NodePointer.class, int.class, NodePointer.class, int.class);
                                                                                                      method.setAccessible(true);
                                                                                                      
                                                                                                      // Call the method with depth=3 (will recurse down to parents)
                                                                                                      int result = (int) method.invoke(testPointer, p1, 3, p2, 3);
                                                                                                      
                                                                                                      // Verify the negative result is returned (would be lost in mutant)
                                                                                                      assertEquals(-1, result);
                                                                                                      
                                                                                                      // Verify interactions
                                                                                                      verify(grandParent1).compareChildNodePointers(parent1, parent2);
                                                                                                  }

    @Test
                                                                                             public void testCompareNodePointers_DetectsPositiveComparisonResult() throws Exception {
                                                                                                 // Create mock NodePointer instances
                                                                                                 NodePointer p1 = mock(NodePointer.class);
                                                                                                 NodePointer p2 = mock(NodePointer.class);
                                                                                                 NodePointer parent1 = mock(NodePointer.class);
                                                                                                 NodePointer parent2 = mock(NodePointer.class);
                                                                                                 
                                                                                                 // Set up parent relationships
                                                                                                 when(p1.getParent()).thenReturn(parent1);
                                                                                                 when(p2.getParent()).thenReturn(parent2);
                                                                                                 
                                                                                                 // Set up comparison results
                                                                                                 // First recursive call will return positive value
                                                                                                 when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
                                                                                                 
                                                                                                 // Set up parent comparison to return positive value
                                                                                                 when(parent1.compareTo(parent2)).thenReturn(1);
                                                                                                 
                                                                                                 // Get the private method via reflection
                                                                                                 Method method = NodePointer.class.getDeclaredMethod(
                                                                                                     "compareNodePointers", 
                                                                                                     NodePointer.class, int.class, NodePointer.class, int.class
                                                                                                 );
                                                                                                 method.setAccessible(true);
                                                                                                 
                                                                                                 // Call the method with equal depths > 1
                                                                                                 int result = (int) method.invoke(null, p1, 2, p2, 2);
                                                                                                 
                                                                                                 // Verify the positive comparison result is returned
                                                                                                 assertEquals(1, result);
                                                                                                 
                                                                                                 // Verify parent comparison was called
                                                                                                 verify(parent1).compareChildNodePointers(p1, p2);
                                                                                             }

    @Test
                                                                                    public void testCompareNodePointers_DetectMutant() throws Exception {
                                                                                        // Create mock parent pointers that will compare equal
                                                                                        NodePointer parent1 = mock(NodePointer.class);
                                                                                        NodePointer parent2 = mock(NodePointer.class);
                                                                                        
                                                                                        // Create test pointers with these parents
                                                                                        NodePointer p1 = mock(NodePointer.class);
                                                                                        NodePointer p2 = mock(NodePointer.class);
                                                                                        when(p1.getParent()).thenReturn(parent1);
                                                                                        when(p2.getParent()).thenReturn(parent2);
                                                                                        
                                                                                        // Setup parent comparison to return 0 (equal)
                                                                                        when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1); // children are different
                                                                                        
                                                                                        // Get the private method via reflection
                                                                                        Method compareNodePointersMethod = NodePointer.class.getDeclaredMethod(
                                                                                            "compareNodePointers", 
                                                                                            NodePointer.class, 
                                                                                            int.class, 
                                                                                            NodePointer.class, 
                                                                                            int.class
                                                                                        );
                                                                                        compareNodePointersMethod.setAccessible(true);
                                                                                        
                                                                                        // Invoke the method with test parameters
                                                                                        int result = (int) compareNodePointersMethod.invoke(p1, p1, 2, p2, 2);
                                                                                        
                                                                                        // Original should return 1 (from compareChildNodePointers)
                                                                                        // Mutant would return 0 (from parent comparison)
                                                                                        assertEquals("Should return result of compareChildNodePointers when parents are equal", 
                                                                                                    1, result);
                                                                                    }

    @Test
                                                                               public void testCompareNodePointersDepthCondition() throws Exception {
                                                                                   // Create mock NodePointer objects
                                                                                   NodePointer parent1 = mock(NodePointer.class);
                                                                                   NodePointer parent2 = mock(NodePointer.class);
                                                                                   NodePointer p1 = mock(NodePointer.class);
                                                                                   NodePointer p2 = mock(NodePointer.class);
                                                                                   
                                                                                   // Set up parent relationships
                                                                                   when(p1.getParent()).thenReturn(parent1);
                                                                                   when(p2.getParent()).thenReturn(parent2);
                                                                                   
                                                                                   // Set up comparison behavior
                                                                                   when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
                                                                                   
                                                                                   // Get the private method via reflection
                                                                                   Method compareNodePointers = NodePointer.class.getDeclaredMethod(
                                                                                       "compareNodePointers", 
                                                                                       NodePointer.class, 
                                                                                       int.class, 
                                                                                       NodePointer.class, 
                                                                                       int.class
                                                                                   );
                                                                                   compareNodePointers.setAccessible(true);
                                                                                   
                                                                                   // Test case where depth1 = 2 (should NOT return 0)
                                                                                   int result = (int) compareNodePointers.invoke(null, p1, 2, p2, 2);
                                                                                   
                                                                                   // Verify it didn't return 0 (which mutant would do)
                                                                                   assertNotEquals(0, result);
                                                                                   
                                                                                   // Verify it actually performed the parent comparison
                                                                                   verify(parent1).compareChildNodePointers(p1, p2);
                                                                                   
                                                                                   // Also test depth1 = 1 case (both original and mutant should return 0)
                                                                                   result = (int) compareNodePointers.invoke(null, p1, 1, p2, 1);
                                                                                   assertEquals(0, result);
                                                                               }

    @Test
                                                                          public void testCompareNodePointers_DetectsMutantByComparingParentNodes() {
                                                                              // Create mock node hierarchy: grandparent -> parent1 -> child1
                                                                              NodePointer grandparent = mock(NodePointer.class);
                                                                              NodePointer parent1 = mock(NodePointer.class);
                                                                              NodePointer child1 = mock(NodePointer.class);
                                                                              
                                                                              when(parent1.getParent()).thenReturn(grandparent);
                                                                              when(child1.getParent()).thenReturn(parent1);
                                                                              
                                                                              // Create another hierarchy: grandparent -> parent2 -> child2
                                                                              NodePointer parent2 = mock(NodePointer.class);
                                                                              NodePointer child2 = mock(NodePointer.class);
                                                                              
                                                                              when(parent2.getParent()).thenReturn(grandparent);
                                                                              when(child2.getParent()).thenReturn(parent2);
                                                                              
                                                                              // Mock compareChildNodePointers to return different values for parents vs children
                                                                              when(grandparent.compareChildNodePointers(parent1, parent2)).thenReturn(1);
                                                                              when(parent1.compareChildNodePointers(child1, child2)).thenReturn(-1);
                                                                              
                                                                              // Test comparison at depth 2 (should compare parents)
                                                                              int result = child1.compareTo(child2);
                                                                              
                                                                              // Original would return 1 (from parent comparison)
                                                                              // Mutant would return -1 (from child comparison)
                                                                              assertEquals("Should return parent comparison result", 1, result);
                                                                          }

    @Test
                                                                     public void testCompareNodePointers_DetectsDepthMutation1() throws Exception {
                                                                         // Create a parent-child structure with depth > 1
                                                                         NodePointer grandParent = mock(NodePointer.class);
                                                                         NodePointer parent1 = mock(NodePointer.class);
                                                                         NodePointer parent2 = mock(NodePointer.class);
                                                                         NodePointer child1 = mock(NodePointer.class);
                                                                         NodePointer child2 = mock(NodePointer.class);
                                                                         
                                                                         // Set up parent relationships
                                                                         when(child1.getParent()).thenReturn(parent1);
                                                                         when(child2.getParent()).thenReturn(parent2);
                                                                         when(parent1.getParent()).thenReturn(grandParent);
                                                                         when(parent2.getParent()).thenReturn(grandParent);
                                                                         
                                                                         // Mock the final comparison to return a known value
                                                                         when(grandParent.compareChildNodePointers(parent1, parent2)).thenReturn(1);
                                                                         
                                                                         // Get the private method via reflection
                                                                         Method compareNodePointers = NodePointer.class.getDeclaredMethod(
                                                                             "compareNodePointers", 
                                                                             NodePointer.class, 
                                                                             int.class, 
                                                                             NodePointer.class, 
                                                                             int.class
                                                                         );
                                                                         compareNodePointers.setAccessible(true);
                                                                         
                                                                         // Test with depth=2 (should do one recursive call with depth=1)
                                                                         int result = (int) compareNodePointers.invoke(
                                                                             null, // static method
                                                                             child1, 
                                                                             2, 
                                                                             child2, 
                                                                             2
                                                                         );
                                                                         
                                                                         // Verify the result comes from grandParent comparison
                                                                         assertEquals(1, result);
                                                                         
                                                                         // Verify the recursion worked correctly by checking parent calls
                                                                         verify(child1).getParent();
                                                                         verify(child2).getParent();
                                                                         verify(parent1).getParent();
                                                                         verify(parent2).getParent();
                                                                         verify(grandParent).compareChildNodePointers(parent1, parent2);
                                                                     }

    @Test
                                                                public void testCompareNodePointersDetectsParameterSwapMutant1() throws Exception {
                                                                    // Create mock parent pointers with order-sensitive comparison
                                                                    NodePointer parent1 = mock(NodePointer.class);
                                                                    NodePointer parent2 = mock(NodePointer.class);
                                                                    
                                                                    // Setup mock behavior - comparison is order sensitive
                                                                    when(parent1.compareChildNodePointers(parent1, parent2)).thenReturn(1);
                                                                    when(parent1.compareChildNodePointers(parent2, parent1)).thenReturn(-1);
                                                                    
                                                                    // Create test pointers with same depth > 1
                                                                    NodePointer p1 = mock(NodePointer.class);
                                                                    NodePointer p2 = mock(NodePointer.class);
                                                                    
                                                                    // Setup parent relationships
                                                                    when(p1.getParent()).thenReturn(parent1);
                                                                    when(p2.getParent()).thenReturn(parent2);
                                                                    
                                                                    // Setup depth > 1
                                                                    int depth = 2;
                                                                    
                                                                    // Get the private method via reflection
                                                                    Method compareNodePointers = NodePointer.class.getDeclaredMethod(
                                                                        "compareNodePointers", 
                                                                        NodePointer.class, 
                                                                        int.class, 
                                                                        NodePointer.class, 
                                                                        int.class
                                                                    );
                                                                    compareNodePointers.setAccessible(true);
                                                                    
                                                                    // Create a NodePointer instance to invoke the method on
                                                                    NodePointer nodePointer = mock(NodePointer.class);
                                                                    
                                                                    // Call original method - should return 1
                                                                    int originalResult = (int) compareNodePointers.invoke(
                                                                        nodePointer, 
                                                                        p1, 
                                                                        depth, 
                                                                        p2, 
                                                                        depth
                                                                    );
                                                                    
                                                                    // Assert original behavior
                                                                    assertEquals(1, originalResult);
                                                                    
                                                                    // Verify mock interactions
                                                                    verify(parent1).compareChildNodePointers(p1, p2);
                                                                }

    @Test
                                                           public void testCompareNodePointers_DetectsMutantWhenRecursiveComparisonNonZero1() throws Exception {
                                                               // Create mock NodePointer objects
                                                               NodePointer p1 = mock(NodePointer.class);
                                                               NodePointer p2 = mock(NodePointer.class);
                                                               NodePointer parent1 = mock(NodePointer.class);
                                                               NodePointer parent2 = mock(NodePointer.class);
                                                               
                                                               // Set up parent relationships
                                                               when(p1.getParent()).thenReturn(parent1);
                                                               when(p2.getParent()).thenReturn(parent2);
                                                               
                                                               // Set up recursive comparison to return non-zero
                                                               // Mock the behavior of compareChildNodePointers to return different value
                                                               when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
                                                               
                                                               // Get the private method via reflection
                                                               Method method = NodePointer.class.getDeclaredMethod(
                                                                   "compareNodePointers", 
                                                                   NodePointer.class, 
                                                                   int.class, 
                                                                   NodePointer.class, 
                                                                   int.class
                                                               );
                                                               method.setAccessible(true);
                                                               
                                                               // Test with depths > 1 to ensure we reach the mutated condition
                                                               int result = (int) method.invoke(null, p1, 2, p2, 2);
                                                               
                                                               // In original code, should return -1 (from recursive comparison)
                                                               // In mutated code, would return 1 (from child comparison)
                                                               // So assertion will fail for mutated code
                                                               assertEquals(-1, result);
                                                               
                                                               // Verify the interactions
                                                               verify(parent1).compareChildNodePointers(p1, p2);
                                                           }

    @Test
                                                      public void testCompareNodePointers_DetectsNegativeComparison1() {
                                                          // Create mock NodePointer objects
                                                          NodePointer p1 = mock(NodePointer.class);
                                                          NodePointer p2 = mock(NodePointer.class);
                                                          NodePointer parent1 = mock(NodePointer.class);
                                                          NodePointer parent2 = mock(NodePointer.class);
                                                          
                                                          // Set up the scenario where:
                                                          // - p1 is at depth 2, p2 at depth 1
                                                          // - The recursive comparison (p1.parent vs p2) returns -1
                                                          when(p1.getParent()).thenReturn(parent1);
                                                          when(p2.getParent()).thenReturn(parent2);
                                                          
                                                          // Mock the compareChildNodePointers to return 0 (not relevant for this test)
                                                          when(parent1.compareChildNodePointers(any(), any())).thenReturn(0);
                                                          
                                                          // Create test instance using mock instead of trying to instantiate abstract class
                                                          NodePointer testPointer = mock(NodePointer.class);
                                                          
                                                          // Use reflection to access private method
                                                          try {
                                                              Method method = NodePointer.class.getDeclaredMethod(
                                                                  "compareNodePointers", 
                                                                  NodePointer.class, int.class, NodePointer.class, int.class
                                                              );
                                                              method.setAccessible(true);
                                                              
                                                              // Test case where recursive comparison returns -1
                                                              // Original: should return -1
                                                              // Mutant: would return 0 (since -1 > 0 is false)
                                                              int result = (int) method.invoke(testPointer, p1, 2, p2, 1);
                                                              
                                                              // Assert that we get the negative comparison result
                                                              assertEquals("Should return negative comparison result", -1, result);
                                                          } catch (Exception e) {
                                                              fail("Failed to invoke private method: " + e.getMessage());
                                                          }
                                                      }

    @Test
                                                 public void testCompareNodePointers_DetectsRNot0ToRLess0Mutant() throws Exception {
                                                     // Create mock nodes with parent-child relationships
                                                     NodePointer parent1 = mock(NodePointer.class);
                                                     NodePointer parent2 = mock(NodePointer.class);
                                                     NodePointer child1 = mock(NodePointer.class);
                                                     NodePointer child2 = mock(NodePointer.class);
                                                     
                                                     // Setup behavior
                                                     when(child1.getParent()).thenReturn(parent1);
                                                     when(child2.getParent()).thenReturn(parent2);
                                                     
                                                     // Make recursive call return positive value
                                                     when(parent1.compareChildNodePointers(any(), any())).thenReturn(1);
                                                     
                                                     // Get the private method via reflection
                                                     Method compareNodePointers = NodePointer.class.getDeclaredMethod(
                                                         "compareNodePointers", 
                                                         NodePointer.class, 
                                                         int.class, 
                                                         NodePointer.class, 
                                                         int.class
                                                     );
                                                     compareNodePointers.setAccessible(true);
                                                     
                                                     // Call the method - depth > 1 to ensure we reach the mutated condition
                                                     int result = (int) compareNodePointers.invoke(
                                                         null, // static method
                                                         child1, 
                                                         2, 
                                                         child2, 
                                                         2
                                                     );
                                                     
                                                     // Verify the behavior difference:
                                                     // Original would return 1 immediately (r != 0)
                                                     // Mutant would continue to call compareChildNodePointers
                                                     // So we verify parent1.compareChildNodePointers was NOT called (original behavior)
                                                     verify(parent1, never()).compareChildNodePointers(any(), any());
                                                     
                                                     // Also assert the expected return value
                                                     assertEquals(1, result);
                                                 }

    @Test
                                            public void testCompareNodePointers_ShouldContinueWhenParentComparisonIsZero() throws Exception {
                                                // Create mock nodes with hierarchy: 
                                                // root -> parent1 -> child1
                                                // root -> parent1 -> child2
                                                NodePointer root = mock(NodePointer.class);
                                                NodePointer parent1 = mock(NodePointer.class);
                                                NodePointer child1 = mock(NodePointer.class);
                                                NodePointer child2 = mock(NodePointer.class);
                                                
                                                // Set up parent relationships
                                                when(child1.getParent()).thenReturn(parent1);
                                                when(child2.getParent()).thenReturn(parent1);
                                                when(parent1.getParent()).thenReturn(root);
                                                
                                                // Make parent-level comparison return 0 (equal)
                                                when(parent1.compareChildNodePointers(child1, child2)).thenReturn(1); // children are different
                                                
                                                // Get the private method via reflection
                                                Method compareNodePointersMethod = NodePointer.class.getDeclaredMethod(
                                                    "compareNodePointers", 
                                                    NodePointer.class, 
                                                    int.class, 
                                                    NodePointer.class, 
                                                    int.class
                                                );
                                                compareNodePointersMethod.setAccessible(true);
                                                
                                                // Test comparison at depth=2 (comparing children)
                                                int result = (int) compareNodePointersMethod.invoke(
                                                    null, // static method
                                                    child1, 
                                                    2, 
                                                    child2, 
                                                    2
                                                );
                                                
                                                // Verify: 
                                                // Original: Should return 1 (from compareChildNodePointers)
                                                // Mutant: Would return 0 (from parent comparison due to if(true))
                                                assertEquals("Should return child comparison result when parents are equal", 
                                                            1, result);
                                                
                                                // Verify parent comparison was called
                                                verify(parent1).compareChildNodePointers(child1, child2);
                                            }

    @Test
                                       public void testCompareNodePointersDepthCondition1() throws Exception {
                                           // Create mock NodePointer objects
                                           NodePointer parent1 = mock(NodePointer.class);
                                           NodePointer parent2 = mock(NodePointer.class);
                                           NodePointer child1 = mock(NodePointer.class);
                                           NodePointer child2 = mock(NodePointer.class);
                                           
                                           // Set up parent-child relationships
                                           when(child1.getParent()).thenReturn(parent1);
                                           when(child2.getParent()).thenReturn(parent2);
                                           
                                           // Set up comparison behavior
                                           when(parent1.compareChildNodePointers(child1, child2)).thenReturn(1);
                                           
                                           // Get private method via reflection
                                           Method compareNodePointers = NodePointer.class.getDeclaredMethod(
                                               "compareNodePointers", 
                                               NodePointer.class, 
                                               int.class, 
                                               NodePointer.class, 
                                               int.class
                                           );
                                           compareNodePointers.setAccessible(true);
                                           
                                           // Test case where depth1 is 2 (not 1) - should not return 0
                                           int result = (int) compareNodePointers.invoke(
                                               null, // static method
                                               child1, 
                                               2, 
                                               child2, 
                                               2
                                           );
                                           
                                           // Verify the mutant would return 0 here, but original should return 1
                                           assertEquals("Should not return 0 when depth is not 1", 1, result);
                                           
                                           // Test case where depth1 is 1 - should return 0
                                           result = (int) compareNodePointers.invoke(
                                               null, // static method
                                               child1, 
                                               1, 
                                               child2, 
                                               1
                                           );
                                           assertEquals("Should return 0 when depth is 1", 0, result);
                                       }

    @Test
                                  public void testCompareNodePointers_DetectsMutantByCheckingParentComparison() throws Exception {
                                      // Create mock parent nodes that will be different
                                      NodePointer parent1 = mock(NodePointer.class);
                                      NodePointer parent2 = mock(NodePointer.class);
                                      
                                      // Setup mock behavior for parent comparison
                                      when(parent1.compareChildNodePointers(any(), any())).thenReturn(1);
                                      
                                      // Create test nodes with these parents
                                      NodePointer p1 = mock(NodePointer.class);
                                      NodePointer p2 = mock(NodePointer.class);
                                      when(p1.getParent()).thenReturn(parent1);
                                      when(p2.getParent()).thenReturn(parent2);
                                      
                                      // Nodes are different but not null
                                      when(p1.equals(p2)).thenReturn(false);
                                      
                                      // Get private compareNodePointers method via reflection
                                      Method compareNodePointersMethod = NodePointer.class.getDeclaredMethod(
                                          "compareNodePointers", 
                                          NodePointer.class, 
                                          int.class, 
                                          NodePointer.class, 
                                          int.class
                                      );
                                      compareNodePointersMethod.setAccessible(true);
                                      
                                      // Test with depth > 1 to ensure parent comparison is reached
                                      int result = (int) compareNodePointersMethod.invoke(
                                          null, // static method
                                          p1, 
                                          2, 
                                          p2, 
                                          2
                                      );
                                      
                                      // Verify the result comes from parent comparison
                                      assertEquals(1, result);
                                      
                                      // Verify parent comparison was attempted
                                      verify(parent1).compareChildNodePointers(p1, p2);
                                  }

    @Test
                             public void testCompareNodePointers_DetectsDepthMutation2() throws Exception {
                                 // Create mock parent pointers
                                 NodePointer parent1 = mock(NodePointer.class);
                                 NodePointer parent2 = mock(NodePointer.class);
                                 
                                 // Create test pointers with parents
                                 NodePointer p1 = mock(NodePointer.class);
                                 NodePointer p2 = mock(NodePointer.class);
                                 when(p1.getParent()).thenReturn(parent1);
                                 when(p2.getParent()).thenReturn(parent2);
                                 
                                 // Set up comparison behavior
                                 // Original would compare parents at depth-1, mutant compares at original depth
                                 // So we need to make the comparison different at different depths
                                 when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
                                 when(parent2.compareChildNodePointers(p1, p2)).thenReturn(-1);
                                 
                                 // Test with depth > 1
                                 int depth = 2;
                                 
                                 // Get the private method via reflection
                                 Method method = NodePointer.class.getDeclaredMethod(
                                     "compareNodePointers", 
                                     NodePointer.class, 
                                     int.class, 
                                     NodePointer.class, 
                                     int.class
                                 );
                                 method.setAccessible(true);
                                 
                                 // Invoke the method on a test instance (we'll use parent1 as the instance)
                                 int result = (int) method.invoke(parent1, p1, depth, p2, depth);
                                 
                                 // Assert the correct comparison result
                                 assertEquals(1, result);
                                 
                                 // Verify parent comparison was called
                                 verify(parent1).compareChildNodePointers(p1, p2);
                             }

    @Test
                        public void testCompareNodePointersDetectsParameterSwapMutant2() throws Exception {
                            // Create mock NodePointers with parents
                            NodePointer parent1 = mock(NodePointer.class);
                            NodePointer parent2 = mock(NodePointer.class);
                            
                            NodePointer p1 = mock(NodePointer.class);
                            NodePointer p2 = mock(NodePointer.class);
                            
                            // Set up parent relationships
                            when(p1.getParent()).thenReturn(parent1);
                            when(p2.getParent()).thenReturn(parent2);
                            
                            // Make sure pointers are not equal and not null
                            when(p1.equals(p2)).thenReturn(false);
                            
                            // Set up asymmetric comparison results
                            // First recursive call should return non-zero
                            when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
                            when(parent2.compareChildNodePointers(p2, p1)).thenReturn(-1);
                            
                            // Test with equal depths > 1
                            int depth = 2;
                            
                            // Create test instance using mock
                            NodePointer testPointer = mock(NodePointer.class);
                            
                            // Use reflection to access private method
                            Method method = NodePointer.class.getDeclaredMethod(
                                "compareNodePointers", 
                                NodePointer.class, 
                                int.class, 
                                NodePointer.class, 
                                int.class
                            );
                            method.setAccessible(true);
                            
                            // Invoke the method
                            int result = (int) method.invoke(testPointer, p1, depth, p2, depth);
                            
                            // Verify the result matches original behavior
                            assertEquals(1, result);
                            
                            // Verify parent comparisons were called
                            verify(p1).getParent();
                            verify(p2).getParent();
                            verify(parent1).compareChildNodePointers(p1, p2);
                        }

    @Test
                   public void testCompareNodePointers_DetectsMutatedCondition() throws Exception {
                       // Create mock nodes with hierarchy
                       NodePointer grandParent = mock(NodePointer.class);
                       NodePointer parent1 = mock(NodePointer.class);
                       NodePointer parent2 = mock(NodePointer.class);
                       NodePointer child1 = mock(NodePointer.class);
                       NodePointer child2 = mock(NodePointer.class);
                       
                       // Set up parent-child relationships
                       when(child1.getParent()).thenReturn(parent1);
                       when(child2.getParent()).thenReturn(parent2);
                       when(parent1.getParent()).thenReturn(grandParent);
                       when(parent2.getParent()).thenReturn(grandParent);
                       
                       // Make parent comparison return non-zero (let's say 1)
                       // This is the recursive call that would happen in the method
                       when(grandParent.compareChildNodePointers(parent1, parent2)).thenReturn(1);
                       
                       // Make child comparison return different value (-1)
                       when(parent1.compareChildNodePointers(child1, child2)).thenReturn(-1);
                       
                       // Get the private method via reflection
                       Method method = NodePointer.class.getDeclaredMethod(
                           "compareNodePointers", 
                           NodePointer.class, 
                           int.class, 
                           NodePointer.class, 
                           int.class
                       );
                       method.setAccessible(true);
                       
                       // Test with depth=2 (so it will do parent comparison)
                       int result = (int) method.invoke(child1, child1, 2, child2, 2);
                       
                       // Original behavior: should return parent comparison result (1)
                       // Mutant behavior: would proceed to child comparison and return -1
                       assertEquals("Should return parent comparison result when r != 0", 1, result);
                   }

    @Test
              public void testCompareNodePointers_ReturnsNegativeFromRecursiveComparison() throws Exception {
                  // Create mock NodePointer objects
                  NodePointer p1 = mock(NodePointer.class);
                  NodePointer p2 = mock(NodePointer.class);
                  NodePointer p1Parent = mock(NodePointer.class);
                  NodePointer p2Parent = mock(NodePointer.class);
                  
                  // Set up parent relationships
                  when(p1.getParent()).thenReturn(p1Parent);
                  when(p2.getParent()).thenReturn(p2Parent);
                  
                  // Set up the scenario where:
                  // - Depths are equal (depth1 = depth2 = 2)
                  // - Parent comparison returns negative
                  // - compareChildNodePointers would return something else
                  when(p1Parent.compareChildNodePointers(p1, p2)).thenReturn(1); // This would be used if mutant doesn't return negative
                  
                  // The key part: make recursive comparison return negative
                  // This should be returned immediately in original, but mutant would ignore it
                  int expectedNegativeResult = -1;
                  when(p1Parent.compareTo(p2Parent)).thenReturn(expectedNegativeResult);
                  
                  // Use reflection to access private method
                  Method method = NodePointer.class.getDeclaredMethod(
                      "compareNodePointers", 
                      NodePointer.class, int.class, NodePointer.class, int.class);
                  method.setAccessible(true);
                  
                  // Create a concrete instance to invoke the method on
                  NodePointer instance = new NodePointer(null) {
                      @Override
                      public boolean isLeaf() { return false; }
                      @Override
                      public boolean isCollection() { return false; }
                      @Override
                      public int getLength() { return 0; }
                      @Override
                      public QName getName() { return null; }
                      @Override
                      public Object getBaseValue() { return null; }
                      @Override
                      public Object getImmediateNode() { return null; }
                      @Override
                      public void setValue(Object value) {}
                      @Override
                      public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2) { return 0; }
                  };
                  
                  // Call the method via reflection
                  int result = (int) method.invoke(instance, p1, 2, p2, 2);
                  
                  // Verify the original would return the negative value
                  // Mutant would ignore it and return compareChildNodePointers result (1)
                  assertEquals("Should return negative recursive comparison result", 
                              expectedNegativeResult, result);
                  
                  // Verify parent comparison was called
                  verify(p1Parent).compareTo(p2Parent);
              }

    @Test
         public void testCompareNodePointers_ReturnsPositiveComparison() throws Exception {
             // Create mock NodePointer objects
             NodePointer p1 = mock(NodePointer.class);
             NodePointer p2 = mock(NodePointer.class);
             NodePointer parent1 = mock(NodePointer.class);
             NodePointer parent2 = mock(NodePointer.class);
             
             // Set up parent relationships
             when(p1.getParent()).thenReturn(parent1);
             when(p2.getParent()).thenReturn(parent2);
             
             // Mock the recursive comparison to return positive value
             when(parent1.compareChildNodePointers(p1, p2)).thenReturn(1);
             
             // Get the private method via reflection
             Method method = NodePointer.class.getDeclaredMethod(
                 "compareNodePointers", 
                 NodePointer.class, 
                 int.class, 
                 NodePointer.class, 
                 int.class
             );
             method.setAccessible(true);
             
             // Call the method with equal depths > 1
             int result = (int) method.invoke(null, p1, 2, p2, 2);
             
             // Verify the positive comparison result is returned
             assertEquals(1, result);
             
             // Verify parent comparison was called
             verify(parent1).compareChildNodePointers(p1, p2);
         }

    @Test
    public void testCompareNodePointers_DetectMutant1() throws Exception {
        // Create mock nodes with hierarchy
        NodePointer grandParent1 = mock(NodePointer.class);
        NodePointer parent1 = mock(NodePointer.class);
        NodePointer child1 = mock(NodePointer.class);
        
        NodePointer grandParent2 = mock(NodePointer.class);
        NodePointer parent2 = mock(NodePointer.class);
        NodePointer child2 = mock(NodePointer.class);
        
        // Set up parent relationships
        when(child1.getParent()).thenReturn(parent1);
        when(parent1.getParent()).thenReturn(grandParent1);
        
        when(child2.getParent()).thenReturn(parent2);
        when(parent2.getParent()).thenReturn(grandParent2);
        
        // Make children equal (r=0)
        when(child1.equals(child2)).thenReturn(true);
        
        // Make parents different (should be compared)
        when(grandParent1.compareChildNodePointers(parent1, parent2)).thenReturn(1);
        
        // Get private method via reflection
        Method compareNodePointersMethod = NodePointer.class.getDeclaredMethod(
            "compareNodePointers", 
            NodePointer.class, 
            int.class, 
            NodePointer.class, 
            int.class
        );
        compareNodePointersMethod.setAccessible(true);
        
        // Test with depth=2 (need to go up one level)
        int result = (int) compareNodePointersMethod.invoke(
            null, // static method
            child1, 
            2, 
            child2, 
            2
        );
        
        // Original would return 1 (from parent comparison)
        // Mutant would return 0 (from early return)
        assertEquals("Should return parent comparison result", 1, result);
    }


}
