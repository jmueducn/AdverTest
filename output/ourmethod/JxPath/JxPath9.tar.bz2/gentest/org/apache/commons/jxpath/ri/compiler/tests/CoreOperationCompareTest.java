package gentest.org.apache.commons.jxpath.ri.compiler.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.compiler.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.InfoSetUtil;
import org.apache.commons.jxpath.ri.axes.InitialContext;
import org.apache.commons.jxpath.ri.axes.SelfContext;
 
public class CoreOperationCompareTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                     public void testComputeValue_NotEqualExpressions() {
                                                                                         // Setup
                                                                                         Expression arg1 = mock(Expression.class);
                                                                                         Expression arg2 = mock(Expression.class);
                                                                                         EvalContext context = mock(EvalContext.class);
                                                                                         
                                                                                         // Create an anonymous subclass since CoreOperationCompare is abstract
                                                                                         CoreOperationCompare compare = new CoreOperationCompare(arg1, arg2) {
                                                                                             @Override
                                                                                             public Object computeValue(EvalContext context) {
                                                                                                 return Boolean.FALSE;
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                 return false;
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             public String getSymbol() {
                                                                                                 return "!="; // or whatever symbol is appropriate for comparison
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         // Test
                                                                                         Object result = compare.computeValue(context);
                                                                                         
                                                                                         // Verify
                                                                                         assertEquals(Boolean.FALSE, result);
                                                                                     }

 @Test
                                                                                     public void testComputeValue_NotEqualExpressionsWithInvert() {
                                                                                         // Setup
                                                                                         Expression arg1 = mock(Expression.class);
                                                                                         Expression arg2 = mock(Expression.class);
                                                                                         EvalContext context = mock(EvalContext.class);
                                                                                         
                                                                                         // Create instance using protected constructor
                                                                                         CoreOperationCompare compare = new CoreOperationCompare(arg1, arg2, true) {
                                                                                             // Implement abstract methods
                                                                                             @Override
                                                                                             public Object computeValue(EvalContext context) {
                                                                                                 return super.computeValue(context);
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                 return false; // Mock behavior
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             public String getSymbol() {
                                                                                                 return "!="; // Mock symbol for comparison operation
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         // Test
                                                                                         Object result = compare.computeValue(context);
                                                                                         
                                                                                         // Verify
                                                                                         assertEquals(Boolean.TRUE, result);
                                                                                     }

 @Test
                                                                                     public void testComputeValue_EqualWithNullExpressions() {
                                                                                         // Setup
                                                                                         EvalContext context = mock(EvalContext.class);
                                                                                         
                                                                                         // Create a concrete subclass since CoreOperationCompare is abstract
                                                                                         CoreOperationCompare compare = new CoreOperationCompare(null, null) {
                                                                                             @Override
                                                                                             public Object computeValue(EvalContext context) {
                                                                                                 return equal(context, null, null);
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                 return true; // Mock implementation
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             public String getSymbol() {
                                                                                                 return "="; // Mock implementation of abstract method
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         // Test
                                                                                         Object result = compare.computeValue(context);
                                                                                         
                                                                                         // Verify
                                                                                         assertEquals(Boolean.TRUE, result);
                                                                                     }

 @Test
                                                                                     public void testComputeValue_NotEqualWithOneNullExpression() {
                                                                                         // Setup
                                                                                         Expression arg1 = mock(Expression.class);
                                                                                         EvalContext context = mock(EvalContext.class);
                                                                                         
                                                                                         // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                         CoreOperationCompare compare = new CoreOperationCompare(arg1, null) {
                                                                                             @Override
                                                                                             public Object computeValue(EvalContext context) {
                                                                                                 return Boolean.FALSE;
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                                 return false;
                                                                                             }
                                                                                             
                                                                                             @Override
                                                                                             public String getSymbol() {
                                                                                                 return "=="; // or whatever symbol is appropriate for comparison
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         // Test
                                                                                         Object result = compare.computeValue(context);
                                                                                         
                                                                                         // Verify
                                                                                         assertEquals(Boolean.FALSE, result);
                                                                                     }

 @Test
                                                                                     public void testGetPrecedence_ConsistentAcrossMultipleCalls() throws Exception {
                                                                                         // Create mock expressions for the constructor
                                                                                         Expression arg1 = mock(Expression.class);
                                                                                         Expression arg2 = mock(Expression.class);
                                                                                         
                                                                                         // Create instance of CoreOperationCompare using reflection since constructor is protected
                                                                                         Constructor<CoreOperationCompare> constructor = CoreOperationCompare.class
                                                                                             .getDeclaredConstructor(Expression.class, Expression.class, boolean.class);
                                                                                         constructor.setAccessible(true);
                                                                                         CoreOperationCompare operationCompare = constructor.newInstance(arg1, arg2, false);
                                                                                         
                                                                                         // Use reflection to access protected getPrecedence method
                                                                                         Method getPrecedence = CoreOperationCompare.class.getDeclaredMethod("getPrecedence");
                                                                                         getPrecedence.setAccessible(true);
                                                                                         
                                                                                         // Verify the method returns the same value consistently
                                                                                         int precedence = (int) getPrecedence.invoke(operationCompare);
                                                                                         assertEquals(2, precedence);
                                                                                         assertEquals(2, (int) getPrecedence.invoke(operationCompare));
                                                                                         assertEquals(2, (int) getPrecedence.invoke(operationCompare));
                                                                                     }

 @Test
                                                                                     public void testGetPrecedence_IndependentOfConstructorArguments() throws Exception {
                                                                                         // Create concrete subclass to test abstract class's protected method
                                                                                         class TestCoreOperationCompare extends CoreOperationCompare {
                                                                                             public TestCoreOperationCompare(Expression arg1, Expression arg2) {
                                                                                                 super(arg1, arg2);
                                                                                             }
                                                                                             
                                                                                             protected TestCoreOperationCompare(Expression arg1, Expression arg2, boolean invert) {
                                                                                                 super(arg1, arg2, invert);
                                                                                             }
                                                                                             
                                                                                             // Implement abstract method
                                                                                             public String getSymbol() {
                                                                                                 return "=="; // Return appropriate comparison symbol
                                                                                             }
                                                                                             
                                                                                             // Expose protected method for testing
                                                                                             public int getPrecedencePublic() {
                                                                                                 return super.getPrecedence();
                                                                                             }
                                                                                         }
                                                                                         
                                                                                         // Test with different constructor arguments
                                                                                         TestCoreOperationCompare compare1 = new TestCoreOperationCompare(mock(Expression.class), mock(Expression.class));
                                                                                         TestCoreOperationCompare compare2 = new TestCoreOperationCompare(mock(Expression.class), mock(Expression.class), true);
                                                                                         
                                                                                         assertEquals(2, compare1.getPrecedencePublic());
                                                                                         assertEquals(2, compare2.getPrecedencePublic());
                                                                                     }

 @Test
                                                                                     public void testEqual_WithPointerObjects() throws Exception {
                                                                                         // Create mock objects
                                                                                         Pointer pointer1 = mock(Pointer.class);
                                                                                         Pointer pointer2 = mock(Pointer.class);
                                                                                         Object value1 = new Object();
                                                                                         Object value2 = new Object();
                                                                                         
                                                                                         // Set up mock behavior
                                                                                         when(pointer1.getValue()).thenReturn(value1);
                                                                                         when(pointer2.getValue()).thenReturn(value2);
                                                                                         
                                                                                         // Create comparator instance using the protected constructor via reflection
                                                                                         Expression expr1 = mock(Expression.class);
                                                                                         Expression expr2 = mock(Expression.class);
                                                                                         
                                                                                         // Get the protected constructor
                                                                                         Constructor<CoreOperationCompare> constructor = CoreOperationCompare.class
                                                                                                 .getDeclaredConstructor(Expression.class, Expression.class, boolean.class);
                                                                                         constructor.setAccessible(true);
                                                                                         CoreOperationCompare comparator = constructor.newInstance(expr1, expr2, false);
                                                                                         
                                                                                         // Get the protected equal method
                                                                                         Method equalMethod = CoreOperationCompare.class
                                                                                                 .getDeclaredMethod("equal", Object.class, Object.class);
                                                                                         equalMethod.setAccessible(true);
                                                                                         
                                                                                         // Test with same pointer values
                                                                                         assertTrue((Boolean) equalMethod.invoke(comparator, pointer1, pointer1));
                                                                                         
                                                                                         // Test with different pointer values
                                                                                         assertFalse((Boolean) equalMethod.invoke(comparator, pointer1, pointer2));
                                                                                         
                                                                                         // Test with one pointer and one direct value
                                                                                         assertTrue((Boolean) equalMethod.invoke(comparator, pointer1, value1));
                                                                                         assertFalse((Boolean) equalMethod.invoke(comparator, pointer1, value2));
                                                                                     }

 @Test
                                                                                     public void testEqual_WithBooleanValues() throws Exception {
                                                                                         // Create mock expressions since we can't instantiate abstract class directly
                                                                                         Expression mockExpr1 = new Expression() {
                                                                                             public Object computeValue(EvalContext context) { return null; }
                                                                                             public Object compute(EvalContext context) { return null; }
                                                                                             public boolean computeContextDependent() { return false; }
                                                                                         };
                                                                                         Expression mockExpr2 = new Expression() {
                                                                                             public Object computeValue(EvalContext context) { return null; }
                                                                                             public Object compute(EvalContext context) { return null; }
                                                                                             public boolean computeContextDependent() { return false; }
                                                                                         };
                                                                                         
                                                                                         // Create comparator instances using protected constructor via reflection
                                                                                         Constructor<CoreOperationCompare> ctor = CoreOperationCompare.class.getDeclaredConstructor(
                                                                                             Expression.class, Expression.class, boolean.class);
                                                                                         ctor.setAccessible(true);
                                                                                         CoreOperationCompare comparator = ctor.newInstance(mockExpr1, mockExpr2, false);
                                                                                         CoreOperationCompare invertedComparator = ctor.newInstance(mockExpr1, mockExpr2, true);
                                                                                         
                                                                                         // Get the protected equal method via reflection
                                                                                         Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                         equalMethod.setAccessible(true);
                                                                                         
                                                                                         // Boolean with Boolean
                                                                                         assertTrue((Boolean) equalMethod.invoke(comparator, true, true));
                                                                                         assertFalse((Boolean) equalMethod.invoke(comparator, true, false));
                                                                                         
                                                                                         // Boolean with non-Boolean (should convert to boolean)
                                                                                         assertTrue((Boolean) equalMethod.invoke(comparator, true, 1));
                                                                                         assertTrue((Boolean) equalMethod.invoke(comparator, true, "true"));
                                                                                         assertFalse((Boolean) equalMethod.invoke(comparator, false, 1));
                                                                                         assertFalse((Boolean) equalMethod.invoke(comparator, false, "true"));
                                                                                         
                                                                                         // Test with inverted comparator
                                                                                         assertFalse((Boolean) equalMethod.invoke(invertedComparator, true, true));
                                                                                         assertTrue((Boolean) equalMethod.invoke(invertedComparator, true, false));
                                                                                     }

 @Test
                                                                                     public void testEqual_WithStringValues() {
                                                                                         // Create comparator instances
                                                                                         CoreOperationCompare comparator = new CoreOperationCompare(null, null) {
                                                                                             protected boolean equal(Object l, Object r) {
                                                                                                 if (l == r) return true;
                                                                                                 if (l == null || r == null) return false;
                                                                                                 return l.toString().equals(r.toString());
                                                                                             }
                                                                                             
                                                                                             public String getSymbol() {
                                                                                                 return "=";
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         CoreOperationCompare invertedComparator = new CoreOperationCompare(null, null, true) {
                                                                                             protected boolean equal(Object l, Object r) {
                                                                                                 if (l == r) return true;
                                                                                                 if (l == null || r == null) return false;
                                                                                                 return l.toString().equals(r.toString());
                                                                                             }
                                                                                             
                                                                                             public String getSymbol() {
                                                                                                 return "!=";
                                                                                             }
                                                                                         };
                                                                                     
                                                                                         // Test equal() method through reflection since it's protected
                                                                                         try {
                                                                                             Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                             equalMethod.setAccessible(true);
                                                                                             
                                                                                             // Equal strings
                                                                                             assertTrue((Boolean)equalMethod.invoke(comparator, "test", "test"));
                                                                                             assertTrue((Boolean)equalMethod.invoke(comparator, new String("test"), "test")); // different instances
                                                                                             
                                                                                             // Unequal strings
                                                                                             assertFalse((Boolean)equalMethod.invoke(comparator, "test", "TEST"));
                                                                                             assertFalse((Boolean)equalMethod.invoke(comparator, "test", "test2"));
                                                                                             
                                                                                             // String with non-string (should convert to string)
                                                                                             assertTrue((Boolean)equalMethod.invoke(comparator, "5", 5));
                                                                                             assertTrue((Boolean)equalMethod.invoke(comparator, "true", true));
                                                                                             assertFalse((Boolean)equalMethod.invoke(comparator, "5", 6));
                                                                                             
                                                                                             // Test with inverted comparator
                                                                                             assertFalse((Boolean)equalMethod.invoke(invertedComparator, "test", "test"));
                                                                                             assertTrue((Boolean)equalMethod.invoke(invertedComparator, "test", "TEST"));
                                                                                         } catch (Exception e) {
                                                                                             fail("Reflection failed: " + e.getMessage());
                                                                                         }
                                                                                     }

 @Test
                                                                                 public void testComputeValue_EqualExpressions() {
                                                                                     // Setup
                                                                                     Expression arg1 = mock(Expression.class);
                                                                                     Expression arg2 = mock(Expression.class);
                                                                                     EvalContext context = mock(EvalContext.class);
                                                                                     
                                                                                     // Create anonymous subclass since CoreOperationCompare is abstract
                                                                                     CoreOperationCompare compare = new CoreOperationCompare(arg1, arg2) {
                                                                                         @Override
                                                                                         public Object computeValue(EvalContext context) {
                                                                                             return equal(context, arg1, arg2) ? Boolean.TRUE : Boolean.FALSE;
                                                                                         }
                                                                                         
                                                                                         @Override
                                                                                         protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                             return true; // Mocked behavior
                                                                                         }
                                                                                         
                                                                                         @Override
                                                                                         public String getSymbol() {  // Changed from protected to public
                                                                                             return "=="; // Mocked symbol for comparison operation
                                                                                         }
                                                                                     };
                                                                                     
                                                                                     // Test
                                                                                     Object result = compare.computeValue(context);
                                                                                     
                                                                                     // Verify
                                                                                     assertEquals(Boolean.TRUE, result);
                                                                                 }

 @Test
                                                                                 public void testComputeValue_EqualExpressionsWithInvert() {
                                                                                     // Setup
                                                                                     Expression arg1 = mock(Expression.class);
                                                                                     Expression arg2 = mock(Expression.class);
                                                                                     EvalContext context = mock(EvalContext.class);
                                                                                     
                                                                                     // Use the protected constructor with invert flag
                                                                                     CoreOperationCompare compare = new CoreOperationCompare(arg1, arg2, true) {
                                                                                         // Implement abstract methods if any
                                                                                         @Override
                                                                                         protected int getPrecedence() {
                                                                                             return 0;
                                                                                         }
                                                                                         
                                                                                         @Override
                                                                                         protected boolean isSymmetric() {
                                                                                             return false;
                                                                                         }
                                                                                         
                                                                                         @Override
                                                                                         public String getSymbol() {  // Changed from protected to public
                                                                                             return "==";
                                                                                         }
                                                                                         
                                                                                         // Override equal method to make it mockable
                                                                                         @Override
                                                                                         protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                                             return true;
                                                                                         }
                                                                                     };
                                                                                     
                                                                                     // Test
                                                                                     Object result = compare.computeValue(context);
                                                                                     
                                                                                     // Verify
                                                                                     assertEquals(Boolean.FALSE, result);
                                                                                 }

 @Test
                                                                                 public void testEqual_WithNullValues() throws Exception {
                                                                                     // Create test expressions (dummy implementations with all required methods)
                                                                                     Expression arg1 = new Expression() {
                                                                                         public Object computeValue(EvalContext context) { return null; }
                                                                                         public Object compute(EvalContext context) { return null; }
                                                                                         public boolean computeContextDependent() { return false; }
                                                                                     };
                                                                                     Expression arg2 = new Expression() {
                                                                                         public Object computeValue(EvalContext context) { return null; }
                                                                                         public Object compute(EvalContext context) { return null; }
                                                                                         public boolean computeContextDependent() { return false; }
                                                                                     };
                                                                                     
                                                                                     // Create comparators using reflection to access protected constructor
                                                                                     Constructor<CoreOperationCompare> constructor = 
                                                                                         CoreOperationCompare.class.getDeclaredConstructor(Expression.class, Expression.class, boolean.class);
                                                                                     constructor.setAccessible(true);
                                                                                     CoreOperationCompare comparator = constructor.newInstance(arg1, arg2, false);
                                                                                     CoreOperationCompare invertedComparator = constructor.newInstance(arg1, arg2, true);
                                                                                     
                                                                                     // Get the equal method using reflection since it's protected
                                                                                     Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", Object.class, Object.class);
                                                                                     equalMethod.setAccessible(true);
                                                                                     
                                                                                     // Both null
                                                                                     assertTrue((Boolean)equalMethod.invoke(comparator, null, null));
                                                                                     
                                                                                     // One null
                                                                                     assertFalse((Boolean)equalMethod.invoke(comparator, null, "test"));
                                                                                     assertFalse((Boolean)equalMethod.invoke(comparator, 5, null));
                                                                                     
                                                                                     // Test with inverted comparator
                                                                                     assertFalse((Boolean)equalMethod.invoke(invertedComparator, null, null));
                                                                                     assertTrue((Boolean)equalMethod.invoke(invertedComparator, null, "test"));
                                                                                 }

 @Test
                                                                                 public void testEqual_WithCustomObjects() throws Exception {
                                                                                     // Create mock expressions with all required methods
                                                                                     Expression mockExpr1 = new Expression() {
                                                                                         public Object computeValue(EvalContext context) { return null; }
                                                                                         public Object compute(EvalContext context) { return null; }
                                                                                         public Object compute(EvalContext context, boolean b) { return null; }
                                                                                         public boolean computeContextDependent() { return false; }
                                                                                     };
                                                                                     Expression mockExpr2 = new Expression() {
                                                                                         public Object computeValue(EvalContext context) { return null; }
                                                                                         public Object compute(EvalContext context) { return null; }
                                                                                         public Object compute(EvalContext context, boolean b) { return null; }
                                                                                         public boolean computeContextDependent() { return false; }
                                                                                     };
                                                                                     
                                                                                     // Create concrete subclass of CoreOperationCompare to test protected methods
                                                                                     class TestComparator extends CoreOperationCompare {
                                                                                         public TestComparator(Expression arg1, Expression arg2) {
                                                                                             super(arg1, arg2);
                                                                                         }
                                                                                         
                                                                                         public TestComparator(Expression arg1, Expression arg2, boolean invert) {
                                                                                             super(arg1, arg2, invert);
                                                                                         }
                                                                                         
                                                                                         // Implement abstract method
                                                                                         public String getSymbol() {
                                                                                             return "=";
                                                                                         }
                                                                                         
                                                                                         // Expose protected method for testing
                                                                                         public boolean testEqual(Object l, Object r) {
                                                                                             return equal(l, r);
                                                                                         }
                                                                                     }
                                                                                     
                                                                                     TestComparator comparator = new TestComparator(mockExpr1, mockExpr2);
                                                                                     TestComparator invertedComparator = new TestComparator(mockExpr1, mockExpr2, true);
                                                                                     
                                                                                     Object obj1 = new Object();
                                                                                     Object obj2 = new Object();
                                                                                     
                                                                                     // Same object
                                                                                     assertTrue(comparator.testEqual(obj1, obj1));
                                                                                     
                                                                                     // Different objects
                                                                                     assertFalse(comparator.testEqual(obj1, obj2));
                                                                                     
                                                                                     // Equal objects (by equals() method)
                                                                                     String s1 = new String("test");
                                                                                     String s2 = new String("test");
                                                                                     assertTrue(comparator.testEqual(s1, s2));
                                                                                     
                                                                                     // Test with inverted comparator
                                                                                     assertFalse(invertedComparator.testEqual(obj1, obj1));
                                                                                     assertTrue(invertedComparator.testEqual(obj1, obj2));
                                                                                 }

 @Test
                                                                             public void testEqual_WithNumberValues() throws Exception {
                                                                                 // Create test expressions with all required methods implemented
                                                                                 Expression arg1 = new Expression() {
                                                                                     public Object computeValue(EvalContext context) { return null; }
                                                                                     public Object getValue(EvalContext context) { return null; }
                                                                                     public Object compute(EvalContext context) { return null; }
                                                                                     public boolean computeContextDependent() { return false; }
                                                                                 };
                                                                                 Expression arg2 = new Expression() {
                                                                                     public Object computeValue(EvalContext context) { return null; }
                                                                                     public Object getValue(EvalContext context) { return null; }
                                                                                     public Object compute(EvalContext context) { return null; }
                                                                                     public boolean computeContextDependent() { return false; }
                                                                                 };
                                                                                 
                                                                                 // Create concrete subclass to test protected methods
                                                                                 class TestComparator extends CoreOperationCompare {
                                                                                     public TestComparator(Expression arg1, Expression arg2) {
                                                                                         super(arg1, arg2);
                                                                                     }
                                                                                     public TestComparator(Expression arg1, Expression arg2, boolean invert) {
                                                                                         super(arg1, arg2, invert);
                                                                                     }
                                                                                     public boolean testEqual(Object l, Object r) {
                                                                                         return equal(l, r);
                                                                                     }
                                                                                     public String getSymbol() {
                                                                                         return "=";
                                                                                     }
                                                                                 }
                                                                                 
                                                                                 // Create comparators
                                                                                 TestComparator comparator = new TestComparator(arg1, arg2);
                                                                                 TestComparator invertedComparator = new TestComparator(arg1, arg2, true);
                                                                                 
                                                                                 // Equal numbers
                                                                                 assertTrue(comparator.testEqual(5, 5));
                                                                                 assertTrue(comparator.testEqual(5, 5.0));
                                                                                 assertTrue(comparator.testEqual(5.0f, 5.0));
                                                                                 
                                                                                 // Unequal numbers
                                                                                 assertFalse(comparator.testEqual(5, 6));
                                                                                 assertFalse(comparator.testEqual(5.0, 5.1));
                                                                                 
                                                                                 // NaN cases
                                                                                 assertFalse(comparator.testEqual(Double.NaN, Double.NaN));
                                                                                 assertFalse(comparator.testEqual(Double.NaN, 5));
                                                                                 assertFalse(comparator.testEqual(5, Double.NaN));
                                                                                 
                                                                                 // Test with inverted comparator
                                                                                 assertFalse(invertedComparator.testEqual(5, 5));
                                                                                 assertTrue(invertedComparator.testEqual(5, 6));
                                                                             }

 @Test
                                                                         public void testComputeValue_NullContext() {
                                                                             // Setup
                                                                             Expression arg1 = mock(Expression.class);
                                                                             Expression arg2 = mock(Expression.class);
                                                                             
                                                                             // Create a concrete subclass since CoreOperationCompare is abstract
                                                                             CoreOperationCompare compare = new CoreOperationCompare(arg1, arg2) {
                                                                                 @Override
                                                                                 public Object computeValue(EvalContext context) {
                                                                                     return null; // Implementation not needed for this test
                                                                                 }
                                                                                 
                                                                                 @Override
                                                                                 protected int getPrecedence() {
                                                                                     return 0; // Implementation not needed for this test
                                                                                 }
                                                                                 
                                                                                 @Override
                                                                                 protected boolean isSymmetric() {
                                                                                     return false; // Implementation not needed for this test
                                                                                 }
                                                                                 
                                                                                 @Override
                                                                                 public String getSymbol() {
                                                                                     return null; // Implementation not needed for this test
                                                                                 }
                                                                             };
                                                                             
                                                                             // Expect exception
                                                                             ExpectedException expectedException = ExpectedException.none();
                                                                             expectedException.expect(NullPointerException.class);
                                                                             
                                                                             // Test
                                                                             compare.computeValue(null);
                                                                         }

 @Test
                                                                 public void testEqual_MixedNullValues() throws Exception {
                                                                     // Setup
                                                                     org.apache.commons.jxpath.ri.compiler.Expression left = 
                                                                         mock(org.apache.commons.jxpath.ri.compiler.Expression.class);
                                                                     org.apache.commons.jxpath.ri.compiler.Expression right = 
                                                                         mock(org.apache.commons.jxpath.ri.compiler.Expression.class);
                                                                     EvalContext context = mock(EvalContext.class);
                                                                     
                                                                     // Create anonymous subclass since CoreOperationCompare is abstract
                                                                     CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                                         @Override
                                                                         public Object computeValue(EvalContext context) {
                                                                             return null; // Default implementation for abstract method
                                                                         }
                                                                         
                                                                         @Override
                                                                         public String getSymbol() {
                                                                             return "=="; // Implementation for abstract method from CoreOperation
                                                                         }
                                                                     };
                                                                     
                                                                     Object leftValue = null;
                                                                     Object rightValue = "value";
                                                                     when(left.compute(context)).thenReturn(leftValue);
                                                                     when(right.compute(context)).thenReturn(rightValue);
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                                         "equal", Object.class, Object.class);
                                                                     equalMethod.setAccessible(true);
                                                                     boolean result = (boolean) equalMethod.invoke(comparator, leftValue, rightValue);
                                                                     
                                                                     // Test & Verify
                                                                     assertFalse(result);
                                                                 }

 @Test
                                                     public void testEqual_InitialContextHandling() {
                                                         // Setup
                                                         Expression left = mock(Expression.class);
                                                         Expression right = mock(Expression.class);
                                                         EvalContext context = mock(EvalContext.class);
                                                         InitialContext initialContext = mock(InitialContext.class);
                                                         
                                                         // Create a concrete subclass since CoreOperationCompare is abstract
                                                         CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                             @Override
                                                             public Object computeValue(EvalContext context) {
                                                                 return Boolean.FALSE;
                                                             }
                                                             
                                                             @Override
                                                             protected int getPrecedence() {
                                                                 return 0;
                                                             }
                                                             
                                                             @Override
                                                             protected boolean isSymmetric() {
                                                                 return false;
                                                             }
                                                             
                                                             @Override
                                                             public String getSymbol() {
                                                                 return "==";
                                                             }
                                                             
                                                             @Override
                                                             protected boolean equal(EvalContext context, Expression left, Expression right) {
                                                                 // Compare the values directly since we're testing the initial context handling
                                                                 Object leftValue = left.compute(context);
                                                                 Object rightValue = right.compute(context);
                                                                 return leftValue != null && leftValue.equals(rightValue);
                                                             }
                                                         };
                                                         
                                                         when(left.compute(context)).thenReturn(initialContext);
                                                         when(right.compute(context)).thenReturn("value");
                                                         
                                                         // Test & Verify
                                                         verify(initialContext).reset();
                                                     }

 @Test
                                                     public void testEqual_NullValues() {
                                                         // Setup
                                                         Expression left = mock(Expression.class);
                                                         Expression right = mock(Expression.class);
                                                         EvalContext context = mock(EvalContext.class);
                                                         
                                                         // Create anonymous subclass since CoreOperationCompare is abstract
                                                         CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                             @Override
                                                             public Object computeValue(EvalContext context) {
                                                                 return null;
                                                             }
                                                             
                                                             @Override
                                                             public String getSymbol() {
                                                                 return "=";
                                                             }
                                                             
                                                             @Override
                                                             protected int getPrecedence() {
                                                                 return 0;
                                                             }
                                                             
                                                             @Override
                                                             protected boolean isSymmetric() {
                                                                 return false;
                                                             }
                                                             
                                                             @Override
                                                             protected boolean equal(EvalContext context, Expression l, Expression r) {
                                                                 // Directly implement the null comparison logic we want to test
                                                                 Object leftValue = l.compute(context);
                                                                 Object rightValue = r.compute(context);
                                                                 return leftValue == null && rightValue == null;
                                                             }
                                                         };
                                                         
                                                         when(left.compute(context)).thenReturn(null);
                                                         when(right.compute(context)).thenReturn(null);
                                                         
                                                         // Test & Verify
                                                     }

 @Test
                                             public void testGetPrecedence_ReturnsCorrectValue() throws Exception {
                                                 // Create test expressions (using mock or simple expressions)
                                                 org.apache.commons.jxpath.ri.compiler.Expression arg1 = 
                                                     new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual(
                                                         new org.apache.commons.jxpath.ri.compiler.Constant("true"), 
                                                         new org.apache.commons.jxpath.ri.compiler.Constant("true"));
                                                 org.apache.commons.jxpath.ri.compiler.Expression arg2 = 
                                                     new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual(
                                                         new org.apache.commons.jxpath.ri.compiler.Constant("true"), 
                                                         new org.apache.commons.jxpath.ri.compiler.Constant("true"));
                                                 
                                                 // Create concrete subclass since CoreOperationCompare is abstract
                                                 class TestOperationCompare extends org.apache.commons.jxpath.ri.compiler.CoreOperationCompare {
                                                     public TestOperationCompare(org.apache.commons.jxpath.ri.compiler.Expression arg1, 
                                                                               org.apache.commons.jxpath.ri.compiler.Expression arg2) {
                                                         super(arg1, arg2);
                                                     }
                                                     
                                                     public TestOperationCompare(org.apache.commons.jxpath.ri.compiler.Expression arg1, 
                                                                               org.apache.commons.jxpath.ri.compiler.Expression arg2, 
                                                                               boolean invert) {
                                                         super(arg1, arg2, invert);
                                                     }
                                                     
                                                     public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) {
                                                         return null; // Not needed for this test
                                                     }
                                                     
                                                     public String getSymbol() {
                                                         return "test"; // Implement abstract method
                                                     }
                                                 }
                                                 
                                                 // Create normal (non-inverted) operation
                                                 TestOperationCompare operationCompare = new TestOperationCompare(arg1, arg2);
                                                 
                                                 // Use reflection to access protected getPrecedence() method
                                                 java.lang.reflect.Method getPrecedenceMethod = 
                                                     org.apache.commons.jxpath.ri.compiler.CoreOperationCompare.class
                                                         .getDeclaredMethod("getPrecedence");
                                                 getPrecedenceMethod.setAccessible(true);
                                                 
                                                 // Test with normal (non-inverted) operation
                                                 assertEquals("Precedence should be 2 for normal comparison", 
                                                     2, ((Integer)getPrecedenceMethod.invoke(operationCompare)).intValue());
                                                 
                                                 // Create inverted operation
                                                 TestOperationCompare invertedOperationCompare = new TestOperationCompare(arg1, arg2, true);
                                                 
                                                 // Test with inverted operation
                                                 assertEquals("Precedence should be 2 even for inverted comparison", 
                                                     2, ((Integer)getPrecedenceMethod.invoke(invertedOperationCompare)).intValue());
                                             }

 @Test
                                             public void testEqual_BothIterators() {
                                                 // Setup
                                                 Expression left = mock(Expression.class);
                                                 Expression right = mock(Expression.class);
                                                 EvalContext context = mock(EvalContext.class);
                                                 
                                                 // Create mock iterators
                                                 Iterator leftIterator = mock(Iterator.class);
                                                 Iterator rightIterator = mock(Iterator.class);
                                                 
                                                 // Create a concrete subclass since CoreOperationCompare is abstract
                                                 CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                                                     @Override
                                                     public Object computeValue(EvalContext context) {
                                                         return null;
                                                     }
                                                     
                                                     @Override
                                                     protected int getPrecedence() {
                                                         return 0;
                                                     }
                                                     
                                                     @Override
                                                     protected boolean isSymmetric() {
                                                         return false;
                                                     }
                                                     
                                                     @Override
                                                     public String getSymbol() {
                                                         return "=";
                                                     }
                                                 };
                                                 
                                                 // Use reflection to access protected method
                                                 try {
                                                     Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                         "equal", EvalContext.class, Expression.class, Expression.class);
                                                     equalMethod.setAccessible(true);
                                                     
                                                     Method findMatchMethod = CoreOperationCompare.class.getDeclaredMethod(
                                                         "findMatch", Iterator.class, Iterator.class);
                                                     findMatchMethod.setAccessible(true);
                                                     
                                                     // Mock the behavior
                                                     when(left.compute(context)).thenReturn(leftIterator);
                                                     when(right.compute(context)).thenReturn(rightIterator);
                                                     
                                                     // Stub the findMatch method to return true
                                                     when(findMatchMethod.invoke(comparator, any(Iterator.class), any(Iterator.class))).thenReturn(Boolean.TRUE);
                                                     
                                                     // Test & Verify
                                                     boolean result = (Boolean) equalMethod.invoke(comparator, context, left, right);
                                                     assertTrue(result);
                                                 } catch (Exception e) {
                                                     fail("Test failed due to reflection error: " + e.getMessage());
                                                 }
                                             }

 @Test
                                 public void testEqual_BothObjectsEqual() {
                                     // Setup
                                     org.apache.commons.jxpath.ri.compiler.Expression left = 
                                         new org.apache.commons.jxpath.ri.compiler.Expression() {
                                             public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) {
                                                 return null;
                                             }
                                             public Object compute(org.apache.commons.jxpath.ri.EvalContext context) {
                                                 return null;
                                             }
                                             public boolean computeContextDependent() {
                                                 return false;
                                             }
                                         };
                                     org.apache.commons.jxpath.ri.compiler.Expression right = 
                                         new org.apache.commons.jxpath.ri.compiler.Expression() {
                                             public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) {
                                                 return null;
                                             }
                                             public Object compute(org.apache.commons.jxpath.ri.EvalContext context) {
                                                 return null;
                                             }
                                             public boolean computeContextDependent() {
                                                 return false;
                                             }
                                         };
                                     // Create anonymous subclass since CoreOperationCompare is abstract
                                     org.apache.commons.jxpath.ri.compiler.CoreOperationCompare comparator = 
                                         new org.apache.commons.jxpath.ri.compiler.CoreOperationCompare(left, right) {
                                             public Object computeValue(org.apache.commons.jxpath.ri.EvalContext context) {
                                                 return null; // dummy implementation
                                             }
                                             public String getSymbol() {
                                                 return "="; // dummy implementation
                                             }
                                         };
                                     
                                     Object leftValue = "test";
                                     Object rightValue = "test";
                                     org.apache.commons.jxpath.ri.EvalContext context = null; // dummy context
                                     
                                     // Test & Verify
                                     try {
                                         java.lang.reflect.Method equalMethod = org.apache.commons.jxpath.ri.compiler.CoreOperationCompare.class
                                             .getDeclaredMethod("equal", 
                                                 org.apache.commons.jxpath.ri.EvalContext.class,
                                                 Object.class, 
                                                 Object.class);
                                         equalMethod.setAccessible(true);
                                         boolean result = (boolean) equalMethod.invoke(comparator, context, leftValue, rightValue);
                                         org.junit.Assert.assertTrue(result);
                                     } catch (Exception e) {
                                         org.junit.Assert.fail("Failed to invoke equal method: " + e.getMessage());
                                     }
                                 }

 @Test
                     public void testEqual_SelfContextHandling() {
                         // Setup
                         org.apache.commons.jxpath.ri.compiler.Expression left = mock(org.apache.commons.jxpath.ri.compiler.Expression.class);
                         org.apache.commons.jxpath.ri.compiler.Expression right = mock(org.apache.commons.jxpath.ri.compiler.Expression.class);
                         org.apache.commons.jxpath.ri.EvalContext context = mock(org.apache.commons.jxpath.ri.EvalContext.class);
                         org.apache.commons.jxpath.ri.axes.SelfContext selfContext = mock(org.apache.commons.jxpath.ri.axes.SelfContext.class);
                         org.apache.commons.jxpath.ri.model.NodePointer nodePointer = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                         
                         // Create anonymous subclass since CoreOperationCompare is abstract
                         org.apache.commons.jxpath.ri.compiler.CoreOperationCompare comparator = 
                             new org.apache.commons.jxpath.ri.compiler.CoreOperationCompare(left, right) {
                                 @Override
                                 public Object computeValue(EvalContext context) {
                                     return null;
                                 }
                                 
                                 @Override
                                 protected boolean equal(EvalContext context, 
                                     org.apache.commons.jxpath.ri.compiler.Expression left, 
                                     org.apache.commons.jxpath.ri.compiler.Expression right) {
                                     return super.equal(context, left, right);
                                 }
                                 
                                 @Override
                                 protected int getPrecedence() {
                                     return 0;
                                 }
                                 
                                 @Override
                                 protected boolean isSymmetric() {
                                     return false;
                                 }
                                 
                                 @Override
                                 public String getSymbol() {
                                     return "=";
                                 }
                             };
                         
                         when(left.compute(context)).thenReturn(selfContext);
                         when(right.compute(context)).thenReturn("value");
                         when(selfContext.getSingleNodePointer()).thenReturn(nodePointer);
                         
                         // Test & Verify
                         Object leftResult = left.compute(context);
                         Object rightResult = right.compute(context);
                         // Call the equal method through reflection since it's protected
                         try {
                             Method equalMethod = org.apache.commons.jxpath.ri.compiler.CoreOperationCompare.class
                                 .getDeclaredMethod("equal", EvalContext.class, Expression.class, Expression.class);
                             equalMethod.setAccessible(true);
                             boolean result = (boolean) equalMethod.invoke(comparator, context, left, right);
                             assertFalse(result);
                         } catch (Exception e) {
                             fail("Failed to invoke equal method: " + e.getMessage());
                         }
                     }

 @Test
                 public void testEqual_RightIteratorLeftValue() {
                     // Setup
                     Expression left = mock(Expression.class);
                     Expression right = mock(Expression.class);
                     EvalContext context = mock(EvalContext.class);
                     
                     // Create a concrete subclass since CoreOperationCompare is abstract
                     CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                         @Override
                         public Object computeValue(EvalContext context) {
                             return null;
                         }
                         
                         @Override
                         protected int getPrecedence() {
                             return 0;
                         }
                         
                         @Override
                         protected boolean isSymmetric() {
                             return false;
                         }
                     
                         @Override
                         public String getSymbol() {
                             return "==";
                         }
                     
                         @Override
                         protected boolean equal(EvalContext context, Expression left, Expression right) {
                             return false;
                         }
                     
                         @Override
                         protected boolean contains(Iterator it, Object value) {
                             // Default implementation that will be overridden via reflection
                             return false;
                         }
                     };
                     
                     // Create test iterator
                     Iterator<?> iterator = mock(Iterator.class);
                     
                     try {
                         // Get the equal method
                         Method equalMethod = CoreOperationCompare.class.getDeclaredMethod(
                             "equal", EvalContext.class, Expression.class, Expression.class);
                         equalMethod.setAccessible(true);
                         
                         // Get the contains method
                         Method containsMethod = CoreOperationCompare.class.getDeclaredMethod(
                             "contains", Iterator.class, Object.class);
                         containsMethod.setAccessible(true);
                         
                         when(left.compute(context)).thenReturn("y");
                         when(right.compute(context)).thenReturn(iterator);
                         
                         // Create a spy of the comparator
                         CoreOperationCompare spyComparator = spy(comparator);
                         
                         // Use reflection to set up the contains method behavior
                         // Instead of Mockito's doReturn, we'll use reflection to test the actual behavior
                         when(left.compute(context)).thenReturn("y");
                         when(right.compute(context)).thenReturn(iterator);
                         
                         // Test & Verify
                         boolean result = (boolean) equalMethod.invoke(spyComparator, context, left, right);
                         assertTrue(result);
                     } catch (Exception e) {
                         fail("Test failed due to reflection error: " + e.getMessage());
                     }
                 }

 @Test
             public void testEqual_CollectionHandling() {
                 // Setup
                 Expression left = mock(Expression.class);
                 Expression right = mock(Expression.class);
                 EvalContext context = mock(EvalContext.class);
                 
                 // Create test collection
                 Collection<String> collection = new ArrayList<>();
                 collection.add("a");
                 collection.add("b");
                 collection.add("c");
                 
                 // Create a concrete subclass since CoreOperationCompare is abstract
                 CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                     @Override
                     public Object computeValue(EvalContext context) {
                         return null;
                     }
                     
                     @Override
                     protected int getPrecedence() {
                         return 0;
                     }
                     
                     @Override
                     protected boolean isSymmetric() {
                         return false;
                     }
                     
                     @Override
                     public String getSymbol() {
                         return "==";
                     }
                     
                     @Override
                     protected boolean equal(EvalContext context, Expression left, Expression right) {
                         Object leftValue = left.compute(context);
                         Object rightValue = right.compute(context);
                         return contains(((Collection<?>) leftValue).iterator(), rightValue);
                     }
                     
         {
         {
         {
                             }
                         }
                     }
                     
                     @Override
                     protected boolean equal(Object l, Object r) {
                         return l == null ? r == null : l.equals(r);
                     }
                 };
                 
                 when(left.compute(context)).thenReturn(collection);
                 when(right.compute(context)).thenReturn("b");
                 
                 // Test & Verify
             }

 @Test
             public void testEqual_LeftIteratorRightValue() {
                 // Setup
                 Expression left = mock(Expression.class);
                 Expression right = mock(Expression.class);
                 EvalContext context = mock(EvalContext.class);
                 
                 // Create iterator for testing
                 
                 // Create a concrete subclass since CoreOperationCompare is abstract
                 CoreOperationCompare comparator = new CoreOperationCompare(left, right) {
                     @Override
                     public Object computeValue(EvalContext context) {
                         return null;
                     }
                     
                     @Override
                     protected int getPrecedence() {
                         return 0;
                     }
                     
                     @Override
                     protected boolean isSymmetric() {
                         return false;
                     }
                     
                     @Override
                     public String getSymbol() {
                         return "=";
                     }
                 };
                 
                 // Spy on the concrete instance
                 CoreOperationCompare spyComparator = spy(comparator);
                 
                 when(right.compute(context)).thenReturn("b");
                 
                 // Use reflection to access protected contains method
                 try {
                     Method containsMethod = CoreOperationCompare.class.getDeclaredMethod("contains", Iterator.class, Object.class);
                     containsMethod.setAccessible(true);
                     when((Boolean)containsMethod.invoke(spyComparator, any(Iterator.class), any(Object.class))).thenReturn(true);
                 } catch (Exception e) {
                     fail("Failed to set up mock for protected contains method");
                 }
                 
                 // Test & Verify
                 try {
                     Method equalMethod = CoreOperationCompare.class.getDeclaredMethod("equal", EvalContext.class, Expression.class, Expression.class);
                     equalMethod.setAccessible(true);
                     boolean result = (Boolean) equalMethod.invoke(spyComparator, context, left, right);
                     assertTrue(result);
                 } catch (Exception e) {
                     fail("Failed to invoke protected equal method");
                 }
             }

}
