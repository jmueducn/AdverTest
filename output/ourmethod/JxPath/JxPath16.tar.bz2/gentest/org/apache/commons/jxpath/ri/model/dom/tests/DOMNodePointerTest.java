package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testTestNode_Instance_WithDifferentNodeStates() {
                                                                                                                                                                            // Test with different node states
                                                                                                                                                                            Node validNode = mock(Node.class);
                                                                                                                                                                            Node invalidNode = mock(Node.class);
                                                                                                                                                                            NodeTest test = mock(NodeTest.class);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer validPointer = new DOMNodePointer(validNode, null);
                                                                                                                                                                            DOMNodePointer invalidPointer = new DOMNodePointer(invalidNode, null);
                                                                                                                                                                            
                                                                                                                                                                            when(DOMNodePointer.testNode(validNode, test)).thenReturn(true);
                                                                                                                                                                            when(DOMNodePointer.testNode(invalidNode, test)).thenReturn(false);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(validPointer.testNode(test));
                                                                                                                                                                            assertFalse(invalidPointer.testNode(test));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NullTest() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(null));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeNameTest_NonElementNode() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                            when(mockTest.getNodeName()).thenReturn(mock(QName.class));
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeNameTest_WildcardNullPrefix() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                            when(mockTest.isWildcard()).thenReturn(true);
                                                                                                                                                                            when(mockTest.getNodeName()).thenReturn(mock(QName.class));
                                                                                                                                                                            when(mockTest.getNodeName().getPrefix()).thenReturn(null);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeNameTest_MatchingLocalNameAndNamespace() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                            QName mockQName = mock(QName.class);
                                                                                                                                                                            when(mockTest.getNodeName()).thenReturn(mockQName);
                                                                                                                                                                            when(mockTest.isWildcard()).thenReturn(false);
                                                                                                                                                                            when(mockQName.getName()).thenReturn("test");
                                                                                                                                                                            when(mockTest.getNamespaceURI()).thenReturn("http://example.com");
                                                                                                                                                                            
                                                                                                                                                                            // Mock static method behavior
                                                                                                                                                                            when(DOMNodePointer.getLocalName(mockNode)).thenReturn("test");
                                                                                                                                                                            when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("http://example.com");
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeTypeTest_NodeTypeNode() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                            when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeTypeTest_NodeTypeText_TextNode() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                            when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_TEXT);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeTypeTest_NodeTypeComment_NonCommentNode() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                            when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_COMMENT);
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_ProcessingInstructionTest_MatchingTarget() {
                                                                                                                                                                            ProcessingInstruction mockNode = mock(ProcessingInstruction.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                            when(mockNode.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                            
                                                                                                                                                                            ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                            when(mockTest.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_ProcessingInstructionTest_NonMatchingTarget() {
                                                                                                                                                                            ProcessingInstruction mockNode = mock(ProcessingInstruction.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                            when(mockNode.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                            
                                                                                                                                                                            ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                            when(mockTest.getTarget()).thenReturn("other-target");
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_UnknownTestType() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            NodeTest mockTest = mock(NodeTest.class); // Not one of the known types
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testNode_NodeNameTest_WildcardPrefixMatching() {
                                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                                            when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                            
                                                                                                                                                                            NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                            QName mockQName = mock(QName.class);
                                                                                                                                                                            when(mockTest.getNodeName()).thenReturn(mockQName);
                                                                                                                                                                            when(mockTest.isWildcard()).thenReturn(true);
                                                                                                                                                                            when(mockQName.getPrefix()).thenReturn("test");
                                                                                                                                                                            when(mockTest.getNamespaceURI()).thenReturn(null);
                                                                                                                                                                            
                                                                                                                                                                            // Mock static method behavior
                                                                                                                                                                            when(DOMNodePointer.getLocalName(mockNode)).thenReturn("element");
                                                                                                                                                                            when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn(null);
                                                                                                                                                                            when(DOMNodePointer.getPrefix(mockNode)).thenReturn("test");
                                                                                                                                                                            
                                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testTestNode_Static_NullTestThrowsNullPointerException() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    Node testNode = mock(Node.class);
                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                    
                                                                                                                                                                    // Expect exception
                                                                                                                                                                    exception.expect(NullPointerException.class);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    DOMNodePointer.testNode(testNode, null);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindEnclosingAttribute_NullNodeInput() throws Exception {
                                                                                                                                                                    Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    String result = (String) method.invoke(null, null, "testAttr");
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                                                                            public void testTestNode_Instance_NullTestThrowsNullPointerException() {
                                                                                                                                                                // Setup
                                                                                                                                                                Node testNode = mock(Node.class);
                                                                                                                                                                DOMNodePointer pointer = new DOMNodePointer(testNode, null);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                pointer.testNode(null);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFindEnclosingAttribute_CurrentNodeHasAttribute() throws Exception {
                                                                                                                                                                // Create mock Node and NamedNodeMap
                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                                                                                                Attr mockAttr = mock(Attr.class);
                                                                                                                                                                
                                                                                                                                                                // Setup mock behavior
                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(mockNode.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                                when(mockAttributes.getNamedItem("testAttr")).thenReturn(mockAttr);
                                                                                                                                                                when(mockAttr.getNodeValue()).thenReturn("value1");
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                    "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Call the method and verify
                                                                                                                                                                String result = (String) method.invoke(null, mockNode, "testAttr");
                                                                                                                                                                assertEquals("value1", result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFindEnclosingAttribute_ParentNodeHasAttribute() throws Exception {
                                                                                                                                                                // Create mock nodes
                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                Node mockParentNode = mock(Node.class);
                                                                                                                                                                
                                                                                                                                                                // Set up mock behavior
                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                                
                                                                                                                                                                when(mockParentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockParentNode).getAttribute("testAttr")).thenReturn("value2");
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access the protected method
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                    "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Call the method under test
                                                                                                                                                                String result = (String) method.invoke(null, mockNode, "testAttr");
                                                                                                                                                                
                                                                                                                                                                // Verify the result
                                                                                                                                                                assertEquals("value2", result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFindEnclosingAttribute_GrandparentNodeHasAttribute() throws Exception {
                                                                                                                                                                // Create mock objects
                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                Node mockParentNode = mock(Node.class);
                                                                                                                                                                Node mockGrandparentNode = mock(Node.class);
                                                                                                                                                                
                                                                                                                                                                // Setup node hierarchy
                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                                
                                                                                                                                                                when(mockParentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(mockParentNode.getParentNode()).thenReturn(mockGrandparentNode);
                                                                                                                                                                when(((Element)mockParentNode).getAttribute("testAttr")).thenReturn("");
                                                                                                                                                                
                                                                                                                                                                when(mockGrandparentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockGrandparentNode).getAttribute("testAttr")).thenReturn("value3");
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                String result = (String) method.invoke(null, mockNode, "testAttr");
                                                                                                                                                                
                                                                                                                                                                assertEquals("value3", result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFindEnclosingAttribute_NoElementNodes() throws Exception {
                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                Node mockParentNode = mock(Node.class);
                                                                                                                                                                
                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                                
                                                                                                                                                                when(mockParentNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                when(mockParentNode.getParentNode()).thenReturn(null);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access the protected method
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                    "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                String result = (String) method.invoke(null, mockNode, "testAttr");
                                                                                                                                                                
                                                                                                                                                                assertNull(result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFindEnclosingAttribute_ElementNodesButNoMatchingAttribute() throws Exception {
                                                                                                                                                                // Create mock nodes
                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                Element mockElementNode = mock(Element.class);
                                                                                                                                                                Node mockParentNode = mock(Node.class);
                                                                                                                                                                Element mockParentElement = mock(Element.class);
                                                                                                                                                                
                                                                                                                                                                // Setup mock behavior
                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockNode).getAttribute("testAttr")).thenReturn("");
                                                                                                                                                                when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                                
                                                                                                                                                                when(mockParentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockParentNode).getAttribute("testAttr")).thenReturn(null);
                                                                                                                                                                when(mockParentNode.getParentNode()).thenReturn(null);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                String result = (String) method.invoke(null, mockNode, "testAttr");
                                                                                                                                                                
                                                                                                                                                                assertNull(result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFindEnclosingAttribute_EmptyAttrName() throws Exception {
                                                                                                                                                                // Create mock Node (Element)
                                                                                                                                                                Node mockNode = mock(Element.class);
                                                                                                                                                                
                                                                                                                                                                // Set up mock behavior
                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockNode).getAttribute("")).thenReturn("emptyAttrValue");
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Test the method
                                                                                                                                                                String result = (String) method.invoke(null, mockNode, "");
                                                                                                                                                                assertEquals("emptyAttrValue", result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFindEnclosingAttribute_AttributeExistsButEmptyString() throws Exception {
                                                                                                                                                                // Create mock nodes
                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                Node mockParentNode = mock(Node.class);
                                                                                                                                                                
                                                                                                                                                                // Set up mock behavior
                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockNode).getAttribute("emptyAttr")).thenReturn("");
                                                                                                                                                                when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                                
                                                                                                                                                                when(mockParentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockParentNode).getAttribute("emptyAttr")).thenReturn("nonEmptyValue");
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access the protected method
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Call the method under test
                                                                                                                                                                String result = (String) method.invoke(null, mockNode, "emptyAttr");
                                                                                                                                                                
                                                                                                                                                                // Verify the result
                                                                                                                                                                assertEquals("nonEmptyValue", result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testFindEnclosingAttribute_MultipleLevelsWithEmptyAttributes() throws Exception {
                                                                                                                                                                // Create mock nodes
                                                                                                                                                                Node mockNode = mock(Node.class);
                                                                                                                                                                Node mockParentNode = mock(Node.class);
                                                                                                                                                                Node mockGrandparentNode = mock(Node.class);
                                                                                                                                                                
                                                                                                                                                                // Setup 3-level hierarchy where only top level has non-empty attribute
                                                                                                                                                                when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                                
                                                                                                                                                                when(mockParentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockParentNode).getAttribute("multiAttr")).thenReturn("");
                                                                                                                                                                when(mockParentNode.getParentNode()).thenReturn(mockGrandparentNode);
                                                                                                                                                                
                                                                                                                                                                when(mockGrandparentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                when(((Element)mockGrandparentNode).getAttribute("multiAttr")).thenReturn("topLevelValue");
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                String result = (String) method.invoke(null, mockNode, "multiAttr");
                                                                                                                                                                
                                                                                                                                                                assertEquals("topLevelValue", result);
                                                                                                                                                            }

    @Test
                                                                                                                                                public void testTestNode_Static_NullNodeReturnsFalse() {
                                                                                                                                                    // Setup
                                                                                                                                                    NodeTest test = mock(NodeTest.class);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    boolean result = DOMNodePointer.testNode(null, test);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertFalse(result);
                                                                                                                                                    verifyNoInteractions(test);
                                                                                                                                                }

    @Test
                                                                                                                        public void testTestNode_Static_ReturnsFalseWhenTestFails() {
                                                                                                                            // Setup
                                                                                                                            Node testNode = null; // Mock or create a real Node object here
                                                                                                                            NodeTest test = null; // Mock or create a real NodeTest object here
                                                                                                                            boolean result = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(testNode, test);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            org.junit.Assert.assertFalse(result);
                                                                                                                        }

    @Test
                                                                                                                public void testTestNode_Static_WithDifferentNodeTypes() {
                                                                                                                    // Create test nodes
                                                                                                                    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                    org.w3c.dom.Document document;
                                                                                                                    try {
                                                                                                                        document = factory.newDocumentBuilder().newDocument();
                                                                                                                    } catch (javax.xml.parsers.ParserConfigurationException e) {
                                                                                                                        throw new RuntimeException(e);
                                                                                                                    }
                                                                                                                    org.w3c.dom.Element elementNode = document.createElement("testElement");
                                                                                                                    org.w3c.dom.Text textNode = document.createTextNode("testText");
                                                                                                                    org.w3c.dom.Attr attributeNode = document.createAttribute("testAttr");
                                                                                                                    
                                                                                                                    // Create node pointers for each node type
                                                                                                                    DOMNodePointer elementPointer = new DOMNodePointer(elementNode, Locale.getDefault());
                                                                                                                    DOMNodePointer textPointer = new DOMNodePointer(textNode, Locale.getDefault());
                                                                                                                    DOMNodePointer attributePointer = new DOMNodePointer(attributeNode, Locale.getDefault());
                                                                                                                    
                                                                                                                    // Create a simple node test that matches element and attribute nodes
                                                                                                                    NodeTest test = new NodeTest() {
                                                                                                                        public boolean isNameTest() {
                                                                                                                            return false;
                                                                                                                        }
                                                                                                                        public boolean isWildcard() {
                                                                                                                            return false;
                                                                                                                        }
                                                                                                                        public boolean testNode(NodePointer nodePointer) {
                                                                                                                            return true;
                                                                                                                        }
                                                                                                                    };
                                                                                                                    
                                                                                                                    // Test with different node types
                                                                                                                    org.junit.Assert.assertTrue(elementPointer.testNode(test));
                                                                                                                    org.junit.Assert.assertFalse(textPointer.testNode(test));
                                                                                                                    org.junit.Assert.assertTrue(attributePointer.testNode(test));
                                                                                                                }

    @Test
    public void testFindEnclosingAttribute_NullAttrName() throws Exception {
        // Create mock Node
        
        // Create DOMNodePointer instance
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
            new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, java.util.Locale.getDefault());
        
        // Use reflection to access protected method
        java.lang.reflect.Method method = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
            .getDeclaredMethod("findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
        method.setAccessible(true);
        
        // Set up expected exception
        org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
        expectedException.expect(NullPointerException.class);
        
        // Invoke method with null attribute name
        method.invoke(pointer, mockNode, null);
    }

    @Test
    public void testTestNode_Static_ReturnsTrueWhenTestPasses() throws Exception {
        // Setup
        javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
        javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
        org.w3c.dom.Document document = builder.newDocument();
        org.w3c.dom.Element testNode = document.createElement("test");
        
        // Create a NodeTest that will match our test node
            new org.apache.commons.jxpath.ri.compiler.NodeNameTest(
                new org.apache.commons.jxpath.ri.QName("test"));
        
        // Test
        boolean result = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(testNode, test);
        
        // Verify
        org.junit.Assert.assertTrue(result);
    }

    @Test
    public void testTestNode_DelegatesToStaticMethod() {
        // Setup
        
        try (org.mockito.MockedStatic<org.apache.commons.jxpath.ri.model.dom.DOMNodePointer> mockedStatic = 
{
            // Mock static method call
            
            // Execute
        }
    }


}
