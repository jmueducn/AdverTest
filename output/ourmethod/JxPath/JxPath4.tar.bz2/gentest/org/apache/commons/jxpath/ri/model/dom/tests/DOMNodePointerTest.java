package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                public void testGetValue_CommentNodeWithNullData() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    Comment mockComment = mock(Comment.class);
                                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                                    when(mockComment.getData()).thenReturn(null);
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockComment, null);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    String result = (String) pointer.getValue();
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("", result);
                                                                                                                                                                    verify(mockComment).getData();
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetValue_CommentNodeWithEmptyString() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    Comment mockComment = mock(Comment.class);
                                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                                    when(mockComment.getData()).thenReturn("");
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockComment, null);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    String result = (String) pointer.getValue();
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("", result);
                                                                                                                                                                    verify(mockComment).getData();
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetValue_CommentNodeWithWhitespace() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    Comment mockComment = mock(Comment.class);
                                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                                    when(mockComment.getData()).thenReturn("   test comment   ");
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockComment, null);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    String result = (String) pointer.getValue();
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("test comment", result);
                                                                                                                                                                    verify(mockComment).getData();
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetValue_CommentNodeWithNormalText() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                                    Comment mockComment = mock(Comment.class);
                                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                                    when(mockComment.getData()).thenReturn("test comment");
                                                                                                                                                                    
                                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockComment, null);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    String result = (String) pointer.getValue();
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("test comment", result);
                                                                                                                                                                    verify(mockComment).getData();
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testGetBaseValue_WithTextNode() {
                                                                                                                                                            org.w3c.dom.Text mockText = new org.apache.xerces.dom.TextImpl();
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockText, null);
                                                                                                                                                            assertSame(mockText, pointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetBaseValue_WithNullNode() {
                                                                                                                                                            org.w3c.dom.Node node = null;
                                                                                                                                                            java.util.Locale locale = null;
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(node, locale);
                                                                                                                                                            assertNull(pointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetBaseValue_WithParentPointer() {
                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                            NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(parentPointer, mockNode);
                                                                                                                                                            assertSame(mockNode, pointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetBaseValue_WithIdConstructor() {
                                                                                                                                                            String testId = "testId";
                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, null, testId);
                                                                                                                                                            assertSame(mockNode, pointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetBaseValue_WithLocaleConstructor() {
                                                                                                                                                            org.w3c.dom.Node mockNode = new org.apache.xerces.dom.DocumentImpl().createElement("testElement");
                                                                                                                                                            java.util.Locale locale = java.util.Locale.US;
                                                                                                                                                            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, locale);
                                                                                                                                                            assertSame(mockNode, pointer.getBaseValue());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetImmediateNode_WithElementNode() {
                                                                                                                                                            // Create a mock element node
                                                                                                                                                            Node mockElementNode = mock(Node.class);
                                                                                                                                                            
                                                                                                                                                            // Create a DOMNodePointer with the mock element node
                                                                                                                                                            DOMNodePointer pointerWithElement = new DOMNodePointer(mockElementNode, Locale.getDefault());
                                                                                                                                                            
                                                                                                                                                            // Test the getImmediateNode method
                                                                                                                                                            Node result = (Node) pointerWithElement.getImmediateNode();
                                                                                                                                                            assertSame("Should return the same element node that was set in constructor", 
                                                                                                                                                                      mockElementNode, result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetImmediateNode_WithNullNode() {
                                                                                                                                                            DOMNodePointer pointerWithNull = new DOMNodePointer(null, Locale.getDefault());
                                                                                                                                                            Node result = (Node) pointerWithNull.getImmediateNode();
                                                                                                                                                            assertNull("Should return null when constructed with null node", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetImmediateNode_AfterParentPointerConstruction() {
                                                                                                                                                            // Create mock nodes
                                                                                                                                                            org.w3c.dom.Element mockElementNode = new org.apache.xerces.dom.ElementImpl(null, "testElement");
                                                                                                                                                            org.w3c.dom.Text mockTextNode = new org.apache.xerces.dom.TextImpl();
                                                                                                                                                            mockTextNode.setNodeValue("testValue");
                                                                                                                                                            
                                                                                                                                                            DOMNodePointer parentPointer = new DOMNodePointer(mockElementNode, java.util.Locale.US);
                                                                                                                                                            DOMNodePointer childPointer = new DOMNodePointer(parentPointer, mockTextNode);
                                                                                                                                                            
                                                                                                                                                            Node result = (Node) childPointer.getImmediateNode();
                                                                                                                                                            assertSame("Should return the node set in child pointer", 
                                                                                                                                                                      mockTextNode, result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetImmediateNode_WithIDConstructor() {
                                                                                                                                                            // Create a mock Element node
                                                                                                                                                            Element mockElementNode = mock(Element.class);
                                                                                                                                                            String testId = "testId";
                                                                                                                                                            DOMNodePointer pointerWithId = new DOMNodePointer(mockElementNode, java.util.Locale.US, testId);
                                                                                                                                                            
                                                                                                                                                            Node result = (Node) pointerWithId.getImmediateNode();
                                                                                                                                                            assertSame("Should return node regardless of ID being set", 
                                                                                                                                                                      mockElementNode, result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testIsLanguage_WhenCurrentLanguageIsNull_ShouldDelegateToSuper() {
                                                                                                                                                            // Create a mock Node and Locale
                                                                                                                                                            Node mockNode = mock(Node.class);
                                                                                                                                                            Locale mockLocale = new Locale("");
                                                                                                                                                            
                                                                                                                                                            // Create the pointer instance
                                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, mockLocale);
                                                                                                                                                            
                                                                                                                                                            // Mock getLanguage() to return null using reflection since it's protected
                                                                                                                                                            try {
                                                                                                                                                                Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                                getLanguageMethod.setAccessible(true);
                                                                                                                                                                when(getLanguageMethod.invoke(pointer)).thenReturn(null);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to mock getLanguage() method");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Test with various language inputs
                                                                                                                                                            assertFalse(pointer.isLanguage("en"));
                                                                                                                                                            assertFalse(pointer.isLanguage("fr"));
                                                                                                                                                            assertFalse(pointer.isLanguage(null));
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_AttributeInCurrentNode() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            String attrName = "testAttr";
                                                                                                                                                            String expectedValue = "testValue";
                                                                                                                                                            
                                                                                                                                                            Node currentNode = mock(Node.class);
                                                                                                                                                            when(currentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element element = mock(Element.class);
                                                                                                                                                            when(element.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                            when(currentNode.getParentNode()).thenReturn(null);
                                                                                                                                                            when(((Element) currentNode)).thenReturn(element);
                                                                                                                                                            
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = (String) method.invoke(null, currentNode, attrName);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertEquals(expectedValue, result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_AttributeInParentNode() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            String attrName = "testAttr";
                                                                                                                                                            String expectedValue = "parentValue";
                                                                                                                                                            
                                                                                                                                                            Node childNode = mock(Node.class);
                                                                                                                                                            when(childNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element childElement = mock(Element.class);
                                                                                                                                                            when(childElement.getAttribute(attrName)).thenReturn("");
                                                                                                                                                            
                                                                                                                                                            Node parentNode = mock(Node.class);
                                                                                                                                                            when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element parentElement = mock(Element.class);
                                                                                                                                                            when(parentElement.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                            
                                                                                                                                                            when(childNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                            when(parentNode.getParentNode()).thenReturn(null);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access protected method
                                                                                                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = (String) method.invoke(null, childNode, attrName);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertEquals(expectedValue, result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_AttributeNotFound() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            String attrName = "nonExistentAttr";
                                                                                                                                                            
                                                                                                                                                            Node currentNode = mock(Node.class);
                                                                                                                                                            when(currentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element element = mock(Element.class);
                                                                                                                                                            when(element.getAttribute(attrName)).thenReturn("");
                                                                                                                                                            
                                                                                                                                                            Node parentNode = mock(Node.class);
                                                                                                                                                            when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element parentElement = mock(Element.class);
                                                                                                                                                            when(parentElement.getAttribute(attrName)).thenReturn("");
                                                                                                                                                            
                                                                                                                                                            when(currentNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                            when(parentNode.getParentNode()).thenReturn(null);
                                                                                                                                                        
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = (String) method.invoke(null, currentNode, attrName);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertNull(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_NonElementNodesInHierarchy() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            String attrName = "testAttr";
                                                                                                                                                            String expectedValue = "foundValue";
                                                                                                                                                            
                                                                                                                                                            Node textNode = mock(Node.class);
                                                                                                                                                            when(textNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                            
                                                                                                                                                            Node commentNode = mock(Node.class);
                                                                                                                                                            when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Node elementNode = mock(Node.class);
                                                                                                                                                            when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element element = mock(Element.class);
                                                                                                                                                            when(element.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                            
                                                                                                                                                            when(textNode.getParentNode()).thenReturn(commentNode);
                                                                                                                                                            when(commentNode.getParentNode()).thenReturn(elementNode);
                                                                                                                                                            when(elementNode.getParentNode()).thenReturn(null);
                                                                                                                                                            
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = (String) method.invoke(null, textNode, attrName);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertEquals(expectedValue, result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_NullNodeInput() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            String attrName = "testAttr";
                                                                                                                                                            
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Class<?> clazz = Class.forName("org.apache.commons.jxpath.ri.model.dom.DOMNodePointer");
                                                                                                                                                            Method method = clazz.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = (String) method.invoke(null, null, attrName);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertNull(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_NullAttrNameInput() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            Node currentNode = mock(Node.class);
                                                                                                                                                            
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = (String) method.invoke(null, currentNode, null);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertNull(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_EmptyAttrNameInput() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            Node currentNode = mock(Node.class);
                                                                                                                                                            when(currentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element element = mock(Element.class);
                                                                                                                                                            when(element.getAttribute("")).thenReturn("someValue");
                                                                                                                                                            when(currentNode.getAttributes()).thenReturn(new NamedNodeMap() {
                                                                                                                                                                @Override
                                                                                                                                                                public Node getNamedItem(String name) {
                                                                                                                                                                    return element;
                                                                                                                                                                }
                                                                                                                                                                // Implement other required methods with default returns
                                                                                                                                                                @Override public int getLength() { return 0; }
                                                                                                                                                                @Override public Node item(int index) { return null; }
                                                                                                                                                                @Override public Node setNamedItem(Node arg) { return null; }
                                                                                                                                                                @Override public Node removeNamedItem(String name) { return null; }
                                                                                                                                                                @Override public Node getNamedItemNS(String namespaceURI, String localName) { return null; }
                                                                                                                                                                @Override public Node setNamedItemNS(Node arg) { return null; }
                                                                                                                                                                @Override public Node removeNamedItemNS(String namespaceURI, String localName) { return null; }
                                                                                                                                                            });
                                                                                                                                                        
                                                                                                                                                            // Get protected method via reflection
                                                                                                                                                            Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = (String) method.invoke(null, currentNode, "");
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertEquals("someValue", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_AttributeWithEmptyValue() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            String attrName = "emptyAttr";
                                                                                                                                                            
                                                                                                                                                            Node currentNode = mock(Node.class);
                                                                                                                                                            when(currentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element element = mock(Element.class);
                                                                                                                                                            when(element.getAttribute(attrName)).thenReturn("");
                                                                                                                                                            
                                                                                                                                                            Node parentNode = mock(Node.class);
                                                                                                                                                            when(parentNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                            
                                                                                                                                                            Element parentElement = mock(Element.class);
                                                                                                                                                            when(parentElement.getAttribute(attrName)).thenReturn("validValue");
                                                                                                                                                            
                                                                                                                                                            when(currentNode.getParentNode()).thenReturn(parentNode);
                                                                                                                                                            when(parentNode.getParentNode()).thenReturn(null);
                                                                                                                                                            
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Method method = DOMNodePointer.class.getDeclaredMethod("findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = (String) method.invoke(null, currentNode, attrName);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertEquals("validValue", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testFindEnclosingAttribute_DeepHierarchy() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            String attrName = "deepAttr";
                                                                                                                                                            String expectedValue = "deepValue";
                                                                                                                                                            
                                                                                                                                                            // Create a deep hierarchy (5 levels)
                                                                                                                                                            Node[] nodes = new Node[5];
                                                                                                                                                            for (int i = 0; i < nodes.length; i++) {
                                                                                                                                                                nodes[i] = mock(Node.class);
                                                                                                                                                                when(nodes[i].getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                
                                                                                                                                                                Element element = mock(Element.class);
                                                                                                                                                                when(element.getAttribute(attrName)).thenReturn("");
                                                                                                                                                                
                                                                                                                                                                if (i > 0) {
                                                                                                                                                                    when(nodes[i-1].getParentNode()).thenReturn(nodes[i]);
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Set the attribute on the topmost node
                                                                                                                                                            Element topElement = mock(Element.class);
                                                                                                                                                            when(topElement.getAttribute(attrName)).thenReturn(expectedValue);
                                                                                                                                                            when(nodes[nodes.length-1].getParentNode()).thenReturn(topElement);
                                                                                                                                                            
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                                "findEnclosingAttribute", Node.class, String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test starting from the bottom node
                                                                                                                                                            String result = (String) method.invoke(null, nodes[0], attrName);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertEquals(expectedValue, result);
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testAsPath_TextNode() throws Exception {
                                                                                                                                                        // Mock the node and parent pointer
                                                                                                                                                        Node node = mock(Node.class);
                                                                                                                                                        NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                        
                                                                                                                                                        // Set up mock behaviors
                                                                                                                                                        when(node.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                        when(parentPointer.asPath()).thenReturn("/parent");
                                                                                                                                                        
                                                                                                                                                        // Create the pointer under test
                                                                                                                                                        DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to set the relative position since getRelativePositionOfTextNode() is private
                                                                                                                                                        Method method = DOMNodePointer.class.getDeclaredMethod("getRelativePositionOfTextNode");
                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                        when(method.invoke(pointer)).thenReturn(1);
                                                                                                                                                        
                                                                                                                                                        // Test the asPath method
                                                                                                                                                        String result = pointer.asPath();
                                                                                                                                                        assertEquals("/parent/text()[1]", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testAsPath_CDataSectionNode() throws Exception {
                                                                                                                                                        // Create mock objects
                                                                                                                                                        Node node = mock(Node.class);
                                                                                                                                                        NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                        
                                                                                                                                                        // Set up mock behavior
                                                                                                                                                        when(node.getNodeType()).thenReturn(Node.CDATA_SECTION_NODE);
                                                                                                                                                        when(parentPointer.asPath()).thenReturn("/parent");
                                                                                                                                                        
                                                                                                                                                        // Create the pointer under test
                                                                                                                                                        DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to set the relative position since it's a private method
                                                                                                                                                        Method getRelativePositionOfTextNode = DOMNodePointer.class.getDeclaredMethod("getRelativePositionOfTextNode");
                                                                                                                                                        getRelativePositionOfTextNode.setAccessible(true);
                                                                                                                                                        int position = (int) getRelativePositionOfTextNode.invoke(pointer);
                                                                                                                                                        
                                                                                                                                                        // Test the asPath method
                                                                                                                                                        String result = pointer.asPath();
                                                                                                                                                        assertEquals("/parent/text()[" + (position + 1) + "]", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testAsPath_ProcessingInstructionNode() throws Exception {
                                                                                                                                                        // Mock parent pointer
                                                                                                                                                        DOMNodePointer parentPointer = mock(DOMNodePointer.class);
                                                                                                                                                        when(parentPointer.asPath()).thenReturn("/parent");
                                                                                                                                                        
                                                                                                                                                        // Mock node and processing instruction
                                                                                                                                                        Node node = mock(Node.class);
                                                                                                                                                        when(node.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                        
                                                                                                                                                        ProcessingInstruction pi = mock(ProcessingInstruction.class);
                                                                                                                                                        when(pi.getTarget()).thenReturn("target");
                                                                                                                                                        when(node).thenReturn(pi);
                                                                                                                                                        
                                                                                                                                                        // Create pointer under test
                                                                                                                                                        DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
                                                                                                                                                        
                                                                                                                                                        // Mock the relative position method using reflection since it's private
                                                                                                                                                        Method getRelativePositionOfPIMethod = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                            "getRelativePositionOfPI", String.class);
                                                                                                                                                        getRelativePositionOfPIMethod.setAccessible(true);
                                                                                                                                                        when(getRelativePositionOfPIMethod.invoke(pointer, "target")).thenReturn(1);
                                                                                                                                                        
                                                                                                                                                        String result = pointer.asPath();
                                                                                                                                                        assertEquals("/parent/processing-instruction('target')[1]", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testAsPath_DocumentNode() throws Exception {
                                                                                                                                                    // Create mock objects
                                                                                                                                                    Node node = mock(Node.class);
                                                                                                                                                    NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                    
                                                                                                                                                    // Set up mock behavior
                                                                                                                                                    when(node.getNodeType()).thenReturn(Node.DOCUMENT_NODE);
                                                                                                                                                    when(parentPointer.asPath()).thenReturn("/parent");
                                                                                                                                                    
                                                                                                                                                    // Create the pointer under test
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(parentPointer, node);
                                                                                                                                                    
                                                                                                                                                    // Test the method
                                                                                                                                                    String result = pointer.asPath();
                                                                                                                                                    assertEquals("/parent", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetValue_NonCommentNode() {
                                                                                                                                                    // Setup
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                    // Setup node to return expected value when processed by stringValue()
                                                                                                                                                    when(mockNode.getFirstChild()).thenReturn(mock(Node.class));
                                                                                                                                                    when(mockNode.getFirstChild().getNodeValue()).thenReturn("element value");
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    Object result = pointer.getValue();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertEquals("element value", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetValue_TextNode() {
                                                                                                                                                    // Setup
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                    when(mockNode.getNodeValue()).thenReturn("text value");
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    String result = (String) pointer.getValue();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertEquals("text value", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetValue_ProcessingInstructionNode() {
                                                                                                                                                    // Setup
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                    
                                                                                                                                                    // Create a real DOMNodePointer instance
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Mock the node's behavior that would affect stringValue()
                                                                                                                                                    ProcessingInstruction pi = mock(ProcessingInstruction.class);
                                                                                                                                                    when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                    when(pi.getData()).thenReturn("pi value");
                                                                                                                                                    when(mockNode.getNodeValue()).thenReturn("pi value");
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    String result = (String) pointer.getValue();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertEquals("pi value", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetValue_WithNullNode() {
                                                                                                                                                    // Setup
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer((Node) null, null);
                                                                                                                                                    
                                                                                                                                                    // Expect exception
                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                    exception.expect(NullPointerException.class);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    pointer.getValue();
                                                                                                                                                }

    @Test
                                                                                                                                                public void testStringValue_CommentNode() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node commentNode = mock(Comment.class);
                                                                                                                                                    when(commentNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(commentNode, null);
                                                                                                                                                    
                                                                                                                                                    // Get the private stringValue method via reflection
                                                                                                                                                    Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                    stringValueMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    String result = (String) stringValueMethod.invoke(pointer, commentNode);
                                                                                                                                                    assertEquals("", result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testStringValue_ProcessingInstruction_NullData() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    ProcessingInstruction piNode = mock(ProcessingInstruction.class);
                                                                                                                                                    when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                    when(piNode.getData()).thenReturn(null);
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(piNode, null);
                                                                                                                                                    
                                                                                                                                                    // Get the private stringValue method via reflection
                                                                                                                                                    Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                    stringValueMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertEquals("", stringValueMethod.invoke(pointer, piNode));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testStringValue_ElementWithChildren() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node elementNode = mock(Node.class);
                                                                                                                                                    when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                    
                                                                                                                                                    NodeList childNodes = mock(NodeList.class);
                                                                                                                                                    when(elementNode.getChildNodes()).thenReturn(childNodes);
                                                                                                                                                    when(childNodes.getLength()).thenReturn(3);
                                                                                                                                                    
                                                                                                                                                    // Setup child nodes
                                                                                                                                                    Node textNode1 = mock(Node.class);
                                                                                                                                                    when(textNode1.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                    when(textNode1.getNodeValue()).thenReturn("Hello");
                                                                                                                                                    
                                                                                                                                                    Node textNode2 = mock(Node.class);
                                                                                                                                                    when(textNode2.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                    when(textNode2.getNodeValue()).thenReturn(" ");
                                                                                                                                                    
                                                                                                                                                    Node textNode3 = mock(Node.class);
                                                                                                                                                    when(textNode3.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                    when(textNode3.getNodeValue()).thenReturn("World");
                                                                                                                                                    
                                                                                                                                                    when(childNodes.item(0)).thenReturn(textNode1);
                                                                                                                                                    when(childNodes.item(1)).thenReturn(textNode2);
                                                                                                                                                    when(childNodes.item(2)).thenReturn(textNode3);
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(elementNode, null);
                                                                                                                                                    
                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                    Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                    stringValueMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertEquals("Hello World", stringValueMethod.invoke(pointer, elementNode));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testStringValue_ElementWithNoChildren() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node elementNode = mock(Node.class);
                                                                                                                                                    when(elementNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                    
                                                                                                                                                    NodeList emptyNodeList = mock(NodeList.class);
                                                                                                                                                    when(elementNode.getChildNodes()).thenReturn(emptyNodeList);
                                                                                                                                                    when(emptyNodeList.getLength()).thenReturn(0);
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(elementNode, null);
                                                                                                                                                    
                                                                                                                                                    // Get the private stringValue method using reflection
                                                                                                                                                    Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                                    stringValueMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertEquals("", stringValueMethod.invoke(pointer, elementNode));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetBaseValue_WithRegularNode() {
                                                                                                                                                    org.w3c.dom.Node mockNode = new org.apache.xerces.dom.ElementImpl(null, "testElement");
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    assertSame(mockNode, pointer.getBaseValue());
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WhenCurrentLanguageMatchesExactly_ShouldReturnTrue() throws Exception {
                                                                                                                                                    // Create a mock Node
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    // Create a DOMNodePointer instance with default locale
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set the language value
                                                                                                                                                    Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                                                                                    languageField.setAccessible(true);
                                                                                                                                                    languageField.set(pointer, "en-US");
                                                                                                                                                    
                                                                                                                                                    assertTrue(pointer.isLanguage("en-US"));
                                                                                                                                                    assertTrue(pointer.isLanguage("EN-us")); // case insensitive
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WhenCurrentLanguageStartsWithInput_ShouldReturnTrue() throws Exception {
                                                                                                                                                    // Create a mock Node and Locale for the DOMNodePointer constructor
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Locale locale = Locale.US;
                                                                                                                                                    
                                                                                                                                                    // Create the pointer instance
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set the language value
                                                                                                                                                    Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                                                                                    languageField.setAccessible(true);
                                                                                                                                                    languageField.set(pointer, "en-US");
                                                                                                                                                    
                                                                                                                                                    assertTrue(pointer.isLanguage("en"));
                                                                                                                                                    assertTrue(pointer.isLanguage("EN")); // case insensitive
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WhenCurrentLanguageDoesNotMatch_ShouldReturnFalse() throws Exception {
                                                                                                                                                    // Create a mock node
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    
                                                                                                                                                    // Create a DOMNodePointer instance with a locale
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.FRANCE);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set the language value since getLanguage() is protected
                                                                                                                                                    Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                                                                                    languageField.setAccessible(true);
                                                                                                                                                    languageField.set(pointer, "fr-FR");
                                                                                                                                                    
                                                                                                                                                    assertFalse(pointer.isLanguage("en"));
                                                                                                                                                    assertFalse(pointer.isLanguage("fr-CA"));
                                                                                                                                                    assertFalse(pointer.isLanguage("FR")); // full language doesn't match
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WhenInputLanguageIsNull_ShouldHandleGracefully() throws Exception {
                                                                                                                                                    // Create a mock Node and Locale for the DOMNodePointer constructor
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Locale locale = Locale.US;
                                                                                                                                                    
                                                                                                                                                    // Create the pointer instance
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set the language value since getLanguage() is protected
                                                                                                                                                    Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                                                                                    languageField.setAccessible(true);
                                                                                                                                                    languageField.set(pointer, "en-US");
                                                                                                                                                    
                                                                                                                                                    // Test the isLanguage method with null input
                                                                                                                                                    assertFalse(pointer.isLanguage(null));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WhenCurrentLanguageIsEmptyString_ShouldHandleGracefully() {
                                                                                                                                                    // Create a mock Node and Locale for the DOMNodePointer constructor
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Locale mockLocale = mock(Locale.class);
                                                                                                                                                    
                                                                                                                                                    // Create the pointer instance
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, mockLocale);
                                                                                                                                                    
                                                                                                                                                    try {
                                                                                                                                                        // Use reflection to access the protected getLanguage() method
                                                                                                                                                        Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                        getLanguageMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Create a spy to intercept the getLanguage() call
                                                                                                                                                        DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                                        when(getLanguageMethod.invoke(spyPointer)).thenReturn("");
                                                                                                                                                        
                                                                                                                                                        // Test assertions
                                                                                                                                                        assertFalse(spyPointer.isLanguage("en"));
                                                                                                                                                        assertFalse(spyPointer.isLanguage(""));
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WhenInputLanguageIsEmptyString_ShouldHandleGracefully() {
                                                                                                                                                    // Create a mock Node and Locale for the DOMNodePointer constructor
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Locale locale = Locale.US;
                                                                                                                                                    
                                                                                                                                                    // Create the pointer instance
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                                    
                                                                                                                                                    try {
                                                                                                                                                        // Use reflection to access the protected getLanguage() method
                                                                                                                                                        Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                        getLanguageMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Mock the return value of getLanguage()
                                                                                                                                                        DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                                        when(getLanguageMethod.invoke(spyPointer)).thenReturn("en-US");
                                                                                                                                                        
                                                                                                                                                        // Test with empty string
                                                                                                                                                        assertFalse(spyPointer.isLanguage(""));
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Exception occurred while testing: " + e.getMessage());
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WithDifferentCaseVariations_ShouldBeCaseInsensitive() throws Exception {
                                                                                                                                                    // Create a mock node
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    // Create a DOMNodePointer instance with default locale
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set the language field since getLanguage() is protected
                                                                                                                                                    Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                                                                                    languageField.setAccessible(true);
                                                                                                                                                    languageField.set(pointer, "en-US");
                                                                                                                                                    
                                                                                                                                                    // Test case-insensitive language matching
                                                                                                                                                    assertTrue(pointer.isLanguage("EN-us"));
                                                                                                                                                    assertTrue(pointer.isLanguage("en-US"));
                                                                                                                                                    assertTrue(pointer.isLanguage("EN-US"));
                                                                                                                                                    assertTrue(pointer.isLanguage("en-us"));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsLanguage_WithPartialMatchButNotPrefix_ShouldReturnFalse() throws Exception {
                                                                                                                                                    // Create a mock Node
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    // Create a DOMNodePointer with default locale
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.US);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set the language field
                                                                                                                                                    Field languageField = DOMNodePointer.class.getDeclaredField("language");
                                                                                                                                                    languageField.setAccessible(true);
                                                                                                                                                    languageField.set(pointer, "en-US");
                                                                                                                                                    
                                                                                                                                                    // Test partial matches that aren't prefixes
                                                                                                                                                    assertFalse(pointer.isLanguage("n-U"));
                                                                                                                                                    assertFalse(pointer.isLanguage("US"));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenNodeHasDirectLangAttribute() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                                                                                    Node mockLangAttr = mock(Node.class);
                                                                                                                                                    
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                    when(mockAttributes.getNamedItem("xml:lang")).thenReturn(mockLangAttr);
                                                                                                                                                    when(mockLangAttr.getNodeValue()).thenReturn("en-US");
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String language = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertEquals("en-US", language);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenParentNodeHasLangAttribute() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Node mockParentNode = mock(Node.class);
                                                                                                                                                    Attr mockLangAttr = mock(Attr.class);
                                                                                                                                                    NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                                                                                    NamedNodeMap mockParentAttributes = mock(NamedNodeMap.class);
                                                                                                                                                    
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                    when(mockAttributes.getNamedItem("xml:lang")).thenReturn(null);
                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                    when(mockParentNode.getAttributes()).thenReturn(mockParentAttributes);
                                                                                                                                                    when(mockParentAttributes.getNamedItem("xml:lang")).thenReturn(mockLangAttr);
                                                                                                                                                    when(mockLangAttr.getNodeValue()).thenReturn("fr");
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String language = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertEquals("fr", language);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenNoLangAttributeInHierarchy() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    NamedNodeMap mockNamedNodeMap = mock(NamedNodeMap.class);
                                                                                                                                                    
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mockNamedNodeMap);
                                                                                                                                                    when(mockNamedNodeMap.getNamedItem("xml:lang")).thenReturn(null);
                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(null); // No parent
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String language = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertNull(language);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenNodeIsNull() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer((Node)null, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertNull(getLanguageMethod.invoke(pointer));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenLangAttributeExistsButEmpty() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Attr mockLangAttr = mock(Attr.class);
                                                                                                                                                    NamedNodeMap mockAttributes = mock(NamedNodeMap.class);
                                                                                                                                                    
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mockAttributes);
                                                                                                                                                    when(mockAttributes.getNamedItem("xml:lang")).thenReturn(mockLangAttr);
                                                                                                                                                    when(mockLangAttr.getNodeValue()).thenReturn("");
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String language = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertEquals("", language);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLanguage_WhenMultipleLevelsOfInheritance() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                                                    Node mockParentNode = mock(Node.class);
                                                                                                                                                    Node grandParentNode = mock(Node.class);
                                                                                                                                                    Node mockLangAttr = mock(Node.class);
                                                                                                                                                    
                                                                                                                                                    when(mockNode.getAttributes()).thenReturn(mock(NamedNodeMap.class));
                                                                                                                                                    when(mockNode.getAttributes().getNamedItem("xml:lang")).thenReturn(null);
                                                                                                                                                    when(mockNode.getParentNode()).thenReturn(mockParentNode);
                                                                                                                                                    
                                                                                                                                                    when(mockParentNode.getAttributes()).thenReturn(mock(NamedNodeMap.class));
                                                                                                                                                    when(mockParentNode.getAttributes().getNamedItem("xml:lang")).thenReturn(null);
                                                                                                                                                    when(mockParentNode.getParentNode()).thenReturn(grandParentNode);
                                                                                                                                                    
                                                                                                                                                    when(grandParentNode.getAttributes()).thenReturn(mock(NamedNodeMap.class));
                                                                                                                                                    when(grandParentNode.getAttributes().getNamedItem("xml:lang")).thenReturn(mockLangAttr);
                                                                                                                                                    when(mockLangAttr.getNodeValue()).thenReturn("de");
                                                                                                                                                    
                                                                                                                                                    DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                    Method getLanguageMethod = DOMNodePointer.class.getDeclaredMethod("getLanguage");
                                                                                                                                                    getLanguageMethod.setAccessible(true);
                                                                                                                                                    String language = (String) getLanguageMethod.invoke(pointer);
                                                                                                                                                    
                                                                                                                                                    // Test & Verify
                                                                                                                                                    assertEquals("de", language);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testAsPath_WithId() {
                                                                                                                                                    try {
                                                                                                                                                        javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                        javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                        org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                        org.w3c.dom.Element node = document.createElement("testElement");
                                                                                                                                                        
                                                                                                                                                        String id = "testId";
                                                                                                                                                        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                                            new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node, java.util.Locale.US, id);
                                                                                                                                                        
                                                                                                                                                        String result = pointer.asPath();
                                                                                                                                                        assertEquals("id('testId')", result);
                                                                                                                                                    } catch (javax.xml.parsers.ParserConfigurationException e) {
                                                                                                                                                        fail("Parser configuration error: " + e.getMessage());
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                                                public void testAsPath_ElementNode_WithParent_NoPrefixNamespace() throws Exception {
                                                                                                                                                    // Create mock objects
                                                                                                                                                    org.w3c.dom.Node node = mock(org.w3c.dom.Node.class);
                                                                                                                                                    org.apache.commons.jxpath.ri.model.NodePointer parentPointer = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                    org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                                    
                                                                                                                                                    // Set up mock behavior
                                                                                                                                                    when(node.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                                                    when(parentPointer.asPath()).thenReturn("/parent");
                                                                                                                                                    when(parentPointer.getNamespaceURI()).thenReturn("http://example");
                                                                                                                                                    when(namespaceResolver.getDefaultNamespaceURI()).thenReturn("http://default");
                                                                                                                                                    when(namespaceResolver.getPrefix("http://example")).thenReturn(null);
                                                                                                                                                    
                                                                                                                                                    // Create test object
                                                                                                                                                    org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(parentPointer, node);
                                                                                                                                                    pointer.setNamespaceResolver(namespaceResolver);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to set relative position since getRelativePositionOfElement() is private
                                                                                                                                                    java.lang.reflect.Field field = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredField("relativePositionOfElement");
                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                    field.set(pointer, 3);
                                                                                                                                                    
                                                                                                                                                    // Test the method
                                                                                                                                                    String result = pointer.asPath();
                                                                                                                                                    assertEquals("/parent/node()[3]", result);
                                                                                                                                                }

    @Test
                                                                                                                                        public void testStringValue_TextNode_Trim() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            org.w3c.dom.Text textNode = mock(org.w3c.dom.Text.class);
                                                                                                                                            when(textNode.getNodeType()).thenReturn(org.w3c.dom.Node.TEXT_NODE);
                                                                                                                                            when(textNode.getNodeValue()).thenReturn("  some text  ");
                                                                                                                                            
                                                                                                                                            // Create pointer instance
                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(textNode, null);
                                                                                                                                            
                                                                                                                                            // Use reflection to test private stringValue method
                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", org.w3c.dom.Node.class);
                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Test & Verify
                                                                                                                                            assertEquals("some text", stringValueMethod.invoke(pointer, textNode));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testStringValue_TextNode_NullValue() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            org.w3c.dom.Node textNode = mock(org.w3c.dom.Text.class);
                                                                                                                                            when(textNode.getNodeType()).thenReturn(org.w3c.dom.Node.TEXT_NODE);
                                                                                                                                            when(textNode.getNodeValue()).thenReturn(null);
                                                                                                                                            
                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(textNode, null);
                                                                                                                                            
                                                                                                                                            // Use reflection to access private method
                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", org.w3c.dom.Node.class);
                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Test & Verify
                                                                                                                                            assertEquals("", stringValueMethod.invoke(pointer, textNode));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testStringValue_CDATASection() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            org.w3c.dom.CDATASection cdataNode = mock(org.w3c.dom.CDATASection.class);
                                                                                                                                            when(cdataNode.getNodeType()).thenReturn(org.w3c.dom.Node.CDATA_SECTION_NODE);
                                                                                                                                            when(cdataNode.getNodeValue()).thenReturn("<![CDATA[content]]>");
                                                                                                                                            
                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(cdataNode, null);
                                                                                                                                            
                                                                                                                                            // Use reflection to mock protected findEnclosingAttribute
                                                                                                                                            Method findEnclosingAttribute = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                "findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
                                                                                                                                            findEnclosingAttribute.setAccessible(true);
                                                                                                                                            findEnclosingAttribute.invoke(pointer, cdataNode, "xml:space");
                                                                                                                                            
                                                                                                                                            // Use reflection to call private stringValue
                                                                                                                                            Method stringValue = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                                "stringValue", org.w3c.dom.Node.class);
                                                                                                                                            stringValue.setAccessible(true);
                                                                                                                                            String result = (String) stringValue.invoke(pointer, cdataNode);
                                                                                                                                            
                                                                                                                                            // Test & Verify
                                                                                                                                            assertEquals("<![CDATA[content]]>", result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testStringValue_ProcessingInstruction_Trim() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            ProcessingInstruction piNode = mock(ProcessingInstruction.class);
                                                                                                                                            when(piNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                            when(piNode.getData()).thenReturn("  target data  ");
                                                                                                                                            
                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(piNode, null);
                                                                                                                                            
                                                                                                                                            // Use reflection to set up findEnclosingAttribute behavior
                                                                                                                                            Field findEnclosingAttributeField = DOMNodePointer.class
                                                                                                                                                .getDeclaredField("findEnclosingAttribute");
                                                                                                                                            findEnclosingAttributeField.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Create a spy that won't interfere with protected methods
                                                                                                                                            DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                            
                                                                                                                                            // Use reflection to call the private stringValue method
                                                                                                                                            Method stringValueMethod = DOMNodePointer.class
                                                                                                                                                .getDeclaredMethod("stringValue", Node.class);
                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Test & Verify
                                                                                                                                            String result = (String) stringValueMethod.invoke(spyPointer, piNode);
                                                                                                                                            assertEquals("target data", result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testStringValue_NullNode() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            Node mockNode = null;
                                                                                                                                            Locale locale = Locale.getDefault();
                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                            
                                                                                                                                            // Get private method via reflection
                                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod("stringValue", Node.class);
                                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Expect exception
                                                                                                                                            ExpectedException exception = ExpectedException.none();
                                                                                                                                            exception.expect(NullPointerException.class);
                                                                                                                                            
                                                                                                                                            // Test
                                                                                                                                            stringValueMethod.invoke(pointer, (Node)null);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testGetBaseValue_WithElementNode() throws Exception {
                                                                                                                                            // Create a real Element node using DOM
                                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                            org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                            org.w3c.dom.Element element = document.createElement("testElement");
                                                                                                                                            
                                                                                                                                            // Create the DOMNodePointer instance
                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(element, null);
                                                                                                                                            
                                                                                                                                            // Verify the base value matches the element
                                                                                                                                            assertSame(element, pointer.getBaseValue());
                                                                                                                                        }

    @Test
                                                                                                                                        public void testGetBaseValue_WithDocumentNode() throws Exception {
                                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                            org.w3c.dom.Document mockDocument = builder.newDocument();
                                                                                                                                            
                                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(mockDocument, null);
                                                                                                                                            assertSame(mockDocument, pointer.getBaseValue());
                                                                                                                                        }

    @Test
                                                                                                                                        public void testGetBaseValue_ConsistencyAcrossMultipleCalls() {
                                                                                                                                            // Create mock Node object (using a simple implementation for testing)
                                                                                                                                            org.w3c.dom.Node mockNode = new org.w3c.dom.Node() {
                                                                                                                                                // Implement required Node interface methods with minimal implementation
                                                                                                                                                public String getNodeName() { return ""; }
                                                                                                                                                public String getNodeValue() { return ""; }
                                                                                                                                                public void setNodeValue(String nodeValue) {}
                                                                                                                                                public short getNodeType() { return 0; }
                                                                                                                                                public org.w3c.dom.Node getParentNode() { return null; }
                                                                                                                                                public org.w3c.dom.NodeList getChildNodes() { return null; }
                                                                                                                                                public org.w3c.dom.Node getFirstChild() { return null; }
                                                                                                                                                public org.w3c.dom.Node getLastChild() { return null; }
                                                                                                                                                public org.w3c.dom.Node getPreviousSibling() { return null; }
                                                                                                                                                public org.w3c.dom.Node getNextSibling() { return null; }
                                                                                                                                                public org.w3c.dom.NamedNodeMap getAttributes() { return null; }
                                                                                                                                                public org.w3c.dom.Document getOwnerDocument() { return null; }
                                                                                                                                                public org.w3c.dom.Node insertBefore(org.w3c.dom.Node newChild, org.w3c.dom.Node refChild) { return null; }
                                                                                                                                                public org.w3c.dom.Node replaceChild(org.w3c.dom.Node newChild, org.w3c.dom.Node oldChild) { return null; }
                                                                                                                                                public org.w3c.dom.Node removeChild(org.w3c.dom.Node oldChild) { return null; }
                                                                                                                                                public org.w3c.dom.Node appendChild(org.w3c.dom.Node newChild) { return null; }
                                                                                                                                                public boolean hasChildNodes() { return false; }
                                                                                                                                                public org.w3c.dom.Node cloneNode(boolean deep) { return null; }
                                                                                                                                                public void normalize() {}
                                                                                                                                                public boolean isSupported(String feature, String version) { return false; }
                                                                                                                                                public String getNamespaceURI() { return null; }
                                                                                                                                                public String getPrefix() { return null; }
                                                                                                                                                public void setPrefix(String prefix) {}
                                                                                                                                                public String getLocalName() { return null; }
                                                                                                                                                public boolean hasAttributes() { return false; }
                                                                                                                                                public String getBaseURI() { return null; }
                                                                                                                                                public short compareDocumentPosition(org.w3c.dom.Node other) { return 0; }
                                                                                                                                                public String getTextContent() { return null; }
                                                                                                                                                public void setTextContent(String textContent) {}
                                                                                                                                                public boolean isSameNode(org.w3c.dom.Node other) { return false; }
                                                                                                                                                public String lookupPrefix(String namespaceURI) { return null; }
                                                                                                                                                public boolean isDefaultNamespace(String namespaceURI) { return false; }
                                                                                                                                                public String lookupNamespaceURI(String prefix) { return null; }
                                                                                                                                                public boolean isEqualNode(org.w3c.dom.Node arg) { return false; }
                                                                                                                                                public Object getFeature(String feature, String version) { return null; }
                                                                                                                                                public Object setUserData(String key, Object data, org.w3c.dom.UserDataHandler handler) { return null; }
                                                                                                                                                public Object getUserData(String key) { return null; }
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                                new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, null);
                                                                                                                                            // First call
                                                                                                                                            assertSame(mockNode, pointer.getBaseValue());
                                                                                                                                            // Second call
                                                                                                                                            assertSame(mockNode, pointer.getBaseValue());
                                                                                                                                            // Third call
                                                                                                                                            assertSame(mockNode, pointer.getBaseValue());
                                                                                                                                        }

    @Test
                                                                                                                                        public void testGetImmediateNode_WithTextNode() throws Exception {
                                                                                                                                            // Create a document and text node
                                                                                                                                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                            org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                            org.w3c.dom.Node mockTextNode = document.createTextNode("test");
                                                                                                                                            
                                                                                                                                            // Create a DOMNodePointer with the text node
                                                                                                                                            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointerWithText = 
                                                                                                                                                new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockTextNode, java.util.Locale.getDefault());
                                                                                                                                            
                                                                                                                                            org.w3c.dom.Node result = (org.w3c.dom.Node) pointerWithText.getImmediateNode();
                                                                                                                                            assertSame("Should return the same text node that was set in constructor", 
                                                                                                                                                      mockTextNode, result);
                                                                                                                                        }

    @Test
                                                                                                                                    public void testAsPath_ElementNode_NoParent_DefaultNamespace() throws Exception {
                                                                                                                                        // Mock objects
                                                                                                                                        org.w3c.dom.Node node = mock(org.w3c.dom.Node.class);
                                                                                                                                        org.apache.commons.jxpath.ri.model.NodePointer parentPointer = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                                        
                                                                                                                                        // Setup mocks
                                                                                                                                        when(node.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                                        when(parentPointer.getNamespaceURI()).thenReturn("http://default");
                                                                                                                                        when(namespaceResolver.getDefaultNamespaceURI()).thenReturn("http://default");
                                                                                                                                        
                                                                                                                                        // Create test object
                                                                                                                                        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                            new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(parentPointer, node);
                                                                                                                                        pointer.setNamespaceResolver(namespaceResolver);
                                                                                                                                        
                                                                                                                                        // Mock node properties directly
                                                                                                                                        when(node.getLocalName()).thenReturn("element");
                                                                                                                                        when(node.getPrefix()).thenReturn(null);
                                                                                                                                        when(node.getNamespaceURI()).thenReturn("http://default");
                                                                                                                                        
                                                                                                                                        // Mock private method call using reflection
                                                                                                                                        Method getRelativePositionByNameMethod = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                                            .getDeclaredMethod("getRelativePositionByName");
                                                                                                                                        getRelativePositionByNameMethod.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Create a spy to mock the private method
                                                                                                                                        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer spyPointer = spy(pointer);
                                                                                                                                        when(getRelativePositionByNameMethod.invoke(spyPointer)).thenReturn(1);
                                                                                                                                        
                                                                                                                                        // Test and verify
                                                                                                                                        String result = spyPointer.asPath();
                                                                                                                                        assertEquals("/element[1]", result);
                                                                                                                                    }

    @Test
                                                                                                                        public void testStringValue_TextNode_Preserve() throws Exception {
                                                                                                                            // Setup
                                                                                                                            org.w3c.dom.Text textNode = mock(org.w3c.dom.Text.class);
                                                                                                                            when(textNode.getNodeType()).thenReturn(org.w3c.dom.Node.TEXT_NODE);
                                                                                                                            when(textNode.getNodeValue()).thenReturn("  preserved text  ");
                                                                                                                            
                                                                                                                            // Create DOMNodePointer instance
                                                                                                                            DOMNodePointer pointer = new DOMNodePointer(textNode, null);
                                                                                                                            
                                                                                                                            // Create a spy
                                                                                                                            DOMNodePointer spyPointer = spy(pointer);
                                                                                                                            
                                                                                                                            // Get the protected findEnclosingAttribute method using reflection
                                                                                                                            Method findEnclosingAttributeMethod = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                "findEnclosingAttribute", org.w3c.dom.Node.class, String.class);
                                                                                                                            findEnclosingAttributeMethod.setAccessible(true);
                                                                                                                            
                                                                                                                            // Stub the protected method to return "preserve"
                                                                                                                            when(findEnclosingAttributeMethod.invoke(
                                                                                                                                spyPointer, 
                                                                                                                                any(org.w3c.dom.Node.class), 
                                                                                                                                eq("xml:space"))
                                                                                                                            ).thenReturn("preserve");
                                                                                                                            
                                                                                                                            // Get the private stringValue method using reflection
                                                                                                                            Method stringValueMethod = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                                "stringValue", org.w3c.dom.Node.class);
                                                                                                                            stringValueMethod.setAccessible(true);
                                                                                                                            
                                                                                                                            // Test & Verify
                                                                                                                            String result = (String) stringValueMethod.invoke(spyPointer, textNode);
                                                                                                                            assertEquals("  preserved text  ", result);
                                                                                                                        }

    @Test
                                                                                                                public void testAsPath_ElementNode_WithParent_DefaultNamespace() throws Exception {
                                                                                                                    // Create mock objects
                                                                                                                    org.apache.commons.jxpath.ri.model.NodePointer parentPointer = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                    org.w3c.dom.Node node = mock(org.w3c.dom.Node.class);
                                                                                                                    org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                    
                                                                                                                    // Set up mock behavior
                                                                                                                    when(parentPointer.asPath()).thenReturn("/parent");
                                                                                                                    when(node.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                    
                                                                                                                    // Create test object
                                                                                                                    org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                        new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(parentPointer, node);
                                                                                                                    pointer.setNamespaceResolver(namespaceResolver);
                                                                                                                    
                                                                                                                    // Mock static method using reflection (since getLocalName is static)
                                                                                                                    java.lang.reflect.Method getLocalNameMethod = 
                                                                                                                        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredMethod(
                                                                                                                            "getLocalName", org.w3c.dom.Node.class);
                                                                                                                    getLocalNameMethod.setAccessible(true);
                                                                                                                    when(getLocalNameMethod.invoke(null, node)).thenReturn("element");
                                                                                                                    
                                                                                                                    // Mock private method using reflection
                                                                                                                    java.lang.reflect.Method getRelativePositionByNameMethod = 
                                                                                                                        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredMethod(
                                                                                                                            "getRelativePositionByName");
                                                                                                                    getRelativePositionByNameMethod.setAccessible(true);
                                                                                                                    when(getRelativePositionByNameMethod.invoke(pointer)).thenReturn(1);
                                                                                                                    
                                                                                                                    // Test and verify
                                                                                                                    String result = pointer.asPath();
                                                                                                                    org.junit.Assert.assertEquals("/parent/element[1]", result);
                                                                                                                }

    @Test
                                                                                                            public void testAsPath_ElementNode_WithParent_EndsWithSlash() throws Exception {
                                                                                                                // Create mocks
                                                                                                                org.w3c.dom.Node node = mock(org.w3c.dom.Node.class);
                                                                                                                org.apache.commons.jxpath.ri.model.NodePointer parentPointer = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                
                                                                                                                // Set up mock behaviors
                                                                                                                when(node.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                when(parentPointer.asPath()).thenReturn("/parent/");
                                                                                                                when(parentPointer.getNamespaceURI()).thenReturn("http://default");
                                                                                                                when(namespaceResolver.getDefaultNamespaceURI()).thenReturn("http://default");
                                                                                                                
                                                                                                                // Create test object
                                                                                                                org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                    new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(parentPointer, node);
                                                                                                                pointer.setNamespaceResolver(namespaceResolver);
                                                                                                                
                                                                                                                // Mock static method behavior using reflection
                                                                                                                java.lang.reflect.Method getLocalNameMethod = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                    .getDeclaredMethod("getLocalName", org.w3c.dom.Node.class);
                                                                                                                getLocalNameMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Mock the static method behavior
                                                                                                                org.apache.commons.jxpath.ri.model.dom.DOMNodePointer spyPointer = spy(pointer);
                                                                                                                doReturn("element").when(spyPointer).getLocalName(node);
                                                                                                                
                                                                                                                // Mock private method behavior using reflection
                                                                                                                java.lang.reflect.Method getRelativePositionByNameMethod = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class
                                                                                                                    .getDeclaredMethod("getRelativePositionByName");
                                                                                                                getRelativePositionByNameMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Test and verify
                                                                                                                String result = spyPointer.asPath();
                                                                                                                assertEquals("/parent/element[1]", result);
                                                                                                            }

    @Test
                                                                                                            public void testAsPath_ElementNode_WithParent_PrefixedNamespace() throws Exception {
                                                                                                                // Mock objects
                                                                                                                org.w3c.dom.Node node = mock(org.w3c.dom.Node.class);
                                                                                                                org.apache.commons.jxpath.ri.model.dom.DOMNodePointer parentPointer = 
                                                                                                                    mock(org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class);
                                                                                                                org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = 
                                                                                                                    mock(org.apache.commons.jxpath.ri.NamespaceResolver.class);
                                                                                                                
                                                                                                                // Setup mock behavior
                                                                                                                when(node.getNodeType()).thenReturn(org.w3c.dom.Node.ELEMENT_NODE);
                                                                                                                when(parentPointer.asPath()).thenReturn("/parent");
                                                                                                                when(parentPointer.getNamespaceURI()).thenReturn("http://example");
                                                                                                                when(namespaceResolver.getDefaultNamespaceURI()).thenReturn("http://default");
                                                                                                                when(namespaceResolver.getPrefix("http://example")).thenReturn("ex");
                                                                                                                
                                                                                                                // Create test object
                                                                                                                org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                    new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(parentPointer, node);
                                                                                                                pointer.setNamespaceResolver(namespaceResolver);
                                                                                                                
                                                                                                                // Mock static method behavior using reflection
                                                                                                                java.lang.reflect.Method getLocalNameMethod = 
                                                                                                                    org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredMethod(
                                                                                                                        "getLocalName", org.w3c.dom.Node.class);
                                                                                                                getLocalNameMethod.setAccessible(true);
                                                                                                                when(getLocalNameMethod.invoke(pointer, node)).thenReturn("element");
                                                                                                                
                                                                                                                // Mock relative position
                                                                                                                java.lang.reflect.Field relativePositionField = 
                                                                                                                    org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredField("relativePosition");
                                                                                                                relativePositionField.setAccessible(true);
                                                                                                                relativePositionField.set(pointer, 2);
                                                                                                                
                                                                                                                // Test
                                                                                                                String result = pointer.asPath();
                                                                                                                assertEquals("/parent/ex:element[2]", result);
                                                                                                            }

    @Test
    public void testGetImmediateNode_VerifyNoSideEffects() {
        try {
            // Import required classes
            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
            org.w3c.dom.Document document = builder.newDocument();
            org.w3c.dom.Node mockNode = document.createElement("testElement");
            
            // Create DOMNodePointer instance
            org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointerWithElement = 
                new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, java.util.Locale.getDefault());
            
            // First call to getImmediateNode
            Object firstResult = pointerWithElement.getImmediateNode();
            
            // Second call to getImmediateNode
            Object secondResult = pointerWithElement.getImmediateNode();
            
            // Verify same result is returned
            org.junit.Assert.assertEquals(firstResult, secondResult);
            
            // Since we're not using Mockito anymore, we can't verify interactions
            // Instead, we can verify the node wasn't modified by checking its properties
            org.junit.Assert.assertEquals("testElement", mockNode.getNodeName());
        } catch (javax.xml.parsers.ParserConfigurationException e) {
            org.junit.Assert.fail("Parser configuration failed: " + e.getMessage());
        }
    }


}
