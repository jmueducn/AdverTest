package gentest.org.apache.commons.jxpath.ri.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class NamespaceResolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testGetNamespaceURI_WithNullPrefix() {
                                                                                                                                                                            // Setup
                                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                            
                                                                                                                                                                            // Test
                                                                                                                                                                            String result = resolver.getNamespaceURI(null);
                                                                                                                                                                            
                                                                                                                                                                            // Verify
                                                                                                                                                                            assertNull(result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSeal_SetsSealedFlag() {
                                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                            assertFalse(resolver.isSealed());
                                                                                                                                                                            
                                                                                                                                                                            resolver.seal();
                                                                                                                                                                            assertTrue(resolver.isSealed());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSeal_WithNullParent() {
                                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver(null);
                                                                                                                                                                            resolver.seal();
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(resolver.isSealed());
                                                                                                                                                                            // No parent to verify
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSeal_WithParent() {
                                                                                                                                                                            NamespaceResolver parent = mock(NamespaceResolver.class);
                                                                                                                                                                            NamespaceResolver child = new NamespaceResolver(parent);
                                                                                                                                                                            
                                                                                                                                                                            child.seal();
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(child.isSealed());
                                                                                                                                                                            verify(parent).seal(); // Verify parent's seal() was called
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSeal_AlreadySealed() {
                                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                            resolver.seal(); // First seal
                                                                                                                                                                            resolver.seal(); // Second seal
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(resolver.isSealed());
                                                                                                                                                                            // Should not throw exception when called multiple times
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSeal_WithParentChain() {
                                                                                                                                                                            NamespaceResolver grandParent = new NamespaceResolver();
                                                                                                                                                                            NamespaceResolver parent = new NamespaceResolver(grandParent);
                                                                                                                                                                            NamespaceResolver child = new NamespaceResolver(parent);
                                                                                                                                                                            
                                                                                                                                                                            child.seal();
                                                                                                                                                                            
                                                                                                                                                                            assertTrue(child.isSealed());
                                                                                                                                                                            assertTrue(parent.isSealed());
                                                                                                                                                                            assertTrue(grandParent.isSealed());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSeal_AfterClone() throws CloneNotSupportedException {
                                                                                                                                                                            NamespaceResolver original = new NamespaceResolver();
                                                                                                                                                                            original.seal();
                                                                                                                                                                            
                                                                                                                                                                            NamespaceResolver clone = (NamespaceResolver) original.clone();
                                                                                                                                                                            assertFalse(clone.isSealed()); // Assuming clone creates unsealed copy
                                                                                                                                                                            
                                                                                                                                                                            clone.seal();
                                                                                                                                                                            assertTrue(clone.isSealed());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testClone_EmptyResolver() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            NamespaceResolver original = new NamespaceResolver();
                                                                                                                                                                            
                                                                                                                                                                            // Act
                                                                                                                                                                            NamespaceResolver clone = (NamespaceResolver) original.clone();
                                                                                                                                                                            
                                                                                                                                                                            // Assert
                                                                                                                                                                            assertNotNull(clone);
                                                                                                                                                                            assertNotSame(original, clone);
                                                                                                                                                                            assertFalse(clone.isSealed());
                                                                                                                                                                            assertNull(clone.getNamespaceContextPointer());
                                                                                                                                                                            assertTrue(clone.getNamespaceURI("anyPrefix") == null);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testClone_WithNamespaceMappings() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            NamespaceResolver original = new NamespaceResolver();
                                                                                                                                                                            original.registerNamespace("pre", "http://example.com");
                                                                                                                                                                            original.seal();
                                                                                                                                                                            
                                                                                                                                                                            // Act
                                                                                                                                                                            NamespaceResolver clone = (NamespaceResolver) original.clone();
                                                                                                                                                                            
                                                                                                                                                                            // Assert
                                                                                                                                                                            assertNotNull(clone);
                                                                                                                                                                            assertEquals("http://example.com", clone.getNamespaceURI("pre"));
                                                                                                                                                                            assertFalse(clone.isSealed()); // Should be false even if original was sealed
                                                                                                                                                                            
                                                                                                                                                                            // Verify it's a deep copy of the maps
                                                                                                                                                                            original.registerNamespace("new", "http://new.com");
                                                                                                                                                                            assertNull(clone.getNamespaceURI("new"));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testClone_SealedOriginal() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            NamespaceResolver original = new NamespaceResolver();
                                                                                                                                                                            original.seal();
                                                                                                                                                                            
                                                                                                                                                                            // Act
                                                                                                                                                                            NamespaceResolver clone = (NamespaceResolver) original.clone();
                                                                                                                                                                            
                                                                                                                                                                            // Assert
                                                                                                                                                                            assertTrue(original.isSealed());
                                                                                                                                                                            assertFalse(clone.isSealed());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testClone_WithPointerAndMaps() throws Exception {
                                                                                                                                                                            // Arrange
                                                                                                                                                                            NamespaceResolver original = new NamespaceResolver();
                                                                                                                                                                            NodePointer pointer = mock(NodePointer.class);
                                                                                                                                                                            original.setNamespaceContextPointer(pointer);
                                                                                                                                                                            original.registerNamespace("p1", "uri1");
                                                                                                                                                                            original.registerNamespace("p2", "uri2");
                                                                                                                                                                            
                                                                                                                                                                            // Act
                                                                                                                                                                            NamespaceResolver clone = (NamespaceResolver) original.clone();
                                                                                                                                                                            
                                                                                                                                                                            // Assert
                                                                                                                                                                            assertEquals(pointer, clone.getNamespaceContextPointer());
                                                                                                                                                                            assertEquals("uri1", clone.getNamespaceURI("p1"));
                                                                                                                                                                            assertEquals("uri2", clone.getNamespaceURI("p2"));
                                                                                                                                                                            assertEquals("p1", clone.getPrefix("uri1"));
                                                                                                                                                                            assertEquals("p2", clone.getPrefix("uri2"));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testGetNamespaceURI_WithExternalURIAndNoPointer() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                    String testPrefix = "test";
                                                                                                                                                                    String expectedURI = "http://example.com";
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to set the expected URI in the protected method
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Create a subclass that returns our expected URI
                                                                                                                                                                    NamespaceResolver testResolver = new NamespaceResolver() {
                                                                                                                                                                        @Override
                                                                                                                                                                        protected String getExternallyRegisteredNamespaceURI(String prefix) {
                                                                                                                                                                            return prefix.equals(testPrefix) ? expectedURI : null;
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = testResolver.getNamespaceURI(testPrefix);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals(expectedURI, result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetNamespaceURI_WithNoExternalURIAndPointer() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                    String testPrefix = "test";
                                                                                                                                                                    String expectedURI = "http://example.com";
                                                                                                                                                                    
                                                                                                                                                                    // Mock the pointer to return a URI
                                                                                                                                                                    NodePointer mockPointer = mock(NodePointer.class);
                                                                                                                                                                    when(mockPointer.getNamespaceURI(testPrefix)).thenReturn(expectedURI);
                                                                                                                                                                    resolver.setNamespaceContextPointer(mockPointer);
                                                                                                                                                                    
                                                                                                                                                                    // Create a spy and use reflection to set the externally registered URI to null
                                                                                                                                                                    NamespaceResolver spyResolver = spy(resolver);
                                                                                                                                                                    try {
                                                                                                                                                                        Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                            "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        when(method.invoke(spyResolver, testPrefix)).thenReturn(null);
                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                        fail("Failed to access protected method via reflection: " + e.getMessage());
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = spyResolver.getNamespaceURI(testPrefix);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals(expectedURI, result);
                                                                                                                                                                    verify(mockPointer).getNamespaceURI(testPrefix);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetNamespaceURI_WithNoExternalURIAndNoPointer() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                    String testPrefix = "test";
                                                                                                                                                                    
                                                                                                                                                                    // Create a spy
                                                                                                                                                                    NamespaceResolver spyResolver = spy(resolver);
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to mock the protected method
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    when(method.invoke(spyResolver, testPrefix)).thenReturn(null);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = spyResolver.getNamespaceURI(testPrefix);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetNamespaceURI_WithParentResolver() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver parent = new NamespaceResolver();
                                                                                                                                                                    NamespaceResolver child = new NamespaceResolver(parent);
                                                                                                                                                                    String testPrefix = "test";
                                                                                                                                                                    String expectedURI = "http://parent.com";
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to set up parent's external registration
                                                                                                                                                                    Method parentMethod = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    parentMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Create a spy that will return our expected URI for the parent
                                                                                                                                                                    NamespaceResolver spyParent = spy(parent);
                                                                                                                                                                    when(parentMethod.invoke(spyParent, testPrefix)).thenReturn(expectedURI);
                                                                                                                                                                    
                                                                                                                                                                    // Create child with the spy parent
                                                                                                                                                                    NamespaceResolver childWithSpyParent = new NamespaceResolver(spyParent);
                                                                                                                                                                    
                                                                                                                                                                    // Test - should delegate to parent when child doesn't have the namespace
                                                                                                                                                                    String result = childWithSpyParent.getNamespaceURI(testPrefix);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals(expectedURI, result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetNamespaceURI_WhenSealed() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                    resolver.seal();
                                                                                                                                                                    
                                                                                                                                                                    // Verify behavior when sealed
                                                                                                                                                                    assertTrue(resolver.isSealed());
                                                                                                                                                                    
                                                                                                                                                                    // The sealing shouldn't affect getNamespaceURI functionality
                                                                                                                                                                    // So we can test normal behavior while sealed
                                                                                                                                                                    String testPrefix = "test";
                                                                                                                                                                    String expectedURI = "http://example.com";
                                                                                                                                                                    
                                                                                                                                                                    try {
                                                                                                                                                                        // Use reflection to access the protected method
                                                                                                                                                                        Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                            "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Create a spy and stub the protected method
                                                                                                                                                                        NamespaceResolver spyResolver = spy(resolver);
                                                                                                                                                                        when(method.invoke(spyResolver, testPrefix)).thenReturn(expectedURI);
                                                                                                                                                                        
                                                                                                                                                                        // Test
                                                                                                                                                                        String result = spyResolver.getNamespaceURI(testPrefix);
                                                                                                                                                                        
                                                                                                                                                                        // Verify
                                                                                                                                                                        assertEquals(expectedURI, result);
                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                        fail("Exception occurred while testing: " + e.getMessage());
                                                                                                                                                                    }
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetExternallyRegisteredNamespaceURI_WithLocalMapping() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                    
                                                                                                                                                                    // Access protected namespaceMap field
                                                                                                                                                                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    namespaceMapField.setAccessible(true);
                                                                                                                                                                    Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                                                                    namespaceMap.put("test", "http://example.com");
                                                                                                                                                                    namespaceMapField.set(resolver, namespaceMap);
                                                                                                                                                                    
                                                                                                                                                                    // Access protected method
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(resolver, "test");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("http://example.com", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetExternallyRegisteredNamespaceURI_NoLocalMappingNoParent() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to set the namespaceMap
                                                                                                                                                                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    namespaceMapField.setAccessible(true);
                                                                                                                                                                    namespaceMapField.set(resolver, new HashMap<>());
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to call the protected method
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    String result = (String) method.invoke(resolver, "nonexistent");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetExternallyRegisteredNamespaceURI_NoLocalMappingWithParent() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver parent = new NamespaceResolver();
                                                                                                                                                                    Map<String, String> parentMap = new HashMap<>();
                                                                                                                                                                    parentMap.put("parent", "http://parent.com");
                                                                                                                                                                    
                                                                                                                                                                    // Set parent's namespaceMap using reflection
                                                                                                                                                                    Field parentNamespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    parentNamespaceMapField.setAccessible(true);
                                                                                                                                                                    parentNamespaceMapField.set(parent, parentMap);
                                                                                                                                                                    
                                                                                                                                                                    NamespaceResolver child = new NamespaceResolver(parent);
                                                                                                                                                                    
                                                                                                                                                                    // Set child's empty namespaceMap using reflection
                                                                                                                                                                    Map<String, String> childMap = new HashMap<>();
                                                                                                                                                                    Field childNamespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    childNamespaceMapField.setAccessible(true);
                                                                                                                                                                    childNamespaceMapField.set(child, childMap);
                                                                                                                                                                    
                                                                                                                                                                    // Test - access protected method via reflection
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    String result = (String) method.invoke(child, "parent");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("http://parent.com", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetExternallyRegisteredNamespaceURI_EmptyPrefix() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                    
                                                                                                                                                                    // Get the namespaceMap field using reflection
                                                                                                                                                                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    namespaceMapField.setAccessible(true);
                                                                                                                                                                    Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                                                                    namespaceMap.put("", "http://empty.com");
                                                                                                                                                                    namespaceMapField.set(resolver, namespaceMap);
                                                                                                                                                                    
                                                                                                                                                                    // Get the method using reflection
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(resolver, "");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("http://empty.com", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetExternallyRegisteredNamespaceURI_MultiLevelParent() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver grandParent = new NamespaceResolver();
                                                                                                                                                                    Map<String, String> grandParentMap = new HashMap<>();
                                                                                                                                                                    grandParentMap.put("gp", "http://grandparent.com");
                                                                                                                                                                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    namespaceMapField.setAccessible(true);
                                                                                                                                                                    namespaceMapField.set(grandParent, grandParentMap);
                                                                                                                                                                    
                                                                                                                                                                    NamespaceResolver parent = new NamespaceResolver(grandParent);
                                                                                                                                                                    namespaceMapField.set(parent, new HashMap<>());
                                                                                                                                                                    
                                                                                                                                                                    NamespaceResolver child = new NamespaceResolver(parent);
                                                                                                                                                                    namespaceMapField.set(child, new HashMap<>());
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    String result = (String) method.invoke(child, "gp");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("http://grandparent.com", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetExternallyRegisteredNamespaceURI_ParentHasNullMap() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver parent = new NamespaceResolver();
                                                                                                                                                                    Field parentNamespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    parentNamespaceMapField.setAccessible(true);
                                                                                                                                                                    parentNamespaceMapField.set(parent, null);
                                                                                                                                                                    
                                                                                                                                                                    NamespaceResolver child = new NamespaceResolver(parent);
                                                                                                                                                                    Field childNamespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    childNamespaceMapField.setAccessible(true);
                                                                                                                                                                    childNamespaceMapField.set(child, new HashMap<>());
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    String result = (String) method.invoke(child, "any");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(result);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetExternallyRegisteredNamespaceURI_SealedResolver() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                    
                                                                                                                                                                    // Access protected namespaceMap field
                                                                                                                                                                    Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                    namespaceMapField.setAccessible(true);
                                                                                                                                                                    Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                                                                    namespaceMap.put("test", "http://example.com");
                                                                                                                                                                    namespaceMapField.set(resolver, namespaceMap);
                                                                                                                                                                    
                                                                                                                                                                    resolver.seal();
                                                                                                                                                                    
                                                                                                                                                                    // Access protected method
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = (String) method.invoke(resolver, "test");
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals("http://example.com", result);
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testGetPrefix_ExternallyRegisteredPrefixNull_PointerFindsPrefix() {
                                                                                                                                                                // Setup
                                                                                                                                                                String namespaceURI = "http://example.com";
                                                                                                                                                                String expectedPrefix = "ex";
                                                                                                                                                                NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                NodePointer mockPointer = mock(NodePointer.class);
                                                                                                                                                                
                                                                                                                                                                // Mock external prefix lookup to return null
                                                                                                                                                                NamespaceResolver spyResolver = spy(resolver);
                                                                                                                                                                try {
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    when(method.invoke(spyResolver, namespaceURI)).thenReturn(null);
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    fail("Failed to mock protected method");
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                // Set pointer and mock pointer behavior
                                                                                                                                                                spyResolver.setNamespaceContextPointer(mockPointer);
                                                                                                                                                                try {
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getPrefix", NodePointer.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    when(method.invoke(spyResolver, mockPointer, namespaceURI)).thenReturn(expectedPrefix);
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    fail("Failed to mock protected method");
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                // Test
                                                                                                                                                                String result = spyResolver.getPrefix(namespaceURI);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(expectedPrefix, result);
                                                                                                                                                                try {
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    verify(spyResolver, times(1)).getPrefix(namespaceURI);
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    fail("Failed to verify protected method call");
                                                                                                                                                                }
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSeal_WithMockParentThatThrowsException() {
                                                                                                                                                                // Create mock parent
                                                                                                                                                                NamespaceResolver parent = mock(NamespaceResolver.class);
                                                                                                                                                                doThrow(new RuntimeException("Seal failed")).when(parent).seal();
                                                                                                                                                                
                                                                                                                                                                // Create child resolver
                                                                                                                                                                NamespaceResolver child = new NamespaceResolver(parent);
                                                                                                                                                                
                                                                                                                                                                // Setup expected exception
                                                                                                                                                                ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                expectedException.expect(RuntimeException.class);
                                                                                                                                                                expectedException.expectMessage("Seal failed");
                                                                                                                                                                
                                                                                                                                                                // Trigger the test
                                                                                                                                                                child.seal();
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testClone_WithParentResolver() throws Exception {
                                                                                                                                                                // Arrange
                                                                                                                                                                NamespaceResolver parent = new NamespaceResolver();
                                                                                                                                                                NamespaceResolver original = new NamespaceResolver(parent);
                                                                                                                                                                original.setNamespaceContextPointer(mock(NodePointer.class));
                                                                                                                                                                
                                                                                                                                                                // Act
                                                                                                                                                                NamespaceResolver clone = (NamespaceResolver) original.clone();
                                                                                                                                                                
                                                                                                                                                                // Assert
                                                                                                                                                                assertNotNull(clone);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected parent field
                                                                                                                                                                Field parentField = NamespaceResolver.class.getDeclaredField("parent");
                                                                                                                                                                parentField.setAccessible(true);
                                                                                                                                                                NamespaceResolver cloneParent = (NamespaceResolver) parentField.get(clone);
                                                                                                                                                                
                                                                                                                                                                assertEquals(parent, cloneParent);
                                                                                                                                                                assertSame(original.getNamespaceContextPointer(), clone.getNamespaceContextPointer());
                                                                                                                                                                assertFalse(clone.isSealed());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testGetPrefix_FoundInCurrentPointer() throws Exception {
                                                                                                                                                                // Setup mocks
                                                                                                                                                                NodePointer pointer = mock(NodePointer.class);
                                                                                                                                                                NodeIterator ni = mock(NodeIterator.class);
                                                                                                                                                                NodePointer nsPointer = mock(NodePointer.class);
                                                                                                                                                                
                                                                                                                                                                // Setup mock behavior
                                                                                                                                                                when(pointer.namespaceIterator()).thenReturn(ni);
                                                                                                                                                                when(ni.setPosition(1)).thenReturn(true);
                                                                                                                                                                when(ni.getNodePointer()).thenReturn(nsPointer);
                                                                                                                                                                when(nsPointer.getNamespaceURI()).thenReturn("testURI");
                                                                                                                                                                when(nsPointer.getName()).thenReturn(new QName("testPrefix"));
                                                                                                                                                                
                                                                                                                                                                // Get the protected static method using reflection
                                                                                                                                                                Method getPrefixMethod = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                    "getPrefix", NodePointer.class, String.class);
                                                                                                                                                                getPrefixMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Invoke the method
                                                                                                                                                                String result = (String) getPrefixMethod.invoke(null, pointer, "testURI");
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals("testPrefix", result);
                                                                                                                                                                verify(ni).setPosition(1);
                                                                                                                                                                verify(nsPointer).getNamespaceURI();
                                                                                                                                                                verify(nsPointer).getName();
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testGetPrefix_NullPointer() {
                                                                                                                                                                // Setup
                                                                                                                                                                NodePointer pointer = mock(NodePointer.class);
                                                                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                                                                
                                                                                                                                                                // Setup mock behavior
                                                                                                                                                                when(pointer.namespaceIterator()).thenReturn(null);
                                                                                                                                                                when(pointer.getParent()).thenReturn(null);
                                                                                                                                                                
                                                                                                                                                                // Test
                                                                                                                                                                String result;
                                                                                                                                                                try {
                                                                                                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getPrefix", NodePointer.class, String.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    result = (String) method.invoke(null, pointer, "testURI");
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    throw new RuntimeException(e);
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertNull(result);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testGetNamespaceURI_WithExternalURITakesPrecedence() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                String testPrefix = "test";
                                                                                                                                                                String expectedURI = "http://external.com";
                                                                                                                                                                String pointerURI = "http://pointer.com";
                                                                                                                                                                
                                                                                                                                                                // Mock the pointer
                                                                                                                                                                NodePointer mockPointer = mock(NodePointer.class);
                                                                                                                                                                when(mockPointer.getNamespaceURI(testPrefix)).thenReturn(pointerURI);
                                                                                                                                                                resolver.setNamespaceContextPointer(mockPointer);
                                                                                                                                                                
                                                                                                                                                                // Register the namespace directly since we can't access the protected method
                                                                                                                                                                resolver.registerNamespace(testPrefix, expectedURI);
                                                                                                                                                                
                                                                                                                                                                // Test
                                                                                                                                                                String result = resolver.getNamespaceURI(testPrefix);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(expectedURI, result);
                                                                                                                                                                verify(mockPointer, never()).getNamespaceURI(testPrefix);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testGetExternallyRegisteredNamespaceURI_NullPrefix() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected namespaceMap
                                                                                                                                                                Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                namespaceMapField.setAccessible(true);
                                                                                                                                                                namespaceMapField.set(resolver, new HashMap<String, String>());
                                                                                                                                                                
                                                                                                                                                                // Setup expected exception
                                                                                                                                                                ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                expectedException.expect(NullPointerException.class);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to call protected method
                                                                                                                                                                Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredNamespaceURI", String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                method.invoke(resolver, (String)null);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testGetPrefix_ExternallyRegisteredPrefixExists() {
                                                                                                                                                                // Setup
                                                                                                                                                                String namespaceURI = "http://example.com";
                                                                                                                                                                String expectedPrefix = "ex";
                                                                                                                                                                
                                                                                                                                                                // Create resolver instance
                                                                                                                                                                NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                                
                                                                                                                                                                // Mock external prefix lookup using reflection since the method is protected
                                                                                                                                                                try {
                                                                                                                                                                    Method getExternallyRegisteredPrefixMethod = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                        "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                    getExternallyRegisteredPrefixMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Create spy
                                                                                                                                                                    NamespaceResolver spyResolver = spy(resolver);
                                                                                                                                                                    
                                                                                                                                                                    // Mock the protected method
                                                                                                                                                                    when(getExternallyRegisteredPrefixMethod.invoke(spyResolver, namespaceURI))
                                                                                                                                                                        .thenReturn(expectedPrefix);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    String result = spyResolver.getPrefix(namespaceURI);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals(expectedPrefix, result);
                                                                                                                                                                    verify(spyResolver, times(1)).getPrefix(namespaceURI);
                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                    fail("Exception occurred during test: " + e.getMessage());
                                                                                                                                                                }
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testGetPrefix_PointerNull_PrefixExistsExternally() {
                                                                                                                                                            // Setup
                                                                                                                                                            String namespaceURI = "http://example.com";
                                                                                                                                                            String expectedPrefix = "ex";
                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                            
                                                                                                                                                            // Mock external prefix lookup
                                                                                                                                                            NamespaceResolver spyResolver = spy(resolver);
                                                                                                                                                            try {
                                                                                                                                                                Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                    "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                when(method.invoke(spyResolver, namespaceURI)).thenReturn(expectedPrefix);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to mock protected method");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            String result = spyResolver.getPrefix(namespaceURI);
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertEquals(expectedPrefix, result);
                                                                                                                                                            try {
                                                                                                                                                                Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                    "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                verify(spyResolver, times(1)).getPrefix(namespaceURI);
                                                                                                                                                                // Verify the protected method was called through reflection
                                                                                                                                                                method.invoke(spyResolver, namespaceURI);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to verify protected method");
                                                                                                                                                            }
                                                                                                                                                            // Remove incorrect verification of getPrefix with NodePointer parameter
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetExternallyRegisteredPrefix_WhenReverseMapIsNull_InitializesReverseMap() {
                                                                                                                                                            // Given
                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                            Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                                                            namespaceMap.put("prefix1", "uri1");
                                                                                                                                                            namespaceMap.put("prefix2", "uri2");
                                                                                                                                                            
                                                                                                                                                            try {
                                                                                                                                                                Field field = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                field.set(resolver, namespaceMap);
                                                                                                                                                                
                                                                                                                                                                Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                                                                reverseMapField.set(resolver, null);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // When
                                                                                                                                                            String result = null;
                                                                                                                                                            try {
                                                                                                                                                                Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                result = (String) method.invoke(resolver, "uri1");
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to invoke getExternallyRegisteredPrefix: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Then
                                                                                                                                                            try {
                                                                                                                                                                Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                                                                Map<String, String> reverseMap = (Map<String, String>) reverseMapField.get(resolver);
                                                                                                                                                                
                                                                                                                                                                assertNotNull(reverseMap);
                                                                                                                                                                assertEquals("prefix1", result);
                                                                                                                                                                assertEquals(2, reverseMap.size());
                                                                                                                                                                assertEquals("prefix1", reverseMap.get("uri1"));
                                                                                                                                                                assertEquals("prefix2", reverseMap.get("uri2"));
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to verify test due to reflection error: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetExternallyRegisteredPrefix_WhenNamespaceURIIsFoundInReverseMap_ReturnsPrefix() {
                                                                                                                                                            // Given
                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                            Map<String, String> reverseMap = new HashMap<>();
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access the private reverseMap field
                                                                                                                                                            try {
                                                                                                                                                                Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                                                                reverseMapField.set(resolver, reverseMap);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to set reverseMap field via reflection");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            reverseMap.put("uri1", "prefix1");
                                                                                                                                                            reverseMap.put("uri2", "prefix2");
                                                                                                                                                            
                                                                                                                                                            // When
                                                                                                                                                            String result = null;
                                                                                                                                                            try {
                                                                                                                                                                Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                    "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                result = (String) method.invoke(resolver, "uri1");
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to invoke getExternallyRegisteredPrefix via reflection");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Then
                                                                                                                                                            assertEquals("prefix1", result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetExternallyRegisteredPrefix_WhenNamespaceURIIsNotFoundAndParentIsNull_ReturnsNull() {
                                                                                                                                                            // Given
                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver(null); // No parent resolver
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access the private reverseMap field
                                                                                                                                                            try {
                                                                                                                                                                Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                                                                Map<String, String> reverseMap = (Map<String, String>) reverseMapField.get(resolver);
                                                                                                                                                                reverseMap.put("uri1", "prefix1");
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to access reverseMap field: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // When
                                                                                                                                                            String result = null;
                                                                                                                                                            try {
                                                                                                                                                                Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                    "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                result = (String) method.invoke(resolver, "unknownURI");
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to invoke getExternallyRegisteredPrefix: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Then
                                                                                                                                                            assertNull(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetExternallyRegisteredPrefix_WhenNamespaceMapIsEmpty_ReturnsNull() {
                                                                                                                                                            // Given
                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                            Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                                                            
                                                                                                                                                            try {
                                                                                                                                                                // Use reflection to access private fields
                                                                                                                                                                Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                                namespaceMapField.setAccessible(true);
                                                                                                                                                                namespaceMapField.set(resolver, namespaceMap);
                                                                                                                                                                
                                                                                                                                                                Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                                                                reverseMapField.set(resolver, null);
                                                                                                                                                                
                                                                                                                                                                // When - use reflection to call protected method
                                                                                                                                                                Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                    "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                String result = (String) method.invoke(resolver, "anyURI");
                                                                                                                                                                
                                                                                                                                                                // Then
                                                                                                                                                                assertNull(result);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to execute test due to reflection error: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetExternallyRegisteredPrefix_WhenNamespaceURIisNull_ReturnsNull() {
                                                                                                                                                            // Given
                                                                                                                                                            // Create a test subclass that exposes the protected method
                                                                                                                                                            class TestNamespaceResolver extends NamespaceResolver {
                                                                                                                                                                public String testGetExternallyRegisteredPrefix(String namespaceURI) {
                                                                                                                                                                    return super.getExternallyRegisteredPrefix(namespaceURI);
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            TestNamespaceResolver resolver = new TestNamespaceResolver();
                                                                                                                                                            Map<String, String> reverseMap = new HashMap<>();
                                                                                                                                                            reverseMap.put("uri1", "prefix1");
                                                                                                                                                            
                                                                                                                                                            // Use reflection to set the reverseMap field since it's protected
                                                                                                                                                            try {
                                                                                                                                                                Field field = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                field.set(resolver, reverseMap);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to set reverseMap field via reflection");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // When
                                                                                                                                                            String result = resolver.testGetExternallyRegisteredPrefix(null);
                                                                                                                                                            
                                                                                                                                                            // Then
                                                                                                                                                            assertNull(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetExternallyRegisteredPrefix_WhenReverseMapInitializationIsThreadSafe() throws Exception {
                                                                                                                                                            // Given
                                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                            Map<String, String> namespaceMap = new HashMap<>();
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access private fields
                                                                                                                                                            Field namespaceMapField = NamespaceResolver.class.getDeclaredField("namespaceMap");
                                                                                                                                                            namespaceMapField.setAccessible(true);
                                                                                                                                                            namespaceMapField.set(resolver, namespaceMap);
                                                                                                                                                            
                                                                                                                                                            Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                                                            reverseMapField.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            namespaceMap.put("prefix1", "uri1");
                                                                                                                                                            namespaceMap.put("prefix2", "uri2");
                                                                                                                                                            reverseMapField.set(resolver, null);
                                                                                                                                                            
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Method getExternallyRegisteredPrefixMethod = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                "getExternallyRegisteredPrefix", String.class);
                                                                                                                                                            getExternallyRegisteredPrefixMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // When called multiple times
                                                                                                                                                            String result1 = (String) getExternallyRegisteredPrefixMethod.invoke(resolver, "uri1");
                                                                                                                                                            String result2 = (String) getExternallyRegisteredPrefixMethod.invoke(resolver, "uri2");
                                                                                                                                                            
                                                                                                                                                            // Then
                                                                                                                                                            assertEquals("prefix1", result1);
                                                                                                                                                            assertEquals("prefix2", result2);
                                                                                                                                                            assertEquals(2, ((Map<?, ?>) reverseMapField.get(resolver)).size());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetPrefix_FoundInParentPointer() throws Exception {
                                                                                                                                                            // Create mocks
                                                                                                                                                            NodePointer pointer = mock(NodePointer.class);
                                                                                                                                                            NodeIterator ni = mock(NodeIterator.class);
                                                                                                                                                            NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                            
                                                                                                                                                            // Setup mock behavior - current pointer doesn't have the namespace
                                                                                                                                                            when(pointer.namespaceIterator()).thenReturn(ni);
                                                                                                                                                            when(ni.setPosition(1)).thenReturn(false);
                                                                                                                                                            when(pointer.getParent()).thenReturn(parentPointer);
                                                                                                                                                            
                                                                                                                                                            // Parent pointer has the namespace
                                                                                                                                                            NodeIterator parentNi = mock(NodeIterator.class);
                                                                                                                                                            NodePointer parentNsPointer = mock(NodePointer.class);
                                                                                                                                                            when(parentPointer.namespaceIterator()).thenReturn(parentNi);
                                                                                                                                                            when(parentNi.setPosition(1)).thenReturn(true);
                                                                                                                                                            when(parentNi.getNodePointer()).thenReturn(parentNsPointer);
                                                                                                                                                            when(parentNsPointer.getNamespaceURI()).thenReturn("testURI");
                                                                                                                                                            when(parentNsPointer.getName()).thenReturn(new QName("parentPrefix"));
                                                                                                                                                            
                                                                                                                                                            // Get the protected method via reflection
                                                                                                                                                            Method getPrefixMethod = NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                                                "getPrefix", NodePointer.class, String.class);
                                                                                                                                                            getPrefixMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Invoke the method
                                                                                                                                                            String result = (String) getPrefixMethod.invoke(null, pointer, "testURI");
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertEquals("parentPrefix", result);
                                                                                                                                                            verify(pointer).getParent();
                                                                                                                                                            verify(parentNi).setPosition(1);
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testGetPrefix_PointerNull_NoPrefixExists() {
                                                                                                                                                        // Setup
                                                                                                                                                        String namespaceURI = "http://example.com";
                                                                                                                                                        NamespaceResolver resolver = new NamespaceResolver();
                                                                                                                                                        
                                                                                                                                                        // Mock external prefix lookup to return null
                                                                                                                                                        NamespaceResolver spyResolver = spy(resolver);
                                                                                                                                                        try {
                                                                                                                                                            Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                            when(method.invoke(spyResolver, namespaceURI)).thenReturn(null);
                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                            fail("Failed to mock protected method");
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        // Ensure pointer is null (default state)
                                                                                                                                                        spyResolver.setNamespaceContextPointer(null);
                                                                                                                                                        
                                                                                                                                                        // Test
                                                                                                                                                        String result = spyResolver.getPrefix(namespaceURI);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertNull(result);
                                                                                                                                                        try {
                                                                                                                                                            verify(spyResolver, times(1)).getPrefix(namespaceURI);
                                                                                                                                                            // Remove verification of protected static method as it's not accessible through spy
                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                            fail("Verification failed");
                                                                                                                                                        }
                                                                                                                                                    }

    @Test
                                                                                                                                        public void testGetExternallyRegisteredPrefix_WhenNamespaceURIIsNotFoundAndParentExists_DelegatesToParent() {
                                                                                                                                            // Given
                                                                                                                                            NamespaceResolver parentResolver = mock(NamespaceResolver.class);
                                                                                                                                            NamespaceResolver resolver = new NamespaceResolver(parentResolver);
                                                                                                                                            
                                                                                                                                            // Access the private reverseMap field using reflection
                                                                                                                                            Map<String, String> reverseMap;
                                                                                                                                            try {
                                                                                                                                                Field reverseMapField = NamespaceResolver.class.getDeclaredField("reverseMap");
                                                                                                                                                reverseMapField.setAccessible(true);
                                                                                                                                                reverseMap = (Map<String, String>) reverseMapField.get(resolver);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                throw new RuntimeException("Failed to access reverseMap field", e);
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Mock parent resolver behavior
                                                                                                                                            try {
                                                                                                                                                Method parentMethod = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                                                                                                                                                parentMethod.setAccessible(true);
                                                                                                                                                when(parentMethod.invoke(parentResolver, "unknownURI")).thenReturn("parentPrefix");
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                throw new RuntimeException("Failed to mock parent resolver", e);
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            reverseMap.put("uri1", "prefix1");
                                                                                                                                            
                                                                                                                                            // Access the protected method using reflection
                                                                                                                                            try {
                                                                                                                                                Method method = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                                                                                                                                                method.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // When
                                                                                                                                                String result = (String) method.invoke(resolver, "unknownURI");
                                                                                                                                                
                                                                                                                                                // Then
                                                                                                                                                assertEquals("parentPrefix", result);
                                                                                                                                                
                                                                                                                                                // Verify parent was called
                                                                                                                                                try {
                                                                                                                                                    Method verifyMethod = NamespaceResolver.class.getDeclaredMethod("getExternallyRegisteredPrefix", String.class);
                                                                                                                                                    verifyMethod.setAccessible(true);
                                                                                                                                                    verifyMethod.invoke(verify(parentResolver, times(1)), "unknownURI");
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    throw new RuntimeException("Failed to verify parent call", e);
                                                                                                                                                }
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                throw new RuntimeException("Failed to invoke getExternallyRegisteredPrefix method", e);
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                            public void testGetPrefix_NullNamespaceURI() {
                                                                                                                                // Define required classes/interfaces within the test method
                                                                                                                                class QName {}
                                                                                                                                class NodeTest {}
                                                                                                                                class NodeIterator {}
                                                                                                                                class JXPathContext {}
                                                                                                                                
                                                                                                                                NamespaceResolver namespaceResolver = new NamespaceResolver();
                                                                                                                                Object pointer = new Object() {
                                                                                                                                    public int compareChildNodePointers(Object pointer1, Object pointer2) {
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public NodeIterator childIterator(NodeTest test, boolean reverse, Object startWith) {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public NodeIterator attributeIterator(QName name) {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public void setValue(Object value) {
                                                                                                                                        // Empty implementation
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public QName getName() {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public Object getBaseValue() {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public boolean isCollection() {
                                                                                                                                        return false;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public int getLength() {
                                                                                                                                        return 0;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public Object getImmediateNode() {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public boolean isLeaf() {
                                                                                                                                        return false;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public boolean testNode(NodeTest test) {
                                                                                                                                        return false;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public Object createChild(JXPathContext context, QName name, int index) {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public Object createAttribute(JXPathContext context, QName name) {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    public String asPath() {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                };
                                                                                                                                
                                                                                                                                // Use reflection to set the namespace context pointer since we can't access NodePointer directly
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Method method = NamespaceResolver.class.getMethod(
                                                                                                                                        "setNamespaceContextPointer", Object.class);
                                                                                                                                    method.invoke(namespaceResolver, pointer);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    throw new RuntimeException(e);
                                                                                                                                }
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    namespaceResolver.getPrefix(null);
                                                                                                                                    fail("Expected NullPointerException");
                                                                                                                                } catch (NullPointerException e) {
                                                                                                                                    // Expected exception
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                        public void testGetPrefix_EmptyPrefix() {
                                                                                                                            // Create mock objects
                                                                                                                            org.apache.commons.jxpath.ri.model.NodePointer pointer = null; // Initialize with null or mock
                                                                                                                            org.apache.commons.jxpath.ri.model.NodePointer parentPointer = null; // Initialize with null or mock
                                                                                                                            
                                                                                                                            // Setup mock behavior
                                                                                                                            // Should continue searching
                                                                                                                            
                                                                                                                            // Create namespace resolver
                                                                                                                            org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = new org.apache.commons.jxpath.ri.NamespaceResolver();
                                                                                                                            namespaceResolver.setNamespaceContextPointer(pointer);
                                                                                                                            
                                                                                                                            // Test using reflection to access protected method
                                                                                                                            try {
                                                                                                                                java.lang.reflect.Method method = org.apache.commons.jxpath.ri.NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                    "getPrefix", 
                                                                                                                                    org.apache.commons.jxpath.ri.model.NodePointer.class, 
                                                                                                                                    String.class);
                                                                                                                                method.setAccessible(true);
                                                                                                                                String result = (String) method.invoke(namespaceResolver, pointer, "testURI");
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                org.junit.Assert.assertEquals("validPrefix", result);
                                                                                                                            } catch (Exception e) {
                                                                                                                                org.junit.Assert.fail("Failed to invoke protected method: " + e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                        public void testGetPrefix_NotFound() {
                                                                                                                            // Setup mocks
                                                                                                                            org.apache.commons.jxpath.ri.model.NodePointer pointer = null; // Initialize pointer
                                                                                                                            
                                                                                                                            // Create NamespaceResolver instance
                                                                                                                            org.apache.commons.jxpath.ri.NamespaceResolver resolver = new org.apache.commons.jxpath.ri.NamespaceResolver();
                                                                                                                            
                                                                                                                            // Test the protected method using reflection
                                                                                                                            try {
                                                                                                                                java.lang.reflect.Method method = org.apache.commons.jxpath.ri.NamespaceResolver.class.getDeclaredMethod(
                                                                                                                                    "getPrefix", 
                                                                                                                                    org.apache.commons.jxpath.ri.model.NodePointer.class, 
                                                                                                                                    String.class
                                                                                                                                );
                                                                                                                                method.setAccessible(true);
                                                                                                                                String result = (String) method.invoke(resolver, pointer, "nonExistingURI");
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                org.junit.Assert.assertNull(result);
                                                                                                                            } catch (Exception e) {
                                                                                                                                org.junit.Assert.fail("Failed to invoke protected method: " + e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                            public void testGetPrefix_NoPrefixFoundAnywhere() {
                                                                                // Setup
                                                                                String namespaceURI = "http://example.com";
                                                                                NamespaceResolver resolver = new NamespaceResolver();
                                                                                NodePointer mockPointer = mock(NodePointer.class);
                                                                                
                                                                                // Create spy
                                                                                NamespaceResolver spyResolver = spy(resolver);
                                                                                
                                                                                // Mock protected method
                                                                                try {
                                                                                    Method method = NamespaceResolver.class.getDeclaredMethod(
                                                                                        "getExternallyRegisteredPrefix", String.class);
                                                                                    method.setAccessible(true);
                                                                                    when(method.invoke(spyResolver, namespaceURI)).thenReturn(null);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to access protected method");
                                                                                }
                                                                                
                                                                                // Mock static method behavior
                                                                                try {
                                                                                    Method staticMethod = NamespaceResolver.class.getDeclaredMethod(
                                                                                        "getPrefix", NodePointer.class, String.class);
                                                                                    staticMethod.setAccessible(true);
                                                                                    when(staticMethod.invoke(null, mockPointer, namespaceURI)).thenReturn(null);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to mock static method");
                                                                                }
                                                                                
                                                                                // Set pointer
                                                                                spyResolver.setNamespaceContextPointer(mockPointer);
                                                                                
                                                                                // Test
                                                                                String result = spyResolver.getPrefix(namespaceURI);
                                                                                
                                                                                // Verify
                                                                                assertNull(result);
                                                                                verify(spyResolver, times(1)).getPrefix(namespaceURI);
                                                                            }

    @Test
    public void testGetPrefix_NullNamespaceURI1() {
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver = 
            new org.apache.commons.jxpath.ri.NamespaceResolver();
        org.apache.commons.jxpath.ri.model.NodePointer pointer = 
            new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(null, null, null) {
                @Override
                public int compareChildNodePointers(
                    org.apache.commons.jxpath.ri.model.NodePointer pointer1, 
                    org.apache.commons.jxpath.ri.model.NodePointer pointer2) {
                    return 0;
                }
                
                public org.apache.commons.jxpath.ri.model.NodeIterator childIterator(
                    org.apache.commons.jxpath.ri.QName name, 
                    org.apache.commons.jxpath.Pointer pointer, 
                    boolean reverse, 
                    org.apache.commons.jxpath.ri.model.NodePointer startWith) {
                    return null;
                }
                
                @Override
                public org.apache.commons.jxpath.ri.model.NodeIterator attributeIterator(
                    org.apache.commons.jxpath.ri.QName name) {
                    return null;
                }
                
                @Override
                public void setValue(Object value) {
                    // Empty implementation
                }
                
                @Override
                public org.apache.commons.jxpath.ri.QName getName() {
                    return null;
                }
                
                @Override
                public Object getBaseValue() {
                    return null;
                }
                
                @Override
                public boolean isCollection() {
                    return false;
                }
                
                @Override
                public int getLength() {
                    return 0;
                }
                
                @Override
                public Object getImmediateNode() {
                    return null;
                }
                
                @Override
                public boolean isLeaf() {
                    return false;
                }
                
                @Override
                public String getNamespaceURI() {
                    return null;
                }
                
                @Override
                public String getNamespaceURI(String prefix) {
                    return null;
                }
                
                @Override
                public String asPath() {
                    return "";
                }
            };
        
        try {
            // Using reflection to access protected method
            java.lang.reflect.Method method = org.apache.commons.jxpath.ri.NamespaceResolver.class
                .getDeclaredMethod("getPrefix", 
                    org.apache.commons.jxpath.ri.model.NodePointer.class, 
                    String.class);
            method.setAccessible(true);
            method.invoke(namespaceResolver, pointer, (String)null);
            fail("Expected NullPointerException");
        } catch (java.lang.reflect.InvocationTargetException e) {
            if (!(e.getCause() instanceof NullPointerException)) {
                fail("Expected NullPointerException but got: " + e.getCause().getClass().getName());
            }
        } catch (Exception e) {
            fail("Unexpected exception: " + e.getClass().getName());
        }
    }

    @Test
    public void testGetPrefix_MultipleNamespaces() throws Exception {
        // Create manual mock objects
{
            
            @Override
{
            }
            
            @Override
{
            }
            
            public void setParent(org.apache.commons.jxpath.ri.model.NodePointer parent) {
                this.parent = parent;
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
            public void setValue(Object value) {
                // Empty implementation for test
            }
        };
        
{
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
{
            }
            
            @Override
            public void setValue(Object value) {
                // Empty implementation for test
            }
            
            @Override
{
            }
        };
        
        // Setup namespaces
        
        // Setup parent/child relationships
{
            
            // Verify
}{
            org.junit.Assert.fail("Failed to invoke protected static getPrefix method: " + e.getMessage());
        }
    }


}
