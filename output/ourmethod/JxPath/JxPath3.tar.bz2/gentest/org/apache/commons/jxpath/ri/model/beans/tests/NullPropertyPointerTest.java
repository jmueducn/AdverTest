package gentest.org.apache.commons.jxpath.ri.model.beans.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.beans.*;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathInvalidAccessException;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.model.NodePointer;
 
public class NullPropertyPointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                                                                                              public void testCreatePath_WhenPropertyNameIsNull_HandlesNullName() {
                                                                                                                                                                                  // Setup
                                                                                                                                                                                  JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                                  NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                                  NodePointer newParent = mock(NodePointer.class);
                                                                                                                                                                                  NodePointer expectedResult = mock(NodePointer.class);
                                                                                                                                                                                  
                                                                                                                                                                                  NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                                                  pointer.setPropertyName(null);
                                                                                                                                                                                  
                                                                                                                                                                                  // Mock isAttribute() to return false and newParent is not PropertyOwnerPointer
                                                                                                                                                                                  when(parent.createPath(context)).thenReturn(newParent);
                                                                                                                                                                                  when(newParent.createChild(context, null, 0)).thenReturn(expectedResult);
                                                                                                                                                                                  
                                                                                                                                                                                  // Execute
                                                                                                                                                                                  NodePointer result = pointer.createPath(context);
                                                                                                                                                                                  
                                                                                                                                                                                  // Verify
                                                                                                                                                                                  assertEquals(expectedResult, result);
                                                                                                                                                                                  verify(newParent).createChild(context, null, 0);
                                                                                                                                                                              }

 @Test
                                                                                                                                                                      public void testCreatePath_WhenIsAttribute_CreatesAttribute() {
                                                                                                                                                                          // Setup
                                                                                                                                                                          JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                          NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                          NodePointer newParent = mock(NodePointer.class);
                                                                                                                                                                          NodePointer expectedResult = mock(NodePointer.class);
                                                                                                                                                                          
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                                          QName propertyName = new QName("testAttr");
                                                                                                                                                                          pointer.setPropertyName(propertyName.toString());
                                                                                                                                                                          
                                                                                                                                                                          // Mock isAttribute() to return true
                                                                                                                                                                          when(parent.createPath(context)).thenReturn(newParent);
                                                                                                                                                                          when(newParent.createAttribute(context, propertyName)).thenReturn(expectedResult);
                                                                                                                                                                          
                                                                                                                                                                          // Execute
                                                                                                                                                                          NodePointer result = pointer.createPath(context);
                                                                                                                                                                          
                                                                                                                                                                          // Verify
                                                                                                                                                                          assertEquals(expectedResult, result);
                                                                                                                                                                          verify(parent).createPath(context);
                                                                                                                                                                          verify(newParent).createAttribute(context, propertyName);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testCreatePath_WhenNewParentIsPropertyOwnerPointer_CreatesPropertyPointer() {
                                                                                                                                                                          // Setup
                                                                                                                                                                          JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                          NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                          PropertyOwnerPointer pop = mock(PropertyOwnerPointer.class);
                                                                                                                                                                          PropertyPointer propertyPointer = mock(PropertyPointer.class);
                                                                                                                                                                          NodePointer expectedResult = mock(NodePointer.class);
                                                                                                                                                                          
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                                          pointer.setPropertyName("testProp");
                                                                                                                                                                          pointer.setPropertyIndex(1);
                                                                                                                                                                          
                                                                                                                                                                          // Create QName for the property
                                                                                                                                                                          QName testPropQName = new QName(null, "testProp");
                                                                                                                                                                          
                                                                                                                                                                          // Mock behavior
                                                                                                                                                                          when(parent.createPath(context)).thenReturn(pop);
                                                                                                                                                                          when(pop.getPropertyPointer()).thenReturn(propertyPointer);
                                                                                                                                                                          when(propertyPointer.createChild(context, testPropQName, 1)).thenReturn(expectedResult);
                                                                                                                                                                          
                                                                                                                                                                          // Execute
                                                                                                                                                                          NodePointer result = pointer.createPath(context);
                                                                                                                                                                          
                                                                                                                                                                          // Verify
                                                                                                                                                                          assertEquals(expectedResult, result);
                                                                                                                                                                          verify(parent).createPath(context);
                                                                                                                                                                          verify(pop).getPropertyPointer();
                                                                                                                                                                          verify(propertyPointer).createChild(context, testPropQName, 1);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testCreatePath_AttributeCreation() {
                                                                                                                                                                          // Setup
                                                                                                                                                                          JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                          NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                          NodePointer newParent = mock(NodePointer.class);
                                                                                                                                                                          NodePointer attributePointer = mock(NodePointer.class);
                                                                                                                                                                          
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                                          pointer.setPropertyName("testAttr");
                                                                                                                                                                          pointer.setValue("testValue");
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to set private byNameAttribute field
                                                                                                                                                                          try {
                                                                                                                                                                              Field byNameAttributeField = NullPropertyPointer.class.getDeclaredField("byNameAttribute");
                                                                                                                                                                              byNameAttributeField.setAccessible(true);
                                                                                                                                                                              byNameAttributeField.setBoolean(pointer, true);
                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                              fail("Failed to set byNameAttribute field via reflection");
                                                                                                                                                                          }
                                                                                                                                                                      
                                                                                                                                                                          QName testAttrQName = new QName("testAttr");
                                                                                                                                                                          
                                                                                                                                                                          when(parent.createPath(context)).thenReturn(newParent);
                                                                                                                                                                          when(newParent.createAttribute(context, testAttrQName)).thenReturn(attributePointer);
                                                                                                                                                                      
                                                                                                                                                                          // Execute
                                                                                                                                                                          NodePointer result = pointer.createPath(context);
                                                                                                                                                                      
                                                                                                                                                                          // Verify
                                                                                                                                                                          assertEquals(attributePointer, result);
                                                                                                                                                                          verify(attributePointer).setValue("testValue");
                                                                                                                                                                          verify(newParent).createAttribute(context, testAttrQName);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testCreatePath_NormalPathCreation() {
                                                                                                                                                                          // Setup
                                                                                                                                                                          JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                          NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                          NodePointer newParent = mock(NodePointer.class);
                                                                                                                                                                          NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                          
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                                          pointer.setPropertyName("testProperty");
                                                                                                                                                                          pointer.setValue("testValue");
                                                                                                                                                                      
                                                                                                                                                                          QName propertyQName = new QName("testProperty");
                                                                                                                                                                          
                                                                                                                                                                          when(parent.createPath(context)).thenReturn(newParent);
                                                                                                                                                                          when(newParent.createChild(context, propertyQName, -1, "testValue")).thenReturn(childPointer);
                                                                                                                                                                      
                                                                                                                                                                          // Execute
                                                                                                                                                                          NodePointer result = pointer.createPath(context);
                                                                                                                                                                      
                                                                                                                                                                          // Verify
                                                                                                                                                                          assertEquals(childPointer, result);
                                                                                                                                                                          verify(newParent).createChild(context, propertyQName, -1, "testValue");
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testCreatePath_WithIndex() {
                                                                                                                                                                          // Setup
                                                                                                                                                                          JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                          NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                          NodePointer newParent = mock(NodePointer.class);
                                                                                                                                                                          NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                                          
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                                          pointer.setPropertyName("testProperty");
                                                                                                                                                                          pointer.setValue("testValue");
                                                                                                                                                                          pointer.setPropertyIndex(2); // Set index
                                                                                                                                                                      
                                                                                                                                                                          QName propertyQName = new QName("testProperty");
                                                                                                                                                                          
                                                                                                                                                                          when(parent.createPath(context)).thenReturn(newParent);
                                                                                                                                                                          when(newParent.createChild(context, propertyQName, 2, "testValue")).thenReturn(childPointer);
                                                                                                                                                                      
                                                                                                                                                                          // Execute
                                                                                                                                                                          NodePointer result = pointer.createPath(context);
                                                                                                                                                                      
                                                                                                                                                                          // Verify
                                                                                                                                                                          assertEquals(childPointer, result);
                                                                                                                                                                          verify(newParent).createChild(context, propertyQName, 2, "testValue");
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_NoQuotes() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "This is a test string without quotes";
                                                                                                                                                                          String expected = "This is a test string without quotes";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Invoke the method
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_SingleQuoteOnly() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "This is a 'test' string";
                                                                                                                                                                          String expected = "This is a &apos;test&apos; string";
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to access private escape method
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_DoubleQuoteOnly() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "This is a \"test\" string";
                                                                                                                                                                          String expected = "This is a &quot;test&quot; string";
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to access private method
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_MixedQuotes() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "This is a \'test\' with \"mixed\" quotes";
                                                                                                                                                                          String expected = "This is a &apos;test&apos; with &quot;mixed&quot; quotes";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Invoke the method
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_MultipleQuotes() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "'Multiple' 'single' \"quotes\" \"here\"";
                                                                                                                                                                          String expected = "&apos;Multiple&apos; &apos;single&apos; &quot;quotes&quot; &quot;here&quot;";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_EmptyString() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "";
                                                                                                                                                                          String expected = "";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Invoke the method
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_OnlySingleQuote() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "'";
                                                                                                                                                                          String expected = "&apos;";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Invoke the method on our pointer instance
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_OnlyDoubleQuote() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "\"";
                                                                                                                                                                          String expected = "&quot;";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Invoke the method on our pointer instance
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_AdjacentQuotes() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "\'\"\'\"";
                                                                                                                                                                          String expected = "&apos;&quot;&apos;&quot;";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Invoke the method on our pointer instance
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test(expected = NullPointerException.class)
                                                                                                                                                                      public void testEscape_NullInput() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          escapeMethod.invoke(pointer, (String) null);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_QuotesAtStartAndEnd() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "'start' middle \"end\"";
                                                                                                                                                                          String expected = "&apos;start&apos; middle &quot;end&quot;";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Invoke the method on our pointer instance
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testEscape_WithSpecialCharacters() throws Exception {
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          String input = "Special chars: \\n\\t\\r\'quote\'";
                                                                                                                                                                          String expected = "Special chars: \\n\\t\\r&apos;quote&apos;";
                                                                                                                                                                          
                                                                                                                                                                          // Get the private escape method using reflection
                                                                                                                                                                          Method escapeMethod = NullPropertyPointer.class.getDeclaredMethod("escape", String.class);
                                                                                                                                                                          escapeMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Invoke the method
                                                                                                                                                                          String result = (String) escapeMethod.invoke(pointer, input);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(expected, result);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testCreateBadFactoryException_WithEmptyPath() throws Exception {
                                                                                                                                                                          // Setup
                                                                                                                                                                          AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          
                                                                                                                                                                          when(mockFactory.toString()).thenReturn("EmptyPathFactory");
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to access private asPath() method
                                                                                                                                                                          Method asPathMethod = NullPropertyPointer.class.getDeclaredMethod("asPath");
                                                                                                                                                                          asPathMethod.setAccessible(true);
                                                                                                                                                                          when(asPathMethod.invoke(pointer)).thenReturn("");
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to access private createBadFactoryException method
                                                                                                                                                                          Method createBadFactoryExceptionMethod = NullPropertyPointer.class.getDeclaredMethod("createBadFactoryException", AbstractFactory.class);
                                                                                                                                                                          createBadFactoryExceptionMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Execute
                                                                                                                                                                          JXPathAbstractFactoryException exception = (JXPathAbstractFactoryException) 
                                                                                                                                                                              createBadFactoryExceptionMethod.invoke(pointer, mockFactory);
                                                                                                                                                                          
                                                                                                                                                                          // Verify
                                                                                                                                                                          String expectedMessage = "Factory EmptyPathFactory reported success creating object for path:  but object was null.  Terminating to avoid stack recursion.";
                                                                                                                                                                          assertEquals(expectedMessage, exception.getMessage());
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testCreateBadFactoryException_VerifyExceptionType() throws Exception {
                                                                                                                                                                          // Setup
                                                                                                                                                                          AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                          
                                                                                                                                                                          when(mockFactory.toString()).thenReturn("TypeCheckFactory");
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to access private method
                                                                                                                                                                          Method createBadFactoryException = NullPropertyPointer.class.getDeclaredMethod(
                                                                                                                                                                              "createBadFactoryException", AbstractFactory.class);
                                                                                                                                                                          createBadFactoryException.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Execute
                                                                                                                                                                          JXPathAbstractFactoryException exception = (JXPathAbstractFactoryException) 
                                                                                                                                                                              createBadFactoryException.invoke(pointer, mockFactory);
                                                                                                                                                                          
                                                                                                                                                                          // Verify
                                                                                                                                                                          assertTrue(exception instanceof JXPathAbstractFactoryException);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                  public void testCreatePath_WhenParentIsNullPointerAndEqualsNewParent_ThrowsException() {
                                                                                                                                                                      // Setup
                                                                                                                                                                      JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                      AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                                                                      NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                      when(context.getFactory()).thenReturn(factory);
                                                                                                                                                                      
                                                                                                                                                                      NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                                      pointer.setPropertyName("test");
                                                                                                                                                                      
                                                                                                                                                                      // Expect exception
                                                                                                                                                                      ExpectedException exception = ExpectedException.none();
                                                                                                                                                                      exception.expect(JXPathAbstractFactoryException.class);
                                                                                                                                                                      
                                                                                                                                                                      // Mock parent.createPath to return same parent
                                                                                                                                                                      when(parent.createPath(context)).thenReturn(parent);
                                                                                                                                                                      when(parent.equals(parent)).thenReturn(true);
                                                                                                                                                                      
                                                                                                                                                                      // Execute
                                                                                                                                                                      pointer.createPath(context);
                                                                                                                                                                  }

 @Test
                                                                                                                                                                  public void testCreateBadFactoryException_WithNonNullFactory() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                      NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                                      
                                                                                                                                                                      when(mockFactory.toString()).thenReturn("TestFactory");
                                                                                                                                                                      when(pointer.asPath()).thenReturn("/test/path");
                                                                                                                                                                      
                                                                                                                                                                      // Get the private method via reflection
                                                                                                                                                                      Method createBadFactoryExceptionMethod = NullPropertyPointer.class
                                                                                                                                                                              .getDeclaredMethod("createBadFactoryException", AbstractFactory.class);
                                                                                                                                                                      createBadFactoryExceptionMethod.setAccessible(true);
                                                                                                                                                                      
                                                                                                                                                                      // Execute
                                                                                                                                                                      JXPathAbstractFactoryException exception = (JXPathAbstractFactoryException) 
                                                                                                                                                                              createBadFactoryExceptionMethod.invoke(pointer, mockFactory);
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      String expectedMessage = "Factory TestFactory reported success creating object for path: /test/path but object was null.  Terminating to avoid stack recursion.";
                                                                                                                                                                      assertEquals(expectedMessage, exception.getMessage());
                                                                                                                                                                  }

 @Test
                                                                                                                                                                  public void testCreateBadFactoryException_WithNullFactory() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                      NullPropertyPointer pointer = new NullPropertyPointer(parentPointer);
                                                                                                                                                                      
                                                                                                                                                                      // Mock asPath() behavior
                                                                                                                                                                      NullPropertyPointer spyPointer = spy(pointer);
                                                                                                                                                                      when(spyPointer.asPath()).thenReturn("/null/path");
                                                                                                                                                                      
                                                                                                                                                                      // Get the private method via reflection
                                                                                                                                                                      Method method = NullPropertyPointer.class.getDeclaredMethod(
                                                                                                                                                                          "createBadFactoryException", AbstractFactory.class);
                                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                                      
                                                                                                                                                                      // Execute
                                                                                                                                                                      JXPathAbstractFactoryException exception = 
                                                                                                                                                                          (JXPathAbstractFactoryException) method.invoke(spyPointer, (AbstractFactory) null);
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      String expectedMessage = "Factory null reported success creating object for path: /null/path but object was null.  Terminating to avoid stack recursion.";
                                                                                                                                                                      assertEquals(expectedMessage, exception.getMessage());
                                                                                                                                                                  }

 @Test
                                                                                                                                                                  public void testCreateBadFactoryException_WithSpecialCharactersInPath() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                      NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                      NullPropertyPointer pointer = new NullPropertyPointer(parentPointer);
                                                                                                                                                                      
                                                                                                                                                                      when(mockFactory.toString()).thenReturn("SpecialCharsFactory");
                                                                                                                                                                      when(pointer.asPath()).thenReturn("/path/with/special@chars");
                                                                                                                                                                      
                                                                                                                                                                      // Get the private method via reflection
                                                                                                                                                                      Method method = NullPropertyPointer.class.getDeclaredMethod(
                                                                                                                                                                          "createBadFactoryException", AbstractFactory.class);
                                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                                      
                                                                                                                                                                      // Execute
                                                                                                                                                                      JXPathAbstractFactoryException exception = 
                                                                                                                                                                          (JXPathAbstractFactoryException) method.invoke(pointer, mockFactory);
                                                                                                                                                                      
                                                                                                                                                                      // Verify
                                                                                                                                                                      String expectedMessage = "Factory SpecialCharsFactory reported success creating object for path: /path/with/special@chars but object was null.  Terminating to avoid stack recursion.";
                                                                                                                                                                      assertEquals(expectedMessage, exception.getMessage());
                                                                                                                                                                  }

 @Test(expected = JXPathAbstractFactoryException.class)
                                                                                                                                                              public void testCreatePath_ThrowsExceptionWhenParentIsNullPointer() {
                                                                                                                                                                  // Setup
                                                                                                                                                                  JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                                  AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                                                                                  NodePointer parent = mock(NodePointer.class);
                                                                                                                                                                  when(context.getFactory()).thenReturn(factory);
                                                                                                                                                                  
                                                                                                                                                                  NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                                  pointer.setPropertyName("testProperty");
                                                                                                                                                                  
                                                                                                                                                                  when(parent.createPath(context)).thenReturn(parent);
                                                                                                                                                                  when(parent.equals(parent)).thenReturn(true);
                                                                                                                                                                  
                                                                                                                                                                  // Execute - should throw JXPathAbstractFactoryException
                                                                                                                                                                  pointer.createPath(context);
                                                                                                                                                              }

 @Test
                                                                                                                                                          public void testCreatePath_WithPropertyOwnerParent() {
                                                                                                                                                              // Setup
                                                                                                                                                              JXPathContext context = mock(JXPathContext.class);
                                                                                                                                                              NodePointer parent = mock(NodePointer.class);
                                                                                                                                                              PropertyOwnerPointer propertyOwner = mock(PropertyOwnerPointer.class);
                                                                                                                                                              PropertyPointer propertyPointer = mock(PropertyPointer.class);
                                                                                                                                                              NodePointer childPointer = mock(NodePointer.class);
                                                                                                                                                              
                                                                                                                                                              NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                              pointer.setPropertyName("testProperty");
                                                                                                                                                              pointer.setValue("testValue");
                                                                                                                                                              
                                                                                                                                                              QName testQName = new QName("testProperty");
                                                                                                                                                              
                                                                                                                                                              when(parent.createPath(context)).thenReturn(propertyOwner);
                                                                                                                                                              when(propertyOwner.getPropertyPointer()).thenReturn(propertyPointer);
                                                                                                                                                              when(propertyPointer.createChild(context, testQName, -1, "testValue")).thenReturn(childPointer);
                                                                                                                                                              
                                                                                                                                                              // Execute
                                                                                                                                                              NodePointer result = pointer.createPath(context);
                                                                                                                                                              
                                                                                                                                                              // Verify
                                                                                                                                                              assertEquals(childPointer, result);
                                                                                                                                                              verify(propertyOwner).getPropertyPointer();
                                                                                                                                                              verify(propertyPointer).createChild(context, testQName, -1, "testValue");
                                                                                                                                                          }

 @Test
                                                                                                                                                  public void testCreatePath_WhenNewParentIsNotPropertyOwnerPointer_CreatesChildDirectly() {
                                                                                                                                                      // Setup
                                                                                                                                                      org.apache.commons.jxpath.JXPathContext context = mock(org.apache.commons.jxpath.JXPathContext.class);
                                                                                                                                                      org.apache.commons.jxpath.ri.model.NodePointer parent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                      org.apache.commons.jxpath.ri.model.NodePointer newParent = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                      org.apache.commons.jxpath.ri.model.NodePointer expectedResult = mock(org.apache.commons.jxpath.ri.model.NodePointer.class);
                                                                                                                                                      
                                                                                                                                                      org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer pointer = 
                                                                                                                                                          new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(parent);
                                                                                                                                                      pointer.setPropertyName("testChild");
                                                                                                                                                      pointer.setPropertyIndex(2);
                                                                                                                                                      
                                                                                                                                                      // Create QName for the property using the correct class
                                                                                                                                                      org.apache.commons.jxpath.ri.QName propertyQName = new org.apache.commons.jxpath.ri.QName("testChild");
                                                                                                                                                      
                                                                                                                                                      // Mock behavior
                                                                                                                                                      when(parent.createPath(context)).thenReturn(newParent);
                                                                                                                                                      when(newParent.createChild(context, propertyQName, 2)).thenReturn(expectedResult);
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      org.apache.commons.jxpath.ri.model.NodePointer result = pointer.createPath(context);
                                                                                                                                                      
                                                                                                                                                      // Verify
                                                                                                                                                      assertEquals(expectedResult, result);
                                                                                                                                                      verify(parent).createPath(context);
                                                                                                                                                      verify(newParent).createChild(context, propertyQName, 2);
                                                                                                                                                  }

 @Test
                                                                                                                                             public void testGetNameReturnsNonNullQName() {
                                                                                                                                                 // Setup
                                                                                                                                                 NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                                 String testPropertyName = "testProperty";
                                                                                                                                                 pointer.setPropertyName(testPropertyName);
                                                                                                                                                 
                                                                                                                                                 // Exercise
                                                                                                                                                 QName result = pointer.getName();
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 assertNotNull("getName() should not return null", result);
                                                                                                                                                 assertEquals("QName should match property name", 
                                                                                                                                                             testPropertyName, 
                                                                                                                                                             result.toString()); // Changed from getLocalPart() to toString()
                                                                                                                                             }

 @Test
                                                                                                                                             public void testSetPropertyIndexStoresCorrectValue() {
                                                                                                                                                 // Create parent pointer (can be null for this test)
                                                                                                                                                 NodePointer parent = mock(NodePointer.class);
                                                                                                                                                 
                                                                                                                                                 // Create test object
                                                                                                                                                 NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                                                                                 
                                                                                                                                                 // Test setting various index values
                                                                                                                                                 pointer.setPropertyIndex(5);
                                                                                                                                                 // Since we can't directly access the index field, we'll need to verify through other means
                                                                                                                                                 // Assuming getLength() might be affected by the index
                                                                                                                                                 // If we can't verify through public methods, this mutant might be hard to catch without reflection
                                                                                                                                                 // Alternative approach using reflection to verify the field value:
                                                                                                                                                 try {
                                                                                                                                                     java.lang.reflect.Field indexField = NullPropertyPointer.class.getDeclaredField("index");
                                                                                                                                                     indexField.setAccessible(true);
                                                                                                                                                     int storedValue = indexField.getInt(pointer);
                                                                                                                                                     assertEquals("Index should store the provided value", 5, storedValue);
                                                                                                                                                     
                                                                                                                                                     // Test another value
                                                                                                                                                     pointer.setPropertyIndex(10);
                                                                                                                                                     storedValue = indexField.getInt(pointer);
                                                                                                                                                     assertEquals("Index should store the provided value", 10, storedValue);
                                                                                                                                                     
                                                                                                                                                     // Test negative value
                                                                                                                                                     pointer.setPropertyIndex(-1);
                                                                                                                                                     storedValue = indexField.getInt(pointer);
                                                                                                                                                     assertEquals("Index should store negative values", -1, storedValue);
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Reflection failed: " + e.getMessage());
                                                                                                                                                 }
                                                                                                                                             }

 @Test
                                                                                                                                   public void testGetNameReturnsQNameWithCorrectPropertyName() {
                                                                                                                                       // Setup
                                                                                                                                       NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                       String testName = "testProperty";
                                                                                                                                       pointer.setPropertyName(testName);
                                                                                                                                       
                                                                                                                                       // Exercise
                                                                                                                                       QName result = pointer.getName();
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       // First check the exact type is QName (this catches the Object mutant)
                                                                                                                                       assertTrue("Return type should be QName", result instanceof QName);
                                                                                                                                       
                                                                                                                                       // Then verify the content is correct
                                                                                                                                       assertEquals("QName should contain the property name", 
                                                                                                                                                   testName, result.getName());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetNameReturnTypeIsQName() {
                                                                                                                                       // Setup
                                                                                                                                       NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                                       pointer.setPropertyName("anyName");
                                                                                                                                       
                                                                                                                                       // Exercise
                                                                                                                                       Object result = pointer.getName();
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       assertTrue("Return type should be QName", 
                                                                                                                                                 result instanceof QName);
                                                                                                                                       // This would fail on the mutant since it returns boolean
                                                                                                                                   }

 @Test
                                                                                                                      public void testGetNameReturnsQNameWithCorrectProperty() {
                                                                                                                          // Setup
                                                                                                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                                          String testPropertyName = "testProperty";
                                                                                                                          pointer.setPropertyName(testPropertyName);
                                                                                                                          
                                                                                                                          // Exercise
                                                                                                                          QName result = pointer.getName();
                                                                                                                          
                                                                                                                          // Verify
                                                                                                                          assertNotNull("Returned QName should not be null", result);
                                                                                                                          assertEquals("QName should match property name", 
                                                                                                                                       testPropertyName, result.getName());
                                                                                                                      }

 @Test
                                                                                                 public void testGetNameReturnsQNameWithPropertyName() {
                                                                                                     // Setup
                                                                                                     org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer pointer = 
                                                                                                         new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(null);
                                                                                                     String testPropertyName = "testProperty";
                                                                                                     pointer.setPropertyName(testPropertyName);
                                                                                                     
                                                                                                     // Exercise
                                                                                                     org.apache.commons.jxpath.ri.QName result = pointer.getName();
                                                                                                     
                                                                                                     // Verify
                                                                                                     assertNotNull("Returned QName should not be null", result);
                                                                                                     assertEquals("QName should contain the property name", 
                                                                                                               testPropertyName, result.getName());
                                                                                                     // This will fail on the mutant since it returns 'this' instead of a QName
                                                                                                     assertTrue("Return value should be a QName", 
                                                                                                               result instanceof org.apache.commons.jxpath.ri.QName);
                                                                                                 }

 @Test
                                                                                            public void testGetNameReturnsQName() {
                                                                                                // Setup
                                                                                                javax.xml.namespace.QName expectedQName = new javax.xml.namespace.QName("testProperty");
                                                                                                NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                                String testName = "testProperty";
                                                                                                pointer.setPropertyName(testName);
                                                                                                
                                                                                                // Exercise
                                                                                                Object result = pointer.getName();
                                                                                                
                                                                                                // Verify
                                                                                                assertNotNull("Return value should not be null", result);
                                                                                                assertTrue("Return value should be a QName", result instanceof javax.xml.namespace.QName);
                                                                                                assertEquals("QName should match property name", 
                                                                                                             testName, 
                                                                                                             ((javax.xml.namespace.QName)result).getLocalPart());
                                                                                            }

 @Test
                                                                                       public void testGetNameReturnsQName1() {
                                                                                           // Setup
                                                                                           javax.xml.namespace.QName expectedQName = new javax.xml.namespace.QName("testProperty");
                                                                                           NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                           String testPropertyName = "testProperty";
                                                                                           pointer.setPropertyName(testPropertyName);
                                                                                           
                                                                                           // Execute
                                                                                           Object result = pointer.getName();
                                                                                           
                                                                                           // Verify
                                                                                           assertNotNull("Returned value should not be null", result);
                                                                                           assertTrue("Returned object should be a QName", result instanceof javax.xml.namespace.QName);
                                                                                           assertEquals("QName should match property name", 
                                                                                                       testPropertyName, 
                                                                                                       ((javax.xml.namespace.QName)result).getLocalPart());
                                                                                       }

 @Test
                                                                                       public void testGetNameWhenParentIsContainer() {
                                                                                           // Setup
                                                                                           String testPropertyName = "testProperty";
                                                                                           NodePointer mockParent = mock(NodePointer.class);
                                                                                           when(mockParent.isContainer()).thenReturn(true);
                                                                                           
                                                                                           NullPropertyPointer pointer = new NullPropertyPointer(mockParent);
                                                                                           pointer.setPropertyName(testPropertyName);
                                                                                           
                                                                                           // Execute
                                                                                           QName result = pointer.getName();
                                                                                           
                                                                                           // Verify
                                                                                           assertEquals("QName should match property name", 
                                                                                                       new QName(testPropertyName), result);
                                                                                           verify(mockParent).isContainer(); // This assertion will fail with the mutant
                                                                                       }

 @Test
                                                                                       public void testGetNameWhenParentIsNull() {
                                                                                           // Setup
                                                                                           String testPropertyName = "testProperty";
                                                                                           NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                           pointer.setPropertyName(testPropertyName);
                                                                                           
                                                                                           // Execute
                                                                                           QName result = pointer.getName();
                                                                                           
                                                                                           // Verify
                                                                                           assertEquals("QName should match property name", 
                                                                                                       new QName(testPropertyName), result);
                                                                                       }

 @Test
                                                                                       public void testGetNameWhenParentIsNotNullAndNotContainer() {
                                                                                           // Setup
                                                                                           String testPropertyName = "testProperty";
                                                                                           NodePointer mockParent = mock(NodePointer.class);
                                                                                           when(mockParent.isContainer()).thenReturn(false);
                                                                                           
                                                                                           NullPropertyPointer pointer = new NullPropertyPointer(mockParent);
                                                                                           pointer.setPropertyName(testPropertyName);
                                                                                           
                                                                                           // Execute
                                                                                           QName result = pointer.getName();
                                                                                           
                                                                                           // Verify
                                                                                           assertEquals("QName should match property name", 
                                                                                                       new QName(testPropertyName), result);
                                                                                           verify(mockParent).isContainer(); // This assertion will fail with the mutant
                                                                                       }

 @Test
                                                                                  public void testCreateAttributeUsesCorrectParent() throws Exception {
                                                                                      // Setup
                                                                                      NodePointer parent = mock(NodePointer.class);
                                                                                      NodePointer newParent = mock(NodePointer.class);
                                                                                      JXPathContext context = mock(JXPathContext.class);
                                                                                      QName expectedQName = new QName("test");
                                                                                      NodePointer expectedResult = mock(NodePointer.class);
                                                                                      
                                                                                      // Create NullPropertyPointer with parent
                                                                                      NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                      
                                                                                      // Mock getName() to return expected QName
                                                                                      when(pointer.getName()).thenReturn(expectedQName);
                                                                                      
                                                                                      // Set different behaviors for parent and newParent
                                                                                      when(parent.createAttribute(context, expectedQName)).thenReturn(null);
                                                                                      when(newParent.createAttribute(context, expectedQName)).thenReturn(expectedResult);
                                                                                      
                                                                                      // Set newParent (this would normally happen in the actual code)
                                                                                      // Reflection to set newParent since it's not directly accessible
                                                                                      Field parentField = NodePointer.class.getDeclaredField("parent");
                                                                                      parentField.setAccessible(true);
                                                                                      parentField.set(pointer, newParent);
                                                                                      
                                                                                      // Test - this should call newParent.createAttribute()
                                                                                      NodePointer result = pointer.createAttribute(context, pointer.getName());
                                                                                      
                                                                                      // Verify - should use newParent, not original parent
                                                                                      verify(newParent, times(1)).createAttribute(context, expectedQName);
                                                                                      verify(parent, never()).createAttribute(context, expectedQName);
                                                                                      assertEquals(expectedResult, result);
                                                                                  }

 @Test
                                                                                     public void testGetNameWithDifferentNullPointerParents() {
                                                                                         // Create two different NullPointer parents
                                                                                         NodePointer parent1 = mock(NodePointer.class);
                                                                                         when(parent1 instanceof NullPointer).thenReturn(true);
                                                                                         NodePointer parent2 = mock(NodePointer.class);
                                                                                         when(parent2 instanceof NullPointer).thenReturn(true);
                                                                                         
                                                                                         // Make them not equal
                                                                                         when(parent1.equals(parent2)).thenReturn(false);
                                                                                         
                                                                                         // Create test objects
                                                                                         NullPropertyPointer pointer1 = new NullPropertyPointer(parent1);
                                                                                         NullPropertyPointer pointer2 = new NullPropertyPointer(parent2);
                                                                                         
                                                                                         // Set property names
                                                                                         pointer1.setPropertyName("test1");
                                                                                         pointer2.setPropertyName("test2");
                                                                                         
                                                                                         // Test that getName returns different QNames for different parents
                                                                                         // This would fail with the mutant since it wouldn't check equality
                                                                                         assertNotEquals(pointer1.getName(), pointer2.getName());
                                                                                         
                                                                                         // Test with same parent
                                                                                         NullPropertyPointer pointer3 = new NullPropertyPointer(parent1);
                                                                                         pointer3.setPropertyName("test1");
                                                                                         assertEquals(pointer1.getName(), pointer3.getName());
                                                                                     }

 @Test
                                                                                     public void testGetNameWithNonNullPointerParent() {
                                                                                         NodePointer nonNullParent = mock(NodePointer.class);
                                                                                         when(nonNullParent instanceof NullPointer).thenReturn(false);
                                                                                         
                                                                                         NullPropertyPointer pointer = new NullPropertyPointer(nonNullParent);
                                                                                         pointer.setPropertyName("test");
                                                                                         
                                                                                         // Should still work regardless of parent type
                                                                                         assertNotNull(pointer.getName());
                                                                                         assertEquals(new QName("test"), pointer.getName());
                                                                                     }

 @Test
                                                                                    public void testCreateAttributeUsesNewParent() {
                                                                                        // Setup test objects
                                                                                        NodePointer parent = mock(NodePointer.class);
                                                                                        NodePointer newParent = mock(NodePointer.class);
                                                                                        JXPathContext context = mock(JXPathContext.class);
                                                                                        QName expectedName = new QName("testProperty");
                                                                                        
                                                                                        // Create test instance
                                                                                        NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                        pointer.setPropertyName("testProperty");
                                                                                        
                                                                                        // Mock behavior
                                                                                        when(parent.createAttribute(any(), any())).thenReturn(mock(NodePointer.class));
                                                                                        when(newParent.createAttribute(any(), any())).thenReturn(mock(NodePointer.class));
                                                                                        
                                                                                        // This would normally be set during createPath operation
                                                                                        // We're simulating the internal state where newParent is different from parent
                                                                                        try {
                                                                                            java.lang.reflect.Field parentField = NodePointer.class.getDeclaredField("parent");
                                                                                            parentField.setAccessible(true);
                                                                                            parentField.set(pointer, newParent);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set parent field via reflection");
                                                                                        }
                                                                                        
                                                                                        // Call the method that should use newParent
                                                                                        NodePointer result = pointer.createPath(context);
                                                                                        
                                                                                        // Verify the correct parent was used
                                                                                        verify(newParent, times(1)).createAttribute(eq(context), eq(expectedName));
                                                                                        verify(parent, never()).createAttribute(any(), any());
                                                                                        
                                                                                        // Additional assertions
                                                                                        assertNotNull(result);
                                                                                    }

 @Test
                                                                              public void testCreateChildUsesNewParentNotOriginalParent() throws Exception {
                                                                                  // Setup
                                                                                  NodePointer parent = mock(NodePointer.class);
                                                                                  NodePointer newParent = mock(NodePointer.class);
                                                                                  NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                                                  
                                                                                  // Mock behavior
                                                                                  JXPathContext context = mock(JXPathContext.class);
                                                                                  QName name = new QName("testName");
                                                                                  int index = 0;
                                                                                  Object value = "testValue";
                                                                                  
                                                                                  // When getName() is called, return our test QName
                                                                                  when(pointer.getName()).thenReturn(name);
                                                                                  
                                                                                  // Mock the expected child pointer
                                                                                  NodePointer expectedChild = mock(NodePointer.class);
                                                                                  when(newParent.createChild(context, name, index, value)).thenReturn(expectedChild);
                                                                                  
                                                                                  // Need to simulate that createPath creates newParent
                                                                                  // This would normally happen in the actual implementation
                                                                                  when(parent.createPath(context)).thenReturn(newParent);
                                                                                  
                                                                                  // Test - use the correct createChild method signature with QName parameter
                                                                                  NodePointer result = pointer.createChild(context, name, index, value);
                                                                                  
                                                                                  // Verify
                                                                                  // The key assertion - verify newParent was used, not parent
                                                                                  verify(newParent, times(1)).createChild(context, name, index, value);
                                                                                  verify(parent, never()).createChild(context, name, index, value);
                                                                                  assertEquals(expectedChild, result);
                                                                              }

 @Test(expected = NullPointerException.class)
                                                                              public void testMutatedGetNameThrowsNullPointer() {
                                                                                  // This test would catch the mutant version
                                                                                  // Setup
                                                                                  String testPropertyName = "testProperty";
                                                                                  NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                                                  pointer.setPropertyName(testPropertyName);
                                                                                  
                                                                                  // This would throw NullPointerException in mutant version
                                                                                  // because it tries to call createChild on null parent
                                                                                  pointer.getName();
                                                                              }

 @Test
                                                 public void testGetNameReturnsQNameWithPropertyName1() {
                                                     // Setup
                                                     String testPropertyName = "testProperty";
                                                     NullPropertyPointer pointer = new NullPropertyPointer(null);
                                                     pointer.setPropertyName(testPropertyName);
                                                     
                                                     // Test
                                                     org.apache.commons.jxpath.ri.QName result = pointer.getName();
                                                     
                                                     // Verify
                                                     assertNotNull("Result should not be null", result);
                                                     assertEquals("QName should match property name", 
                                                               testPropertyName, result.toString());
                                                 }

 @Test
                                                 public void testCreateChildUsesCreatePathNotParentDirectly() {
                                                     // Setup mocks
                                                     NodePointer parent = mock(NodePointer.class);
                                                     JXPathContext context = mock(JXPathContext.class);
                                                     QName name = new QName("testName");
                                                     int index = 0;
                                                     Object value = new Object();
                                                     
                                                     // Create test instance
                                                     NullPropertyPointer pointer = new NullPropertyPointer(parent);
                                                     
                                                     // Stub createPath to return a mock
                                                     NodePointer expectedPointer = mock(NodePointer.class);
                                                     when(pointer.createPath(context)).thenReturn(expectedPointer);
                                                     
                                                     // Stub createChild on the expected pointer
                                                     NodePointer childPointer = mock(NodePointer.class);
                                                     when(expectedPointer.createChild(context, name, index, value)).thenReturn(childPointer);
                                                     
                                                     // Execute
                                                     NodePointer result = pointer.createChild(context, name, index, value);
                                                     
                                                     // Verify behavior
                                                     verify(pointer).createPath(context); // Original behavior
                                                     verify(expectedPointer).createChild(context, name, index, value); // Original behavior
                                                     verify(parent, never()).createChild(any(), any(), anyInt(), any()); // Should never call parent directly
                                                     
                                                     // Verify result
                                                     assertSame(childPointer, result);
                                                 }

 @Test
                                           public void testGetNameReturnsQName2() {
                                               // Setup
                                               javax.xml.namespace.QName expectedQName = new javax.xml.namespace.QName("testProperty");
                                               NullPropertyPointer pointer = new NullPropertyPointer(null);
                                               String testName = "testProperty";
                                               pointer.setPropertyName(testName);
                                               
                                               // Test
                                               Object result = pointer.getName();
                                               
                                               // Verify
                                               assertNotNull("Return value should not be null", result);
                                               assertTrue("Return value should be QName", result instanceof javax.xml.namespace.QName);
                                               assertEquals("QName value should match property name", 
                                                          testName, ((javax.xml.namespace.QName)result).getLocalPart());
                                           }

 @Test
                                           public void testGetNameWithNullPropertyName() {
                                               // Setup
                                               NullPropertyPointer pointer = new NullPropertyPointer(null);
                                               pointer.setPropertyName(null);
                                               
                                               // Test
                                               Object result = pointer.getName();
                                               
                                               // Verify
                                               assertNotNull("Return value should not be null even with null property", result);
                                               assertTrue("Return value should be QName", result instanceof javax.xml.namespace.QName);
                                               assertNull("QName local part should be null", ((javax.xml.namespace.QName)result).getLocalPart());
                                           }

 @Test
                                      public void testGetNameWithNullPropertyName1() {
                                          // Setup
                                          NullPropertyPointer pointer = new NullPropertyPointer(null);
                                          pointer.setPropertyName(null);
                                          
                                          // Exercise
                                          QName result = pointer.getName();
                                          
                                          // Verify
                                          assertNotNull("getName() should not return null even with null propertyName", result);
                                          assertNull("The name should be null when propertyName is null", result.getName());
                                      }

 @Test
                                  public void testGetNameReturnsQNameNotNull() {
                                      // Setup
                                      org.apache.commons.jxpath.ri.QName expectedQName = new org.apache.commons.jxpath.ri.QName("testProperty");
                                      NullPropertyPointer pointer = new NullPropertyPointer(null);
                                      pointer.setPropertyName("testProperty");
                                      
                                      // Exercise
                                      org.apache.commons.jxpath.ri.QName result = pointer.getName();
                                      
                                      // Verify
                                      assertNotNull("getName() should not return null", result);
                                      assertEquals("testProperty", result.getName());
                                  }

}
