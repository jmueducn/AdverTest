package gentest.org.apache.commons.jxpath.ri.model.dom.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.jxpath.ri.model.dom.*;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.util.TypeUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
 
public class DOMNodePointerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                         public void testNode_NullTest() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertTrue(pointer.testNode(null));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_NodeNameTest_NonElementNode() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                                             when(mockTest.getNodeName()).thenReturn(mock(QName.class));
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_NodeNameTest_WildcardNullPrefix() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                                             when(mockTest.isWildcard()).thenReturn(true);
                                                                                                                                                                                                                                                                                             when(mockTest.getNodeName()).thenReturn(mock(QName.class));
                                                                                                                                                                                                                                                                                             when(mockTest.getNodeName().getPrefix()).thenReturn(null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_NodeNameTest_MatchingLocalNameEqualNamespace() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             NodeNameTest mockTest = mock(NodeNameTest.class);
                                                                                                                                                                                                                                                                                             QName mockQName = mock(QName.class);
                                                                                                                                                                                                                                                                                             when(mockTest.getNodeName()).thenReturn(mockQName);
                                                                                                                                                                                                                                                                                             when(mockTest.isWildcard()).thenReturn(false);
                                                                                                                                                                                                                                                                                             when(mockQName.getName()).thenReturn("test");
                                                                                                                                                                                                                                                                                             when(mockTest.getNamespaceURI()).thenReturn("http://example.com");
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Mock static method behavior
                                                                                                                                                                                                                                                                                             when(DOMNodePointer.getLocalName(mockNode)).thenReturn("test");
                                                                                                                                                                                                                                                                                             when(DOMNodePointer.getNamespaceURI(mockNode)).thenReturn("http://example.com");
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_NodeTypeTest_NodeTypeNode_Element() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                                             when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_NodeTypeTest_NodeTypeText_TextNode() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.TEXT_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                                             when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_TEXT);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_NodeTypeTest_NodeTypeComment_CommentNode() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.COMMENT_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                                             when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_COMMENT);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_NodeTypeTest_NodeTypePI_PINode() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             NodeTypeTest mockTest = mock(NodeTypeTest.class);
                                                                                                                                                                                                                                                                                             when(mockTest.getNodeType()).thenReturn(Compiler.NODE_TYPE_PI);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_ProcessingInstructionTest_MatchingTarget() {
                                                                                                                                                                                                                                                                                             ProcessingInstruction mockNode = mock(ProcessingInstruction.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                                             when(mockNode.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                                             when(mockTest.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertTrue(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_ProcessingInstructionTest_NonMatchingTarget() {
                                                                                                                                                                                                                                                                                             ProcessingInstruction mockNode = mock(ProcessingInstruction.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.PROCESSING_INSTRUCTION_NODE);
                                                                                                                                                                                                                                                                                             when(mockNode.getTarget()).thenReturn("xml-stylesheet");
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                                             when(mockTest.getTarget()).thenReturn("other-target");
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_ProcessingInstructionTest_WrongNodeType() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             when(mockNode.getNodeType()).thenReturn(Node.ELEMENT_NODE);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             ProcessingInstructionTest mockTest = mock(ProcessingInstructionTest.class);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                         public void testNode_UnknownTestType() {
                                                                                                                                                                                                                                                                                             Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                             NodeTest mockTest = mock(NodeTest.class); // Not one of the known subtypes
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             assertFalse(pointer.testNode(mockTest));
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                 public void testTestNode_WithNullTest() {
                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                     Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Expect exception
                                                                                                                                                                                                                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                                     exception.expect(NullPointerException.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                     pointer.testNode(null);
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                 public void testTestNode_WithNullNode() {
                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                     NodeTest mockTest = mock(NodeTest.class);
                                                                                                                                                                                                                                                                                     DOMNodePointer pointer = new DOMNodePointer((Node)null, (Locale)null);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                     boolean result = pointer.testNode(mockTest);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                                     assertFalse(result);
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                 public void testStaticTestNode_WithNullTest() {
                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                     org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                                                                                                                                                                                     org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Expect exception
                                                                                                                                                                                                                                                                                     exception.expect(NullPointerException.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                     org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(mockNode, null);
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                 public void testCreateChild_SuccessfulCreation() throws Exception {
                                                                                                                                                                                                                                                                                     // Mock objects
                                                                                                                                                                                                                                                                                     Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                     Node mockChildNode = mock(Node.class);
                                                                                                                                                                                                                                                                                     NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                                                                                                                     JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                     AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Create test objects
                                                                                                                                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                                                                                                                                     int index = 0;
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Create pointer with mock node
                                                                                                                                                                                                                                                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Set up mock factory
                                                                                                                                                                                                                                                                                     Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                                                                                                     factoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                     factoryField.set(pointer, mockFactory);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Mock behaviors
                                                                                                                                                                                                                                                                                     when(mockFactory.createObject(mockContext, pointer, mockNode, "test", index))
                                                                                                                                                                                                                                                                                         .thenReturn(true);
                                                                                                                                                                                                                                                                                     when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                                                                                                                                                                                         .thenReturn(mockIterator);
                                                                                                                                                                                                                                                                                     when(mockIterator.setPosition(index + 1)).thenReturn(true);
                                                                                                                                                                                                                                                                                     when(mockIterator.getNodePointer()).thenReturn(new DOMNodePointer(mockChildNode, null));
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Test
                                                                                                                                                                                                                                                                                     NodePointer result = pointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                                                     assertEquals(mockChildNode, result.getNode());
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                 public void testCreateChild_WHOLE_COLLECTIONIndex() throws Exception {
                                                                                                                                                                                                                                                                                     // Mock objects
                                                                                                                                                                                                                                                                                     Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                     Node mockChildNode = mock(Node.class);
                                                                                                                                                                                                                                                                                     NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                                                                                                                     JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                     AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Create pointer with mock node
                                                                                                                                                                                                                                                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Set up factory in context
                                                                                                                                                                                                                                                                                     when(mockContext.getFactory()).thenReturn(mockFactory);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     QName name = new QName("test");
                                                                                                                                                                                                                                                                                     int index = DOMNodePointer.WHOLE_COLLECTION;
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     when(mockFactory.createObject(mockContext, pointer, mockNode, "test", 0))
                                                                                                                                                                                                                                                                                         .thenReturn(true);
                                                                                                                                                                                                                                                                                     when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                                                                                                                                                                                         .thenReturn(mockIterator);
                                                                                                                                                                                                                                                                                     when(mockIterator.setPosition(1)).thenReturn(true);
                                                                                                                                                                                                                                                                                     when(mockIterator.getNodePointer()).thenReturn(new DOMNodePointer(mockChildNode, null));
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     NodePointer result = pointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                                                     assertEquals(mockChildNode, result.getNode());
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                 public void testCreateChild_WithValidParameters() {
                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                     QName name = new QName("http://example.com", "child");
                                                                                                                                                                                                                                                                                     int index = 1;
                                                                                                                                                                                                                                                                                     Object value = "testValue";
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Mock objects
                                                                                                                                                                                                                                                                                     JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                     NodePointer mockChildPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Mock the createChild method that returns NodePointer
                                                                                                                                                                                                                                                                                     when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                                                                                                                                                                                                                                         .thenReturn(mockChildPointer);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                     NodePointer result = parentPointer.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                                                     assertEquals(mockChildPointer, result);
                                                                                                                                                                                                                                                                                     verify(mockChildPointer).setValue(value);
                                                                                                                                                                                                                                                                                     verify(parentPointer).createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                 public void testCreateChild_WithNegativeIndex() {
                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                     QName name = new QName("child");
                                                                                                                                                                                                                                                                                     int index = -1;
                                                                                                                                                                                                                                                                                     Object value = "value";
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                     JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                     NodePointer mockChildPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Mock the createChild method to handle negative index
                                                                                                                                                                                                                                                                                     when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                                                                                                                                                                                                                                         .thenReturn(mockChildPointer);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                     NodePointer result = parentPointer.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                                                     verify(parentPointer).createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                 public void testCreateChild_WithNullValue() {
                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                     QName name = new QName("child");
                                                                                                                                                                                                                                                                                     int index = 0;
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Create mocks
                                                                                                                                                                                                                                                                                     NodePointer parentPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                     JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                     NodePointer mockChildPointer = mock(NodePointer.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Mock the createChild method
                                                                                                                                                                                                                                                                                     when(parentPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt(), any()))
                                                                                                                                                                                                                                                                                         .thenReturn(mockChildPointer);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                     NodePointer result = parentPointer.createChild(mockContext, name, index, null);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                                                     verify(mockChildPointer).setValue(null);
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                 public void testCreateChild_VerifyChildCreation() {
                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                     QName name = new QName("child");
                                                                                                                                                                                                                                                                                     int index = 0;
                                                                                                                                                                                                                                                                                     Object value = "test";
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                                                                                     Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                     Node mockChildNode = mock(Node.class);
                                                                                                                                                                                                                                                                                     JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Create a real child pointer (not mocked) to test actual behavior
                                                                                                                                                                                                                                                                                     DOMNodePointer realParent = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Mock the createChild method to return a real pointer
                                                                                                                                                                                                                                                                                     when(realParent.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                                                                                                                                                                                                                                                                                         .thenReturn(new DOMNodePointer(realParent, mockChildNode));
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                     NodePointer result = realParent.createChild(mockContext, name, index, value);
                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                                                                     assertNotNull(result);
                                                                                                                                                                                                                                                                                     assertEquals(mockChildNode, result.getImmediateNode());
                                                                                                                                                                                                                                                                                     assertEquals(realParent, result.getParent());
                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                             public void testCreateChild_WithNamespace() throws Exception {
                                                                                                                                                                                                                                                                                 // Create mocks
                                                                                                                                                                                                                                                                                 Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                 Node mockChildNode = mock(Node.class);
                                                                                                                                                                                                                                                                                 NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                                                                                                                                                                                 JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                                                                                                                                                                                 AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Create pointer with mock node
                                                                                                                                                                                                                                                                                 DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Set up test data - using QName constructor that takes namespace URI and local name
                                                                                                                                                                                                                                                                                 QName name = new QName("http://ns", "prefix:test");
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 int index = 0;
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Mock behaviors
                                                                                                                                                                                                                                                                                 when(mockFactory.createObject(mockContext, pointer, mockNode, "test", index))
                                                                                                                                                                                                                                                                                     .thenReturn(true);
                                                                                                                                                                                                                                                                                 when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                                                                                                                                                                                     .thenReturn(mockIterator);
                                                                                                                                                                                                                                                                                 when(mockIterator.setPosition(index + 1)).thenReturn(true);
                                                                                                                                                                                                                                                                                 when(mockIterator.getNodePointer()).thenReturn(new DOMNodePointer(mockChildNode, null));
                                                                                                                                                                                                                                                                                 when(mockContext.getNamespaceURI("prefix")).thenReturn("http://ns");
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Use reflection to set private factory field
                                                                                                                                                                                                                                                                                 Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                                                                                                 factoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                 factoryField.set(pointer, mockFactory);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Execute test
                                                                                                                                                                                                                                                                                 NodePointer result = pointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                 assertNotNull(result);
                                                                                                                                                                                                                                                                                 assertEquals(mockChildNode, result.getNode());
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                             public void testCreateChild_WithNullContext() {
                                                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                                                 Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                                                                 Locale locale = Locale.getDefault();
                                                                                                                                                                                                                                                                                 DOMNodePointer parentPointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                                                                                                                                                                 QName name = new QName("child");
                                                                                                                                                                                                                                                                                 int index = 0;
                                                                                                                                                                                                                                                                                 Object value = "value";
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Exception rule
                                                                                                                                                                                                                                                                                 ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                                                 expectedException.expect(NullPointerException.class);
                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                 // Execute
                                                                                                                                                                                                                                                                                 parentPointer.createChild(null, name, index, value);
                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                         public void testCreateChild_FactoryFailure() throws Exception {
                                                                                                                                                                                                                                             // Create test objects
                                                                                                                                                                                                                                             javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                                                                                                                                                                                                                                             javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                                                                                                                                                                                                                                             org.w3c.dom.Document document = builder.newDocument();
                                                                                                                                                                                                                                             org.w3c.dom.Node mockNode = document.createElement("testElement");
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create required objects
                                                                                                                                                                                                                                             org.apache.commons.jxpath.ri.QName name = new org.apache.commons.jxpath.ri.QName("test");
                                                                                                                                                                                                                                             int index = 0;
                                                                                                                                                                                                                                             org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, java.util.Locale.getDefault());
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create mock factory and context
                                                                                                                                                                                                                                             org.apache.commons.jxpath.AbstractFactory mockFactory = new org.apache.commons.jxpath.AbstractFactory() {
                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                 public boolean createObject(JXPathContext context, Pointer pointer, Object parent, String name, int index) {
                                                                                                                                                                                                                                                     return false;
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                 public boolean declareVariable(JXPathContext context, String name) {
                                                                                                                                                                                                                                                     return false;
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             org.apache.commons.jxpath.JXPathContext mockContext = org.apache.commons.jxpath.JXPathContext.newContext(null);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Use reflection to set private factory field
                                                                                                                                                                                                                                             java.lang.reflect.Field factoryField = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                                                             factoryField.setAccessible(true);
                                                                                                                                                                                                                                             factoryField.set(pointer, mockFactory);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Set up exception expectations
                                                                                                                                                                                                                                             org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                             exception.expect(org.apache.commons.jxpath.JXPathAbstractFactoryException.class);
                                                                                                                                                                                                                                             exception.expectMessage("Factory could not create a child node for path: ");
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Test the method
                                                                                                                                                                                                                                             pointer.createChild(mockContext, name, index);
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                     public void testTestNode_DelegatesToStaticMethod() {
                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                                                                                                                                         Locale locale = Locale.getDefault();
                                                                                                                                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockNode, locale);
                                                                                                                                                                                                                                         NodeTest mockTest = mock(NodeTest.class);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Since we can't mock static methods with Mockito alone, we'll test the delegation path
                                                                                                                                                                                                                                         // by verifying the testNode method calls the static testNode method with correct parameters
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                                                         boolean result = pointer.testNode(mockTest);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                                         org.junit.Assert.assertTrue(result);
                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                     public void testStaticTestNode_WithNullNode() {
                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                         NodeTest mockTest = new NodeNameTest(new QName("test")); // Create a simple NodeTest implementation
                                                                                                                                                                                                                                         boolean result = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(null, mockTest);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                                         org.junit.Assert.assertFalse(result);
                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                     public void testCreateChild_IteratorFailure() throws Exception {
                                                                                                                                                                                                         // Mock objects
                                                                                                                                                                                                         org.w3c.dom.Node mockNode = mock(org.w3c.dom.Node.class);
                                                                                                                                                                                                         org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                                                                                             new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, java.util.Locale.ENGLISH);
                                                                                                                                                                                                         org.apache.commons.jxpath.AbstractFactory mockFactory = mock(org.apache.commons.jxpath.AbstractFactory.class);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Set up mock factory using reflection
                                                                                                                                                                                                         java.lang.reflect.Field factoryField = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.class.getDeclaredField("factory");
                                                                                                                                                                                                         int index = 0;
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Expected exception rule
                                                                                                                                                                                                         org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                         org.apache.commons.jxpath.ri.model.NodeIterator mockIterator = mock(org.apache.commons.jxpath.ri.model.NodeIterator.class);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Mock behavior
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                 public void testCreateChild_WithNullName() {
                                                                                                                                                                                     // Setup
                                                                                                                                                                                     org.w3c.dom.UserDataHandler userDataHandler = null; // Define UserDataHandler
                                                                                                                                                                                     Node mockNode = new Node() {
                                                                                                                                                                                         @Override
                                                                                                                                                                                         public void normalize() {}
                                                                                                                                                                                         
                                                                                                                                                                                         @Override
                                                                                                                                                                                         public void setPrefix(String prefix) {}
                                                                                                                                                                                         
                                                                                                                                                                                         @Override
                                                                                                                                                                                         public void setTextContent(String textContent) {}
                                                                                                                                                                                     
                                                                                                                                                                                         // Implement other required Node interface methods with empty implementations
                                                                                                                                                                                         @Override public String getNodeName() { return null; }
                                                                                                                                                                                         @Override public String getNodeValue() { return null; }
                                                                                                                                                                                         @Override public void setNodeValue(String nodeValue) {}
                                                                                                                                                                                         @Override public short getNodeType() { return 0; }
                                                                                                                                                                                         @Override public Node getParentNode() { return null; }
                                                                                                                                                                                         @Override public NodeList getChildNodes() { return null; }
                                                                                                                                                                                         @Override public Node getFirstChild() { return null; }
                                                                                                                                                                                         @Override public Node getLastChild() { return null; }
                                                                                                                                                                                         @Override public Node getPreviousSibling() { return null; }
                                                                                                                                                                                         @Override public Node getNextSibling() { return null; }
                                                                                                                                                                                         @Override public NamedNodeMap getAttributes() { return null; }
                                                                                                                                                                                         @Override public Document getOwnerDocument() { return null; }
                                                                                                                                                                                         @Override public Node insertBefore(Node newChild, Node refChild) { return null; }
                                                                                                                                                                                         @Override public Node replaceChild(Node newChild, Node oldChild) { return null; }
                                                                                                                                                                                         @Override public Node removeChild(Node oldChild) { return null; }
                                                                                                                                                                                         @Override public Node appendChild(Node newChild) { return null; }
                                                                                                                                                                                         @Override public boolean hasChildNodes() { return false; }
                                                                                                                                                                                         @Override public Node cloneNode(boolean deep) { return null; }
                                                                                                                                                                                         @Override public boolean hasAttributes() { return false; }
                                                                                                                                                                                         @Override public String getNamespaceURI() { return null; }
                                                                                                                                                                                         @Override public String getPrefix() { return null; }
                                                                                                                                                                                         @Override public String getLocalName() { return null; }
                                                                                                                                                                                         @Override public String getTextContent() { return null; }
                                                                                                                                                                                         @Override public boolean isSupported(String feature, String version) { return false; }
                                                                                                                                                                                         @Override public Object getUserData(String key) { return null; }
                                                                                                                                                                                         @Override public Object setUserData(String key, Object data, org.w3c.dom.UserDataHandler handler) { return null; }
                                                                                                                                                                                         @Override public boolean isSameNode(Node other) { return false; }
                                                                                                                                                                                         @Override public boolean isEqualNode(Node arg) { return false; }
                                                                                                                                                                                         @Override public String lookupPrefix(String namespaceURI) { return null; }
                                                                                                                                                                                         @Override public boolean isDefaultNamespace(String namespaceURI) { return false; }
                                                                                                                                                                                         @Override public String lookupNamespaceURI(String prefix) { return null; }
                                                                                                                                                                                         @Override public short compareDocumentPosition(Node other) { return 0; }
                                                                                                                                                                                         @Override public Object getFeature(String feature, String version) { return null; }
                                                                                                                                                                                         @Override public String getBaseURI() { return null; }
                                                                                                                                                                                     };
                                                                                                                                                                                     
                                                                                                                                                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, java.util.Locale.ENGLISH);
                                                                                                                                                                                     
                                                                                                                                                                                     // Execute
                                                                                                                                                                                     // Test logic would go here
                                                                                                                                                                                 }

    @Test
                                                                                                                                                     public void testStaticTestNode_WithValidInputs() {
                                                                                                                                                         // Setup
                                                                                                                                                         org.apache.commons.jxpath.ri.compiler.NodeTest mockTest = 
                                                                                                                                                             new org.apache.commons.jxpath.ri.compiler.NodeNameTest(
                                                                                                                                                                 new org.apache.commons.jxpath.ri.QName("test"));
                                                                                                                                                         
                                                                                                                                                         // Create a mock node
                                                                                                                                                         org.w3c.dom.Node mockNode = new org.apache.xerces.dom.ElementImpl(null, "test");
                                                                                                                                                         
                                                                                                                                                         // Test static method
                                                                                                                                                         boolean result = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(mockNode, mockTest);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         org.junit.Assert.assertTrue(result);
                                                                                                                                                     }

    @Test
                                                                                                                                     public void testTestNode_WithDifferentTestResults() {
                                                                                                                                         // Setup
                                                                                                                                         java.util.Locale locale = java.util.Locale.getDefault();
                                                                                                                                         org.w3c.dom.Document document = new org.apache.xerces.dom.DocumentImpl();
                                                                                                                                         org.w3c.dom.Node mockNode = document.createElement("test");
                                                                                                                                         org.apache.commons.jxpath.ri.model.dom.DOMNodePointer pointer = 
                                                                                                                                             new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(mockNode, locale);
                                                                                                                                         
                                                                                                                                         // Create test cases - using anonymous classes for NodeTest
                                                                                                                                         org.apache.commons.jxpath.ri.compiler.NodeTest trueTest = new org.apache.commons.jxpath.ri.compiler.NodeTest() {
                                                                                                                                             public boolean testNode(
                                                                                                                                                 org.apache.commons.jxpath.ri.model.NodePointer nodePointer,
                                                                                                                                                 org.apache.commons.jxpath.ri.model.NodePointer[] result,
                                                                                                                                                 org.apache.commons.jxpath.Pointer ptr) {
                                                                                                                                                 return true;
                                                                                                                                             }
                                                                                                                                         };
                                                                                                                                         
                                                                                                                                         org.apache.commons.jxpath.ri.compiler.NodeTest falseTest = new org.apache.commons.jxpath.ri.compiler.NodeTest() {
                                                                                                                                             public boolean testNode(
                                                                                                                                                 org.apache.commons.jxpath.ri.model.NodePointer nodePointer,
                                                                                                                                                 org.apache.commons.jxpath.ri.model.NodePointer[] result,
                                                                                                                                                 org.apache.commons.jxpath.Pointer ptr) {
                                                                                                                                                 return false;
                                                                                                                                             }
                                                                                                                                         };
                                                                                                                                         
                                                                                                                                         // Execute and verify true case
                                                                                                                                         assertTrue(pointer.testNode(trueTest));
                                                                                                                                         
                                                                                                                                         // Execute and verify false case
                                                                                                                                         assertFalse(pointer.testNode(falseTest));
                                                                                                                                     }

    @Test
                                                                                                                     public void testCreateChild_WithDefaultNamespace() throws Exception {
                                                                                                                         // Mock objects
                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                         Node mockChildNode = mock(Node.class);
                                                                                                                         JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                         AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                         
                                                                                                                         // Create pointer with mock node
                                                                                                                         DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                                                                         
                                                                                                                         // Set up test data - using QName for name parameter
                                                                                                                         QName name = new QName("test");
                                                                                                                         int index = 0;
                                                                                                                         Object value = "testValue";
                                                                                                                         
                                                                                                                         // Mock behavior
                                                                                                                         when(mockContext.getFactory()).thenReturn(mockFactory);
                                                                                                                         
                                                                                                                         // Test the method - using the 4-parameter version that includes the value
                                                                                                                         NodePointer result = pointer.createChild(mockContext, name, index, value);
                                                                                                                         
                                                                                                                         // Verify the result
                                                                                                                         assertNotNull(result);
                                                                                                                         assertEquals(mockChildNode, result.getNode());
                                                                                                                     }

    @Test
                                                                                                                     public void testCreateChildWithWholeCollectionIndex() {
                                                                                                                         // Setup
                                                                                                                         JXPathContext context = mock(JXPathContext.class);
                                                                                                                         QName name = new QName("test");
                                                                                                                         Object value = "testValue";
                                                                                                                         Node mockNode = mock(Node.class);
                                                                                                                         DOMNodePointer parentPointer = new DOMNodePointer(mockNode, null);
                                                                                                                         
                                                                                                                         // Mock the createChild call that would happen internally
                                                                                                                         NodePointer expectedPointer = mock(NodePointer.class);
                                                                                                                         when(parentPointer.createChild(context, name, NodePointer.WHOLE_COLLECTION))
                                                                                                                             .thenReturn(expectedPointer);
                                                                                                                         
                                                                                                                         // Test with WHOLE_COLLECTION index
                                                                                                                         NodePointer result = parentPointer.createChild(context, name, NodePointer.WHOLE_COLLECTION, value);
                                                                                                                         
                                                                                                                         // Verify the behavior specific to WHOLE_COLLECTION
                                                                                                                         verify(expectedPointer).setValue(value);
                                                                                                                         assertEquals(expectedPointer, result);
                                                                                                                         
                                                                                                                         // Test with normal index to ensure different behavior
                                                                                                                         int normalIndex = 1;
                                                                                                                         NodePointer normalPointer = mock(NodePointer.class);
                                                                                                                         when(parentPointer.createChild(context, name, normalIndex))
                                                                                                                             .thenReturn(normalPointer);
                                                                                                                         
                                                                                                                         NodePointer normalResult = parentPointer.createChild(context, name, normalIndex, value);
                                                                                                                         
                                                                                                                         verify(normalPointer).setValue(value);
                                                                                                                         assertEquals(normalPointer, normalResult);
                                                                                                                         
                                                                                                                         // The mutant would fail here because it would treat WHOLE_COLLECTION 
                                                                                                                         // the same as normal index or vice versa
                                                                                                                     }

    @Test
                                                                                                                public void testCreateChildWithWholeCollectionIndex1() throws Exception {
                                                                                                                    // Setup
                                                                                                                    int WHOLE_COLLECTION = -1; // Assuming this is the value based on common JXPath constants
                                                                                                                    Node mockNode = mock(Node.class);
                                                                                                                    JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                                    QName mockQName = mock(QName.class);
                                                                                                                    DOMNodePointer parentPointer = new DOMNodePointer(mockNode, null);
                                                                                                                    
                                                                                                                    // Mock the factory to return true for successful creation
                                                                                                                    AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                                                    
                                                                                                                    // Use reflection to access private getAbstractFactory method
                                                                                                                    Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod(
                                                                                                                        "getAbstractFactory", JXPathContext.class);
                                                                                                                    getAbstractFactoryMethod.setAccessible(true);
                                                                                                                    getAbstractFactoryMethod.invoke(parentPointer, mockContext);
                                                                                                                    
                                                                                                                    // Mock the factory behavior
                                                                                                                    when(mockFactory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                                                                                    
                                                                                                                    // Mock child iterator to return a node
                                                                                                                    NodeIterator mockIterator = mock(NodeIterator.class);
                                                                                                                    when(parentPointer.childIterator(any(), anyBoolean(), any())).thenReturn(mockIterator);
                                                                                                                    when(mockIterator.setPosition(1)).thenReturn(true); // index+1 when index=0
                                                                                                                    
                                                                                                                    NodePointer expectedPointer = mock(NodePointer.class);
                                                                                                                    when(mockIterator.getNodePointer()).thenReturn(expectedPointer);
                                                                                                                    
                                                                                                                    // Test with WHOLE_COLLECTION index
                                                                                                                    NodePointer result = parentPointer.createChild(mockContext, mockQName, WHOLE_COLLECTION);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertEquals(expectedPointer, result);
                                                                                                                    // Verify the factory was called with index=0 (original behavior)
                                                                                                                    verify(mockFactory).createObject(
                                                                                                                        eq(mockContext), 
                                                                                                                        eq(parentPointer), 
                                                                                                                        eq(mockNode), 
                                                                                                                        any(), 
                                                                                                                        eq(0)); // This would fail with the mutant which would pass WHOLE_COLLECTION
                                                                                                                }

    @Test
                                                                                                            public void testCreateChildReturnsNonNullPointer() {
                                                                                                                // Setup test data
                                                                                                                JXPathContext context = mock(JXPathContext.class);
                                                                                                                QName name = new QName("testName");
                                                                                                                int index = 0;
                                                                                                                Object value = "testValue";
                                                                                                                
                                                                                                                // Create test instance
                                                                                                                Node testNode = mock(Node.class);
                                                                                                                DOMNodePointer pointer = new DOMNodePointer(testNode, Locale.ENGLISH);
                                                                                                                
                                                                                                                // Mock the createChild call to return a real pointer (not null)
                                                                                                                NodePointer childPointer = mock(NodePointer.class);
                                                                                                                when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                                                                                
                                                                                                                // Execute method under test
                                                                                                                NodePointer result = pointer.createChild(context, name, index, value);
                                                                                                                
                                                                                                                // Verify results
                                                                                                                assertNotNull("Returned pointer should not be null", result);
                                                                                                                verify(childPointer).setValue(value); // Verify value was set
                                                                                                                assertEquals(childPointer, result); // Verify correct pointer returned
                                                                                                            }

    @Test
                                                                                                           public void testCreateChildWithValidParentPointer() throws Exception {
                                                                                                               // Setup test data
                                                                                                               JXPathContext context = mock(JXPathContext.class);
                                                                                                               QName name = new QName("test");
                                                                                                               int index = 0;
                                                                                                               Node node = mock(Node.class);
                                                                                                               
                                                                                                               // Mock the abstract factory and its behavior
                                                                                                               AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                               when(factory.createObject(context, any(DOMNodePointer.class), eq(node), 
                                                                                                                       eq("test"), eq(index))).thenReturn(true);
                                                                                                               
                                                                                                               // Create a real DOMNodePointer instance instead of mocking it
                                                                                                               DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                                                               
                                                                                                               // Use reflection to set the private factory field
                                                                                                               Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                                                               factoryField.setAccessible(true);
                                                                                                               factoryField.set(pointer, factory);
                                                                                                               
                                                                                                               when(pointer.asPath()).thenReturn("/parent");
                                                                                                               when(pointer.getImmediateNode()).thenReturn(node);
                                                                                                               
                                                                                                               // Mock the child iterator behavior
                                                                                                               NodeIterator it = mock(NodeIterator.class);
                                                                                                               when(it.setPosition(index + 1)).thenReturn(true);
                                                                                                               NodePointer childPointer = mock(NodePointer.class);
                                                                                                               when(it.getNodePointer()).thenReturn(childPointer);
                                                                                                               when(pointer.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                                       .thenReturn(it);
                                                                                                               
                                                                                                               // Call the method
                                                                                                               NodePointer result = pointer.createChild(context, name, index);
                                                                                                               
                                                                                                               // Verify the factory was called with the correct parent pointer (this)
                                                                                                               verify(factory).createObject(context, pointer, node, "test", index);
                                                                                                               
                                                                                                               // Verify the result is the expected child pointer
                                                                                                               assertSame(childPointer, result);
                                                                                                           }

    @Test
                                                                                                           public void testCreateChildWithNullParentPointerShouldFail() throws Exception {
                                                                                                               // Setup test data
                                                                                                               JXPathContext context = mock(JXPathContext.class);
                                                                                                               QName name = new QName("test");
                                                                                                               int index = 0;
                                                                                                               Node node = mock(Node.class);
                                                                                                               
                                                                                                               // Mock the abstract factory to fail when parent is null
                                                                                                               AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                               when(factory.createObject(context, isNull(), eq(node), 
                                                                                                                       eq("test"), eq(index))).thenReturn(false);
                                                                                                               
                                                                                                               // Mock the DOMNodePointer
                                                                                                               DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                                                               
                                                                                                               // Use reflection to mock the private getAbstractFactory method
                                                                                                               Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                                                                                               getAbstractFactoryMethod.setAccessible(true);
                                                                                                               when(getAbstractFactoryMethod.invoke(pointer, context)).thenReturn(factory);
                                                                                                               
                                                                                                               when(pointer.asPath()).thenReturn("/parent");
                                                                                                               when(pointer.getImmediateNode()).thenReturn(node);
                                                                                                               
                                                                                                               // Call the method - should throw exception
                                                                                                               pointer.createChild(context, name, index);
                                                                                                               
                                                                                                               // Verify the factory was called with null parent
                                                                                                               verify(factory).createObject(context, null, node, "test", index);
                                                                                                           }

    @Test
                                                                                                       public void testCreateChildWithValue_NodeNotNull() {
                                                                                                           // Setup test data
                                                                                                           JXPathContext context = mock(JXPathContext.class);
                                                                                                           QName name = new QName("testName");
                                                                                                           int index = 0;
                                                                                                           Object value = "testValue";
                                                                                                           
                                                                                                           // Create parent node
                                                                                                           Node parentNode = mock(Node.class);
                                                                                                           DOMNodePointer parentPointer = new DOMNodePointer(parentNode, Locale.getDefault());
                                                                                                           
                                                                                                           // Mock child node creation
                                                                                                           Node childNode = mock(Node.class);
                                                                                                           when(parentNode.appendChild(any(Node.class))).thenReturn(childNode);
                                                                                                           
                                                                                                           // Call method under test
                                                                                                           NodePointer result = parentPointer.createChild(context, name, index, value);
                                                                                                           
                                                                                                           // Verify results
                                                                                                           assertNotNull("Returned pointer should not be null", result);
                                                                                                           assertEquals("Value should be set correctly", value, result.getValue());
                                                                                                           
                                                                                                           // Verify node was properly used (this would fail if node was mutated to null)
                                                                                                           verify(parentNode).appendChild(any(Node.class));
                                                                                                           
                                                                                                           // Additional verification that the created pointer maintains parent relationship
                                                                                                           assertSame("Parent node should be properly set", 
                                                                                                                     parentPointer, result.getParent());
                                                                                                       }

    @Test
                                                                                                  public void testCreateChildWithNullNodeShouldFail() {
                                                                                                      // Define required variables
                                                                                                      DOMNodePointer pointer = new DOMNodePointer((Node) null, null);
                                                                                                      JXPathContext context = mock(JXPathContext.class);
                                                                                                      QName name = mock(QName.class);
                                                                                                      
                                                                                                      // Setup expected exception using JUnit 4 rule
                                                                                                      ExpectedException exceptionRule = ExpectedException.none();
                                                                                                      exceptionRule.expect(NullPointerException.class);
                                                                                                      exceptionRule.expectMessage("Cannot create child on null node");
                                                                                                      
                                                                                                      // Call method with null node (mutated case)
                                                                                                      pointer.createChild(context, name, 0);
                                                                                                      
                                                                                                      // Verify interactions
                                                                                                      verify(name).toString();
                                                                                                      // No other interactions should occur with context since it should fail early
                                                                                                  }

    @Test
                                                                                              public void testCreateChildSetsValueWhenSuccessful() {
                                                                                                  // Setup test data
                                                                                                  JXPathContext context = mock(JXPathContext.class);
                                                                                                  QName name = new QName("testName");
                                                                                                  int index = 0;
                                                                                                  Object value = "testValue";
                                                                                                  
                                                                                                  // Mock the child node pointer that will be created
                                                                                                  NodePointer childPointer = mock(NodePointer.class);
                                                                                                  
                                                                                                  // Create instance of class under test
                                                                                                  Node testNode = mock(Node.class);
                                                                                                  DOMNodePointer pointer = new DOMNodePointer(testNode, Locale.getDefault());
                                                                                                  
                                                                                                  // Mock the createChild method to return our mock pointer
                                                                                                  // (Assuming this is how the method works internally)
                                                                                                  when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                                                                  
                                                                                                  // Execute the method
                                                                                                  NodePointer result = pointer.createChild(context, name, index, value);
                                                                                                  
                                                                                                  // Verify the value was set on the child pointer
                                                                                                  verify(childPointer).setValue(value);
                                                                                                  
                                                                                                  // Verify the correct pointer was returned
                                                                                                  assertEquals(childPointer, result);
                                                                                              }

    @Test
                                                                                             public void testCreateChildWhenFactorySucceeds() throws Exception {
                                                                                                 // Setup test data
                                                                                                 JXPathContext context = mock(JXPathContext.class);
                                                                                                 QName name = new QName("test");
                                                                                                 int index = 0;
                                                                                                 
                                                                                                 // Mock the DOMNodePointer and its dependencies
                                                                                                 DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                                                                 AbstractFactory factory = mock(AbstractFactory.class);
                                                                                                 Node node = mock(Node.class);
                                                                                                 NodeIterator iterator = mock(NodeIterator.class);
                                                                                                 NodePointer expectedPointer = mock(NodePointer.class);
                                                                                                 
                                                                                                 // Use reflection to access private getAbstractFactory method
                                                                                                 Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                                                                                 getAbstractFactoryMethod.setAccessible(true);
                                                                                                 
                                                                                                 // Stub method calls
                                                                                                 when(getAbstractFactoryMethod.invoke(pointer, context)).thenReturn(factory);
                                                                                                 when(factory.createObject(context, pointer, node, "test", index))
                                                                                                     .thenReturn(true); // Factory succeeds
                                                                                                 when(pointer.childIterator(any(NodeTest.class), eq(false), eq(null)))
                                                                                                     .thenReturn(iterator);
                                                                                                 when(iterator.setPosition(index + 1)).thenReturn(true);
                                                                                                 when(iterator.getNodePointer()).thenReturn(expectedPointer);
                                                                                                 
                                                                                                 // Call the method under test
                                                                                                 NodePointer result = pointer.createChild(context, name, index);
                                                                                                 
                                                                                                 // Verify behavior
                                                                                                 assertSame(expectedPointer, result); // Should return the created node pointer
                                                                                                 verify(factory).createObject(context, pointer, node, "test", index);
                                                                                                 verify(iterator).setPosition(index + 1);
                                                                                             }

    @Test
                                                                                             public void testCreateChildWithNullNodeTest() {
                                                                                                 // Setup
                                                                                                 Node mockNode = mock(Node.class);
                                                                                                 JXPathContext mockContext = mock(JXPathContext.class);
                                                                                                 QName mockQName = mock(QName.class);
                                                                                                 int index = 1;
                                                                                                 Object value = "testValue";
                                                                                                 
                                                                                                 // Create test instance
                                                                                                 DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                                 
                                                                                                 // Mock the createChild that returns NodePointer
                                                                                                 NodePointer mockChildPointer = mock(NodePointer.class);
                                                                                                 when(pointer.createChild(mockContext, mockQName, index)).thenReturn(mockChildPointer);
                                                                                                 
                                                                                                 // Execute
                                                                                                 NodePointer result = pointer.createChild(mockContext, mockQName, index, value);
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertNotNull(result);
                                                                                                 assertEquals(mockChildPointer, result);
                                                                                                 verify(mockChildPointer).setValue(value);
                                                                                                 
                                                                                                 // Additional test for nodeTest behavior
                                                                                                 // This would fail if the mutation affected the testNode method behavior
                                                                                                 NodeTest nodeTest = null;
                                                                                                 boolean testResult = pointer.testNode(nodeTest);
                                                                                                 // Default behavior should be consistent regardless of how nodeTest was initialized
                                                                                                 assertFalse(testResult); // Assuming null nodeTest should return false
                                                                                             }

    @Test
                                                                                        public void testCreateChild_nodeTestInitialization() throws Exception {
                                                                                            // Setup context and mocks
                                                                                            JXPathContext context = mock(JXPathContext.class);
                                                                                            QName name = new QName("test");
                                                                                            int index = 0;
                                                                                            
                                                                                            // Create test node
                                                                                            Node node = mock(Node.class);
                                                                                            
                                                                                            // Create real instance under test (not a mock)
                                                                                            DOMNodePointer instance = new DOMNodePointer(node, Locale.getDefault());
                                                                                            
                                                                                            // Use reflection to set a mock AbstractFactory
                                                                                            AbstractFactory factory = mock(AbstractFactory.class);
                                                                                            Field factoryField = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                                                            factoryField.setAccessible(true);
                                                                                            factoryField.set(instance, factory);
                                                                                            
                                                                                            // Mock factory to return success but make child iteration fail
                                                                                            when(factory.createObject(
                                                                                                context, instance, any(Node.class), anyString(), anyInt()))
                                                                                                .thenReturn(true);
                                                                                            
                                                                                            // Mock asPath() to return expected path
                                                                                            DOMNodePointer pointerSpy = spy(instance);
                                                                                            when(pointerSpy.asPath()).thenReturn("/test");
                                                                                            when(pointerSpy.getNamespaceURI(anyString())).thenReturn("uri");
                                                                                            when(pointerSpy.getDefaultNamespaceURI()).thenReturn("defaultUri");
                                                                                            
                                                                                            // Mock childIterator to return null to simulate iteration failure
                                                                                            when(pointerSpy.childIterator(any(NodeTest.class), eq(false), isNull()))
                                                                                                .thenReturn(null);
                                                                                            
                                                                                            try {
                                                                                                // This should throw JXPathAbstractFactoryException
                                                                                                pointerSpy.createChild(context, name, index);
                                                                                                fail("Expected JXPathAbstractFactoryException");
                                                                                            } catch (JXPathAbstractFactoryException e) {
                                                                                                // Verify the exception message contains expected path info
                                                                                                assertTrue(e.getMessage().contains("/test/test[1]"));
                                                                                                throw e;
                                                                                            }
                                                                                        }

    @Test
                                                                                   public void testCreateChildNamespaceHandling() {
                                                                                       // Setup test data
                                                                                       JXPathContext context = mock(JXPathContext.class);
                                                                                       QName nameWithPrefix = new QName("testPrefix", "localName");
                                                                                       QName nameWithoutPrefix = new QName(null, "localName");
                                                                                       Object value = "testValue";
                                                                                       int index = 0;
                                                                                       
                                                                                       // Mock node and namespace behavior
                                                                                       Node mockNode = mock(Node.class);
                                                                                       Map<String, String> namespaces = new HashMap<>();
                                                                                       namespaces.put("testPrefix", "http://test.namespace");
                                                                                       
                                                                                       // Create test instance
                                                                                       DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                                                       
                                                                                       // Use reflection to set private namespaces field
                                                                                       try {
                                                                                           Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                                                                           namespacesField.setAccessible(true);
                                                                                           namespacesField.set(pointer, namespaces);
                                                                                       } catch (Exception e) {
                                                                                           fail("Failed to set namespaces field via reflection: " + e.getMessage());
                                                                                       }
                                                                                       
                                                                                       // Test case 1: With prefix - should get namespace URI in original
                                                                                       NodePointer resultWithPrefix = pointer.createChild(context, nameWithPrefix, index, value);
                                                                                       assertNotNull("Should create child with prefix", resultWithPrefix);
                                                                                       assertEquals("http://test.namespace", resultWithPrefix.getNamespaceURI());
                                                                                       
                                                                                       // Test case 2: Without prefix - should not get namespace URI in original
                                                                                       NodePointer resultWithoutPrefix = pointer.createChild(context, nameWithoutPrefix, index, value);
                                                                                       assertNotNull("Should create child without prefix", resultWithoutPrefix);
                                                                                       assertNull("Should not have namespace URI when no prefix", resultWithoutPrefix.getNamespaceURI());
                                                                                   }

    @Test
                                                                               public void testCreateChildNamespaceURILogic() throws Exception {
                                                                                   // Setup test data
                                                                                   JXPathContext context = mock(JXPathContext.class);
                                                                                   QName nameWithPrefix = new QName("testPrefix", "localName");
                                                                                   QName nameWithoutPrefix = new QName(null, "localName");
                                                                                   
                                                                                   // Mock context behavior
                                                                                   when(context.getNamespaceURI("testPrefix")).thenReturn("testNamespace");
                                                                                   when(context.getDefaultNamespaceURI()).thenReturn("defaultNamespace");
                                                                                   
                                                                                   // Create real DOMNodePointer and mock its behavior using reflection
                                                                                   Node mockNode = mock(Node.class);
                                                                                   DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ROOT);
                                                                                   
                                                                                   // Use reflection to set private abstractFactory field
                                                                                   Field factoryField = DOMNodePointer.class.getDeclaredField("abstractFactory");
                                                                                   factoryField.setAccessible(true);
                                                                                   AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                                   factoryField.set(pointer, mockFactory);
                                                                                   
                                                                                   // Mock factory behavior
                                                                                   when(mockFactory.createObject(
                                                                                       any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                                                   
                                                                                   // Mock child iterator to return a node
                                                                                   NodeIterator it = mock(NodeIterator.class);
                                                                                   when(it.setPosition(1)).thenReturn(true);
                                                                                   when(it.getNodePointer()).thenReturn(mock(NodePointer.class));
                                                                                   
                                                                                   // Create spy to verify calls
                                                                                   DOMNodePointer pointerSpy = spy(pointer);
                                                                                   when(pointerSpy.childIterator(any(), anyBoolean(), any())).thenReturn(it);
                                                                                   
                                                                                   // Test with prefix (should use prefix's namespace)
                                                                                   try {
                                                                                       pointerSpy.createChild(context, nameWithPrefix, 0);
                                                                                       // Verify correct namespace was used in node test creation
                                                                                       verify(pointerSpy).childIterator(argThat(test -> {
                                                                                           if (test instanceof NodeNameTest) {
                                                                                               NodeNameTest nameTest = (NodeNameTest) test;
                                                                                               return "testNamespace".equals(nameTest.getNamespaceURI());
                                                                                           }
                                                                                           return false;
                                                                                       }), anyBoolean(), any());
                                                                                   } catch (JXPathAbstractFactoryException e) {
                                                                                       fail("Should not throw exception for successful creation");
                                                                                   }
                                                                                   
                                                                                   // Test without prefix (should use default namespace)
                                                                                   try {
                                                                                       pointerSpy.createChild(context, nameWithoutPrefix, 0);
                                                                                       // Verify correct namespace was used in node test creation
                                                                                       verify(pointerSpy, times(2)).childIterator(argThat(test -> {
                                                                                           if (test instanceof NodeNameTest) {
                                                                                               NodeNameTest nameTest = (NodeNameTest) test;
                                                                                               return "defaultNamespace".equals(nameTest.getNamespaceURI());
                                                                                           }
                                                                                           return false;
                                                                                       }), anyBoolean(), any());
                                                                                   } catch (JXPathAbstractFactoryException e) {
                                                                                       fail("Should not throw exception for successful creation");
                                                                                   }
                                                                               }

    @Test
                                                                               public void testCreateChildWithWholeCollectionIndex2() {
                                                                                   // Setup
                                                                                   JXPathContext context = mock(JXPathContext.class);
                                                                                   QName name = new QName("test");
                                                                                   Object value = "testValue";
                                                                                   Node mockNode = mock(Node.class);
                                                                                   DOMNodePointer parentPointer = new DOMNodePointer(mockNode, null);
                                                                                   
                                                                                   // Mock the createChild call that returns a pointer
                                                                                   NodePointer expectedPointer = mock(NodePointer.class);
                                                                                   when(parentPointer.createChild(eq(context), eq(name), eq(NodePointer.WHOLE_COLLECTION)))
                                                                                       .thenReturn(expectedPointer);
                                                                                   
                                                                                   // Test
                                                                                   NodePointer result = parentPointer.createChild(context, name, NodePointer.WHOLE_COLLECTION, value);
                                                                                   
                                                                                   // Verify
                                                                                   assertEquals(expectedPointer, result);
                                                                                   verify(expectedPointer).setValue(value);
                                                                                   // This test would fail with the mutant since the mutant would handle WHOLE_COLLECTION differently
                                                                               }

    @Test
                                                                               public void testCreateChildWithSpecificIndex() {
                                                                                   // Setup
                                                                                   JXPathContext context = mock(JXPathContext.class);
                                                                                   QName name = new QName("test");
                                                                                   Object value = "testValue";
                                                                                   int specificIndex = 5;
                                                                                   Node mockNode = mock(Node.class);
                                                                                   DOMNodePointer parentPointer = new DOMNodePointer(mockNode, null);
                                                                                   
                                                                                   // Mock the createChild call that returns a pointer
                                                                                   NodePointer expectedPointer = mock(NodePointer.class);
                                                                                   when(parentPointer.createChild(eq(context), eq(name), eq(specificIndex)))
                                                                                       .thenReturn(expectedPointer);
                                                                                   
                                                                                   // Test
                                                                                   NodePointer result = parentPointer.createChild(context, name, specificIndex, value);
                                                                                   
                                                                                   // Verify
                                                                                   assertEquals(expectedPointer, result);
                                                                                   verify(expectedPointer).setValue(value);
                                                                                   // This test would also fail with the mutant since the mutant would handle specificIndex differently
                                                                               }

    @Test
                                                                          public void testCreateChildIndexHandling() throws Exception {
                                                                              // Setup test data
                                                                              final int WHOLE_COLLECTION = -1;
                                                                              JXPathContext context = mock(JXPathContext.class);
                                                                              QName name = new QName("test");
                                                                              Node node = mock(Node.class);
                                                                              
                                                                              // Mock the factory to return success
                                                                              AbstractFactory factory = mock(AbstractFactory.class);
                                                                              when(factory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
                                                                              
                                                                              // Mock child iterator to return a node
                                                                              NodeIterator iterator = mock(NodeIterator.class);
                                                                              when(iterator.setPosition(anyInt())).thenReturn(true);
                                                                              when(iterator.getNodePointer()).thenReturn(mock(NodePointer.class));
                                                                              
                                                                              // Create test instance
                                                                              DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                              
                                                                              // Use reflection to set the factory since getAbstractFactory is private
                                                                              Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                                                                              factoryField.setAccessible(true);
                                                                              factoryField.set(pointer, factory);
                                                                              
                                                                              // Mock child iterator behavior
                                                                              DOMNodePointer spyPointer = spy(pointer);
                                                                              when(spyPointer.childIterator(any(), anyBoolean(), any())).thenReturn(iterator);
                                                                              
                                                                              // Case 1: Test WHOLE_COLLECTION case (index = -1)
                                                                              // Should reset to 0 before calling createObject
                                                                              spyPointer.createChild(context, name, WHOLE_COLLECTION);
                                                                              
                                                                              // Verify createObject was called with index 0 (not -1)
                                                                              verify(factory).createObject(
                                                                                  eq(context), 
                                                                                  eq(spyPointer), 
                                                                                  eq(node), 
                                                                                  eq("test"), 
                                                                                  eq(0)
                                                                              );
                                                                              
                                                                              // Case 2: Test normal index case (index = 2)
                                                                              // Should keep original index
                                                                              spyPointer.createChild(context, name, 2);
                                                                              
                                                                              // Verify createObject was called with original index 2
                                                                              verify(factory).createObject(
                                                                                  eq(context), 
                                                                                  eq(spyPointer), 
                                                                                  eq(node), 
                                                                                  eq("test"), 
                                                                                  eq(2)
                                                                              );
                                                                          }

    @Test(expected = NullPointerException.class)
                                                                          public void testCreateChildWithNullNode() {
                                                                              // Setup
                                                                              Node mockNode = null; // Mutant sets node to null
                                                                              QName name = new QName("test");
                                                                              Object value = "testValue";
                                                                              int index = 0;
                                                                              
                                                                              // Mock context
                                                                              JXPathContext context = mock(JXPathContext.class);
                                                                              
                                                                              // Create pointer with null node
                                                                              DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                              
                                                                              // This should throw NullPointerException when node is null (mutant case)
                                                                              pointer.createChild(context, name, index, value);
                                                                              
                                                                              // If we get here, the test fails (original code would proceed)
                                                                              fail("Expected NullPointerException when node is null");
                                                                          }

    @Test
                                                                          public void testCreateChildWithValidNode() {
                                                                              // Setup
                                                                              Node mockNode = mock(Node.class);
                                                                              QName name = new QName("test");
                                                                              Object value = "testValue";
                                                                              int index = 0;
                                                                              
                                                                              // Mock context and child pointer
                                                                              JXPathContext context = mock(JXPathContext.class);
                                                                              NodePointer childPointer = mock(NodePointer.class);
                                                                              
                                                                              // Create pointer with valid node
                                                                              DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                                                                              
                                                                              // Mock createChild to return our mock pointer
                                                                              when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                                              
                                                                              // Execute
                                                                              NodePointer result = pointer.createChild(context, name, index, value);
                                                                              
                                                                              // Verify
                                                                              assertNotNull("Returned pointer should not be null", result);
                                                                              verify(childPointer).setValue(value);
                                                                          }

    @Test
                                                                     public void testCreateChildWithNullNode1() throws Exception {
                                                                         // Setup test data
                                                                         JXPathContext context = mock(JXPathContext.class);
                                                                         QName name = new QName("testName");
                                                                         int index = 1;
                                                                         
                                                                         // Create pointer with null node
                                                                         DOMNodePointer pointer = new DOMNodePointer(null, Locale.ENGLISH);
                                                                         
                                                                         // Use reflection to access private getAbstractFactory method
                                                                         Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod(
                                                                             "getAbstractFactory", JXPathContext.class);
                                                                         getAbstractFactoryMethod.setAccessible(true);
                                                                         
                                                                         // Mock the abstract factory to return false (creation failure)
                                                                         AbstractFactory mockFactory = mock(AbstractFactory.class);
                                                                         when(mockFactory.createObject(
                                                                             any(JXPathContext.class), 
                                                                             any(DOMNodePointer.class), 
                                                                             any(Node.class), 
                                                                             anyString(), 
                                                                             anyInt())).thenReturn(false);
                                                                         
                                                                         // Stub the getAbstractFactory method to return our mock factory
                                                                         when(getAbstractFactoryMethod.invoke(pointer, context)).thenReturn(mockFactory);
                                                                         
                                                                         // Mock asPath() to return a known path
                                                                         when(pointer.asPath()).thenReturn("/test/path");
                                                                         
                                                                         // Execute and verify
                                                                         try {
                                                                             pointer.createChild(context, name, index);
                                                                         } catch (JXPathAbstractFactoryException e) {
                                                                             // Verify exception message contains expected path info
                                                                             assertTrue(e.getMessage().contains("/test/path"));
                                                                             assertTrue(e.getMessage().contains("testName"));
                                                                             assertTrue(e.getMessage().contains("2")); // index + 1
                                                                             throw e;
                                                                         }
                                                                     }

    @Test
                                                                 public void testCreateChildSetsValueWhenSuccessful1() {
                                                                     // Setup
                                                                     Node mockNode = mock(Node.class);
                                                                     JXPathContext mockContext = mock(JXPathContext.class);
                                                                     QName name = new QName("testName");
                                                                     Object value = "testValue";
                                                                     
                                                                     // Create test instance
                                                                     DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                                                                     
                                                                     // Mock the child creation to be successful
                                                                     NodePointer mockChildPointer = mock(NodePointer.class);
                                                                     when(pointer.createChild(mockContext, name, 0)).thenReturn(mockChildPointer);
                                                                     
                                                                     // Execute
                                                                     NodePointer result = pointer.createChild(mockContext, name, 0, value);
                                                                     
                                                                     // Verify
                                                                     // Original behavior: value should be set to child pointer
                                                                     // Mutant behavior: value won't be set
                                                                     verify(mockChildPointer).setValue(value);
                                                                     assertSame(mockChildPointer, result);
                                                                 }

    @Test
                                                            public void testCreateChildWhenFactorySucceeds1() throws Exception {
                                                                // Setup test data
                                                                JXPathContext context = mock(JXPathContext.class);
                                                                QName name = new QName("test");
                                                                int index = 0;
                                                                
                                                                // Mock the DOMNodePointer and its dependencies
                                                                Node node = mock(Node.class);
                                                                DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                                                                
                                                                // Mock the factory to return success (true)
                                                                AbstractFactory factory = mock(AbstractFactory.class);
                                                                
                                                                // Use reflection to set the factory since getAbstractFactory is private
                                                                Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                                                getAbstractFactoryMethod.setAccessible(true);
                                                                getAbstractFactoryMethod.invoke(pointer, context);
                                                                
                                                                // Mock the factory behavior
                                                                when(factory.createObject(context, pointer, node, "test", index)).thenReturn(true);
                                                                
                                                                // Mock the child iterator to return a valid node
                                                                NodeIterator iterator = mock(NodeIterator.class);
                                                                when(iterator.setPosition(index + 1)).thenReturn(true);
                                                                NodePointer childPointer = mock(NodePointer.class);
                                                                when(iterator.getNodePointer()).thenReturn(childPointer);
                                                                
                                                                // Mock the node test creation path
                                                                when(name.toString()).thenReturn("test");
                                                                when(name.getPrefix()).thenReturn(null);
                                                                when(context.getDefaultNamespaceURI()).thenReturn("uri");
                                                                when(pointer.childIterator(any(NodeTest.class), eq(false), isNull(NodePointer.class)))
                                                                    .thenReturn(iterator);
                                                                
                                                                // Execute and verify
                                                                NodePointer result = pointer.createChild(context, name, index);
                                                                assertNotNull("Should return a node pointer when factory succeeds", result);
                                                                assertEquals("Should return the created child pointer", childPointer, result);
                                                                
                                                                // Verify the factory was called
                                                                verify(factory).createObject(context, pointer, node, "test", index);
                                                            }

    @Test
                                                       public void testCreateChildNamespaceHandling1() throws Exception {
                                                           // Setup test data
                                                           JXPathContext context = mock(JXPathContext.class);
                                                           QName name = new QName("prefix", "localName");
                                                           int index = 0;
                                                           Node node = mock(Node.class);
                                                           
                                                           // Mock the DOMNodePointer
                                                           DOMNodePointer pointer = mock(DOMNodePointer.class);
                                                           
                                                           // Use reflection to mock the private getAbstractFactory method
                                                           Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod(
                                                               "getAbstractFactory", 
                                                               JXPathContext.class
                                                           );
                                                           getAbstractFactoryMethod.setAccessible(true);
                                                           when(getAbstractFactoryMethod.invoke(pointer, context)).thenReturn(mock(AbstractFactory.class));
                                                           
                                                           when(pointer.childIterator(any(), anyBoolean(), any())).thenReturn(mock(NodeIterator.class));
                                                           when(pointer.asPath()).thenReturn("/test/path");
                                                           
                                                           // Mock context behavior
                                                           when(context.getNamespaceURI("prefix")).thenReturn("expectedURI");
                                                           when(context.getDefaultNamespaceURI()).thenReturn("defaultURI");
                                                           
                                                           // Test case 1: With prefix (should use getNamespaceURI)
                                                           try {
                                                               // Call the method (using reflection since it's protected)
                                                               Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                   "createChild", 
                                                                   JXPathContext.class, 
                                                                   QName.class, 
                                                                   int.class
                                                               );
                                                               method.setAccessible(true);
                                                               method.invoke(pointer, context, name, index);
                                                               
                                                               // Verify namespace handling
                                                               verify(context).getNamespaceURI("prefix");
                                                               verify(context, never()).getDefaultNamespaceURI();
                                                           } catch (Exception e) {
                                                               fail("Test failed with exception: " + e.getMessage());
                                                           }
                                                           
                                                           // Test case 2: Without prefix (should use default namespace)
                                                           QName nameNoPrefix = new QName(null, "localName");
                                                           try {
                                                               Method method = DOMNodePointer.class.getDeclaredMethod(
                                                                   "createChild", 
                                                                   JXPathContext.class, 
                                                                   QName.class, 
                                                                   int.class
                                                               );
                                                               method.setAccessible(true);
                                                               method.invoke(pointer, context, nameNoPrefix, index);
                                                               
                                                               // Verify namespace handling
                                                               verify(context).getDefaultNamespaceURI();
                                                               verify(context, never()).getNamespaceURI(null);
                                                           } catch (Exception e) {
                                                               fail("Test failed with exception: " + e.getMessage());
                                                           }
                                                       }

    @Test
                                                       public void testCreateChildNamespaceHandling2() throws Exception {
                                                           // Setup context and mocks
                                                           JXPathContext context = mock(JXPathContext.class);
                                                           QName prefixedName = new QName("test", "prefixedName");
                                                           QName nonPrefixedName = new QName(null, "simpleName");
                                                           Object value = "testValue";
                                                           
                                                           // Mock node and namespaces
                                                           Node mockNode = mock(Node.class);
                                                           Map<String, String> namespaces = new HashMap<>();
                                                           namespaces.put("test", "http://test.namespace");
                                                           String defaultNs = "http://default.namespace";
                                                           
                                                           // Create test instance
                                                           DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
                                                           
                                                           // Use reflection to set private fields
                                                           Field namespacesField = DOMNodePointer.class.getDeclaredField("namespaces");
                                                           namespacesField.setAccessible(true);
                                                           namespacesField.set(pointer, namespaces);
                                                           
                                                           Field defaultNamespaceField = DOMNodePointer.class.getDeclaredField("defaultNamespace");
                                                           defaultNamespaceField.setAccessible(true);
                                                           defaultNamespaceField.set(pointer, defaultNs);
                                                           
                                                           // Mock the createChild call that returns a pointer
                                                           NodePointer mockChildPointer = mock(NodePointer.class);
                                                           when(pointer.createChild(context, prefixedName, 0)).thenReturn(mockChildPointer);
                                                           when(pointer.createChild(context, nonPrefixedName, 0)).thenReturn(mockChildPointer);
                                                           
                                                           // Test with prefixed name (should use namespace from namespaces map)
                                                           NodePointer result1 = pointer.createChild(context, prefixedName, 0, value);
                                                           verify(mockChildPointer).setValue(value);
                                                           // Verify namespace handling for prefixed name was correct
                                                           // The mutant would fail here as it would check prefix == null
                                                           
                                                           // Test with non-prefixed name (should use default namespace)
                                                           NodePointer result2 = pointer.createChild(context, nonPrefixedName, 0, value);
                                                           verify(mockChildPointer, times(2)).setValue(value);
                                                           // Verify namespace handling for non-prefixed name was correct
                                                           // The mutant would fail here as it would check prefix == null
                                                           
                                                           // Additional verification could check the actual namespace URI used
                                                           // but that would require more mocking of the createChild implementation
                                                       }

    @Test
                                                   public void testCreateChild_DetectsNamespaceURIMutation() {
                                                       // Setup test context with known default namespace
                                                       JXPathContext context = mock(JXPathContext.class);
                                                       when(context.getDefaultNamespaceURI()).thenReturn("http://example.com/ns");
                                                       
                                                       // Setup test data
                                                       QName name = new QName("test");
                                                       int index = 0;
                                                       Object value = "testValue";
                                                       
                                                       // Create test node and pointer
                                                       Node testNode = mock(Node.class);
                                                       DOMNodePointer pointer = new DOMNodePointer(testNode, Locale.ENGLISH);
                                                       
                                                       // Mock the child pointer creation
                                                       DOMNodePointer childPointer = mock(DOMNodePointer.class);
                                                       when(pointer.createChild(context, name, index)).thenReturn(childPointer);
                                                       
                                                       // Call the method under test
                                                       NodePointer result = pointer.createChild(context, name, index, value);
                                                       
                                                       // Verify the namespace handling
                                                       verify(context).getDefaultNamespaceURI();
                                                       verify(childPointer).setValue(value);
                                                       
                                                       // Assert the returned pointer is correct
                                                       assertEquals(childPointer, result);
                                                       
                                                       // Additional verification that would catch the mutant
                                                       // The mutant would fail here because it wouldn't call getDefaultNamespaceURI()
                                                       verify(context, atLeastOnce()).getDefaultNamespaceURI();
                                                   }

    @Test
                                  public void testCreateChild_WithNullPrefix_UsesDefaultNamespace() throws Exception {
                                      // Setup test data
                                      JXPathContext context = mock(JXPathContext.class);
                                      QName name = new QName(null, "testName"); // null prefix
                                      int index = 0;
                                      Node node = mock(Node.class);
                                      DOMNodePointer pointer = mock(DOMNodePointer.class);
                                      
                                      // Mock behavior
                                      when(context.getDefaultNamespaceURI()).thenReturn("http://default-namespace");
                                      
                                      // Mock getAbstractFactory method
                                      AbstractFactory factory = mock(AbstractFactory.class);
                                      Method getAbstractFactory = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                      getAbstractFactory.setAccessible(true);
                                      when(getAbstractFactory.invoke(pointer, context)).thenReturn(factory);
                                      when(factory.createObject(context, pointer, node, "testName", index)).thenReturn(true);
                                      
                                      // Mock child iterator
                                      NodeIterator it = mock(NodeIterator.class);
                                      when(it.setPosition(index + 1)).thenReturn(true);
                                      NodePointer expectedPointer = mock(NodePointer.class);
                                      when(it.getNodePointer()).thenReturn(expectedPointer);
                                      
                                      // Mock childIterator method
                                      Method childIterator = DOMNodePointer.class.getDeclaredMethod("childIterator", 
                                          NodeTest.class, boolean.class, NodePointer.class);
                                      childIterator.setAccessible(true);
                                      when(childIterator.invoke(pointer, any(NodeTest.class), eq(false), isNull(NodePointer.class)))
                                          .thenReturn(it);
                                      
                                      // Execute createChild method
                                      Method createChild = DOMNodePointer.class.getDeclaredMethod("createChild", 
                                          JXPathContext.class, QName.class, int.class);
                                      createChild.setAccessible(true);
                                      NodePointer result = (NodePointer) createChild.invoke(pointer, context, name, index);
                                      
                                      // Verify namespace handling
                                      org.mockito.ArgumentCaptor<NodeTest> nodeTestCaptor = org.mockito.ArgumentCaptor.forClass(NodeTest.class);
                                      verify(childIterator).invoke(eq(pointer), nodeTestCaptor.capture(), eq(false), isNull(NodePointer.class));
                                      
                                      NodeNameTest createdTest = (NodeNameTest) nodeTestCaptor.getValue();
                                      assertEquals("http://default-namespace", createdTest.getNamespaceURI());
                                      assertEquals(expectedPointer, result);
                                  }

    @Test
                             public void testCreateChildWithWholeCollectionIndex3() throws Exception {
                                 // Setup test data
                                 final int WHOLE_COLLECTION = -1;
                                 JXPathContext context = mock(JXPathContext.class);
                                 QName name = new QName("test");
                                 Node node = mock(Node.class);
                                 
                                 // Mock the DOMNodePointer and its behavior
                                 DOMNodePointer pointer = mock(DOMNodePointer.class);
                                 
                                 // Create a mock AbstractFactory
                                 AbstractFactory mockFactory = mock(AbstractFactory.class);
                                 
                                 // Use reflection to set up the private getAbstractFactory method
                                 Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                                 getAbstractFactoryMethod.setAccessible(true);
                                 when(getAbstractFactoryMethod.invoke(pointer, context)).thenReturn(mockFactory);
                                 
                                 when(mockFactory.createObject(
                                     any(JXPathContext.class), 
                                     any(DOMNodePointer.class), 
                                     any(Node.class), 
                                     anyString(), 
                                     anyInt())).thenReturn(true);
                                 
                                 // Mock the child iterator behavior
                                 NodeIterator mockIterator = mock(NodeIterator.class);
                                 when(mockIterator.setPosition(1)).thenReturn(true);
                                 NodePointer expectedPointer = mock(NodePointer.class);
                                 when(mockIterator.getNodePointer()).thenReturn(expectedPointer);
                                 when(pointer.childIterator(any(NodeTest.class), anyBoolean(), isNull()))
                                     .thenReturn(mockIterator);
                                 
                                 // Mock namespace-related behavior
                                 when(pointer.getNamespaceURI(anyString())).thenReturn("testURI");
                                 when(pointer.getDefaultNamespaceURI()).thenReturn("defaultURI");
                                 when(pointer.asPath()).thenReturn("/test/path");
                                 
                                 // Call the method with WHOLE_COLLECTION index
                                 NodePointer result = pointer.createChild(context, name, WHOLE_COLLECTION);
                                 
                                 // Verify the behavior
                                 verify(mockFactory).createObject(
                                     context, 
                                     pointer, 
                                     node, 
                                     "test", 
                                     0);
                                 
                                 // Verify the correct pointer is returned
                                 assertEquals(expectedPointer, result);
                                 
                                 // Also test the exception case when creation fails
                                 when(mockFactory.createObject(
                                     any(JXPathContext.class), 
                                     any(DOMNodePointer.class), 
                                     any(Node.class), 
                                     anyString(), 
                                     anyInt())).thenReturn(false);
                                 
                                 try {
                                     pointer.createChild(context, name, WHOLE_COLLECTION);
                                     fail("Expected JXPathAbstractFactoryException");
                                 } catch (JXPathAbstractFactoryException e) {
                                     assertTrue(e.getMessage().contains("Factory could not create a child node"));
                                 }
                             }

    @Test
                             public void testCreateChildWithWholeCollectionIndex4() {
                                 // Setup test data
                                 JXPathContext context = mock(JXPathContext.class);
                                 QName name = new QName("testName");
                                 Object value = "testValue";
                                 
                                 // Mock the createChild method to return a mock pointer
                                 DOMNodePointer pointer = mock(DOMNodePointer.class);
                                 DOMNodePointer testPointer = new DOMNodePointer(mock(Node.class), Locale.ENGLISH);
                                 
                                 // Test case 1: index is WHOLE_COLLECTION (should trigger special handling)
                                 when(pointer.createChild(context, name, DOMNodePointer.WHOLE_COLLECTION))
                                     .thenReturn(testPointer);
                                 
                                 DOMNodePointer result1 = (DOMNodePointer) pointer.createChild(context, name, DOMNodePointer.WHOLE_COLLECTION, value);
                                 verify(pointer).createChild(context, name, DOMNodePointer.WHOLE_COLLECTION);
                                 verify(testPointer).setValue(value);
                                 assertSame(testPointer, result1);
                                 
                                 // Test case 2: index is not WHOLE_COLLECTION (normal case)
                                 int normalIndex = 1;
                                 when(pointer.createChild(context, name, normalIndex))
                                     .thenReturn(testPointer);
                                 
                                 DOMNodePointer result2 = (DOMNodePointer) pointer.createChild(context, name, normalIndex, value);
                                 verify(pointer).createChild(context, name, normalIndex);
                                 verify(testPointer, times(2)).setValue(value);
                                 assertSame(testPointer, result2);
                             }

    @Test
                        public void testCreateChildWithNullParentPointer() throws Exception {
                            // Setup test data
                            JXPathContext context = mock(JXPathContext.class);
                            QName name = new QName("test");
                            int index = 0;
                            
                            // Mock the DOMNodePointer and its dependencies
                            Node node = mock(Node.class);
                            DOMNodePointer pointer = new DOMNodePointer(node, Locale.ENGLISH);
                            
                            // Mock the abstract factory to return false when parent is null
                            AbstractFactory factory = mock(AbstractFactory.class);
                            
                            // Use reflection to set the factory since getAbstractFactory is private
                            Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                            getAbstractFactoryMethod.setAccessible(true);
                            getAbstractFactoryMethod.invoke(pointer, context);
                            
                            // Mock the factory behavior
                            when(factory.createObject(context, null, node, "test", index)).thenReturn(false);
                            
                            // Mock the name.toString() to return "test"
                            when(name.toString()).thenReturn("test");
                            
                            // Mock the asPath() method to return a test path
                            when(pointer.asPath()).thenReturn("/test/path");
                            
                            // Execute - should throw exception
                            try {
                                pointer.createChild(context, name, index);
                                fail("Expected JXPathException");
                            } catch (JXPathException e) {
                                // Expected exception
                            }
                            
                            // Verify the factory was called with null instead of 'this'
                            verify(factory).createObject(context, null, node, "test", index);
                        }

    @Test
                        public void testCreateChildReturnsNonNullPointer1() {
                            // Setup test data
                            JXPathContext context = mock(JXPathContext.class);
                            QName name = new QName("http://example.com", "testElement");
                            int index = 0;
                            Object value = "testValue";
                            
                            // Create test instance (using constructor with minimal required parameters)
                            Node testNode = mock(Node.class);
                            DOMNodePointer pointer = new DOMNodePointer(testNode, null);
                            
                            // Execute method under test
                            NodePointer result = pointer.createChild(context, name, index, value);
                            
                            // Verify results
                            assertNotNull("createChild should return non-null NodePointer", result);
                            assertEquals("Returned pointer should have the set value", value, result.getValue());
                        }

    @Test(expected = NullPointerException.class)
                    public void testCreateChildWithNullNode2() throws Exception {
                        // Setup test data
                        JXPathContext context = mock(JXPathContext.class);
                        QName name = new QName("test");
                        int index = 0;
                        
                        // Mock behavior
                        when(context.getNamespaceURI(anyString())).thenReturn("http://test");
                        when(context.getDefaultNamespaceURI()).thenReturn("http://default");
                        
                        // Create test object with null node
                        DOMNodePointer pointer = new DOMNodePointer(null, Locale.getDefault());
                        
                        // This should throw NullPointerException due to null node
                        pointer.createChild(context, name, index);
                    }

    @Test(expected = NullPointerException.class)
                    public void testCreateChildWithNullNode3() throws Exception {
                        // Setup
                        Node mockNode = null; // Explicit null node
                        JXPathContext mockContext = mock(JXPathContext.class);
                        QName mockQName = mock(QName.class);
                        Object testValue = "testValue";
                        
                        // Create pointer with null node
                        DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                        
                        // This should throw NullPointerException when trying to create child on null node
                        pointer.createChild(mockContext, mockQName, 0, testValue);
                        
                        // If it doesn't throw, explicitly fail
                        fail("Expected NullPointerException when creating child on null node");
                    }

    @Test
                    public void testCreateChildWithNullNodeReturnsNull() throws Exception {
                        // Setup
                        Node mockNode = null; // Explicit null node
                        JXPathContext mockContext = mock(JXPathContext.class);
                        QName mockQName = mock(QName.class);
                        Object testValue = "testValue";
                        
                        // Create pointer with null node
                        DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.getDefault());
                        
                        // Call method
                        NodePointer result = pointer.createChild(mockContext, mockQName, 0, testValue);
                        
                        // Verify
                        assertNull("Expected null when creating child on null node", result);
                    }

    @Test(expected = JXPathAbstractFactoryException.class)
                   public void testCreateChildWithNullNode4() throws Exception {
                       // Setup test data
                       JXPathContext context = mock(JXPathContext.class);
                       QName name = new QName("test");
                       int index = 0;
                       
                       // Mock behavior
                       when(context.getNamespaceURI(anyString())).thenReturn("http://test");
                       when(context.getDefaultNamespaceURI()).thenReturn("http://default");
                       
                       // Mock abstract factory to return false (creation failed)
                       AbstractFactory factory = mock(AbstractFactory.class);
                       when(factory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(false);
                       
                       // Create test object with null node
                       DOMNodePointer pointer = new DOMNodePointer(null, Locale.getDefault());
                       
                       // Use reflection to set the factory
                       Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
                       factoryField.setAccessible(true);
                       factoryField.set(pointer, factory);
                       
                       // This should throw JXPathAbstractFactoryException
                       pointer.createChild(context, name, index);
                   }

    @Test
               public void testCreateChildSetsValue() {
                   // Setup test data
                   JXPathContext context = mock(JXPathContext.class);
                   QName name = new QName("testName");
                   int index = 0;
                   Object testValue = "testValue";
                   
                   // Mock the child node pointer that will be created
                   NodePointer mockChildPointer = mock(NodePointer.class);
                   
                   // Create partial mock of DOMNodePointer to stub createChild
                   DOMNodePointer nodePointer = mock(DOMNodePointer.class);
                   when(nodePointer.createChild(context, name, index)).thenReturn(mockChildPointer);
                   
                   // Call the method under test
                   NodePointer result = nodePointer.createChild(context, name, index, testValue);
                   
                   // Verify the child pointer was created
                   assertSame(mockChildPointer, result);
                   
                   // Verify the value was set on the child pointer - this would fail with the mutant
                   verify(mockChildPointer).setValue(testValue);
               }

    @Test
              public void testCreateChildWhenFactorySucceeds2() throws Exception {
                  // Setup test data
                  JXPathContext context = mock(JXPathContext.class);
                  QName name = new QName("test");
                  int index = 0;
                  
                  // Mock the DOMNodePointer and its dependencies
                  DOMNodePointer pointer = mock(DOMNodePointer.class);
                  Node node = mock(Node.class);
                  AbstractFactory factory = mock(AbstractFactory.class);
                  NodeIterator iterator = mock(NodeIterator.class);
                  NodePointer expectedPointer = mock(NodePointer.class);
                  
                  // Use reflection to mock the private getAbstractFactory method
                  Method getAbstractFactoryMethod = DOMNodePointer.class.getDeclaredMethod("getAbstractFactory", JXPathContext.class);
                  getAbstractFactoryMethod.setAccessible(true);
                  when(getAbstractFactoryMethod.invoke(pointer, context)).thenReturn(factory);
                  
                  // Stub method calls
                  when(factory.createObject(context, pointer, node, "test", index)).thenReturn(true);
                  when(pointer.childIterator(any(NodeTest.class), eq(false), isNull(NodePointer.class)))
                      .thenReturn(iterator);
                  when(iterator.setPosition(index + 1)).thenReturn(true);
                  when(iterator.getNodePointer()).thenReturn(expectedPointer);
                  when(pointer.asPath()).thenReturn("/test");
                  when(pointer.getNode()).thenReturn(node);
                  
                  // Call the method under test
                  NodePointer result = pointer.createChild(context, name, index);
                  
                  // Verify the results
                  assertSame(expectedPointer, result);
                  verify(factory).createObject(context, pointer, node, "test", index);
                  verify(pointer).childIterator(any(NodeTest.class), eq(false), isNull(NodePointer.class));
                  verify(iterator).setPosition(index + 1);
                  verify(iterator).getNodePointer();
                  
                  // The test will fail for the mutant because:
                  // - Mutant would skip the success path and throw exception
                  // - This test expects a node pointer to be returned
              }

    @Test
              public void testCreateChildWithNullNodeTest1() throws Exception {
                  // Setup test data
                  JXPathContext context = mock(JXPathContext.class);
                  QName name = new QName("test");
                  int index = 0;
                  Object value = "testValue";
                  
                  // Mock the node and child pointer
                  Node mockNode = mock(Node.class);
                  NodePointer mockChildPointer = mock(NodePointer.class);
                  
                  // Create test instance
                  DOMNodePointer pointer = new DOMNodePointer(mockNode, null);
                  
                  // Mock the createChild method to return our mock pointer
                  DOMNodePointer spyPointer = spy(pointer);
                  when(spyPointer.createChild(any(JXPathContext.class), any(QName.class), anyInt()))
                      .thenReturn(mockChildPointer);
                  
                  // Execute the method
                  NodePointer result = spyPointer.createChild(context, name, index, value);
                  
                  // Verify behavior
                  verify(spyPointer).createChild(context, name, index);
                  verify(mockChildPointer).setValue(value);
                  assertEquals(mockChildPointer, result);
                  
                  // Additional test to ensure nodeTest behavior
                  // This would fail if nodeTest was null and caused issues in internal processing
                  assertNotNull(result);
              }

    @Test
         public void testCreateChild_nodeTestInitialization1() throws Exception {
             // Setup
             Node mockNode = mock(Node.class);
             JXPathContext mockContext = mock(JXPathContext.class);
             QName mockQName = mock(QName.class);
             DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
             
             // Mock behavior to reach the nodeTest initialization
             when(mockContext.getNamespaceURI(anyString())).thenThrow(new NullPointerException());
             when(mockQName.toString()).thenReturn("testName");
             when(mockQName.getPrefix()).thenReturn("testPrefix");
             
             // Mock factory to return success
             AbstractFactory mockFactory = mock(AbstractFactory.class);
             when(mockFactory.createObject(any(), any(), any(), any(), anyInt())).thenReturn(true);
             
             // Use reflection to set the factory
             Field factoryField = DOMNodePointer.class.getDeclaredField("factory");
             factoryField.setAccessible(true);
             factoryField.set(pointer, mockFactory);
             
             // This should throw NPE when trying to get namespaceURI,
             // but would fail earlier if nodeTest wasn't properly initialized
             pointer.createChild(mockContext, mockQName, 0);
             
             // Verify the mock interactions
             verify(mockContext).getNamespaceURI("testPrefix");
         }

    @Test
    public void testCreateChildNamespaceHandling3() throws Exception {
        // Setup test data
        JXPathContext context = mock(JXPathContext.class);
        QName name = new QName("prefix", "localName");
        int index = 0;
        Node node = mock(Node.class);
        
        // Create a real DOMNodePointer instance instead of mocking it
        DOMNodePointer pointer = new DOMNodePointer(node, Locale.getDefault());
        
        // Mock the abstract factory behavior using reflection
        AbstractFactory factory = mock(AbstractFactory.class);
        Field field = DOMNodePointer.class.getDeclaredField("abstractFactory");
        field.setAccessible(true);
        field.set(pointer, factory);
        
        // Mock other behaviors
        when(pointer.asPath()).thenReturn("/test/path");
        when(pointer.childIterator(any(), anyBoolean(), any())).thenReturn(mock(NodeIterator.class));
        
        // Case 1: Non-null prefix - should use getNamespaceURI
        when(name.getPrefix()).thenReturn("prefix");
        when(context.getNamespaceURI("prefix")).thenReturn("expectedURI");
        when(context.getDefaultNamespaceURI()).thenReturn("wrongURI");
        
        // This will fail if mutation is present (should use getNamespaceURI)
        try {
            pointer.createChild(context, name, index);
            // Verify correct namespace was requested
            verify(context).getNamespaceURI("prefix");
        } catch (JXPathAbstractFactoryException e) {
            // Expected if factory fails, but we care about the namespace lookup
        }
        
        // Case 2: Null prefix - should use default namespace
        when(name.getPrefix()).thenReturn(null);
        when(context.getDefaultNamespaceURI()).thenReturn("defaultURI");
        
        // This will fail if mutation is present (should use getDefaultNamespaceURI)
        try {
            pointer.createChild(context, name, index);
            // Verify default namespace was requested
            verify(context).getDefaultNamespaceURI();
        } catch (JXPathAbstractFactoryException e) {
            // Expected if factory fails, but we care about the namespace lookup
        }
    }

    @Test
    public void testCreateChildNamespaceHandling4() {
        // Setup test data
        JXPathContext context = mock(JXPathContext.class);
        QName name = new QName("testPrefix", "testLocalName");
        int index = 0;
        Object value = "testValue";
        
        // Mock the DOMNodePointer behavior
        DOMNodePointer parentPointer = mock(DOMNodePointer.class);
        Node mockNode = mock(Node.class);
        DOMNodePointer childPointer = new DOMNodePointer(parentPointer, mockNode);
        
        // Mock namespace handling - this is where we'll catch the mutant
        when(parentPointer.getNamespaceURI("testPrefix")).thenReturn("expectedNamespace");
        when(parentPointer.getNamespaceURI((String)null)).thenReturn("defaultNamespace");
        
        // Create instance under test
        DOMNodePointer pointer = new DOMNodePointer(mockNode, Locale.ENGLISH);
        
        // Stub createChild to return our mock child pointer
        when(pointer.createChild(context, name, index)).thenReturn(childPointer);
        
        // Test with non-null prefix (should use prefix's namespace)
        NodePointer result = pointer.createChild(context, name, index, value);
        
        // Verify namespace handling - this will catch the mutant
        // Original: should get namespace for "testPrefix"
        // Mutant: would get namespace for null instead
        verify(parentPointer).getNamespaceURI("testPrefix");
        
        // Additional assertions
        assertEquals(childPointer, result);
        verify(childPointer).setValue(value);
        
        // Test with null prefix QName
        QName nullPrefixName = new QName(null, "testLocalName");
        pointer.createChild(context, nullPrefixName, index, value);
        
        // Verify null prefix handling
        // Original: would skip namespace lookup
        // Mutant: would incorrectly do lookup
        verify(parentPointer).getNamespaceURI((String)null);
    }


}
