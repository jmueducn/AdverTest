package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
 
public class WeekTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                public void testWeekConstructor_CurrentDate() {
                                    // Create a Week object with current date
                                    Week week = new Week();
                                    
                                    // Verify the year is set correctly
                                    Calendar cal = Calendar.getInstance();
                                    int expectedYear = cal.get(Calendar.YEAR);
                                    assertEquals(expectedYear, week.getYearValue());
                                    
                                    // Verify week number is within valid range
                                    int weekNumber = week.getWeek();
                                    assertTrue(weekNumber >= Week.FIRST_WEEK_IN_YEAR && weekNumber <= Week.LAST_WEEK_IN_YEAR);
                                    
                                    // Verify first and last millisecond are set
                                    assertTrue(week.getFirstMillisecond() > 0);
                                    assertTrue(week.getLastMillisecond() > 0);
                                    assertTrue(week.getLastMillisecond() > week.getFirstMillisecond());
                                }

    @Test
                                public void testWeekConstructor_EdgeCase_FirstWeekOfYear() {
                                    // Set up a date that's definitely in the first week of a year
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(Calendar.YEAR, 2023);
                                    cal.set(Calendar.MONTH, Calendar.JANUARY);
                                    cal.set(Calendar.DAY_OF_MONTH, 1);
                                    Date firstWeekDate = cal.getTime();
                                    
                                    // Create Week object with this date (using reflection since we don't have this constructor)
                                    Week week = new Week(firstWeekDate);
                                    
                                    assertEquals(2023, week.getYearValue());
                                    assertEquals(Week.FIRST_WEEK_IN_YEAR, week.getWeek());
                                }

    @Test
                                public void testWeekConstructor_EdgeCase_LastWeekOfYear() {
                                    // Set up a date that's definitely in the last week of a year
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(Calendar.YEAR, 2023);
                                    cal.set(Calendar.MONTH, Calendar.DECEMBER);
                                    cal.set(Calendar.DAY_OF_MONTH, 31);
                                    Date lastWeekDate = cal.getTime();
                                    
                                    // Create Week object with this date (using reflection since we don't have this constructor)
                                    Week week = new Week(lastWeekDate);
                                    
                                    assertEquals(2023, week.getYearValue());
                                    assertEquals(Week.LAST_WEEK_IN_YEAR, week.getWeek());
                                }

    @Test
                                public void testWeekConstructor_NullDate() {
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Null 'time' argument.");
                                    
                                    // This would require access to the constructor that takes a Date parameter
                                    // Since we don't have direct access, we'll test the behavior through reflection
                                    // In a real test, you would call: new Week(null);
                                    
                                    // For demonstration purposes, we'll simulate this with reflection
                                    try {
                                        Week.class.getConstructor(Date.class).newInstance((Date)null);
                                    } catch (Exception e) {
                                        if (e.getCause() instanceof IllegalArgumentException) {
                                            throw (IllegalArgumentException) e.getCause();
                                        }
                                        fail("Unexpected exception: " + e);
                                    }
                                }

    @Test
                                public void testConstructor_ValidWeekValues() {
                                    // Test minimum valid week
                                    Week weekMin = new Week(Week.FIRST_WEEK_IN_YEAR, 2023);
                                    assertEquals(Week.FIRST_WEEK_IN_YEAR, weekMin.getWeek());
                                    assertEquals(2023, weekMin.getYearValue());
                                    
                                    // Test maximum valid week
                                    Week weekMax = new Week(Week.LAST_WEEK_IN_YEAR, 2023);
                                    assertEquals(Week.LAST_WEEK_IN_YEAR, weekMax.getWeek());
                                    assertEquals(2023, weekMax.getYearValue());
                                    
                                    // Test middle range week
                                    Week weekMid = new Week(26, 2023);
                                    assertEquals(26, weekMid.getWeek());
                                    assertEquals(2023, weekMid.getYearValue());
                                }

    @Test
                                public void testConstructor_WeekBelowMinimum() {
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("The 'week' argument must be in the range 1 - 53.");
                                    new Week(Week.FIRST_WEEK_IN_YEAR - 1, 2023);
                                }

    @Test
                                public void testConstructor_WeekAboveMaximum() {
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("The 'week' argument must be in the range 1 - 53.");
                                    new Week(Week.LAST_WEEK_IN_YEAR + 1, 2023);
                                }

    @Test
                                public void testConstructor_YearEdgeCases() {
                                    // Test minimum year (assuming short can handle this)
                                    Week weekMinYear = new Week(1, Short.MIN_VALUE);
                                    assertEquals(1, weekMinYear.getWeek());
                                    assertEquals(Short.MIN_VALUE, weekMinYear.getYearValue());
                                    
                                    // Test maximum year
                                    Week weekMaxYear = new Week(1, Short.MAX_VALUE);
                                    assertEquals(1, weekMaxYear.getWeek());
                                    assertEquals(Short.MAX_VALUE, weekMaxYear.getYearValue());
                                    
                                    // Test year 0 (if historically relevant)
                                    Week weekZeroYear = new Week(1, 0);
                                    assertEquals(1, weekZeroYear.getWeek());
                                    assertEquals(0, weekZeroYear.getYearValue());
                                }

    @Test
                                public void testConstructor_PeggingBehavior() {
                                    // Create a Week instance
                                    Week week = new Week(10, 2023);
                                    
                                    // Verify peg() was called by checking millisecond fields are set
                                    assertTrue("firstMillisecond should be set", week.getFirstMillisecond() != 0);
                                    assertTrue("lastMillisecond should be set", week.getLastMillisecond() != 0);
                                    
                                    // Verify the milliseconds are in proper order
                                    assertTrue("firstMillisecond should be before lastMillisecond", 
                                        week.getFirstMillisecond() < week.getLastMillisecond());
                                }

    @Test
                                public void testConstructor_FieldCasting() {
                                    // Test that week is properly cast to byte
                                    Week week = new Week(Byte.MAX_VALUE, 2023);
                                    assertEquals(Byte.MAX_VALUE, week.getWeek());
                                    
                                    // Test that year is properly cast to short
                                    Week year = new Week(1, Short.MAX_VALUE);
                                    assertEquals(Short.MAX_VALUE, year.getYearValue());
                                }

    @Test
                                public void testConstructor_ValidWeekValues1() {
                                    // Mock Year object
                                    Year mockYear = mock(Year.class);
                                    when(mockYear.getYear()).thenReturn(2023);
                                    
                                    // Test first valid week
                                    Week week1 = new Week(Week.FIRST_WEEK_IN_YEAR, mockYear);
                                    assertEquals(Week.FIRST_WEEK_IN_YEAR, week1.getWeek());
                                    assertEquals(2023, week1.getYearValue());
                                    
                                    // Test last valid week
                                    Week week2 = new Week(Week.LAST_WEEK_IN_YEAR, mockYear);
                                    assertEquals(Week.LAST_WEEK_IN_YEAR, week2.getWeek());
                                    assertEquals(2023, week2.getYearValue());
                                    
                                    // Test middle week
                                    Week week3 = new Week(26, mockYear);
                                    assertEquals(26, week3.getWeek());
                                    assertEquals(2023, week3.getYearValue());
                                }

    @Test
                                public void testConstructor_WeekBelowFirstWeek_ThrowsException() {
                                    Year mockYear = mock(Year.class);
                                    when(mockYear.getYear()).thenReturn(2023);
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("The 'week' argument must be in the range 1 - 53.");
                                    
                                    new Week(Week.FIRST_WEEK_IN_YEAR - 1, mockYear);
                                }

    @Test
                                public void testConstructor_WeekAboveLastWeek_ThrowsException() {
                                    Year mockYear = mock(Year.class);
                                    when(mockYear.getYear()).thenReturn(2023);
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("The 'week' argument must be in the range 1 - 53.");
                                    
                                    new Week(Week.LAST_WEEK_IN_YEAR + 1, mockYear);
                                }

    @Test
                                public void testConstructor_NullYear_ThrowsException() {
                                    thrown.expect(NullPointerException.class);
                                    new Week(1, null);
                                }

    @Test
                                public void testConstructor_VerifyPegCalled() {
                                    Year mockYear = mock(Year.class);
                                    when(mockYear.getYear()).thenReturn(2023);
                                    
                                    // We can't easily verify peg() was called since it's private and affects internal state
                                    // But we can verify the year was properly set
                                    Week week = new Week(1, mockYear);
                                    assertEquals(2023, week.getYearValue());
                                }

    @Test
                                public void testConstructor_YearValueProperlyConverted() {
                                    Year mockYear = mock(Year.class);
                                    when(mockYear.getYear()).thenReturn(9999); // Test max possible year
                                    
                                    Week week = new Week(1, mockYear);
                                    assertEquals(9999, week.getYearValue());
                                    
                                    when(mockYear.getYear()).thenReturn(0); // Test min possible year
                                    week = new Week(1, mockYear);
                                    assertEquals(0, week.getYearValue());
                                }

    @Test
                                public void testConstructor_WeekValueProperlyConverted() {
                                    Year mockYear = mock(Year.class);
                                    when(mockYear.getYear()).thenReturn(2023);
                                    
                                    // Test max week value
                                    Week week = new Week(Byte.MAX_VALUE, mockYear);
                                    assertEquals(Byte.MAX_VALUE, week.getWeek());
                                    
                                    // Test min week value (should be FIRST_WEEK_IN_YEAR)
                                    week = new Week(Byte.MIN_VALUE, mockYear);
                                    // This should throw exception since Byte.MIN_VALUE is certainly < FIRST_WEEK_IN_YEAR
                                }

    @Test
                                public void testConstructorWithCurrentDate() {
                                    // Test with current date
                                    Date now = new Date();
                                    Week week = new Week(now);
                                    
                                    Calendar calendar = Calendar.getInstance();
                                    calendar.setTime(now);
                                    int expectedWeek = calendar.get(Calendar.WEEK_OF_YEAR);
                                    int expectedYear = calendar.get(Calendar.YEAR);
                                    
                                    assertEquals(expectedYear, week.getYearValue());
                                    assertEquals(expectedWeek, week.getWeek());
                                    assertTrue(week.getFirstMillisecond() <= now.getTime());
                                    assertTrue(week.getLastMillisecond() >= now.getTime());
                                }

    @Test
                                public void testConstructorWithFirstWeekOfYear() {
                                    // Test with first week of a year
                                    Calendar calendar = Calendar.getInstance();
                                    calendar.set(Calendar.YEAR, 2023);
                                    calendar.set(Calendar.MONTH, Calendar.JANUARY);
                                    calendar.set(Calendar.DAY_OF_MONTH, 1);
                                    Date date = calendar.getTime();
                                    
                                    Week week = new Week(date);
                                    
                                    assertEquals(2023, week.getYearValue());
                                    assertEquals(1, week.getWeek());
                                }

    @Test
                                public void testConstructorWithLastWeekOfYear() {
                                    // Test with last week of a year
                                    Calendar calendar = Calendar.getInstance();
                                    calendar.set(Calendar.YEAR, 2023);
                                    calendar.set(Calendar.MONTH, Calendar.DECEMBER);
                                    calendar.set(Calendar.DAY_OF_MONTH, 31);
                                    Date date = calendar.getTime();
                                    
                                    Week week = new Week(date);
                                    
                                    // The exact week number might vary based on locale, but should be either 52 or 53
                                    assertTrue(week.getWeek() == 52 || week.getWeek() == 53);
                                    assertEquals(2023, week.getYearValue());
                                }

    @Test
                                public void testConstructorWithNullDate() {
                                    // Test with null date
                                    thrown.expect(IllegalArgumentException.class);
                                    new Week(null);
                                }

    @Test
                                public void testConstructorWithDateInDifferentLocale() {
                                    // Test with a date that falls in different weeks in different locales
                                    Calendar calendar = Calendar.getInstance();
                                    calendar.set(Calendar.YEAR, 2023);
                                    calendar.set(Calendar.MONTH, Calendar.JANUARY);
                                    calendar.set(Calendar.DAY_OF_MONTH, 1);
                                    Date date = calendar.getTime();
                                    
                                    // US locale typically considers week starting on Sunday
                                    Week weekUS = new Week(date);
                                    
                                    // Change to a locale where week starts on Monday (like France)
                                    Locale.setDefault(Locale.FRANCE);
                                    Week weekFR = new Week(date);
                                    
                                    // The week number might be different between locales
                                    assertEquals(weekUS.getYearValue(), weekFR.getYearValue());
                                    // The week number might differ by 1 depending on locale
                                    assertTrue(Math.abs(weekUS.getWeek() - weekFR.getWeek()) <= 1);
                                }

    @Test
                                public void testConstructorWithLeapYear() {
                                    // Test with a date in a leap year
                                    Calendar calendar = Calendar.getInstance();
                                    calendar.set(Calendar.YEAR, 2020); // Leap year
                                    calendar.set(Calendar.MONTH, Calendar.FEBRUARY);
                                    calendar.set(Calendar.DAY_OF_MONTH, 29); // Leap day
                                    Date date = calendar.getTime();
                                    
                                    Week week = new Week(date);
                                    
                                    assertEquals(2020, week.getYearValue());
                                    // Week number should be valid (between 1 and 53)
                                    assertTrue(week.getWeek() >= 1 && week.getWeek() <= 53);
                                }

    @Test
                                public void testConstructorWithDSTTransition() {
                                    // Test with a date during daylight saving time transition
                                    TimeZone defaultTZ = TimeZone.getDefault();
                                    try {
                                        TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
                                        Calendar calendar = Calendar.getInstance();
                                        calendar.set(Calendar.YEAR, 2023);
                                        calendar.set(Calendar.MONTH, Calendar.MARCH);
                                        calendar.set(Calendar.DAY_OF_MONTH, 12); // DST starts in US
                                        Date date = calendar.getTime();
                                        
                                        Week week = new Week(date);
                                        
                                        assertEquals(2023, week.getYearValue());
                                        assertTrue(week.getWeek() >= 1 && week.getWeek() <= 53);
                                        assertTrue(week.getFirstMillisecond() < week.getLastMillisecond());
                                    } finally {
                                        TimeZone.setDefault(defaultTZ);
                                    }
                                }

    @Test
                                public void testConstructorWithEpochDate() {
                                    // Test with epoch date (Jan 1, 1970)
                                    Date epoch = new Date(0);
                                    Week week = new Week(epoch);
                                    
                                    // The exact week number depends on locale, but year should be 1970
                                    assertEquals(1970, week.getYearValue());
                                    assertTrue(week.getWeek() >= 1 && week.getWeek() <= 53);
                                }

    @Test
                                public void testConstructorWithValidDateAndTimeZone() {
                                    // Setup
                                    Date testDate = new Date(122, Calendar.JANUARY, 10); // Jan 10, 2022
                                    TimeZone timeZone = TimeZone.getTimeZone("America/New_York");
                                    
                                    // Execute
                                    Week week = new Week(testDate, timeZone);
                                    
                                    // Verify
                                    assertEquals(2022, week.getYearValue());
                                    assertTrue("Week number should be between FIRST_WEEK_IN_YEAR and LAST_WEEK_IN_YEAR",
                                            week.getWeek() >= Week.FIRST_WEEK_IN_YEAR && week.getWeek() <= Week.LAST_WEEK_IN_YEAR);
                                    assertTrue("First millisecond should be set", week.getFirstMillisecond() > 0);
                                    assertTrue("Last millisecond should be set", week.getLastMillisecond() > 0);
                                    assertTrue("Last millisecond should be after first millisecond",
                                            week.getLastMillisecond() > week.getFirstMillisecond());
                                }

    @Test
                                public void testConstructorWithNullDate1() {
                                    // Setup
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Null 'time' argument.");
                                    
                                    TimeZone timeZone = TimeZone.getDefault();
                                    
                                    // Execute
                                    new Week(null, timeZone);
                                }

    @Test
                                public void testConstructorWithNullTimeZone() {
                                    // Setup
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Null 'zone' argument.");
                                    
                                    Date testDate = new Date();
                                    
                                    // Execute
                                    new Week(testDate, null);
                                }

    @Test
                                public void testConstructorWithDifferentTimeZones() {
                                    // Setup
                                    Date testDate = new Date(122, Calendar.JANUARY, 1); // Jan 1, 2022
                                    TimeZone nyZone = TimeZone.getTimeZone("America/New_York");
                                    TimeZone londonZone = TimeZone.getTimeZone("Europe/London");
                                    
                                    // Execute
                                    Week nyWeek = new Week(testDate, nyZone);
                                    Week londonWeek = new Week(testDate, londonZone);
                                    
                                    // Verify
                                    // The week numbers might be different due to timezone differences
                                    assertTrue(Math.abs(nyWeek.getWeek() - londonWeek.getWeek()) <= 1);
                                    assertNotEquals(nyWeek.getFirstMillisecond(), londonWeek.getFirstMillisecond());
                                    assertNotEquals(nyWeek.getLastMillisecond(), londonWeek.getLastMillisecond());
                                }

    @Test
                                public void testConstructorWithDateAtWeekBoundary() {
                                    // Setup - Sunday is typically the first day of the week in US locale
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(2022, Calendar.JANUARY, 2); // Jan 2, 2022 (Sunday)
                                    Date sundayDate = cal.getTime();
                                    TimeZone timeZone = TimeZone.getDefault();
                                    
                                    // Execute
                                    Week week = new Week(sundayDate, timeZone);
                                    
                                    // Verify
                                    assertEquals(1, week.getWeek()); // Should be first week of the year
                                }

    @Test
                                public void testConstructorWithDateAtYearBoundary() {
                                    // Setup - December 31
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(2022, Calendar.DECEMBER, 31); // Dec 31, 2022
                                    Date yearEndDate = cal.getTime();
                                    TimeZone timeZone = TimeZone.getDefault();
                                    
                                    // Execute
                                    Week week = new Week(yearEndDate, timeZone);
                                    
                                    // Verify
                                    assertTrue(week.getWeek() >= Week.FIRST_WEEK_IN_YEAR && 
                                              week.getWeek() <= Week.LAST_WEEK_IN_YEAR);
                                    assertEquals(2022, week.getYearValue());
                                }

    @Test
                                public void testConstructorWithDateInDifferentLocale1() {
                                    // Setup - Change default locale for this test
                                    Locale originalLocale = Locale.getDefault();
                                    try {
                                        Locale.setDefault(Locale.FRANCE); // France uses Monday as first day of week
                                        
                                        Date testDate = new Date(122, Calendar.JANUARY, 3); // Jan 3, 2022 (Monday)
                                        TimeZone timeZone = TimeZone.getDefault();
                                        
                                        // Execute
                                        Week week = new Week(testDate, timeZone);
                                        
                                        // Verify
                                        assertEquals(1, week.getWeek()); // Should be first week of the year in France locale
                                    } finally {
                                        Locale.setDefault(originalLocale); // Restore original locale
                                    }
                                }

    @Test
                                public void testConstructor_NullArguments() {
                                    Date date = new Date();
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Null 'time' argument.");
                                    new Week(null, TimeZone.getDefault(), Locale.getDefault());
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Null 'zone' argument.");
                                    new Week(date, null, Locale.getDefault());
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Null 'locale' argument.");
                                    new Week(date, TimeZone.getDefault(), null);
                                }

    @Test
                                public void testConstructor_RegularWeek() {
                                    // Setup a known date in the middle of a year
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(2023, Calendar.JUNE, 15); // June 15, 2023
                                    Date date = cal.getTime();
                                    
                                    Week week = new Week(date, TimeZone.getDefault(), Locale.getDefault());
                                    
                                    assertEquals(24, week.getWeek()); // Week 24 of 2023
                                    assertEquals(2023, week.getYearValue());
                                }

    @Test
                                public void testConstructor_LastWeekOfYear() {
                                    // Setup a date in the last week of the year
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(2023, Calendar.DECEMBER, 28); // December 28, 2023 (week 52)
                                    Date date = cal.getTime();
                                    
                                    Week week = new Week(date, TimeZone.getDefault(), Locale.getDefault());
                                    
                                    assertEquals(52, week.getWeek());
                                    assertEquals(2023, week.getYearValue());
                                }

    @Test
                                public void testConstructor_FirstWeekOfNextYear() {
                                    // Setup a date in December that belongs to week 1 of next year
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(2023, Calendar.DECEMBER, 31); // December 31, 2023 (week 1 of 2024 in some locales)
                                    Date date = cal.getTime();
                                    
                                    // Use US locale which typically considers this week 1 of next year
                                    Week week = new Week(date, TimeZone.getDefault(), Locale.US);
                                    
                                    assertEquals(1, week.getWeek());
                                    assertEquals(2024, week.getYearValue());
                                }

    @Test
                                public void testConstructor_FirstWeekOfYear() {
                                    // Setup a date in January that's clearly in week 1
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(2023, Calendar.JANUARY, 5); // January 5, 2023 (week 1)
                                    Date date = cal.getTime();
                                    
                                    Week week = new Week(date, TimeZone.getDefault(), Locale.getDefault());
                                    
                                    assertEquals(1, week.getWeek());
                                    assertEquals(2023, week.getYearValue());
                                }

    @Test
                                public void testConstructor_FirstDaysInLastWeekOfPreviousYear() {
                                    // Setup a date in January that belongs to last week of previous year
                                    Calendar cal = Calendar.getInstance();
                                    cal.set(2023, Calendar.JANUARY, 1); // January 1, 2023 (might be week 52 or 53 of 2022)
                                    Date date = cal.getTime();
                                    
                                    // Use a locale where Jan 1 is considered part of previous year's last week
                                    Week week = new Week(date, TimeZone.getDefault(), Locale.GERMANY);
                                    
                                    assertTrue(week.getWeek() >= 52);
                                    assertEquals(2022, week.getYearValue());
                                }

    @Test
                    public void testConstructor_WeekNeverExceedsLastWeekInYear() throws Exception {
                        // Mock a calendar that returns a week number higher than LAST_WEEK_IN_YEAR
                        Calendar mockCalendar = mock(Calendar.class);
                        when(mockCalendar.get(Calendar.WEEK_OF_YEAR)).thenReturn(60); // Unrealistically high week number
                        when(mockCalendar.get(Calendar.MONTH)).thenReturn(Calendar.JUNE);
                        when(mockCalendar.get(Calendar.YEAR)).thenReturn(2023);
                        
                        // Mock Calendar.getInstance to return our mock
                        Calendar original = Calendar.getInstance();
                        TimeZone originalTimeZone = original.getTimeZone();
                        Locale originalLocale = Locale.getDefault();
                        
                        try {
                            // Set static fields using reflection
                            Field defaultTimeZoneField = Calendar.class.getDeclaredField("defaultTimeZone");
                            defaultTimeZoneField.setAccessible(true);
                            Field modifiersField = Field.class.getDeclaredField("modifiers");
                            modifiersField.setAccessible(true);
                            modifiersField.setInt(defaultTimeZoneField, defaultTimeZoneField.getModifiers() & ~Modifier.FINAL);
                            TimeZone savedTimeZone = (TimeZone) defaultTimeZoneField.get(null);
                            defaultTimeZoneField.set(null, TimeZone.getDefault());
                            
                            Field defaultLocaleField = Calendar.class.getDeclaredField("defaultLocale");
                            defaultLocaleField.setAccessible(true);
                            modifiersField.setInt(defaultLocaleField, defaultLocaleField.getModifiers() & ~Modifier.FINAL);
                            Locale savedLocale = (Locale) defaultLocaleField.get(null);
                            defaultLocaleField.set(null, Locale.getDefault());
                            
                            when(Calendar.getInstance(any(TimeZone.class), any(Locale.class))).thenReturn(mockCalendar);
                            
                            Week week = new Week(new Date(), TimeZone.getDefault(), Locale.getDefault());
                            
                            assertEquals(Week.LAST_WEEK_IN_YEAR, week.getWeek());
                            assertEquals(2023, week.getYearValue());
                        } finally {
                            // Reset the static fields
                            Field defaultTimeZoneField = Calendar.class.getDeclaredField("defaultTimeZone");
                            defaultTimeZoneField.setAccessible(true);
                            defaultTimeZoneField.set(null, originalTimeZone);
                            
                            Field defaultLocaleField = Calendar.class.getDeclaredField("defaultLocale");
                            defaultLocaleField.setAccessible(true);
                            defaultLocaleField.set(null, originalLocale);
                        }
                    }

    @Test
                    public void testConstructorWithDateLocaleSensitivity() {
                        // Setup: Create a known date and set different default locales
                        Date testDate = new Date(122, 0, 1); // Jan 1, 2022
                        Locale originalDefault = Locale.getDefault();
                        Locale originalDisplay = Locale.getDefault(Locale.Category.DISPLAY);
                        
                        try {
                            // Set different locales for default and display categories
                            Locale.setDefault(Locale.US);
                            Locale.setDefault(Locale.Category.DISPLAY, Locale.FRANCE);
                            
                            // Create Week instance - should use default locale in original, display locale in mutant
                            Week week = new Week(testDate);
                            
                            // Verify week calculation isn't affected by locale differences
                            assertEquals(2022, week.getYearValue());
                            assertEquals(1, week.getWeek()); // Jan 1 2022 is week 1
                            
                            // Additional verification that locale didn't affect week boundaries
                            Week nextWeek = (Week)week.next();
                            assertEquals(2, nextWeek.getWeek());
                            
                        } finally {
                            // Restore original locales
                            Locale.setDefault(originalDefault);
                            Locale.setDefault(Locale.Category.DISPLAY, originalDisplay);
                        }
                    }

    @Test
                    public void testLocaleHandlingInConstructor() {
                        // Save original default locale
                        Locale originalDefault = Locale.getDefault();
                        
                        try {
                            // Set a non-default locale that might affect week calculation
                            Locale.setDefault(Locale.GERMANY); // Germany uses Monday as first day of week
                            
                            // Create a Week instance that would trigger peg() calculation
                            Week week = new Week(1, 2023);
                            
                            // Verify the week boundaries are calculated correctly regardless of display locale
                            Calendar cal = Calendar.getInstance();
                            week.peg(cal);
                            
                            long firstMillisecond = week.getFirstMillisecond();
                            long lastMillisecond = week.getLastMillisecond();
                            
                            // Assert that the week boundaries make sense (7 days difference)
                            assertEquals(7 * 24 * 60 * 60 * 1000 - 1, lastMillisecond - firstMillisecond);
                            
                            // Verify the week number was set correctly
                            assertEquals(1, week.getWeek());
                            
                        } finally {
                            // Restore original locale
                            Locale.setDefault(originalDefault);
                        }
                    }

    @Test
                    public void testLocaleInitialization() {
                        // Save original default locale
                        Locale originalDefault = Locale.getDefault();
                        Locale originalDisplay = Locale.getDefault(Locale.Category.DISPLAY);
                        
                        try {
                            // Set different locales for default and display categories
                            Locale testDefault = Locale.US;
                            Locale testDisplay = Locale.FRANCE;
                            
                            Locale.setDefault(testDefault);
                            Locale.setDefault(Locale.Category.DISPLAY, testDisplay);
                            
                            // Create a Week instance - the constructor should use DISPLAY locale
                            Year year = new Year(2023); // Assuming Year class exists
                            Week week = new Week(1, year);
                            
                            // Verify locale-sensitive operations use DISPLAY locale
                            // Test toString() or other locale-dependent methods
                            String weekString = week.toString();
                            
                            // The actual assertion depends on how toString() is implemented,
                            // but we expect French locale formatting if it's using DISPLAY locale
                            // For example, checking for French-specific formatting
                            assertTrue("String should show French locale formatting", 
                                      weekString.contains("Semaine") || weekString.contains("semaine"));
                            
                        } finally {
                            // Restore original locales
                            Locale.setDefault(originalDefault);
                            Locale.setDefault(Locale.Category.DISPLAY, originalDisplay);
                        }
                    }

    @Test
                    public void testConstructorWithDifferentLocaleCategories() {
                        // Setup test data
                        Date time = new Date(); // current time
                        TimeZone zone = TimeZone.getDefault();
                        
                        // Save original locale settings
                        Locale originalDefault = Locale.getDefault();
                        Locale originalDisplay = Locale.getDefault(Locale.Category.DISPLAY);
                        Locale originalFormat = Locale.getDefault(Locale.Category.FORMAT);
                        
                        try {
                            // Set different locales for DISPLAY and FORMAT categories
                            Locale testLocale = Locale.US;
                            Locale.setDefault(Locale.Category.DISPLAY, testLocale);
                            Locale.setDefault(Locale.Category.FORMAT, Locale.FRANCE);
                            
                            // Create Week instance - this should use DISPLAY locale due to mutation
                            Week weekInstance = new Week(time, zone, null);
                            
                            // Verify the week calculation matches expected behavior for DISPLAY locale
                            Calendar cal = Calendar.getInstance(zone, testLocale);
                            cal.setTime(time);
                            int expectedWeek = cal.get(Calendar.WEEK_OF_YEAR);
                            
                            if (expectedWeek == 1 && cal.get(Calendar.MONTH) == Calendar.DECEMBER) {
                                assertEquals(1, weekInstance.getWeek());
                            } else {
                                int minWeek = Math.min(expectedWeek, Week.LAST_WEEK_IN_YEAR);
                                assertEquals(minWeek, weekInstance.getWeek());
                            }
                            
                        } finally {
                            // Restore original locale settings
                            Locale.setDefault(originalDefault);
                            Locale.setDefault(Locale.Category.DISPLAY, originalDisplay);
                            Locale.setDefault(Locale.Category.FORMAT, originalFormat);
                        }
                    }

    @Test
            public void testConstructorUsesGeneralDefaultLocaleNotDisplayLocale() {
                // Save original defaults
                Locale originalDefault = Locale.getDefault();
                Locale originalDisplayDefault = Locale.getDefault(Locale.Category.DISPLAY);
                TimeZone originalTimeZone = TimeZone.getDefault();
                
                try {
                    // Set different locales for default and display categories
                    Locale testDefault = Locale.JAPANESE;
                    Locale testDisplayDefault = Locale.CHINESE;
                    
                    Locale.setDefault(testDefault);
                    Locale.setDefault(Locale.Category.DISPLAY, testDisplayDefault);
                    
                    // Create a Week instance - should use general default (JAPANESE)
                    Date testTime = new Date(); // Using Date instead of long
                    Week week = new Week(testTime);
                    
                    // Verify the locale used was the general default, not display default
                    // We can't directly check the locale used in construction, but we can verify
                    // behavior that would differ based on locale
                    // For example, check toString() format which is locale-dependent
                    // This assumes toString() uses the locale set during construction
                    String weekString = week.toString();
                    
                    // The exact assertion depends on how toString() uses the locale
                    // Here we just verify it's not using the display locale's format
                    // (This is a simplified check - in real code you'd need more specific assertions)
                    assertFalse("Should not use display locale format", 
                               weekString.contains(testDisplayDefault.getDisplayName()));
                    
                } finally {
                    // Restore original defaults
                    Locale.setDefault(originalDefault);
                    Locale.setDefault(Locale.Category.DISPLAY, originalDisplayDefault);
                    TimeZone.setDefault(originalTimeZone);
                }
            }

    @Test
            public void testConstructorLocaleHandling() {
                // Save original locales
                Locale originalDefault = Locale.getDefault();
                Locale originalDisplay = Locale.getDefault(Locale.Category.DISPLAY);
                
                try {
                    // Set different default and display locales
                    Locale.setDefault(Locale.US);
                    Locale.setDefault(Locale.Category.DISPLAY, Locale.UK);
                    
                    long testTime = System.currentTimeMillis();
                    TimeZone testZone = TimeZone.getDefault();
                    
                    // Create week instance using Date constructor
                    Date testDate = new Date(testTime);
                    Week week = new Week(testDate, testZone);
                    
                    // Verify behavior that would differ based on locale
                    // For example, week numbering might differ between US and UK
                    // We can't directly test the locale used in constructor, but we can test
                    // methods whose behavior depends on it
                    
                    // Test toString() which might use locale for formatting
                    String str = week.toString();
                    assertNotNull(str);
                    
                    // Test week number calculation which might be locale-dependent
                    int weekNumber = week.getWeek();
                    assertTrue(weekNumber >= 1 && weekNumber <= 53);
                    
                } finally {
                    // Restore original locales
                    Locale.setDefault(originalDefault);
                    Locale.setDefault(Locale.Category.DISPLAY, originalDisplay);
                }
            }

    @Test
            public void testConstructorWithDifferentFormatLocale() {
                // Save original locales
                Locale originalDefault = Locale.getDefault();
                Locale originalFormatDefault = Locale.getDefault(Locale.Category.FORMAT);
                
                try {
                    // Set different locales for default and format categories
                    Locale.setDefault(Locale.US);
                    Locale.setDefault(Locale.Category.FORMAT, Locale.UK);
                    
                    // Create a date that would be in different weeks in US vs UK locale
                    // For example, Jan 1, 2022 - in US week 52 of 2021, in UK week 1 of 2022
                    Date testDate = new Date(1640995200000L); // Jan 1, 2022
                    
                    // Create Week instance
                    Week week = new Week(testDate);
                    
                    // Verify week number is calculated using format locale (UK)
                    // In UK locale, Jan 1 is week 1 of the new year
                    assertEquals(1, week.getWeek());
                    assertEquals(2022, week.getYearValue());
                    
                } finally {
                    // Restore original locales
                    Locale.setDefault(originalDefault);
                    Locale.setDefault(Locale.Category.FORMAT, originalFormatDefault);
                }
            }

    @Test
            public void testPegWithDefaultLocale() {
                // Setup test data
                int testWeek = 25;
                int testYear = 2023;
                TimeZone zone = TimeZone.getDefault();
                
                // Create a Week instance - this will call the constructor with mutated locale
                Week week = new Week(testWeek, testYear);
                
                // Get a calendar instance with default locale for comparison
                Calendar calDefault = Calendar.getInstance();
                calDefault.set(Calendar.WEEK_OF_YEAR, testWeek);
                calDefault.set(Calendar.YEAR, testYear);
                
                // Verify the first millisecond matches expected value
                // The mutant using FORMAT locale might calculate this differently
                long expectedFirstMs = week.getFirstMillisecond(calDefault);
                assertEquals("First millisecond should match default locale calculation", 
                    expectedFirstMs, week.getFirstMillisecond());
                
                // Verify the last millisecond matches expected value
                long expectedLastMs = week.getLastMillisecond(calDefault);
                assertEquals("Last millisecond should match default locale calculation",
                    expectedLastMs, week.getLastMillisecond());
            }

    @Test
            public void testConstructorLocaleHandling1() {
                // Save original default locale
                Locale originalDefault = Locale.getDefault();
                
                try {
                    // Set a specific locale for testing
                    Locale.setDefault(Locale.US);
                    
                    // Create a test Year object (mocked if needed)
                    Year testYear = new Year(2023);
                    
                    // Create Week instance
                    Week week = new Week(1, testYear);
                    
                    // Verify the Calendar peg uses the correct locale
                    Calendar cal = Calendar.getInstance();
                    week.peg(cal);
                    
                    // Get the first millisecond which would be affected by locale
                    long firstMs = week.getFirstMillisecond();
                    
                    // Now change the default locale to something different
                    Locale.setDefault(Locale.FRANCE);
                    
                    // Create another Week instance
                    Week weekFr = new Week(1, testYear);
                    weekFr.peg(cal);
                    
                    // Verify behavior is consistent regardless of default locale
                    assertEquals("Week start time should not depend on default locale", 
                                firstMs, weekFr.getFirstMillisecond());
                    
                } finally {
                    // Restore original locale
                    Locale.setDefault(originalDefault);
                }
            }

    @Test
            public void testLocaleSensitivity() {
                // Setup test data
                Date testDate = new Date(123, Calendar.DECEMBER, 31); // Dec 31, 2023
                TimeZone zone = TimeZone.getDefault();
                
                // Get default and format locales that are different
                Locale defaultLocale = Locale.getDefault();
                Locale formatLocale = Locale.getDefault(Locale.Category.FORMAT);
                
                // Only proceed if they're actually different
                if (!defaultLocale.equals(formatLocale)) {
                    // Create Week instance with original behavior (implicit default locale)
                    Week weekOriginal = new Week(testDate, zone, defaultLocale);
                    
                    // Create Week instance with mutated behavior (format locale)
                    Week weekMutated = new Week(testDate, zone, formatLocale);
                    
                    // Assert week numbers should be same if behavior unchanged
                    assertNotEquals("Week number differs between default and format locale", 
                                  weekOriginal.getWeek(), weekMutated.getWeek());
                }
            }

    @Test
    public void testConstructorUsesDefaultLocaleNotFormatLocale() {
        // Save original locales
        Locale originalDefault = Locale.getDefault();
        Locale originalFormat = Locale.getDefault(Locale.Category.FORMAT);
        
        try {
            // Set different locales for default and format categories
            Locale.setDefault(Locale.US);
            Locale.setDefault(Locale.Category.FORMAT, Locale.FRANCE);
            
            // Create a test time (using first millisecond of week 1, 2000)
            long testTime = new Week(1, 2000).getFirstMillisecond();
            
            // Convert long to Date
            Date testDate = new Date(testTime);
            
            // Create week instance - should use default locale (US), not format locale (FRANCE)
            Week week = new Week(testDate);
            
            // Verify behavior that depends on locale
            // For example, toString() might format differently based on locale
            // This assertion expects US locale behavior
            assertTrue("Week string representation should follow default locale", 
                      week.toString().contains("Week ") || 
                      week.toString().contains("2000"));
            
        } finally {
            // Restore original locales
            Locale.setDefault(originalDefault);
            Locale.setDefault(Locale.Category.FORMAT, originalFormat);
        }
    }

    @Test
    public void testConstructorUsesDefaultLocaleNotFormatLocale1() {
        // Save original default and format locales
        Locale originalDefault = Locale.getDefault();
        Locale originalFormat = Locale.getDefault(Locale.Category.FORMAT);
        
        try {
            // Set different locales for default and format categories
            Locale testDefault = Locale.US;
            Locale testFormat = Locale.FRANCE;
            
            Locale.setDefault(testDefault);
            Locale.setDefault(Locale.Category.FORMAT, testFormat);
            
            // Create a test time and zone
            Date time = new Date(System.currentTimeMillis());
            TimeZone zone = TimeZone.getDefault();
            
            // Create Week instance - should use default locale, not format locale
            Week week = new Week(time, zone);
            
            // Verify behavior that would differ based on locale
            // For example, check if parsing/formatting uses the default locale
            String str = week.toString();
            
            // If the toString() implementation is locale-sensitive,
            // we can check for locale-specific patterns
            if (testDefault != testFormat) {
                // Example check - this would need to be adapted based on actual toString() implementation
                boolean usesDefaultLocaleFormat = str.contains(testDefault.getCountry()) || 
                                               str.contains(testDefault.getLanguage());
                assertTrue("Should use default locale, not format locale", usesDefaultLocaleFormat);
            }
            
        } finally {
            // Restore original locales
            Locale.setDefault(originalDefault);
            Locale.setDefault(Locale.Category.FORMAT, originalFormat);
        }
    }


}
