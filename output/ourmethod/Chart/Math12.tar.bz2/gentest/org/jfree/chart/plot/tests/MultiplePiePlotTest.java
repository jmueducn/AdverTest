package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryToPieDataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.PieDataset;
 
public class MultiplePiePlotTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                    public void testMultiplePiePlotConstructor_WithNullDataset() {
                                        // When
                                        MultiplePiePlot plot = new MultiplePiePlot();
                                        
                                        // Then
                                        assertNull("Constructor with null should set dataset to null", plot.getDataset());
                                    }

    @Test
                                    public void testMultiplePiePlotConstructor_VerifyPieChartInitialization() {
                                        // When
                                        MultiplePiePlot plot = new MultiplePiePlot();
                                        
                                        // Then
                                        assertNull("Pie chart should be null after construction", plot.getPieChart());
                                    }

    @Test
                                    public void testMultiplePiePlotConstructor_VerifyDataExtractOrderInitialization() {
                                        // When
                                        MultiplePiePlot plot = new MultiplePiePlot();
                                        
                                        // Then
                                        assertEquals("Data extract order should be initialized to BY_ROW", 
                                                    TableOrder.BY_ROW, plot.getDataExtractOrder());
                                    }

    @Test
                                    public void testMultiplePiePlotConstructor_VerifyLimitInitialization() {
                                        // When
                                        MultiplePiePlot plot = new MultiplePiePlot();
                                        
                                        // Then
                                        assertEquals("Limit should be initialized to 0.0", 0.0, plot.getLimit(), 0.0001);
                                    }

    @Test
                                    public void testMultiplePiePlotConstructor_VerifyAggregatedItemsInitialization() {
                                        // When
                                        MultiplePiePlot plot = new MultiplePiePlot();
                                        
                                        // Then
                                        assertNull("Aggregated items key should be null", plot.getAggregatedItemsKey());
                                        assertNull("Aggregated items paint should be null", plot.getAggregatedItemsPaint());
                                    }

    @Test
                                    public void testConstructor_NullDataset() {
                                        // Act
                                        MultiplePiePlot plot = new MultiplePiePlot(null);
                                        
                                        // Assert
                                        assertNull(plot.getDataset());
                                        // Other initializations should still occur
                                        assertNotNull(plot.getPieChart());
                                        assertEquals(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                                    }

    @Test
                                    public void testConstructor_VerifyDefaultLimitValue() {
                                        // Arrange
                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                        
                                        // Act
                                        MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                        
                                        // Assert
                                        // Assuming default limit is 0.0 if not set in constructor
                                        assertEquals(0.0, plot.getLimit(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_VerifyChartProperties() {
                                        // Arrange
                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                        
                                        // Act
                                        MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                        JFreeChart chart = plot.getPieChart();
                                        
                                        // Assert
                                        assertNotNull(chart.getPlot());
                                        assertEquals(1, chart.getSubtitles().size()); // Only the title should be present
                                        assertFalse(chart.isBorderVisible());
                                    }

    @Test
                            public void testMultiplePiePlotConstructor_InitializesFieldsToDefaultValues() {
                                // When
                                MultiplePiePlot plot = new MultiplePiePlot();
                                
                                // Then
                                assertNull("Dataset should be null", plot.getDataset());
                                assertNull("Pie chart should be null", plot.getPieChart());
                                assertEquals("Default data extract order should be BY_ROW", 
                                            TableOrder.BY_ROW, plot.getDataExtractOrder());
                                assertEquals("Default limit should be 0.0", 0.0, plot.getLimit(), 0.0001);
                                assertNull("Aggregated items key should be null", plot.getAggregatedItemsKey());
                                assertNull("Aggregated items paint should be null", plot.getAggregatedItemsPaint());
                                
                                // Test sectionPaints using reflection since there's no public getter
                                try {
                                    Field field = MultiplePiePlot.class.getDeclaredField("sectionPaints");
                                    field.setAccessible(true);
                                    Map<?,?> sectionPaints = (Map<?,?>) field.get(plot);
                                    assertNotNull("Section paints map should be initialized", sectionPaints);
                                } catch (Exception e) {
                                    fail("Failed to access sectionPaints field: " + e.getMessage());
                                }
                            }

    @Test
                            public void testConstructor_InitializesFieldsCorrectly() {
                                // Arrange
                                CategoryDataset dataset = mock(CategoryDataset.class);
                                
                                // Act
                                MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                
                                // Assert
                                // Verify dataset is set
                                assertSame(dataset, plot.getDataset());
                                
                                // Verify pieChart initialization
                                assertNotNull(plot.getPieChart());
                                assertNull(plot.getPieChart().getBackgroundPaint());
                                assertNull(plot.getPieChart().getLegend());
                                
                                // Verify title setup
                                TextTitle title = (TextTitle) plot.getPieChart().getTitle();
                                assertNotNull(title);
                                assertEquals("Series Title", title.getText());
                                assertEquals(RectangleEdge.BOTTOM, title.getPosition());
                                assertEquals(new Font("SansSerif", Font.BOLD, 12), title.getFont());
                                
                                // Verify data extract order
                                assertEquals(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                                
                                // Verify aggregated items settings
                                assertEquals("Other", plot.getAggregatedItemsKey());
                                assertEquals(Color.lightGray, plot.getAggregatedItemsPaint());
                                
                                // Verify section paints map
                                try {
                                    Field sectionPaintsField = MultiplePiePlot.class.getDeclaredField("sectionPaints");
                                    sectionPaintsField.setAccessible(true);
                                    Map<?,?> sectionPaints = (Map<?,?>) sectionPaintsField.get(plot);
                                    assertNotNull(sectionPaints);
                                    assertTrue(sectionPaints.isEmpty());
                                } catch (Exception e) {
                                    fail("Failed to access sectionPaints field: " + e.getMessage());
                                }
                            }

    @Test
                            public void testConstructorInitialization() {
                                // Test that constructor properly initializes the object
                                MultiplePiePlot plot = new MultiplePiePlot(null);
                                
                                // Verify default values are set (these might be set in parent or child constructor)
                                assertNotNull(plot.getPieChart());
                                assertNull(plot.getDataset()); // Since we passed null
                                assertNotNull(plot.getDataExtractOrder()); // Should have a default
                                assertEquals(0.0, plot.getLimit(), 0.0001);
                                assertNotNull(plot.getAggregatedItemsKey());
                                assertNotNull(plot.getAggregatedItemsPaint());
                                
                                // Test basic functionality
                                try {
                                    plot.getLegendItems(); // Should not throw NPE if properly initialized
                                    plot.setDataset(mock(CategoryDataset.class)); // Should work
                                    plot.setPieChart(mock(JFreeChart.class)); // Should work
                                } catch (NullPointerException e) {
                                    fail("Constructor failed to properly initialize object: " + e);
                                }
                            }

    @Test
                            public void testConstructorInitialization1() {
                                // Arrange
                                CategoryDataset dataset = mock(CategoryDataset.class);
                                
                                // Act
                                MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                
                                // Assert - verify all initializations that happen after super()
                                assertNotNull(plot.getPieChart());
                                assertNull(plot.getPieChart().getBackgroundPaint());
                                assertEquals(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                                assertEquals("Other", plot.getAggregatedItemsKey());
                                assertEquals(Color.lightGray, plot.getAggregatedItemsPaint());
                                
                                // Verify the title was set correctly
                                TextTitle title = (TextTitle) plot.getPieChart().getTitle();
                                assertNotNull(title);
                                assertEquals("Series Title", title.getText());
                                assertEquals(RectangleEdge.BOTTOM, title.getPosition());
                                assertEquals(new Font("SansSerif", Font.BOLD, 12), title.getFont());
                                
                                // If super() was called properly, the object should be fully initialized
                                // If super() was skipped, some inherited fields might not be initialized
                                try {
                                    plot.equals(plot); // Basic Object method that might fail if not properly initialized
                                } catch (Exception e) {
                                    fail("Object not properly initialized - super() call might be missing");
                                }
                            }

    @Test
                public void testConstructorRemovesLegend() {
                    // Create a mock pie chart
                    JFreeChart mockPieChart = mock(JFreeChart.class);
                    
                    // Create the plot object - the constructor should call removeLegend()
                    MultiplePiePlot plot = new MultiplePiePlot(null);
                    plot.setPieChart(mockPieChart);
                    
                    // Verify that removeLegend was called exactly once
                    verify(mockPieChart, times(1)).removeLegend();
                }

    @Test
        public void testConstructorRemovesLegend1() {
            // Create a new MultiplePiePlot instance (constructor being tested)
            MultiplePiePlot plot = new MultiplePiePlot(null);
            
            // Get the pie chart from the plot
            JFreeChart pieChart = plot.getPieChart();
            
            // Verify that the chart has no legend
            org.jfree.chart.title.LegendTitle legend = pieChart.getLegend();
            assertNull("The pie chart should have no legend after construction", legend);
            
            // Additional check: if we add a legend, it should be removable
            pieChart.addLegend(new org.jfree.chart.title.LegendTitle(pieChart.getPlot()));
            assertNotNull("Sanity check: should have legend after adding", pieChart.getLegend());
            pieChart.removeLegend();
            assertNull("Sanity check: should have no legend after removal", pieChart.getLegend());
        }

    @Test
        public void testConstructorPieChartTitle() {
            // Create a new MultiplePiePlot instance with null parameter
            MultiplePiePlot plot = new MultiplePiePlot(null);
            
            // Get the created pie chart
            JFreeChart pieChart = plot.getPieChart();
            
            // Verify the chart title is null (original behavior)
            // This will fail if the mutant is present (which sets empty string title)
            assertNull("Pie chart title should be null", pieChart.getTitle());
            
            // Additional check to ensure the chart was properly created
            assertNotNull("Pie chart should not be null", pieChart);
        }

    @Test
        public void testPieChartInitializationTitle() {
            // Arrange
            CategoryDataset dataset = mock(CategoryDataset.class);
            
            // Act - create the MultiplePiePlot which will initialize the pieChart
            MultiplePiePlot plot = new MultiplePiePlot(dataset);
            
            // Assert - verify the pieChart was initialized without a title string
            JFreeChart pieChart = plot.getPieChart();
            assertNotNull("PieChart should not be null", pieChart);
            
            // The original code would have no title at this point (before setTitle is called)
            // The mutant would have set an empty string title
            assertNull("PieChart title should be null initially", pieChart.getTitle());
            
            // Verify the title is properly set later in the constructor
            TextTitle actualTitle = (TextTitle) pieChart.getTitle();
            assertEquals("Series Title", actualTitle.getText());
            assertEquals(Font.BOLD, actualTitle.getFont().getStyle());
            assertEquals(12, actualTitle.getFont().getSize());
        }

}
