package gentest.org.jfree.data.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.general.*;
import org.jfree.data.pie.PieDataset;
import org.jfree.data.pie.DefaultPieDataset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jfree.chart.util.ArrayUtilities;
import org.jfree.data.DomainInfo;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.KeyedValues;
import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryRangeInfo;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.function.Function2D;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYDomainInfo;
import org.jfree.data.xy.XYRangeInfo;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
 
public class DatasetUtilitiesTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithNullDataset() {
                                                                                                                                            // Test that null dataset returns null
                                                                                                                                            assertNull(DatasetUtilities.iterateDomainBounds(null));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithEmptyDataset() {
                                                                                                                                            // Test with empty dataset
                                                                                                                                            XYDataset emptyDataset = mock(XYDataset.class);
                                                                                                                                            when(emptyDataset.getSeriesCount()).thenReturn(0);
                                                                                                                                            
                                                                                                                                            assertNull(DatasetUtilities.iterateDomainBounds(emptyDataset));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithSingleSeriesDataset() {
                                                                                                                                            // Test with single series dataset
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(3.0);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithMultipleSeriesDataset() {
                                                                                                                                            // Test with multiple series dataset
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(2);
                                                                                                                                            
                                                                                                                                            // First series
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(5.0);
                                                                                                                                            
                                                                                                                                            // Second series
                                                                                                                                            when(dataset.getItemCount(1)).thenReturn(3);
                                                                                                                                            when(dataset.getXValue(1, 0)).thenReturn(-2.0);
                                                                                                                                            when(dataset.getXValue(1, 1)).thenReturn(3.0);
                                                                                                                                            when(dataset.getXValue(1, 2)).thenReturn(4.0);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(-2.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithNaNValues() {
                                                                                                                                            // Test that NaN values are ignored
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(3);
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                                                                            when(dataset.getXValue(0, 2)).thenReturn(Double.NaN);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithAllNaNValues() {
                                                                                                                                            // Test that all NaN values return null
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                                            
                                                                                                                                            assertNull(DatasetUtilities.iterateDomainBounds(dataset));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithIncludeIntervalTrue() {
                                                                                                                                            // Test with includeInterval parameter set to true
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(3.0);
                                                                                                                                            when(dataset.getX(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getX(0, 1)).thenReturn(3.0);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithIncludeIntervalFalse() {
                                                                                                                                            // Test with includeInterval parameter set to false
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(3.0);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_NullDataset() {
                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                            thrown.expectMessage("Null 'dataset' argument.");
                                                                                                                                            DatasetUtilities.iterateDomainBounds(null);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_EmptyDataset() {
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(0);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                            assertNull(result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_NonIntervalDataset() {
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(2);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            when(dataset.getItemCount(1)).thenReturn(3);
                                                                                                                                            
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(10.0);
                                                                                                                                            when(dataset.getXValue(1, 0)).thenReturn(2.0);
                                                                                                                                            when(dataset.getXValue(1, 1)).thenReturn(7.0);
                                                                                                                                            when(dataset.getXValue(1, 2)).thenReturn(Double.NaN);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                            assertEquals(new Range(2.0, 10.0), result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_IntervalDatasetWithoutInterval() {
                                                                                                                                            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(3.0);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(8.0);
                                                                                                                                            // These shouldn't be called since includeInterval is false
                                                                                                                                            when(dataset.getStartXValue(anyInt(), anyInt())).thenReturn(1.0);
                                                                                                                                            when(dataset.getEndXValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                                                                                            assertEquals(new Range(3.0, 8.0), result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_IntervalDatasetWithInterval() {
                                                                                                                                            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(3.0);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(8.0);
                                                                                                                                            when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getEndXValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getStartXValue(0, 1)).thenReturn(7.0);
                                                                                                                                            when(dataset.getEndXValue(0, 1)).thenReturn(10.0);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                                                            assertEquals(new Range(1.0, 10.0), result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_WithNaNValues1() {
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(3);
                                                                                                                                            
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(4.0);
                                                                                                                                            when(dataset.getXValue(0, 2)).thenReturn(Double.NaN);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                            assertEquals(new Range(4.0, 4.0), result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_AllNaNValues() {
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                            assertNull(result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateDomainBounds_MultipleSeriesWithMixedValues() {
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(2);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            when(dataset.getItemCount(1)).thenReturn(3);
                                                                                                                                            
                                                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(-5.0);
                                                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(10.0);
                                                                                                                                            when(dataset.getXValue(1, 0)).thenReturn(0.0);
                                                                                                                                            when(dataset.getXValue(1, 1)).thenReturn(Double.NaN);
                                                                                                                                            when(dataset.getXValue(1, 2)).thenReturn(15.0);
                                                                                                                                            
                                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                            assertEquals(new Range(-5.0, 15.0), result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithNullDataset() {
                                                                                                                                            // Setup
                                                                                                                                            CategoryDataset dataset = null;
                                                                                                                                            
                                                                                                                                            // Execute and Verify
                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                            DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithEmptyDataset() {
                                                                                                                                            // Setup
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(0);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(0);
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertNull("Range should be null for empty dataset", result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithSingleValueDataset() {
                                                                                                                                            // Setup
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(1);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(1);
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull("Range should not be null", result);
                                                                                                                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithMultipleValues() {
                                                                                                                                            // Setup
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getValue(0, 1)).thenReturn(2.0);
                                                                                                                                            when(dataset.getValue(1, 0)).thenReturn(3.0);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(4.0);
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull("Range should not be null", result);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithNullValuesInDataset() {
                                                                                                                                            // Setup
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getValue(0, 1)).thenReturn(null);
                                                                                                                                            when(dataset.getValue(1, 0)).thenReturn(3.0);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(4.0);
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull("Range should not be null", result);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithNegativeValues() {
                                                                                                                                            // Setup
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(-5.0);
                                                                                                                                            when(dataset.getValue(0, 1)).thenReturn(-2.0);
                                                                                                                                            when(dataset.getValue(1, 0)).thenReturn(0.0);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(3.0);
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull("Range should not be null", result);
                                                                                                                                            assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithIncludeIntervalFalse() {
                                                                                                                                            // Setup
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(dataset.getValue(0, 1)).thenReturn(2.0);
                                                                                                                                            when(dataset.getValue(1, 0)).thenReturn(3.0);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(4.0);
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull("Range should not be null", result);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithAllNullValues() {
                                                                                                                                            // Setup
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(null);
                                                                                                                                            when(dataset.getValue(0, 1)).thenReturn(null);
                                                                                                                                            when(dataset.getValue(1, 0)).thenReturn(null);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(null);
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertNull("Range should be null when all values are null", result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_EmptyDataset() {
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(0);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(0);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            assertNull(result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_StandardCategoryDataset() {
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getValue(0, 1)).thenReturn(10.0);
                                                                                                                                            when(dataset.getValue(1, 0)).thenReturn(-3.0);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(null); // null value should be ignored
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(-3.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithNaNValues() {
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getValue(0, 1)).thenReturn(Double.NaN); // NaN should be ignored
                                                                                                                                            when(dataset.getValue(1, 0)).thenReturn(-3.0);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(8.0);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(-3.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(8.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_IntervalCategoryDataset_IncludeInterval() {
                                                                                                                                            IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            
                                                                                                                                            // Regular values
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(10.0);
                                                                                                                                            
                                                                                                                                            // Interval values
                                                                                                                                            when(dataset.getStartValue(0, 1)).thenReturn(2.0);
                                                                                                                                            when(dataset.getEndValue(0, 1)).thenReturn(7.0);
                                                                                                                                            when(dataset.getStartValue(1, 0)).thenReturn(-5.0);
                                                                                                                                            when(dataset.getEndValue(1, 0)).thenReturn(null); // null should be ignored
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_IntervalCategoryDataset_ExcludeInterval() {
                                                                                                                                            IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            
                                                                                                                                            // Regular values
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getValue(1, 1)).thenReturn(10.0);
                                                                                                                                            
                                                                                                                                            // Interval values (should be ignored when includeInterval is false)
                                                                                                                                            when(dataset.getStartValue(0, 1)).thenReturn(2.0);
                                                                                                                                            when(dataset.getEndValue(0, 1)).thenReturn(7.0);
                                                                                                                                            when(dataset.getStartValue(1, 0)).thenReturn(-5.0);
                                                                                                                                            when(dataset.getEndValue(1, 0)).thenReturn(null);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_AllNullValues() {
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            
                                                                                                                                            when(dataset.getValue(anyInt(), anyInt())).thenReturn(null);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            assertNull(result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_AllNaNValues() {
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(2);
                                                                                                                                            
                                                                                                                                            when(dataset.getValue(anyInt(), anyInt())).thenReturn(Double.NaN);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            assertNull(result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_SingleValue() {
                                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                            when(dataset.getRowCount()).thenReturn(1);
                                                                                                                                            when(dataset.getColumnCount()).thenReturn(1);
                                                                                                                                            
                                                                                                                                            when(dataset.getValue(0, 0)).thenReturn(7.5);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(7.5, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(7.5, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_NullDataset() {
                                                                                                                                            // Test that null dataset returns null
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds((CategoryDataset) null));
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds((CategoryDataset) null, true));
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds((CategoryDataset) null, false));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_EmptyDataset1() {
                                                                                                                                            // Test with empty dataset
                                                                                                                                            CategoryDataset emptyDataset = mock(CategoryDataset.class);
                                                                                                                                            when(emptyDataset.getRowCount()).thenReturn(0);
                                                                                                                                            when(emptyDataset.getColumnCount()).thenReturn(0);
                                                                                                                                    
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds(emptyDataset));
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds(emptyDataset, true));
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds(emptyDataset, false));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_SingleValueDataset() {
                                                                                                                                            // Test with dataset containing single value
                                                                                                                                            CategoryDataset singleValueDataset = mock(CategoryDataset.class);
                                                                                                                                            when(singleValueDataset.getRowCount()).thenReturn(1);
                                                                                                                                            when(singleValueDataset.getColumnCount()).thenReturn(1);
                                                                                                                                            when(singleValueDataset.getValue(0, 0)).thenReturn(5.0);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(singleValueDataset);
                                                                                                                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                            result = DatasetUtilities.iterateRangeBounds(singleValueDataset, true);
                                                                                                                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                            result = DatasetUtilities.iterateRangeBounds(singleValueDataset, false);
                                                                                                                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_MultipleValues() {
                                                                                                                                            // Test with dataset containing multiple values
                                                                                                                                            CategoryDataset multiValueDataset = mock(CategoryDataset.class);
                                                                                                                                            when(multiValueDataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(multiValueDataset.getColumnCount()).thenReturn(2);
                                                                                                                                            when(multiValueDataset.getValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(multiValueDataset.getValue(0, 1)).thenReturn(2.0);
                                                                                                                                            when(multiValueDataset.getValue(1, 0)).thenReturn(3.0);
                                                                                                                                            when(multiValueDataset.getValue(1, 1)).thenReturn(4.0);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(multiValueDataset);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                            result = DatasetUtilities.iterateRangeBounds(multiValueDataset, true);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                            result = DatasetUtilities.iterateRangeBounds(multiValueDataset, false);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_WithNullValues() {
                                                                                                                                            // Test with dataset containing some null values
                                                                                                                                            CategoryDataset datasetWithNulls = mock(CategoryDataset.class);
                                                                                                                                            when(datasetWithNulls.getRowCount()).thenReturn(2);
                                                                                                                                            when(datasetWithNulls.getColumnCount()).thenReturn(2);
                                                                                                                                            when(datasetWithNulls.getValue(0, 0)).thenReturn(1.0);
                                                                                                                                            when(datasetWithNulls.getValue(0, 1)).thenReturn(null);
                                                                                                                                            when(datasetWithNulls.getValue(1, 0)).thenReturn(3.0);
                                                                                                                                            when(datasetWithNulls.getValue(1, 1)).thenReturn(4.0);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(datasetWithNulls);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                            result = DatasetUtilities.iterateRangeBounds(datasetWithNulls, true);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                            result = DatasetUtilities.iterateRangeBounds(datasetWithNulls, false);
                                                                                                                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_AllNullValues1() {
                                                                                                                                            // Test with dataset containing all null values
                                                                                                                                            CategoryDataset allNullsDataset = mock(CategoryDataset.class);
                                                                                                                                            when(allNullsDataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(allNullsDataset.getColumnCount()).thenReturn(2);
                                                                                                                                            when(allNullsDataset.getValue(anyInt(), anyInt())).thenReturn(null);
                                                                                                                                    
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds(allNullsDataset));
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds(allNullsDataset, true));
                                                                                                                                            assertNull(DatasetUtilities.iterateRangeBounds(allNullsDataset, false));
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_NegativeValues() {
                                                                                                                                            // Test with negative values
                                                                                                                                            CategoryDataset negativeDataset = mock(CategoryDataset.class);
                                                                                                                                            when(negativeDataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(negativeDataset.getColumnCount()).thenReturn(1);
                                                                                                                                            when(negativeDataset.getValue(0, 0)).thenReturn(-5.0);
                                                                                                                                            when(negativeDataset.getValue(1, 0)).thenReturn(-1.0);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(negativeDataset);
                                                                                                                                            assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(-1.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                            result = DatasetUtilities.iterateRangeBounds(negativeDataset, true);
                                                                                                                                            assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(-1.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_MixedPositiveNegative() {
                                                                                                                                            // Test with mixed positive and negative values
                                                                                                                                            CategoryDataset mixedDataset = mock(CategoryDataset.class);
                                                                                                                                            when(mixedDataset.getRowCount()).thenReturn(2);
                                                                                                                                            when(mixedDataset.getColumnCount()).thenReturn(1);
                                                                                                                                            when(mixedDataset.getValue(0, 0)).thenReturn(-5.0);
                                                                                                                                            when(mixedDataset.getValue(1, 0)).thenReturn(5.0);
                                                                                                                                    
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(mixedDataset);
                                                                                                                                            assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                            result = DatasetUtilities.iterateRangeBounds(mixedDataset, false);
                                                                                                                                            assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_StandardXYDataset_WithValidValues() {
                                                                                                                                            // Setup
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(2);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            when(dataset.getItemCount(1)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            // Series 0
                                                                                                                                            when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getYValue(0, 1)).thenReturn(10.0);
                                                                                                                                            // Series 1
                                                                                                                                            when(dataset.getYValue(1, 0)).thenReturn(2.0);
                                                                                                                                            when(dataset.getYValue(1, 1)).thenReturn(15.0);
                                                                                                                                    
                                                                                                                                            // Test
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                    
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(15.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_StandardXYDataset_WithNaNValues() {
                                                                                                                                            // Setup
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(3);
                                                                                                                                            
                                                                                                                                            when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                                            when(dataset.getYValue(0, 2)).thenReturn(15.0);
                                                                                                                                    
                                                                                                                                            // Test
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                    
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(15.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_StandardXYDataset_AllNaNValues() {
                                                                                                                                            // Setup
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
                                                                                                                                            when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                                    
                                                                                                                                            // Test
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                    
                                                                                                                                            // Verify
                                                                                                                                            assertNull(result);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_IntervalXYDataset_IncludeInterval() {
                                                                                                                                            // Setup
                                                                                                                                            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            // First item
                                                                                                                                            when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getStartYValue(0, 0)).thenReturn(4.0);
                                                                                                                                            when(dataset.getEndYValue(0, 0)).thenReturn(6.0);
                                                                                                                                            // Second item
                                                                                                                                            when(dataset.getYValue(0, 1)).thenReturn(10.0);
                                                                                                                                            when(dataset.getStartYValue(0, 1)).thenReturn(9.0);
                                                                                                                                            when(dataset.getEndYValue(0, 1)).thenReturn(11.0);
                                                                                                                                    
                                                                                                                                            // Test
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                                                                    
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(4.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_IntervalXYDataset_ExcludeInterval() {
                                                                                                                                            // Setup
                                                                                                                                            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            // First item
                                                                                                                                            when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                                                                                            when(dataset.getStartYValue(0, 0)).thenReturn(4.0);
                                                                                                                                            when(dataset.getEndYValue(0, 0)).thenReturn(6.0);
                                                                                                                                            // Second item
                                                                                                                                            when(dataset.getYValue(0, 1)).thenReturn(10.0);
                                                                                                                                            when(dataset.getStartYValue(0, 1)).thenReturn(9.0);
                                                                                                                                            when(dataset.getEndYValue(0, 1)).thenReturn(11.0);
                                                                                                                                    
                                                                                                                                            // Test
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                                                                                    
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_OHLCDataset_IncludeInterval() {
                                                                                                                                            // Setup
                                                                                                                                            OHLCDataset dataset = mock(OHLCDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            // First item
                                                                                                                                            when(dataset.getLowValue(0, 0)).thenReturn(4.0);
                                                                                                                                            when(dataset.getHighValue(0, 0)).thenReturn(6.0);
                                                                                                                                            // Second item
                                                                                                                                            when(dataset.getLowValue(0, 1)).thenReturn(3.0);
                                                                                                                                            when(dataset.getHighValue(0, 1)).thenReturn(7.0);
                                                                                                                                    
                                                                                                                                            // Test
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                                                                                    
                                                                                                                                            // Verify
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(3.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(7.0, result.getUpperBound(), 0.0001);
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_OHLCDataset_ExcludeInterval() {
                                                                                                                                            // Setup
                                                                                                                                            OHLCDataset dataset = mock(OHLCDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                                            
                                                                                                                                            // First item
                                                                                                                                            when(dataset.getLowValue(0, 0)).thenReturn(4.0);
                                                                                                                                            when(dataset.getHighValue(0, 0)).thenReturn(6.0);
                                                                                                                                            // Second item
                                                                                                                                            when(dataset.getLowValue(0, 1)).thenReturn(3.0);
                                                                                                                                            when(dataset.getHighValue(0, 1)).thenReturn(7.0);
                                                                                                                                    
                                                                                                                                            // Test
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                                                                                    
                                                                                                                                            // Verify
                                                                                                                                            assertNull(result); // OHLCDataset without interval inclusion should return null
                                                                                                                                        }

    @Test
                                                                                                                                        public void testIterateRangeBounds_EmptyDataset2() {
                                                                                                                                            // Setup
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            when(dataset.getSeriesCount()).thenReturn(0);
                                                                                                                                    
                                                                                                                                            // Test
                                                                                                                                            Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                    
                                                                                                                                            // Verify
                                                                                                                                            assertNull(result);
                                                                                                                                        }

    @Test
                                                                                                                                public void testIterateRangeBounds_NullDataset1() {
                                                                                                                                    CategoryDataset dataset = null;
                                                                                                                                    Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                                                                                    assertNull(result);
                                                                                                                                }

    @Test
                                                                                                                                public void testIterateRangeBounds_NullDataset2() {
                                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                                    DatasetUtilities.iterateRangeBounds((CategoryDataset) null);
                                                                                                                                }

    @Test
                                                                                                                                public void testIterateDomainBoundsWithNegativeValues() {
                                                                                                                                    // Create a dataset with negative values
                                                                                                                                    XYSeries series1 = new XYSeries("Series1");
                                                                                                                                    series1.add(-5.0, 100);
                                                                                                                                    series1.add(-3.0, 200);
                                                                                                                                    series1.add(-1.0, 150);
                                                                                                                                    
                                                                                                                                    XYSeries series2 = new XYSeries("Series2");
                                                                                                                                    series2.add(-2.0, 50);
                                                                                                                                    series2.add(4.0, 75);
                                                                                                                                    series2.add(6.0, 80);
                                                                                                                                    
                                                                                                                                    XYSeriesCollection dataset = new XYSeriesCollection();
                                                                                                                                    dataset.addSeries(series1);
                                                                                                                                    dataset.addSeries(series2);
                                                                                                                                    
                                                                                                                                    // Get the actual range
                                                                                                                                    Range range = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                    
                                                                                                                                    // Verify the range includes all values (especially negative ones)
                                                                                                                                    assertNotNull("Range should not be null", range);
                                                                                                                                    assertEquals("Lower bound should be -5.0", -5.0, range.getLowerBound(), 0.0001);
                                                                                                                                    assertEquals("Upper bound should be 6.0", 6.0, range.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                    // This test will fail if maximum was initialized to 0.0 instead of Double.NEGATIVE_INFINITY
                                                                                                                                    // because it would miss the negative maximum values
                                                                                                                                }

    @Test
                                                                                                                                public void testIterateDomainBoundsWithNegativeValues1() {
                                                                                                                                    // Create a dataset with negative values
                                                                                                                                    XYSeries series = new XYSeries("Test Series");
                                                                                                                                    series.add(1, -5.0);
                                                                                                                                    series.add(2, -3.0);
                                                                                                                                    series.add(3, -1.0);  // This should be the maximum
                                                                                                                                    
                                                                                                                                    XYSeriesCollection dataset = new XYSeriesCollection();
                                                                                                                                    dataset.addSeries(series);
                                                                                                                                    
                                                                                                                                    // Call the method
                                                                                                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                    
                                                                                                                                    // Verify the range
                                                                                                                                    assertNotNull("Result should not be null", result);
                                                                                                                                    assertEquals("Minimum should be -5.0", -5.0, result.getLowerBound(), 0.0001);
                                                                                                                                    assertEquals("Maximum should be -1.0 (not 0.0)", -1.0, result.getUpperBound(), 0.0001);
                                                                                                                                    
                                                                                                                                    // This test will fail if maximum was initialized to 0.0 instead of Double.NEGATIVE_INFINITY
                                                                                                                                    // because the maximum would remain 0.0 instead of being updated to -1.0
                                                                                                                                }

    @Test
                                                                                                                            public void testIterateDomainBounds_WithNaNValues2() {
                                                                                                                                // Create a test dataset with both valid numbers and NaN values
                                                                                                                                XYSeries series = new XYSeries("Test Series");
                                                                                                                                series.add(1.0, 10.0);
                                                                                                                                series.add(Double.NaN, 20.0);  // NaN domain value
                                                                                                                                series.add(3.0, 30.0);
                                                                                                                                series.add(4.0, Double.NaN);  // NaN range value (shouldn't affect domain bounds)
                                                                                                                                series.add(Double.NaN, 50.0);  // Another NaN domain value
                                                                                                                                
                                                                                                                                XYDataset dataset = new XYSeriesCollection(series);
                                                                                                                                
                                                                                                                                // Calculate domain bounds
                                                                                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                                
                                                                                                                                // Verify NaN values are excluded from bounds calculation
                                                                                                                                assertNotNull("Result should not be null", result);
                                                                                                                                assertEquals("Lower bound should be 1.0", 1.0, result.getLowerBound(), 0.0001);
                                                                                                                                assertEquals("Upper bound should be 3.0", 3.0, result.getUpperBound(), 0.0001);
                                                                                                                                
                                                                                                                                // Verify the range doesn't include NaN positions
                                                                                                                                assertFalse("Range should not include NaN positions", 
                                                                                                                                           result.contains(Double.NaN));
                                                                                                                            }

    @Test
                                                                                                                            public void testIterateDomainBoundsWithIntervalAndNaNValues() {
                                                                                                                                // Create mock IntervalXYDataset
                                                                                                                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                                                
                                                                                                                                // Setup mock behavior
                                                                                                                                when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                                when(dataset.getItemCount(0)).thenReturn(3);
                                                                                                                                
                                                                                                                                // First item: valid value with NaN interval
                                                                                                                                when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                                                                                when(dataset.getStartXValue(0, 0)).thenReturn(Double.NaN);
                                                                                                                                when(dataset.getEndXValue(0, 0)).thenReturn(Double.NaN);
                                                                                                                                
                                                                                                                                // Second item: NaN value with valid interval
                                                                                                                                when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                                when(dataset.getStartXValue(0, 1)).thenReturn(2.0);
                                                                                                                                when(dataset.getEndXValue(0, 1)).thenReturn(8.0);
                                                                                                                                
                                                                                                                                // Third item: all valid values
                                                                                                                                when(dataset.getXValue(0, 2)).thenReturn(3.0);
                                                                                                                                when(dataset.getStartXValue(0, 2)).thenReturn(1.0);
                                                                                                                                when(dataset.getEndXValue(0, 2)).thenReturn(4.0);
                                                                                                                                
                                                                                                                                // Test with includeInterval=true
                                                                                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                                                
                                                                                                                                // Verify results
                                                                                                                                assertNotNull("Result should not be null", result);
                                                                                                                                assertEquals("Minimum should be 1.0", 1.0, result.getLowerBound(), 0.0001);
                                                                                                                                assertEquals("Maximum should be 8.0", 8.0, result.getUpperBound(), 0.0001);
                                                                                                                                
                                                                                                                                // Verify interactions - ensure all values were accessed
                                                                                                                                verify(dataset, times(3)).getXValue(0, anyInt());
                                                                                                                                verify(dataset, times(3)).getStartXValue(0, anyInt());
                                                                                                                                verify(dataset, times(3)).getEndXValue(0, anyInt());
                                                                                                                            }

    @Test
                                                                                                                        public void testIterateDomainBounds_WithNaNValues3() {
                                                                                                                            // Create a test dataset with NaN values
                                                                                                                            XYSeries series = new XYSeries("Test");
                                                                                                                            series.add(1.0, 1.0);
                                                                                                                            series.add(Double.NaN, 2.0);  // NaN domain value
                                                                                                                            series.add(3.0, 3.0);
                                                                                                                            XYSeriesCollection dataset = new XYSeriesCollection();
                                                                                                                            dataset.addSeries(series);
                                                                                                                            
                                                                                                                            // Call the method under test
                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                            
                                                                                                                            // Verify NaN was properly excluded
                                                                                                                            assertNotNull("Result should not be null", result);
                                                                                                                            assertEquals("Lower bound should be 1.0", 1.0, result.getLowerBound(), 0.0001);
                                                                                                                            assertEquals("Upper bound should be 3.0", 3.0, result.getUpperBound(), 0.0001);
                                                                                                                            
                                                                                                                            // This test would fail with the mutant since it would try to include NaN in bounds calculation
                                                                                                                        }

    @Test
                                                                                                                        public void testIterateDomainBounds_AllNaNValues1() {
                                                                                                                            // Create a dataset with only NaN values
                                                                                                                            XYSeries series = new XYSeries("Test");
                                                                                                                            series.add(Double.NaN, 1.0);
                                                                                                                            series.add(Double.NaN, 2.0);
                                                                                                                            XYSeriesCollection dataset = new XYSeriesCollection();
                                                                                                                            dataset.addSeries(series);
                                                                                                                            
                                                                                                                            // Call the method under test
                                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                            
                                                                                                                            // Verify result is null when all values are NaN
                                                                                                                            assertNull("Result should be null for all NaN values", result);
                                                                                                                            
                                                                                                                            // This test would fail with the mutant since it would try to process NaN values
                                                                                                                        }

    @Test
                                                                                                                    public void testIterateDomainBounds_ShouldIgnoreNaNValues() {
                                                                                                                        // Create mock IntervalXYDataset with NaN values
                                                                                                                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                        when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                        
                                                                                                                        // First item has valid numbers
                                                                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                                        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                                                                                        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                                                                                        
                                                                                                                        // Second item has NaN values
                                                                                                                        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                        when(dataset.getStartXValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                        when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                        
                                                                                                                        // Call method with includeInterval=true
                                                                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                                        
                                                                                                                        // Verify NaN values were ignored and only valid numbers considered
                                                                                                                        assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                                                                        assertEquals(1.5, result.getUpperBound(), 0.0001);
                                                                                                                        
                                                                                                                        // The mutant version would fail this test because it would try to process NaN values,
                                                                                                                        // potentially causing incorrect min/max calculations or even exceptions
                                                                                                                    }

    @Test
                                                                                                                    public void testIterateDomainBoundsShouldReturnCorrectMaximumValue() {
                                                                                                                        // Create a test dataset with known values
                                                                                                                        XYSeries series = new XYSeries("Test Series");
                                                                                                                        series.add(1.0, 100.0);
                                                                                                                        series.add(2.0, 200.0);
                                                                                                                        series.add(5.0, 500.0);  // This should be the maximum x-value
                                                                                                                        series.add(3.0, 300.0);
                                                                                                                        
                                                                                                                        XYDataset dataset = new XYSeriesCollection(series);
                                                                                                                        
                                                                                                                        // Call the method under test
                                                                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                        
                                                                                                                        // Verify the upper bound is the maximum x-value (5.0)
                                                                                                                        // This will fail if the mutant is present (would return 1.0 instead)
                                                                                                                        assertEquals("Upper bound should be maximum x-value", 
                                                                                                                                     5.0, result.getUpperBound(), 0.0001);
                                                                                                                        
                                                                                                                        // Also verify lower bound for completeness
                                                                                                                        assertEquals("Lower bound should be minimum x-value", 
                                                                                                                                     1.0, result.getLowerBound(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testIterateDomainBoundsWithIntervalXYDatasetDetectsMaxMutation() {
                                                                                                                        // Create a mock IntervalXYDataset
                                                                                                                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                                        
                                                                                                                        // Setup test data - series 0 has 2 items with different values
                                                                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                        when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                        
                                                                                                                        // First item values
                                                                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                                        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                                                                                        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                                                                                        
                                                                                                                        // Second item values (has higher value)
                                                                                                                        when(dataset.getXValue(0, 1)).thenReturn(3.0);
                                                                                                                        when(dataset.getStartXValue(0, 1)).thenReturn(2.5);
                                                                                                                        when(dataset.getEndXValue(0, 1)).thenReturn(3.5);
                                                                                                                        
                                                                                                                        // Call method with includeInterval=true
                                                                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                                        
                                                                                                                        // Verify the maximum is correctly calculated (should be 3.5)
                                                                                                                        // This will fail if the mutant is present (would return 1.0 instead)
                                                                                                                        assertNotNull(result);
                                                                                                                        assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                                                                        assertEquals(3.5, result.getUpperBound(), 0.0001);
                                                                                                                        
                                                                                                                        // Verify interactions with mock
                                                                                                                        verify(dataset, atLeastOnce()).getSeriesCount();
                                                                                                                        verify(dataset, atLeastOnce()).getItemCount(0);
                                                                                                                    }

    @Test
                                                                                                                public void testIterateDomainBoundsShouldReturnCorrectMaximumValue1() {
                                                                                                                    // Create a test dataset with known values
                                                                                                                    XYSeries series = new XYSeries("Test Series");
                                                                                                                    series.add(1.0, 100.0);  // x, y values
                                                                                                                    series.add(2.0, 200.0);
                                                                                                                    series.add(5.0, 500.0);  // This should be the maximum x-value
                                                                                                                    series.add(3.0, 300.0);
                                                                                                                    
                                                                                                                    XYDataset dataset = new XYSeriesCollection(series);
                                                                                                                    
                                                                                                                    // Call the method under test
                                                                                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                    
                                                                                                                    // Verify the range contains the correct maximum value
                                                                                                                    assertNotNull("Returned range should not be null", result);
                                                                                                                    assertEquals("Upper bound should be 5.0 (maximum x-value)", 
                                                                                                                        5.0, result.getUpperBound(), 0.0001);
                                                                                                                    
                                                                                                                    // Also verify the full range for completeness
                                                                                                                    assertEquals("Lower bound should be 1.0 (minimum x-value)",
                                                                                                                        1.0, result.getLowerBound(), 0.0001);
                                                                                                                }

    @Test
                                                                                                                public void testIterateDomainBoundsWithIntervalXYDatasetDetectsMaxMutation1() {
                                                                                                                    // Create mock IntervalXYDataset
                                                                                                                    IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                                    
                                                                                                                    // Setup mock behavior
                                                                                                                    when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                    when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                                    
                                                                                                                    // First item values
                                                                                                                    when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                                                                    when(dataset.getStartXValue(0, 0)).thenReturn(4.0);
                                                                                                                    when(dataset.getEndXValue(0, 0)).thenReturn(6.0);
                                                                                                                    
                                                                                                                    // Second item values - lvalue is larger than first item's values
                                                                                                                    when(dataset.getXValue(0, 1)).thenReturn(7.0);
                                                                                                                    when(dataset.getStartXValue(0, 1)).thenReturn(8.0); // This should become new max
                                                                                                                    when(dataset.getEndXValue(0, 1)).thenReturn(9.0);
                                                                                                                    
                                                                                                                    // Execute method with includeInterval=true
                                                                                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                                    
                                                                                                                    // Verify results
                                                                                                                    assertNotNull("Result should not be null", result);
                                                                                                                    assertEquals("Lower bound should be minimum value", 4.0, result.getLowerBound(), 0.0001);
                                                                                                                    assertEquals("Upper bound should be maximum value (9.0)", 9.0, result.getUpperBound(), 0.0001);
                                                                                                                    // The mutant would return 8.0 (Math.min of previous max and 8.0) instead of 9.0
                                                                                                                }

    @Test
                                                                                                            public void testIterateDomainBounds_ShouldIgnoreNaNValues1() {
                                                                                                                // Create a mock XYDataset that returns some NaN values
                                                                                                                XYDataset dataset = mock(XYDataset.class);
                                                                                                                when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                                when(dataset.getItemCount(0)).thenReturn(3);
                                                                                                                
                                                                                                                // Setup values: first and third are valid, middle is NaN
                                                                                                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                                when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                                                                when(dataset.getXValue(0, 2)).thenReturn(3.0);
                                                                                                                
                                                                                                                // Call the method
                                                                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                                
                                                                                                                // Verify the range only includes non-NaN values (1.0 to 3.0)
                                                                                                                assertNotNull(result);
                                                                                                                assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                                                
                                                                                                                // The mutant would fail this test because it would try to include NaN in bounds calculation,
                                                                                                                // which would either throw an exception or produce incorrect bounds
                                                                                                            }

    @Test
                                                                                                        public void testIterateDomainBounds_ShouldIgnoreNaNUpperValues() {
                                                                                                            // Create mock IntervalXYDataset
                                                                                                            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                            
                                                                                                            // Setup test data - include NaN in uvalue
                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                            
                                                                                                            // First item - valid values
                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                            when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                                                                            when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                                                                            
                                                                                                            // Second item - include NaN in uvalue
                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                                            when(dataset.getStartXValue(0, 1)).thenReturn(1.5);
                                                                                                            when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
                                                                                                            
                                                                                                            // Call method with includeInterval=true
                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                            
                                                                                                            // Verify results - NaN uvalue should be ignored
                                                                                                            // Original: Range should be (0.5, 2.0)
                                                                                                            // Mutated: Would include NaN in calculations, potentially corrupting range
                                                                                                            assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                                                            assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                                                            
                                                                                                            // Additional verification that NaN wasn't included
                                                                                                            assertFalse(Double.isNaN(result.getLowerBound()));
                                                                                                            assertFalse(Double.isNaN(result.getUpperBound()));
                                                                                                        }

    @Test
                                                                                                        public void testIterateDomainBoundsWithNegativeValues2() {
                                                                                                            // Create a dataset with negative values
                                                                                                            XYSeries series = new XYSeries("Test Series");
                                                                                                            series.add(-5.0, 1.0);
                                                                                                            series.add(-2.0, 2.0);
                                                                                                            series.add(0.0, 3.0);
                                                                                                            series.add(3.0, 4.0);
                                                                                                            
                                                                                                            XYDataset dataset = new XYSeriesCollection(series);
                                                                                                            
                                                                                                            // Call the method under test
                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                            
                                                                                                            // Verify the range includes all values (including negatives)
                                                                                                            assertNotNull("Result should not be null", result);
                                                                                                            assertEquals("Lower bound should include negative value", -5.0, result.getLowerBound(), 0.0001);
                                                                                                            assertEquals("Upper bound should be correct", 3.0, result.getUpperBound(), 0.0001);
                                                                                                            
                                                                                                            // This test will fail on the mutant because:
                                                                                                            // - Mutant would exclude -5.0 and -2.0 (since they're negative)
                                                                                                            // - Expected lower bound would be 0.0 instead of -5.0
                                                                                                        }

    @Test
                                                                                                        public void testIterateDomainBoundsWithNegativeValuesInIntervalDataset() {
                                                                                                            // Create mock IntervalXYDataset
                                                                                                            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                            
                                                                                                            // Setup test data with negative values
                                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                            when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                            
                                                                                                            // First item: negative value
                                                                                                            when(dataset.getXValue(0, 0)).thenReturn(-2.0);
                                                                                                            when(dataset.getStartXValue(0, 0)).thenReturn(-3.0);
                                                                                                            when(dataset.getEndXValue(0, 0)).thenReturn(-1.0);
                                                                                                            
                                                                                                            // Second item: positive value
                                                                                                            when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                                            when(dataset.getStartXValue(0, 1)).thenReturn(1.0);
                                                                                                            when(dataset.getEndXValue(0, 1)).thenReturn(3.0);
                                                                                                    
                                                                                                            // Call method with includeInterval=true
                                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                            
                                                                                                            // Verify the range includes negative values
                                                                                                            assertNotNull("Result should not be null", result);
                                                                                                            assertEquals("Lower bound should include negative value", -3.0, result.getLowerBound(), 0.0001);
                                                                                                            assertEquals("Upper bound should include positive value", 3.0, result.getUpperBound(), 0.0001);
                                                                                                            
                                                                                                            // The mutant would fail this test because it would ignore negative values,
                                                                                                            // resulting in range of (1.0, 3.0) instead of (-3.0, 3.0)
                                                                                                        }

    @Test
                                                                                                    public void testIterateDomainBoundsWithNonEmptyDataset() {
                                                                                                        // Create a mock XYDataset with 3 series
                                                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                                                        when(dataset.getSeriesCount()).thenReturn(3);
                                                                                                        // Setup mock behavior for each series
                                                                                                        when(dataset.getItemCount(anyInt())).thenReturn(2);
                                                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                        when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                                        when(dataset.getXValue(1, 0)).thenReturn(1.5);
                                                                                                        when(dataset.getXValue(1, 1)).thenReturn(2.5);
                                                                                                        when(dataset.getXValue(2, 0)).thenReturn(0.5);
                                                                                                        when(dataset.getXValue(2, 1)).thenReturn(3.0);
                                                                                                        
                                                                                                        // Test the method - should work without exceptions
                                                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                        assertNotNull(result);
                                                                                                        assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                                                        assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                                    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                                                    public void testIterateDomainBoundsDetectsMutant() {
                                                                                                        // Create a mock XYDataset with 1 series
                                                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                        // Setup mock behavior for the series
                                                                                                        when(dataset.getItemCount(0)).thenReturn(1);
                                                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                        
                                                                                                        // The mutant will try to access series 1 (which doesn't exist)
                                                                                                        // This should throw ArrayIndexOutOfBoundsException for the mutant
                                                                                                        // but work fine for the original code
                                                                                                        DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                        
                                                                                                        // If we reach here, the mutant wasn't detected
                                                                                                        // So we force a fail (though the expected exception should catch it first)
                                                                                                        fail("Mutant not detected - loop condition incorrect");
                                                                                                    }

    @Test
                                                                                                    public void testIterateDomainBoundsWithEmptyDataset() {
                                                                                                        // Create a mock empty XYDataset
                                                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                                                        when(dataset.getSeriesCount()).thenReturn(0);
                                                                                                        
                                                                                                        // Should return null for empty dataset
                                                                                                        assertNull(DatasetUtilities.iterateDomainBounds(dataset));
                                                                                                    }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                    public void testIterateDomainBoundsWithInterval_MutantDetection() {
                                                                                                        // Create mock IntervalXYDataset with 1 series
                                                                                                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                        when(dataset.getItemCount(0)).thenReturn(1);
                                                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                                                                        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                                                                        
                                                                                                        // This should throw IndexOutOfBoundsException for the mutant
                                                                                                        // because it will try to access series 1 (which doesn't exist)
                                                                                                        DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                    }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                    public void testIterateDomainBoundsWithoutInterval_MutantDetection() {
                                                                                                        // Create mock XYDataset with 1 series
                                                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                        when(dataset.getItemCount(0)).thenReturn(1);
                                                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                        
                                                                                                        // This should throw IndexOutOfBoundsException for the mutant
                                                                                                        DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                                                    }

    @Test
                                                                                                    public void testIterateDomainBoundsWithInterval_CorrectBehavior() {
                                                                                                        // Create mock IntervalXYDataset with 1 series
                                                                                                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                        when(dataset.getItemCount(0)).thenReturn(1);
                                                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                                                                        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                                                                        
                                                                                                        // Original code should work fine
                                                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                        assertNotNull(result);
                                                                                                        assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                                                        assertEquals(1.5, result.getUpperBound(), 0.0001);
                                                                                                    }

    @Test
                                                                                                    public void testIterateDomainBoundsWithoutInterval_CorrectBehavior() {
                                                                                                        // Create mock XYDataset with 1 series
                                                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                        when(dataset.getItemCount(0)).thenReturn(1);
                                                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                        
                                                                                                        // Original code should work fine
                                                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                                                        assertNotNull(result);
                                                                                                        assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                        assertEquals(1.0, result.getUpperBound(), 0.0001);
                                                                                                    }

    @Test
                                                                                                public void testIterateDomainBoundsWithMultipleSeriesDifferentItemCounts() {
                                                                                                    // Create mock dataset with 2 series having different item counts
                                                                                                    XYDataset dataset = mock(XYDataset.class);
                                                                                                    when(dataset.getSeriesCount()).thenReturn(2);
                                                                                                    
                                                                                                    // Series 0 has 3 items with x-values 1.0, 2.0, 3.0
                                                                                                    when(dataset.getItemCount(0)).thenReturn(3);
                                                                                                    when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                    when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                                    when(dataset.getXValue(0, 2)).thenReturn(3.0);
                                                                                                    
                                                                                                    // Series 1 has 2 items with x-values 0.5, 4.0
                                                                                                    when(dataset.getItemCount(1)).thenReturn(2);
                                                                                                    when(dataset.getXValue(1, 0)).thenReturn(0.5);
                                                                                                    when(dataset.getXValue(1, 1)).thenReturn(4.0);
                                                                                                    
                                                                                                    // Expected range should be from 0.5 (min of all items) to 4.0 (max of all items)
                                                                                                    Range expected = new Range(0.5, 4.0);
                                                                                                    
                                                                                                    // Call method under test
                                                                                                    Range actual = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                    
                                                                                                    // Verify the range includes all items from both series
                                                                                                    assertEquals("Domain bounds should cover all items from all series", 
                                                                                                                expected, actual);
                                                                                                }

    @Test
                                                                                                public void testIterateDomainBoundsWithDifferentSeriesItemCounts() {
                                                                                                    // Create dataset with different item counts per series
                                                                                                    XYSeries series1 = new XYSeries("Series1");
                                                                                                    series1.add(1.0, 1.0);
                                                                                                    series1.add(2.0, 2.0); // Series1 has 2 items
                                                                                                    
                                                                                                    XYSeries series2 = new XYSeries("Series2");
                                                                                                    series2.add(3.0, 3.0);
                                                                                                    series2.add(4.0, 4.0);
                                                                                                    series2.add(5.0, 5.0); // Series2 has 3 items
                                                                                                    
                                                                                                    XYSeriesCollection dataset = new XYSeriesCollection();
                                                                                                    dataset.addSeries(series1);
                                                                                                    dataset.addSeries(series2);
                                                                                                    
                                                                                                    // Call method under test
                                                                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                                                    
                                                                                                    // Verify all items were processed (min=1.0, max=5.0)
                                                                                                    // Mutant would only process first 2 items of series2 (max=4.0)
                                                                                                    assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                    assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                }

    @Test
                                                                                                public void testIterateDomainBoundsWithIntervalAndDifferentSeriesItemCounts() {
                                                                                                    // Create mock IntervalXYDataset with different item counts
                                                                                                    IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                                    when(dataset.getSeriesCount()).thenReturn(2);
                                                                                                    
                                                                                                    // Series 0 has 2 items
                                                                                                    when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                    when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                                    when(dataset.getStartXValue(0, 0)).thenReturn(0.9);
                                                                                                    when(dataset.getEndXValue(0, 0)).thenReturn(1.1);
                                                                                                    when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                                                    when(dataset.getStartXValue(0, 1)).thenReturn(1.9);
                                                                                                    when(dataset.getEndXValue(0, 1)).thenReturn(2.1);
                                                                                                    
                                                                                                    // Series 1 has 3 items
                                                                                                    when(dataset.getItemCount(1)).thenReturn(3);
                                                                                                    when(dataset.getXValue(1, 0)).thenReturn(3.0);
                                                                                                    when(dataset.getStartXValue(1, 0)).thenReturn(2.9);
                                                                                                    when(dataset.getEndXValue(1, 0)).thenReturn(3.1);
                                                                                                    when(dataset.getXValue(1, 1)).thenReturn(4.0);
                                                                                                    when(dataset.getStartXValue(1, 1)).thenReturn(3.9);
                                                                                                    when(dataset.getEndXValue(1, 1)).thenReturn(4.1);
                                                                                                    when(dataset.getXValue(1, 2)).thenReturn(5.0);
                                                                                                    when(dataset.getStartXValue(1, 2)).thenReturn(4.9);
                                                                                                    when(dataset.getEndXValue(1, 2)).thenReturn(5.1);
                                                                                                    
                                                                                                    // Call method under test with includeInterval=true
                                                                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                                    
                                                                                                    // Verify all items were processed (min=0.9, max=5.1)
                                                                                                    // Mutant would only process first 2 items of series1 (max=2.1)
                                                                                                    assertEquals(0.9, result.getLowerBound(), 0.0001);
                                                                                                    assertEquals(5.1, result.getUpperBound(), 0.0001);
                                                                                                }

    @Test
                                                                                            public void testIterateDomainBoundsShouldReturnCorrectMaximumValue2() {
                                                                                                // Create a test dataset with known values
                                                                                                XYSeries series = new XYSeries("Test Series");
                                                                                                series.add(1.0, 100.0);  // x, y values
                                                                                                series.add(2.0, 200.0);
                                                                                                series.add(5.0, 300.0);  // 5.0 should be the maximum x-value
                                                                                                series.add(3.0, 400.0);
                                                                                                XYDataset dataset = new XYSeriesCollection(series);
                                                                                                
                                                                                                // Call the method under test
                                                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                                
                                                                                                // Verify the upper bound is the maximum x-value
                                                                                                assertEquals("Upper bound should be 5.0", 5.0, result.getUpperBound(), 0.0001);
                                                                                                
                                                                                                // Also verify the full range for completeness
                                                                                                assertEquals("Lower bound should be 1.0", 1.0, result.getLowerBound(), 0.0001);
                                                                                            }

    @Test
                                                                                            public void testIterateDomainBounds_NonIntervalDataset_DetectsMaxMutation() {
                                                                                                // Create a mock XYDataset (not IntervalXYDataset)
                                                                                                XYDataset dataset = mock(XYDataset.class);
                                                                                                
                                                                                                // Setup mock behavior
                                                                                                when(dataset.getSeriesCount()).thenReturn(1);
                                                                                                when(dataset.getItemCount(0)).thenReturn(2);
                                                                                                
                                                                                                // First item value (smaller)
                                                                                                when(dataset.getXValue(0, 0)).thenReturn(10.0);
                                                                                                // Second item value (larger - should become new max)
                                                                                                when(dataset.getXValue(0, 1)).thenReturn(20.0);
                                                                                                
                                                                                                // Execute method under test
                                                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                                                
                                                                                                // Verify results
                                                                                                assertNotNull("Should not return null for valid data", result);
                                                                                                assertEquals("Minimum should be smallest value", 10.0, result.getLowerBound(), 0.0001);
                                                                                                assertEquals("Maximum should be largest value (mutation would make this wrong)", 
                                                                                                            20.0, result.getUpperBound(), 0.0001);
                                                                                                
                                                                                                // Verify mock interactions
                                                                                                verify(dataset).getSeriesCount();
                                                                                                verify(dataset, times(2)).getItemCount(0);
                                                                                                verify(dataset, times(2)).getXValue(anyInt(), anyInt());
                                                                                            }

    @Test
                                                                                        public void testIterateDomainBounds_WithNaNValues4() {
                                                                                            // Create a dataset with NaN values
                                                                                            XYSeries series = new XYSeries("Test Series");
                                                                                            series.add(1.0, 10.0);
                                                                                            series.add(2.0, Double.NaN); // NaN value
                                                                                            series.add(3.0, 30.0);
                                                                                            
                                                                                            XYSeriesCollection dataset = new XYSeriesCollection();
                                                                                            dataset.addSeries(series);
                                                                                            
                                                                                            // Calculate domain bounds
                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                            
                                                                                            // Verify NaN values don't affect the bounds
                                                                                            assertNotNull("Result should not be null", result);
                                                                                            assertEquals("Lower bound should be 1.0", 1.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals("Upper bound should be 3.0", 3.0, result.getUpperBound(), 0.0001);
                                                                                            
                                                                                            // This test will fail on the mutant because:
                                                                                            // - Original: NaN values are excluded, bounds are 1.0-3.0
                                                                                            // - Mutant: NaN values would be included, potentially causing incorrect bounds
                                                                                        }

    @Test
                                                                                        public void testIterateDomainBounds_WithNaNUpperValue() {
                                                                                            // Create mock IntervalXYDataset
                                                                                            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                            
                                                                                            // Setup mock behavior
                                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                                            when(dataset.getItemCount(0)).thenReturn(1);
                                                                                            when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                                            when(dataset.getStartXValue(0, 0)).thenReturn(3.0);
                                                                                            when(dataset.getEndXValue(0, 0)).thenReturn(Double.NaN); // NaN upper value
                                                                                            
                                                                                            // Call method with includeInterval=true
                                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                            
                                                                                            // Verify correct behavior (should ignore NaN uvalue)
                                                                                            assertNotNull(result);
                                                                                            assertEquals(3.0, result.getLowerBound(), 0.0001);
                                                                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                            
                                                                                            // Verify interactions
                                                                                            verify(dataset).getSeriesCount();
                                                                                            verify(dataset).getItemCount(0);
                                                                                            verify(dataset).getXValue(0, 0);
                                                                                            verify(dataset).getStartXValue(0, 0);
                                                                                            verify(dataset).getEndXValue(0, 0);
                                                                                        }

    @Test
                                                                                    public void testIterateDomainBoundsShouldFindActualMaximumNotJustLastValue() {
                                                                                        // Create a dataset where maximum value is not the last one
                                                                                        XYSeries series = new XYSeries("Test Series");
                                                                                        series.add(1.0, 100.0);  // First value
                                                                                        series.add(5.0, 200.0);  // This is the actual maximum
                                                                                        series.add(3.0, 150.0);  // Last value but not maximum
                                                                                        series.add(2.0, 120.0);  // Additional value
                                                                                        
                                                                                        XYDataset dataset = new XYSeriesCollection(series);
                                                                                        
                                                                                        // Call the method under test
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                        
                                                                                        // Verify the range contains the actual maximum (5.0)
                                                                                        assertEquals("Lower bound should be minimum value", 1.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals("Upper bound should be maximum value (5.0), not just last value (3.0)", 
                                                                                                     5.0, result.getUpperBound(), 0.0001);
                                                                                    }

    @Test
                                                                                    public void testIterateDomainBounds_DetectMaxValueMutation() {
                                                                                        // Create a mock IntervalXYDataset
                                                                                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                        
                                                                                        // Setup dataset behavior
                                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                                        when(dataset.getItemCount(0)).thenReturn(3);
                                                                                        
                                                                                        // Setup values that fluctuate (not monotonically increasing)
                                                                                        when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                                        when(dataset.getStartXValue(0, 0)).thenReturn(4.0);
                                                                                        when(dataset.getEndXValue(0, 0)).thenReturn(6.0);
                                                                                        
                                                                                        when(dataset.getXValue(0, 1)).thenReturn(8.0);
                                                                                        when(dataset.getStartXValue(0, 1)).thenReturn(7.0);
                                                                                        when(dataset.getEndXValue(0, 1)).thenReturn(9.0);
                                                                                        
                                                                                        when(dataset.getXValue(0, 2)).thenReturn(4.0); // This is less than previous max
                                                                                        when(dataset.getStartXValue(0, 2)).thenReturn(3.0);
                                                                                        when(dataset.getEndXValue(0, 2)).thenReturn(5.0);
                                                                                        
                                                                                        // Call the method with includeInterval=true
                                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                        
                                                                                        // Verify the maximum is correctly calculated (should be 9.0, not 5.0)
                                                                                        assertNotNull(result);
                                                                                        assertEquals(3.0, result.getLowerBound(), 0.0001);
                                                                                        assertEquals(9.0, result.getUpperBound(), 0.0001); // This will fail if mutant is present
                                                                                    }

    @Test
                                                                                public void testIterateDomainBoundsWithNonAscendingValues() {
                                                                                    // Create a mock XYDataset with non-ascending values
                                                                                    XYDataset dataset = mock(XYDataset.class);
                                                                                    
                                                                                    // Setup mock behavior
                                                                                    when(dataset.getSeriesCount()).thenReturn(1);
                                                                                    when(dataset.getItemCount(0)).thenReturn(3);
                                                                                    when(dataset.getXValue(0, 0)).thenReturn(5.0);  // first value (not smallest)
                                                                                    when(dataset.getXValue(0, 1)).thenReturn(2.0);  // smallest value
                                                                                    when(dataset.getXValue(0, 2)).thenReturn(4.0);  // last value (not smallest)
                                                                                    
                                                                                    // Call the method under test
                                                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                                    
                                                                                    // Verify the result captures the true minimum (2.0), not the last value (4.0)
                                                                                    assertEquals("Lower bound should be the minimum value (2.0)", 
                                                                                        2.0, result.getLowerBound(), 0.0001);
                                                                                    assertEquals("Upper bound should be the maximum value (5.0)",
                                                                                        5.0, result.getUpperBound(), 0.0001);
                                                                                }

    @Test
                                                                            public void testIterateDomainBounds_DetectMinimumMutation() {
                                                                                // Create a mock IntervalXYDataset with fluctuating lvalues
                                                                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                when(dataset.getSeriesCount()).thenReturn(1);
                                                                                when(dataset.getItemCount(0)).thenReturn(3);
                                                                                
                                                                                // Setup values where lvalues go: 5.0, 2.0, 3.0 (minimum should be 2.0)
                                                                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                when(dataset.getStartXValue(0, 0)).thenReturn(5.0);
                                                                                when(dataset.getEndXValue(0, 0)).thenReturn(5.0);
                                                                                
                                                                                when(dataset.getXValue(0, 1)).thenReturn(1.0);
                                                                                when(dataset.getStartXValue(0, 1)).thenReturn(2.0);
                                                                                when(dataset.getEndXValue(0, 1)).thenReturn(2.0);
                                                                                
                                                                                when(dataset.getXValue(0, 2)).thenReturn(1.0);
                                                                                when(dataset.getStartXValue(0, 2)).thenReturn(3.0);
                                                                                when(dataset.getEndXValue(0, 2)).thenReturn(3.0);
                                                                                
                                                                                // Call method with includeInterval=true
                                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                
                                                                                // Verify the minimum is correctly calculated (2.0)
                                                                                // This will fail if mutation is present (would get 3.0 instead)
                                                                                assertNotNull(result);
                                                                                assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                            }

    @Test
                                                                            public void testIterateDomainBoundsWithMultipleValues() {
                                                                                // Create a mock XYDataset
                                                                                XYDataset dataset = mock(XYDataset.class);
                                                                                
                                                                                // Configure the mock to return 3 items in series 0
                                                                                when(dataset.getSeriesCount()).thenReturn(1);
                                                                                when(dataset.getItemCount(0)).thenReturn(3);
                                                                                
                                                                                // Set up values where:
                                                                                // - First value is 1.0
                                                                                // - Second value is 3.0 (maximum)
                                                                                // - Third value is 2.0
                                                                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                                when(dataset.getXValue(0, 1)).thenReturn(3.0);
                                                                                when(dataset.getXValue(0, 2)).thenReturn(2.0);
                                                                                
                                                                                // Call the method
                                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                
                                                                                // Verify the range contains the correct bounds
                                                                                // Original should be 1.0 to 3.0
                                                                                // Mutant would return 1.0 to 2.0 (incorrect)
                                                                                assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                                                
                                                                                // Verify interactions with the mock
                                                                                verify(dataset).getSeriesCount();
                                                                                verify(dataset, times(3)).getItemCount(0);
                                                                                verify(dataset).getXValue(0, 0);
                                                                                verify(dataset).getXValue(0, 1);
                                                                                verify(dataset).getXValue(0, 2);
                                                                            }

    @Test
                                                                            public void testIterateDomainBounds_DetectMaxMutation() {
                                                                                // Create a mock IntervalXYDataset
                                                                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                                
                                                                                // Setup dataset behavior
                                                                                when(dataset.getSeriesCount()).thenReturn(1);
                                                                                when(dataset.getItemCount(0)).thenReturn(2);
                                                                                
                                                                                // First item values
                                                                                when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                                when(dataset.getStartXValue(0, 0)).thenReturn(4.0); // lvalue
                                                                                when(dataset.getEndXValue(0, 0)).thenReturn(6.0);  // uvalue
                                                                                
                                                                                // Second item values - lvalue is smaller than previous maximum (6.0)
                                                                                when(dataset.getXValue(0, 1)).thenReturn(3.0);
                                                                                when(dataset.getStartXValue(0, 1)).thenReturn(2.0); // lvalue
                                                                                when(dataset.getEndXValue(0, 1)).thenReturn(4.0);  // uvalue
                                                                                
                                                                                // Call method with includeInterval=true
                                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                                
                                                                                // Verify the maximum is properly maintained (should be 6.0, not 2.0)
                                                                                assertNotNull(result);
                                                                                assertEquals(2.0, result.getLowerBound(), 0.0001); // minimum from lvalue=2.0
                                                                                assertEquals(6.0, result.getUpperBound(), 0.0001);  // maximum should stay 6.0
                                                                            }

    @Test
                                                                        public void testIterateDomainBounds_DetectsMaximumMutation() {
                                                                            // Create a mock XYDataset with values where maximum isn't last
                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                            
                                                                            // Configure the mock
                                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                                            when(dataset.getItemCount(0)).thenReturn(3);
                                                                            when(dataset.getXValue(0, 0)).thenReturn(5.0);  // Not max
                                                                            when(dataset.getXValue(0, 1)).thenReturn(10.0); // Max value
                                                                            when(dataset.getXValue(0, 2)).thenReturn(7.0);  // Not max
                                                                            
                                                                            // Call the method under test
                                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                            
                                                                            // Verify the range contains the true maximum (10.0)
                                                                            assertEquals("Upper bound should be 10.0 (maximum value in dataset)", 
                                                                                         10.0, result.getUpperBound(), 0.0001);
                                                                            
                                                                            // Also verify the lower bound for completeness
                                                                            assertEquals("Lower bound should be 5.0 (minimum value in dataset)",
                                                                                         5.0, result.getLowerBound(), 0.0001);
                                                                        }

    @Test
                                                                    public void testIterateDomainBounds_IntervalDataset_DetectsMaxMutation() {
                                                                        // Create a mock IntervalXYDataset
                                                                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                        
                                                                        // Setup test data where:
                                                                        // - Series 0 has 2 items
                                                                        // - First item has values (1.0, 0.5, 1.5)
                                                                        // - Second item has values (2.0, 1.5, 2.5)
                                                                        // The maximum should be 2.5, but mutant would return 2.5 (last uvalue) by coincidence
                                                                        // So we add third item (3.0, 2.0, 2.8) where 2.8 is not the overall max
                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                        when(dataset.getItemCount(0)).thenReturn(3);
                                                                        
                                                                        // First item
                                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                                        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                                        
                                                                        // Second item
                                                                        when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                        when(dataset.getStartXValue(0, 1)).thenReturn(1.5);
                                                                        when(dataset.getEndXValue(0, 1)).thenReturn(2.5);
                                                                        
                                                                        // Third item (critical for catching mutant)
                                                                        when(dataset.getXValue(0, 2)).thenReturn(3.0);
                                                                        when(dataset.getStartXValue(0, 2)).thenReturn(2.0);
                                                                        when(dataset.getEndXValue(0, 2)).thenReturn(2.8);
                                                                        
                                                                        // Execute
                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                        
                                                                        // Verify - original would return (0.5, 3.0), mutant would return (0.5, 2.8)
                                                                        assertNotNull(result);
                                                                        assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                        assertEquals(3.0, result.getUpperBound(), 0.0001); // This would fail for the mutant
                                                                    }

    @Test
                                                                    public void testIterateDomainBoundsWithNegativeValues3() {
                                                                        // Create a dataset with negative values
                                                                        XYSeries series = new XYSeries("Test Series");
                                                                        series.add(-5.0, 1.0);
                                                                        series.add(-2.0, 2.0);
                                                                        series.add(0.0, 3.0);
                                                                        series.add(3.0, 4.0);
                                                                        
                                                                        XYDataset dataset = new XYSeriesCollection(series);
                                                                        
                                                                        // Calculate domain bounds
                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                        
                                                                        // Verify the range includes all values (including negatives)
                                                                        assertNotNull("Result should not be null", result);
                                                                        assertEquals("Lower bound should include negative value", 
                                                                            -5.0, result.getLowerBound(), 0.0001);
                                                                        assertEquals("Upper bound should include positive value", 
                                                                            3.0, result.getUpperBound(), 0.0001);
                                                                        
                                                                        // This test will fail with the mutant since it would exclude negative values,
                                                                        // resulting in a range of 0.0 to 3.0 instead of -5.0 to 3.0
                                                                    }

    @Test
                                                                    public void testIterateDomainBoundsWithNegativeValues4() {
                                                                        // Create a mock XYDataset with negative values
                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                                        when(dataset.getItemCount(0)).thenReturn(2);
                                                                        when(dataset.getXValue(0, 0)).thenReturn(-5.0); // negative value
                                                                        when(dataset.getXValue(0, 1)).thenReturn(10.0); // positive value
                                                                        
                                                                        // Call the method with includeInterval=false
                                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                        
                                                                        // Verify the range includes both negative and positive values
                                                                        assertNotNull("Result should not be null", result);
                                                                        assertEquals("Lower bound should include negative value", -5.0, result.getLowerBound(), 0.0001);
                                                                        assertEquals("Upper bound should include positive value", 10.0, result.getUpperBound(), 0.0001);
                                                                        
                                                                        // Verify interactions with the mock
                                                                        verify(dataset).getSeriesCount();
                                                                        verify(dataset).getItemCount(0);
                                                                        verify(dataset, times(2)).getXValue(anyInt(), anyInt());
                                                                    }

    @Test
                                                                public void testIterateDomainBoundsWithNegativeValues5() {
                                                                    // Create a dataset with negative values
                                                                    XYSeries series = new XYSeries("Test Series");
                                                                    series.add(-5.0, 1.0);
                                                                    series.add(-2.0, 2.0);
                                                                    series.add(0.0, 3.0);
                                                                    series.add(3.0, 4.0);
                                                                    
                                                                    XYDataset dataset = new XYSeriesCollection(series);
                                                                    
                                                                    // Calculate bounds
                                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                    
                                                                    // Verify the range includes all values (including negatives)
                                                                    assertNotNull("Result should not be null", result);
                                                                    assertEquals("Lower bound should include negative value", 
                                                                        -5.0, result.getLowerBound(), 0.0001);
                                                                    assertEquals("Upper bound should include positive value",
                                                                        3.0, result.getUpperBound(), 0.0001);
                                                                    
                                                                    // This test will fail with the mutant since it would exclude negative values
                                                                    // and only return range from 0 to 3
                                                                }

    @Test
                                                                public void testIterateDomainBoundsWithNegativeIntervalValues() {
                                                                    // Create a mock IntervalXYDataset with negative interval values
                                                                    IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                    when(dataset.getSeriesCount()).thenReturn(1);
                                                                    when(dataset.getItemCount(0)).thenReturn(1);
                                                                    
                                                                    // Setup test values - include negative uvalue
                                                                    when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                    when(dataset.getStartXValue(0, 0)).thenReturn(-2.0);
                                                                    when(dataset.getEndXValue(0, 0)).thenReturn(-1.5);  // Negative uvalue
                                                                    
                                                                    // Call the method with includeInterval=true
                                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                    
                                                                    // Verify the result includes the negative uvalue
                                                                    assertNotNull("Result should not be null", result);
                                                                    assertEquals("Lower bound should include negative value", -2.0, result.getLowerBound(), 0.0001);
                                                                    assertEquals("Upper bound should include positive value", 1.0, result.getUpperBound(), 0.0001);
                                                                    
                                                                    // Verify interactions
                                                                    verify(dataset).getSeriesCount();
                                                                    verify(dataset).getItemCount(0);
                                                                    verify(dataset).getXValue(0, 0);
                                                                    verify(dataset).getStartXValue(0, 0);
                                                                    verify(dataset).getEndXValue(0, 0);
                                                                }

    @Test
                                                            public void testIterateDomainBounds_ShouldProcessExactSeriesCount() {
                                                                // Create a mock XYDataset with 3 series
                                                                XYDataset dataset = mock(XYDataset.class);
                                                                when(dataset.getSeriesCount()).thenReturn(3);
                                                                
                                                                // Setup mock behavior for each series
                                                                when(dataset.getItemCount(0)).thenReturn(1);
                                                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                when(dataset.getItemCount(1)).thenReturn(1);
                                                                when(dataset.getXValue(1, 0)).thenReturn(2.0);
                                                                when(dataset.getItemCount(2)).thenReturn(1);
                                                                when(dataset.getXValue(2, 0)).thenReturn(3.0);
                                                                
                                                                // Call the method under test
                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                
                                                                // Verify the correct range was calculated
                                                                assertEquals(new Range(1.0, 3.0), result);
                                                                
                                                                // Verify exactly 3 series were processed (not 4)
                                                                verify(dataset, times(3)).getItemCount(anyInt());
                                                                verify(dataset, never()).getItemCount(3); // Should never try to access series 3
                                                            }

    @Test
                                                            public void testIterateDomainBounds_SeriesCountBoundary() {
                                                                // Create a mock XYDataset that is also an IntervalXYDataset
                                                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                
                                                                // Setup the mock behavior
                                                                when(dataset.getSeriesCount()).thenReturn(2);
                                                                when(dataset.getItemCount(0)).thenReturn(1);
                                                                when(dataset.getItemCount(1)).thenReturn(1);
                                                                
                                                                // Setup values for first series
                                                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                                when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                                
                                                                // Setup values for second series
                                                                when(dataset.getXValue(1, 0)).thenReturn(2.0);
                                                                when(dataset.getStartXValue(1, 0)).thenReturn(1.5);
                                                                when(dataset.getEndXValue(1, 0)).thenReturn(2.5);
                                                                
                                                                // Call the method with includeInterval=true
                                                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                
                                                                // Verify the expected range (should be min of all values to max of all values)
                                                                assertEquals(new Range(0.5, 2.5), result);
                                                                
                                                                // Verify the mock interactions - should only call for series 0 and 1
                                                                verify(dataset, times(2)).getItemCount(anyInt());
                                                                verify(dataset, never()).getItemCount(2); // Should not try to access series 2
                                                            }

    @Test
                                                        public void testIterateDomainBoundsWithInfiniteValues() {
                                                            // Create a mock XYDataset that contains finite, NaN and infinite values
                                                            XYDataset dataset = mock(XYDataset.class);
                                                            
                                                            // Setup mock behavior
                                                            when(dataset.getSeriesCount()).thenReturn(1);
                                                            when(dataset.getItemCount(0)).thenReturn(4);
                                                            
                                                            // First item: finite value
                                                            when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                            // Second item: NaN
                                                            when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                            // Third item: positive infinity
                                                            when(dataset.getXValue(0, 2)).thenReturn(Double.POSITIVE_INFINITY);
                                                            // Fourth item: negative infinity
                                                            when(dataset.getXValue(0, 3)).thenReturn(Double.NEGATIVE_INFINITY);
                                                            
                                                            // Call the method under test
                                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                            
                                                            // Verify the result
                                                            // Original behavior should include infinite values in bounds
                                                            // Mutant behavior would exclude them, resulting in range [1.0,1.0]
                                                            assertNotNull(result);
                                                            assertEquals(Double.NEGATIVE_INFINITY, result.getLowerBound(), 0.0001);
                                                            assertEquals(Double.POSITIVE_INFINITY, result.getUpperBound(), 0.0001);
                                                            
                                                            // Verify interactions with mock
                                                            verify(dataset).getSeriesCount();
                                                            verify(dataset, times(4)).getXValue(anyInt(), anyInt());
                                                        }

    @Test
                                                    public void testIterateDomainBoundsWithInfiniteValues1() {
                                                        // Create a mock IntervalXYDataset with series containing finite, NaN and infinite values
                                                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                        when(dataset.getItemCount(0)).thenReturn(3);
                                                        
                                                        // First item: finite value
                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                        
                                                        // Second item: NaN value
                                                        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                        when(dataset.getStartXValue(0, 1)).thenReturn(Double.NaN);
                                                        when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
                                                        
                                                        // Third item: infinite value
                                                        when(dataset.getXValue(0, 2)).thenReturn(Double.POSITIVE_INFINITY);
                                                        when(dataset.getStartXValue(0, 2)).thenReturn(Double.POSITIVE_INFINITY);
                                                        when(dataset.getEndXValue(0, 2)).thenReturn(Double.POSITIVE_INFINITY);
                                                        
                                                        // Test with includeInterval=true
                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                        
                                                        // Original behavior should include the infinite value in the range
                                                        // Mutant would exclude it and only use the finite value
                                                        assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                        assertEquals(Double.POSITIVE_INFINITY, result.getUpperBound(), 0.0001);
                                                        
                                                        // Also verify the finite-only case would be different
                                                        Range finiteResult = new Range(0.5, 1.5);
                                                        assertFalse(finiteResult.equals(result)); // This would be true for mutant
                                                    }

    @Test
                                                    public void testIterateDomainBoundsWithNaNValues() {
                                                        // Create a dataset with NaN values
                                                        XYSeries series = new XYSeries("Test Series");
                                                        series.add(1.0, 10.0);
                                                        series.add(Double.NaN, 20.0);  // NaN domain value
                                                        series.add(3.0, 30.0);
                                                        series.add(4.0, Double.NaN);   // NaN range value (shouldn't affect domain bounds)
                                                        
                                                        XYSeriesCollection dataset = new XYSeriesCollection();
                                                        dataset.addSeries(series);
                                                        
                                                        // Calculate domain bounds
                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                        
                                                        // Verify NaN was excluded and bounds are correct
                                                        assertNotNull("Result should not be null", result);
                                                        assertEquals("Lower bound should be 1.0", 1.0, result.getLowerBound(), 0.0001);
                                                        assertEquals("Upper bound should be 3.0", 3.0, result.getUpperBound(), 0.0001);
                                                    }

    @Test
                                                    public void testIterateDomainBoundsWithSpecialFloatingPointValues() {
                                                        // Create a dataset with special floating-point values
                                                        XYSeries series = new XYSeries("Test Series");
                                                        series.add(Double.POSITIVE_INFINITY, 10.0);
                                                        series.add(Double.NEGATIVE_INFINITY, 20.0);
                                                        series.add(Double.NaN, 30.0);
                                                        series.add(1.0, 40.0);
                                                        
                                                        XYSeriesCollection dataset = new XYSeriesCollection();
                                                        dataset.addSeries(series);
                                                        
                                                        // Calculate domain bounds
                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                        
                                                        // Verify only finite values are included
                                                        assertNotNull("Result should not be null", result);
                                                        assertEquals("Lower bound should be 1.0", 1.0, result.getLowerBound(), 0.0001);
                                                        assertEquals("Upper bound should be 1.0", 1.0, result.getUpperBound(), 0.0001);
                                                    }

    @Test
                                                    public void testIterateDomainBoundsWithNaNValues1() {
                                                        // Create a mock IntervalXYDataset with NaN values
                                                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                        when(dataset.getSeriesCount()).thenReturn(1);
                                                        when(dataset.getItemCount(0)).thenReturn(3);
                                                        
                                                        // Setup values: first normal, then NaN, then normal
                                                        when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                        when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                        when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                        
                                                        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                        when(dataset.getStartXValue(0, 1)).thenReturn(Double.NaN);
                                                        when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
                                                        
                                                        when(dataset.getXValue(0, 2)).thenReturn(2.0);
                                                        when(dataset.getStartXValue(0, 2)).thenReturn(1.5);
                                                        when(dataset.getEndXValue(0, 2)).thenReturn(2.5);
                                                
                                                        // Call the method with includeInterval=true
                                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                        
                                                        // Verify the result - should be from 0.5 to 2.5 (NaN values should be ignored)
                                                        assertNotNull("Result should not be null", result);
                                                        assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                        assertEquals(2.5, result.getUpperBound(), 0.0001);
                                                        
                                                        // The mutant version would potentially include NaN in calculations,
                                                        // which could lead to incorrect bounds or null result
                                                    }

    @Test
                                                public void testIterateDomainBoundsWithNaNValues2() {
                                                    // Create a mock XYDataset that contains NaN values
                                                    XYDataset dataset = mock(XYDataset.class);
                                                    when(dataset.getSeriesCount()).thenReturn(1);
                                                    when(dataset.getItemCount(0)).thenReturn(2);
                                                    // First item has regular number, second has NaN
                                                    when(dataset.getXValue(0, 0)).thenReturn(10.0);
                                                    when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                    
                                                    // The original code would return Range(10,10) because Math.max(10,NaN) is 10
                                                    // The mutated code would return Range(NaN,NaN) because Math.max(NaN,10) is NaN
                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                    
                                                    assertNotNull(result);
                                                    assertEquals(10.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateDomainBoundsWithExtremeValues() {
                                                    // Create a mock XYDataset with very large and very small numbers
                                                    XYDataset dataset = mock(XYDataset.class);
                                                    when(dataset.getSeriesCount()).thenReturn(1);
                                                    when(dataset.getItemCount(0)).thenReturn(3);
                                                    when(dataset.getXValue(0, 0)).thenReturn(Double.MIN_VALUE);
                                                    when(dataset.getXValue(0, 1)).thenReturn(Double.MAX_VALUE);
                                                    when(dataset.getXValue(0, 2)).thenReturn(-Double.MAX_VALUE);
                                                    
                                                    // The order shouldn't matter for these cases, but testing anyway
                                                    Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                    
                                                    assertNotNull(result);
                                                    assertEquals(-Double.MAX_VALUE, result.getLowerBound(), 0.0001);
                                                    assertEquals(Double.MAX_VALUE, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                            public void testIterateDomainBoundsWithIntervalXYDatasetForMaximumCalculation() {
                                                // Create a mock IntervalXYDataset
                                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                
                                                // Setup test data - series 0 has 3 items with varying values
                                                when(dataset.getSeriesCount()).thenReturn(1);
                                                when(dataset.getItemCount(0)).thenReturn(3);
                                                
                                                // Setup values where maximum increases with each item
                                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                
                                                when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                when(dataset.getStartXValue(0, 1)).thenReturn(1.5);
                                                when(dataset.getEndXValue(0, 1)).thenReturn(2.5);
                                                
                                                when(dataset.getXValue(0, 2)).thenReturn(3.0);
                                                when(dataset.getStartXValue(0, 2)).thenReturn(2.5);
                                                when(dataset.getEndXValue(0, 2)).thenReturn(3.5);
                                                
                                                // Call the method with includeInterval=true
                                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                
                                                // Verify the maximum was correctly calculated (should be 3.5 from endXValue)
                                                assertNotNull(result);
                                                assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                assertEquals(3.5, result.getUpperBound(), 0.0001);
                                                
                                                // Verify interactions with the mock
                                                verify(dataset, times(3)).getXValue(anyInt(), anyInt());
                                                verify(dataset, times(3)).getStartXValue(anyInt(), anyInt());
                                                verify(dataset, times(3)).getEndXValue(anyInt(), anyInt());
                                            }

    @Test
                                            public void testIterateDomainBoundsShouldReturnCorrectMaximum() {
                                                // Create a test dataset where maximum isn't the last value
                                                XYSeries series = new XYSeries("Test Series");
                                                series.add(1.0, 1.0);  // First value
                                                series.add(5.0, 5.0);  // Actual maximum
                                                series.add(3.0, 3.0);  // Last value (not maximum)
                                                
                                                XYDataset dataset = new XYSeriesCollection(series);
                                                
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                
                                                // Verify the upper bound is the true maximum (5.0), not the last value (3.0)
                                                assertEquals("Upper bound should be 5.0", 
                                                             5.0, 
                                                             result.getUpperBound(), 
                                                             0.0001);
                                            }

    @Test
                                            public void testIterateDomainBoundsDetectsMaximumMutation() {
                                                // Create mock IntervalXYDataset
                                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                
                                                // Setup dataset behavior
                                                when(dataset.getSeriesCount()).thenReturn(1);
                                                when(dataset.getItemCount(0)).thenReturn(3);
                                                
                                                // Setup values where maximum (5.0) is not the last value (3.0)
                                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                when(dataset.getStartXValue(0, 0)).thenReturn(1.0);
                                                when(dataset.getEndXValue(0, 0)).thenReturn(1.0);
                                                
                                                when(dataset.getXValue(0, 1)).thenReturn(5.0);  // This is the actual maximum
                                                when(dataset.getStartXValue(0, 1)).thenReturn(5.0);
                                                when(dataset.getEndXValue(0, 1)).thenReturn(5.0);
                                                
                                                when(dataset.getXValue(0, 2)).thenReturn(3.0);
                                                when(dataset.getStartXValue(0, 2)).thenReturn(3.0);
                                                when(dataset.getEndXValue(0, 2)).thenReturn(3.0);
                                                
                                                // Call method with includeInterval=true
                                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                
                                                // Verify the maximum is correctly found (5.0)
                                                assertNotNull(result);
                                                assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                
                                                // The mutant would return 3.0 here instead of 5.0
                                            }

    @Test
                                        public void testIterateDomainBoundsWithNaNValues3() {
                                            // Create a mock XYDataset that returns NaN in specific order
                                            XYDataset dataset = mock(XYDataset.class);
                                            when(dataset.getItemCount(0)).thenReturn(2);
                                            when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                            when(dataset.getXValue(0, 1)).thenReturn(5.0);
                                            
                                            // The original code would handle NaN differently than the mutant
                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                            
                                            // With NaN first, original would ignore it and return 5.0
                                            // Mutant might behave differently with NaN handling
                                            assertNotNull(result);
                                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                                            assertEquals(5.0, result.getUpperBound(), 0.0001);
                                        }

    @Test
                                        public void testIterateDomainBoundsWithExtremeValues1() {
                                            // Create a mock XYDataset with very large values
                                            XYDataset dataset = mock(XYDataset.class);
                                            when(dataset.getItemCount(0)).thenReturn(3);
                                            when(dataset.getXValue(0, 0)).thenReturn(Double.MAX_VALUE);
                                            when(dataset.getXValue(0, 1)).thenReturn(Double.MAX_VALUE/2);
                                            when(dataset.getXValue(0, 2)).thenReturn(-Double.MAX_VALUE);
                                            
                                            // Test if order affects floating point precision
                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                            
                                            assertNotNull(result);
                                            assertEquals(-Double.MAX_VALUE, result.getLowerBound(), 0.0001);
                                            assertEquals(Double.MAX_VALUE, result.getUpperBound(), 0.0001);
                                        }

    @Test
                                        public void testIterateDomainBoundsWithInitialNegativeInfinity() {
                                            // Create a mock XYDataset where first value is negative infinity
                                            XYDataset dataset = mock(XYDataset.class);
                                            when(dataset.getItemCount(0)).thenReturn(2);
                                            when(dataset.getXValue(0, 0)).thenReturn(Double.NEGATIVE_INFINITY);
                                            when(dataset.getXValue(0, 1)).thenReturn(10.0);
                                            
                                            // Test if order matters when starting with negative infinity
                                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                            
                                            assertNotNull(result);
                                            assertEquals(Double.NEGATIVE_INFINITY, result.getLowerBound(), 0.0001);
                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                        }

    @Test
                                    public void testIterateDomainBounds_HandlesNaNValuesCorrectly() {
                                        // Create a mock XYDataset that will return some NaN values
                                        XYDataset dataset = mock(XYDataset.class);
                                        when(dataset.getSeriesCount()).thenReturn(1);
                                        when(dataset.getItemCount(0)).thenReturn(3);
                                        
                                        // Setup values: first valid, then NaN, then valid
                                        when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                        when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                        when(dataset.getXValue(0, 2)).thenReturn(10.0);
                                        
                                        // Call the method with includeInterval = false
                                        Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                        
                                        // Verify the maximum was calculated correctly despite NaN
                                        assertNotNull("Result should not be null", result);
                                        assertEquals("Minimum should be 5.0", 5.0, result.getLowerBound(), 0.0001);
                                        assertEquals("Maximum should be 10.0", 10.0, result.getUpperBound(), 0.0001);
                                        
                                        // The key assertion that would catch the mutant:
                                        // If the mutant swapped arguments, it might incorrectly handle NaN values
                                        // This test ensures NaN values don't affect the maximum calculation
                                    }

    @Test
                                    public void testIterateDomainBoundsShouldReturnCorrectMaximum1() {
                                        // Create a dataset where maximum x-value isn't the first value
                                        XYSeries series = new XYSeries("Test Series");
                                        series.add(5.0, 1.0);  // Not the maximum
                                        series.add(2.0, 2.0);
                                        series.add(10.0, 3.0); // This should be the maximum
                                        series.add(7.0, 4.0);
                                        
                                        XYDataset dataset = new XYSeriesCollection(series);
                                        
                                        // Call the method under test
                                        Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                        
                                        // Verify the upper bound is correctly calculated
                                        assertEquals("Upper bound should be maximum x-value", 
                                                     10.0, result.getUpperBound(), 0.0001);
                                        
                                        // Additional check for complete range verification
                                        assertEquals("Lower bound should be minimum x-value",
                                                     2.0, result.getLowerBound(), 0.0001);
                                    }

    @Test
                                public void testIterateDomainBounds_DetectMaximumMutation() {
                                    // Create a mock IntervalXYDataset with test data
                                    IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                    
                                    // Setup test data - series 0 has 2 items with increasing values
                                    when(dataset.getSeriesCount()).thenReturn(1);
                                    when(dataset.getItemCount(0)).thenReturn(2);
                                    
                                    // First item values
                                    when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                    when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                    when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                    
                                    // Second item values - lvalue (2.5) should become new maximum
                                    when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                    when(dataset.getStartXValue(0, 1)).thenReturn(2.5); // This should update maximum
                                    when(dataset.getEndXValue(0, 1)).thenReturn(3.0);
                                    
                                    // Mock instanceof check
                                    when(dataset instanceof IntervalXYDataset).thenReturn(true);
                                    
                                    // Call method with includeInterval=true
                                    Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                    
                                    // Verify maximum bound is correct (should be 3.0)
                                    // The mutant would return 1.5 instead
                                    assertEquals(0.5, result.getLowerBound(), 0.0001);
                                    assertEquals(3.0, result.getUpperBound(), 0.0001);
                                }

    @Test
                                public void testIterateDomainBoundsWithNaNValues4() {
                                    // Create a mock XYDataset that returns NaN values
                                    XYDataset dataset = mock(XYDataset.class);
                                    when(dataset.getSeriesCount()).thenReturn(1);
                                    when(dataset.getItemCount(0)).thenReturn(1);
                                    when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                    
                                    // Test the method that contains the mutant
                                    Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                    
                                    // Verify NaN is properly handled (should be excluded from range)
                                    assertNull("Range should be null when all values are NaN", result);
                                }

    @Test
                                public void testIterateDomainBoundsWithMixedValues() {
                                    // Create a mock XYDataset with normal and NaN values
                                    XYDataset dataset = mock(XYDataset.class);
                                    when(dataset.getSeriesCount()).thenReturn(1);
                                    when(dataset.getItemCount(0)).thenReturn(3);
                                    when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                    when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                    when(dataset.getXValue(0, 2)).thenReturn(2.0);
                                    
                                    // Test the method
                                    Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                    
                                    // Verify NaN was excluded from range calculation
                                    assertNotNull("Range should not be null with valid values", result);
                                    assertEquals(1.0, result.getLowerBound(), 0.0001);
                                    assertEquals(2.0, result.getUpperBound(), 0.0001);
                                }

    @Test
                            public void testIterateDomainBounds_WithNaNIntervalValues() {
                                // Create a mock IntervalXYDataset with NaN values
                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                when(dataset.getSeriesCount()).thenReturn(1);
                                when(dataset.getItemCount(0)).thenReturn(2);
                                
                                // First item has valid values
                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                
                                // Second item has NaN in uvalue (endXValue)
                                when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                when(dataset.getStartXValue(0, 1)).thenReturn(1.8);
                                when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
                                
                                // Test with includeInterval=true
                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                
                                // Verify the NaN value was properly excluded
                                // Correct behavior: Range should be from 0.5 to 2.0
                                // Mutant behavior: Would incorrectly include NaN in calculations
                                assertEquals(0.5, result.getLowerBound(), 0.0001);
                                assertEquals(2.0, result.getUpperBound(), 0.0001);
                            }

    @Test
                            public void testIterateDomainBounds_ShouldNotExceedSeriesCount() {
                                // Create a mock XYDataset with 3 series
                                XYDataset dataset = mock(XYDataset.class);
                                when(dataset.getSeriesCount()).thenReturn(3);
                                
                                // Setup mock behavior for each series
                                when(dataset.getItemCount(0)).thenReturn(1);
                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                
                                when(dataset.getItemCount(1)).thenReturn(1);
                                when(dataset.getXValue(1, 0)).thenReturn(2.0);
                                
                                when(dataset.getItemCount(2)).thenReturn(1);
                                when(dataset.getXValue(2, 0)).thenReturn(3.0);
                                
                                // Execute the method
                                DatasetUtilities.iterateDomainBounds(dataset);
                                
                                // Verify the interactions - should only call getItemCount/getXValue for series 0,1,2
                                verify(dataset, times(3)).getItemCount(anyInt());
                                verify(dataset, times(3)).getXValue(anyInt(), anyInt());
                                
                                // The mutant would try to access series 3 (seriesCount + 1)
                                // So we verify that getItemCount(3) was never called
                                verify(dataset, never()).getItemCount(3);
                                verify(dataset, never()).getXValue(3, anyInt());
                            }

    @Test
                            public void testIterateDomainBounds_ShouldNotExceedSeriesCount1() {
                                // Create a mock IntervalXYDataset with 2 series
                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                when(dataset.getSeriesCount()).thenReturn(2);
                                
                                // Setup mock behavior for series 0
                                when(dataset.getItemCount(0)).thenReturn(1);
                                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                                when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                                
                                // Setup mock behavior for series 1
                                when(dataset.getItemCount(1)).thenReturn(1);
                                when(dataset.getXValue(1, 0)).thenReturn(2.0);
                                when(dataset.getStartXValue(1, 0)).thenReturn(1.5);
                                when(dataset.getEndXValue(1, 0)).thenReturn(2.5);
                                
                                // The test will fail if the mutated version tries to access series 2
                                // which would throw IndexOutOfBoundsException
                                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                
                                // Verify the correct range is calculated
                                assertEquals(new Range(0.5, 2.5), result);
                                
                                // Verify the interactions - should only access series 0 and 1
                                verify(dataset, times(2)).getItemCount(anyInt());
                                verify(dataset, never()).getItemCount(2);
                            }

    @Test
                        public void testIterateDomainBoundsWithNaNValues5() {
                            // Create a mock dataset that returns NaN values in different orders
                            XYDataset dataset = mock(XYDataset.class);
                            when(dataset.getSeriesCount()).thenReturn(1);
                            when(dataset.getItemCount(0)).thenReturn(3);
                            
                            // First item is normal, second is NaN, third is normal
                            when(dataset.getXValue(0, 0)).thenReturn(5.0);
                            when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                            when(dataset.getXValue(0, 2)).thenReturn(10.0);
                            
                            // The original would handle NaN differently than the mutant
                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                            
                            // With NaN in the middle, proper handling should still give us 5.0-10.0 range
                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                        }

    @Test
                        public void testIterateDomainBoundsWithAlternatingMaxValues() {
                            // Create a mock dataset with alternating max values
                            XYDataset dataset = mock(XYDataset.class);
                            when(dataset.getSeriesCount()).thenReturn(1);
                            when(dataset.getItemCount(0)).thenReturn(4);
                            
                            // Values that alternate which one is larger
                            when(dataset.getXValue(0, 0)).thenReturn(1.0);
                            when(dataset.getXValue(0, 1)).thenReturn(3.0);
                            when(dataset.getXValue(0, 2)).thenReturn(2.0);
                            when(dataset.getXValue(0, 3)).thenReturn(4.0);
                            
                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                            
                            // Should get the overall max (4.0) regardless of order
                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                            assertEquals(4.0, result.getUpperBound(), 0.0001);
                        }

    @Test
                        public void testIterateDomainBoundsWithExtremeValues2() {
                            // Test with Double.MIN_VALUE and Double.MAX_VALUE
                            XYDataset dataset = mock(XYDataset.class);
                            when(dataset.getSeriesCount()).thenReturn(1);
                            when(dataset.getItemCount(0)).thenReturn(2);
                            
                            when(dataset.getXValue(0, 0)).thenReturn(Double.MIN_VALUE);
                            when(dataset.getXValue(0, 1)).thenReturn(Double.MAX_VALUE);
                            
                            Range result = DatasetUtilities.iterateDomainBounds(dataset);
                            
                            assertEquals(Double.MIN_VALUE, result.getLowerBound(), 0.0001);
                            assertEquals(Double.MAX_VALUE, result.getUpperBound(), 0.0001);
                        }

    @Test
                        public void testIterateDomainBounds_NaNHandlingInMaxCalculation() {
                            // Create a mock IntervalXYDataset
                            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                            
                            // Setup mock behavior
                            when(dataset.getSeriesCount()).thenReturn(1);
                            when(dataset.getItemCount(0)).thenReturn(1);
                            
                            // Setup values where lvalue is NaN and maximum is a valid number
                            when(dataset.getXValue(0, 0)).thenReturn(5.0);
                            when(dataset.getStartXValue(0, 0)).thenReturn(Double.NaN); // lvalue is NaN
                            when(dataset.getEndXValue(0, 0)).thenReturn(7.0);
                            
                            // Call the method with includeInterval=true
                            Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                            
                            // Verify the maximum should be 7.0 (uvalue), not affected by NaN lvalue
                            assertNotNull(result);
                            assertEquals(5.0, result.getLowerBound(), 0.0001);
                            assertEquals(7.0, result.getUpperBound(), 0.0001);
                            
                            // Verify interactions
                            verify(dataset).getSeriesCount();
                            verify(dataset).getItemCount(0);
                            verify(dataset).getXValue(0, 0);
                            verify(dataset).getStartXValue(0, 0);
                            verify(dataset).getEndXValue(0, 0);
                        }

    @Test
                    public void testIterateDomainBoundsShouldReturnCorrectMaximum2() {
                        // Create a dataset with known values where one x-value is clearly the maximum
                        XYSeries series = new XYSeries("Test Series");
                        series.add(1.0, 100.0);  // x, y values
                        series.add(2.0, 200.0);
                        series.add(5.0, 300.0);  // This should be the maximum x-value
                        series.add(3.0, 400.0);
                        
                        XYDataset dataset = new XYSeriesCollection(series);
                        
                        // Call the method under test
                        Range result = DatasetUtilities.iterateDomainBounds(dataset);
                        
                        // Verify the upper bound matches the largest x-value (5.0)
                        assertNotNull("Result should not be null", result);
                        assertEquals("Upper bound should be 5.0", 
                                     5.0, result.getUpperBound(), 0.0001);
                        
                        // Also verify the full range for completeness
                        assertEquals("Lower bound should be 1.0", 
                                     1.0, result.getLowerBound(), 0.0001);
                    }

    @Test
                    public void testIterateDomainBounds_IntervalDatasetWithLvalueGreaterThanCurrentMax() {
                        // Create mock IntervalXYDataset
                        IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                        
                        // Setup test data
                        when(dataset.getSeriesCount()).thenReturn(1);
                        when(dataset.getItemCount(0)).thenReturn(2);
                        
                        // First item - sets initial max
                        when(dataset.getXValue(0, 0)).thenReturn(5.0);
                        when(dataset.getStartXValue(0, 0)).thenReturn(4.0);
                        when(dataset.getEndXValue(0, 0)).thenReturn(6.0);
                        
                        // Second item - lvalue should update max (10.0 > 6.0)
                        when(dataset.getXValue(0, 1)).thenReturn(7.0);
                        when(dataset.getStartXValue(0, 1)).thenReturn(10.0); // This lvalue should update max
                        when(dataset.getEndXValue(0, 1)).thenReturn(8.0);
                        
                        // Execute test with includeInterval=true
                        Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                        
                        // Verify the maximum was properly updated to include lvalue (10.0)
                        assertNotNull(result);
                        assertEquals(4.0, result.getLowerBound(), 0.0001);
                        assertEquals(10.0, result.getUpperBound(), 0.0001); // This assertion will fail with the mutant
                    }

    @Test
                public void testIterateDomainBoundsWithNaNValues6() {
                    // Create a dataset with NaN values
                    XYSeries series = new XYSeries("Test Series");
                    series.add(1.0, 10.0);
                    series.add(2.0, Double.NaN);  // NaN value
                    series.add(3.0, 30.0);
                    series.add(Double.NaN, 40.0);  // NaN domain value
                    series.add(5.0, 50.0);
                    
                    XYSeriesCollection dataset = new XYSeriesCollection();
                    dataset.addSeries(series);
                    
                    // Calculate domain bounds
                    Range result = DatasetUtilities.iterateDomainBounds(dataset);
                    
                    // Verify NaN values are excluded from bounds
                    assertNotNull("Result should not be null", result);
                    assertEquals("Lower bound should be 1.0", 1.0, result.getLowerBound(), 0.0001);
                    assertEquals("Upper bound should be 5.0", 5.0, result.getUpperBound(), 0.0001);
                    
                    // Additional check to ensure NaN at position 4 wasn't included
                    assertFalse("Range should not include NaN", Double.isNaN(result.getLowerBound()));
                    assertFalse("Range should not include NaN", Double.isNaN(result.getUpperBound()));
                }

    @Test
            public void testIterateDomainBounds_WithNaNIntervalValues1() {
                // Create a mock IntervalXYDataset with some NaN values
                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                
                // Setup mock behavior
                when(dataset.getSeriesCount()).thenReturn(1);
                when(dataset.getItemCount(0)).thenReturn(2);
                
                // First item: valid values
                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                when(dataset.getEndXValue(0, 0)).thenReturn(1.5);
                
                // Second item: contains NaN in uvalue
                when(dataset.getXValue(0, 1)).thenReturn(2.0);
                when(dataset.getStartXValue(0, 1)).thenReturn(1.5);
                when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
                
                // Call the method with includeInterval=true
                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                
                // Verify the result
                assertNotNull("Result should not be null", result);
                assertEquals("Minimum should be 0.5", 0.5, result.getLowerBound(), 0.0001);
                assertEquals("Maximum should be 2.0", 2.0, result.getUpperBound(), 0.0001);
                
                // Verify interactions with the mock
                verify(dataset, times(2)).getXValue(anyInt(), anyInt());
                verify(dataset, times(2)).getStartXValue(anyInt(), anyInt());
                verify(dataset, times(2)).getEndXValue(anyInt(), anyInt());
            }

    @Test
            public void testIterateDomainBoundsWithNaNValues7() {
                // Create a dataset with NaN values in different orders
                XYSeries series1 = new XYSeries("Series1");
                series1.add(1.0, Double.NaN);
                series1.add(2.0, 5.0);
                series1.add(Double.NaN, 3.0);
                
                XYSeries series2 = new XYSeries("Series2");
                series2.add(Double.NaN, 1.0);
                series2.add(3.0, Double.NaN);
                series2.add(4.0, 2.0);
                
                XYSeriesCollection dataset = new XYSeriesCollection();
                dataset.addSeries(series1);
                dataset.addSeries(series2);
                
                Range result = DatasetUtilities.iterateDomainBounds(dataset);
                assertNotNull(result);
                // Should properly handle NaN values regardless of order
                assertEquals(1.0, result.getLowerBound(), 0.0001);
                assertEquals(4.0, result.getUpperBound(), 0.0001);
            }

    @Test
            public void testIterateDomainBoundsWithExtremeValues3() {
                // Create dataset with very large numbers in different orders
                XYSeries series = new XYSeries("Series");
                series.add(Double.MAX_VALUE, 1.0);
                series.add(1.0E308, 2.0);
                series.add(-Double.MAX_VALUE, 3.0);
                series.add(-1.0E308, 4.0);
                
                // Add values in reverse order to test order sensitivity
                series.add(1.0, 5.0);
                series.add(2.0, 6.0);
                
                XYSeriesCollection dataset = new XYSeriesCollection();
                dataset.addSeries(series);
                
                Range result = DatasetUtilities.iterateDomainBounds(dataset);
                assertNotNull(result);
                // Should get correct bounds regardless of value order
                assertEquals(-Double.MAX_VALUE, result.getLowerBound(), 0.0001);
                assertEquals(Double.MAX_VALUE, result.getUpperBound(), 0.0001);
            }

    @Test
            public void testIterateDomainBoundsWithMixedValues1() {
                // Create dataset with mixed positive/negative values
                XYSeries series1 = new XYSeries("Series1");
                series1.add(-5.0, 1.0);
                series1.add(10.0, 2.0);
                
                XYSeries series2 = new XYSeries("Series2");
                series2.add(-10.0, 3.0);
                series2.add(5.0, 4.0);
                
                XYSeriesCollection dataset = new XYSeriesCollection();
                dataset.addSeries(series1);
                dataset.addSeries(series2);
                
                Range result = DatasetUtilities.iterateDomainBounds(dataset);
                assertNotNull(result);
                // Should properly calculate min/max regardless of order
                assertEquals(-10.0, result.getLowerBound(), 0.0001);
                assertEquals(10.0, result.getUpperBound(), 0.0001);
            }

    @Test
            public void testIterateDomainBoundsWithIntervalXYDatasetDetectsMutant() {
                // Create a mock IntervalXYDataset
                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                
                // Setup test data where uvalue will affect the maximum
                when(dataset.getSeriesCount()).thenReturn(1);
                when(dataset.getItemCount(0)).thenReturn(2);
                
                // First item values
                when(dataset.getXValue(0, 0)).thenReturn(1.0);
                when(dataset.getStartXValue(0, 0)).thenReturn(0.5);
                when(dataset.getEndXValue(0, 0)).thenReturn(1.5); // uvalue that should update maximum
                
                // Second item values - important for testing the mutation
                when(dataset.getXValue(0, 1)).thenReturn(2.0);
                when(dataset.getStartXValue(0, 1)).thenReturn(1.5);
                when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN); // NaN should be skipped
                
                // Call the method with includeInterval=true
                Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                
                // Verify the result
                assertNotNull(result);
                assertEquals(0.5, result.getLowerBound(), 0.0001);
                assertEquals(2.0, result.getUpperBound(), 0.0001); // This would fail if the mutant survives
                
                // Verify interactions
                verify(dataset, times(2)).getXValue(anyInt(), anyInt());
                verify(dataset, times(2)).getStartXValue(anyInt(), anyInt());
                verify(dataset, times(2)).getEndXValue(anyInt(), anyInt());
            }

    @Test
        public void testIterateDomainBounds_WithNaNValues5() {
            // Create a dataset with normal numbers and NaN values
            XYSeries series = new XYSeries("Test");
            series.add(1.0, 1.0);
            series.add(2.0, Double.NaN); // NaN y-value shouldn't affect domain
            series.add(Double.NaN, 3.0); // NaN x-value that should be excluded
            series.add(-1.0, 4.0);
            series.add(Double.POSITIVE_INFINITY, 5.0); // Test infinity
            
            // Add a positive NaN case that would trigger the mutant
            // In Java, Double.NaN comparisons always return false, but we'll include
            // it to be thorough
            series.add(Double.NaN, 6.0);
            
            XYSeriesCollection dataset = new XYSeriesCollection();
            dataset.addSeries(series);
            
            // Calculate bounds
            Range result = DatasetUtilities.iterateDomainBounds(dataset);
            
            // Verify NaN values are excluded
            assertNotNull("Result should not be null", result);
            assertEquals("Lower bound should be -1.0", 
                -1.0, result.getLowerBound(), 0.0001);
            assertEquals("Upper bound should be 2.0", 
                2.0, result.getUpperBound(), 0.0001);
                
            // Verify infinity is handled properly
            assertFalse("Range should not include NaN", 
                Double.isNaN(result.getLowerBound()));
            assertFalse("Range should not include NaN", 
                Double.isNaN(result.getUpperBound()));
        }

    @Test
        public void testIterateDomainBounds_AllNaNValues2() {
            // Create dataset with only NaN values
            XYSeries series = new XYSeries("Test");
            series.add(Double.NaN, 1.0);
            series.add(Double.NaN, 2.0);
            
            XYSeriesCollection dataset = new XYSeriesCollection();
            dataset.addSeries(series);
            
            // Should return null when no valid values exist
            Range result = DatasetUtilities.iterateDomainBounds(dataset);
            assertNull("Should return null for all NaN dataset", result);
        }

    @Test
        public void testIterateDomainBoundsWithNegativeValues6() {
            // Create a mock IntervalXYDataset with negative values
            IntervalXYDataset dataset = mock(IntervalXYDataset.class);
            when(dataset.getSeriesCount()).thenReturn(1);
            when(dataset.getItemCount(0)).thenReturn(2);
            
            // First item: valid negative value
            when(dataset.getXValue(0, 0)).thenReturn(-5.0);
            when(dataset.getStartXValue(0, 0)).thenReturn(-5.0);
            when(dataset.getEndXValue(0, 0)).thenReturn(-5.0);
            
            // Second item: NaN value (should be skipped)
            when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
            when(dataset.getStartXValue(0, 1)).thenReturn(Double.NaN);
            when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
            
            // Test with includeInterval=true
            Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
            
            // Verify the range includes the negative value
            assertNotNull("Result should not be null", result);
            assertEquals("Minimum should be -5.0", -5.0, result.getLowerBound(), 0.0001);
            assertEquals("Maximum should be -5.0", -5.0, result.getUpperBound(), 0.0001);
            
            // The mutant would skip the negative value because of the || lvalue > 0 condition,
            // resulting in null return value
        }

    @Test
        public void testIterateDomainBoundsWithNegativeValuesNonInterval() {
            // Create a mock XYDataset with negative values
            XYDataset dataset = mock(XYDataset.class);
            when(dataset.getSeriesCount()).thenReturn(1);
            when(dataset.getItemCount(0)).thenReturn(2);
            
            // First item: valid negative value
            when(dataset.getXValue(0, 0)).thenReturn(-3.0);
            
            // Second item: NaN value (should be skipped)
            when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
            
            // Test with includeInterval=false
            Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
            
            // Verify the range includes the negative value
            assertNotNull("Result should not be null", result);
            assertEquals("Minimum should be -3.0", -3.0, result.getLowerBound(), 0.0001);
            assertEquals("Maximum should be -3.0", -3.0, result.getUpperBound(), 0.0001);
            
            // The mutant would skip the negative value in the non-interval case too
        }

}
