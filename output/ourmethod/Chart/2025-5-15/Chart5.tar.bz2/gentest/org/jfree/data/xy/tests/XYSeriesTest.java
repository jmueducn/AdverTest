package gentest.org.jfree.data.xy.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.xy.*;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class XYSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                 public void testAddOrUpdate_CloneNotSupported() throws CloneNotSupportedException {
                                                                     XYDataItem mockItem = mock(XYDataItem.class);
                                                                     when(mockItem.clone()).thenThrow(new CloneNotSupportedException());
                                                                     
                                                                     // Create a series with our mock item
                                                                     XYSeries customSeries = new XYSeries("Custom", false, false);
                                                                     customSeries.add(mockItem);
                                                                     
                                                                     thrown.expect(SeriesException.class);
                                                                     thrown.expectMessage("Couldn't clone XYDataItem!");
                                                                     customSeries.addOrUpdate(1, 10); // 1 should match the x value of mockItem
                                                                 }

 @Test
                                                         public void testAddOrUpdate_AddNewItemToEmptySeries() {
                                                             XYSeries seriesWithAutoSort = new XYSeries("Test Series", true);
                                                             XYDataItem result = seriesWithAutoSort.addOrUpdate(1.0, 2.0);
                                                             assertEquals(1, seriesWithAutoSort.getItemCount());
                                                             assertEquals(1.0, seriesWithAutoSort.getX(0).doubleValue(), 0.0001);
                                                             assertEquals(2.0, seriesWithAutoSort.getY(0).doubleValue(), 0.0001);
                                                             assertEquals(1.0, result.getX().doubleValue(), 0.0001);
                                                             assertEquals(2.0, result.getY().doubleValue(), 0.0001);
                                                         }

 @Test
                                                         public void testAddOrUpdate_AddNewItemToNonEmptySeriesWithAutoSort() {
                                                             XYSeries seriesWithAutoSort = new XYSeries("Test Series", true); // autoSort=true
                                                             seriesWithAutoSort.add(3.0, 4.0);
                                                             seriesWithAutoSort.add(1.0, 2.0);
                                                             
                                                             XYDataItem result = seriesWithAutoSort.addOrUpdate(2.0, 5.0);
                                                             assertEquals(3, seriesWithAutoSort.getItemCount());
                                                             assertEquals(1.0, seriesWithAutoSort.getX(0).doubleValue(), 0.0001);
                                                             assertEquals(2.0, seriesWithAutoSort.getX(1).doubleValue(), 0.0001);
                                                             assertEquals(3.0, seriesWithAutoSort.getX(2).doubleValue(), 0.0001);
                                                             assertEquals(5.0, result.getY().doubleValue(), 0.0001);
                                                         }

 @Test
                                                         public void testAddOrUpdate_AddNewItemToNonEmptySeriesWithoutAutoSort() {
                                                             XYSeries seriesWithoutAutoSort = new XYSeries("Test Series", false);
                                                             seriesWithoutAutoSort.add(1.0, 2.0);
                                                             seriesWithoutAutoSort.add(3.0, 4.0);
                                                             
                                                             XYDataItem result = seriesWithoutAutoSort.addOrUpdate(2.0, 5.0);
                                                             assertEquals(3, seriesWithoutAutoSort.getItemCount());
                                                             assertEquals(1.0, seriesWithoutAutoSort.getX(0).doubleValue(), 0.0001);
                                                             assertEquals(3.0, seriesWithoutAutoSort.getX(1).doubleValue(), 0.0001);
                                                             assertEquals(2.0, seriesWithoutAutoSort.getX(2).doubleValue(), 0.0001);
                                                             assertEquals(5.0, result.getY().doubleValue(), 0.0001);
                                                         }

 @Test
                                                         public void testAddOrUpdate_UpdateExistingItem() {
                                                             XYSeries series = new XYSeries("Test Series", true);  // autoSort=true
                                                             series.add(1.0, 2.0);
                                                             series.add(3.0, 4.0);
                                                             
                                                             XYDataItem result = series.addOrUpdate(1.0, 5.0);
                                                             assertEquals(2, series.getItemCount());
                                                             assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
                                                             assertEquals(5.0, series.getY(0).doubleValue(), 0.0001);
                                                             assertEquals(5.0, result.getY().doubleValue(), 0.0001);
                                                         }

 @Test
                                                         public void testAddOrUpdate_AddDuplicateXWhenAllowed() {
                                                             XYSeries seriesWithAutoSort = new XYSeries("Test Series", true, true);
                                                             seriesWithAutoSort.add(1.0, 2.0);
                                                             XYDataItem result = seriesWithAutoSort.addOrUpdate(1.0, 3.0);
                                                             assertEquals(2, seriesWithAutoSort.getItemCount());
                                                             assertEquals(1.0, seriesWithAutoSort.getX(0).doubleValue(), 0.0001);
                                                             assertEquals(1.0, seriesWithAutoSort.getX(1).doubleValue(), 0.0001);
                                                             assertEquals(3.0, result.getY().doubleValue(), 0.0001);
                                                         }

 @Test
                                                         public void testAddOrUpdate_AddDuplicateXWhenNotAllowed() {
                                                             thrown.expect(IllegalArgumentException.class);
                                                             thrown.expectMessage("X-value already exists.");
                                                             
                                                             XYSeries seriesNoDuplicates = new XYSeries("Test Series", false, false);
                                                             seriesNoDuplicates.add(1.0, 2.0);
                                                             seriesNoDuplicates.addOrUpdate(1.0, 3.0);
                                                         }

 @Test
                                                         public void testAddOrUpdate_WithNullYValue() {
                                                             XYSeries seriesWithAutoSort = new XYSeries("Test Series", true);
                                                             XYDataItem result = seriesWithAutoSort.addOrUpdate(1.0, null);
                                                             assertEquals(1, seriesWithAutoSort.getItemCount());
                                                             assertEquals(1.0, seriesWithAutoSort.getX(0).doubleValue(), 0.0001);
                                                             assertNull(seriesWithAutoSort.getY(0));
                                                             assertNull(result.getY());
                                                         }

 @Test
                                                         public void testAddOrUpdate_AfterReachingMaximumItemCount() {
                                                             XYSeries seriesWithAutoSort = new XYSeries("Test Series", true); // auto-sort enabled
                                                             seriesWithAutoSort.setMaximumItemCount(2);
                                                             seriesWithAutoSort.add(1.0, 1.0);
                                                             seriesWithAutoSort.add(2.0, 2.0);
                                                             
                                                             XYDataItem result = seriesWithAutoSort.addOrUpdate(3.0, 3.0);
                                                             assertEquals(2, seriesWithAutoSort.getItemCount());
                                                             assertEquals(2.0, seriesWithAutoSort.getX(0).doubleValue(), 0.0001);
                                                             assertEquals(3.0, seriesWithAutoSort.getX(1).doubleValue(), 0.0001);
                                                             assertEquals(3.0, result.getY().doubleValue(), 0.0001);
                                                         }

 @Test
                                                         public void testAddOrUpdate_WithExtremeValues() {
                                                             XYSeries seriesWithAutoSort = new XYSeries("Test Series", true);
                                                             XYDataItem result = seriesWithAutoSort.addOrUpdate(Double.MAX_VALUE, Double.MIN_VALUE);
                                                             assertEquals(1, seriesWithAutoSort.getItemCount());
                                                             assertEquals(Double.MAX_VALUE, seriesWithAutoSort.getX(0).doubleValue(), 0.0001);
                                                             assertEquals(Double.MIN_VALUE, seriesWithAutoSort.getY(0).doubleValue(), 0.0001);
                                                             assertEquals(Double.MAX_VALUE, result.getX().doubleValue(), 0.0001);
                                                             assertEquals(Double.MIN_VALUE, result.getY().doubleValue(), 0.0001);
                                                         }

 @Test
                                                         public void testAddOrUpdate_NullXValue() {
                                                             org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                             thrown.expect(IllegalArgumentException.class);
                                                             thrown.expectMessage("Null 'x' argument.");
                                                             XYSeries series = new XYSeries("Test Series");
                                                             series.addOrUpdate(null, 5);
                                                         }

 @Test
                                                         public void testAddOrUpdate_DuplicateAllowed() {
                                                             // Create a series that allows duplicate X values
                                                             XYSeries duplicateAllowedSeries = new XYSeries("Test Series", true, true);
                                                             
                                                             // When duplicates are allowed, should always add new item and return null
                                                             assertNull(duplicateAllowedSeries.addOrUpdate(1, 10));
                                                             assertEquals(1, duplicateAllowedSeries.getItemCount());
                                                             assertEquals(10, duplicateAllowedSeries.getY(0).doubleValue(), 0.0001);
                                                             
                                                             // Adding another with same x value should create new item
                                                             assertNull(duplicateAllowedSeries.addOrUpdate(1, 20));
                                                             assertEquals(2, duplicateAllowedSeries.getItemCount());
                                                             assertEquals(20, duplicateAllowedSeries.getY(1).doubleValue(), 0.0001);
                                                         }

 @Test
                                                         public void testAddOrUpdate_UpdateExisting() {
                                                             XYSeries series = new XYSeries("Test Series", false, false);
                                                             series.add(1.0, 10.0);
                                                             XYDataItem overwritten = series.addOrUpdate(1.0, 20.0);
                                                             
                                                             assertNotNull(overwritten);
                                                             assertEquals(10.0, overwritten.getY().doubleValue());
                                                             assertEquals(1, series.getItemCount());
                                                             assertEquals(20.0, series.getY(0).doubleValue());
                                                         }

 @Test
                                                         public void testAddOrUpdate_AddNewToNonAutoSort() {
                                                             XYSeries series = new XYSeries("Test Series", false); // non-auto-sort
                                                             series.add(1, 10);
                                                             assertNull(series.addOrUpdate(2, 20));
                                                             
                                                             assertEquals(2, series.getItemCount());
                                                             assertEquals(20, series.getY(1).doubleValue(), 0.0001); // Should be appended
                                                         }

 @Test
                                                         public void testAddOrUpdate_AddNewToAutoSort() {
                                                             XYSeries autoSortSeries = new XYSeries("Test Series", true); // autoSort enabled
                                                             autoSortSeries.add(2.0, 20.0);
                                                             assertNull(autoSortSeries.addOrUpdate(1.0, 10.0));
                                                             
                                                             assertEquals(2, autoSortSeries.getItemCount());
                                                             assertEquals(10.0, autoSortSeries.getY(0).doubleValue(), 0.0001); // Should be inserted at beginning
                                                         }

 @Test
                                                         public void testAddOrUpdate_MaximumItemCount() {
                                                             XYSeries series = new XYSeries("Test Series");
                                                             series.setMaximumItemCount(2);
                                                             series.add(1.0, 10.0);
                                                             series.add(2.0, 20.0);
                                                             
                                                             // Adding third item should remove first one
                                                             assertNull(series.addOrUpdate(3.0, 30.0));
                                                             assertEquals(2, series.getItemCount());
                                                             assertEquals(20.0, series.getY(0).doubleValue(), 0.0001);
                                                             assertEquals(30.0, series.getY(1).doubleValue(), 0.0001);
                                                             
                                                             // Updating existing shouldn't affect count
                                                             series.addOrUpdate(2.0, 25.0);
                                                             assertEquals(2, series.getItemCount());
                                                         }

 @Test
                                                     public void testAddOrUpdate_WithNullXValue() {
                                                         XYSeries seriesWithAutoSort = new XYSeries("Test Series", true);
                                                         try {
                                                             seriesWithAutoSort.addOrUpdate(null, 2.0);
                                                             fail("Expected IllegalArgumentException for null x value");
                                                         } catch (IllegalArgumentException e) {
                                                             assertEquals("Null 'x' argument.", e.getMessage());
                                                         }
                                                     }

 @Test
                                                 public void testAddOrUpdate_FireSeriesChanged() {
                                                     XYSeries series = new XYSeries("Test Series");
                                                     XYSeriesCollection collection = new XYSeriesCollection(series);
                                                     
                                                     final boolean[] changed = new boolean[1];
                                                     collection.addChangeListener(new org.jfree.data.general.DatasetChangeListener() {
                                                         @Override
                                                         public void datasetChanged(org.jfree.data.general.DatasetChangeEvent event) {
                                                             changed[0] = true;
                                                         }
                                                     });
                                                     
                                                     series.addOrUpdate(1, 10);
                                                     assertTrue(changed[0]);
                                                 }

 @Test
                                                 public void testAddOrUpdateWithNullXShouldThrowException() {
                                                     // Setup
                                                     XYSeries series = new XYSeries("Test Series");
                                                     Double nullX = null;
                                                     Double y = 5.0;
                                                     
                                                     // Expect exception
                                                     thrown.expect(IllegalArgumentException.class);
                                                     thrown.expectMessage("Null 'x' argument.");
                                                     
                                                     // Test
                                                     series.addOrUpdate(nullX, y);
                                                     
                                                     // If we reach here, the test fails (mutant survived)
                                                     // because the exception wasn't thrown
                                                 }

 @Test
                                                 public void testAddOrUpdateWithNullXShouldNotReturnNull() {
                                                     // Setup
                                                     XYSeries series = new XYSeries("Test Series");
                                                     Double nullX = null;
                                                     Double y = 5.0;
                                                     
                                                     try {
                                                         XYDataItem result = series.addOrUpdate(nullX, y);
                                                         // If we get here, verify result is not null (though original should throw exception first)
                                                         assertNotNull("Method should throw exception before returning", result);
                                                     } catch (IllegalArgumentException e) {
                                                         // This is expected behavior
                                                         assertEquals("Null 'x' argument.", e.getMessage());
                                                     }
                                                 }

 @Test
                                                 public void testAddOrUpdateWithNullXShouldThrowException1() {
                                                     // Setup
                                                     XYSeries series = new XYSeries("Test Series");
                                                     
                                                     // Expect exception
                                                     thrown.expect(IllegalArgumentException.class);
                                                     thrown.expectMessage("Null 'x' argument.");
                                                     
                                                     // Test
                                                     series.addOrUpdate(null, 10);
                                                     
                                                     // If we get here, the test fails (mutant survived)
                                                     fail("Expected IllegalArgumentException was not thrown");
                                                 }

 @Test
                                            public void testAddOrUpdateWithDuplicateXValuesWhenNotAllowed() {
                                                // Create series with duplicate x values not allowed
                                                XYSeries series = new XYSeries("Test Series", true, false);
                                                
                                                // Add initial point
                                                series.add(1.0, 10.0);
                                                assertEquals(1, series.getItemCount());
                                                assertEquals(10.0, series.getY(0));
                                                
                                                // Try to add point with same x value - should update existing point
                                                series.addOrUpdate(1.0, 20.0);
                                                
                                                // Verify behavior
                                                if (series.getAllowDuplicateXValues()) {
                                                    // Mutant behavior - added new point
                                                    assertEquals(2, series.getItemCount());
                                                    assertEquals(10.0, series.getY(0));
                                                    assertEquals(20.0, series.getY(1));
                                                } else {
                                                    // Original behavior - updated existing point
                                                    assertEquals(1, series.getItemCount());
                                                    assertEquals(20.0, series.getY(0));
                                                }
                                                
                                                // Explicit assertion that should catch the mutant
                                                assertEquals("Should only have one item when duplicates not allowed", 
                                                    1, series.getItemCount());
                                            }

 @Test
                                            public void testAddOrUpdateDetectsAllowDuplicateMutation() {
                                                // Create series with duplicate x values NOT allowed
                                                XYSeries series = new XYSeries("Test Series", true, false);
                                                
                                                // Add initial data point
                                                Number x = 1.0;
                                                Number y1 = 10.0;
                                                series.add(x, y1);
                                                
                                                // Add/update with same x but different y
                                                Number y2 = 20.0;
                                                XYDataItem result = series.addOrUpdate(x, y2);
                                                
                                                // Verify behavior - should update existing point, not add new one
                                                assertEquals(1, series.getItemCount());  // Item count should stay same
                                                assertEquals(y2, series.getY(0));      // Y value should be updated
                                                assertNotNull(result);                  // Should return overwritten item
                                                assertEquals(y1, result.getY());       // Overwritten item should have old y value
                                                
                                                // If mutant exists (always allows duplicates), we would see:
                                                // - Item count would be 2
                                                // - Original y value would remain unchanged
                                                // - Return value would be null
                                            }

 @Test
                                           public void testAddOrUpdate_NewPoint_ShouldReturnNull() {
                                               // Create series that doesn't allow duplicate X values
                                               XYSeries series = new XYSeries("Test Series", true, false);
                                               
                                               // Add a new point (1.0, 2.0) that doesn't exist in the series
                                               XYDataItem result = series.addOrUpdate(1.0, 2.0);
                                               
                                               // Verify null is returned (original behavior)
                                               assertNull("Adding new point should return null", result);
                                               
                                               // Verify the point was actually added
                                               assertEquals(1, series.getItemCount());
                                               assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
                                               assertEquals(2.0, series.getY(0).doubleValue(), 0.0001);
                                           }

 @Test
                                           public void testAddOrUpdate_NewItem_ShouldReturnNull() {
                                               // Setup - create series with no duplicates allowed
                                               XYSeries series = new XYSeries("Test Series", true, false);
                                               
                                               // Test adding a new item (x=1 doesn't exist in series)
                                               Number x = 1;
                                               Number y = 10;
                                               XYDataItem result = series.addOrUpdate(x, y);
                                               
                                               // Verify - should return null for new items
                                               assertNull("Adding new item should return null", result);
                                               
                                               // Additional verification that item was added correctly
                                               assertEquals(1, series.getItemCount());
                                               assertEquals(x, series.getX(0));
                                               assertEquals(y, series.getY(0));
                                           }

 @Test
                                          public void testAddOrUpdateDetectsIndexOfXMutation() {
                                              // Create series with some initial data
                                              XYSeries series = new XYSeries("Test");
                                              series.add(1.0, 100.0);  // x=1.0, y=100.0
                                              series.add(2.0, 200.0);  // x=2.0, y=200.0
                                              
                                              // Try to update existing x=1.0 with new y=300.0
                                              // Note: 300.0 doesn't exist as any y value in the series
                                              series.addOrUpdate(1.0, 300.0);
                                              
                                              // Verify:
                                              // Original behavior would update x=1.0 to y=300.0
                                              // Mutant behavior would not update anything (since no y=300.0 exists)
                                              assertEquals(2, series.getItemCount());  // Count shouldn't change
                                              assertEquals(300.0, series.getY(0).doubleValue(), 0.0001);  // First item's y should be updated
                                              assertEquals(200.0, series.getY(1).doubleValue(), 0.0001);  // Second item unchanged
                                              
                                              // Additional check to ensure we're updating by x not y
                                              assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);  // x value should remain
                                          }

 @Test
                                          public void testAddOrUpdateDetectsIndexOfXMutation1() {
                                              // Setup - create series without duplicate x values allowed
                                              XYSeries series = new XYSeries("Test Series", true, false);
                                              
                                              // Add initial data points with unique x and y values
                                              series.add(1.0, 100.0);  // x=1.0, y=100.0
                                              series.add(2.0, 200.0);  // x=2.0, y=200.0
                                              series.add(3.0, 300.0);  // x=3.0, y=300.0
                                              
                                              // Test case that will detect the mutant
                                              // Try to update x=2.0 (existing) with y=250.0
                                              // With original code, this should update the existing item
                                              // With mutant (indexOf(y)), it might not find the existing x=2.0 item
                                              XYDataItem result = series.addOrUpdate(2.0, 250.0);
                                              
                                              // Verify the update occurred correctly
                                              assertNotNull("Should return overwritten item", result);
                                              assertEquals(200.0, result.getY().doubleValue(), 0.0001);
                                              
                                              // Verify the series state
                                              assertEquals(3, series.getItemCount());
                                              assertEquals(250.0, series.getY(1).doubleValue(), 0.0001);  // y value updated at x=2.0
                                              
                                              // Additional check - verify no duplicate was added
                                              assertEquals(2.0, series.getX(1).doubleValue(), 0.0001);
                                              assertEquals(3, series.getItemCount());
                                              
                                              // Edge case - try with y value that matches another item's y
                                              // Original: should update x=3.0
                                              // Mutant: might update wrong item (x=1.0 which has y=100.0)
                                              XYDataItem edgeResult = series.addOrUpdate(3.0, 100.0);
                                              assertNotNull("Should return overwritten item", edgeResult);
                                              assertEquals(300.0, edgeResult.getY().doubleValue(), 0.0001);
                                              assertEquals(100.0, series.getY(2).doubleValue(), 0.0001);  // x=3.0 should be updated
                                          }

 @Test
                                         public void testAddOrUpdateShouldUpdateExistingPoint() {
                                             // Setup
                                             XYSeries series = new XYSeries("Test Series");
                                             double x = 1.0;
                                             double y1 = 10.0;
                                             double y2 = 20.0;
                                             
                                             // Add initial point
                                             series.add(x, y1);
                                             
                                             // Test addOrUpdate with same x
                                             series.addOrUpdate(x, y2);
                                             
                                             // Verify
                                             assertEquals(1, series.getItemCount());  // Should still have 1 item (updated)
                                             assertEquals(y2, series.getY(0).doubleValue(), 0.0001);  // Y should be updated
                                             assertEquals(x, series.getX(0).doubleValue(), 0.0001);  // X should remain same
                                         }

 @Test
                                         public void testAddOrUpdateShouldNotAddDuplicateWhenUpdating() {
                                             // Setup with duplicate prevention
                                             XYSeries series = new XYSeries("Test Series", true, false);
                                             double x = 1.0;
                                             double y1 = 10.0;
                                             double y2 = 20.0;
                                             
                                             // Add initial point
                                             series.add(x, y1);
                                             
                                             // Test addOrUpdate with same x (should update, not add)
                                             series.addOrUpdate(x, y2);
                                             
                                             // Verify only one item exists
                                             assertEquals(1, series.getItemCount());
                                         }

 @Test(expected = IllegalArgumentException.class)
                                         public void testAddOrUpdateShouldThrowWhenDuplicateNotAllowed() {
                                             // Setup with strict duplicate prevention
                                             XYSeries series = new XYSeries("Test Series", true, false);
                                             double x = 1.0;
                                             double y1 = 10.0;
                                             double y2 = 20.0;
                                             
                                             // Add initial point
                                             series.add(x, y1);
                                             
                                             // Force mutant behavior (would try to add duplicate)
                                             // This should throw if mutation is present
                                             series.addOrUpdate(x, y2);
                                         }

 @Test
                                         public void testAddOrUpdateShouldUpdateExistingItem() {
                                             // Setup
                                             XYSeries series = new XYSeries("Test Series", true, false); // autoSort=true, no duplicates
                                             Number x = 10;
                                             Number y1 = 100;
                                             Number y2 = 200;
                                             
                                             // Add initial item
                                             series.add(x, y1);
                                             
                                             // Test addOrUpdate with same x
                                             XYDataItem result = series.addOrUpdate(x, y2);
                                             
                                             // Verify
                                             // Should return the original item that was overwritten
                                             assertNotNull("Should return overwritten item", result);
                                             assertEquals("Returned item should have original x", x, result.getX());
                                             assertEquals("Returned item should have original y", y1, result.getY());
                                             
                                             // Should have updated the existing item, not added new one
                                             assertEquals("Series should still have 1 item", 1, series.getItemCount());
                                             assertEquals("Item should have new y value", y2, series.getY(0));
                                             
                                             // Verify the x value wasn't duplicated
                                             assertEquals("Index of x should still be 0", 0, series.indexOf(x));
                                         }

 @Test
                                        public void testAddOrUpdateWithIndexZeroShouldUpdateExistingItem() {
                                            // Create series with autoSort=true and allowDuplicateXValues=false
                                            XYSeries series = new XYSeries("Test Series");
                                            
                                            // Add initial point that will be at index 0
                                            series.add(0.0, 1.0);
                                            
                                            // Verify initial state
                                            assertEquals(1, series.getItemCount());
                                            assertEquals(1.0, series.getY(0).doubleValue(), 0.0001);
                                            
                                            // Call addOrUpdate with same x value (should update)
                                            series.addOrUpdate(0.0, 2.0);
                                            
                                            // Verify the point was updated rather than added
                                            assertEquals(1, series.getItemCount());  // Count should remain 1
                                            assertEquals(2.0, series.getY(0).doubleValue(), 0.0001);  // Y value should be updated
                                            
                                            // The mutant would fail this test because:
                                            // - With condition changed to index > 0, it wouldn't update index 0
                                            // - Depending on allowDuplicateXValues, it would either:
                                            //   * Add a duplicate point (if true), making itemCount=2
                                            //   * Throw exception (if false)
                                            // Our assertions would catch either case
                                        }

 @Test
                                        public void testAddOrUpdateShouldUpdateWhenIndexIsZero() {
                                            // Setup - create series with one item (will be at index 0)
                                            XYSeries series = new XYSeries("Test", true, false); // autoSort=true, no duplicates
                                            Number x = 1.0;
                                            Number y1 = 10.0;
                                            Number y2 = 20.0;
                                            
                                            // Add initial item
                                            series.add(x, y1);
                                            
                                            // Test - try to update the item (should be at index 0)
                                            XYDataItem result = series.addOrUpdate(x, y2);
                                            
                                            // Verify
                                            assertNotNull("Should return overwritten item", result);
                                            assertEquals("Original Y value should be returned", y1, result.getY());
                                            assertEquals("Series should still have 1 item", 1, series.getItemCount());
                                            assertEquals("Y value should be updated", y2, series.getY(0));
                                        }

 @Test
                                       public void testAddOrUpdateDetectsIndexConditionMutant() {
                                           // Create series with autoSort=false to control item positions
                                           XYSeries series = new XYSeries("Test", false, true);
                                           
                                           // Add initial items
                                           series.add(1.0, 10.0);  // index 0
                                           series.add(2.0, 20.0);  // index 1
                                           series.add(3.0, 30.0);  // index 2
                                           
                                           // Test 1: Update existing item at index 1 (x=2.0)
                                           series.addOrUpdate(2.0, 25.0);
                                           
                                           // Verify update happened (original behavior)
                                           assertEquals(3, series.getItemCount());  // Should still have 3 items
                                           assertEquals(25.0, series.getY(1));     // Y value at index 1 should be updated
                                           
                                           // Test 2: Update existing item at index 0 (x=1.0)
                                           // This is where mutant would behave differently
                                           series.addOrUpdate(1.0, 15.0);
                                           
                                           // Verify update happened (original behavior)
                                           assertEquals(3, series.getItemCount());  // Should still have 3 items
                                           assertEquals(15.0, series.getY(0));     // Y value at index 0 should be updated
                                           
                                           // Test 3: Add new item (x=4.0)
                                           series.addOrUpdate(4.0, 40.0);
                                           assertEquals(4, series.getItemCount());  // Should now have 4 items
                                       }

 @Test
                                       public void testAddOrUpdateDetectsIndexMutation() {
                                           // Setup - create series with autoSort=false and no duplicates allowed
                                           XYSeries series = new XYSeries("Test", false, false);
                                           
                                           // Add initial items to create a scenario where index > 0
                                           series.add(1.0, 100.0);  // index 0
                                           series.add(2.0, 200.0);  // index 1
                                           series.add(3.0, 300.0);  // index 2
                                           
                                           // Test updating existing item at index > 0
                                           XYDataItem result = series.addOrUpdate(2.0, 250.0);
                                           
                                           // Verify the update occurred and returned the old item
                                           assertNotNull("Should return overwritten item", result);
                                           assertEquals(200.0, result.getY().doubleValue(), 0.0001);
                                           
                                           // Verify the update was applied
                                           assertEquals(250.0, series.getY(1).doubleValue(), 0.0001);
                                           
                                           // Verify no new item was added
                                           assertEquals(3, series.getItemCount());
                                           
                                           // This test will fail with the mutant because:
                                           // - indexOf(2.0) returns 1 (>0)
                                           // - Mutated condition (index <= 0) is false
                                           // - Original would enter the update block, mutant would skip it
                                       }

 @Test
                                      public void testAddOrUpdateWithNonExistingXShouldAddNewItem() {
                                          // Setup test data
                                          XYSeries series = new XYSeries("Test Series");
                                          series.add(1.0, 10.0);  // Existing item
                                          
                                          // Verify initial state
                                          assertEquals(1, series.getItemCount());
                                          
                                          // Test with non-existing x value
                                          XYDataItem result = series.addOrUpdate(2.0, 20.0);
                                          
                                          // Verify correct behavior (should add new item)
                                          assertEquals(2, series.getItemCount());  // Size should increase
                                          assertNotNull(result);  // Should return the new item
                                          assertEquals(2.0, result.getX().doubleValue(), 0.0001);
                                          assertEquals(20.0, result.getY().doubleValue(), 0.0001);
                                          
                                          // The mutant would fail here because:
                                          // - It would try to update non-existing item (index = -1)
                                          // - Wouldn't add new item (size would stay 1)
                                          // - Might throw IndexOutOfBoundsException
                                      }

 @Test
                                      public void testAddOrUpdateWithNewItemShouldNotEnterUpdateBlock() {
                                          // Setup - create series that doesn't allow duplicates and isn't auto-sorted
                                          XYSeries series = new XYSeries("Test", false, false);
                                          
                                          // Add initial item
                                          Number x1 = 1;
                                          Number y1 = 10;
                                          series.add(x1, y1);
                                          
                                          // Test adding new item (x2 doesn't exist in series)
                                          Number x2 = 2;
                                          Number y2 = 20;
                                          XYDataItem result = series.addOrUpdate(x2, y2);
                                          
                                          // Verify behavior
                                          assertNull("Should return null for new addition", result);
                                          assertEquals("Series should have 2 items", 2, series.getItemCount());
                                          assertEquals("New item should be added with correct y value", 
                                                       y2, series.getY(1));
                                          
                                          // Additional verification that we didn't enter the update block
                                          assertEquals("Original item should remain unchanged",
                                                       y1, series.getY(0));
                                      }

 @Test
                                     public void testAddOrUpdateUpdatesCorrectItemWhenNotFirst() {
                                         // Create series with autoSort=false to control item positions
                                         XYSeries series = new XYSeries("Test", false, true);
                                         
                                         // Add three items with different x values
                                         series.add(1.0, 10.0);  // index 0
                                         series.add(2.0, 20.0);  // index 1
                                         series.add(3.0, 30.0);  // index 2
                                         
                                         // Try to update the item at index 1 (x=2.0)
                                         XYDataItem result = series.addOrUpdate(2.0, 25.0);
                                         
                                         // Verify the correct item was updated
                                         assertEquals(2.0, result.getX().doubleValue(), 0.0001);
                                         assertEquals(25.0, result.getY().doubleValue(), 0.0001);
                                         
                                         // Verify the item at index 0 was NOT updated
                                         assertEquals(10.0, series.getY(0).doubleValue(), 0.0001);
                                         
                                         // Verify the item at index 1 was updated
                                         assertEquals(25.0, series.getY(1).doubleValue(), 0.0001);
                                         
                                         // Verify the item at index 2 was NOT updated
                                         assertEquals(30.0, series.getY(2).doubleValue(), 0.0001);
                                     }

 @Test
                                     public void testAddOrUpdateUpdatesCorrectItemWhenXExistsAtNonZeroIndex() {
                                         // Setup - create series with autoSort=false and no duplicate x values
                                         XYSeries series = new XYSeries("Test", false, false);
                                         
                                         // Add multiple items where the x we'll update is at index 1
                                         series.add(1.0, 10.0);  // index 0
                                         series.add(2.0, 20.0);  // index 1 (this is the one we'll update)
                                         series.add(3.0, 30.0);  // index 2
                                         
                                         // Call method - update x=2.0 (which is at index 1)
                                         XYDataItem result = series.addOrUpdate(2.0, 25.0);
                                         
                                         // Verify correct item was updated
                                         assertEquals(20.0, result.getY().doubleValue(), 0.0001);  // original y value returned
                                         assertEquals(25.0, series.getY(1).doubleValue(), 0.0001); // y at index 1 updated
                                         
                                         // Verify other items weren't changed
                                         assertEquals(10.0, series.getY(0).doubleValue(), 0.0001);
                                         assertEquals(30.0, series.getY(2).doubleValue(), 0.0001);
                                         
                                         // The mutant would update index 0 instead of index 1, so these assertions would fail
                                     }

 @Test
                                    public void testAddOrUpdateUpdatesExistingItem() {
                                        // Setup
                                        XYSeries series = new XYSeries("Test Series");
                                        double x = 1.0;
                                        double y1 = 10.0;
                                        double y2 = 20.0;
                                        
                                        // Add initial item
                                        series.add(x, y1);
                                        int initialItemCount = series.getItemCount();
                                        
                                        // Test addOrUpdate with same x value
                                        XYDataItem result = series.addOrUpdate(x, y2);
                                        
                                        // Verify
                                        assertEquals("Item count should not increase when updating", 
                                                     initialItemCount, series.getItemCount());
                                        assertEquals("Should return the updated item", 
                                                     y2, result.getY().doubleValue(), 0.0001);
                                        assertEquals("Item in series should be updated",
                                                     y2, series.getY(0).doubleValue(), 0.0001);
                                    }

 @Test
                                    public void testAddOrUpdate_ExistingItem_ReturnsClonedItem() {
                                        // Setup
                                        XYSeries series = new XYSeries("Test Series", false, false);
                                        Number x = 1.0;
                                        Number y1 = 10.0;
                                        Number y2 = 20.0;
                                        
                                        // Add initial item
                                        series.add(x, y1);
                                        
                                        // Test update
                                        XYDataItem result = series.addOrUpdate(x, y2);
                                        
                                        // Verify
                                        assertNotNull("Should return cloned item when updating", result);
                                        assertEquals("Cloned item should have original y value", y1, result.getY());
                                        
                                        // Verify update was successful
                                        assertEquals("Series should have updated y value", 
                                                     y2, series.getY(0));
                                        assertEquals("Series should still have only one item", 
                                                     1, series.getItemCount());
                                    }

 @Test(expected = RuntimeException.class)
                                   public void testAddOrUpdate_ShouldNotCatchNonCloneExceptions() throws CloneNotSupportedException {
                                       // Setup
                                       XYSeries series = new XYSeries("Test Series", true, false);
                                       Number x = 1;
                                       Number y = 10;
                                       
                                       // Add initial item
                                       series.add(x, y);
                                       
                                       // Create mock item that throws RuntimeException during clone
                                       XYDataItem mockItem = mock(XYDataItem.class);
                                       when(mockItem.clone()).thenThrow(new RuntimeException("Test exception"));
                                       
                                       // Replace the real item with our mock in the series
                                       // This requires accessing the internal data list, which we'll do via reflection
                                       try {
                                           Field dataField = XYSeries.class.getDeclaredField("data");
                                           dataField.setAccessible(true);
                                           List dataList = (List) dataField.get(series);
                                           dataList.set(0, mockItem);
                                       } catch (Exception e) {
                                           fail("Failed to setup test via reflection");
                                       }
                                       
                                       // Test - should throw the original RuntimeException, not SeriesException
                                       series.addOrUpdate(x, 20);
                                   }

 @Test
                              public void testAddOrUpdateHandlesCloneNotSupportedException() throws CloneNotSupportedException {
                                  // Create a new XYSeries
                                  XYSeries series = new XYSeries("Test Series");
                                  
                                  // Create a mock XYDataItem that throws CloneNotSupportedException
                                  XYDataItem mockItem = mock(XYDataItem.class);
                                  when(mockItem.clone()).thenThrow(new CloneNotSupportedException("Test clone exception"));
                                  when(mockItem.getX()).thenReturn(1.0);  // Mock getX() to return a value
                                  
                                  // Add the mock item to the series first
                                  series.add(mockItem);
                                  
                                  // Try to addOrUpdate with same x value
                                  // Both original and mutated versions should handle this gracefully
                                  XYDataItem result = series.addOrUpdate(mockItem.getX(), 2.0);
                                  assertNotNull(result);
                              }

 @Test
          public void testAddOrUpdatePropagatesNonCloneExceptions() throws CloneNotSupportedException {
              // Create test series
              XYSeries series = new XYSeries("Test Series");
              
              // Create a mock XYDataItem that throws RuntimeException when cloned
              XYDataItem mockItem = mock(XYDataItem.class);
              when(mockItem.getX()).thenReturn(1.0); // Need to mock getX() for the test
              when(mockItem.clone()).thenThrow(new CloneNotSupportedException())
                                    .thenThrow(new RuntimeException("Test exception"));
              
              // Add the mock item to the series first
              series.add(mockItem);
              
              // Try to addOrUpdate with same x value (should trigger clone attempt)
              // This should throw RuntimeException in original code
              try {
                  series.addOrUpdate(mockItem.getX(), 2.0);
                  fail("Expected RuntimeException to be thrown");
              } catch (RuntimeException e) {
                  // Expected behavior
              }
          }

 @Test(expected = SeriesException.class)
      public void testAddOrUpdate_CloneNotSupported_ThrowsException() throws CloneNotSupportedException {
          // Setup
          XYSeries series = new XYSeries("Test", true, false); // autoSort=true, no duplicates
          Number x = 1.0;
          Number y = 2.0;
          
          // Add initial item that will fail to clone
          XYDataItem mockItem = mock(XYDataItem.class);
          when(mockItem.clone()).thenThrow(new CloneNotSupportedException());
          
          // Add the mock item to the series first
          series.add(mockItem);
          
          // Try to update - should attempt to clone existing item and fail
          series.addOrUpdate(x, y);
          
          // If we get here without exception, the test fails (mutant survives)
      }

 @Test(expected = SeriesException.class)
     public void testAddOrUpdateWhenCloneFails() {
         // Create a series to test with
         XYSeries series = new XYSeries("Test Series");
         
         // Create a custom XYDataItem that fails to clone
         XYDataItem failingItem = new XYDataItem(1.0, 2.0) {
             @Override
             public Object clone() throws CloneNotSupportedException {
                 throw new CloneNotSupportedException("Simulated clone failure");
             }
         };
         
         // Try to add the item that will fail to clone
         // This should throw SeriesException in original code
         // Mutant would return null instead
         series.addOrUpdate(failingItem.getX(), failingItem.getY());
     }

 @Test(expected = CloneNotSupportedException.class)
     public void testAddOrUpdateWhenCloneFails_CheckForNull() throws CloneNotSupportedException {
         // Create a series to test with
         XYSeries series = new XYSeries("Test Series");
         
         // Create a custom XYDataItem that fails to clone
         XYDataItem failingItem = new XYDataItem(1.0, 2.0) {
             @Override
             public Object clone() throws CloneNotSupportedException {
                 throw new CloneNotSupportedException("Simulated clone failure");
             }
         };
         
         // Try to add the item that will fail to clone
         // This should throw CloneNotSupportedException
         series.addOrUpdate(failingItem.getX(), failingItem.getY());
     }

 @Test
 public void testAddOrUpdateShouldUpdateYValueNotSetToNull() {
     // Create test series
     XYSeries series = new XYSeries("Test Series");
     
     // Add initial data point
     Number x = 1.0;
     Number initialY = 10.0;
     series.add(x, initialY);
     
     // Verify initial state
     assertEquals(1, series.getItemCount());
     assertEquals(initialY, series.getY(0));
     
     // Update with new y value
     Number updatedY = 20.0;
     XYDataItem result = series.addOrUpdate(x, updatedY);
     
     // Verify the update
     assertEquals(1, series.getItemCount()); // Should still have 1 item
     assertEquals(updatedY, series.getY(0)); // y should be updated to 20.0, not null
     assertEquals(updatedY, result.getY()); // returned item should have updated y value
 }

 @Test
 public void testAddOrUpdateShouldUpdateYValueWhenXExists() {
     // Setup
     XYSeries series = new XYSeries("Test Series", true, false); // autoSort=true, no duplicates
     Number x = 1.0;
     Number initialY = 10.0;
     Number newY = 20.0;
     
     // Add initial item
     series.add(x, initialY);
     
     // Action - update existing item
     XYDataItem overwritten = series.addOrUpdate(x, newY);
     
     // Verify overwritten item has original y
     assertEquals(initialY, overwritten.getY());
     
     // Verify series now contains new y value (this will fail with mutant)
     assertEquals(newY, series.getY(0));
     
     // Additional verification that we didn't add a new item
     assertEquals(1, series.getItemCount());
 }

}
