package gentest.org.jfree.data.statistics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.statistics.*;
import java.util.List;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.data.KeyedObjects2D;
import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.general.AbstractDataset;
 
public class DefaultBoxAndWhiskerCategoryDatasetTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                        public void testAdd_WithNullRowKey() {
                            // Setup
                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                            List<Double> values = new ArrayList<>();
                            values.add(1.0);
                            String columnKey = "Column1";
                            
                            thrown.expect(IllegalArgumentException.class);
                            
                            // Execute
                            dataset.add(values, null, columnKey);
                        }

    @Test
                        public void testAdd_WithNullColumnKey() {
                            // Setup
                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                            List<Double> values = new ArrayList<>();
                            values.add(1.0);
                            String rowKey = "Row1";
                            
                            thrown.expect(IllegalArgumentException.class);
                            
                            // Execute
                            dataset.add(values, rowKey, null);
                        }

    @Test
                public void testAdd_WithValidData() {
                    // Setup
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    List<Double> values = new ArrayList<>();
                    values.add(1.0);
                    values.add(2.0);
                    values.add(3.0);
                    values.add(4.0);
                    values.add(5.0);
                    
                    String rowKey = "Row1";
                    String columnKey = "Column1";
                    
                    // Execute
                    dataset.add(values, rowKey, columnKey);
                    
                    // Verify
                    BoxAndWhiskerItem item = dataset.getItem(dataset.getRowIndex(rowKey), dataset.getColumnIndex(columnKey));
                    assertNotNull(item);
                    assertEquals(3.0, item.getMedian().doubleValue(), 0.001);
                    assertEquals(1.0, dataset.getMinRegularValue(rowKey, columnKey).doubleValue(), 0.001);
                    assertEquals(5.0, dataset.getMaxRegularValue(rowKey, columnKey).doubleValue(), 0.001);
                    
                    // Verify range bounds were updated
                    assertEquals(1.0, dataset.getRangeLowerBound(true), 0.001);
                    assertEquals(5.0, dataset.getRangeUpperBound(true), 0.001);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testAdd_WithNullList() {
                    // Setup
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    String rowKey = "Row1";
                    String columnKey = "Column1";
                    
                    // Execute
                    dataset.add((List)null, rowKey, columnKey);
                }

    @Test
                public void testAdd_WithSingleValueList() {
                    // Setup
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    List<Double> singleValue = new ArrayList<Double>();
                    singleValue.add(42.0);
                    
                    // Execute
                    dataset.add(singleValue, "Row1", "Column1");
                    
                    // Verify
                    int row = dataset.getRowIndex("Row1");
                    int column = dataset.getColumnIndex("Column1");
                    BoxAndWhiskerItem item = dataset.getItem(row, column);
                    assertEquals(42.0, item.getMedian().doubleValue(), 0.001);
                    assertEquals(42.0, item.getQ1().doubleValue(), 0.001);
                    assertEquals(42.0, item.getQ3().doubleValue(), 0.001);
                }

    @Test
                public void testAdd_FirstItem() {
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                    Comparable<String> rowKey = "Row1";
                    Comparable<String> columnKey = "Column1";
                    
                    when(item.getMinOutlier()).thenReturn(5.0);
                    when(item.getMaxOutlier()).thenReturn(10.0);
                    
                    dataset.add(item, rowKey, columnKey);
                    
                    assertEquals(5.0, dataset.getRangeBounds(false).getLowerBound(), 0.001);
                    assertEquals(10.0, dataset.getRangeBounds(false).getUpperBound(), 0.001);
                    assertEquals(0, dataset.getRowIndex(rowKey));
                    assertEquals(0, dataset.getColumnIndex(columnKey));
                }

    @Test
                public void testAdd_ItemWithHigherMaxOutlier() {
                    // Initialize dataset
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    Comparable<String> rowKey = "Row1";
                    Comparable<String> columnKey = "Column1";
                    
                    // Add initial item
                    BoxAndWhiskerItem firstItem = mock(BoxAndWhiskerItem.class);
                    when(firstItem.getMinOutlier()).thenReturn(5.0);
                    when(firstItem.getMaxOutlier()).thenReturn(10.0);
                    dataset.add(firstItem, rowKey, columnKey);
                
                    // Add new item with higher max outlier
                    BoxAndWhiskerItem secondItem = mock(BoxAndWhiskerItem.class);
                    when(secondItem.getMinOutlier()).thenReturn(7.0);
                    when(secondItem.getMaxOutlier()).thenReturn(15.0);
                    dataset.add(secondItem, "Row2", "Column1");
                
                    assertEquals(5.0, dataset.getRangeBounds(false).getLowerBound(), 0.001);
                    assertEquals(15.0, dataset.getRangeBounds(false).getUpperBound(), 0.001);
                }

    @Test
                public void testAdd_ItemWithLowerMinOutlier() {
                    // Initialize dataset
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    Comparable<String> rowKey = "Row1";
                    Comparable<String> columnKey = "Column1";
                    
                    // Add initial item
                    BoxAndWhiskerItem firstItem = mock(BoxAndWhiskerItem.class);
                    when(firstItem.getMinOutlier()).thenReturn(5.0);
                    when(firstItem.getMaxOutlier()).thenReturn(10.0);
                    dataset.add(firstItem, rowKey, columnKey);
                    
                    // Add new item with lower min outlier
                    BoxAndWhiskerItem secondItem = mock(BoxAndWhiskerItem.class);
                    when(secondItem.getMinOutlier()).thenReturn(2.0);
                    when(secondItem.getMaxOutlier()).thenReturn(8.0);
                    dataset.add(secondItem, "Row2", "Column1");
                    
                    assertEquals(2.0, dataset.getRangeBounds(false).getLowerBound(), 0.001);
                    assertEquals(10.0, dataset.getRangeBounds(false).getUpperBound(), 0.001);
                }

    @Test
                public void testAdd_ItemToCurrentMinMaxPosition() {
                    // Define row and column keys
                    Comparable<String> rowKey = "Row";
                    Comparable<String> columnKey = "Column";
                    
                    // Create dataset instance
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    
                    // Add initial item that will be min/max
                    BoxAndWhiskerItem firstItem = mock(BoxAndWhiskerItem.class);
                    when(firstItem.getMinOutlier()).thenReturn(5.0);
                    when(firstItem.getMaxOutlier()).thenReturn(10.0);
                    dataset.add(firstItem, rowKey, columnKey);
                
                    // Add another item to same position
                    BoxAndWhiskerItem secondItem = mock(BoxAndWhiskerItem.class);
                    when(secondItem.getMinOutlier()).thenReturn(7.0);
                    when(secondItem.getMaxOutlier()).thenReturn(12.0);
                    dataset.add(secondItem, rowKey, columnKey);
                
                    // Should trigger updateBounds() since we replaced the min/max position
                    // We can't directly test updateBounds() was called, but we can verify the new bounds
                    assertEquals(7.0, dataset.getRangeBounds(false).getLowerBound(), 0.001);
                    assertEquals(12.0, dataset.getRangeBounds(false).getUpperBound(), 0.001);
                }

    @Test
                public void testAdd_ItemWithNullOutliers() {
                    // Initialize test objects
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    Comparable<String> rowKey = "Row1";
                    Comparable<String> columnKey = "Column1";
                    
                    // Create mock item
                    BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                    when(item.getMinOutlier()).thenReturn(null);
                    when(item.getMaxOutlier()).thenReturn(null);
                    
                    // Test the method
                    dataset.add(item, rowKey, columnKey);
                    
                    // Verify results
                    assertTrue(Double.isNaN(dataset.getRangeBounds(false).getLowerBound()));
                    assertTrue(Double.isNaN(dataset.getRangeBounds(false).getUpperBound()));
                }

    @Test
                public void testAdd_ItemWithPartialOutliers() {
                    // Initialize dataset and keys
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    Comparable<String> rowKey = "Row 1";
                    Comparable<String> columnKey = "Column 1";
                    
                    // Test with only min outlier
                    BoxAndWhiskerItem minOnlyItem = mock(BoxAndWhiskerItem.class);
                    when(minOnlyItem.getMinOutlier()).thenReturn(5.0);
                    when(minOnlyItem.getMaxOutlier()).thenReturn(null);
                    dataset.add(minOnlyItem, rowKey, columnKey);
                    
                    assertEquals(5.0, dataset.getRangeBounds(false).getLowerBound(), 0.001);
                    assertTrue(Double.isNaN(dataset.getRangeBounds(false).getUpperBound()));
                    
                    // Reset dataset
                    dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    
                    // Test with only max outlier
                    BoxAndWhiskerItem maxOnlyItem = mock(BoxAndWhiskerItem.class);
                    when(maxOnlyItem.getMinOutlier()).thenReturn(null);
                    when(maxOnlyItem.getMaxOutlier()).thenReturn(10.0);
                    dataset.add(maxOnlyItem, rowKey, columnKey);
                    
                    assertTrue(Double.isNaN(dataset.getRangeBounds(false).getLowerBound()));
                    assertEquals(10.0, dataset.getRangeBounds(false).getUpperBound(), 0.001);
                }

    @Test
                public void testAdd_MultipleItemsWithoutAffectingBounds() {
                    // Initialize dataset
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    Comparable<String> rowKey = "Row1";
                    Comparable<String> columnKey = "Column1";
                    
                    // Add initial item that sets bounds
                    BoxAndWhiskerItem boundsItem = mock(BoxAndWhiskerItem.class);
                    when(boundsItem.getMinOutlier()).thenReturn(5.0);
                    when(boundsItem.getMaxOutlier()).thenReturn(10.0);
                    dataset.add(boundsItem, rowKey, columnKey);
                    
                    // Add items that don't affect bounds
                    BoxAndWhiskerItem insideItem1 = mock(BoxAndWhiskerItem.class);
                    when(insideItem1.getMinOutlier()).thenReturn(6.0);
                    when(insideItem1.getMaxOutlier()).thenReturn(9.0);
                    dataset.add(insideItem1, "Row2", "Column1");
                    
                    BoxAndWhiskerItem insideItem2 = mock(BoxAndWhiskerItem.class);
                    when(insideItem2.getMinOutlier()).thenReturn(7.0);
                    when(insideItem2.getMaxOutlier()).thenReturn(8.0);
                    dataset.add(insideItem2, "Row1", "Column2");
                    
                    // Bounds should remain the same
                    assertEquals(5.0, dataset.getRangeBounds(false).getLowerBound(), 0.001);
                    assertEquals(10.0, dataset.getRangeBounds(false).getUpperBound(), 0.001);
                }

    @Test
                public void testUpdateBounds_EmptyDataset() throws Exception {
                    // Setup
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    Field rowCountField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("rowCount");
                    rowCountField.setAccessible(true);
                    rowCountField.set(dataset, 0);
                    Field columnCountField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("columnCount");
                    columnCountField.setAccessible(true);
                    columnCountField.set(dataset, 0);
                    
                    // Execute
                    Method updateBounds = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                    updateBounds.setAccessible(true);
                    updateBounds.invoke(dataset);
                    
                    // Verify
                    Field minRangeValue = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                    minRangeValue.setAccessible(true);
                    assertTrue(Double.isNaN((Double)minRangeValue.get(dataset)));
                    
                    Field minRangeRow = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                    minRangeRow.setAccessible(true);
                    assertEquals(-1, minRangeRow.get(dataset));
                    
                    Field minRangeCol = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                    minRangeCol.setAccessible(true);
                    assertEquals(-1, minRangeCol.get(dataset));
                    
                    Field maxRangeValue = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                    maxRangeValue.setAccessible(true);
                    assertTrue(Double.isNaN((Double)maxRangeValue.get(dataset)));
                    
                    Field maxRangeRow = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                    maxRangeRow.setAccessible(true);
                    assertEquals(-1, maxRangeRow.get(dataset));
                    
                    Field maxRangeCol = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                    maxRangeCol.setAccessible(true);
                    assertEquals(-1, maxRangeCol.get(dataset));
                }

    @Test
                public void testUpdateBounds_AllNullItems() throws Exception {
                    // Setup
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    KeyedObjects2D data = mock(KeyedObjects2D.class);
                    
                    // Use reflection to set private data field
                    Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                    dataField.setAccessible(true);
                    dataField.set(dataset, data);
                    
                    when(data.getRowCount()).thenReturn(2);
                    when(data.getColumnCount()).thenReturn(2);
                    when(data.getObject(anyInt(), anyInt())).thenReturn(null);
                    
                    // Execute
                    Method updateBounds = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                    updateBounds.setAccessible(true);
                    updateBounds.invoke(dataset);
                    
                    // Verify using reflection
                    Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                    minValueField.setAccessible(true);
                    double minValue = (Double) minValueField.get(dataset);
                    assertTrue(Double.isNaN(minValue));
                    
                    Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                    minRowField.setAccessible(true);
                    assertEquals(-1, minRowField.get(dataset));
                    
                    Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                    minColField.setAccessible(true);
                    assertEquals(-1, minColField.get(dataset));
                    
                    Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                    maxValueField.setAccessible(true);
                    double maxValue = (Double) maxValueField.get(dataset);
                    assertTrue(Double.isNaN(maxValue));
                    
                    Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                    maxRowField.setAccessible(true);
                    assertEquals(-1, maxRowField.get(dataset));
                    
                    Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                    maxColField.setAccessible(true);
                    assertEquals(-1, maxColField.get(dataset));
                }

    @Test
                public void testUpdateBounds_ItemsWithNaNOutliers() {
                    // Setup
                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                    BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                    when(item.getMinOutlier()).thenReturn(Double.NaN);
                    when(item.getMaxOutlier()).thenReturn(Double.NaN);
                    
                    // Add the item to the dataset
                    dataset.add(item, "Row1", "Column1");
                    
                    // Execute
                    try {
                        Method method = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                        method.setAccessible(true);
                        method.invoke(dataset);
                    } catch (Exception e) {
                        fail("Failed to invoke updateBounds method");
                    }
                    
                    // Verify
                    try {
                        Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                        minValueField.setAccessible(true);
                        double minValue = minValueField.getDouble(dataset);
                        assertTrue(Double.isNaN(minValue));
                        
                        Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                        minRowField.setAccessible(true);
                        assertEquals(-1, minRowField.getInt(dataset));
                        
                        Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                        minColField.setAccessible(true);
                        assertEquals(-1, minColField.getInt(dataset));
                        
                        Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                        maxValueField.setAccessible(true);
                        double maxValue = maxValueField.getDouble(dataset);
                        assertTrue(Double.isNaN(maxValue));
                        
                        Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                        maxRowField.setAccessible(true);
                        assertEquals(-1, maxRowField.getInt(dataset));
                        
                        Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                        maxColField.setAccessible(true);
                        assertEquals(-1, maxColField.getInt(dataset));
                    } catch (Exception e) {
                        fail("Failed to access fields for verification");
                    }
                }

    @Test
            public void testUpdateBounds_SingleValidItem() throws Exception {
                // Setup
                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                when(item.getMinOutlier()).thenReturn(5.0);
                when(item.getMaxOutlier()).thenReturn(15.0);
                
                // Use reflection to set the private data field
                Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                dataField.setAccessible(true);
                KeyedObjects2D data = mock(KeyedObjects2D.class);
                dataField.set(dataset, data);
                
                when(data.getRowCount()).thenReturn(1);
                when(data.getColumnCount()).thenReturn(1);
                when(data.getObject(0, 0)).thenReturn(item);
                
                // Execute
                Method updateBounds = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                updateBounds.setAccessible(true);
                updateBounds.invoke(dataset);
                
                // Verify using reflection to access private fields
                Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                minValueField.setAccessible(true);
                Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                minRowField.setAccessible(true);
                Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                minColField.setAccessible(true);
                Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                maxValueField.setAccessible(true);
                Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                maxRowField.setAccessible(true);
                Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                maxColField.setAccessible(true);
                
                assertEquals(5.0, (Double)minValueField.get(dataset), 0.0001);
                assertEquals(0, minRowField.get(dataset));
                assertEquals(0, minColField.get(dataset));
                assertEquals(15.0, (Double)maxValueField.get(dataset), 0.0001);
                assertEquals(0, maxRowField.get(dataset));
                assertEquals(0, maxColField.get(dataset));
            }

    @Test
            public void testUpdateBounds_MultipleItems() throws Exception {
                // Setup
                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                KeyedObjects2D data = new KeyedObjects2D();
                
                // Use reflection to set the private data field
                Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                dataField.setAccessible(true);
                dataField.set(dataset, data);
                
                BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                when(item1.getMinOutlier()).thenReturn(2.0);
                when(item1.getMaxOutlier()).thenReturn(10.0);
                
                BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                when(item2.getMinOutlier()).thenReturn(1.0);
                when(item2.getMaxOutlier()).thenReturn(20.0);
                
                BoxAndWhiskerItem item3 = mock(BoxAndWhiskerItem.class);
                when(item3.getMinOutlier()).thenReturn(3.0);
                when(item3.getMaxOutlier()).thenReturn(15.0);
                
                data.addObject(item1, "Row1", "Column1");
                data.addObject(item2, "Row1", "Column2");
                data.addObject(item3, "Row2", "Column1");
                
                // Execute
                Method updateBounds = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                updateBounds.setAccessible(true);
                updateBounds.invoke(dataset);
                
                // Verify
                Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                minValueField.setAccessible(true);
                assertEquals(1.0, (Double)minValueField.get(dataset), 0.0001);
                
                Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                minRowField.setAccessible(true);
                assertEquals(0, minRowField.get(dataset));
                
                Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                minColField.setAccessible(true);
                assertEquals(1, minColField.get(dataset));
                
                Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                maxValueField.setAccessible(true);
                assertEquals(20.0, (Double)maxValueField.get(dataset), 0.0001);
                
                Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                maxRowField.setAccessible(true);
                assertEquals(0, maxRowField.get(dataset));
                
                Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                maxColField.setAccessible(true);
                assertEquals(1, maxColField.get(dataset));
            }

    @Test
            public void testAdd_WithEmptyList() {
                // Setup
                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                List<Double> emptyList = new ArrayList<>();
                String rowKey = "Row1";
                String columnKey = "Column1";
                
                // Execute
                dataset.add(emptyList, rowKey, columnKey);
                
                // Verify
                int row = dataset.getRowIndex(rowKey);
                int column = dataset.getColumnIndex(columnKey);
                BoxAndWhiskerItem item = dataset.getItem(row, column);
                assertNotNull(item);
                assertTrue(Double.isNaN(item.getMean().doubleValue()));
                assertTrue(Double.isNaN(item.getMedian().doubleValue()));
            }

    @Test
            public void testUpdateBounds_ItemsWithNullOutliers() {
                // Setup
                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                when(item.getMinOutlier()).thenReturn(null);
                when(item.getMaxOutlier()).thenReturn(null);
                
                // Add the item to the dataset
                dataset.add(item, "Row1", "Column1");
                
                // Use reflection to access private updateBounds method
                try {
                    Method method = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                    method.setAccessible(true);
                    method.invoke(dataset);
                    
                    // Use reflection to access private fields for verification
                    Field minRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                    minRangeValueField.setAccessible(true);
                    Field minRangeRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                    minRangeRowField.setAccessible(true);
                    Field minRangeColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                    minRangeColField.setAccessible(true);
                    Field maxRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                    maxRangeValueField.setAccessible(true);
                    Field maxRangeRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                    maxRangeRowField.setAccessible(true);
                    Field maxRangeColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                    maxRangeColField.setAccessible(true);
                    
                    // Verify
                    assertTrue(Double.isNaN((Double)minRangeValueField.get(dataset)));
                    assertEquals(-1, minRangeRowField.get(dataset));
                    assertEquals(-1, minRangeColField.get(dataset));
                    assertTrue(Double.isNaN((Double)maxRangeValueField.get(dataset)));
                    assertEquals(-1, maxRangeRowField.get(dataset));
                    assertEquals(-1, maxRangeColField.get(dataset));
                } catch (Exception e) {
                    fail("Failed to invoke updateBounds method or access fields via reflection: " + e.getMessage());
                }
            }

    @Test
        public void testAdd_UpdatesMinMaxRangeValues() {
            // Setup
            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
            java.util.List<Double> values1 = java.util.Arrays.asList(1.0, 2.0, 3.0);
            java.util.List<Double> values2 = java.util.Arrays.asList(4.0, 5.0, 6.0);
            
            // Execute
            dataset.add(values1, "Row1", "Column1");
            dataset.add(values2, "Row2", "Column1");
            
            // Verify
            assertEquals(1.0, dataset.getRangeLowerBound(true), 0.001);
            assertEquals(6.0, dataset.getRangeUpperBound(true), 0.001);
            assertEquals(1.0, dataset.getRangeLowerBound(true), 0.001);
            assertEquals(6.0, dataset.getRangeUpperBound(true), 0.001);
        }

    @Test
    public void testUpdateBounds_ExtremeValues() throws NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        // Setup
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.KeyedObjects2D data = mock(org.jfree.data.KeyedObjects2D.class);
        
        // Use reflection to set the private data field
        Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
        dataField.setAccessible(true);
        dataField.set(dataset, data);
        
        BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
        when(item1.getMinOutlier()).thenReturn(Double.MIN_VALUE);
        when(item1.getMaxOutlier()).thenReturn(Double.MAX_VALUE);
        
        BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
        when(item2.getMinOutlier()).thenReturn(Double.NEGATIVE_INFINITY);
        when(item2.getMaxOutlier()).thenReturn(Double.POSITIVE_INFINITY);
        
        when(data.getRowCount()).thenReturn(1);
        when(data.getColumnCount()).thenReturn(2);
        when(data.getObject(0, 0)).thenReturn(item1);
        when(data.getObject(0, 1)).thenReturn(item2);
        
        // Execute - use reflection to call private updateBounds method
        Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
        updateBoundsMethod.setAccessible(true);
        updateBoundsMethod.invoke(dataset);
        
        // Use reflection to get private fields for verification
        Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
        minValueField.setAccessible(true);
        double minValue = minValueField.getDouble(dataset);
        
        Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
        minRowField.setAccessible(true);
        int minRow = minRowField.getInt(dataset);
        
        Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
        minColField.setAccessible(true);
        int minCol = minColField.getInt(dataset);
        
        Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
        maxValueField.setAccessible(true);
        double maxValue = maxValueField.getDouble(dataset);
        
        Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
        maxRowField.setAccessible(true);
        int maxRow = maxRowField.getInt(dataset);
        
        Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
        maxColField.setAccessible(true);
        int maxCol = maxColField.getInt(dataset);
        
        // Verify
        assertEquals(Double.NEGATIVE_INFINITY, minValue, 0.0001);
        assertEquals(0, minRow);
        assertEquals(1, minCol);
        assertEquals(Double.POSITIVE_INFINITY, maxValue, 0.0001);
        assertEquals(0, maxRow);
        assertEquals(1, maxCol);
    }


}
