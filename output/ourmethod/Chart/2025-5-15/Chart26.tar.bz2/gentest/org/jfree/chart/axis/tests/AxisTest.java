package gentest.org.jfree.chart.axis.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.axis.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.EventListener;
import java.util.List;
import javax.swing.event.EventListenerList;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.entity.AxisLabelEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.AxisChangeListener;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.text.TextAnchor;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
 
public class AxisTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                public void testDrawLabel_NullOrEmptyLabel() throws Exception {
                                                                                                                                                                                                                                                                                                                                    // Setup test objects
                                                                                                                                                                                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                                                                                    AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                                                    PlotRenderingInfo plotState = null;
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Create axis instance
                                                                                                                                                                                                                                                                                                                                    Axis axis = new Axis("Test Axis") {
                                                                                                                                                                                                                                                                                                                                        // Anonymous subclass to make abstract class concrete
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public void configure() {}
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                                RectangleEdge edge, AxisSpace space) { return null; }
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                                Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) { return null; }
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, 
                                                                                                                                                                                                                                                                                                                                                RectangleEdge edge) { return null; }
                                                                                                                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Get the protected method using reflection
                                                                                                                                                                                                                                                                                                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                        "drawLabel", 
                                                                                                                                                                                                                                                                                                                                        String.class, 
                                                                                                                                                                                                                                                                                                                                        Graphics2D.class, 
                                                                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.class, 
                                                                                                                                                                                                                                                                                                                                        AxisState.class, 
                                                                                                                                                                                                                                                                                                                                        PlotRenderingInfo.class
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Test null label
                                                                                                                                                                                                                                                                                                                                    AxisState result1 = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                                                                                        axis, 
                                                                                                                                                                                                                                                                                                                                        null, 
                                                                                                                                                                                                                                                                                                                                        g2, 
                                                                                                                                                                                                                                                                                                                                        plotArea, 
                                                                                                                                                                                                                                                                                                                                        dataArea, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.TOP, 
                                                                                                                                                                                                                                                                                                                                        state, 
                                                                                                                                                                                                                                                                                                                                        plotState
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    assertSame(state, result1);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Test empty label
                                                                                                                                                                                                                                                                                                                                    AxisState result2 = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                                                                                        axis, 
                                                                                                                                                                                                                                                                                                                                        "", 
                                                                                                                                                                                                                                                                                                                                        g2, 
                                                                                                                                                                                                                                                                                                                                        plotArea, 
                                                                                                                                                                                                                                                                                                                                        dataArea, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.TOP, 
                                                                                                                                                                                                                                                                                                                                        state, 
                                                                                                                                                                                                                                                                                                                                        plotState
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    assertSame(state, result2);
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testDrawLabel_TopEdge() throws Exception {
                                                                                                                                                                                                                                                                                                                                    // Setup mock objects and test data
                                                                                                                                                                                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                                                    FontMetrics fontMetrics = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                                                                                    when(g2.getFontMetrics(any(Font.class))).thenReturn(fontMetrics);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 800, 600);
                                                                                                                                                                                                                                                                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(100, 100, 600, 400);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                                                    state.setCursor(400); // Start cursor position
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Create axis instance and set necessary properties
                                                                                                                                                                                                                                                                                                                                    Axis axis = new NumberAxis("Test Axis");
                                                                                                                                                                                                                                                                                                                                    axis.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
                                                                                                                                                                                                                                                                                                                                    axis.setLabelPaint(Color.BLACK);
                                                                                                                                                                                                                                                                                                                                    axis.setLabelInsets(new RectangleInsets(5, 5, 5, 5));
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                        "drawLabel", 
                                                                                                                                                                                                                                                                                                                                        String.class, 
                                                                                                                                                                                                                                                                                                                                        Graphics2D.class, 
                                                                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.class, 
                                                                                                                                                                                                                                                                                                                                        AxisState.class, 
                                                                                                                                                                                                                                                                                                                                        PlotRenderingInfo.class
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Execute test
                                                                                                                                                                                                                                                                                                                                    AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                                                                                        axis, 
                                                                                                                                                                                                                                                                                                                                        "Test Label", 
                                                                                                                                                                                                                                                                                                                                        g2, 
                                                                                                                                                                                                                                                                                                                                        plotArea, 
                                                                                                                                                                                                                                                                                                                                        dataArea, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.TOP, 
                                                                                                                                                                                                                                                                                                                                        state, 
                                                                                                                                                                                                                                                                                                                                        plotState
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify cursor was updated correctly
                                                                                                                                                                                                                                                                                                                                    assertNotEquals(400, result.getCursor(), 0.001);
                                                                                                                                                                                                                                                                                                                                    assertTrue(result.getCursor() < 400); // Should move up
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify text was drawn
                                                                                                                                                                                                                                                                                                                                    verify(g2).setFont(axis.getLabelFont());
                                                                                                                                                                                                                                                                                                                                    verify(g2).setPaint(axis.getLabelPaint());
                                                                                                                                                                                                                                                                                                                                    verify(g2).drawString(anyString(), anyFloat(), anyFloat());
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testDrawLabel_BottomEdge() throws Exception {
                                                                                                                                                                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                                                    FontMetrics fontMetrics = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                                                                                    when(g2.getFontMetrics(any(Font.class))).thenReturn(fontMetrics);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Initialize rectangles
                                                                                                                                                                                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 500, 500);
                                                                                                                                                                                                                                                                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(50, 50, 400, 400);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Initialize axis state
                                                                                                                                                                                                                                                                                                                                    AxisState state = new AxisState(100); // Start cursor position
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Mock plot state
                                                                                                                                                                                                                                                                                                                                    PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Create axis instance
                                                                                                                                                                                                                                                                                                                                    Axis axis = new CategoryAxis("Test Axis");
                                                                                                                                                                                                                                                                                                                                    axis.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
                                                                                                                                                                                                                                                                                                                                    axis.setLabelPaint(Color.BLACK);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                        "drawLabel", 
                                                                                                                                                                                                                                                                                                                                        String.class, 
                                                                                                                                                                                                                                                                                                                                        Graphics2D.class, 
                                                                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.class, 
                                                                                                                                                                                                                                                                                                                                        AxisState.class, 
                                                                                                                                                                                                                                                                                                                                        PlotRenderingInfo.class
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                    AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                                                                                        axis, 
                                                                                                                                                                                                                                                                                                                                        "Test Label", 
                                                                                                                                                                                                                                                                                                                                        g2, 
                                                                                                                                                                                                                                                                                                                                        plotArea, 
                                                                                                                                                                                                                                                                                                                                        dataArea, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.BOTTOM, 
                                                                                                                                                                                                                                                                                                                                        state, 
                                                                                                                                                                                                                                                                                                                                        plotState
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify cursor was updated correctly
                                                                                                                                                                                                                                                                                                                                    assertNotEquals(100.0, result.getCursor(), 0.001);
                                                                                                                                                                                                                                                                                                                                    assertTrue(result.getCursor() > 100); // Should move down
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify text was drawn
                                                                                                                                                                                                                                                                                                                                    verify(g2).setFont(axis.getLabelFont());
                                                                                                                                                                                                                                                                                                                                    verify(g2).setPaint(axis.getLabelPaint());
                                                                                                                                                                                                                                                                                                                                    verify(g2).drawString(anyString(), anyFloat(), anyFloat());
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testDrawLabel_LeftEdge() throws Exception {
                                                                                                                                                                                                                                                                                                                                    // Setup mock objects
                                                                                                                                                                                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                                                    FontMetrics fontMetrics = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                                                                                    when(g2.getFontMetrics(any(Font.class))).thenReturn(fontMetrics);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Initialize rectangles
                                                                                                                                                                                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 500, 500);
                                                                                                                                                                                                                                                                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(50, 50, 400, 400);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Initialize axis state
                                                                                                                                                                                                                                                                                                                                    AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                                                    state.setCursor(100); // Start cursor position
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Create test axis
                                                                                                                                                                                                                                                                                                                                    Axis axis = new CategoryAxis("Test Axis");
                                                                                                                                                                                                                                                                                                                                    axis.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
                                                                                                                                                                                                                                                                                                                                    axis.setLabelPaint(Color.BLACK);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                        "drawLabel", 
                                                                                                                                                                                                                                                                                                                                        String.class, 
                                                                                                                                                                                                                                                                                                                                        Graphics2D.class, 
                                                                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.class, 
                                                                                                                                                                                                                                                                                                                                        AxisState.class, 
                                                                                                                                                                                                                                                                                                                                        PlotRenderingInfo.class
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Call method under test
                                                                                                                                                                                                                                                                                                                                    AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                                                                                        axis, 
                                                                                                                                                                                                                                                                                                                                        "Test Label", 
                                                                                                                                                                                                                                                                                                                                        g2, 
                                                                                                                                                                                                                                                                                                                                        plotArea, 
                                                                                                                                                                                                                                                                                                                                        dataArea, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.LEFT, 
                                                                                                                                                                                                                                                                                                                                        state, 
                                                                                                                                                                                                                                                                                                                                        null
                                                                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify cursor was updated correctly
                                                                                                                                                                                                                                                                                                                                    assertNotEquals(100, result.getCursor(), 0.001);
                                                                                                                                                                                                                                                                                                                                    assertTrue(result.getCursor() < 100); // Should move left
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify text was drawn with rotation
                                                                                                                                                                                                                                                                                                                                    verify(g2).setFont(axis.getLabelFont());
                                                                                                                                                                                                                                                                                                                                    verify(g2).setPaint(axis.getLabelPaint());
                                                                                                                                                                                                                                                                                                                                    verify(g2).drawString(anyString(), anyFloat(), anyFloat());
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testDrawLabel_RightEdge() throws Exception {
                                                                                                                                                                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                                                    FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                                                                                    when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Initialize rectangles
                                                                                                                                                                                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 500, 500);
                                                                                                                                                                                                                                                                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(50, 50, 400, 400);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Initialize axis state
                                                                                                                                                                                                                                                                                                                                    AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                                                    state.setCursor(400); // Start cursor position
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Initialize plot state (can be null according to method implementation)
                                                                                                                                                                                                                                                                                                                                    PlotRenderingInfo plotState = null;
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Create concrete Axis subclass that implements all abstract methods
                                                                                                                                                                                                                                                                                                                                    class TestAxis extends Axis {
                                                                                                                                                                                                                                                                                                                                        public TestAxis(String label) {
                                                                                                                                                                                                                                                                                                                                            super(label);
                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public void configure() {}
                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                                RectangleEdge edge, AxisSpace space) {
                                                                                                                                                                                                                                                                                                                                            return space;
                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                                Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                                                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public List refreshTicks(Graphics2D g2, AxisState state, 
                                                                                                                                                                                                                                                                                                                                                Rectangle2D dataArea, RectangleEdge edge) {
                                                                                                                                                                                                                                                                                                                                            return new ArrayList();
                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Create axis instance and set required properties
                                                                                                                                                                                                                                                                                                                                    TestAxis axis = new TestAxis("Test Axis");
                                                                                                                                                                                                                                                                                                                                    axis.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
                                                                                                                                                                                                                                                                                                                                    axis.setLabelPaint(Color.BLACK);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Use reflection to access protected drawLabel method
                                                                                                                                                                                                                                                                                                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", 
                                                                                                                                                                                                                                                                                                                                            String.class, Graphics2D.class, Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                            Rectangle2D.class, RectangleEdge.class, 
                                                                                                                                                                                                                                                                                                                                            AxisState.class, PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                    drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    AxisState result = (AxisState) drawLabelMethod.invoke(axis, 
                                                                                                                                                                                                                                                                                                                                            "Test Label", g2, plotArea, dataArea, 
                                                                                                                                                                                                                                                                                                                                            RectangleEdge.RIGHT, state, plotState);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify cursor was updated correctly
                                                                                                                                                                                                                                                                                                                                    assertNotEquals(400, result.getCursor(), 0.001);
                                                                                                                                                                                                                                                                                                                                    assertTrue(result.getCursor() > 400); // Should move right
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify text was drawn with rotation
                                                                                                                                                                                                                                                                                                                                    verify(g2).setFont(axis.getLabelFont());
                                                                                                                                                                                                                                                                                                                                    verify(g2).setPaint(axis.getLabelPaint());
                                                                                                                                                                                                                                                                                                                                    verify(g2).drawString(anyString(), anyFloat(), anyFloat());
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testDrawLabel_WithPlotStateAndHotspot() throws Exception {
                                                                                                                                                                                                                                                                                                                                    ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                    EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                                                                                                                                                                    PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                                                                                    AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                                                                                                                                                                                                    when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    Axis axis = new Axis("Test Axis") {
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public void configure() {}
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                                RectangleEdge edge, AxisSpace space) { return null; }
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                                Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) { return null; }
                                                                                                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                                                                                                        public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, 
                                                                                                                                                                                                                                                                                                                                                RectangleEdge edge) { return null; }
                                                                                                                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", 
                                                                                                                                                                                                                                                                                                                                            String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                            RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                    drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                    AxisState result = (AxisState) drawLabelMethod.invoke(axis, 
                                                                                                                                                                                                                                                                                                                                            "Test Label", g2, plotArea, dataArea, RectangleEdge.TOP, state, plotState);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify entity was added
                                                                                                                                                                                                                                                                                                                                    verify(entities).add(any(AxisLabelEntity.class));
                                                                                                                                                                                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                                                                                            public void testDrawLabel_NullState() throws Exception {
                                                                                                                                                                                                                                                                                                                                // Create mock objects
                                                                                                                                                                                                                                                                                                                                Axis axis = new Axis("Test Axis") {
                                                                                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                                                                                    public AxisState drawLabel(String label, Graphics2D g2, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                            Rectangle2D dataArea, RectangleEdge edge, AxisState state, 
                                                                                                                                                                                                                                                                                                                                            PlotRenderingInfo plotState) {
                                                                                                                                                                                                                                                                                                                                        if (state == null) {
                                                                                                                                                                                                                                                                                                                                            throw new IllegalArgumentException("Null 'state' argument.");
                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                        return state;
                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                                                                                    public List refreshTicks(Graphics2D g2, AxisState state, 
                                                                                                                                                                                                                                                                                                                                            Rectangle2D dataArea, RectangleEdge edge) {
                                                                                                                                                                                                                                                                                                                                        return new ArrayList();
                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                                                                                    public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                            Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                                                                                                                                                                                                                                                                        return new AxisState(cursor);
                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                                                                                    public void configure() {
                                                                                                                                                                                                                                                                                                                                        // empty implementation for test
                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                                                                                    public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                                            RectangleEdge edge, AxisSpace space) {
                                                                                                                                                                                                                                                                                                                                        return new AxisSpace();
                                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                                                Rectangle2D plotArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                                                                                                Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                                                                                                PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                                                Method method = Axis.class.getDeclaredMethod("drawLabel", String.class, 
                                                                                                                                                                                                                                                                                                                                        Graphics2D.class, Rectangle2D.class, Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                method.invoke(axis, "Label", g2, plotArea, dataArea, 
                                                                                                                                                                                                                                                                                                                                        RectangleEdge.TOP, null, plotState);
                                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                                            public void testDrawLabel_WithLabelAngle() throws Exception {
                                                                                                                                                                                                                                                                                                                                // Import required classes (not shown in test method, but needed in actual file)
                                                                                                                                                                                                                                                                                                                                // Create mock objects
                                                                                                                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                                                PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Create real objects
                                                                                                                                                                                                                                                                                                                                Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                                                                                Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                                                                                AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Create axis instance (using concrete subclass since Axis is abstract)
                                                                                                                                                                                                                                                                                                                                NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Set up axis
                                                                                                                                                                                                                                                                                                                                axis.setLabelAngle(Math.PI / 4); // 45 degrees
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                                                Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                    "drawLabel", 
                                                                                                                                                                                                                                                                                                                                    String.class, 
                                                                                                                                                                                                                                                                                                                                    Graphics2D.class, 
                                                                                                                                                                                                                                                                                                                                    Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                    Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                                    RectangleEdge.class, 
                                                                                                                                                                                                                                                                                                                                    AxisState.class, 
                                                                                                                                                                                                                                                                                                                                    PlotRenderingInfo.class
                                                                                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                                                                                drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Execute test
                                                                                                                                                                                                                                                                                                                                AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                                                                                    axis, 
                                                                                                                                                                                                                                                                                                                                    "Test Label", 
                                                                                                                                                                                                                                                                                                                                    g2, 
                                                                                                                                                                                                                                                                                                                                    plotArea, 
                                                                                                                                                                                                                                                                                                                                    dataArea, 
                                                                                                                                                                                                                                                                                                                                    RectangleEdge.TOP, 
                                                                                                                                                                                                                                                                                                                                    state, 
                                                                                                                                                                                                                                                                                                                                    plotState
                                                                                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                // Verify rotated text was drawn
                                                                                                                                                                                                                                                                                                                                verify(g2).setFont(axis.getLabelFont());
                                                                                                                                                                                                                                                                                                                                verify(g2).setPaint(axis.getLabelPaint());
                                                                                                                                                                                                                                                                                                                                verify(g2).drawString(anyString(), anyFloat(), anyFloat());
                                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                                        public void testDrawLabel_WithLabelInsets() throws Exception {
                                                                                                                                                                                                                                                                                                            // Create a concrete Axis subclass for testing
                                                                                                                                                                                                                                                                                                            class TestAxis extends Axis {
                                                                                                                                                                                                                                                                                                                public TestAxis(String label) {
                                                                                                                                                                                                                                                                                                                    super(label);
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                                                                public void configure() {
                                                                                                                                                                                                                                                                                                                    // Empty implementation for testing
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                                                                public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                        RectangleEdge edge, AxisSpace space) {
                                                                                                                                                                                                                                                                                                                    return null;
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                                                                public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                                                                        Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                                                                                                                                                                                                                                                    return null;
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                                                                public List refreshTicks(Graphics2D g2, AxisState state, 
                                                                                                                                                                                                                                                                                                                        Rectangle2D dataArea, RectangleEdge edge) {
                                                                                                                                                                                                                                                                                                                    return null;
                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            TestAxis axis = new TestAxis("Test Axis");
                                                                                                                                                                                                                                                                                                            axis.setLabelInsets(new org.jfree.chart.util.RectangleInsets(10, 10, 10, 10));
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Create mock objects
                                                                                                                                                                                                                                                                                                            java.awt.image.BufferedImage image = new java.awt.image.BufferedImage(100, 100, 
                                                                                                                                                                                                                                                                                                                    java.awt.image.BufferedImage.TYPE_INT_ARGB);
                                                                                                                                                                                                                                                                                                            Graphics2D g2 = image.createGraphics();
                                                                                                                                                                                                                                                                                                            Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                                                            Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                                                            AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                            PlotRenderingInfo plotState = new PlotRenderingInfo(new ChartRenderingInfo());
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                            Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", 
                                                                                                                                                                                                                                                                                                                    String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                                    RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                            drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                            AxisState result = (AxisState) drawLabelMethod.invoke(axis, 
                                                                                                                                                                                                                                                                                                                    "Test Label", g2, plotArea, dataArea, 
                                                                                                                                                                                                                                                                                                                    RectangleEdge.TOP, state, plotState);
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            // Verify cursor position accounts for insets
                                                                                                                                                                                                                                                                                                            assertNotEquals(state.getCursor(), result.getCursor(), 0.001);
                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                   public void testDrawLabel_PlotStateNullHotspotNotNull_ShouldNotAddEntity() {
                                                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                                                       NumberAxis axis = new NumberAxis("Test Axis"); // Using concrete subclass
                                                                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                       Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                                                       Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                                                       RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                                                                                                                                       AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                       PlotRenderingInfo plotState = null; // Important for the test
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Mock font metrics and other required objects
                                                                                                                                                                                                                                                                                                       FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                                                       when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                                                                       when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Mock TextUtilities behavior
                                                                                                                                                                                                                                                                                                       Rectangle2D labelBounds = new Rectangle2D.Double(0, 0, 50, 10);
                                                                                                                                                                                                                                                                                                       when(TextUtilities.getTextBounds(anyString(), any(Graphics2D.class), any(FontMetrics.class)))
                                                                                                                                                                                                                                                                                                           .thenReturn(labelBounds);
                                                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                       try {
                                                                                                                                                                                                                                                                                                           Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", 
                                                                                                                                                                                                                                                                                                               String.class, Graphics2D.class, Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                               Rectangle2D.class, RectangleEdge.class, AxisState.class, 
                                                                                                                                                                                                                                                                                                               PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                           drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                           AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                                                               axis, "Test Label", g2, plotArea, dataArea, edge, state, plotState);
                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                           // Verify - should not try to add any entities since plotState is null
                                                                                                                                                                                                                                                                                                           assertSame(state, result);
                                                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                                                           // Additional verification - ensure no NPE occurred
                                                                                                                                                                                                                                                                                                           verifyNoInteractions(plotState); // Though plotState is null, this ensures no NPE occurred
                                                                                                                                                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                                                                                                                                                           fail("Failed to invoke drawLabel method via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                                                              public void testDrawLabelEntityAdditionConditions() throws Exception {
                                                                                                                                                                                                                                                                                                  // Setup test objects using concrete subclass
                                                                                                                                                                                                                                                                                                  NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                                                                                                                                                  Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                                  Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                                                  Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                                                  RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                                                                                                                                  AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                                  FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                                                  when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Get protected method via reflection
                                                                                                                                                                                                                                                                                                  Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                      "drawLabel", 
                                                                                                                                                                                                                                                                                                      String.class, 
                                                                                                                                                                                                                                                                                                      Graphics2D.class, 
                                                                                                                                                                                                                                                                                                      Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                      Rectangle2D.class, 
                                                                                                                                                                                                                                                                                                      RectangleEdge.class, 
                                                                                                                                                                                                                                                                                                      AxisState.class, 
                                                                                                                                                                                                                                                                                                      PlotRenderingInfo.class
                                                                                                                                                                                                                                                                                                  );
                                                                                                                                                                                                                                                                                                  drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Case 1: Both plotState and hotspot are non-null (should add entity)
                                                                                                                                                                                                                                                                                                  PlotRenderingInfo plotState1 = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                  ChartRenderingInfo owner1 = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                                                                                  EntityCollection entities1 = mock(EntityCollection.class);
                                                                                                                                                                                                                                                                                                  when(plotState1.getOwner()).thenReturn(owner1);
                                                                                                                                                                                                                                                                                                  when(owner1.getEntityCollection()).thenReturn(entities1);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  drawLabelMethod.invoke(axis, "Label", g2, plotArea, dataArea, edge, state, plotState1);
                                                                                                                                                                                                                                                                                                  verify(entities1, times(1)).add(any(AxisLabelEntity.class));
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Case 2: plotState is null (should not add entity regardless of hotspot)
                                                                                                                                                                                                                                                                                                  drawLabelMethod.invoke(axis, "Label", g2, plotArea, dataArea, edge, state, null);
                                                                                                                                                                                                                                                                                                  // No verification needed since no plotState
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Case 3: hotspot is null (simulated by empty label)
                                                                                                                                                                                                                                                                                                  PlotRenderingInfo plotState3 = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                  ChartRenderingInfo owner3 = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                                                                                  EntityCollection entities3 = mock(EntityCollection.class);
                                                                                                                                                                                                                                                                                                  when(plotState3.getOwner()).thenReturn(owner3);
                                                                                                                                                                                                                                                                                                  when(owner3.getEntityCollection()).thenReturn(entities3);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  drawLabelMethod.invoke(axis, "", g2, plotArea, dataArea, edge, state, plotState3);
                                                                                                                                                                                                                                                                                                  verify(entities3, never()).add(any(AxisLabelEntity.class));
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Case 4: Only plotState exists (hotspot is null via empty label)
                                                                                                                                                                                                                                                                                                  PlotRenderingInfo plotState4 = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                                  drawLabelMethod.invoke(axis, "", g2, plotArea, dataArea, edge, state, plotState4);
                                                                                                                                                                                                                                                                                                  // In original: no entity added (correct)
                                                                                                                                                                                                                                                                                                  // In mutant: might try to add entity (would throw NPE or incorrect behavior)
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                     public void testDrawLabel_AddsEntityWhenPlotStateAndHotspotExist() throws Exception {
                                                                                                                                                                                                                                                                                         // Setup test objects
                                                                                                                                                                                                                                                                                         Axis axis = mock(Axis.class);
                                                                                                                                                                                                                                                                                         Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                         Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                                         Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                                         RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                                                                                                                         AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                         PlotRenderingInfo plotState = new PlotRenderingInfo(new ChartRenderingInfo());
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Mock font metrics and text bounds
                                                                                                                                                                                                                                                                                         FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                                         when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                                                         when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Mock other required methods
                                                                                                                                                                                                                                                                                         when(axis.getLabelFont()).thenReturn(new Font("Arial", Font.PLAIN, 12));
                                                                                                                                                                                                                                                                                         when(axis.getLabelInsets()).thenReturn(new RectangleInsets(5, 5, 5, 5));
                                                                                                                                                                                                                                                                                         when(axis.getLabelPaint()).thenReturn(Color.BLACK);
                                                                                                                                                                                                                                                                                         when(axis.getLabelAngle()).thenReturn(0.0);
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Use reflection to call protected method
                                                                                                                                                                                                                                                                                         Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", 
                                                                                                                                                                                                                                                                                             String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, 
                                                                                                                                                                                                                                                                                             RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                                         drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                         AxisState result = (AxisState) drawLabelMethod.invoke(axis, 
                                                                                                                                                                                                                                                                                             "Test Label", g2, plotArea, dataArea, edge, state, plotState);
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Verify the entity was added (this would fail with the mutant)
                                                                                                                                                                                                                                                                                         EntityCollection entities = plotState.getOwner().getEntityCollection();
                                                                                                                                                                                                                                                                                         assertNotNull("Entity collection should not be null", entities);
                                                                                                                                                                                                                                                                                         assertEquals("Should have exactly one entity", 1, entities.getEntityCount());
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Verify the entity is an AxisLabelEntity
                                                                                                                                                                                                                                                                                         Object entity = entities.getEntity(0);
                                                                                                                                                                                                                                                                                         assertTrue("Entity should be AxisLabelEntity", entity instanceof org.jfree.chart.entity.AxisLabelEntity);
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                         // Verify the state was updated
                                                                                                                                                                                                                                                                                         assertNotSame("Should return modified state", state, result);
                                                                                                                                                                                                                                                                                         assertTrue("Cursor should be updated", result.getCursor() > state.getCursor());
                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                public void testDrawLabelWithNullPlotStateShouldNotAddEntity() throws Exception {
                                                                                                                                                                                                                                                                                    // Setup test objects - use a concrete subclass of Axis
                                                                                                                                                                                                                                                                                    NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                                    AxisState state = new AxisState();
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Mock font metrics for label calculation
                                                                                                                                                                                                                                                                                    FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                                    when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                                                    when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                                                                                                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                        "drawLabel", 
                                                                                                                                                                                                                                                                                        String.class, 
                                                                                                                                                                                                                                                                                        Graphics2D.class, 
                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                        Rectangle2D.class, 
                                                                                                                                                                                                                                                                                        RectangleEdge.class, 
                                                                                                                                                                                                                                                                                        AxisState.class, 
                                                                                                                                                                                                                                                                                        PlotRenderingInfo.class
                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                    drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Test with null plotState but valid label (which creates hotspot)
                                                                                                                                                                                                                                                                                    AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                                        axis, 
                                                                                                                                                                                                                                                                                        "Test Label", 
                                                                                                                                                                                                                                                                                        g2, 
                                                                                                                                                                                                                                                                                        plotArea, 
                                                                                                                                                                                                                                                                                        dataArea, 
                                                                                                                                                                                                                                                                                        RectangleEdge.TOP, 
                                                                                                                                                                                                                                                                                        state, 
                                                                                                                                                                                                                                                                                        null
                                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Verify state was updated (proves method executed)
                                                                                                                                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                                                                                                                                    assertTrue(result.getCursor() > 0);
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // No assertions needed for plotState interaction since it's null,
                                                                                                                                                                                                                                                                                    // but the test will fail if mutant tries to access null plotState
                                                                                                                                                                                                                                                                                    // (would throw NullPointerException)
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Alternative verification: if we had a way to check entity collection,
                                                                                                                                                                                                                                                                                    // we would verify it wasn't modified, but with current setup,
                                                                                                                                                                                                                                                                                    // the main verification is that no exception is thrown
                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                       public void testDrawLabel_AddsEntityWhenPlotStateAndHotspotExist1() {
                                                                                                                                                                                                                                                                           // Setup test objects - use NumberAxis which extends Axis
                                                                                                                                                                                                                                                                           NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                                                                                                                           Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                           Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                           Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                           RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                                                                                                           AxisState state = new AxisState();
                                                                                                                                                                                                                                                                           PlotRenderingInfo plotState = new PlotRenderingInfo(new ChartRenderingInfo());
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Mock necessary behavior
                                                                                                                                                                                                                                                                           FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                           when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                                           when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Set label properties that will create a hotspot
                                                                                                                                                                                                                                                                           axis.setLabel("Test Label");
                                                                                                                                                                                                                                                                           axis.setLabelInsets(new RectangleInsets(5, 5, 5, 5));
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Execute through reflection since drawLabel is protected
                                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                                               Method drawLabel = Axis.class.getDeclaredMethod("drawLabel", String.class, Graphics2D.class, 
                                                                                                                                                                                                                                                                                       Rectangle2D.class, Rectangle2D.class, RectangleEdge.class, AxisState.class, 
                                                                                                                                                                                                                                                                                       PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                               drawLabel.setAccessible(true);
                                                                                                                                                                                                                                                                               AxisState result = (AxisState) drawLabel.invoke(axis, axis.getLabel(), g2, plotArea, 
                                                                                                                                                                                                                                                                                       dataArea, edge, state, plotState);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Verify entity was added
                                                                                                                                                                                                                                                                               EntityCollection entities = plotState.getOwner().getEntityCollection();
                                                                                                                                                                                                                                                                               assertNotNull("Entity collection should exist", entities);
                                                                                                                                                                                                                                                                               assertEquals("Should have one entity", 1, entities.getEntityCount());
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Verify the entity is an AxisLabelEntity
                                                                                                                                                                                                                                                                               Object entity = entities.getEntity(0);
                                                                                                                                                                                                                                                                               assertTrue("Entity should be AxisLabelEntity", 
                                                                                                                                                                                                                                                                                       entity.getClass().getName().endsWith("AxisLabelEntity"));
                                                                                                                                                                                                                                                                               Method getAxis = entity.getClass().getMethod("getAxis");
                                                                                                                                                                                                                                                                               Object labelAxis = getAxis.invoke(entity);
                                                                                                                                                                                                                                                                               assertEquals("Entity should reference the axis", axis, labelAxis);
                                                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                                                               fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                  public void testDrawLabel_AddsEntityWhenPlotStateHasOwner() throws Exception {
                                                                                                                                                                                                                                                                      // Setup test objects - use ValueAxis (a concrete subclass) instead of Axis
                                                                                                                                                                                                                                                                      ValueAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                                                                                                                      Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                                      Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                                      Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                                      RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                                                                                                      AxisState state = new AxisState();
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Mock FontMetrics for text measurement
                                                                                                                                                                                                                                                                      FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                                      when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                                      when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Setup plot state with owner and entity collection
                                                                                                                                                                                                                                                                      PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                      ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                                                      EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                                                                                                                                      when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Use reflection to access protected method
                                                                                                                                                                                                                                                                      Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", 
                                                                                                                                                                                                                                                                          String.class, Graphics2D.class, Rectangle2D.class, 
                                                                                                                                                                                                                                                                          Rectangle2D.class, RectangleEdge.class, AxisState.class, 
                                                                                                                                                                                                                                                                          PlotRenderingInfo.class);
                                                                                                                                                                                                                                                                      drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                      AxisState result = (AxisState) drawLabelMethod.invoke(axis, 
                                                                                                                                                                                                                                                                          "Test Label", g2, plotArea, dataArea, edge, state, plotState);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify entity was added (this would fail with the mutant)
                                                                                                                                                                                                                                                                      verify(entities).add(any(AxisLabelEntity.class));
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Verify state was updated
                                                                                                                                                                                                                                                                      assertNotNull(result);
                                                                                                                                                                                                                                                                      assertTrue(result.getCursor() > state.getCursor());
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                         public void testDrawLabel_AddsEntityWhenOwnerExists() throws Exception {
                                                                                                                                                                                                                                                             // Create a concrete subclass of Axis for testing
                                                                                                                                                                                                                                                             class TestAxis extends Axis {
                                                                                                                                                                                                                                                                 public TestAxis(String label) {
                                                                                                                                                                                                                                                                     super(label);
                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                 public void configure() {}
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                 public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                         RectangleEdge edge, AxisSpace space) {
                                                                                                                                                                                                                                                                     return null;
                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                 public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                         Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                                                                                                                                                                                                     return null;
                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                 public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, 
                                                                                                                                                                                                                                                                         RectangleEdge edge) {
                                                                                                                                                                                                                                                                     return null;
                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Setup test objects
                                                                                                                                                                                                                                                             TestAxis axis = new TestAxis("Test Axis");
                                                                                                                                                                                                                                                             Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                             Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                             Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                             AxisState state = new AxisState();
                                                                                                                                                                                                                                                             PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                             ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                                             EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Configure mocks
                                                                                                                                                                                                                                                             when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                                                                                                                                                                                                                                                             when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                                                                                                                             when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Get the protected method via reflection
                                                                                                                                                                                                                                                             Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "drawLabel", 
                                                                                                                                                                                                                                                                 String.class, 
                                                                                                                                                                                                                                                                 Graphics2D.class, 
                                                                                                                                                                                                                                                                 Rectangle2D.class, 
                                                                                                                                                                                                                                                                 Rectangle2D.class, 
                                                                                                                                                                                                                                                                 RectangleEdge.class, 
                                                                                                                                                                                                                                                                 AxisState.class, 
                                                                                                                                                                                                                                                                 PlotRenderingInfo.class
                                                                                                                                                                                                                                                             );
                                                                                                                                                                                                                                                             drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Call method under test
                                                                                                                                                                                                                                                             AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                                 axis, 
                                                                                                                                                                                                                                                                 "Test Label", 
                                                                                                                                                                                                                                                                 g2, 
                                                                                                                                                                                                                                                                 plotArea, 
                                                                                                                                                                                                                                                                 dataArea, 
                                                                                                                                                                                                                                                                 RectangleEdge.TOP, 
                                                                                                                                                                                                                                                                 state, 
                                                                                                                                                                                                                                                                 plotState
                                                                                                                                                                                                                                                             );
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify entity was added (this would fail with the mutant)
                                                                                                                                                                                                                                                             verify(entities, times(1)).add(any(AxisLabelEntity.class));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify other behavior
                                                                                                                                                                                                                                                             assertNotNull(result);
                                                                                                                                                                                                                                                             assertNotSame(state, result); // Should return a modified state
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                    public void testDrawLabel_NullOwner_ShouldNotAddEntity() throws Exception {
                                                                                                                                                                                                                                                        // Setup test objects - use ValueAxis as concrete implementation
                                                                                                                                                                                                                                                        ValueAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                                                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                        Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                        AxisState state = new AxisState();
                                                                                                                                                                                                                                                        // Create plot state with null owner directly
                                                                                                                                                                                                                                                        PlotRenderingInfo plotState = new PlotRenderingInfo(null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Mock font metrics for label drawing
                                                                                                                                                                                                                                                        FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                        when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                        when(fm.getStringBounds(anyString(), any(Graphics2D.class)))
                                                                                                                                                                                                                                                            .thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Create a mock entity collection to verify interactions
                                                                                                                                                                                                                                                        EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                                                                                        ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                                        when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                                                                                                        Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                                            "drawLabel", 
                                                                                                                                                                                                                                                            String.class, 
                                                                                                                                                                                                                                                            Graphics2D.class, 
                                                                                                                                                                                                                                                            Rectangle2D.class, 
                                                                                                                                                                                                                                                            Rectangle2D.class, 
                                                                                                                                                                                                                                                            RectangleEdge.class, 
                                                                                                                                                                                                                                                            AxisState.class, 
                                                                                                                                                                                                                                                            PlotRenderingInfo.class
                                                                                                                                                                                                                                                        );
                                                                                                                                                                                                                                                        drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Invoke the method
                                                                                                                                                                                                                                                        AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                                            axis, 
                                                                                                                                                                                                                                                            "Label", 
                                                                                                                                                                                                                                                            g2, 
                                                                                                                                                                                                                                                            plotArea, 
                                                                                                                                                                                                                                                            dataArea, 
                                                                                                                                                                                                                                                            RectangleEdge.TOP, 
                                                                                                                                                                                                                                                            state, 
                                                                                                                                                                                                                                                            plotState
                                                                                                                                                                                                                                                        );
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify no entity was added
                                                                                                                                                                                                                                                        verify(entities, never()).add(any(AxisLabelEntity.class));
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Additional verification that the method still returns the state
                                                                                                                                                                                                                                                        assertSame(state, result);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                               public void testDrawLabel_AddsEntityWhenOwnerExists1() throws Exception {
                                                                                                                                                                                                                                                   // Setup test data
                                                                                                                                                                                                                                                   String label = "Test Label";
                                                                                                                                                                                                                                                   Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                   Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                                   RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Create mocks
                                                                                                                                                                                                                                                   Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                   FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                                   when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   AxisState state = new AxisState();
                                                                                                                                                                                                                                                   PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                                   ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                                   EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Setup mock behavior
                                                                                                                                                                                                                                                   when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                                                                                                                   when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Create test instance using anonymous subclass of Axis
                                                                                                                                                                                                                                                   Axis axis = new Axis("Test Axis") {
                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                       public void configure() {}
                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                       public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                               RectangleEdge edge, AxisSpace space) { return null; }
                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                       public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                               Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) { return null; }
                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                       public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, 
                                                                                                                                                                                                                                                               RectangleEdge edge) { return null; }
                                                                                                                                                                                                                                                   };
                                                                                                                                                                                                                                                   axis.setLabelToolTip("Tooltip");
                                                                                                                                                                                                                                                   axis.setLabelURL("http://example.com");
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Use reflection to access protected method
                                                                                                                                                                                                                                                   Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", 
                                                                                                                                                                                                                                                           String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, 
                                                                                                                                                                                                                                                           RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                                                                                                                                                                                                                                                   drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                                   AxisState result = (AxisState) drawLabelMethod.invoke(axis, 
                                                                                                                                                                                                                                                           label, g2, plotArea, dataArea, edge, state, plotState);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Verify entity was added
                                                                                                                                                                                                                                                   verify(entities).add(any(AxisLabelEntity.class));
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Verify state was returned
                                                                                                                                                                                                                                                   assertSame(state, result);
                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                      public void testDrawLabel_AddsEntityToOwnerCollection() throws Exception {
                                                                                                                                                                                                                                          // Setup test data
                                                                                                                                                                                                                                          String label = "Test Label";
                                                                                                                                                                                                                                          Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                          Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                          Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                                                          RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                                                                          AxisState state = new AxisState();
                                                                                                                                                                                                                                          PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Mock font metrics and text bounds
                                                                                                                                                                                                                                          FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                          when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                          when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Setup owner and entity collection
                                                                                                                                                                                                                                          ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                          EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                                                                          when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                                                                                                          when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Create concrete Axis subclass instance and set necessary properties
                                                                                                                                                                                                                                          class TestAxis extends Axis {
                                                                                                                                                                                                                                              public TestAxis(String label) {
                                                                                                                                                                                                                                                  super(label);
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                              public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, RectangleEdge edge) {
                                                                                                                                                                                                                                                  return new ArrayList();
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                              public void configure() {}
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                              public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                           RectangleEdge edge, AxisSpace space) {
                                                                                                                                                                                                                                                  return new AxisSpace();
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                              public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                                   Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                                                                                                                                                                                  return new AxisState();
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                          TestAxis axis = new TestAxis(label);
                                                                                                                                                                                                                                          axis.setLabelToolTip("Tooltip");
                                                                                                                                                                                                                                          axis.setLabelURL("URL");
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Use reflection to access protected method
                                                                                                                                                                                                                                          Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                              "drawLabel", 
                                                                                                                                                                                                                                              String.class, 
                                                                                                                                                                                                                                              Graphics2D.class, 
                                                                                                                                                                                                                                              Rectangle2D.class, 
                                                                                                                                                                                                                                              Rectangle2D.class, 
                                                                                                                                                                                                                                              RectangleEdge.class, 
                                                                                                                                                                                                                                              AxisState.class, 
                                                                                                                                                                                                                                              PlotRenderingInfo.class
                                                                                                                                                                                                                                          );
                                                                                                                                                                                                                                          drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                                          AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                              axis, 
                                                                                                                                                                                                                                              label, 
                                                                                                                                                                                                                                              g2, 
                                                                                                                                                                                                                                              plotArea, 
                                                                                                                                                                                                                                              dataArea, 
                                                                                                                                                                                                                                              edge, 
                                                                                                                                                                                                                                              state, 
                                                                                                                                                                                                                                              plotState
                                                                                                                                                                                                                                          );
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Verify entity was added
                                                                                                                                                                                                                                          verify(entities).add(any(AxisLabelEntity.class));
                                                                                                                                                                                                                                          assertSame(state, result);
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                 public void testDrawLabelWithNullEntities() throws Exception {
                                                                                                                                                                                                                                     // Create a concrete subclass of Axis for testing
                                                                                                                                                                                                                                     class TestAxis extends Axis {
                                                                                                                                                                                                                                         public TestAxis(String label) {
                                                                                                                                                                                                                                             super(label);
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                         public void configure() {}
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                         public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                 RectangleEdge edge, AxisSpace space) {
                                                                                                                                                                                                                                             return null;
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                         public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                                                                                 Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                                                                                                                                                                             return null;
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                         public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, 
                                                                                                                                                                                                                                                 RectangleEdge edge) {
                                                                                                                                                                                                                                             return null;
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Setup test objects
                                                                                                                                                                                                                                     TestAxis axis = new TestAxis("Test Axis");
                                                                                                                                                                                                                                     Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                     Rectangle2D plotArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                     Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                     AxisState state = mock(AxisState.class);
                                                                                                                                                                                                                                     PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                                                                     ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Mock the chain of calls
                                                                                                                                                                                                                                     when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                                                                                                     when(owner.getEntityCollection()).thenReturn(null);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Mock font metrics for text measurement
                                                                                                                                                                                                                                     FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                                                     when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Mock text bounds calculation
                                                                                                                                                                                                                                     Rectangle2D labelBounds = mock(Rectangle2D.class);
                                                                                                                                                                                                                                     when(labelBounds.getCenterX()).thenReturn(0.0);
                                                                                                                                                                                                                                     when(labelBounds.getCenterY()).thenReturn(0.0);
                                                                                                                                                                                                                                     when(labelBounds.getWidth()).thenReturn(100.0);
                                                                                                                                                                                                                                     when(labelBounds.getHeight()).thenReturn(20.0);
                                                                                                                                                                                                                                     when(TextUtilities.getTextBounds(anyString(), any(Graphics2D.class), any(FontMetrics.class)))
                                                                                                                                                                                                                                         .thenReturn(labelBounds);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Use reflection to access protected method
                                                                                                                                                                                                                                     Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                                                         "drawLabel", 
                                                                                                                                                                                                                                         String.class, 
                                                                                                                                                                                                                                         Graphics2D.class, 
                                                                                                                                                                                                                                         Rectangle2D.class, 
                                                                                                                                                                                                                                         Rectangle2D.class, 
                                                                                                                                                                                                                                         RectangleEdge.class, 
                                                                                                                                                                                                                                         AxisState.class, 
                                                                                                                                                                                                                                         PlotRenderingInfo.class
                                                                                                                                                                                                                                     );
                                                                                                                                                                                                                                     drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Test with BOTTOM edge (could be any edge)
                                                                                                                                                                                                                                     AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                                                         axis, 
                                                                                                                                                                                                                                         "Test Label", 
                                                                                                                                                                                                                                         g2, 
                                                                                                                                                                                                                                         plotArea, 
                                                                                                                                                                                                                                         dataArea, 
                                                                                                                                                                                                                                         RectangleEdge.BOTTOM, 
                                                                                                                                                                                                                                         state, 
                                                                                                                                                                                                                                         plotState
                                                                                                                                                                                                                                     );
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Verify the state was returned (basic functionality)
                                                                                                                                                                                                                                     assertSame(state, result);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // The key verification is that no exception was thrown when entities is null
                                                                                                                                                                                                                                     // The mutant would throw NullPointerException here
                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                            public void testDrawLabel_AddsEntityWhenEntitiesExist() throws Exception {
                                                                                                                                                                                                // Setup test data
                                                                                                                                                                                                String label = "Test Label";
                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                                RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                                AxisState state = new AxisState();
                                                                                                                                                                                                
                                                                                                                                                                                                // Setup entities collection and plot state
                                                                                                                                                                                                org.jfree.chart.entity.StandardEntityCollection entities = new org.jfree.chart.entity.StandardEntityCollection();
                                                                                                                                                                                                org.jfree.chart.ChartRenderingInfo owner = new org.jfree.chart.ChartRenderingInfo();
                                                                                                                                                                                                owner.setEntityCollection(entities);
                                                                                                                                                                                                PlotRenderingInfo plotState = new PlotRenderingInfo(owner);
                                                                                                                                                                                                
                                                                                                                                                                                                // Setup axis with label tooltip (to verify entity creation)
                                                                                                                                                                                                ValueAxis axis = new NumberAxis(label);
                                                                                                                                                                                                axis.setLabelToolTip("Tooltip");
                                                                                                                                                                                                
                                                                                                                                                                                                // Mock font metrics and text bounds
                                                                                                                                                                                                FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                                when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                                when(fm.getStringBounds(anyString(), any(Graphics2D.class)))
                                                                                                                                                                                                    .thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                                                                                                                                                
                                                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                                                Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                                    "drawLabel", 
                                                                                                                                                                                                    String.class, 
                                                                                                                                                                                                    Graphics2D.class, 
                                                                                                                                                                                                    Rectangle2D.class, 
                                                                                                                                                                                                    Rectangle2D.class, 
                                                                                                                                                                                                    RectangleEdge.class, 
                                                                                                                                                                                                    AxisState.class, 
                                                                                                                                                                                                    PlotRenderingInfo.class
                                                                                                                                                                                                );
                                                                                                                                                                                                drawLabelMethod.setAccessible(true);
                                                                                                                                                                                                AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                    axis, 
                                                                                                                                                                                                    label, 
                                                                                                                                                                                                    g2, 
                                                                                                                                                                                                    plotArea, 
                                                                                                                                                                                                    dataArea, 
                                                                                                                                                                                                    edge, 
                                                                                                                                                                                                    state, 
                                                                                                                                                                                                    plotState
                                                                                                                                                                                                );
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify entity was added
                                                                                                                                                                                                assertEquals(1, entities.getEntityCount());
                                                                                                                                                                                                org.jfree.chart.entity.ChartEntity entity = entities.getEntity(0);
                                                                                                                                                                                                assertTrue(entity instanceof org.jfree.chart.entity.AxisLabelEntity);
                                                                                                                                                                                                assertEquals("Tooltip", entity.getToolTipText());
                                                                                                                                                                                                assertEquals(axis, ((org.jfree.chart.entity.AxisLabelEntity)entity).getAxis());
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                       public void testDrawLabelReturnsStateInsteadOfThrowingException() throws Exception {
                                                                                                                                                                                           // Setup test objects using a concrete subclass
                                                                                                                                                                                           NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                                           Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                           Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                           Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                           AxisState state = new AxisState();
                                                                                                                                                                                           PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                           
                                                                                                                                                                                           // Mock necessary behavior
                                                                                                                                                                                           FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                           when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                           when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                                                                                                                                                                                           
                                                                                                                                                                                           // Get the protected method via reflection
                                                                                                                                                                                           Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                                               "drawLabel", 
                                                                                                                                                                                               String.class, 
                                                                                                                                                                                               Graphics2D.class, 
                                                                                                                                                                                               Rectangle2D.class, 
                                                                                                                                                                                               Rectangle2D.class, 
                                                                                                                                                                                               RectangleEdge.class, 
                                                                                                                                                                                               AxisState.class, 
                                                                                                                                                                                               PlotRenderingInfo.class
                                                                                                                                                                                           );
                                                                                                                                                                                           drawLabelMethod.setAccessible(true);
                                                                                                                                                                                           
                                                                                                                                                                                           // Test all edge cases to ensure full coverage
                                                                                                                                                                                           RectangleEdge[] edges = {
                                                                                                                                                                                               RectangleEdge.TOP,
                                                                                                                                                                                               RectangleEdge.BOTTOM,
                                                                                                                                                                                               RectangleEdge.LEFT,
                                                                                                                                                                                               RectangleEdge.RIGHT
                                                                                                                                                                                           };
                                                                                                                                                                                           
                                                                                                                                                                                           for (RectangleEdge edge : edges) {
                                                                                                                                                                                               try {
                                                                                                                                                                                                   // Invoke the method using reflection
                                                                                                                                                                                                   AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                       axis, 
                                                                                                                                                                                                       "Test Label", 
                                                                                                                                                                                                       g2, 
                                                                                                                                                                                                       plotArea, 
                                                                                                                                                                                                       dataArea, 
                                                                                                                                                                                                       edge, 
                                                                                                                                                                                                       state, 
                                                                                                                                                                                                       plotState
                                                                                                                                                                                                   );
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the method returns the state object instead of throwing exception
                                                                                                                                                                                                   assertSame("Method should return the state object for edge: " + edge, state, result);
                                                                                                                                                                                               } catch (InvocationTargetException e) {
                                                                                                                                                                                                   if (e.getCause() instanceof RuntimeException) {
                                                                                                                                                                                                       fail("Method should not throw RuntimeException for edge: " + edge);
                                                                                                                                                                                                   } else {
                                                                                                                                                                                                       throw e;
                                                                                                                                                                                                   }
                                                                                                                                                                                               }
                                                                                                                                                                                           }
                                                                                                                                                                                           
                                                                                                                                                                                           // Also test with empty label case
                                                                                                                                                                                           try {
                                                                                                                                                                                               AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                                                   axis, 
                                                                                                                                                                                                   "", 
                                                                                                                                                                                                   g2, 
                                                                                                                                                                                                   plotArea, 
                                                                                                                                                                                                   dataArea, 
                                                                                                                                                                                                   RectangleEdge.TOP, 
                                                                                                                                                                                                   state, 
                                                                                                                                                                                                   plotState
                                                                                                                                                                                               );
                                                                                                                                                                                               assertSame("Method should return state for empty label", state, result);
                                                                                                                                                                                           } catch (InvocationTargetException e) {
                                                                                                                                                                                               if (e.getCause() instanceof RuntimeException) {
                                                                                                                                                                                                   fail("Method should not throw RuntimeException for empty label");
                                                                                                                                                                                               } else {
                                                                                                                                                                                                   throw e;
                                                                                                                                                                                               }
                                                                                                                                                                                           }
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                              public void testDrawLabelEntityAddition() {
                                                                                                                                                                                  // Create a concrete subclass to test the protected method
                                                                                                                                                                                  class TestAxis extends Axis {
                                                                                                                                                                                      public TestAxis(String label) {
                                                                                                                                                                                          super(label);
                                                                                                                                                                                      }
                                                                                                                                                                                      
                                                                                                                                                                                      // Expose the protected method for testing
                                                                                                                                                                                      public AxisState publicDrawLabel(String label, Graphics2D g2, Rectangle2D plotArea, 
                                                                                                                                                                                              Rectangle2D dataArea, RectangleEdge edge, AxisState state, 
                                                                                                                                                                                              PlotRenderingInfo plotState) {
                                                                                                                                                                                          return super.drawLabel(label, g2, plotArea, dataArea, edge, state, plotState);
                                                                                                                                                                                      }
                                                                                                                                                                              
                                                                                                                                                                                      // Implement required abstract methods
                                                                                                                                                                                      @Override
                                                                                                                                                                                      public void configure() {
                                                                                                                                                                                          // Empty implementation for testing
                                                                                                                                                                                      }
                                                                                                                                                                              
                                                                                                                                                                                      @Override
                                                                                                                                                                                      public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                                                                                              RectangleEdge edge, AxisSpace space) {
                                                                                                                                                                                          return new AxisSpace();
                                                                                                                                                                                      }
                                                                                                                                                                              
                                                                                                                                                                                      @Override
                                                                                                                                                                                      public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                                                                                              Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                                                                                                                          return new AxisState();
                                                                                                                                                                                      }
                                                                                                                                                                              
                                                                                                                                                                                      @Override
                                                                                                                                                                                      public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, 
                                                                                                                                                                                              RectangleEdge edge) {
                                                                                                                                                                                          return new ArrayList();
                                                                                                                                                                                      }
                                                                                                                                                                                  }
                                                                                                                                                                                  
                                                                                                                                                                                  // Setup test objects
                                                                                                                                                                                  TestAxis axis = new TestAxis("Test Axis");
                                                                                                                                                                                  Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                  Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                  Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                                  RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                                                  AxisState state = new AxisState();
                                                                                                                                                                                  FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                                  when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                                  
                                                                                                                                                                                  // Case 1: plotState is non-null, hotspot exists (should add entity in original)
                                                                                                                                                                                  PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                                                  ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                                                  EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                  when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                                                  when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                  
                                                                                                                                                                                  AxisState result = axis.publicDrawLabel("Label", g2, plotArea, dataArea, edge, state, plotState);
                                                                                                                                                                                  
                                                                                                                                                                                  // Verify entity was added (should pass for original, fail for mutant)
                                                                                                                                                                                  verify(entities, times(1)).add(any(AxisLabelEntity.class));
                                                                                                                                                                                  
                                                                                                                                                                                  // Case 2: plotState is null, hotspot exists (should not add entity in original)
                                                                                                                                                                                  result = axis.publicDrawLabel("Label", g2, plotArea, dataArea, edge, state, null);
                                                                                                                                                                                  
                                                                                                                                                                                  // Verify no interaction with entities (should pass for original, fail for mutant)
                                                                                                                                                                                  verifyNoMoreInteractions(entities);
                                                                                                                                                                              }

    @Test
                                                                                                                                                                     public void testDrawLabelEntityAddition1() throws Exception {
                                                                                                                                                                         // Setup test objects
                                                                                                                                                                         NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                         Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                         Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                         Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                         AxisState state = new AxisState();
                                                                                                                                                                         FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                         when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                         
                                                                                                                                                                         // Get protected method via reflection
                                                                                                                                                                         Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                             "drawLabel", 
                                                                                                                                                                             String.class, 
                                                                                                                                                                             Graphics2D.class, 
                                                                                                                                                                             Rectangle2D.class, 
                                                                                                                                                                             Rectangle2D.class, 
                                                                                                                                                                             RectangleEdge.class, 
                                                                                                                                                                             AxisState.class, 
                                                                                                                                                                             PlotRenderingInfo.class
                                                                                                                                                                         );
                                                                                                                                                                         drawLabelMethod.setAccessible(true);
                                                                                                                                                                         
                                                                                                                                                                         // Case 1: Both plotState and hotspot are null
                                                                                                                                                                         AxisState result1 = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                             axis, "Label", g2, plotArea, dataArea, 
                                                                                                                                                                             RectangleEdge.TOP, state, null
                                                                                                                                                                         );
                                                                                                                                                                         assertSame(state, result1);
                                                                                                                                                                         
                                                                                                                                                                         // Case 2: plotState is null, hotspot would be non-null
                                                                                                                                                                         AxisState result2 = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                             axis, "Label", g2, plotArea, dataArea, 
                                                                                                                                                                             RectangleEdge.TOP, state, null
                                                                                                                                                                         );
                                                                                                                                                                         assertSame(state, result2);
                                                                                                                                                                         
                                                                                                                                                                         // Case 3: plotState is non-null, but label is empty (hotspot will be null)
                                                                                                                                                                         PlotRenderingInfo plotState3 = new PlotRenderingInfo(null);
                                                                                                                                                                         AxisState result3 = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                             axis, "", g2, plotArea, dataArea, 
                                                                                                                                                                             RectangleEdge.TOP, state, plotState3
                                                                                                                                                                         );
                                                                                                                                                                         assertSame(state, result3);
                                                                                                                                                                         
                                                                                                                                                                         // Case 4: Both plotState and hotspot are non-null
                                                                                                                                                                         PlotRenderingInfo plotState4 = new PlotRenderingInfo(new ChartRenderingInfo());
                                                                                                                                                                         org.jfree.chart.entity.StandardEntityCollection entities = new org.jfree.chart.entity.StandardEntityCollection();
                                                                                                                                                                         plotState4.getOwner().setEntityCollection(entities);
                                                                                                                                                                         AxisState result4 = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                             axis, "Label", g2, plotArea, dataArea, 
                                                                                                                                                                             RectangleEdge.TOP, state, plotState4
                                                                                                                                                                         );
                                                                                                                                                                         assertSame(state, result4);
                                                                                                                                                                         assertEquals(1, entities.getEntityCount());  // Verify entity was added
                                                                                                                                                                     }

    @Test
                                                                                                                                                            public void testDrawLabel_AddsEntityWhenHotspotExists() throws Exception {
                                                                                                                                                                // Setup test objects - use ValueAxis as concrete implementation
                                                                                                                                                                ValueAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                                AxisState state = new AxisState();
                                                                                                                                                                PlotRenderingInfo plotState = new PlotRenderingInfo(new ChartRenderingInfo());
                                                                                                                                                                
                                                                                                                                                                // Mock font metrics and text bounds
                                                                                                                                                                FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                                when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                                when(fm.getStringBounds(anyString(), any(Graphics2D.class)))
                                                                                                                                                                    .thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                                                                                                                
                                                                                                                                                                // Mock axis properties
                                                                                                                                                                axis.setLabelFont(new Font("Arial", Font.PLAIN, 12));
                                                                                                                                                                axis.setLabelInsets(new RectangleInsets(5, 5, 5, 5));
                                                                                                                                                                axis.setLabelPaint(Color.BLACK);
                                                                                                                                                                axis.setLabelAngle(0.0);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                                    "drawLabel", 
                                                                                                                                                                    String.class, 
                                                                                                                                                                    Graphics2D.class, 
                                                                                                                                                                    Rectangle2D.class, 
                                                                                                                                                                    Rectangle2D.class, 
                                                                                                                                                                    RectangleEdge.class, 
                                                                                                                                                                    AxisState.class, 
                                                                                                                                                                    PlotRenderingInfo.class
                                                                                                                                                                );
                                                                                                                                                                drawLabelMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                                    axis, 
                                                                                                                                                                    "Test Label", 
                                                                                                                                                                    g2, 
                                                                                                                                                                    plotArea, 
                                                                                                                                                                    dataArea, 
                                                                                                                                                                    RectangleEdge.TOP, 
                                                                                                                                                                    state, 
                                                                                                                                                                    plotState
                                                                                                                                                                );
                                                                                                                                                                
                                                                                                                                                                // Verify entity was added
                                                                                                                                                                EntityCollection entities = plotState.getOwner().getEntityCollection();
                                                                                                                                                                assertNotNull("Entity collection should exist", entities);
                                                                                                                                                                assertEquals("Should have one entity", 1, entities.getEntityCount());
                                                                                                                                                                
                                                                                                                                                                // Verify the entity is for our axis label
                                                                                                                                                                org.jfree.chart.entity.ChartEntity entity = entities.getEntity(0);
                                                                                                                                                                assertTrue("Entity should be AxisLabelEntity", 
                                                                                                                                                                        entity instanceof org.jfree.chart.entity.AxisLabelEntity);
                                                                                                                                                                assertEquals("Entity should be for our axis", 
                                                                                                                                                                        axis, ((org.jfree.chart.entity.AxisLabelEntity)entity).getAxis());
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testDrawLabel_ShouldNotAddEntityWhenPlotStateIsNull() throws Exception {
                                                                                                                                                           // Setup
                                                                                                                                                           ValueAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                           Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                           Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                           Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                           AxisState state = new AxisState();
                                                                                                                                                           FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                           when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                           
                                                                                                                                                           // Get protected method via reflection
                                                                                                                                                           Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                               "drawLabel", 
                                                                                                                                                               String.class, 
                                                                                                                                                               Graphics2D.class, 
                                                                                                                                                               Rectangle2D.class, 
                                                                                                                                                               Rectangle2D.class, 
                                                                                                                                                               RectangleEdge.class, 
                                                                                                                                                               AxisState.class, 
                                                                                                                                                               PlotRenderingInfo.class
                                                                                                                                                           );
                                                                                                                                                           drawLabelMethod.setAccessible(true);
                                                                                                                                                           
                                                                                                                                                           // Test with null plotState (should not add entities)
                                                                                                                                                           AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                               axis, 
                                                                                                                                                               "Label", 
                                                                                                                                                               g2, 
                                                                                                                                                               plotArea, 
                                                                                                                                                               dataArea, 
                                                                                                                                                               RectangleEdge.TOP, 
                                                                                                                                                               state, 
                                                                                                                                                               null
                                                                                                                                                           );
                                                                                                                                                           
                                                                                                                                                           // Verify no NPE occurred and state was returned
                                                                                                                                                           assertNotNull(result);
                                                                                                                                                           assertEquals(state, result);
                                                                                                                                                           
                                                                                                                                                           // Test with null hotspot (simulate by making label empty)
                                                                                                                                                           PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                           ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                           EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                           when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                           when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                           
                                                                                                                                                           result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                               axis, 
                                                                                                                                                               "", 
                                                                                                                                                               g2, 
                                                                                                                                                               plotArea, 
                                                                                                                                                               dataArea, 
                                                                                                                                                               RectangleEdge.TOP, 
                                                                                                                                                               state, 
                                                                                                                                                               plotState
                                                                                                                                                           );
                                                                                                                                                           
                                                                                                                                                           // Verify no entities were added
                                                                                                                                                           verify(entities, never()).add(any());
                                                                                                                                                           assertNotNull(result);
                                                                                                                                                           assertEquals(state, result);
                                                                                                                                                       }

    @Test
                                                                                                                                                  public void testDrawLabel_AddsEntityWhenPlotStateAndHotspotExist2() throws Exception {
                                                                                                                                                      // Setup test objects - using NumberAxis as a concrete subclass
                                                                                                                                                      NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                      Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                      Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                      Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                      AxisState state = new AxisState();
                                                                                                                                                      PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                      ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                      EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                      
                                                                                                                                                      // Mock the behavior
                                                                                                                                                      when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                                                                                                                                                      when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                      when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access protected method
                                                                                                                                                      Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                          "drawLabel", 
                                                                                                                                                          String.class, 
                                                                                                                                                          Graphics2D.class, 
                                                                                                                                                          Rectangle2D.class, 
                                                                                                                                                          Rectangle2D.class, 
                                                                                                                                                          RectangleEdge.class, 
                                                                                                                                                          AxisState.class, 
                                                                                                                                                          PlotRenderingInfo.class
                                                                                                                                                      );
                                                                                                                                                      drawLabelMethod.setAccessible(true);
                                                                                                                                                      
                                                                                                                                                      // Call the method via reflection
                                                                                                                                                      AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                          axis, 
                                                                                                                                                          "Test Label", 
                                                                                                                                                          g2, 
                                                                                                                                                          plotArea, 
                                                                                                                                                          dataArea, 
                                                                                                                                                          RectangleEdge.TOP, 
                                                                                                                                                          state, 
                                                                                                                                                          plotState
                                                                                                                                                      );
                                                                                                                                                      
                                                                                                                                                      // Verify the entity was added (this will fail for the mutant)
                                                                                                                                                      verify(entities, times(1)).add(any(AxisLabelEntity.class));
                                                                                                                                                      
                                                                                                                                                      // Verify other state changes
                                                                                                                                                      assertNotNull(result);
                                                                                                                                                      assertNotSame(state, result); // Should return a modified state
                                                                                                                                                  }

    @Test
                                                                                                                                             public void testDrawLabelWithPlotStateAddsEntity() throws Exception {
                                                                                                                                                 // Setup test objects - use a concrete subclass of Axis
                                                                                                                                                 NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                                 Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                 Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                 Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                                 RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                                                 AxisState state = new AxisState();
                                                                                                                                                 state.setCursor(50);
                                                                                                                                                 
                                                                                                                                                 // Setup font metrics mock
                                                                                                                                                 FontMetrics fm = mock(FontMetrics.class);
                                                                                                                                                 when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                                                 when(fm.getStringBounds(anyString(), any(Graphics2D.class)))
                                                                                                                                                     .thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                                                                                                                                                 
                                                                                                                                                 // Setup plot state with owner and entity collection
                                                                                                                                                 PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                                 ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                                 EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                 when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                                 when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                                 
                                                                                                                                                 // Use reflection to access protected drawLabel method
                                                                                                                                                 Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                     "drawLabel", 
                                                                                                                                                     String.class, 
                                                                                                                                                     Graphics2D.class, 
                                                                                                                                                     Rectangle2D.class, 
                                                                                                                                                     Rectangle2D.class, 
                                                                                                                                                     RectangleEdge.class, 
                                                                                                                                                     AxisState.class, 
                                                                                                                                                     PlotRenderingInfo.class
                                                                                                                                                 );
                                                                                                                                                 drawLabelMethod.setAccessible(true);
                                                                                                                                                 drawLabelMethod.invoke(axis, "Test Label", g2, plotArea, dataArea, edge, state, plotState);
                                                                                                                                                 
                                                                                                                                                 // Verify entity was added
                                                                                                                                                 verify(entities).add(any(AxisLabelEntity.class));
                                                                                                                                                 
                                                                                                                                                 // Additional verification that the state was updated
                                                                                                                                                 assertTrue(state.getCursor() > 50); // Verify cursor moved up
                                                                                                                                             }

    @Test
                                                                                                                                        public void testDrawLabel_AddsEntityWhenOwnerExists2() throws Exception {
                                                                                                                                            // Setup test objects - use a concrete subclass
                                                                                                                                            NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                            Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                            Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                            AxisState state = new AxisState();
                                                                                                                                            PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                            ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                                            EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                            
                                                                                                                                            // Setup mock behavior
                                                                                                                                            when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                                                                                                                                            when(plotState.getOwner()).thenReturn(owner);
                                                                                                                                            when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                                            
                                                                                                                                            // Use reflection to access protected method
                                                                                                                                            Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                                "drawLabel", 
                                                                                                                                                String.class, 
                                                                                                                                                Graphics2D.class, 
                                                                                                                                                Rectangle2D.class, 
                                                                                                                                                Rectangle2D.class, 
                                                                                                                                                RectangleEdge.class, 
                                                                                                                                                AxisState.class, 
                                                                                                                                                PlotRenderingInfo.class
                                                                                                                                            );
                                                                                                                                            drawLabelMethod.setAccessible(true);
                                                                                                                                            
                                                                                                                                            // Execute method
                                                                                                                                            AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                                axis, 
                                                                                                                                                "Test Label", 
                                                                                                                                                g2, 
                                                                                                                                                plotArea, 
                                                                                                                                                dataArea, 
                                                                                                                                                RectangleEdge.TOP, 
                                                                                                                                                state, 
                                                                                                                                                plotState
                                                                                                                                            );
                                                                                                                                            
                                                                                                                                            // Verify entity was added (original behavior)
                                                                                                                                            verify(entities).add(any(AxisLabelEntity.class));
                                                                                                                                            
                                                                                                                                            // Verify state was updated
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertNotSame(state, result); // Should return a new state
                                                                                                                                        }

    @Test
                                                                                                                               public void testDrawLabel_OwnerNull_ShouldNotAddEntity() throws Exception {
                                                                                                                                   // Setup test objects - using NumberAxis as a concrete implementation of Axis
                                                                                                                                   NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                                   Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                   Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                   Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                                   AxisState state = new AxisState();
                                                                                                                                   PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                                   
                                                                                                                                   // Setup mock behavior
                                                                                                                                   when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                                                                                                                                   when(plotState.getOwner()).thenReturn(null); // Owner is null
                                                                                                                                   
                                                                                                                                   // Use reflection to access protected method
                                                                                                                                   Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                                       "drawLabel", 
                                                                                                                                       String.class, 
                                                                                                                                       Graphics2D.class, 
                                                                                                                                       Rectangle2D.class, 
                                                                                                                                       Rectangle2D.class, 
                                                                                                                                       RectangleEdge.class, 
                                                                                                                                       AxisState.class, 
                                                                                                                                       PlotRenderingInfo.class
                                                                                                                                   );
                                                                                                                                   drawLabelMethod.setAccessible(true);
                                                                                                                                   
                                                                                                                                   // Call the method
                                                                                                                                   AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                                       axis, 
                                                                                                                                       "Label", 
                                                                                                                                       g2, 
                                                                                                                                       plotArea, 
                                                                                                                                       dataArea, 
                                                                                                                                       RectangleEdge.TOP, 
                                                                                                                                       state, 
                                                                                                                                       plotState
                                                                                                                                   );
                                                                                                                                   
                                                                                                                                   // Verify no entity was added
                                                                                                                                   verify(plotState, never()).getOwner();
                                                                                                                                   
                                                                                                                                   // Additional assertions
                                                                                                                                   assertNotNull(result);
                                                                                                                                   assertEquals(state, result);
                                                                                                                               }

    @Test
                                                                                                                      public void testDrawLabel_AddsLabelEntityWhenOwnerExists() throws Exception {
                                                                                                                          // Setup test objects
                                                                                                                          ValueAxis axis = new NumberAxis("Test Axis");
                                                                                                                          Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                          Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                          Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                          AxisState state = new AxisState();
                                                                                                                          PlotRenderingInfo plotState = new PlotRenderingInfo(null);
                                                                                                                          ChartRenderingInfo owner = new ChartRenderingInfo();
                                                                                                                          org.jfree.chart.entity.StandardEntityCollection entities = new org.jfree.chart.entity.StandardEntityCollection();
                                                                                                                          
                                                                                                                          // Configure mocks and test objects
                                                                                                                          when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                                                                                                                          owner.setEntityCollection(entities);
                                                                                                                          // Use reflection to set owner since setOwner is not accessible
                                                                                                                          Field ownerField = PlotRenderingInfo.class.getDeclaredField("owner");
                                                                                                                          ownerField.setAccessible(true);
                                                                                                                          ownerField.set(plotState, owner);
                                                                                                                          
                                                                                                                          // Set label properties
                                                                                                                          axis.setLabel("Test Label");
                                                                                                                          axis.setLabelToolTip("Tooltip");
                                                                                                                          axis.setLabelURL("http://example.com");
                                                                                                                          
                                                                                                                          // Use reflection to access protected drawLabel method
                                                                                                                          Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                              "drawLabel", 
                                                                                                                              String.class, 
                                                                                                                              Graphics2D.class, 
                                                                                                                              Rectangle2D.class, 
                                                                                                                              Rectangle2D.class, 
                                                                                                                              RectangleEdge.class, 
                                                                                                                              AxisState.class, 
                                                                                                                              PlotRenderingInfo.class
                                                                                                                          );
                                                                                                                          drawLabelMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // Execute method
                                                                                                                          AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                              axis, 
                                                                                                                              axis.getLabel(), 
                                                                                                                              g2, 
                                                                                                                              plotArea, 
                                                                                                                              dataArea, 
                                                                                                                              RectangleEdge.TOP, 
                                                                                                                              state, 
                                                                                                                              plotState
                                                                                                                          );
                                                                                                                          
                                                                                                                          // Verify entity was added
                                                                                                                          assertEquals(1, entities.getEntityCount());
                                                                                                                          org.jfree.chart.entity.ChartEntity entity = entities.getEntity(0);
                                                                                                                          assertTrue(entity instanceof org.jfree.chart.entity.AxisLabelEntity);
                                                                                                                          org.jfree.chart.entity.AxisLabelEntity labelEntity = (org.jfree.chart.entity.AxisLabelEntity) entity;
                                                                                                                          assertEquals(axis, labelEntity.getAxis());
                                                                                                                          assertEquals("Tooltip", labelEntity.getToolTipText());
                                                                                                                          assertEquals("http://example.com", labelEntity.getURLText());
                                                                                                                      }

    @Test
                                                                                                                 public void testDrawLabel_AddsEntityToCollectionWhenConditionsMet() throws Exception {
                                                                                                                     // Setup test objects - use a concrete subclass of Axis
                                                                                                                     NumberAxis axis = new NumberAxis("Test Axis");
                                                                                                                     Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                     Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                     Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                                     RectangleEdge edge = RectangleEdge.TOP;
                                                                                                                     AxisState state = new AxisState();
                                                                                                                     
                                                                                                                     // Setup FontMetrics mock
                                                                                                                     FontMetrics fm = mock(FontMetrics.class);
                                                                                                                     when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                                     
                                                                                                                     // Setup plot state with owner and entity collection
                                                                                                                     PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                                     ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                                     EntityCollection entities = mock(EntityCollection.class);
                                                                                                                     when(plotState.getOwner()).thenReturn(owner);
                                                                                                                     when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                                     
                                                                                                                     // Use reflection to access protected method
                                                                                                                     Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                         "drawLabel", 
                                                                                                                         String.class, 
                                                                                                                         Graphics2D.class, 
                                                                                                                         Rectangle2D.class, 
                                                                                                                         Rectangle2D.class, 
                                                                                                                         RectangleEdge.class, 
                                                                                                                         AxisState.class, 
                                                                                                                         PlotRenderingInfo.class
                                                                                                                     );
                                                                                                                     drawLabelMethod.setAccessible(true);
                                                                                                                     
                                                                                                                     // Call method under test
                                                                                                                     AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                         axis, 
                                                                                                                         "Test Label", 
                                                                                                                         g2, 
                                                                                                                         plotArea, 
                                                                                                                         dataArea, 
                                                                                                                         edge, 
                                                                                                                         state, 
                                                                                                                         plotState
                                                                                                                     );
                                                                                                                     
                                                                                                                     // Verify entity was added to collection
                                                                                                                     verify(entities).add(any(AxisLabelEntity.class));
                                                                                                                     
                                                                                                                     // Verify state was returned
                                                                                                                     assertSame(state, result);
                                                                                                                 }

    @Test
                                                                                                        public void testDrawLabel_AddsEntityWhenEntitiesCollectionExists() throws Exception {
                                                                                                            // Setup test data
                                                                                                            String label = "Test Label";
                                                                                                            Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                            Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                            RectangleEdge edge = RectangleEdge.TOP;
                                                                                                            
                                                                                                            // Create axis state
                                                                                                            AxisState state = new AxisState();
                                                                                                            state.setCursor(50);
                                                                                                            
                                                                                                            // Mock dependencies
                                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                                            FontMetrics fm = mock(FontMetrics.class);
                                                                                                            when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                            
                                                                                                            // Setup plot state with non-null entities collection
                                                                                                            PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                            ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                            EntityCollection entities = mock(EntityCollection.class);
                                                                                                            when(plotState.getOwner()).thenReturn(owner);
                                                                                                            when(owner.getEntityCollection()).thenReturn(entities);
                                                                                                            
                                                                                                            // Create concrete Axis subclass instance with all required methods implemented
                                                                                                            class TestAxis extends Axis {
                                                                                                                public TestAxis(String label) {
                                                                                                                    super(label);
                                                                                                                }
                                                                                                                
                                                                                                                @Override
                                                                                                                public void configure() {
                                                                                                                    // Empty implementation for testing
                                                                                                                }
                                                                                                                
                                                                                                                @Override
                                                                                                                public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                                                        RectangleEdge edge, AxisSpace space) {
                                                                                                                    return new AxisSpace();
                                                                                                                }
                                                                                                                
                                                                                                                @Override
                                                                                                                public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                                                        Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                                                    return new AxisState();
                                                                                                                }
                                                                                                                
                                                                                                                @Override
                                                                                                                public List refreshTicks(Graphics2D g2, AxisState state, 
                                                                                                                        Rectangle2D dataArea, RectangleEdge edge) {
                                                                                                                    return new ArrayList();
                                                                                                                }
                                                                                                            }
                                                                                                            TestAxis axis = new TestAxis(label);
                                                                                                            axis.setLabelToolTip("Tooltip");
                                                                                                            axis.setLabelURL("http://example.com");
                                                                                                            
                                                                                                            // Use reflection to access protected drawLabel method
                                                                                                            Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                                "drawLabel", 
                                                                                                                String.class, 
                                                                                                                Graphics2D.class, 
                                                                                                                Rectangle2D.class, 
                                                                                                                Rectangle2D.class, 
                                                                                                                RectangleEdge.class, 
                                                                                                                AxisState.class, 
                                                                                                                PlotRenderingInfo.class
                                                                                                            );
                                                                                                            drawLabelMethod.setAccessible(true);
                                                                                                            
                                                                                                            // Execute method
                                                                                                            AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                                axis, 
                                                                                                                label, 
                                                                                                                g2, 
                                                                                                                plotArea, 
                                                                                                                dataArea, 
                                                                                                                edge, 
                                                                                                                state, 
                                                                                                                plotState
                                                                                                            );
                                                                                                            
                                                                                                            // Verify entity was added
                                                                                                            verify(entities).add(any(AxisLabelEntity.class));
                                                                                                            
                                                                                                            // Additional assertions
                                                                                                            assertSame(state, result);
                                                                                                            assertTrue(state.getCursor() > 50); // Verify cursor moved
                                                                                                        }

    @Test
                                                                                               public void testDrawLabelWithNullEntityCollection() throws Exception {
                                                                                                   // Setup test objects - use concrete subclass ValueAxis
                                                                                                   ValueAxis axis = new NumberAxis("Test Axis");
                                                                                                   Graphics2D g2 = mock(Graphics2D.class);
                                                                                                   Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                   Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                                   AxisState state = new AxisState();
                                                                                                   PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                                   ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                                   
                                                                                                   // Mock behavior - return owner but null entity collection
                                                                                                   when(plotState.getOwner()).thenReturn(owner);
                                                                                                   when(owner.getEntityCollection()).thenReturn(null);
                                                                                                   
                                                                                                   // Mock font metrics for label drawing
                                                                                                   FontMetrics fm = mock(FontMetrics.class);
                                                                                                   when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                                   when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                                                                                                   
                                                                                                   // Get protected method via reflection
                                                                                                   Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                       "drawLabel", 
                                                                                                       String.class, 
                                                                                                       Graphics2D.class, 
                                                                                                       Rectangle2D.class, 
                                                                                                       Rectangle2D.class, 
                                                                                                       RectangleEdge.class, 
                                                                                                       AxisState.class, 
                                                                                                       PlotRenderingInfo.class
                                                                                                   );
                                                                                                   drawLabelMethod.setAccessible(true);
                                                                                                   
                                                                                                   // Test all edge cases with this setup
                                                                                                   for (RectangleEdge edge : new RectangleEdge[] {
                                                                                                       RectangleEdge.TOP, 
                                                                                                       RectangleEdge.BOTTOM, 
                                                                                                       RectangleEdge.LEFT, 
                                                                                                       RectangleEdge.RIGHT
                                                                                                   }) {
                                                                                                       try {
                                                                                                           // Call method via reflection
                                                                                                           AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                               axis, 
                                                                                                               "Test Label", 
                                                                                                               g2, 
                                                                                                               plotArea, 
                                                                                                               dataArea, 
                                                                                                               edge, 
                                                                                                               state, 
                                                                                                               plotState
                                                                                                           );
                                                                                                           assertNotNull(result);
                                                                                                       } catch (InvocationTargetException e) {
                                                                                                           if (e.getCause() instanceof NullPointerException) {
                                                                                                               fail("Should not throw NPE when entity collection is null");
                                                                                                           }
                                                                                                           throw e;
                                                                                                       }
                                                                                                   }
                                                                                               }

    @Test
                                                                                          public void testDrawLabel_AddsEntityWhenEntitiesExist1() throws Exception {
                                                                                              // Setup test objects - use ValueAxis as concrete implementation
                                                                                              ValueAxis axis = new NumberAxis("Test Axis");
                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                              Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                              Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                              AxisState state = new AxisState();
                                                                                              PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                              ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                                                              EntityCollection entities = mock(EntityCollection.class);
                                                                                              
                                                                                              // Configure mocks
                                                                                              when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                                                                                              when(plotState.getOwner()).thenReturn(owner);
                                                                                              when(owner.getEntityCollection()).thenReturn(entities);
                                                                                              
                                                                                              // Set label properties that will trigger entity creation
                                                                                              axis.setLabelToolTip("Tooltip");
                                                                                              axis.setLabelURL("URL");
                                                                                              
                                                                                              // Get protected method via reflection
                                                                                              Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                                  "drawLabel", 
                                                                                                  String.class, 
                                                                                                  Graphics2D.class, 
                                                                                                  Rectangle2D.class, 
                                                                                                  Rectangle2D.class, 
                                                                                                  RectangleEdge.class, 
                                                                                                  AxisState.class, 
                                                                                                  PlotRenderingInfo.class
                                                                                              );
                                                                                              drawLabelMethod.setAccessible(true);
                                                                                              
                                                                                              // Execute method using reflection
                                                                                              AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                                  axis, 
                                                                                                  "Test Label", 
                                                                                                  g2, 
                                                                                                  plotArea, 
                                                                                                  dataArea, 
                                                                                                  RectangleEdge.TOP, 
                                                                                                  state, 
                                                                                                  plotState
                                                                                              );
                                                                                              
                                                                                              // Verify entity was added
                                                                                              verify(entities).add(any(AxisLabelEntity.class));
                                                                                              
                                                                                              // Additional assertions
                                                                                              assertNotNull(result);
                                                                                              assertNotSame(state, result); // Should return modified state
                                                                                          }

    @Test
                                                                                     public void testDrawLabelReturnsNonNullState() throws Exception {
                                                                                         // Setup test objects - using ValueAxis as concrete implementation
                                                                                         ValueAxis axis = new NumberAxis("Test Axis");
                                                                                         Graphics2D g2 = mock(Graphics2D.class);
                                                                                         Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                         Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                         AxisState state = new AxisState();
                                                                                         PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                                         
                                                                                         // Mock font metrics and text bounds
                                                                                         FontMetrics fm = mock(FontMetrics.class);
                                                                                         when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                         when(TextUtilities.getTextBounds(anyString(), any(Graphics2D.class), any(FontMetrics.class)))
                                                                                             .thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                                                                                         
                                                                                         // Get protected method via reflection
                                                                                         Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                             "drawLabel", 
                                                                                             String.class, 
                                                                                             Graphics2D.class, 
                                                                                             Rectangle2D.class, 
                                                                                             Rectangle2D.class, 
                                                                                             RectangleEdge.class, 
                                                                                             AxisState.class, 
                                                                                             PlotRenderingInfo.class
                                                                                         );
                                                                                         drawLabelMethod.setAccessible(true);
                                                                                         
                                                                                         // Test with non-empty label and different edges
                                                                                         AxisState result1 = (AxisState) drawLabelMethod.invoke(
                                                                                             axis, "Label", g2, plotArea, dataArea, 
                                                                                             RectangleEdge.TOP, state, plotState
                                                                                         );
                                                                                         assertNotNull("Should return non-null state for TOP edge", result1);
                                                                                         
                                                                                         AxisState result2 = (AxisState) drawLabelMethod.invoke(
                                                                                             axis, "Label", g2, plotArea, dataArea, 
                                                                                             RectangleEdge.BOTTOM, state, plotState
                                                                                         );
                                                                                         assertNotNull("Should return non-null state for BOTTOM edge", result2);
                                                                                         
                                                                                         AxisState result3 = (AxisState) drawLabelMethod.invoke(
                                                                                             axis, "Label", g2, plotArea, dataArea, 
                                                                                             RectangleEdge.LEFT, state, plotState
                                                                                         );
                                                                                         assertNotNull("Should return non-null state for LEFT edge", result3);
                                                                                         
                                                                                         AxisState result4 = (AxisState) drawLabelMethod.invoke(
                                                                                             axis, "Label", g2, plotArea, dataArea, 
                                                                                             RectangleEdge.RIGHT, state, plotState
                                                                                         );
                                                                                         assertNotNull("Should return non-null state for RIGHT edge", result4);
                                                                                         
                                                                                         // Test with empty label
                                                                                         AxisState result5 = (AxisState) drawLabelMethod.invoke(
                                                                                             axis, "", g2, plotArea, dataArea, 
                                                                                             RectangleEdge.TOP, state, plotState
                                                                                         );
                                                                                         assertNotNull("Should return non-null state for empty label", result5);
                                                                                         
                                                                                         // Test with null label
                                                                                         AxisState result6 = (AxisState) drawLabelMethod.invoke(
                                                                                             axis, null, g2, plotArea, dataArea, 
                                                                                             RectangleEdge.TOP, state, plotState
                                                                                         );
                                                                                         assertNotNull("Should return non-null state for null label", result6);
                                                                                     }

    @Test
                                                                                public void testDrawLabel_PlotStateNullHotspotNotNull_ShouldNotAddEntity1() throws Exception {
                                                                                    // Setup test objects - using NumberAxis as concrete implementation
                                                                                    NumberAxis axis = new NumberAxis("Test Axis");
                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                                    RectangleEdge edge = RectangleEdge.TOP;
                                                                                    AxisState state = new AxisState();
                                                                                    
                                                                                    // Mock font metrics and text bounds
                                                                                    FontMetrics fm = mock(FontMetrics.class);
                                                                                    when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                                    when(fm.getStringBounds(anyString(), any(Graphics2D.class)))
                                                                                        .thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                                    
                                                                                    // Set up label that will generate a hotspot
                                                                                    String label = "Test Label";
                                                                                    
                                                                                    // Use reflection to access protected drawLabel method
                                                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                                        "drawLabel", 
                                                                                        String.class, 
                                                                                        Graphics2D.class, 
                                                                                        Rectangle2D.class, 
                                                                                        Rectangle2D.class, 
                                                                                        RectangleEdge.class, 
                                                                                        AxisState.class, 
                                                                                        PlotRenderingInfo.class
                                                                                    );
                                                                                    drawLabelMethod.setAccessible(true);
                                                                                    
                                                                                    // Execute with null plotState (should not add entity)
                                                                                    AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                                        axis, 
                                                                                        label, 
                                                                                        g2, 
                                                                                        plotArea, 
                                                                                        dataArea, 
                                                                                        edge, 
                                                                                        state, 
                                                                                        null
                                                                                    );
                                                                                    
                                                                                    // Verify no entity was added (original behavior)
                                                                                    // Since plotState is null, we can't verify through owner/entities,
                                                                                    // but the test will fail if the mutant tries to add to null plotState
                                                                                    
                                                                                    // Additional verification that state was updated correctly
                                                                                    assertNotNull(result);
                                                                                    assertTrue(result.getCursor() > 0); // Verify cursor moved
                                                                                }

    @Test
                                                                       public void testDrawLabelEntityAdditionWithNullHotspot() throws Exception {
                                                                           // Create a concrete subclass of Axis for testing
                                                                           class TestAxis extends Axis {
                                                                               public TestAxis(String label) {
                                                                                   super(label);
                                                                               }
                                                                               
                                                                               @Override
                                                                               public void configure() {}
                                                                               
                                                                               @Override
                                                                               public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                                                       RectangleEdge edge, AxisSpace space) {
                                                                                   return null;
                                                                               }
                                                                               
                                                                               @Override
                                                                               public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                                                       Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                                   return null;
                                                                               }
                                                                               
                                                                               @Override
                                                                               public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, 
                                                                                       RectangleEdge edge) {
                                                                                   return null;
                                                                               }
                                                                           }
                                                                           
                                                                           // Setup test objects
                                                                           TestAxis axis = new TestAxis("Test Axis");
                                                                           Graphics2D g2 = mock(Graphics2D.class);
                                                                           Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                           Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                           RectangleEdge edge = RectangleEdge.TOP;
                                                                           AxisState state = new AxisState();
                                                                           PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                                           
                                                                           // Mock the necessary interactions
                                                                           when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                                                                           ChartRenderingInfo chartInfo = mock(ChartRenderingInfo.class);
                                                                           when(plotState.getOwner()).thenReturn(chartInfo);
                                                                           EntityCollection entities = mock(EntityCollection.class);
                                                                           when(chartInfo.getEntityCollection()).thenReturn(entities);
                                                                           
                                                                           // Use reflection to call the protected method
                                                                           Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", 
                                                                               String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, 
                                                                               RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                                                                           drawLabelMethod.setAccessible(true);
                                                                           AxisState result = (AxisState) drawLabelMethod.invoke(axis, 
                                                                               "", g2, plotArea, dataArea, edge, state, plotState);
                                                                           
                                                                           // Verify no entity was added (mutant would try to add)
                                                                           verify(entities, never()).add(any(AxisLabelEntity.class));
                                                                           
                                                                           // Also verify the state was returned properly
                                                                           assertSame(state, result);
                                                                       }

    @Test
                                                              public void testDrawLabel_AddsEntityWhenPlotStateAndHotspotExist3() {
                                                                  // Setup test objects - use ValueAxis as concrete implementation
                                                                  ValueAxis axis = new NumberAxis("Test Axis");
                                                                  Graphics2D g2 = mock(Graphics2D.class);
                                                                  Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                  Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                                  RectangleEdge edge = RectangleEdge.TOP;
                                                                  AxisState state = new AxisState();
                                                                  PlotRenderingInfo plotState = new PlotRenderingInfo(new ChartRenderingInfo());
                                                                  
                                                                  // Mock font metrics and text bounds
                                                                  FontMetrics fm = mock(FontMetrics.class);
                                                                  when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                                  when(fm.getStringBounds(anyString(), any(Graphics2D.class)))
                                                                      .thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                                  
                                                                  // Mock other required methods
                                                                  when(g2.getFont()).thenReturn(new Font("Arial", Font.PLAIN, 12));
                                                                  
                                                                  try {
                                                                      // Use reflection to access protected method
                                                                      Method drawLabel = Axis.class.getDeclaredMethod(
                                                                          "drawLabel", 
                                                                          String.class, 
                                                                          Graphics2D.class, 
                                                                          Rectangle2D.class, 
                                                                          Rectangle2D.class, 
                                                                          RectangleEdge.class, 
                                                                          AxisState.class, 
                                                                          PlotRenderingInfo.class
                                                                      );
                                                                      drawLabel.setAccessible(true);
                                                                      AxisState result = (AxisState) drawLabel.invoke(
                                                                          axis, 
                                                                          "Test Label", 
                                                                          g2, 
                                                                          plotArea, 
                                                                          dataArea, 
                                                                          edge, 
                                                                          state, 
                                                                          plotState
                                                                      );
                                                                      
                                                                      // Verify entity was added
                                                                      EntityCollection entities = plotState.getOwner().getEntityCollection();
                                                                      assertNotNull("Entity collection should not be null", entities);
                                                                      assertEquals("Should contain exactly one entity", 1, entities.getEntityCount());
                                                                      
                                                                      // Verify the entity is an AxisLabelEntity
                                                                      Object entity = entities.getEntity(0);
                                                                      assertTrue("Entity should be AxisLabelEntity", 
                                                                          entity.getClass().getName().endsWith("AxisLabelEntity"));
                                                                      
                                                                      // Verify the state was returned properly
                                                                      assertSame("Should return the same state object", state, result);
                                                                  } catch (Exception e) {
                                                                      fail("Exception during reflection: " + e.getMessage());
                                                                  }
                                                              }

    @Test
                                                         public void testDrawLabel_ShouldNotAddEntityWhenPlotStateIsNull1() throws Exception {
                                                             // Setup
                                                             ValueAxis axis = new NumberAxis("Test Axis");
                                                             Graphics2D g2 = mock(Graphics2D.class);
                                                             Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                             Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                             AxisState state = new AxisState();
                                                             FontMetrics fm = mock(FontMetrics.class);
                                                             when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                             
                                                             // Use reflection to access protected method
                                                             Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                                 "drawLabel", 
                                                                 String.class, 
                                                                 Graphics2D.class, 
                                                                 Rectangle2D.class, 
                                                                 Rectangle2D.class, 
                                                                 RectangleEdge.class, 
                                                                 AxisState.class, 
                                                                 PlotRenderingInfo.class
                                                             );
                                                             drawLabelMethod.setAccessible(true);
                                                             
                                                             // Test with null plotState (should not attempt to add entities)
                                                             AxisState result = (AxisState) drawLabelMethod.invoke(
                                                                 axis, 
                                                                 "Label", 
                                                                 g2, 
                                                                 plotArea, 
                                                                 dataArea, 
                                                                 RectangleEdge.TOP, 
                                                                 state, 
                                                                 null
                                                             );
                                                             
                                                             // Verify no interaction with entity collection occurred
                                                             // (Since plotState is null, we shouldn't even try to access it)
                                                             // The mutant would have tried to access plotState.getOwner() here
                                                             assertNotNull(result);
                                                         }

    @Test
                                                     public void testDrawLabel_ShouldNotAddEntityWhenHotspotIsNull() {
                                                         // Setup
                                                         Axis axis = new Axis("Test Axis") {
                                                             @Override
                                                             public List refreshTicks(Graphics2D g2, AxisState state, 
                                                                     Rectangle2D dataArea, RectangleEdge edge) {
                                                                 return new ArrayList();
                                                             }
                                                             
                                                             @Override
                                                             public Font getLabelFont() {
                                                                 return null; // Will cause hotspot to be null
                                                             }
                                                             
                                                             @Override
                                                             public void configure() {
                                                                 // Empty implementation
                                                             }
                                                             
                                                             @Override
                                                             public AxisSpace reserveSpace(Graphics2D g2, Plot plot, 
                                                                     Rectangle2D plotArea, RectangleEdge edge, AxisSpace space) {
                                                                 return new AxisSpace();
                                                             }
                                                             
                                                             @Override
                                                             public AxisState draw(Graphics2D g2, double cursor, 
                                                                     Rectangle2D plotArea, Rectangle2D dataArea, 
                                                                     RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                 return new AxisState();
                                                             }
                                                         };
                                                         
                                                         Graphics2D g2 = mock(Graphics2D.class);
                                                         when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                                                         Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                         Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                         AxisState state = new AxisState();
                                                         PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                         
                                                         // Test with null hotspot (due to null font)
                                                         try {
                                                             Method drawLabel = Axis.class.getDeclaredMethod("drawLabel", 
                                                                 String.class, Graphics2D.class, Rectangle2D.class, 
                                                                 Rectangle2D.class, RectangleEdge.class, AxisState.class, 
                                                                 PlotRenderingInfo.class);
                                                             drawLabel.setAccessible(true);
                                                             AxisState result = (AxisState) drawLabel.invoke(axis, "Label", g2, 
                                                                 plotArea, dataArea, RectangleEdge.TOP, state, plotState);
                                                             
                                                             // Verify no entities were added
                                                             verify(plotState, never()).getOwner();
                                                             assertNotNull(result);
                                                         } catch (Exception e) {
                                                             fail("Exception during test: " + e.getMessage());
                                                         }
                                                     }

    @Test
                                                     public void testDrawLabel_ShouldNotAddEntityWhenBothNull() throws Exception {
                                                         // Setup
                                                         Axis axis = new Axis("Test Axis") {
                                                             @Override
                                                             public List refreshTicks(Graphics2D g2, AxisState state, 
                                                                     Rectangle2D dataArea, RectangleEdge edge) {
                                                                 return new ArrayList();
                                                             }
                                                             
                                                             @Override
                                                             public Font getLabelFont() {
                                                                 return null; // Will cause hotspot to be null
                                                             }
                                                             
                                                             @Override
                                                             public void configure() {
                                                             }
                                                             
                                                             @Override
                                                             public AxisSpace reserveSpace(Graphics2D g2, Plot plot, 
                                                                     Rectangle2D plotArea, RectangleEdge edge, AxisSpace space) {
                                                                 return new AxisSpace();
                                                             }
                                                             
                                                             @Override
                                                             public AxisState draw(Graphics2D g2, double cursor, 
                                                                     Rectangle2D plotArea, Rectangle2D dataArea, 
                                                                     RectangleEdge edge, PlotRenderingInfo plotState) {
                                                                 return new AxisState();
                                                             }
                                                         };
                                                         
                                                         Graphics2D g2 = mock(Graphics2D.class);
                                                         Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                         Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                         AxisState state = new AxisState();
                                                         
                                                         // Get the protected drawLabel method via reflection
                                                         Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                             "drawLabel", 
                                                             String.class, 
                                                             Graphics2D.class, 
                                                             Rectangle2D.class, 
                                                             Rectangle2D.class, 
                                                             RectangleEdge.class, 
                                                             AxisState.class, 
                                                             PlotRenderingInfo.class
                                                         );
                                                         drawLabelMethod.setAccessible(true);
                                                         
                                                         // Test with both plotState and hotspot null
                                                         AxisState result = (AxisState) drawLabelMethod.invoke(
                                                             axis, 
                                                             "Label", 
                                                             g2, 
                                                             plotArea, 
                                                             dataArea, 
                                                             RectangleEdge.TOP, 
                                                             state, 
                                                             null
                                                         );
                                                         
                                                         // Verify no interaction with plotState occurred
                                                         assertNotNull(result);
                                                     }

    @Test
                                                public void testDrawLabel_AddsEntityWhenPlotStateAndHotspotExist4() throws Exception {
                                                    // Setup test objects
                                                    ValueAxis axis = new NumberAxis("Test Axis");
                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                    Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                                    RectangleEdge edge = RectangleEdge.TOP;
                                                    AxisState state = new AxisState();
                                                    
                                                    // Mock FontMetrics to return reasonable values
                                                    FontMetrics fm = mock(FontMetrics.class);
                                                    when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                                    when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 50, 10));
                                                    
                                                    // Setup plot state with entity collection
                                                    PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                                    ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                                    EntityCollection entities = mock(EntityCollection.class);
                                                    when(plotState.getOwner()).thenReturn(owner);
                                                    when(owner.getEntityCollection()).thenReturn(entities);
                                                    
                                                    // Use reflection to call protected method
                                                    Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                                        "drawLabel", 
                                                        String.class, 
                                                        Graphics2D.class, 
                                                        Rectangle2D.class, 
                                                        Rectangle2D.class, 
                                                        RectangleEdge.class, 
                                                        AxisState.class, 
                                                        PlotRenderingInfo.class
                                                    );
                                                    drawLabelMethod.setAccessible(true);
                                                    
                                                    // Execute method
                                                    AxisState result = (AxisState) drawLabelMethod.invoke(
                                                        axis, 
                                                        "Test Label", 
                                                        g2, 
                                                        plotArea, 
                                                        dataArea, 
                                                        edge, 
                                                        state, 
                                                        plotState
                                                    );
                                                    
                                                    // Verify entity was added
                                                    verify(entities).add(any(AxisLabelEntity.class));
                                                    
                                                    // Also verify state was updated correctly
                                                    assertNotNull(result);
                                                    assertTrue(result.getCursor() > state.getCursor()); // Verify cursor moved
                                                }

    @Test
                                       public void testDrawLabel_AddsEntityToCollectionWhenPlotStateHasOwner() {
                                           // Create concrete subclass to test protected method
                                           class TestAxis extends Axis {
                                               public TestAxis(String label) {
                                                   super(label);
                                               }
                                               
                                               @Override
                                               public void configure() {
                                                   // Minimal implementation
                                               }
                                               
                                               @Override
                                               public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, 
                                                       RectangleEdge edge, AxisSpace space) {
                                                   return new AxisSpace();
                                               }
                                               
                                               @Override
                                               public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, 
                                                       Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                                                   return new AxisState();
                                               }
                                               
                                               @Override
                                               public List refreshTicks(Graphics2D g2, AxisState state, 
                                                       Rectangle2D dataArea, RectangleEdge edge) {
                                                   return new ArrayList();
                                               }
                                           }
                                           
                                           // Setup test objects
                                           TestAxis axis = new TestAxis("Test Axis");
                                           Graphics2D g2 = mock(Graphics2D.class);
                                           Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                           Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                           AxisState state = new AxisState();
                                           
                                           // Setup font metrics mock
                                           FontMetrics fm = mock(FontMetrics.class);
                                           when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                           when(fm.getStringBounds(anyString(), any(Graphics2D.class))).thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                                           
                                           // Setup plot state with owner and entity collection
                                           PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                           ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                           EntityCollection entities = mock(EntityCollection.class);
                                           when(plotState.getOwner()).thenReturn(owner);
                                           when(owner.getEntityCollection()).thenReturn(entities);
                                           
                                           // Call method using reflection to access protected method
                                           try {
                                               Method drawLabel = Axis.class.getDeclaredMethod("drawLabel", 
                                                   String.class, Graphics2D.class, Rectangle2D.class, 
                                                   Rectangle2D.class, RectangleEdge.class, AxisState.class, 
                                                   PlotRenderingInfo.class);
                                               drawLabel.setAccessible(true);
                                               drawLabel.invoke(axis, "Test Label", g2, plotArea, dataArea, 
                                                   RectangleEdge.TOP, state, plotState);
                                           } catch (Exception e) {
                                               fail("Failed to invoke drawLabel method: " + e.getMessage());
                                           }
                                           
                                           // Verify entity was added to collection
                                           verify(entities).add(any(AxisLabelEntity.class));
                                       }

    @Test
                                  public void testDrawLabel_AddsEntityWhenOwnerExists3() throws Exception {
                                      // Setup test data
                                      String label = "Test Label";
                                      Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                      Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                      RectangleEdge edge = RectangleEdge.TOP;
                                      
                                      // Mock required objects
                                      Graphics2D g2 = mock(Graphics2D.class);
                                      FontMetrics fm = mock(FontMetrics.class);
                                      when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                      
                                      AxisState state = new AxisState();
                                      state.setCursor(50);
                                      
                                      // Setup plot state with owner and entity collection
                                      PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                                      ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                                      EntityCollection entities = mock(EntityCollection.class);
                                      when(plotState.getOwner()).thenReturn(owner);
                                      when(owner.getEntityCollection()).thenReturn(entities);
                                      
                                      // Create axis instance using concrete subclass
                                      ValueAxis axis = new NumberAxis(label);
                                      axis.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
                                      axis.setLabelPaint(Color.BLACK);
                                      axis.setLabelInsets(new RectangleInsets(5, 5, 5, 5));
                                      
                                      // Use reflection to access protected method
                                      Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                          "drawLabel", 
                                          String.class, 
                                          Graphics2D.class, 
                                          Rectangle2D.class, 
                                          Rectangle2D.class, 
                                          RectangleEdge.class, 
                                          AxisState.class, 
                                          PlotRenderingInfo.class
                                      );
                                      drawLabelMethod.setAccessible(true);
                                      
                                      // Execute the method
                                      AxisState result = (AxisState) drawLabelMethod.invoke(
                                          axis, 
                                          label, 
                                          g2, 
                                          plotArea, 
                                          dataArea, 
                                          edge, 
                                          state, 
                                          plotState
                                      );
                                      
                                      // Verify the entity was added (original behavior)
                                      // The mutant would fail this verification
                                      verify(entities).add(any(AxisLabelEntity.class));
                                      
                                      // Additional assertions
                                      assertSame(state, result);
                                      assertTrue(result.getCursor() > 50); // Verify cursor moved
                                  }

    @Test
                             public void testDrawLabelWithNullOwnerShouldNotAddEntity() throws Exception {
                                 // Setup test objects - use concrete subclass of Axis
                                 NumberAxis axis = new NumberAxis("Test Axis");
                                 Graphics2D g2 = mock(Graphics2D.class);
                                 Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                 Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                                 AxisState state = new AxisState();
                                 
                                 // Mock FontMetrics to avoid NPE
                                 FontMetrics fm = mock(FontMetrics.class);
                                 when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                                 
                                 // Create plotState with null owner
                                 PlotRenderingInfo plotState = new PlotRenderingInfo(null);
                                 
                                 // Use reflection to access protected method
                                 Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                     "drawLabel", 
                                     String.class, 
                                     Graphics2D.class, 
                                     Rectangle2D.class, 
                                     Rectangle2D.class, 
                                     RectangleEdge.class, 
                                     AxisState.class, 
                                     PlotRenderingInfo.class
                                 );
                                 drawLabelMethod.setAccessible(true);
                                 
                                 // Execute the method
                                 AxisState result = (AxisState) drawLabelMethod.invoke(
                                     axis, 
                                     "Label", 
                                     g2, 
                                     plotArea, 
                                     dataArea, 
                                     RectangleEdge.TOP, 
                                     state, 
                                     plotState
                                 );
                                 
                                 // Verify no entity was added (since owner is null)
                                 assertNull(plotState.getOwner());
                                 
                                 // Additional verification that the method executed normally
                                 assertNotNull(result);
                                 // Verify cursor was updated (shows main functionality worked)
                                 assertNotEquals(state.getCursor(), result.getCursor(), 0.001);
                             }

    @Test
                        public void testDrawLabel_AddsEntityWhenOwnerExists4() throws Exception {
                            // Setup test objects using concrete subclass
                            NumberAxis axis = new NumberAxis("Test Axis");
                            Graphics2D g2 = mock(Graphics2D.class);
                            Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                            Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                            AxisState state = new AxisState();
                            PlotRenderingInfo plotState = new PlotRenderingInfo(null);
                            ChartRenderingInfo owner = new ChartRenderingInfo();
                            org.jfree.chart.entity.StandardEntityCollection entities = new org.jfree.chart.entity.StandardEntityCollection();
                            
                            // Configure mocks and test objects
                            when(g2.getFontMetrics(any(Font.class))).thenReturn(mock(FontMetrics.class));
                            owner.setEntityCollection(entities);
                            // Use reflection to set owner since setOwner might not be public
                            Field ownerField = PlotRenderingInfo.class.getDeclaredField("owner");
                            ownerField.setAccessible(true);
                            ownerField.set(plotState, owner);
                            
                            // Set label properties that will trigger entity creation
                            axis.setLabel("Test Label");
                            axis.setLabelToolTip("Tooltip");
                            
                            // Use reflection to access protected method
                            Method drawLabelMethod = Axis.class.getDeclaredMethod(
                                "drawLabel", 
                                String.class, 
                                Graphics2D.class, 
                                Rectangle2D.class, 
                                Rectangle2D.class, 
                                RectangleEdge.class, 
                                AxisState.class, 
                                PlotRenderingInfo.class
                            );
                            drawLabelMethod.setAccessible(true);
                            
                            // Execute method
                            AxisState result = (AxisState) drawLabelMethod.invoke(
                                axis,
                                axis.getLabel(), 
                                g2, 
                                plotArea, 
                                dataArea, 
                                RectangleEdge.TOP, 
                                state, 
                                plotState
                            );
                            
                            // Verify entity was added (would fail with mutant)
                            assertEquals(1, entities.getEntityCount());
                            assertNotNull(entities.getEntity(0));
                            assertTrue(entities.getEntity(0) instanceof org.jfree.chart.entity.AxisLabelEntity);
                            
                            // Verify other behavior remains correct
                            assertNotNull(result);
                            assertNotSame(state, result); // Should return new state
                        }

    @Test
                   public void testDrawLabel_AddsEntityToOwnerCollection1() throws Exception {
                       // Setup test objects
                       NumberAxis axis = new NumberAxis("Test Axis");
                       Graphics2D g2 = mock(Graphics2D.class);
                       Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                       Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                       AxisState state = new AxisState();
                       PlotRenderingInfo plotState = new PlotRenderingInfo(new ChartRenderingInfo());
                       
                       // Mock font metrics for label drawing
                       FontMetrics fm = mock(FontMetrics.class);
                       when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                       when(fm.getStringBounds(anyString(), eq(g2))).thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                       
                       // Set label properties
                       axis.setLabel("Test Label");
                       axis.setLabelToolTip("Tooltip");
                       axis.setLabelURL("http://example.com");
                       
                       // Access protected method via reflection
                       Method drawLabelMethod = Axis.class.getDeclaredMethod(
                           "drawLabel", 
                           String.class, 
                           Graphics2D.class, 
                           Rectangle2D.class, 
                           Rectangle2D.class, 
                           RectangleEdge.class, 
                           AxisState.class, 
                           PlotRenderingInfo.class
                       );
                       drawLabelMethod.setAccessible(true);
                       
                       // Execute method
                       AxisState result = (AxisState) drawLabelMethod.invoke(
                           axis, 
                           axis.getLabel(), 
                           g2, 
                           plotArea, 
                           dataArea, 
                           RectangleEdge.TOP, 
                           state, 
                           plotState
                       );
                       
                       // Verify entity was added
                       ChartRenderingInfo owner = plotState.getOwner();
                       EntityCollection entities = owner.getEntityCollection();
                       assertNotNull("Entity collection should not be null", entities);
                       assertEquals("Should contain exactly one entity", 1, entities.getEntityCount());
                       
                       org.jfree.chart.entity.ChartEntity entity = entities.getEntity(0);
                       assertTrue("Entity should be AxisLabelEntity", 
                           entity instanceof org.jfree.chart.entity.AxisLabelEntity);
                       org.jfree.chart.entity.AxisLabelEntity labelEntity = 
                           (org.jfree.chart.entity.AxisLabelEntity) entity;
                       assertEquals("Entity should reference the axis", axis, labelEntity.getAxis());
                   }

    @Test
              public void testDrawLabelWithNullEntityCollection1() throws Exception {
                  // Create a concrete subclass of Axis for testing
                  class TestAxis extends Axis {
                      public TestAxis(String label) {
                          super(label);
                      }
                      @Override
                      public void configure() {}
                      @Override
                      public AxisSpace reserveSpace(Graphics2D g2, Plot plot, Rectangle2D plotArea, RectangleEdge edge, AxisSpace space) {
                          return null;
                      }
                      @Override
                      public AxisState draw(Graphics2D g2, double cursor, Rectangle2D plotArea, Rectangle2D dataArea, RectangleEdge edge, PlotRenderingInfo plotState) {
                          return null;
                      }
                      @Override
                      public List refreshTicks(Graphics2D g2, AxisState state, Rectangle2D dataArea, RectangleEdge edge) {
                          return null;
                      }
                  }
                  
                  // Setup test objects
                  TestAxis axis = new TestAxis("Test Axis");
                  Graphics2D g2 = mock(Graphics2D.class);
                  Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                  Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
                  AxisState state = new AxisState();
                  PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                  
                  // Mock the font metrics and text bounds
                  FontMetrics fm = mock(FontMetrics.class);
                  when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
                  when(TextUtilities.getTextBounds(anyString(), any(Graphics2D.class), any(FontMetrics.class)))
                      .thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
                  
                  // Setup the scenario where entities collection is null
                  ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                  when(plotState.getOwner()).thenReturn(owner);
                  when(owner.getEntityCollection()).thenReturn(null);
                  
                  // Test all edge cases to ensure full coverage
                  RectangleEdge[] edges = {
                      RectangleEdge.TOP, 
                      RectangleEdge.BOTTOM,
                      RectangleEdge.LEFT,
                      RectangleEdge.RIGHT
                  };
                  
                  // Get the protected method via reflection
                  Method drawLabelMethod = Axis.class.getDeclaredMethod(
                      "drawLabel", 
                      String.class, 
                      Graphics2D.class, 
                      Rectangle2D.class, 
                      Rectangle2D.class, 
                      RectangleEdge.class, 
                      AxisState.class, 
                      PlotRenderingInfo.class
                  );
                  drawLabelMethod.setAccessible(true);
                  
                  for (RectangleEdge edge : edges) {
                      // Invoke the protected method using reflection
                      AxisState result = (AxisState) drawLabelMethod.invoke(
                          axis, 
                          "Test Label", 
                          g2, 
                          plotArea, 
                          dataArea, 
                          edge, 
                          state, 
                          plotState
                      );
                      
                      // Verify the state was updated
                      assertNotNull(result);
                      // Additional assertions can be added to verify cursor position changes
                  }
                  
                  // Verify that no interactions occurred with null entity collection
                  verify(owner, never()).getEntityCollection();
              }

    @Test
         public void testDrawLabel_AddsEntityWhenEntitiesExist2() throws Exception {
             // Setup test objects - using ValueAxis instead of abstract Axis
             ValueAxis axis = new NumberAxis("Test Axis");
             axis.setLabelToolTip("Tooltip");
             axis.setLabelURL("URL");
             
             Graphics2D g2 = mock(Graphics2D.class);
             Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
             Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
             AxisState state = new AxisState();
             PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
             ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
             EntityCollection entities = mock(EntityCollection.class);
             
             // Mock the behavior
             when(g2.getFontMetrics()).thenReturn(mock(FontMetrics.class));
             when(plotState.getOwner()).thenReturn(owner);
             when(owner.getEntityCollection()).thenReturn(entities);
             
             // Use reflection to access protected method
             Method drawLabelMethod = Axis.class.getDeclaredMethod(
                 "drawLabel", 
                 String.class, 
                 Graphics2D.class, 
                 Rectangle2D.class, 
                 Rectangle2D.class, 
                 RectangleEdge.class, 
                 AxisState.class, 
                 PlotRenderingInfo.class
             );
             drawLabelMethod.setAccessible(true);
             
             // Execute the method
             AxisState result = (AxisState) drawLabelMethod.invoke(
                 axis, 
                 "Label", 
                 g2, 
                 plotArea, 
                 dataArea, 
                 RectangleEdge.TOP, 
                 state, 
                 plotState
             );
             
             // Verify the entity was added
             verify(entities).add(argThat(entity -> 
                 entity instanceof AxisLabelEntity &&
                 ((AxisLabelEntity) entity).getToolTipText().equals("Tooltip") &&
                 ((AxisLabelEntity) entity).getURLText().equals("URL")
             ));
             
             // Verify the state was returned
             assertSame(state, result);
         }

    @Test
    public void testDrawLabelReturnsCorrectStateObject() throws Exception {
        // Setup test objects - use concrete subclass ValueAxis
        ValueAxis axis = new NumberAxis("Test Axis");
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        Rectangle2D dataArea = new Rectangle2D.Double(10, 10, 80, 80);
        AxisState state = new AxisState();
        PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
        
        // Mock font metrics for label calculation
        FontMetrics fm = mock(FontMetrics.class);
        when(g2.getFontMetrics(any(Font.class))).thenReturn(fm);
        when(fm.getStringBounds(anyString(), any())).thenReturn(new Rectangle2D.Double(0, 0, 30, 10));
        
        // Get protected method via reflection
        Method drawLabelMethod = Axis.class.getDeclaredMethod(
            "drawLabel", 
            String.class, 
            Graphics2D.class, 
            Rectangle2D.class, 
            Rectangle2D.class, 
            RectangleEdge.class, 
            AxisState.class, 
            PlotRenderingInfo.class
        );
        drawLabelMethod.setAccessible(true);
        
        // Test all edge cases
        RectangleEdge[] edges = {
            RectangleEdge.TOP,
            RectangleEdge.BOTTOM,
            RectangleEdge.LEFT,
            RectangleEdge.RIGHT
        };
        
        for (RectangleEdge edge : edges) {
            // Call method with non-empty label to ensure full execution
            AxisState result = (AxisState) drawLabelMethod.invoke(
                axis, 
                "Test Label", 
                g2, 
                plotArea, 
                dataArea, 
                edge, 
                state, 
                plotState
            );
            
            // Verify the returned state is the same object we passed in (not null)
            assertSame("Returned state should be the same object as input state for edge: " + edge, 
                      state, result);
        }
        
        // Additional test with empty label (should return state without modifications)
        AxisState emptyLabelResult = (AxisState) drawLabelMethod.invoke(
            axis, 
            "", 
            g2, 
            plotArea, 
            dataArea, 
            RectangleEdge.TOP, 
            state, 
            plotState
        );
        assertSame("Empty label should return original state", state, emptyLabelResult);
    }


}
