package gentest.org.jfree.data.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.general.*;
import org.jfree.data.pie.PieDataset;
import org.jfree.data.pie.DefaultPieDataset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jfree.chart.util.ArrayUtilities;
import org.jfree.data.DomainInfo;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.KeyedValues;
import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryRangeInfo;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.function.Function2D;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYDomainInfo;
import org.jfree.data.xy.XYRangeInfo;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
 
public class DatasetUtilitiesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                              public void testIterateDomainBounds_NullDataset() {
                                                                  // Test with null dataset
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(null));
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(null, true));
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(null, false));
                                                              }

 @Test
                                                              public void testIterateDomainBounds_EmptyDataset() {
                                                                  // Test with empty dataset
                                                                  XYDataset emptyDataset = mock(XYDataset.class);
                                                                  when(emptyDataset.getSeriesCount()).thenReturn(0);
                                                                  
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(emptyDataset));
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(emptyDataset, true));
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(emptyDataset, false));
                                                              }

 @Test
                                                              public void testIterateDomainBounds_SingleSeriesDataset() {
                                                                  // Test with single series dataset
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                  assertNotNull(result);
                                                                  assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                  
                                                                  // Test with includeInterval = true (same as default)
                                                                  Range resultTrue = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                  assertEquals(result, resultTrue);
                                                                  
                                                                  // Test with includeInterval = false
                                                                  Range resultFalse = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                  assertEquals(result, resultFalse);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_MultiSeriesDataset() {
                                                                  // Test with multiple series dataset
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(2);
                                                                  
                                                                  // Series 0
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(3.0);
                                                                  
                                                                  // Series 1
                                                                  when(dataset.getItemCount(1)).thenReturn(2);
                                                                  when(dataset.getXValue(1, 0)).thenReturn(2.0);
                                                                  when(dataset.getXValue(1, 1)).thenReturn(4.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                  assertNotNull(result);
                                                                  assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(4.0, result.getUpperBound(), 0.0001);
                                                                  
                                                                  // Test with includeInterval = false
                                                                  Range resultFalse = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                  assertEquals(result, resultFalse);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_WithNaNValues() {
                                                                  // Test with dataset containing NaN values
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(3);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                  when(dataset.getXValue(0, 2)).thenReturn(3.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset);
                                                                  assertNotNull(result);
                                                                  assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_AllNaNValues() {
                                                                  // Test with dataset containing only NaN values
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                  
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(dataset));
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(dataset, true));
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(dataset, false));
                                                              }

 @Test
                                                              public void testIterateDomainBounds_WithInterval() {
                                                                  // Test with dataset that has interval data
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(1.0);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(2.0);
                                                                  when(dataset.getX(0, 0)).thenReturn(0.9);
                                                                  when(dataset.getX(0, 1)).thenReturn(2.1);
                                                                  
                                                                  // With includeInterval = true
                                                                  Range resultTrue = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                  assertNotNull(resultTrue);
                                                                  assertEquals(0.9, resultTrue.getLowerBound(), 0.0001);
                                                                  assertEquals(2.1, resultTrue.getUpperBound(), 0.0001);
                                                                  
                                                                  // With includeInterval = false (default)
                                                                  Range resultDefault = DatasetUtilities.iterateDomainBounds(dataset);
                                                                  assertNotNull(resultDefault);
                                                                  assertEquals(1.0, resultDefault.getLowerBound(), 0.0001);
                                                                  assertEquals(2.0, resultDefault.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_NullDataset1() {
                                                                  thrown.expect(IllegalArgumentException.class);
                                                                  thrown.expectMessage("Null 'dataset' argument.");
                                                                  DatasetUtilities.iterateDomainBounds(null, true);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_EmptyDataset1() {
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(0);
                                                                  
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(dataset, false));
                                                              }

 @Test
                                                              public void testIterateDomainBounds_RegularXYDataset() {
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(2);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getItemCount(1)).thenReturn(3);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(10.0);
                                                                  when(dataset.getXValue(1, 0)).thenReturn(2.0);
                                                                  when(dataset.getXValue(1, 1)).thenReturn(7.0);
                                                                  when(dataset.getXValue(1, 2)).thenReturn(15.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                  assertEquals(new Range(2.0, 15.0), result);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_WithNaNValues1() {
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(3);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(3.0);
                                                                  when(dataset.getXValue(0, 2)).thenReturn(Double.NaN);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                  assertEquals(new Range(3.0, 3.0), result);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_AllNaNValues1() {
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                  
                                                                  assertNull(DatasetUtilities.iterateDomainBounds(dataset, false));
                                                              }

 @Test
                                                              public void testIterateDomainBounds_IntervalXYDataset_IncludeInterval() {
                                                                  IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getStartXValue(0, 0)).thenReturn(4.0);
                                                                  when(dataset.getEndXValue(0, 0)).thenReturn(6.0);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(8.0);
                                                                  when(dataset.getStartXValue(0, 1)).thenReturn(7.0);
                                                                  when(dataset.getEndXValue(0, 1)).thenReturn(9.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                  assertEquals(new Range(4.0, 9.0), result);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_IntervalXYDataset_ExcludeInterval() {
                                                                  IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(8.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                  assertEquals(new Range(5.0, 8.0), result);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_MixedIntervalValues() {
                                                                  IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(3);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getStartXValue(0, 0)).thenReturn(4.0);
                                                                  when(dataset.getEndXValue(0, 0)).thenReturn(6.0);
                                                                  when(dataset.getXValue(0, 1)).thenReturn(Double.NaN);
                                                                  when(dataset.getStartXValue(0, 1)).thenReturn(2.0);
                                                                  when(dataset.getEndXValue(0, 1)).thenReturn(Double.NaN);
                                                                  when(dataset.getXValue(0, 2)).thenReturn(10.0);
                                                                  when(dataset.getStartXValue(0, 2)).thenReturn(Double.NaN);
                                                                  when(dataset.getEndXValue(0, 2)).thenReturn(12.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset, true);
                                                                  assertEquals(new Range(2.0, 12.0), result);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_SingleValue() {
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(1);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(3.14);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                  assertEquals(new Range(3.14, 3.14), result);
                                                              }

 @Test
                                                              public void testIterateDomainBounds_NegativeValues() {
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(2);
                                                                  when(dataset.getItemCount(0)).thenReturn(1);
                                                                  when(dataset.getItemCount(1)).thenReturn(1);
                                                                  when(dataset.getXValue(0, 0)).thenReturn(-5.0);
                                                                  when(dataset.getXValue(1, 0)).thenReturn(-2.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateDomainBounds(dataset, false);
                                                                  assertEquals(new Range(-5.0, -2.0), result);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_NullDataset() {
                                                                  // Test with null dataset
                                                                  Range result = DatasetUtilities.iterateRangeBounds((CategoryDataset) null);
                                                                  assertNull("Null dataset should return null range", result);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_EmptyDataset() {
                                                                  // Test with empty dataset
                                                                  CategoryDataset emptyDataset = mock(CategoryDataset.class);
                                                                  when(emptyDataset.getRowCount()).thenReturn(0);
                                                                  when(emptyDataset.getColumnCount()).thenReturn(0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(emptyDataset);
                                                                  assertNull("Empty dataset should return null range", result);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_SingleValueDataset() {
                                                                  // Test with dataset containing single value
                                                                  CategoryDataset singleValueDataset = mock(CategoryDataset.class);
                                                                  when(singleValueDataset.getRowCount()).thenReturn(1);
                                                                  when(singleValueDataset.getColumnCount()).thenReturn(1);
                                                                  when(singleValueDataset.getValue(0, 0)).thenReturn(5.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(singleValueDataset);
                                                                  assertEquals("Range lower bound should match single value", 5.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals("Range upper bound should match single value", 5.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_MultipleValues() {
                                                                  // Test with dataset containing multiple values
                                                                  CategoryDataset multiValueDataset = mock(CategoryDataset.class);
                                                                  when(multiValueDataset.getRowCount()).thenReturn(2);
                                                                  when(multiValueDataset.getColumnCount()).thenReturn(2);
                                                                  when(multiValueDataset.getValue(0, 0)).thenReturn(1.0);
                                                                  when(multiValueDataset.getValue(0, 1)).thenReturn(3.0);
                                                                  when(multiValueDataset.getValue(1, 0)).thenReturn(-2.0);
                                                                  when(multiValueDataset.getValue(1, 1)).thenReturn(4.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(multiValueDataset);
                                                                  assertEquals("Range lower bound should be minimum value", -2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals("Range upper bound should be maximum value", 4.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_WithNullValues() {
                                                                  // Test with dataset containing some null values
                                                                  CategoryDataset datasetWithNulls = mock(CategoryDataset.class);
                                                                  when(datasetWithNulls.getRowCount()).thenReturn(2);
                                                                  when(datasetWithNulls.getColumnCount()).thenReturn(2);
                                                                  when(datasetWithNulls.getValue(0, 0)).thenReturn(1.0);
                                                                  when(datasetWithNulls.getValue(0, 1)).thenReturn(null);
                                                                  when(datasetWithNulls.getValue(1, 0)).thenReturn(-2.0);
                                                                  when(datasetWithNulls.getValue(1, 1)).thenReturn(4.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(datasetWithNulls);
                                                                  assertEquals("Range lower bound should ignore null values", -2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals("Range upper bound should ignore null values", 4.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_AllNullValues() {
                                                                  // Test with dataset containing all null values
                                                                  CategoryDataset allNullsDataset = mock(CategoryDataset.class);
                                                                  when(allNullsDataset.getRowCount()).thenReturn(2);
                                                                  when(allNullsDataset.getColumnCount()).thenReturn(2);
                                                                  when(allNullsDataset.getValue(anyInt(), anyInt())).thenReturn(null);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(allNullsDataset);
                                                                  assertNull("Dataset with all null values should return null range", result);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_WithIncludeIntervalFalse() {
                                                                  // Test with includeInterval set to false
                                                                  CategoryDataset dataset = mock(CategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  when(dataset.getValue(0, 0)).thenReturn(1.0);
                                                                  when(dataset.getValue(0, 1)).thenReturn(3.0);
                                                                  when(dataset.getValue(1, 0)).thenReturn(-2.0);
                                                                  when(dataset.getValue(1, 1)).thenReturn(4.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertEquals("Range lower bound should be minimum value", -2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals("Range upper bound should be maximum value", 4.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_WithIncludeIntervalTrue() {
                                                                  // Test with includeInterval set to true
                                                                  CategoryDataset dataset = mock(CategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  when(dataset.getValue(0, 0)).thenReturn(1.0);
                                                                  when(dataset.getValue(0, 1)).thenReturn(3.0);
                                                                  when(dataset.getValue(1, 0)).thenReturn(-2.0);
                                                                  when(dataset.getValue(1, 1)).thenReturn(4.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                  assertEquals("Range lower bound should be minimum value", -2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals("Range upper bound should be maximum value", 4.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_WithNegativeValues() {
                                                                  // Test with negative values only
                                                                  CategoryDataset negativeDataset = mock(CategoryDataset.class);
                                                                  when(negativeDataset.getRowCount()).thenReturn(2);
                                                                  when(negativeDataset.getColumnCount()).thenReturn(1);
                                                                  when(negativeDataset.getValue(0, 0)).thenReturn(-5.0);
                                                                  when(negativeDataset.getValue(1, 0)).thenReturn(-1.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(negativeDataset);
                                                                  assertEquals("Range lower bound should be minimum negative value", -5.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals("Range upper bound should be maximum negative value", -1.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_WithLargeNumbers() {
                                                                  // Test with very large numbers
                                                                  CategoryDataset largeNumberDataset = mock(CategoryDataset.class);
                                                                  when(largeNumberDataset.getRowCount()).thenReturn(2);
                                                                  when(largeNumberDataset.getColumnCount()).thenReturn(1);
                                                                  when(largeNumberDataset.getValue(0, 0)).thenReturn(Double.MAX_VALUE);
                                                                  when(largeNumberDataset.getValue(1, 0)).thenReturn(-Double.MAX_VALUE);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(largeNumberDataset);
                                                                  assertEquals("Range lower bound should handle Double.MAX_VALUE", -Double.MAX_VALUE, result.getLowerBound(), 0.0001);
                                                                  assertEquals("Range upper bound should handle Double.MAX_VALUE", Double.MAX_VALUE, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_StandardDatasetWithValidValues() {
                                                                  // Create a mock CategoryDataset with valid values
                                                                  CategoryDataset dataset = mock(CategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getValue(0, 1)).thenReturn(10.0);
                                                                  when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                  when(dataset.getValue(1, 1)).thenReturn(8.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertNotNull(result);
                                                                  assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_StandardDatasetWithNullValues() {
                                                                  // Create a mock CategoryDataset with some null values
                                                                  CategoryDataset dataset = mock(CategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getValue(0, 1)).thenReturn(null);
                                                                  when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                  when(dataset.getValue(1, 1)).thenReturn(8.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertNotNull(result);
                                                                  assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(8.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_StandardDatasetWithNaNValues() {
                                                                  // Create a mock CategoryDataset with some NaN values
                                                                  CategoryDataset dataset = mock(CategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getValue(0, 1)).thenReturn(Double.NaN);
                                                                  when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                  when(dataset.getValue(1, 1)).thenReturn(8.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertNotNull(result);
                                                                  assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(8.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_EmptyDataset1() {
                                                                  // Create an empty dataset
                                                                  CategoryDataset dataset = mock(CategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(0);
                                                                  when(dataset.getColumnCount()).thenReturn(0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertNull(result);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_AllNullValues1() {
                                                                  // Create a dataset with all null values
                                                                  CategoryDataset dataset = mock(CategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  when(dataset.getValue(anyInt(), anyInt())).thenReturn(null);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertNull(result);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_IntervalDatasetWithIncludeIntervalTrue() {
                                                                  // Create a mock IntervalCategoryDataset with valid values
                                                                  IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  
                                                                  // Regular values
                                                                  when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getValue(0, 1)).thenReturn(10.0);
                                                                  when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                  when(dataset.getValue(1, 1)).thenReturn(8.0);
                                                                  
                                                                  // Interval start values
                                                                  when(dataset.getStartValue(0, 0)).thenReturn(4.0);
                                                                  when(dataset.getStartValue(0, 1)).thenReturn(9.0);
                                                                  when(dataset.getStartValue(1, 0)).thenReturn(1.0);
                                                                  when(dataset.getStartValue(1, 1)).thenReturn(7.0);
                                                                  
                                                                  // Interval end values
                                                                  when(dataset.getEndValue(0, 0)).thenReturn(6.0);
                                                                  when(dataset.getEndValue(0, 1)).thenReturn(11.0);
                                                                  when(dataset.getEndValue(1, 0)).thenReturn(3.0);
                                                                  when(dataset.getEndValue(1, 1)).thenReturn(9.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                  assertNotNull(result);
                                                                  assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_IntervalDatasetWithIncludeIntervalFalse() {
                                                                  // Create a mock IntervalCategoryDataset but don't include intervals
                                                                  IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  
                                                                  // Regular values
                                                                  when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getValue(0, 1)).thenReturn(10.0);
                                                                  when(dataset.getValue(1, 0)).thenReturn(2.0);
                                                                  when(dataset.getValue(1, 1)).thenReturn(8.0);
                                                                  
                                                                  // Interval values (should be ignored)
                                                                  when(dataset.getStartValue(0, 0)).thenReturn(4.0);
                                                                  when(dataset.getStartValue(0, 1)).thenReturn(9.0);
                                                                  when(dataset.getEndValue(0, 0)).thenReturn(6.0);
                                                                  when(dataset.getEndValue(0, 1)).thenReturn(11.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertNotNull(result);
                                                                  assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_IntervalDatasetWithNullAndNaNValues() {
                                                                  // Create a mock IntervalCategoryDataset with some null and NaN values
                                                                  IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                                                                  when(dataset.getRowCount()).thenReturn(2);
                                                                  when(dataset.getColumnCount()).thenReturn(2);
                                                                  
                                                                  // Regular values
                                                                  when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getValue(0, 1)).thenReturn(null);
                                                                  when(dataset.getValue(1, 0)).thenReturn(Double.NaN);
                                                                  when(dataset.getValue(1, 1)).thenReturn(8.0);
                                                                  
                                                                  // Interval start values
                                                                  when(dataset.getStartValue(0, 0)).thenReturn(null);
                                                                  when(dataset.getStartValue(0, 1)).thenReturn(9.0);
                                                                  when(dataset.getStartValue(1, 0)).thenReturn(1.0);
                                                                  when(dataset.getStartValue(1, 1)).thenReturn(Double.NaN);
                                                                  
                                                                  // Interval end values
                                                                  when(dataset.getEndValue(0, 0)).thenReturn(6.0);
                                                                  when(dataset.getEndValue(0, 1)).thenReturn(null);
                                                                  when(dataset.getEndValue(1, 0)).thenReturn(Double.NaN);
                                                                  when(dataset.getEndValue(1, 1)).thenReturn(9.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                  assertNotNull(result);
                                                                  assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(9.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_NullDataset1() {
                                                                  // Test with null dataset
                                                                  assertNull(DatasetUtilities.iterateRangeBounds((CategoryDataset) null));
                                                                  assertNull(DatasetUtilities.iterateRangeBounds((CategoryDataset) null, true));
                                                                  assertNull(DatasetUtilities.iterateRangeBounds((CategoryDataset) null, false));
                                                              }

 @Test
                                                              public void testIterateRangeBounds_EmptyDataset2() {
                                                                  // Test with empty dataset
                                                                  CategoryDataset emptyDataset = mock(CategoryDataset.class);
                                                                  when(emptyDataset.getRowCount()).thenReturn(0);
                                                                  when(emptyDataset.getColumnCount()).thenReturn(0);
                                                                  
                                                                  assertNull(DatasetUtilities.iterateRangeBounds(emptyDataset));
                                                                  assertNull(DatasetUtilities.iterateRangeBounds(emptyDataset, true));
                                                                  assertNull(DatasetUtilities.iterateRangeBounds(emptyDataset, false));
                                                              }

 @Test
                                                              public void testIterateRangeBounds_SingleValueDataset1() {
                                                                  // Test with dataset containing single value
                                                                  CategoryDataset singleValueDataset = mock(CategoryDataset.class);
                                                                  when(singleValueDataset.getRowCount()).thenReturn(1);
                                                                  when(singleValueDataset.getColumnCount()).thenReturn(1);
                                                                  when(singleValueDataset.getValue(0, 0)).thenReturn(5.0);
                                                                  
                                                                  Range result1 = DatasetUtilities.iterateRangeBounds(singleValueDataset);
                                                                  assertEquals(5.0, result1.getLowerBound(), 0.0001);
                                                                  assertEquals(5.0, result1.getUpperBound(), 0.0001);
                                                                  
                                                                  Range result2 = DatasetUtilities.iterateRangeBounds(singleValueDataset, true);
                                                                  assertEquals(5.0, result2.getLowerBound(), 0.0001);
                                                                  assertEquals(5.0, result2.getUpperBound(), 0.0001);
                                                                  
                                                                  Range result3 = DatasetUtilities.iterateRangeBounds(singleValueDataset, false);
                                                                  assertEquals(5.0, result3.getLowerBound(), 0.0001);
                                                                  assertEquals(5.0, result3.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_MultipleValues1() {
                                                                  // Test with dataset containing multiple values
                                                                  CategoryDataset multiValueDataset = mock(CategoryDataset.class);
                                                                  when(multiValueDataset.getRowCount()).thenReturn(2);
                                                                  when(multiValueDataset.getColumnCount()).thenReturn(2);
                                                                  when(multiValueDataset.getValue(0, 0)).thenReturn(1.0);
                                                                  when(multiValueDataset.getValue(0, 1)).thenReturn(2.0);
                                                                  when(multiValueDataset.getValue(1, 0)).thenReturn(3.0);
                                                                  when(multiValueDataset.getValue(1, 1)).thenReturn(4.0);
                                                                  
                                                                  Range result1 = DatasetUtilities.iterateRangeBounds(multiValueDataset);
                                                                  assertEquals(1.0, result1.getLowerBound(), 0.0001);
                                                                  assertEquals(4.0, result1.getUpperBound(), 0.0001);
                                                                  
                                                                  Range result2 = DatasetUtilities.iterateRangeBounds(multiValueDataset, true);
                                                                  assertEquals(1.0, result2.getLowerBound(), 0.0001);
                                                                  assertEquals(4.0, result2.getUpperBound(), 0.0001);
                                                                  
                                                                  Range result3 = DatasetUtilities.iterateRangeBounds(multiValueDataset, false);
                                                                  assertEquals(1.0, result3.getLowerBound(), 0.0001);
                                                                  assertEquals(4.0, result3.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_WithNullValues1() {
                                                                  // Test with dataset containing some null values
                                                                  CategoryDataset datasetWithNulls = mock(CategoryDataset.class);
                                                                  when(datasetWithNulls.getRowCount()).thenReturn(2);
                                                                  when(datasetWithNulls.getColumnCount()).thenReturn(2);
                                                                  when(datasetWithNulls.getValue(0, 0)).thenReturn(1.0);
                                                                  when(datasetWithNulls.getValue(0, 1)).thenReturn(null);
                                                                  when(datasetWithNulls.getValue(1, 0)).thenReturn(3.0);
                                                                  when(datasetWithNulls.getValue(1, 1)).thenReturn(4.0);
                                                                  
                                                                  Range result1 = DatasetUtilities.iterateRangeBounds(datasetWithNulls);
                                                                  assertEquals(1.0, result1.getLowerBound(), 0.0001);
                                                                  assertEquals(4.0, result1.getUpperBound(), 0.0001);
                                                                  
                                                                  Range result2 = DatasetUtilities.iterateRangeBounds(datasetWithNulls, false);
                                                                  assertEquals(1.0, result2.getLowerBound(), 0.0001);
                                                                  assertEquals(4.0, result2.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_AllNullValues2() {
                                                                  // Test with dataset containing all null values
                                                                  CategoryDataset allNullsDataset = mock(CategoryDataset.class);
                                                                  when(allNullsDataset.getRowCount()).thenReturn(2);
                                                                  when(allNullsDataset.getColumnCount()).thenReturn(2);
                                                                  when(allNullsDataset.getValue(anyInt(), anyInt())).thenReturn(null);
                                                                  
                                                                  assertNull(DatasetUtilities.iterateRangeBounds(allNullsDataset));
                                                                  assertNull(DatasetUtilities.iterateRangeBounds(allNullsDataset, true));
                                                                  assertNull(DatasetUtilities.iterateRangeBounds(allNullsDataset, false));
                                                              }

 @Test
                                                              public void testIterateRangeBounds_NegativeValues() {
                                                                  // Test with negative values
                                                                  CategoryDataset negativeDataset = mock(CategoryDataset.class);
                                                                  when(negativeDataset.getRowCount()).thenReturn(2);
                                                                  when(negativeDataset.getColumnCount()).thenReturn(1);
                                                                  when(negativeDataset.getValue(0, 0)).thenReturn(-5.0);
                                                                  when(negativeDataset.getValue(1, 0)).thenReturn(-1.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateRangeBounds(negativeDataset);
                                                                  assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(-1.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_MixedPositiveNegative() {
                                                                  // Test with mixed positive and negative values
                                                                  CategoryDataset mixedDataset = mock(CategoryDataset.class);
                                                                  when(mixedDataset.getRowCount()).thenReturn(3);
                                                                  when(mixedDataset.getColumnCount()).thenReturn(1);
                                                                  when(mixedDataset.getValue(0, 0)).thenReturn(-5.0);
                                                                  when(mixedDataset.getValue(1, 0)).thenReturn(0.0);
                                                                  when(mixedDataset.getValue(2, 0)).thenReturn(5.0);
                                                                  
                                                                  Range result = DatasetUtilities.iterateRangeBounds(mixedDataset, false);
                                                                  assertEquals(-5.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_StandardXYDataset() {
                                                                  // Setup standard XYDataset mock
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(2);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getItemCount(1)).thenReturn(2);
                                                                  
                                                                  // First series
                                                                  when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getYValue(0, 1)).thenReturn(10.0);
                                                                  // Second series
                                                                  when(dataset.getYValue(1, 0)).thenReturn(2.0);
                                                                  when(dataset.getYValue(1, 1)).thenReturn(15.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                  assertNotNull(result);
                                                                  assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(15.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_StandardXYDatasetWithNaN() {
                                                                  // Setup standard XYDataset mock with NaN values
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(3);
                                                                  
                                                                  when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                                  when(dataset.getYValue(0, 2)).thenReturn(15.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                  assertNotNull(result);
                                                                  assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(15.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_EmptyDataset3() {
                                                                  // Setup empty dataset
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                  assertNull(result);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_IntervalXYDataset_IncludeInterval() {
                                                                  // Setup IntervalXYDataset mock
                                                                  IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  
                                                                  // Main values
                                                                  when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getYValue(0, 1)).thenReturn(10.0);
                                                                  // Interval values
                                                                  when(dataset.getStartYValue(0, 0)).thenReturn(4.0);
                                                                  when(dataset.getEndYValue(0, 0)).thenReturn(6.0);
                                                                  when(dataset.getStartYValue(0, 1)).thenReturn(9.0);
                                                                  when(dataset.getEndYValue(0, 1)).thenReturn(11.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                  assertNotNull(result);
                                                                  assertEquals(4.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_IntervalXYDataset_ExcludeInterval() {
                                                                  // Setup IntervalXYDataset mock but treat as standard XYDataset
                                                                  IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  
                                                                  // Only main values matter when includeInterval=false
                                                                  when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getYValue(0, 1)).thenReturn(10.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertNotNull(result);
                                                                  assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_OHLCDataset_IncludeInterval() {
                                                                  // Setup OHLCDataset mock
                                                                  OHLCDataset dataset = mock(OHLCDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  
                                                                  // High/Low values
                                                                  when(dataset.getHighValue(0, 0)).thenReturn(6.0);
                                                                  when(dataset.getLowValue(0, 0)).thenReturn(4.0);
                                                                  when(dataset.getHighValue(0, 1)).thenReturn(11.0);
                                                                  when(dataset.getLowValue(0, 1)).thenReturn(9.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                                  assertNotNull(result);
                                                                  assertEquals(4.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(11.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_OHLCDataset_ExcludeInterval() {
                                                                  // Setup OHLCDataset mock but treat as standard XYDataset
                                                                  OHLCDataset dataset = mock(OHLCDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  
                                                                  // Only Y values matter when includeInterval=false
                                                                  when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                                                  when(dataset.getYValue(0, 1)).thenReturn(10.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                                                  assertNotNull(result);
                                                                  assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_AllNaNValues() {
                                                                  // Setup dataset with all NaN values
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
                                                                  when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                  assertNull(result);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_MixedPositiveNegativeValues() {
                                                                  // Setup dataset with mixed positive and negative values
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(2);
                                                                  when(dataset.getItemCount(0)).thenReturn(2);
                                                                  when(dataset.getItemCount(1)).thenReturn(2);
                                                                  
                                                                  when(dataset.getYValue(0, 0)).thenReturn(-5.0);
                                                                  when(dataset.getYValue(0, 1)).thenReturn(10.0);
                                                                  when(dataset.getYValue(1, 0)).thenReturn(-10.0);
                                                                  when(dataset.getYValue(1, 1)).thenReturn(5.0);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                  assertNotNull(result);
                                                                  assertEquals(-10.0, result.getLowerBound(), 0.0001);
                                                                  assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                              public void testIterateRangeBounds_SingleValue() {
                                                                  // Setup dataset with single value
                                                                  XYDataset dataset = mock(XYDataset.class);
                                                                  when(dataset.getSeriesCount()).thenReturn(1);
                                                                  when(dataset.getItemCount(0)).thenReturn(1);
                                                                  when(dataset.getYValue(0, 0)).thenReturn(7.5);
                                                          
                                                                  Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                                  assertNotNull(result);
                                                                  assertEquals(7.5, result.getLowerBound(), 0.0001);
                                                                  assertEquals(7.5, result.getUpperBound(), 0.0001);
                                                              }

 @Test
                                                      public void testIterateRangeBounds_NullDataset2() {
                                                          thrown.expect(IllegalArgumentException.class);
                                                          DatasetUtilities.iterateRangeBounds((CategoryDataset) null, false);
                                                      }

 @Test
                                                      public void testIterateRangeBoundsWithExactSeriesCount() {
                                                          // Create a mock dataset with 3 series
                                                          CategoryDataset dataset = mock(CategoryDataset.class);
                                                          when(dataset.getRowCount()).thenReturn(0); // Not used in this case
                                                          when(dataset.getColumnCount()).thenReturn(0); // Not used in this case
                                                          when(dataset.getRowKey(anyInt())).thenReturn("Series");
                                                          when(dataset.getColumnKey(anyInt())).thenReturn("Category");
                                                          
                                                          // Configure series count and values
                                                          int seriesCount = 3;
                                                          when(dataset.getRowCount()).thenReturn(seriesCount);
                                                          
                                                          // Setup values for each series
                                                          when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                          when(dataset.getValue(1, 0)).thenReturn(10.0);
                                                          when(dataset.getValue(2, 0)).thenReturn(15.0);
                                                          
                                                          // Call the method under test
                                                          Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                          
                                                          // Verify the range is correct
                                                          assertEquals("Lower bound should be 5.0", 5.0, result.getLowerBound(), 0.0001);
                                                          assertEquals("Upper bound should be 15.0", 15.0, result.getUpperBound(), 0.0001);
                                                          
                                                          // Verify no attempt to access series beyond the count
                                                          verify(dataset, times(seriesCount)).getValue(anyInt(), anyInt());
                                                      }

 @Test
                                                  public void testIterateRangeBounds_ShouldNotExceedSeriesCount() {
                                                      // Create a mock CategoryDataset with exactly 3 rows and 2 columns
                                                      CategoryDataset dataset = mock(CategoryDataset.class);
                                                      when(dataset.getRowCount()).thenReturn(3);
                                                      when(dataset.getColumnCount()).thenReturn(2);
                                                      
                                                      // Setup values - we'll use simple increasing values to make verification easy
                                                      when(dataset.getValue(0, 0)).thenReturn(1.0);
                                                      when(dataset.getValue(0, 1)).thenReturn(2.0);
                                                      when(dataset.getValue(1, 0)).thenReturn(3.0);
                                                      when(dataset.getValue(1, 1)).thenReturn(4.0);
                                                      when(dataset.getValue(2, 0)).thenReturn(5.0);
                                                      when(dataset.getValue(2, 1)).thenReturn(6.0);
                                                      
                                                      // Execute the method
                                                      Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                      
                                                      // Verify the result
                                                      assertNotNull(result);
                                                      assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                      assertEquals(6.0, result.getUpperBound(), 0.0001);
                                                      
                                                      // Verify no extra calls were made (would throw IndexOutOfBounds if mutant was present)
                                                      verify(dataset, times(6)).getValue(anyInt(), anyInt());
                                                      verify(dataset, never()).getValue(eq(3), anyInt()); // Should never try to access row 3
                                                  }

 @Test
                                                      public void testIterateRangeBounds_ShouldNotExceedSeriesCount1() {
                                                          // Create a mock XYDataset with 3 series
                                                          XYDataset dataset = mock(XYDataset.class);
                                                          when(dataset.getSeriesCount()).thenReturn(3);
                                                          
                                                          // Setup mock values for each series
                                                          when(dataset.getItemCount(anyInt())).thenReturn(2);
                                                          when(dataset.getYValue(0, 0)).thenReturn(1.0);
                                                          when(dataset.getYValue(0, 1)).thenReturn(2.0);
                                                          when(dataset.getYValue(1, 0)).thenReturn(3.0);
                                                          when(dataset.getYValue(1, 1)).thenReturn(4.0);
                                                          when(dataset.getYValue(2, 0)).thenReturn(5.0);
                                                          when(dataset.getYValue(2, 1)).thenReturn(6.0);
                                                          
                                                          // This test will fail if the mutant is present because:
                                                          // 1. It would try to access series index 3 (which doesn't exist)
                                                          // 2. Might throw ArrayIndexOutOfBoundsException
                                                          Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                          
                                                          // Verify the range is correctly calculated from series 0-2
                                                          assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                          assertEquals(6.0, result.getUpperBound(), 0.0001);
                                                      }

 @Test
                                                      public void testIterateRangeBounds_WithEmptyDataset() {
                                                          // Test edge case with 0 series
                                                          XYDataset emptyDataset = mock(XYDataset.class);
                                                          when(emptyDataset.getSeriesCount()).thenReturn(0);
                                                          
                                                          // Should return null for empty dataset (common behavior in JFreeChart)
                                                          Range result = DatasetUtilities.iterateRangeBounds(emptyDataset);
                                                          
                                                          assertNull(result);
                                                      }

 @Test
                                                      public void testIterateRangeBounds_WithSingleSeries() {
                                                          // Test edge case with 1 series
                                                          XYDataset singleSeriesDataset = mock(XYDataset.class);
                                                          when(singleSeriesDataset.getSeriesCount()).thenReturn(1);
                                                          when(singleSeriesDataset.getItemCount(0)).thenReturn(2);
                                                          when(singleSeriesDataset.getYValue(0, 0)).thenReturn(10.0);
                                                          when(singleSeriesDataset.getYValue(0, 1)).thenReturn(20.0);
                                                          
                                                          Range result = DatasetUtilities.iterateRangeBounds(singleSeriesDataset);
                                                          
                                                          // Verify correct range from single series
                                                          assertEquals(10.0, result.getLowerBound(), 0.0001);
                                                          assertEquals(20.0, result.getUpperBound(), 0.0001);
                                                      }

 @Test(expected = IndexOutOfBoundsException.class)
                                                 public void testIterateRangeBoundsWithSeriesCountMutation() {
                                                     // Create mock XYDataset
                                                     XYDataset mockDataset = mock(XYDataset.class);
                                                     
                                                     // Setup mock dataset with 1 series and 1 item
                                                     when(mockDataset.getSeriesCount()).thenReturn(1);
                                                     when(mockDataset.getItemCount(0)).thenReturn(1);
                                                     when(mockDataset.getYValue(0, 0)).thenReturn(5.0);
                                                 
                                                     // The mutant will try to access series index 1 (which doesn't exist)
                                                     // due to the changed loop condition (series <= seriesCount)
                                                     // This should throw ArrayIndexOutOfBoundsException with the mutant
                                                     DatasetUtilities.iterateRangeBounds(mockDataset);
                                                 }

 @Test
                                                 public void testIterateRangeBoundsWithEmptyDataset() {
                                                     // Setup mock dataset
                                                     XYDataset mockDataset = mock(XYDataset.class);
                                                     
                                                     // Setup empty dataset (0 series)
                                                     when(mockDataset.getSeriesCount()).thenReturn(0);
                                                 
                                                     // Original code should handle this correctly (return null)
                                                     // Mutant would try to access series index 0 (series <= 0)
                                                     Range result = DatasetUtilities.iterateRangeBounds(mockDataset);
                                                     assertNull(result);
                                                 }

 @Test
                                                 public void testIterateRangeBoundsWithSingleSeries() {
                                                     // Create mock XYDataset
                                                     XYDataset mockDataset = mock(XYDataset.class);
                                                     
                                                     // Setup dataset with 1 series and 2 items
                                                     when(mockDataset.getSeriesCount()).thenReturn(1);
                                                     when(mockDataset.getItemCount(0)).thenReturn(2);
                                                     when(mockDataset.getYValue(0, 0)).thenReturn(2.0);
                                                     when(mockDataset.getYValue(0, 1)).thenReturn(8.0);
                                                 
                                                     // Original code should return Range(2.0, 8.0)
                                                     // Mutant would try to access series index 1 (causing exception)
                                                     Range result = DatasetUtilities.iterateRangeBounds(mockDataset);
                                                     assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                     assertEquals(8.0, result.getUpperBound(), 0.0001);
                                                 }

 @Test
                                             public void testIterateRangeBoundsWithDifferentSeriesItemCounts() {
                                                 // Create a mock XYDataset where series have different item counts
                                                 XYDataset dataset = mock(XYDataset.class);
                                                 
                                                 // Setup series counts
                                                 when(dataset.getSeriesCount()).thenReturn(2);
                                                 
                                                 // Setup different item counts for each series
                                                 when(dataset.getItemCount(0)).thenReturn(2);  // Series 0 has 2 items
                                                 when(dataset.getItemCount(1)).thenReturn(3);  // Series 1 has 3 items
                                                 
                                                 // Setup Y values - we'll use simple increasing values
                                                 when(dataset.getYValue(0, 0)).thenReturn(1.0);
                                                 when(dataset.getYValue(0, 1)).thenReturn(2.0);
                                                 when(dataset.getYValue(1, 0)).thenReturn(3.0);
                                                 when(dataset.getYValue(1, 1)).thenReturn(4.0);
                                                 when(dataset.getYValue(1, 2)).thenReturn(5.0);  // This item would be missed by the mutant
                                                 
                                                 // All values are valid (not NaN)
                                                 when(dataset.getYValue(anyInt(), anyInt())).thenReturn(1.0); // default
                                                 
                                                 // Execute
                                                 Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                 
                                                 // Verify - should include all items from all series
                                                 assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                 assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                 
                                                 // Additional verification - ensure all items were accessed
                                                 verify(dataset).getYValue(0, 0);
                                                 verify(dataset).getYValue(0, 1);
                                                 verify(dataset).getYValue(1, 0);
                                                 verify(dataset).getYValue(1, 1);
                                                 verify(dataset).getYValue(1, 2);
                                             }

 @Test
                                            public void testIterateRangeBoundsWithVaryingSeriesSizes() {
                                                // Create a mock CategoryDataset where different series have different sizes
                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                
                                                // Setup mock behavior
                                                when(dataset.getRowCount()).thenReturn(3); // 3 series
                                                when(dataset.getColumnCount()).thenReturn(2); // 2 columns
                                                
                                                // Setup values for all series and columns
                                                // Series 0
                                                when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                when(dataset.getValue(0, 1)).thenReturn(7.0);
                                                
                                                // Series 1 (has the min and max values)
                                                when(dataset.getValue(1, 0)).thenReturn(5.0);
                                                when(dataset.getValue(1, 1)).thenReturn(10.0);
                                                
                                                // Series 2
                                                when(dataset.getValue(2, 0)).thenReturn(15.0);
                                                when(dataset.getValue(2, 1)).thenReturn(12.0);
                                                
                                                // Call the method
                                                Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                                
                                                // Verify the range includes all values
                                                assertNotNull(result);
                                                assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                assertEquals(15.0, result.getUpperBound(), 0.0001);
                                                
                                                // Verify the correct methods were called
                                                verify(dataset).getRowCount();
                                                verify(dataset).getColumnCount();
                                                verify(dataset, atLeastOnce()).getValue(anyInt(), anyInt());
                                            }

 @Test
                                            public void testIterateRangeBoundsWithDifferentSeriesItemCounts1() {
                                                // Create a mock dataset where series have different item counts
                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                
                                                // Setup mock behavior
                                                when(dataset.getRowCount()).thenReturn(2); // 2 series
                                                when(dataset.getColumnCount()).thenReturn(3); // 3 categories
                                                
                                                // Setup values - series 0 has values 1.0, 2.0, 3.0
                                                when(dataset.getValue(0, 0)).thenReturn(1.0);
                                                when(dataset.getValue(0, 1)).thenReturn(2.0);
                                                when(dataset.getValue(0, 2)).thenReturn(3.0);
                                                
                                                // Series 1 has values 4.0, 5.0 (only 2 items)
                                                when(dataset.getValue(1, 0)).thenReturn(4.0);
                                                when(dataset.getValue(1, 1)).thenReturn(5.0);
                                                // For column 2 in series 1, return null since it has only 2 items
                                                when(dataset.getValue(1, 2)).thenReturn(null);
                                                
                                                // Expected range should be from 1.0 to 5.0 (all values considered)
                                                Range expected = new Range(1.0, 5.0);
                                                
                                                // Test the method
                                                Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                                
                                                // Verify the result
                                                assertEquals("Range should include all values from all series", 
                                                             expected, result);
                                                
                                                // Verify that getValue was called for each series and column
                                                verify(dataset, atLeastOnce()).getValue(0, 0);
                                                verify(dataset, atLeastOnce()).getValue(0, 1);
                                                verify(dataset, atLeastOnce()).getValue(0, 2);
                                                verify(dataset, atLeastOnce()).getValue(1, 0);
                                                verify(dataset, atLeastOnce()).getValue(1, 1);
                                            }

 @Test
                                public void testIterateRangeBoundsWithMultipleSeries() {
                                    // Create a mock CategoryDataset with 2 series
                                    CategoryDataset dataset = mock(CategoryDataset.class);
                                    
                                    // Series 0 has 2 items, Series 1 has 3 items
                                    when(dataset.getRowCount()).thenReturn(2);
                                    when(dataset.getColumnCount()).thenReturn(3); // Maximum column count across all series
                                    
                                    // Setup values - the range should be determined by series 1's values
                                    when(dataset.getValue(0, 0)).thenReturn(5.0);
                                    when(dataset.getValue(0, 1)).thenReturn(10.0);
                                    when(dataset.getValue(1, 0)).thenReturn(1.0);  // min value
                                    when(dataset.getValue(1, 1)).thenReturn(20.0); // max value
                                    when(dataset.getValue(1, 2)).thenReturn(15.0);
                                    
                                    // Test the method
                                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                    
                                    // Verify the range includes all values (1.0 to 20.0)
                                    assertEquals(1.0, result.getLowerBound(), 0.0001);
                                    assertEquals(20.0, result.getUpperBound(), 0.0001);
                                    
                                    // Verify the correct column count was queried
                                    verify(dataset).getColumnCount();
                                }

 @Test
                            public void testIterateRangeBoundsWithMultipleSeries1() {
                                // Create a mock XYDataset with 2 series
                                XYDataset dataset = mock(XYDataset.class);
                                
                                // Configure mock behavior
                                when(dataset.getSeriesCount()).thenReturn(2);
                                
                                // Series 0 has items with Y values 10, 20
                                when(dataset.getItemCount(0)).thenReturn(2);
                                when(dataset.getYValue(0, 0)).thenReturn(10.0);
                                when(dataset.getYValue(0, 1)).thenReturn(20.0);
                                
                                // Series 1 has items with Y values 5, 25 (min=5, max=25)
                                when(dataset.getItemCount(1)).thenReturn(2);
                                when(dataset.getYValue(1, 0)).thenReturn(5.0);
                                when(dataset.getYValue(1, 1)).thenReturn(25.0);
                                
                                // Call the method under test
                                Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                
                                // Verify the range contains the correct min/max across all series
                                assertEquals(5.0, result.getLowerBound(), 0.0001);
                                assertEquals(25.0, result.getUpperBound(), 0.0001);
                                
                                // Verify interactions with the mock
                                verify(dataset).getSeriesCount();
                                verify(dataset).getItemCount(0);
                                verify(dataset).getItemCount(1);
                                verify(dataset, atLeastOnce()).getYValue(0, 0);
                                verify(dataset, atLeastOnce()).getYValue(0, 1);
                                verify(dataset, atLeastOnce()).getYValue(1, 0);
                                verify(dataset, atLeastOnce()).getYValue(1, 1);
                            }

 @Test
                            public void testIterateRangeBoundsWithMultipleSeries2() {
                                // Create a mock XYDataset with multiple series
                                XYDataset dataset = mock(XYDataset.class);
                                
                                // Setup mock behavior
                                when(dataset.getSeriesCount()).thenReturn(2);
                                when(dataset.getItemCount(0)).thenReturn(2);
                                when(dataset.getItemCount(1)).thenReturn(2);
                                
                                // Series 0 values (should be ignored in mutated version)
                                when(dataset.getYValue(0, 0)).thenReturn(10.0);
                                when(dataset.getYValue(0, 1)).thenReturn(20.0);
                                
                                // Series 1 values (should be used in original version)
                                when(dataset.getYValue(1, 0)).thenReturn(5.0);
                                when(dataset.getYValue(1, 1)).thenReturn(25.0);
                                
                                // Test with includeInterval=false
                                Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                                
                                // Original behavior should return range 5.0-25.0 (from series 1)
                                // Mutated behavior would return range 10.0-20.0 (from series 0)
                                assertEquals("Range minimum should be from series 1", 5.0, result.getLowerBound(), 0.0001);
                                assertEquals("Range maximum should be from series 1", 25.0, result.getUpperBound(), 0.0001);
                                
                                // Test with includeInterval=true
                                // Create a mock IntervalXYDataset
                                IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
                                when(intervalDataset.getSeriesCount()).thenReturn(2);
                                when(intervalDataset.getItemCount(0)).thenReturn(2);
                                when(intervalDataset.getItemCount(1)).thenReturn(2);
                                
                                // Series 0 interval values
                                when(intervalDataset.getYValue(0, 0)).thenReturn(10.0);
                                when(intervalDataset.getStartYValue(0, 0)).thenReturn(8.0);
                                when(intervalDataset.getEndYValue(0, 0)).thenReturn(12.0);
                                when(intervalDataset.getYValue(0, 1)).thenReturn(20.0);
                                when(intervalDataset.getStartYValue(0, 1)).thenReturn(18.0);
                                when(intervalDataset.getEndYValue(0, 1)).thenReturn(22.0);
                                
                                // Series 1 interval values
                                when(intervalDataset.getYValue(1, 0)).thenReturn(5.0);
                                when(intervalDataset.getStartYValue(1, 0)).thenReturn(4.0);
                                when(intervalDataset.getEndYValue(1, 0)).thenReturn(6.0);
                                when(intervalDataset.getYValue(1, 1)).thenReturn(25.0);
                                when(intervalDataset.getStartYValue(1, 1)).thenReturn(24.0);
                                when(intervalDataset.getEndYValue(1, 1)).thenReturn(26.0);
                                
                                Range intervalResult = DatasetUtilities.iterateRangeBounds(intervalDataset, true);
                                
                                // Original behavior should consider all series (4.0-26.0)
                                // Mutated behavior would only consider series 0 (8.0-22.0)
                                assertEquals("Interval range minimum should consider all series", 4.0, intervalResult.getLowerBound(), 0.0001);
                                assertEquals("Interval range maximum should consider all series", 26.0, intervalResult.getUpperBound(), 0.0001);
                            }

 @Test
                            public void testIterateRangeBoundsWithMultipleSeries3() {
                                // Create a mock XYDataset with 2 series
                                XYDataset dataset = mock(XYDataset.class);
                                
                                // Configure the mock
                                when(dataset.getSeriesCount()).thenReturn(2);
                                when(dataset.getItemCount(0)).thenReturn(2);
                                when(dataset.getItemCount(1)).thenReturn(2);
                                
                                // Series 0 has values [1.0, 2.0]
                                when(dataset.getYValue(0, 0)).thenReturn(1.0);
                                when(dataset.getYValue(0, 1)).thenReturn(2.0);
                                
                                // Series 1 has values [0.5, 3.0] - contains both min and max
                                when(dataset.getYValue(1, 0)).thenReturn(0.5);
                                when(dataset.getYValue(1, 1)).thenReturn(3.0);
                                
                                // Call the method under test
                                Range result = DatasetUtilities.iterateRangeBounds(dataset);
                                
                                // Verify the range includes the true min (0.5) and max (3.0)
                                assertEquals(0.5, result.getLowerBound(), 0.0001);
                                assertEquals(3.0, result.getUpperBound(), 0.0001);
                                
                                // Additional verification that the range is correct
                                assertTrue(result.contains(0.5));
                                assertTrue(result.contains(3.0));
                                assertFalse(result.contains(0.4));
                                assertFalse(result.contains(3.1));
                            }

 @Test
                            public void testIterateRangeBounds_DetectsSeries0Mutant() {
                                // Create mock IntervalXYDataset with 2 series
                                IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                                
                                // Setup series counts
                                when(dataset.getSeriesCount()).thenReturn(2);
                                when(dataset.getItemCount(0)).thenReturn(1);
                                when(dataset.getItemCount(1)).thenReturn(1);
                                
                                // Series 0 values (not min/max)
                                when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                when(dataset.getStartYValue(0, 0)).thenReturn(4.0);
                                when(dataset.getEndYValue(0, 0)).thenReturn(6.0);
                                
                                // Series 1 values (contains actual min and max)
                                when(dataset.getYValue(1, 0)).thenReturn(3.0);  // min
                                when(dataset.getStartYValue(1, 0)).thenReturn(2.0);
                                when(dataset.getEndYValue(1, 0)).thenReturn(7.0);  // max
                                
                                // Call method with includeInterval=true
                                Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                
                                // Verify correct range is calculated from all series
                                assertEquals(2.0, result.getLowerBound(), 0.0001);  // min from series 1
                                assertEquals(7.0, result.getUpperBound(), 0.0001);  // max from series 1
                                
                                // Verify all series were accessed
                                verify(dataset).getYValue(0, 0);
                                verify(dataset).getYValue(1, 0);
                            }

 @Test
                           public void testIterateRangeBounds_DetectsMutatedStartValueAccess() {
                               // Create a mock IntervalCategoryDataset with different start values per series
                               IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                               
                               // Setup dataset with 2 series and 2 items
                               when(dataset.getRowCount()).thenReturn(2);
                               when(dataset.getColumnCount()).thenReturn(2);
                               
                               // Setup values - all non-null and valid
                               when(dataset.getValue(anyInt(), anyInt())).thenReturn(5.0);
                               
                               // Setup start values - different per series
                               when(dataset.getStartValue(0, 0)).thenReturn(1.0);  // series 0, item 0
                               when(dataset.getStartValue(0, 1)).thenReturn(2.0);  // series 0, item 1
                               when(dataset.getStartValue(1, 0)).thenReturn(3.0);  // series 1, item 0 (should be included)
                               when(dataset.getStartValue(1, 1)).thenReturn(4.0);  // series 1, item 1 (should be included)
                               
                               // Setup end values - all same for simplicity
                               when(dataset.getEndValue(anyInt(), anyInt())).thenReturn(10.0);
                               
                               // Call method with includeInterval=true
                               Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                               
                               // Verify the range includes the minimum start value (should be 1.0)
                               // If mutant is present, it would miss series 1 values and might return wrong range
                               assertEquals(1.0, result.getLowerBound(), 0.0001);
                               assertEquals(10.0, result.getUpperBound(), 0.0001);
                               
                               // Additional verification that all series were considered
                               // The mutant would only check series 0, missing the 3.0 and 4.0 values
                               verify(dataset, times(4)).getStartValue(anyInt(), anyInt());
                           }

 @Test
                           public void testIterateRangeBoundsWithMultipleSeriesIntervalXYDataset() {
                               // Create a mock IntervalXYDataset with 2 series
                               IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                               
                               // Setup series 0 with items
                               when(dataset.getSeriesCount()).thenReturn(2);
                               when(dataset.getItemCount(0)).thenReturn(2);
                               when(dataset.getYValue(0, 0)).thenReturn(5.0);
                               when(dataset.getStartYValue(0, 0)).thenReturn(4.0);
                               when(dataset.getEndYValue(0, 0)).thenReturn(6.0);
                               when(dataset.getYValue(0, 1)).thenReturn(7.0);
                               when(dataset.getStartYValue(0, 1)).thenReturn(6.0);
                               when(dataset.getEndYValue(0, 1)).thenReturn(8.0);
                               
                               // Setup series 1 with different values
                               when(dataset.getItemCount(1)).thenReturn(2);
                               when(dataset.getYValue(1, 0)).thenReturn(3.0);
                               when(dataset.getStartYValue(1, 0)).thenReturn(2.0); // This value should be considered in original
                               when(dataset.getEndYValue(1, 0)).thenReturn(4.0);
                               when(dataset.getYValue(1, 1)).thenReturn(1.0);
                               when(dataset.getStartYValue(1, 1)).thenReturn(0.0); // This value should be considered in original
                               when(dataset.getEndYValue(1, 1)).thenReturn(2.0);
                               
                               // Call the method with includeInterval=true
                               Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                               
                               // Verify the range includes values from all series
                               // Original should find min=0.0 (from series 1), max=8.0 (from series 0)
                               // Mutant would find min=4.0 (only from series 0), max=8.0
                               assertEquals(0.0, result.getLowerBound(), 0.0001);
                               assertEquals(8.0, result.getUpperBound(), 0.0001);
                           }

 @Test
                          public void testIterateRangeBounds_DetectsSeriesSpecificMutation() {
                              // Create a mock XYDataset with 2 series
                              XYDataset dataset = mock(XYDataset.class);
                              
                              // Setup series count
                              when(dataset.getSeriesCount()).thenReturn(2);
                              
                              // Setup item counts - 2 items per series
                              when(dataset.getItemCount(0)).thenReturn(2);
                              when(dataset.getItemCount(1)).thenReturn(2);
                              
                              // Setup Y values - series 0 has values 10,20; series 1 has values 30,40
                              when(dataset.getYValue(0, 0)).thenReturn(10.0);
                              when(dataset.getYValue(0, 1)).thenReturn(20.0);
                              when(dataset.getYValue(1, 0)).thenReturn(30.0);
                              when(dataset.getYValue(1, 1)).thenReturn(40.0);
                              
                              // Call the method under test
                              Range result = DatasetUtilities.iterateRangeBounds(dataset);
                              
                              // Verify the range includes all values (10-40)
                              assertEquals(10.0, result.getLowerBound(), 0.0001);
                              assertEquals(40.0, result.getUpperBound(), 0.0001);
                              
                              // Additional verification that both series were considered
                              // The mutant would only consider series 0 (10-20)
                              verify(dataset, times(1)).getYValue(0, 0);
                              verify(dataset, times(1)).getYValue(0, 1);
                              verify(dataset, times(1)).getYValue(1, 0);
                              verify(dataset, times(1)).getYValue(1, 1);
                          }

 @Test
                          public void testIterateRangeBounds_DetectsSeriesSpecificYValues() {
                              // Create a mock XYDataset with 2 series
                              XYDataset dataset = mock(XYDataset.class);
                              
                              // Configure series count
                              when(dataset.getSeriesCount()).thenReturn(2);
                              
                              // Configure item counts
                              when(dataset.getItemCount(0)).thenReturn(2);
                              when(dataset.getItemCount(1)).thenReturn(2);
                              
                              // Configure Y values - series 0 has higher values than series 1
                              when(dataset.getYValue(0, 0)).thenReturn(10.0);
                              when(dataset.getYValue(0, 1)).thenReturn(20.0);
                              when(dataset.getYValue(1, 0)).thenReturn(5.0);  // This should be the real min
                              when(dataset.getYValue(1, 1)).thenReturn(25.0); // This should be the real max
                              
                              // Expected range should be from 5.0 to 25.0 (across all series)
                              Range expected = new Range(5.0, 25.0);
                              
                              // Call the method under test
                              Range result = DatasetUtilities.iterateRangeBounds(dataset);
                              
                              // Verify the range matches expected values
                              assertEquals("Lower bound should come from series 1", 
                                  expected.getLowerBound(), result.getLowerBound(), 0.0001);
                              assertEquals("Upper bound should come from series 1", 
                                  expected.getUpperBound(), result.getUpperBound(), 0.0001);
                              
                              // Verify interactions with the mock
                              verify(dataset).getSeriesCount();
                              verify(dataset, atLeastOnce()).getItemCount(anyInt());
                              verify(dataset, atLeastOnce()).getYValue(anyInt(), anyInt());
                          }

 @Test
                      public void testIterateRangeBounds_MultipleSeries_DifferentEndYValues() {
                          // Create mock XYDataset with multiple series having different end Y values
                          IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                          
                          // Setup dataset behavior
                          when(dataset.getSeriesCount()).thenReturn(2);
                          
                          // Series 0 has end Y values between 10-20
                          when(dataset.getItemCount(0)).thenReturn(2);
                          when(dataset.getEndYValue(0, 0)).thenReturn(10.0);
                          when(dataset.getEndYValue(0, 1)).thenReturn(20.0);
                          
                          // Series 1 has end Y values between 30-40 (different from series 0)
                          when(dataset.getItemCount(1)).thenReturn(2);
                          when(dataset.getEndYValue(1, 0)).thenReturn(30.0);
                          when(dataset.getEndYValue(1, 1)).thenReturn(40.0);
                          
                          // Call the method under test
                          Range result = DatasetUtilities.iterateRangeBounds(dataset);
                          
                          // Verify the range includes all values (10-40)
                          assertEquals(10.0, result.getLowerBound(), 0.0001);
                          assertEquals(40.0, result.getUpperBound(), 0.0001);
                          
                          // Additional verification that both series were considered
                          verify(dataset).getEndYValue(0, 0);
                          verify(dataset).getEndYValue(0, 1);
                          verify(dataset).getEndYValue(1, 0);
                          verify(dataset).getEndYValue(1, 1);
                      }

 @Test
                      public void testIterateRangeBounds_DetectMutatedEndValueAccess() {
                          // Create a mock IntervalCategoryDataset with 2 series
                          IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                          
                          // Setup mock behavior
                          when(dataset.getRowCount()).thenReturn(2); // 2 series
                          when(dataset.getColumnCount()).thenReturn(1); // 1 item per series
                          
                          // Series 0 values - shouldn't affect the range in this test
                          when(dataset.getValue(0, 0)).thenReturn(5.0);
                          when(dataset.getStartValue(0, 0)).thenReturn(4.0);
                          when(dataset.getEndValue(0, 0)).thenReturn(6.0);
                          
                          // Series 1 values - should affect the range (but won't with the mutation)
                          when(dataset.getValue(1, 0)).thenReturn(10.0);
                          when(dataset.getStartValue(1, 0)).thenReturn(9.0);
                          when(dataset.getEndValue(1, 0)).thenReturn(11.0); // This should be included in range
                          
                          // Call method with includeInterval=true
                          Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                          
                          // Verify the range includes the end value from series 1
                          // Original code should return range 4.0-11.0
                          // Mutated code would return range 4.0-6.0 (missing series 1 end value)
                          assertEquals(4.0, result.getLowerBound(), 0.0001);
                          assertEquals(11.0, result.getUpperBound(), 0.0001);
                      }

 @Test
                      public void testIterateRangeBounds_DetectsMutatedSeriesIndex() {
                          // Create a mock XYDataset with 2 series having different Y values
                          XYDataset dataset = mock(XYDataset.class);
                          
                          // Configure series count
                          when(dataset.getSeriesCount()).thenReturn(2);
                          
                          // Configure item counts
                          when(dataset.getItemCount(0)).thenReturn(2);
                          when(dataset.getItemCount(1)).thenReturn(2);
                          
                          // Configure Y values - series 0 has low values, series 1 has high values
                          when(dataset.getYValue(0, 0)).thenReturn(1.0);
                          when(dataset.getYValue(0, 1)).thenReturn(2.0);
                          when(dataset.getYValue(1, 0)).thenReturn(10.0);
                          when(dataset.getYValue(1, 1)).thenReturn(20.0);
                          
                          // Configure interval dataset behavior (since includeInterval=true)
                          IntervalXYDataset ixyd = mock(IntervalXYDataset.class);
                          when(dataset instanceof IntervalXYDataset).thenReturn(true);
                          
                          // Configure end Y values - series 0 has low values, series 1 has high values
                          when(ixyd.getEndYValue(0, 0)).thenReturn(1.5);
                          when(ixyd.getEndYValue(0, 1)).thenReturn(2.5);
                          when(ixyd.getEndYValue(1, 0)).thenReturn(15.0);
                          when(ixyd.getEndYValue(1, 1)).thenReturn(25.0);
                          
                          // Calculate range bounds
                          Range result = DatasetUtilities.iterateRangeBounds(dataset);
                          
                          // Verify the range includes values from all series
                          // Original should be 1.0-25.0, mutant would be 1.0-2.5
                          assertEquals(1.0, result.getLowerBound(), 0.0001);
                          assertEquals(25.0, result.getUpperBound(), 0.0001);
                      }

 @Test
                      public void testIterateRangeBounds_IntervalXYDatasetWithMultipleSeries_ShouldConsiderAllSeriesEndYValues() {
                          // Create mock IntervalXYDataset with 2 series
                          IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                          
                          // Setup series counts
                          when(dataset.getSeriesCount()).thenReturn(2);
                          when(dataset.getItemCount(0)).thenReturn(1);
                          when(dataset.getItemCount(1)).thenReturn(1);
                          
                          // Setup values - make sure series 1 has different end Y value
                          when(dataset.getYValue(0, 0)).thenReturn(5.0);
                          when(dataset.getStartYValue(0, 0)).thenReturn(4.0);
                          when(dataset.getEndYValue(0, 0)).thenReturn(6.0);  // series 0 end Y
                          
                          when(dataset.getYValue(1, 0)).thenReturn(8.0);
                          when(dataset.getStartYValue(1, 0)).thenReturn(7.0);
                          when(dataset.getEndYValue(1, 0)).thenReturn(10.0); // series 1 end Y (different)
                          
                          // Call method with includeInterval=true
                          Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                          
                          // Verify range considers all end Y values (should be 4-10)
                          assertEquals(4.0, result.getLowerBound(), 0.0001);
                          assertEquals(10.0, result.getUpperBound(), 0.0001);
                          
                          // The mutant would only consider series 0's end Y (6.0), so upper bound would be 8.0
                          // (from series 1's Y value) instead of 10.0
                      }

 @Test
                     public void testIterateRangeBounds_ShouldIgnoreNaNValues() {
                         // Create a mock CategoryDataset with some valid values and NaN
                         CategoryDataset dataset = mock(CategoryDataset.class);
                         
                         // Setup mock behavior
                         when(dataset.getRowCount()).thenReturn(1);
                         when(dataset.getColumnCount()).thenReturn(3);
                         
                         // First two columns have valid numbers, third has NaN
                         when(dataset.getValue(0, 0)).thenReturn(5.0);
                         when(dataset.getValue(0, 1)).thenReturn(10.0);
                         when(dataset.getValue(0, 2)).thenReturn(Double.NaN);
                         
                         // Call the method under test
                         Range result = DatasetUtilities.iterateRangeBounds(dataset);
                         
                         // Verify the range only includes the valid numbers (5-10)
                         assertNotNull("Result should not be null", result);
                         assertEquals("Lower bound should be 5", 5.0, result.getLowerBound(), 0.0001);
                         assertEquals("Upper bound should be 10", 10.0, result.getUpperBound(), 0.0001);
                         
                         // This test will fail if the mutant is present because:
                         // - Original code ignores NaN, producing range 5-10
                         // - Mutant includes NaN, which would make the range invalid or throw exception
                     }

 @Test
                     public void testIterateRangeBoundsWithNaNStartValues() {
                         // Create mock IntervalCategoryDataset
                         IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                         when(dataset.getRowCount()).thenReturn(1);
                         when(dataset.getColumnCount()).thenReturn(1);
                         
                         // Setup values - regular value is valid, start value is NaN
                         when(dataset.getValue(0, 0)).thenReturn(5.0);
                         when(dataset.getStartValue(0, 0)).thenReturn(Double.NaN);
                         when(dataset.getEndValue(0, 0)).thenReturn(10.0);
                         
                         // Call method with includeInterval=true
                         Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                         
                         // Verify correct behavior (should ignore NaN start value)
                         assertNotNull(result);
                         assertEquals(5.0, result.getLowerBound(), 0.0001);
                         assertEquals(10.0, result.getUpperBound(), 0.0001);
                         
                         // This test would fail with the mutant since it would try to process NaN
                         // The mutant would likely throw an exception or return incorrect bounds
                     }

 @Test
                         public void testIterateRangeBoundsShouldExcludeNaNValues() {
                             // Create a mock dataset that returns some valid numbers and NaN
                             CategoryDataset dataset = mock(CategoryDataset.class);
                             when(dataset.getRowCount()).thenReturn(1);
                             when(dataset.getColumnCount()).thenReturn(2);
                             when(dataset.getValue(0, 0)).thenReturn(5.0);  // valid number
                             when(dataset.getValue(0, 1)).thenReturn(Double.NaN);  // NaN value
                     
                             // Call the method under test
                             Range result = DatasetUtilities.iterateRangeBounds(dataset);
                     
                             // Verify the result excludes NaN (lower bound should be 5.0)
                             assertNotNull("Result should not be null", result);
                             assertEquals("Lower bound should be 5.0", 
                                 5.0, result.getLowerBound(), 0.0001);
                             assertEquals("Upper bound should be 5.0", 
                                 5.0, result.getUpperBound(), 0.0001);
                             
                             // The mutant version would potentially include NaN in calculations,
                             // which would make the bounds incorrect (possibly NaN or different range)
                         }

 @Test
                     public void testIterateRangeBoundsWithOHLCDatasetContainingNaNLowValues() {
                         // Create a mock OHLCDataset with NaN low values
                         OHLCDataset dataset = mock(OHLCDataset.class);
                         when(dataset.getSeriesCount()).thenReturn(1);
                         when(dataset.getItemCount(0)).thenReturn(2);
                         
                         // First item has valid low and high values
                         when(dataset.getLowValue(0, 0)).thenReturn(10.0);
                         when(dataset.getHighValue(0, 0)).thenReturn(20.0);
                         
                         // Second item has NaN low value and valid high value
                         when(dataset.getLowValue(0, 1)).thenReturn(Double.NaN);
                         when(dataset.getHighValue(0, 1)).thenReturn(30.0);
                         
                         // Call the method with includeInterval=true
                         Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                         
                         // Verify the range only includes the valid values (10.0-30.0)
                         // If the mutant is present, it might incorrectly try to include NaN in calculations
                         assertEquals(10.0, result.getLowerBound(), 0.0001);
                         assertEquals(30.0, result.getUpperBound(), 0.0001);
                         
                         // Additional verification that NaN wasn't incorrectly included
                         assertFalse(Double.isNaN(result.getLowerBound()));
                         assertFalse(Double.isNaN(result.getUpperBound()));
                     }

 @Test
                    public void testIterateRangeBoundsOHLCDatasetCallsGetLowValueOnlyForNonNaN() {
                        OHLCDataset dataset = mock(OHLCDataset.class);
                        when(dataset.getSeriesCount()).thenReturn(1);
                        when(dataset.getItemCount(0)).thenReturn(2);
                        
                        // First item has valid low value
                        when(dataset.getLowValue(0, 0)).thenReturn(10.0);
                        when(dataset.getHighValue(0, 0)).thenReturn(20.0);
                        
                        // Second item has NaN low value
                        when(dataset.getLowValue(0, 1)).thenReturn(Double.NaN);
                        when(dataset.getHighValue(0, 1)).thenReturn(30.0);
                        
                        DatasetUtilities.iterateRangeBounds(dataset, true);
                        
                        // Verify getLowValue was called exactly twice (original would skip NaN)
                        verify(dataset, times(2)).getLowValue(anyInt(), anyInt());
                        
                        // For the mutant that changes to if(true), it would still call it twice in this case
                        // So we need a different approach
                        
                        // Alternative: verify behavior when all low values are NaN
                        reset(dataset);
                        when(dataset.getSeriesCount()).thenReturn(1);
                        when(dataset.getItemCount(0)).thenReturn(1);
                        when(dataset.getLowValue(0, 0)).thenReturn(Double.NaN);
                        when(dataset.getHighValue(0, 0)).thenReturn(30.0);
                        
                        Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                        assertEquals(30.0, result.getLowerBound(), 0.0001);
                        assertEquals(30.0, result.getUpperBound(), 0.0001);
                    }

 @Test
                public void testIterateRangeBoundsDetectsMaxMutation() {
                    // Create a mock CategoryDataset with known values
                    CategoryDataset dataset = mock(CategoryDataset.class);
                    
                    // Setup mock behavior
                    when(dataset.getRowCount()).thenReturn(2);
                    when(dataset.getColumnCount()).thenReturn(2);
                    
                    // Set values that will clearly show the mutation
                    // First row: 5.0, 10.0
                    // Second row: 15.0, 20.0
                    when(dataset.getValue(0, 0)).thenReturn(5.0);
                    when(dataset.getValue(0, 1)).thenReturn(10.0);
                    when(dataset.getValue(1, 0)).thenReturn(15.0);
                    when(dataset.getValue(1, 1)).thenReturn(20.0);
                    
                    // Call the method under test
                    Range result = DatasetUtilities.iterateRangeBounds(dataset);
                    
                    // Verify the maximum value is correctly calculated
                    // The expected maximum should be 20.0
                    // With the mutation (using Math.min), it would incorrectly return 5.0
                    assertEquals(20.0, result.getUpperBound(), 0.0001);
                    
                    // Also verify the minimum for completeness
                    assertEquals(5.0, result.getLowerBound(), 0.0001);
                }

 @Test
                public void testIterateRangeBounds_DetectMaxToMinMutant() {
                    // Create a mock IntervalCategoryDataset
                    IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                    
                    // Setup dataset behavior
                    when(dataset.getRowCount()).thenReturn(1);
                    when(dataset.getColumnCount()).thenReturn(1);
                    
                    // Main value is 5.0, start value is 10.0 (higher than main value), end value is 3.0
                    when(dataset.getValue(0, 0)).thenReturn(5.0);
                    when(dataset.getStartValue(0, 0)).thenReturn(10.0);
                    when(dataset.getEndValue(0, 0)).thenReturn(3.0);
                    
                    // Call method with includeInterval=true
                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                    
                    // Verify the range correctly includes the maximum value (10.0)
                    assertNotNull(result);
                    assertEquals(3.0, result.getLowerBound(), 0.0001);  // minimum should be 3.0
                    assertEquals(10.0, result.getUpperBound(), 0.0001); // maximum should be 10.0
                    
                    // This test would fail with the mutant since it would use Math.min instead of Math.max,
                    // causing the upper bound to be 5.0 (min between 5.0 and 10.0) instead of 10.0
                }

 @Test
                public void testIterateRangeBoundsDetectsMaxToMinMutant() {
                    // Create a mock CategoryDataset with known values
                    CategoryDataset dataset = mock(CategoryDataset.class);
                    
                    // Set up the mock to return 3 rows and 2 columns
                    when(dataset.getRowCount()).thenReturn(3);
                    when(dataset.getColumnCount()).thenReturn(2);
                    
                    // Set up values where the maximum is clearly 100.0
                    when(dataset.getValue(0, 0)).thenReturn(10.0);
                    when(dataset.getValue(0, 1)).thenReturn(20.0);
                    when(dataset.getValue(1, 0)).thenReturn(30.0);
                    when(dataset.getValue(1, 1)).thenReturn(40.0);
                    when(dataset.getValue(2, 0)).thenReturn(50.0);
                    when(dataset.getValue(2, 1)).thenReturn(100.0); // This is the max value
                    
                    // Call the method under test
                    Range result = DatasetUtilities.iterateRangeBounds(dataset);
                    
                    // Verify the upper bound is the maximum value (100.0)
                    // This will fail if the mutant using Math.min is present
                    assertEquals(100.0, result.getUpperBound(), 0.0001);
                    
                    // Also verify the lower bound for completeness
                    assertEquals(10.0, result.getLowerBound(), 0.0001);
                }

 @Test
                public void testIterateRangeBounds_IntervalXYDataset_DetectsMaxMutation() {
                    // Create mock IntervalXYDataset
                    IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                    
                    // Setup dataset behavior
                    when(dataset.getSeriesCount()).thenReturn(1);
                    when(dataset.getItemCount(0)).thenReturn(2);
                    
                    // First item values
                    when(dataset.getYValue(0, 0)).thenReturn(5.0);
                    when(dataset.getStartYValue(0, 0)).thenReturn(4.0); // lvalue
                    when(dataset.getEndYValue(0, 0)).thenReturn(6.0);   // uvalue
                    
                    // Second item with lvalue that should affect maximum
                    when(dataset.getYValue(0, 1)).thenReturn(7.0);
                    when(dataset.getStartYValue(0, 1)).thenReturn(8.0); // This lvalue should update maximum
                    when(dataset.getEndYValue(0, 1)).thenReturn(9.0);
                    
                    // Execute method
                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                    
                    // Verify results
                    assertNotNull(result);
                    assertEquals(4.0, result.getLowerBound(), 0.0001);  // Minimum from lvalue=4.0
                    assertEquals(9.0, result.getUpperBound(), 0.0001); // Maximum should be 9.0 (from uvalue)
                    // The mutant would make upper bound 7.0 (min of current max 7.0 and lvalue 8.0)
                }

 @Test
               public void testIterateRangeBoundsDetectsMaximumMutation() {
                   // Create a mock CategoryDataset where maximum isn't the last value
                   CategoryDataset dataset = mock(CategoryDataset.class);
                   
                   // Setup mock behavior - dataset with 2 rows and 2 columns
                   when(dataset.getRowCount()).thenReturn(2);
                   when(dataset.getColumnCount()).thenReturn(2);
                   
                   // Set values where maximum (5.0) is not the last value (3.0)
                   when(dataset.getValue(0, 0)).thenReturn(1.0);
                   when(dataset.getValue(0, 1)).thenReturn(5.0);  // This is the real maximum
                   when(dataset.getValue(1, 0)).thenReturn(2.0);
                   when(dataset.getValue(1, 1)).thenReturn(3.0);
                   
                   // Call the method
                   Range result = DatasetUtilities.iterateRangeBounds(dataset);
                   
                   // Verify the range contains the correct maximum (5.0)
                   assertEquals(5.0, result.getUpperBound(), 0.0001);
                   
                   // Also verify minimum for completeness
                   assertEquals(1.0, result.getLowerBound(), 0.0001);
               }

 @Test
               public void testIterateRangeBoundsDetectsMutatedMaxCalculation() {
                   // Create a mock IntervalCategoryDataset
                   IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                   
                   // Setup dataset dimensions
                   when(dataset.getRowCount()).thenReturn(2);
                   when(dataset.getColumnCount()).thenReturn(1);
                   
                   // Setup values - first row has larger start value than second
                   when(dataset.getValue(0, 0)).thenReturn(5.0);
                   when(dataset.getStartValue(0, 0)).thenReturn(10.0);  // This should be the max
                   when(dataset.getEndValue(0, 0)).thenReturn(15.0);
                   
                   when(dataset.getValue(1, 0)).thenReturn(7.0);
                   when(dataset.getStartValue(1, 0)).thenReturn(8.0);   // This is less than 10.0
                   when(dataset.getEndValue(1, 0)).thenReturn(12.0);
                   
                   // Call the method with includeInterval=true
                   Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                   
                   // Verify the range contains the correct min/max
                   // Original code would find max=15.0 (from end value), min=5.0
                   // Mutated code would incorrectly set max=8.0 when processing second row
                   assertEquals(5.0, result.getLowerBound(), 0.0001);
                   assertEquals(15.0, result.getUpperBound(), 0.0001);
               }

 @Test
               public void testIterateRangeBoundsDetectsMaximumMutation1() {
                   // Create a mock CategoryDataset where the maximum value is not the last one
                   CategoryDataset dataset = mock(CategoryDataset.class);
                   
                   // Setup dataset with 3 rows and 3 columns
                   when(dataset.getRowCount()).thenReturn(3);
                   when(dataset.getColumnCount()).thenReturn(3);
                   
                   // Set values where maximum (5.0) is in the middle
                   when(dataset.getValue(0, 0)).thenReturn(1.0);
                   when(dataset.getValue(0, 1)).thenReturn(2.0);
                   when(dataset.getValue(0, 2)).thenReturn(3.0);
                   when(dataset.getValue(1, 0)).thenReturn(4.0);
                   when(dataset.getValue(1, 1)).thenReturn(5.0);  // This is the maximum
                   when(dataset.getValue(1, 2)).thenReturn(3.5);
                   when(dataset.getValue(2, 0)).thenReturn(2.5);
                   when(dataset.getValue(2, 1)).thenReturn(1.5);
                   when(dataset.getValue(2, 2)).thenReturn(0.5);  // This is the last value
                   
                   // Call the method
                   Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                   
                   // Verify the range contains the correct maximum (5.0)
                   assertEquals(5.0, result.getUpperBound(), 0.0001);
                   
                   // Also verify the minimum for completeness
                   assertEquals(0.5, result.getLowerBound(), 0.0001);
               }

 @Test
               public void testIterateRangeBounds_IntervalXYDataset_MaximumCalculation() {
                   // Create mock IntervalXYDataset
                   IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                   
                   // Setup dataset behavior
                   when(dataset.getSeriesCount()).thenReturn(1);
                   when(dataset.getItemCount(0)).thenReturn(3);
                   
                   // Setup values where:
                   // - First item has lvalue = 5 (should become initial maximum)
                   // - Second item has lvalue = 3 (should NOT replace maximum)
                   // - Third item has lvalue = 7 (should become new maximum)
                   when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
                   when(dataset.getStartYValue(0, 0)).thenReturn(5.0);
                   when(dataset.getEndYValue(0, 0)).thenReturn(Double.NaN);
                   
                   when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
                   when(dataset.getStartYValue(0, 1)).thenReturn(3.0);
                   when(dataset.getEndYValue(0, 1)).thenReturn(Double.NaN);
                   
                   when(dataset.getYValue(0, 2)).thenReturn(Double.NaN);
                   when(dataset.getStartYValue(0, 2)).thenReturn(7.0);
                   when(dataset.getEndYValue(0, 2)).thenReturn(Double.NaN);
                   
                   // Call method with includeInterval=true
                   Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                   
                   // Verify maximum is correctly calculated as 7 (not 3)
                   assertNotNull(result);
                   assertEquals(3.0, result.getLowerBound(), 0.0001);  // minimum from lvalues
                   assertEquals(7.0, result.getUpperBound(), 0.0001);  // should be max of 5,3,7
               }

 @Test
              public void testIterateRangeBoundsWithNaNValues() {
                  // Create a mock CategoryDataset with NaN values
                  CategoryDataset dataset = mock(CategoryDataset.class);
                  when(dataset.getRowCount()).thenReturn(1);
                  when(dataset.getColumnCount()).thenReturn(2);
                  
                  // First value is valid, second is NaN
                  when(dataset.getValue(0, 0)).thenReturn(5.0);
                  when(dataset.getValue(0, 1)).thenReturn(Double.NaN);
                  
                  // Call the method under test
                  Range result = DatasetUtilities.iterateRangeBounds(dataset);
                  
                  // Verify the range only includes the valid value (5.0)
                  assertEquals(5.0, result.getLowerBound(), 0.0001);
                  assertEquals(5.0, result.getUpperBound(), 0.0001);
                  
                  // The mutant would include NaN in calculation and likely return an invalid range
                  // This assertion would fail if the mutant is present
              }

 @Test
              public void testIterateRangeBoundsWithNullAndNaNEndValues() {
                  // Create mock IntervalCategoryDataset
                  IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                  when(dataset.getRowCount()).thenReturn(1);
                  when(dataset.getColumnCount()).thenReturn(1);
                  
                  // Setup test data - valid value but null/NaN end values
                  when(dataset.getValue(0, 0)).thenReturn(5.0);
                  when(dataset.getStartValue(0, 0)).thenReturn(4.0);
                  when(dataset.getEndValue(0, 0)).thenReturn(null); // null end value
                  
                  // Call method with includeInterval=true
                  Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                  
                  // Verify correct range is returned (should ignore null end value)
                  assertEquals(4.0, result.getLowerBound(), 0.0001);
                  assertEquals(5.0, result.getUpperBound(), 0.0001);
                  
                  // Now test with NaN end value
                  when(dataset.getEndValue(0, 0)).thenReturn(Double.NaN);
                  result = DatasetUtilities.iterateRangeBounds(dataset, true);
                  assertEquals(4.0, result.getLowerBound(), 0.0001);
                  assertEquals(5.0, result.getUpperBound(), 0.0001);
                  
                  // Test case that would fail with the mutant:
                  // Only end value exists (null/NaN) - should return null
                  when(dataset.getValue(0, 0)).thenReturn(null);
                  when(dataset.getStartValue(0, 0)).thenReturn(null);
                  when(dataset.getEndValue(0, 0)).thenReturn(Double.NaN);
                  result = DatasetUtilities.iterateRangeBounds(dataset, true);
                  assertNull(result); // Original would return null, mutant might throw exception
              }

 @Test
                  public void testIterateRangeBoundsWithNaNValues1() {
                      // Create a mock dataset with NaN values
                      CategoryDataset dataset = mock(CategoryDataset.class);
                      when(dataset.getRowCount()).thenReturn(1);
                      when(dataset.getColumnCount()).thenReturn(2);
                      when(dataset.getValue(0, 0)).thenReturn(5.0);
                      when(dataset.getValue(0, 1)).thenReturn(Double.NaN);  // Include NaN value
                      
                      // Call the method
                      Range result = DatasetUtilities.iterateRangeBounds(dataset);
                      
                      // Verify the range only includes the valid number (5.0)
                      // The mutant would fail this test because it would include NaN in calculation
                      assertEquals(5.0, result.getLowerBound(), 0.0001);
                      assertEquals(5.0, result.getUpperBound(), 0.0001);
                      
                      // Verify interactions with the mock
                      verify(dataset).getRowCount();
                      verify(dataset).getColumnCount();
                      verify(dataset, times(2)).getValue(anyInt(), anyInt());
                  }

 @Test
              public void testIterateRangeBoundsWithOHLCDatasetContainingNaNHighValues() {
                  // Create a mock OHLCDataset with some NaN high values
                  OHLCDataset dataset = mock(OHLCDataset.class);
                  when(dataset.getSeriesCount()).thenReturn(1);
                  when(dataset.getItemCount(0)).thenReturn(2);
                  
                  // First item has valid low and NaN high
                  when(dataset.getLowValue(0, 0)).thenReturn(10.0);
                  when(dataset.getHighValue(0, 0)).thenReturn(Double.NaN);
                  
                  // Second item has valid low and high
                  when(dataset.getLowValue(0, 1)).thenReturn(5.0);
                  when(dataset.getHighValue(0, 1)).thenReturn(15.0);
                  
                  // Test with includeInterval=true to trigger OHLCDataset branch
                  Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                  
                  // Verify correct handling - NaN high value should be ignored
                  // Original behavior would give Range(5.0, 15.0)
                  // Mutated behavior might give incorrect maximum due to NaN processing
                  assertEquals(5.0, result.getLowerBound(), 0.0001);
                  assertEquals(15.0, result.getUpperBound(), 0.0001);
                  
                  // Additional verification that NaN wasn't processed
                  // If NaN was processed, maximum might be incorrect
                  assertFalse(Double.isNaN(result.getUpperBound()));
              }

 @Test
             public void testIterateRangeBounds_DetectsMaximumValueNotLast() {
                 // Create a mock CategoryDataset
                 CategoryDataset dataset = mock(CategoryDataset.class);
                 
                 // Setup dataset with 3 rows and 3 columns where maximum (5.0) is in the middle
                 when(dataset.getRowCount()).thenReturn(3);
                 when(dataset.getColumnCount()).thenReturn(3);
                 
                 // Setup values - maximum is 5.0 in the middle
                 when(dataset.getValue(0, 0)).thenReturn(1.0);
                 when(dataset.getValue(0, 1)).thenReturn(2.0);
                 when(dataset.getValue(0, 2)).thenReturn(3.0);
                 when(dataset.getValue(1, 0)).thenReturn(4.0);
                 when(dataset.getValue(1, 1)).thenReturn(5.0);  // This is the actual maximum
                 when(dataset.getValue(1, 2)).thenReturn(4.5);
                 when(dataset.getValue(2, 0)).thenReturn(3.5);
                 when(dataset.getValue(2, 1)).thenReturn(2.5);
                 when(dataset.getValue(2, 2)).thenReturn(1.5);
                 
                 // Call the method
                 Range result = DatasetUtilities.iterateRangeBounds(dataset);
                 
                 // Verify the range contains the correct maximum (5.0)
                 assertEquals(5.0, result.getUpperBound(), 0.0001);
                 
                 // Also test with descending values where first is maximum
                 CategoryDataset descendingDataset = mock(CategoryDataset.class);
                 when(descendingDataset.getRowCount()).thenReturn(1);
                 when(descendingDataset.getColumnCount()).thenReturn(3);
                 when(descendingDataset.getValue(0, 0)).thenReturn(10.0);  // Maximum
                 when(descendingDataset.getValue(0, 1)).thenReturn(9.0);
                 when(descendingDataset.getValue(0, 2)).thenReturn(8.0);
                 
                 Range descendingResult = DatasetUtilities.iterateRangeBounds(descendingDataset);
                 assertEquals(10.0, descendingResult.getUpperBound(), 0.0001);
             }

 @Test
             public void testIterateRangeBounds_MutatedMaxComparison() {
                 // Create a mock IntervalCategoryDataset
                 IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
                 
                 // Setup dataset behavior
                 when(dataset.getRowCount()).thenReturn(1);
                 when(dataset.getColumnCount()).thenReturn(1);
                 
                 // First value (regular value) will be 10.0 (should become initial max)
                 when(dataset.getValue(0, 0)).thenReturn(10.0);
                 
                 // Start value will be 5.0 (shouldn't affect max)
                 when(dataset.getStartValue(0, 0)).thenReturn(5.0);
                 
                 // End value will be 7.0 (smaller than current max 10.0)
                 // Original code would keep max=10.0, mutated code would set max=7.0
                 when(dataset.getEndValue(0, 0)).thenReturn(7.0);
                 
                 // Call method with includeInterval=true
                 Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                 
                 // Verify the maximum is still 10.0 (would fail if mutation is present)
                 assertEquals(10.0, result.getUpperBound(), 0.0001);
                 
                 // Also verify minimum for completeness
                 assertEquals(5.0, result.getLowerBound(), 0.0001);
             }

 @Test
             public void testIterateRangeBounds_DetectsMaximumValueCorrectly() {
                 // Create a mock CategoryDataset with values where max is not last
                 CategoryDataset dataset = mock(CategoryDataset.class);
                 when(dataset.getRowCount()).thenReturn(1);
                 when(dataset.getColumnCount()).thenReturn(3);
                 
                 // Setup values where max is 5.0 (middle value), not last (3.0)
                 when(dataset.getValue(0, 0)).thenReturn(1.0);
                 when(dataset.getValue(0, 1)).thenReturn(5.0);
                 when(dataset.getValue(0, 2)).thenReturn(3.0);
                 
                 // Call the method under test
                 Range result = DatasetUtilities.iterateRangeBounds(dataset);
                 
                 // Verify the range contains the correct maximum (5.0)
                 assertEquals(5.0, result.getUpperBound(), 0.0001);
                 
                 // Also verify lower bound for completeness
                 assertEquals(1.0, result.getLowerBound(), 0.0001);
             }

 @Test
             public void testIterateRangeBounds_IntervalXYDataset_MaximumCalculation1() {
                 // Create a mock IntervalXYDataset with multiple items where max uvalue isn't last
                 IntervalXYDataset dataset = mock(IntervalXYDataset.class);
                 when(dataset.getSeriesCount()).thenReturn(1);
                 when(dataset.getItemCount(0)).thenReturn(3);
                 
                 // Setup values where:
                 // - First item has uvalue = 5.0 (should be max)
                 // - Second item has uvalue = 3.0
                 // - Third item has uvalue = 4.0
                 when(dataset.getYValue(0, 0)).thenReturn(Double.NaN);
                 when(dataset.getStartYValue(0, 0)).thenReturn(Double.NaN);
                 when(dataset.getEndYValue(0, 0)).thenReturn(5.0);
                 
                 when(dataset.getYValue(0, 1)).thenReturn(Double.NaN);
                 when(dataset.getStartYValue(0, 1)).thenReturn(Double.NaN);
                 when(dataset.getEndYValue(0, 1)).thenReturn(3.0);
                 
                 when(dataset.getYValue(0, 2)).thenReturn(Double.NaN);
                 when(dataset.getStartYValue(0, 2)).thenReturn(Double.NaN);
                 when(dataset.getEndYValue(0, 2)).thenReturn(4.0);
                 
                 // Call method with includeInterval=true
                 Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                 
                 // Verify maximum is correctly calculated as 5.0 (not 4.0 as mutant would return)
                 assertNotNull(result);
                 assertEquals(5.0, result.getUpperBound(), 0.0001);
             }

 @Test
                public void testIterateRangeBounds_ShouldNotExceedSeriesCount2() {
                    // Create a mock CategoryDataset with 3 series
                    CategoryDataset dataset = mock(CategoryDataset.class);
                    when(dataset.getRowCount()).thenReturn(3); // 3 series
                    when(dataset.getColumnCount()).thenReturn(2); // 2 categories per series
                    
                    // Setup mock values - we'll use simple increasing values
                    when(dataset.getValue(0, 0)).thenReturn(1.0);
                    when(dataset.getValue(0, 1)).thenReturn(2.0);
                    when(dataset.getValue(1, 0)).thenReturn(3.0);
                    when(dataset.getValue(1, 1)).thenReturn(4.0);
                    when(dataset.getValue(2, 0)).thenReturn(5.0);
                    when(dataset.getValue(2, 1)).thenReturn(6.0);
                    
                    // The expected range should be from 1.0 to 6.0
                    Range expected = new Range(1.0, 6.0);
                    
                    // Call the method
                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                    
                    // Verify the result matches expected range
                    assertEquals("Range should match min and max of actual data", 
                        expected, result);
                    
                    // Verify the mock interactions - should only call getValue for existing series
                    verify(dataset, times(3)).getRowCount(); // called once + possibly in verification
                    verify(dataset, never()).getValue(3, anyInt()); // should never try to access series 3
                }

 @Test
            public void testIterateRangeBounds_DetectsExtraLoopIteration() {
                // Create a mock CategoryDataset with known values
                CategoryDataset dataset = mock(CategoryDataset.class);
                when(dataset.getRowCount()).thenReturn(2);
                when(dataset.getColumnCount()).thenReturn(2);
                
                // Setup values in a 2x2 grid
                when(dataset.getValue(0, 0)).thenReturn(1.0);
                when(dataset.getValue(0, 1)).thenReturn(2.0);
                when(dataset.getValue(1, 0)).thenReturn(3.0);
                when(dataset.getValue(1, 1)).thenReturn(4.0);
                
                // Test with includeInterval=false (standard case)
                Range result = DatasetUtilities.iterateRangeBounds(dataset, false);
                
                // Verify the range is exactly as expected
                assertEquals(1.0, result.getLowerBound(), 0.0001);
                assertEquals(4.0, result.getUpperBound(), 0.0001);
                
                // Create a mock IntervalCategoryDataset
                IntervalCategoryDataset intervalDataset = mock(IntervalCategoryDataset.class);
                when(intervalDataset.getRowCount()).thenReturn(1);
                when(intervalDataset.getColumnCount()).thenReturn(1);
                when(intervalDataset.getValue(0, 0)).thenReturn(5.0);
                when(intervalDataset.getStartValue(0, 0)).thenReturn(4.0);
                when(intervalDataset.getEndValue(0, 0)).thenReturn(6.0);
                
                // Test with includeInterval=true (interval case)
                Range intervalResult = DatasetUtilities.iterateRangeBounds(intervalDataset, true);
                
                // Verify the range includes the interval bounds
                assertEquals(4.0, intervalResult.getLowerBound(), 0.0001);
                assertEquals(6.0, intervalResult.getUpperBound(), 0.0001);
                
                // Test empty dataset case
                CategoryDataset emptyDataset = mock(CategoryDataset.class);
                when(emptyDataset.getRowCount()).thenReturn(0);
                when(emptyDataset.getColumnCount()).thenReturn(0);
                assertNull(DatasetUtilities.iterateRangeBounds(emptyDataset, false));
            }

 @Test
                public void testIterateRangeBounds_ShouldNotProcessExtraSeries() {
                    // Create a mock dataset with 3 series
                    CategoryDataset dataset = mock(CategoryDataset.class);
                    when(dataset.getRowCount()).thenReturn(3); // Assuming rowCount represents series count
                    when(dataset.getColumnCount()).thenReturn(2); // Some columns
                    
                    // Setup mock values for each valid series (0,1,2)
                    when(dataset.getValue(0, 0)).thenReturn(5.0);
                    when(dataset.getValue(0, 1)).thenReturn(10.0);
                    when(dataset.getValue(1, 0)).thenReturn(3.0);
                    when(dataset.getValue(1, 1)).thenReturn(7.0);
                    when(dataset.getValue(2, 0)).thenReturn(8.0);
                    when(dataset.getValue(2, 1)).thenReturn(12.0);
                    
                    // Call the method
                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                    
                    // Verify the expected range (3.0 to 12.0)
                    assertEquals(3.0, result.getLowerBound(), 0.0001);
                    assertEquals(12.0, result.getUpperBound(), 0.0001);
                    
                    // Verify no attempt to access series 3 (would be index out of bounds)
                    verify(dataset, never()).getValue(3, anyInt());
                    
                    // Verify exactly 3 series were processed (0,1,2)
                    verify(dataset, times(3)).getRowCount();
                }

 @Test
                public void testIterateRangeBounds_SeriesCountBoundary() {
                    // Test with regular XYDataset
                    XYDataset xyDataset = mock(XYDataset.class);
                    when(xyDataset.getSeriesCount()).thenReturn(2);
                    when(xyDataset.getItemCount(0)).thenReturn(1);
                    when(xyDataset.getItemCount(1)).thenReturn(1);
                    when(xyDataset.getYValue(0, 0)).thenReturn(5.0);
                    when(xyDataset.getYValue(1, 0)).thenReturn(10.0);
                    
                    Range result = DatasetUtilities.iterateRangeBounds(xyDataset);
                    assertEquals(new Range(5.0, 10.0), result);
                    
                    // Test with IntervalXYDataset
                    IntervalXYDataset intervalDataset = mock(IntervalXYDataset.class);
                    when(intervalDataset.getSeriesCount()).thenReturn(1);
                    when(intervalDataset.getItemCount(0)).thenReturn(1);
                    when(intervalDataset.getYValue(0, 0)).thenReturn(2.0);
                    when(intervalDataset.getStartYValue(0, 0)).thenReturn(1.0);
                    when(intervalDataset.getEndYValue(0, 0)).thenReturn(3.0);
                    
                    result = DatasetUtilities.iterateRangeBounds(intervalDataset, true);
                    assertEquals(new Range(1.0, 3.0), result);
                    
                    // Test with OHLCDataset
                    OHLCDataset ohlcDataset = mock(OHLCDataset.class);
                    when(ohlcDataset.getSeriesCount()).thenReturn(1);
                    when(ohlcDataset.getItemCount(0)).thenReturn(1);
                    when(ohlcDataset.getLowValue(0, 0)).thenReturn(4.0);
                    when(ohlcDataset.getHighValue(0, 0)).thenReturn(6.0);
                    
                    result = DatasetUtilities.iterateRangeBounds(ohlcDataset, true);
                    assertEquals(new Range(4.0, 6.0), result);
                    
                    // Test empty dataset
                    XYDataset emptyDataset = mock(XYDataset.class);
                    when(emptyDataset.getSeriesCount()).thenReturn(0);
                    assertNull(DatasetUtilities.iterateRangeBounds(emptyDataset));
                }

 @Test
           public void testIterateRangeBoundsWithDifferentStartValues() {
               // Create a mock IntervalCategoryDataset with different start values per item
               IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
               when(dataset.getRowCount()).thenReturn(1); // 1 series
               when(dataset.getColumnCount()).thenReturn(2); // 2 items
               
               // Setup values - all valid numbers
               when(dataset.getValue(0, 0)).thenReturn(10.0);
               when(dataset.getValue(0, 1)).thenReturn(20.0);
               
               // Setup start values - different for each item
               when(dataset.getStartValue(0, 0)).thenReturn(5.0); // first item start
               when(dataset.getStartValue(0, 1)).thenReturn(15.0); // second item start
               
               // Setup end values
               when(dataset.getEndValue(0, 0)).thenReturn(15.0);
               when(dataset.getEndValue(0, 1)).thenReturn(25.0);
               
               // Call the method with includeInterval=true
               Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
               
               // Verify the range includes all values (min should be 5.0 from first item's start value)
               // If mutant is present, it would miss the second item's start value (15.0)
               assertEquals(5.0, result.getLowerBound(), 0.0001);
               assertEquals(25.0, result.getUpperBound(), 0.0001);
               
               // Additional verification that all start values were considered
               // The mutant would only consider start value of item 0 (5.0)
               assertTrue(result.getLowerBound() == 5.0); // min of 5.0 and 15.0
           }

 @Test
           public void testIterateRangeBounds_IntervalXYDatasetWithVaryingStartYValues() {
               // Create a mock IntervalXYDataset with varying start Y-values
               IntervalXYDataset dataset = mock(IntervalXYDataset.class);
               when(dataset.getSeriesCount()).thenReturn(1);
               when(dataset.getItemCount(0)).thenReturn(2);  // Two items in series
               
               // First item values
               when(dataset.getYValue(0, 0)).thenReturn(5.0);
               when(dataset.getStartYValue(0, 0)).thenReturn(4.0);  // Start Y for item 0
               when(dataset.getEndYValue(0, 0)).thenReturn(6.0);
               
               // Second item values - different start Y
               when(dataset.getYValue(0, 1)).thenReturn(8.0);
               when(dataset.getStartYValue(0, 1)).thenReturn(7.0);  // Start Y for item 1
               when(dataset.getEndYValue(0, 1)).thenReturn(9.0);
               
               // Test with includeInterval = true
               Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
               
               // Verify the range considers all start Y-values (4.0 and 7.0)
               // Original code would find min=4.0 (from first item's start Y)
               // Mutant would find min=4.0 (always from first item's start Y) but miss 7.0
               assertEquals(4.0, result.getLowerBound(), 0.0001);
               assertEquals(9.0, result.getUpperBound(), 0.0001);
               
               // Additional verification that we're using correct items
               verify(dataset, times(2)).getStartYValue(anyInt(), anyInt());
               verify(dataset).getStartYValue(0, 0);
               verify(dataset).getStartYValue(0, 1);
           }

 @Test
          public void testIterateRangeBounds_DetectsMutatedGetStartYValue() {
              // Create a mock XYDataset
              XYDataset dataset = mock(XYDataset.class);
              
              // Setup the mock to return test data
              when(dataset.getSeriesCount()).thenReturn(1);
              when(dataset.getItemCount(0)).thenReturn(3);
              
              // Setup Y values where min/max are not at index 0
              when(dataset.getYValue(0, 0)).thenReturn(5.0);  // First item
              when(dataset.getYValue(0, 1)).thenReturn(2.0);  // Min value at index 1
              when(dataset.getYValue(0, 2)).thenReturn(8.0);  // Max value at index 2
              
              // Call the method under test
              Range result = DatasetUtilities.iterateRangeBounds(dataset);
              
              // Verify the range is correctly calculated (should be 2.0 to 8.0)
              assertEquals(2.0, result.getLowerBound(), 0.0001);
              assertEquals(8.0, result.getUpperBound(), 0.0001);
              
              // The mutant would return range 5.0 to 5.0 since it only checks index 0
          }

 @Test
      public void testIterateRangeBounds_DetectsMutatedGetStartYValue1() {
          // Create a mock XYDataset with varying Y values across items
          XYDataset dataset = mock(XYDataset.class);
          
          // Setup dataset behavior
          when(dataset.getSeriesCount()).thenReturn(1);
          when(dataset.getItemCount(0)).thenReturn(3);
          
          // Set different Y values for each item
          when(dataset.getYValue(0, 0)).thenReturn(10.0);
          when(dataset.getYValue(0, 1)).thenReturn(20.0);
          when(dataset.getYValue(0, 2)).thenReturn(30.0);
          
          // Call the method under test
          Range result = DatasetUtilities.iterateRangeBounds(dataset);
          
          // Verify the range includes all Y values (would fail with mutant)
          assertEquals(10.0, result.getLowerBound(), 0.0001);
          assertEquals(30.0, result.getUpperBound(), 0.0001);
          
          // Additional verification that all items were considered
          verify(dataset, times(3)).getYValue(anyInt(), anyInt());
      }

 @Test
  public void testIterateRangeBounds_ShouldUpdateMaximumValue() {
      // Create a mock CategoryDataset with known values
      CategoryDataset dataset = mock(CategoryDataset.class);
      
      // Setup mock behavior
      when(dataset.getRowCount()).thenReturn(2);
      when(dataset.getColumnCount()).thenReturn(2);
      
      // First row values (5, 10)
      when(dataset.getValue(0, 0)).thenReturn(5.0);
      when(dataset.getValue(0, 1)).thenReturn(10.0);
      
      // Second row values (15, 20) - should update maximum
      when(dataset.getValue(1, 0)).thenReturn(15.0);
      when(dataset.getValue(1, 1)).thenReturn(20.0);
      
      // Call the method under test
      Range result = DatasetUtilities.iterateRangeBounds(dataset);
      
      // Verify the range contains the correct maximum value
      assertEquals("Upper bound should be 20.0", 20.0, result.getUpperBound(), 0.0001);
      
      // Also verify lower bound for completeness
      assertEquals("Lower bound should be 5.0", 5.0, result.getLowerBound(), 0.0001);
  }

 @Test
  public void testIterateRangeBounds_DetectMutantInIntervalDataset() {
      // Create mock IntervalCategoryDataset
      IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
      
      // Setup test data - lvalue (start value) should be the largest
      when(dataset.getRowCount()).thenReturn(1);
      when(dataset.getColumnCount()).thenReturn(1);
      when(dataset.getValue(0, 0)).thenReturn(5.0);  // regular value
      when(dataset.getStartValue(0, 0)).thenReturn(10.0);  // lvalue - should be new maximum
      when(dataset.getEndValue(0, 0)).thenReturn(7.0);  // uvalue
      
      // Call method with includeInterval=true
      Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
      
      // Verify the maximum was properly updated to include lvalue
      // Original code would return range 5.0-10.0
      // Mutated code would return range 5.0-7.0 (ignoring lvalue)
      assertNotNull(result);
      assertEquals(5.0, result.getLowerBound(), 0.0001);
      assertEquals(10.0, result.getUpperBound(), 0.0001);  // This assertion would fail with the mutant
  }

 @Test
  public void testIterateRangeBounds_DetectsMaximumValueMutation() {
      // Create a mock CategoryDataset that returns increasing values
      CategoryDataset dataset = mock(CategoryDataset.class);
      when(dataset.getRowCount()).thenReturn(1);
      when(dataset.getColumnCount()).thenReturn(3);
      
      // Setup values where the maximum is in the middle
      when(dataset.getValue(0, 0)).thenReturn(5.0);
      when(dataset.getValue(0, 1)).thenReturn(10.0);  // This should be the maximum
      when(dataset.getValue(0, 2)).thenReturn(7.0);
      
      // Call the method under test
      Range result = DatasetUtilities.iterateRangeBounds(dataset);
      
      // Verify the range contains the correct maximum value
      assertNotNull("Result should not be null", result);
      assertEquals("Upper bound should be 10.0", 10.0, result.getUpperBound(), 0.0001);
      
      // Also verify lower bound for completeness
      assertEquals("Lower bound should be 5.0", 5.0, result.getLowerBound(), 0.0001);
  }

 @Test
  public void testIterateRangeBounds_IntervalXYDataset_DetectsMaximumMutation() {
      // Create mock IntervalXYDataset
      IntervalXYDataset dataset = mock(IntervalXYDataset.class);
      
      // Setup test data - series 0 has 2 items
      when(dataset.getSeriesCount()).thenReturn(1);
      when(dataset.getItemCount(0)).thenReturn(2);
      
      // First item - normal values
      when(dataset.getYValue(0, 0)).thenReturn(5.0);
      when(dataset.getStartYValue(0, 0)).thenReturn(4.0);
      when(dataset.getEndYValue(0, 0)).thenReturn(6.0);
      
      // Second item - lvalue is the new maximum (10.0)
      when(dataset.getYValue(0, 1)).thenReturn(7.0);
      when(dataset.getStartYValue(0, 1)).thenReturn(10.0); // This should update maximum
      when(dataset.getEndYValue(0, 1)).thenReturn(8.0);
      
      // Execute
      Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
      
      // Verify - maximum should be 10.0 (from lvalue)
      assertNotNull(result);
      assertEquals(4.0, result.getLowerBound(), 0.0001);
      assertEquals(10.0, result.getUpperBound(), 0.0001); // This will fail if mutation is present
  }

 @Test
     public void testIterateRangeBoundsWithNaNValues2() {
         // Create a dataset with NaN values
         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
         dataset.addValue(1.0, "Series1", "Category1");
         dataset.addValue(Double.NaN, "Series1", "Category2");
         dataset.addValue(3.0, "Series1", "Category3");
         
         // The original and mutated code might handle NaN differently
         Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
         
         // Verify the range properly handles NaN (should ignore NaN values)
         assertNotNull(result);
         assertEquals(1.0, result.getLowerBound(), 0.0001);
         assertEquals(3.0, result.getUpperBound(), 0.0001);
     }

 @Test
     public void testIterateRangeBoundsWithExtremeValues() {
         // Create a dataset with very large and very small numbers
         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
         dataset.addValue(Double.MIN_VALUE, "Series1", "Category1");
         dataset.addValue(Double.MAX_VALUE, "Series1", "Category2");
         
         Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
         
         // Verify the range handles extreme values correctly
         assertNotNull(result);
         assertEquals(Double.MIN_VALUE, result.getLowerBound(), 0.0001);
         assertEquals(Double.MAX_VALUE, result.getUpperBound(), 0.0001);
     }

 @Test
     public void testIterateRangeBoundsWithNullValues() {
         // Create a dataset with null values
         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
         dataset.addValue(null, "Series1", "Category1");
         dataset.addValue(5.0, "Series1", "Category2");
         dataset.addValue(null, "Series1", "Category3");
         
         Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
         
         // Verify the range properly ignores null values
         assertNotNull(result);
         assertEquals(5.0, result.getLowerBound(), 0.0001);
         assertEquals(5.0, result.getUpperBound(), 0.0001);
     }

 @Test
     public void testIterateRangeBoundsWithMixedSignNumbers() {
         // Create a dataset with both positive and negative numbers
         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
         dataset.addValue(-10.0, "Series1", "Category1");
         dataset.addValue(0.0, "Series1", "Category2");
         dataset.addValue(10.0, "Series1", "Category3");
         
         Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
         
         // Verify the range handles mixed signs correctly
         assertNotNull(result);
         assertEquals(-10.0, result.getLowerBound(), 0.0001);
         assertEquals(10.0, result.getUpperBound(), 0.0001);
     }

 @Test
 public void testIterateRangeBounds_DetectsMaximumMutation() {
     // Create mock IntervalCategoryDataset
     IntervalCategoryDataset dataset = mock(IntervalCategoryDataset.class);
     
     // Setup test data - 1 row, 1 column
     when(dataset.getRowCount()).thenReturn(1);
     when(dataset.getColumnCount()).thenReturn(1);
     
     // Setup values where endValue > current maximum
     when(dataset.getValue(0, 0)).thenReturn(5.0);
     when(dataset.getStartValue(0, 0)).thenReturn(3.0);
     when(dataset.getEndValue(0, 0)).thenReturn(10.0);  // This should become the new maximum
     
     // Call method with includeInterval=true
     Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
     
     // Verify the maximum was correctly set to the endValue
     assertNotNull(result);
     assertEquals(3.0, result.getLowerBound(), 0.0001);  // Minimum from startValue
     assertEquals(10.0, result.getUpperBound(), 0.0001); // Should be endValue (10.0)
     
     // Verify interactions
     verify(dataset).getValue(0, 0);
     verify(dataset).getStartValue(0, 0);
     verify(dataset).getEndValue(0, 0);
 }

 @Test
     public void testIterateRangeBoundsWithNaNValues3() {
         // Create a dataset with NaN and regular values
         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
         dataset.addValue(5.0, "Series1", "Category1");
         dataset.addValue(Double.NaN, "Series1", "Category2");
         dataset.addValue(10.0, "Series1", "Category3");
         dataset.addValue(Double.NaN, "Series1", "Category4");
         dataset.addValue(15.0, "Series1", "Category5");
         
         // The original implementation would handle NaN values differently
         // depending on parameter order in Math.max
         Range result = DatasetUtilities.iterateRangeBounds(dataset);
         
         // Verify the range correctly ignores NaN values
         assertNotNull("Result should not be null", result);
         assertEquals("Lower bound should be 5.0", 5.0, result.getLowerBound(), 0.0001);
         assertEquals("Upper bound should be 15.0", 15.0, result.getUpperBound(), 0.0001);
     }

 @Test
     public void testIterateRangeBoundsWithExtremeValues1() {
         // Create a dataset with very large and small numbers
         DefaultCategoryDataset dataset = new DefaultCategoryDataset();
         dataset.addValue(Double.MIN_VALUE, "Series1", "Category1");
         dataset.addValue(Double.MAX_VALUE, "Series1", "Category2");
         dataset.addValue(-Double.MAX_VALUE, "Series1", "Category3");
         
         Range result = DatasetUtilities.iterateRangeBounds(dataset);
         
         // Verify the range handles extreme values correctly
         assertNotNull("Result should not be null", result);
         assertEquals("Lower bound should be -Double.MAX_VALUE", 
             -Double.MAX_VALUE, result.getLowerBound(), 0.0001);
         assertEquals("Upper bound should be Double.MAX_VALUE", 
             Double.MAX_VALUE, result.getUpperBound(), 0.0001);
     }

 @Test
 public void testIterateRangeBounds_DetectMutatedMaxCalculation() {
     // Create a mock IntervalXYDataset
     IntervalXYDataset dataset = mock(IntervalXYDataset.class);
     
     // Setup test data - one series with one item
     when(dataset.getSeriesCount()).thenReturn(1);
     when(dataset.getItemCount(0)).thenReturn(1);
     
     // Set up values where uvalue is larger than initial maximum
     when(dataset.getYValue(0, 0)).thenReturn(Double.NaN); // Skip regular Y value
     when(dataset.getStartYValue(0, 0)).thenReturn(Double.NaN); // Skip start value
     when(dataset.getEndYValue(0, 0)).thenReturn(100.0); // This should update maximum
     
     // Call the method with includeInterval=true
     Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
     
     // Verify the maximum was properly updated
     assertNotNull(result);
     assertEquals(100.0, result.getUpperBound(), 0.0001);
     
     // Additional verification that Math.max was called with correct parameters
     // This is the key assertion that would catch the mutant
     // The original would call Math.max(Double.NEGATIVE_INFINITY, 100.0)
     // The mutant would call Math.max(100.0, Double.NEGATIVE_INFINITY)
     // While mathematically equivalent, this test ensures the parameter order is preserved
     verify(dataset, times(1)).getEndYValue(0, 0);
 }

}
