package gentest.org.jfree.data.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.SortOrder;
 
public class DefaultKeyedValuesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                     public void testRemoveValue_SingleElement() {
                                                                                                                                                         DefaultKeyedValues single = new DefaultKeyedValues();
                                                                                                                                                         single.addValue("Single", 1);
                                                                                                                                                         single.removeValue(0);
                                                                                                                                                         assertEquals(0, single.getItemCount());
                                                                                                                                                         assertTrue(single.getKeys().isEmpty());
                                                                                                                                                         assertNull(single.getValue(0));
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testRemoveValue_EmptyCollection() {
                                                                                                                                                         DefaultKeyedValues empty = new DefaultKeyedValues();
                                                                                                                                                         thrown.expect(IndexOutOfBoundsException.class);
                                                                                                                                                         empty.removeValue(0);
                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testClone_ModificationDoesNotAffectOriginal() throws CloneNotSupportedException {
                                                                                                                                                         // Setup original object
                                                                                                                                                         DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                                         original.addValue("A", 1.0);
                                                                                                                                                         original.addValue("B", 2.0);
                                                                                                                                                         
                                                                                                                                                         // Clone and modify the clone
                                                                                                                                                         DefaultKeyedValues cloned = (DefaultKeyedValues) original.clone();
                                                                                                                                                         cloned.setValue("A", 99.0);
                                                                                                                                                         cloned.removeValue("B");
                                                                                                                                                         cloned.addValue("C", 3.0);
                                                                                                                                                         
                                                                                                                                                         // Verify original remains unchanged
                                                                                                                                                         assertEquals("Original value for A should remain unchanged", 1.0, original.getValue("A"));
                                                                                                                                                         assertEquals("Original should still have key B", 2.0, original.getValue("B"));
                                                                                                                                                         assertNull("Original should not have key C", original.getValue("C"));
                                                                                                                                                         assertEquals("Original item count should remain 2", 2, original.getItemCount());
                                                                                                                                                     }

    @Test
                                                                                                                                             public void testRemoveValue_ValidIndex() {
                                                                                                                                                 // Create and initialize the test object
                                                                                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                 
                                                                                                                                                 // Set up initial state
                                                                                                                                                 dkv.addValue("Key1", 10);
                                                                                                                                                 dkv.addValue("Key2", 20);
                                                                                                                                                 dkv.addValue("Key3", 30);
                                                                                                                                                 
                                                                                                                                                 // Test removing middle element
                                                                                                                                                 dkv.removeValue(1);
                                                                                                                                                 assertEquals(2, dkv.getItemCount());
                                                                                                                                                 assertEquals("Key1", dkv.getKey(0));
                                                                                                                                                 assertEquals("Key3", dkv.getKey(1));
                                                                                                                                                 assertEquals(10, dkv.getValue(0).intValue());
                                                                                                                                                 assertEquals(30, dkv.getValue(1).intValue());
                                                                                                                                                 
                                                                                                                                                 // Verify index map was rebuilt correctly
                                                                                                                                                 assertEquals(0, dkv.getIndex("Key1"));
                                                                                                                                                 assertEquals(1, dkv.getIndex("Key3"));
                                                                                                                                                 assertEquals(-1, dkv.getIndex("Key2")); // Should no longer exist
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_FirstIndex() {
                                                                                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                 dkv.addValue("Key1", 10);
                                                                                                                                                 dkv.addValue("Key2", 20);
                                                                                                                                                 dkv.addValue("Key3", 30);
                                                                                                                                                 
                                                                                                                                                 dkv.removeValue(0);
                                                                                                                                                 assertEquals(2, dkv.getItemCount());
                                                                                                                                                 assertEquals("Key2", dkv.getKey(0));
                                                                                                                                                 assertEquals("Key3", dkv.getKey(1));
                                                                                                                                                 assertEquals(20, dkv.getValue(0).intValue());
                                                                                                                                                 assertEquals(30, dkv.getValue(1).intValue());
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_LastIndex() {
                                                                                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                 dkv.addValue("Key1", 10);
                                                                                                                                                 dkv.addValue("Key2", 20);
                                                                                                                                                 dkv.addValue("Key3", 30);  // This will be at index 2 and will be removed
                                                                                                                                                 
                                                                                                                                                 dkv.removeValue(2);
                                                                                                                                                 assertEquals(2, dkv.getItemCount());
                                                                                                                                                 assertEquals("Key1", dkv.getKey(0));
                                                                                                                                                 assertEquals("Key2", dkv.getKey(1));
                                                                                                                                                 assertEquals(10, dkv.getValue(0).intValue());
                                                                                                                                                 assertEquals(20, dkv.getValue(1).intValue());
                                                                                                                                             }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                             public void testRemoveValue_NegativeIndex() {
                                                                                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                 dkv.removeValue(-1);
                                                                                                                                             }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                             public void testRemoveValue_IndexOutOfBounds() {
                                                                                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                 // Add some test data
                                                                                                                                                 dkv.addValue("Key1", 1.0);
                                                                                                                                                 dkv.addValue("Key2", 2.0);
                                                                                                                                                 dkv.addValue("Key3", 3.0);
                                                                                                                                                 // Try to remove at index 3 which is out of bounds (only 0,1,2 exist)
                                                                                                                                                 dkv.removeValue(3);
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_VerifyIndexMapConsistency() {
                                                                                                                                                 // Create and populate test object
                                                                                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                 dkv.addValue("Key1", 1.0);
                                                                                                                                                 dkv.addValue("Key2", 2.0);
                                                                                                                                                 dkv.addValue("Key3", 3.0);
                                                                                                                                                 
                                                                                                                                                 // Verify initial state
                                                                                                                                                 assertEquals(0, dkv.getIndex("Key1"));
                                                                                                                                                 assertEquals(1, dkv.getIndex("Key2"));
                                                                                                                                                 assertEquals(2, dkv.getIndex("Key3"));
                                                                                                                                                 
                                                                                                                                                 // Remove middle element
                                                                                                                                                 dkv.removeValue(1);
                                                                                                                                                 
                                                                                                                                                 // Verify new indices
                                                                                                                                                 assertEquals(0, dkv.getIndex("Key1"));
                                                                                                                                                 assertEquals(1, dkv.getIndex("Key3"));
                                                                                                                                                 assertEquals(-1, dkv.getIndex("Key2")); // Should be removed
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_MultipleRemovals() {
                                                                                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                 // Set up initial data
                                                                                                                                                 dkv.addValue("Key1", 10);
                                                                                                                                                 dkv.addValue("Key2", 20);
                                                                                                                                                 dkv.addValue("Key3", 30);
                                                                                                                                                 
                                                                                                                                                 // Remove first two items
                                                                                                                                                 dkv.removeValue(0);
                                                                                                                                                 dkv.removeValue(0); // Now Key3 is at 0
                                                                                                                                                 
                                                                                                                                                 assertEquals(1, dkv.getItemCount());
                                                                                                                                                 assertEquals("Key3", dkv.getKey(0));
                                                                                                                                                 assertEquals(30, dkv.getValue(0).intValue());
                                                                                                                                                 
                                                                                                                                                 // Remove last item
                                                                                                                                                 dkv.removeValue(0);
                                                                                                                                                 assertEquals(0, dkv.getItemCount());
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_KeyExists_RemovesSuccessfully() {
                                                                                                                                                 // Setup test data
                                                                                                                                                 DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                 keyedValues.addValue("Key1", 10.0);
                                                                                                                                                 keyedValues.addValue("Key2", 20.0);
                                                                                                                                                 
                                                                                                                                                 // Verify initial state
                                                                                                                                                 assertEquals(2, keyedValues.getItemCount());
                                                                                                                                                 assertEquals(10.0, keyedValues.getValue("Key1").doubleValue(), 0.0001);
                                                                                                                                                 
                                                                                                                                                 // Execute
                                                                                                                                                 keyedValues.removeValue("Key1");
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 assertEquals(1, keyedValues.getItemCount());
                                                                                                                                                 assertNull(keyedValues.getValue("Key1"));
                                                                                                                                                 assertEquals(20.0, keyedValues.getValue("Key2").doubleValue(), 0.0001);
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_KeyDoesNotExist_ThrowsException() {
                                                                                                                                                 // Setup test data
                                                                                                                                                 DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                 keyedValues.addValue("Key1", 10.0);
                                                                                                                                                 
                                                                                                                                                 // Setup exception expectation
                                                                                                                                                 ExpectedException thrown = ExpectedException.none();
                                                                                                                                                 thrown.expect(UnknownKeyException.class);
                                                                                                                                                 thrown.expectMessage("The key (NonExistentKey) is not recognised.");
                                                                                                                                                 
                                                                                                                                                 // Execute
                                                                                                                                                 keyedValues.removeValue("NonExistentKey");
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_NullKey_ThrowsException() {
                                                                                                                                                 // Setup test data
                                                                                                                                                 DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                 keyedValues.addValue("Key1", 10.0);
                                                                                                                                                 
                                                                                                                                                 // Setup exception rule
                                                                                                                                                 ExpectedException thrown = ExpectedException.none();
                                                                                                                                                 
                                                                                                                                                 // Expect exception
                                                                                                                                                 thrown.expect(UnknownKeyException.class);
                                                                                                                                                 thrown.expectMessage("The key (null) is not recognised.");
                                                                                                                                                 
                                                                                                                                                 // Execute
                                                                                                                                                 keyedValues.removeValue(null);
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_EmptyCollection_ThrowsException() {
                                                                                                                                                 // Setup
                                                                                                                                                 DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                 ExpectedException thrown = ExpectedException.none();
                                                                                                                                                 
                                                                                                                                                 // Verify initial state
                                                                                                                                                 assertEquals(0, keyedValues.getItemCount());
                                                                                                                                                 
                                                                                                                                                 // Expect exception
                                                                                                                                                 thrown.expect(UnknownKeyException.class);
                                                                                                                                                 thrown.expectMessage("The key (AnyKey) is not recognised.");
                                                                                                                                                 
                                                                                                                                                 // Execute
                                                                                                                                                 keyedValues.removeValue("AnyKey");
                                                                                                                                             }

    @Test
                                                                                                                                             public void testRemoveValue_MultipleRemovals_ConsistentState() {
                                                                                                                                                 // Initialize KeyedValues object
                                                                                                                                                 DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                 
                                                                                                                                                 // Setup test data
                                                                                                                                                 keyedValues.addValue("Key1", 10.0);
                                                                                                                                                 keyedValues.addValue("Key2", 20.0);
                                                                                                                                                 keyedValues.addValue("Key3", 30.0);
                                                                                                                                                 
                                                                                                                                                 // Execute first removal
                                                                                                                                                 keyedValues.removeValue("Key2");
                                                                                                                                                 
                                                                                                                                                 // Verify first removal
                                                                                                                                                 assertEquals(2, keyedValues.getItemCount());
                                                                                                                                                 assertEquals(10.0, keyedValues.getValue("Key1").doubleValue(), 0.0001);
                                                                                                                                                 assertEquals(30.0, keyedValues.getValue("Key3").doubleValue(), 0.0001);
                                                                                                                                                 
                                                                                                                                                 // Execute second removal
                                                                                                                                                 keyedValues.removeValue("Key1");
                                                                                                                                                 
                                                                                                                                                 // Verify second removal
                                                                                                                                                 assertEquals(1, keyedValues.getItemCount());
                                                                                                                                                 assertEquals(30.0, keyedValues.getValue("Key3").doubleValue(), 0.0001);
                                                                                                                                                 
                                                                                                                                                 // Execute third removal
                                                                                                                                                 keyedValues.removeValue("Key3");
                                                                                                                                                 
                                                                                                                                                 // Verify final state
                                                                                                                                                 assertEquals(0, keyedValues.getItemCount());
                                                                                                                                             }

    @Test(expected = CloneNotSupportedException.class)
                                                                                                                                             public void testClone_WhenSuperCloneFails() throws CloneNotSupportedException {
                                                                                                                                                 // Create a mock object that throws CloneNotSupportedException
                                                                                                                                                 DefaultKeyedValues original = new DefaultKeyedValues() {
                                                                                                                                                     @Override
                                                                                                                                                     public Object clone() throws CloneNotSupportedException {
                                                                                                                                                         throw new CloneNotSupportedException("Test exception");
                                                                                                                                                     }
                                                                                                                                                 };
                                                                                                                                                 
                                                                                                                                                 original.clone(); // This should throw the exception
                                                                                                                                             }

    @Test
                                                                                                                                         public void testClone_CreatesDeepCopy() throws CloneNotSupportedException {
                                                                                                                                             // Setup original object with some data
                                                                                                                                             org.jfree.data.DefaultKeyedValues original = new org.jfree.data.DefaultKeyedValues();
                                                                                                                                             original.addValue("Key1", 10.0);
                                                                                                                                             original.addValue("Key2", 20.0);
                                                                                                                                             original.addValue("Key3", 30.0);
                                                                                                                                             
                                                                                                                                             // Clone the object
                                                                                                                                             org.jfree.data.DefaultKeyedValues cloned = (org.jfree.data.DefaultKeyedValues) original.clone();
                                                                                                                                             
                                                                                                                                             // Verify it's a different object
                                                                                                                                             assertNotSame("Cloned object should be a different instance", original, cloned);
                                                                                                                                             
                                                                                                                                             try {
                                                                                                                                                 // Use reflection to access private fields
                                                                                                                                                 java.lang.reflect.Field keysField = org.jfree.data.DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                 keysField.setAccessible(true);
                                                                                                                                                 java.lang.reflect.Field valuesField = org.jfree.data.DefaultKeyedValues.class.getDeclaredField("values");
                                                                                                                                                 valuesField.setAccessible(true);
                                                                                                                                                 java.lang.reflect.Field indexMapField = org.jfree.data.DefaultKeyedValues.class.getDeclaredField("indexMap");
                                                                                                                                                 indexMapField.setAccessible(true);
                                                                                                                                                 
                                                                                                                                                 // Get the field values
                                                                                                                                                 java.util.List<?> originalKeys = (java.util.List<?>) keysField.get(original);
                                                                                                                                                 java.util.List<?> clonedKeys = (java.util.List<?>) keysField.get(cloned);
                                                                                                                                                 java.util.List<?> originalValues = (java.util.List<?>) valuesField.get(original);
                                                                                                                                                 java.util.List<?> clonedValues = (java.util.List<?>) valuesField.get(cloned);
                                                                                                                                                 java.util.Map<?, ?> originalIndexMap = (java.util.Map<?, ?>) indexMapField.get(original);
                                                                                                                                                 java.util.Map<?, ?> clonedIndexMap = (java.util.Map<?, ?>) indexMapField.get(cloned);
                                                                                                                                                 
                                                                                                                                                 // Verify all internal collections are different instances
                                                                                                                                                 assertNotSame("Keys list should be cloned", originalKeys, clonedKeys);
                                                                                                                                                 assertNotSame("Values list should be cloned", originalValues, clonedValues);
                                                                                                                                                 assertNotSame("Index map should be cloned", originalIndexMap, clonedIndexMap);
                                                                                                                                                 
                                                                                                                                                 // Verify content equality
                                                                                                                                                 assertEquals("Keys should be equal", originalKeys, clonedKeys);
                                                                                                                                                 assertEquals("Values should be equal", originalValues, clonedValues);
                                                                                                                                                 assertEquals("Index map should be equal", originalIndexMap, clonedIndexMap);
                                                                                                                                             } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                 fail("Failed to access private fields: " + e.getMessage());
                                                                                                                                             }
                                                                                                                                             
                                                                                                                                             // Verify the clone has the same number of items
                                                                                                                                             assertEquals("Item count should match", original.getItemCount(), cloned.getItemCount());
                                                                                                                                             
                                                                                                                                             // Verify individual values
                                                                                                                                             assertEquals("Value for Key1 should match", original.getValue("Key1"), cloned.getValue("Key1"));
                                                                                                                                             assertEquals("Value for Key2 should match", original.getValue("Key2"), cloned.getValue("Key2"));
                                                                                                                                             assertEquals("Value for Key3 should match", original.getValue("Key3"), cloned.getValue("Key3"));
                                                                                                                                         }

    @Test
                                                                                                                                         public void testClone_EmptyObject() throws CloneNotSupportedException {
                                                                                                                                             // Setup empty original object
                                                                                                                                             DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                             
                                                                                                                                             // Clone the object
                                                                                                                                             DefaultKeyedValues cloned = (DefaultKeyedValues) original.clone();
                                                                                                                                             
                                                                                                                                             // Verify it's a different object
                                                                                                                                             assertNotSame("Cloned empty object should be different instance", original, cloned);
                                                                                                                                             
                                                                                                                                             try {
                                                                                                                                                 // Use reflection to access private fields for verification
                                                                                                                                                 Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                 keysField.setAccessible(true);
                                                                                                                                                 Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                                                                                                                                                 valuesField.setAccessible(true);
                                                                                                                                                 Field indexMapField = DefaultKeyedValues.class.getDeclaredField("indexMap");
                                                                                                                                                 indexMapField.setAccessible(true);
                                                                                                                                                 
                                                                                                                                                 // Verify all collections are empty
                                                                                                                                                 assertTrue("Cloned keys should be empty", ((java.util.List<?>) keysField.get(cloned)).isEmpty());
                                                                                                                                                 assertTrue("Cloned values should be empty", ((java.util.List<?>) valuesField.get(cloned)).isEmpty());
                                                                                                                                                 assertTrue("Cloned indexMap should be empty", ((java.util.Map<?, ?>) indexMapField.get(cloned)).isEmpty());
                                                                                                                                             } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                 fail("Failed to access private fields for verification: " + e.getMessage());
                                                                                                                                             }
                                                                                                                                             
                                                                                                                                             // Verify item count is 0
                                                                                                                                             assertEquals("Empty clone should have 0 items", 0, cloned.getItemCount());
                                                                                                                                         }

    @Test
                                                                                                                             public void testRemoveValue_VerifyInternalStateAfterRemoval() {
                                                                                                                                 // Setup test data
                                                                                                                                 DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                 keyedValues.addValue("Key1", 10.0);
                                                                                                                                 keyedValues.addValue("Key2", 20.0);
                                                                                                                                 
                                                                                                                                 // Execute
                                                                                                                                 keyedValues.removeValue("Key1");
                                                                                                                                 
                                                                                                                                 // Verify using public methods
                                                                                                                                 assertEquals(1, keyedValues.getItemCount());
                                                                                                                                 assertEquals("Key2", keyedValues.getKey(0));
                                                                                                                                 assertEquals(20.0, keyedValues.getValue(0).doubleValue(), 0.0001);
                                                                                                                                 
                                                                                                                                 // Verify internal state using reflection if needed
                                                                                                                                 try {
                                                                                                                                     Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                     keysField.setAccessible(true);
                                                                                                                                     List<String> keys = (List<String>) keysField.get(keyedValues);
                                                                                                                                     assertEquals(1, keys.size());
                                                                                                                                     assertEquals("Key2", keys.get(0));
                                                                                                                                     
                                                                                                                                     Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                                                                                                                                     valuesField.setAccessible(true);
                                                                                                                                     List<Number> values = (List<Number>) valuesField.get(keyedValues);
                                                                                                                                     assertEquals(1, values.size());
                                                                                                                                     assertEquals(20.0, values.get(0).doubleValue(), 0.0001);
                                                                                                                                     
                                                                                                                                     Field indexMapField = DefaultKeyedValues.class.getDeclaredField("indexMap");
                                                                                                                                     indexMapField.setAccessible(true);
                                                                                                                                     java.util.Map<String, java.lang.Integer> indexMap = (java.util.Map<String, java.lang.Integer>) indexMapField.get(keyedValues);
                                                                                                                                     assertEquals(1, indexMap.size());
                                                                                                                                     assertEquals(java.lang.Integer.valueOf(0), indexMap.get("Key2"));
                                                                                                                                 } catch (Exception e) {
                                                                                                                                     fail("Reflection failed: " + e.getMessage());
                                                                                                                                 }
                                                                                                                             }

    @Test
                                                                                                                        public void testHashCodeWhenKeysIsNull() throws Exception {
                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                            
                                                                                                                            // Use reflection to set private field to null
                                                                                                                            Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                            keysField.setAccessible(true);
                                                                                                                            keysField.set(dkv, null);
                                                                                                                            
                                                                                                                            // Original should return 0, mutant would throw NullPointerException
                                                                                                                            assertEquals(0, dkv.hashCode());
                                                                                                                        }

    @Test
                                                                                                                        public void testHashCodeWhenKeysIsNotNull() {
                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                            // Use public method to add a key-value pair
                                                                                                                            dkv.addValue("testKey", 1.0);
                                                                                                                            
                                                                                                                            // Original should return keys.hashCode(), mutant would return 0
                                                                                                                            assertNotEquals(0, dkv.hashCode());
                                                                                                                            assertEquals(dkv.getKeys().hashCode(), dkv.hashCode());
                                                                                                                        }

    @Test
                                                                                                                        public void testHashCodeWhenKeysNotNull() {
                                                                                                                            // Setup
                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                            ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                                                                            testKeys.add("key1");
                                                                                                                            testKeys.add("key2");
                                                                                                                            
                                                                                                                            // Use reflection to set private field since there's no setter
                                                                                                                            try {
                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                keysField.setAccessible(true);
                                                                                                                                keysField.set(dkv, testKeys);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set keys field via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Test - original should return keys.hashCode(), mutant returns 0
                                                                                                                            assertNotEquals("Hash code should not be 0 when keys exist", 0, dkv.hashCode());
                                                                                                                        }

    @Test
                                                                                                                        public void testHashCodeWhenKeysNull() {
                                                                                                                            // Setup
                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                            
                                                                                                                            // Set keys to null via reflection
                                                                                                                            try {
                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                keysField.setAccessible(true);
                                                                                                                                keysField.set(dkv, null);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set keys field to null via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Test - original returns 0, mutant would throw NPE
                                                                                                                            assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                        }

    @Test
                                                                                                                   public void testHashCodeWithNullKeys() {
                                                                                                                       // Create instance with null keys
                                                                                                                       DefaultKeyedValues instance = new DefaultKeyedValues();
                                                                                                                       
                                                                                                                       // Use reflection to set keys to null since it's private
                                                                                                                       try {
                                                                                                                           Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                           keysField.setAccessible(true);
                                                                                                                           keysField.set(instance, null);
                                                                                                                       } catch (Exception e) {
                                                                                                                           fail("Failed to set keys to null via reflection");
                                                                                                                       }
                                                                                                                       
                                                                                                                       // Test that hashCode returns 0 when keys is null
                                                                                                                       assertEquals(0, instance.hashCode());
                                                                                                                   }

    @Test
                                                                                                                      public void testHashCodeWithNullKeys1() {
                                                                                                                          // Create instance with null keys
                                                                                                                          DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                          // Set keys to null through reflection since it's private
                                                                                                                          try {
                                                                                                                              java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                              keysField.setAccessible(true);
                                                                                                                              keysField.set(dkv, null);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set keys to null via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Test that hashCode returns 0 when keys is null
                                                                                                                          assertEquals("HashCode should return 0 when keys is null", 0, dkv.hashCode());
                                                                                                                      }

    @Test
                                                                                                                      public void testHashCodeWithNonNullKeys() {
                                                                                                                          // Create instance with non-null keys
                                                                                                                          DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                          dkv.addValue("Key1", 10); // This will populate the keys list
                                                                                                                          
                                                                                                                          // Test that hashCode returns keys.hashCode()
                                                                                                                          assertEquals("HashCode should return keys.hashCode() when keys is not null", 
                                                                                                                                       dkv.getKeys().hashCode(), dkv.hashCode());
                                                                                                                      }

    @Test
                                                                                                                     public void testHashCodeWithNonNullKeys1() {
                                                                                                                         // Create test object with non-null keys
                                                                                                                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                         dkv.addValue("Key1", 10);  // This will add to keys list
                                                                                                                         
                                                                                                                         // Get the expected hash code from the keys list directly
                                                                                                                         int expectedHash = dkv.getKeys().hashCode();
                                                                                                                         
                                                                                                                         // Verify the actual hash code matches the expected one
                                                                                                                         assertEquals("Hash code should match keys list hash", 
                                                                                                                                     expectedHash, dkv.hashCode());
                                                                                                                         
                                                                                                                         // Add another key to change the hash
                                                                                                                         dkv.addValue("Key2", 20);
                                                                                                                         int newExpectedHash = dkv.getKeys().hashCode();
                                                                                                                         assertNotEquals("Hash code should change when keys change",
                                                                                                                                       expectedHash, dkv.hashCode());
                                                                                                                         assertEquals("New hash code should match new keys list hash",
                                                                                                                                    newExpectedHash, dkv.hashCode());
                                                                                                                     }

    @Test
                                                                                                                     public void testHashCodeWithNullKeys2() {
                                                                                                                         // Create test object and force keys to be null
                                                                                                                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                         try {
                                                                                                                             // Using reflection to set keys to null for testing
                                                                                                                             java.lang.reflect.Field field = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                             field.setAccessible(true);
                                                                                                                             field.set(dkv, null);
                                                                                                                             
                                                                                                                             assertEquals("Hash code should be 0 when keys is null",
                                                                                                                                         0, dkv.hashCode());
                                                                                                                         } catch (Exception e) {
                                                                                                                             fail("Failed to set keys to null via reflection");
                                                                                                                         }
                                                                                                                     }

    @Test
                                                                                                                public void testHashCodeWhenKeysIsNull1() {
                                                                                                                    // Create an instance of DefaultKeyedValues
                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                    
                                                                                                                    // Set keys to null using reflection since it's private
                                                                                                                    try {
                                                                                                                        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                        keysField.setAccessible(true);
                                                                                                                        keysField.set(dkv, null);
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Failed to set keys to null via reflection");
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Test the original behavior - should return 0
                                                                                                                    assertEquals(0, dkv.hashCode());
                                                                                                                    
                                                                                                                    // The mutant would throw NullPointerException here
                                                                                                                    // In JUnit4, we can test for expected exception like this:
                                                                                                                    try {
                                                                                                                        dkv.hashCode();
                                                                                                                    } catch (NullPointerException e) {
                                                                                                                        fail("Mutant detected: hashCode() threw NullPointerException when keys is null");
                                                                                                                    }
                                                                                                                }

    @Test
                                                                                                              public void testHashCodeDetectsMutant() {
                                                                                                                  // Setup
                                                                                                                  DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                  List<String> testKeys = Arrays.asList("key1", "key2", "key3");
                                                                                                                  
                                                                                                                  // Add values to populate the keys list through public API
                                                                                                                  for (String key : testKeys) {
                                                                                                                      dkv.addValue(key, 0); // value doesn't matter for this test
                                                                                                                  }
                                                                                                                  
                                                                                                                  // Calculate expected hash code (based on ArrayList's hashCode implementation)
                                                                                                                  int expectedHash = 1;
                                                                                                                  for (String key : testKeys) {
                                                                                                                      expectedHash = 31 * expectedHash + (key == null ? 0 : key.hashCode());
                                                                                                                  }
                                                                                                                  
                                                                                                                  // Test
                                                                                                                  int actualHash = dkv.hashCode();
                                                                                                                  
                                                                                                                  // Assert - this will catch the mutant because toString().hashCode() would be different
                                                                                                                  assertEquals("Hash code should be based on keys' hash codes, not string representation", 
                                                                                                                              expectedHash, actualHash);
                                                                                                              }

    @Test
                                                                                                              public void testHashCodeWithNullKeys3() {
                                                                                                                  // Setup
                                                                                                                  DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                  try {
                                                                                                                      // Use reflection to set private keys field to null
                                                                                                                      Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                      keysField.setAccessible(true);
                                                                                                                      keysField.set(dkv, null);
                                                                                                                  } catch (Exception e) {
                                                                                                                      fail("Failed to set keys field to null via reflection");
                                                                                                                  }
                                                                                                                  
                                                                                                                  // Test and assert
                                                                                                                  assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                              }

    @Test
                                                                                                         public void testHashCodeDetectsMutant1() throws Exception {
                                                                                                             // Create test object
                                                                                                             DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                             
                                                                                                             // Get the private keys field using reflection
                                                                                                             Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                             keysField.setAccessible(true);
                                                                                                             
                                                                                                             // Case 1: keys is null - both versions return 0
                                                                                                             keysField.set(dkv, null);
                                                                                                             assertEquals(0, dkv.hashCode());
                                                                                                             
                                                                                                             // Case 2: keys is empty - both versions return 0
                                                                                                             keysField.set(dkv, new ArrayList());
                                                                                                             assertEquals(0, dkv.hashCode());
                                                                                                             
                                                                                                             // Case 3: keys has elements - this will detect the mutant
                                                                                                             ArrayList<Comparable> keys = new ArrayList<>();
                                                                                                             keys.add("key1");
                                                                                                             keys.add("key2");
                                                                                                             keysField.set(dkv, keys);
                                                                                                             
                                                                                                             // Original would return keys.hashCode(), mutant returns keys.size() (2)
                                                                                                             // We know that for ArrayList, hashCode is calculated based on elements,
                                                                                                             // so it won't equal the size unless by coincidence
                                                                                                             int originalHash = keys.hashCode();
                                                                                                             assertNotEquals("Hash code should not equal list size", 
                                                                                                                            keys.size(), originalHash);
                                                                                                             
                                                                                                             // This assertion would fail if the mutant is present
                                                                                                             assertEquals(originalHash, dkv.hashCode());
                                                                                                         }

    @Test
                                                                                                     public void testHashCode_ShouldReturnSameHashForEqualKeysLists() {
                                                                                                         // Create two separate but equal keys lists
                                                                                                         List<Comparable> keys1 = new ArrayList<>();
                                                                                                         keys1.add("Key1");
                                                                                                         keys1.add("Key2");
                                                                                                         
                                                                                                         List<Comparable> keys2 = new ArrayList<>();
                                                                                                         keys2.add("Key1");
                                                                                                         keys2.add("Key2");
                                                                                                         
                                                                                                         // Create two DefaultKeyedValues instances
                                                                                                         DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                         DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                         
                                                                                                         // Use reflection to set the private keys field since there's no public setter
                                                                                                         try {
                                                                                                             Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                             keysField.setAccessible(true);
                                                                                                             keysField.set(dkv1, keys1);
                                                                                                             keysField.set(dkv2, keys2);
                                                                                                         } catch (Exception e) {
                                                                                                             fail("Failed to set keys field via reflection");
                                                                                                         }
                                                                                                         
                                                                                                         // Original behavior: hash codes should be equal because keys lists have same content
                                                                                                         // Mutated behavior: hash codes will likely differ because of identityHashCode
                                                                                                         assertEquals("Hash codes should be equal for equal keys lists", 
                                                                                                                      dkv1.hashCode(), dkv2.hashCode());
                                                                                                         
                                                                                                         // Additional test case for null keys
                                                                                                         DefaultKeyedValues dkvNull = new DefaultKeyedValues();
                                                                                                         try {
                                                                                                             Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                             keysField.setAccessible(true);
                                                                                                             keysField.set(dkvNull, null);
                                                                                                         } catch (Exception e) {
                                                                                                             fail("Failed to set keys field to null via reflection");
                                                                                                         }
                                                                                                         assertEquals("Hash code should be 0 when keys is null", 0, dkvNull.hashCode());
                                                                                                     }

    @Test
                                                                                                        public void testHashCodeWithNullKeys4() {
                                                                                                            // Create an object with null keys
                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                            
                                                                                                            // Use reflection to set keys to null since it's private
                                                                                                            try {
                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                keysField.setAccessible(true);
                                                                                                                keysField.set(dkv, null);
                                                                                                            } catch (Exception e) {
                                                                                                                fail("Failed to set keys to null via reflection");
                                                                                                            }
                                                                                                            
                                                                                                            // Test that hashCode returns 0 when keys is null
                                                                                                            assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                        }

    @Test
                                                                                                        public void testHashCodeWithNonNullKeys2() {
                                                                                                            // Create an object with non-null keys
                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                            dkv.addValue("Key1", 10.0);
                                                                                                            
                                                                                                            // Calculate expected hash code
                                                                                                            int expectedHash = dkv.getKeys().hashCode();
                                                                                                            
                                                                                                            assertEquals("Hash code should match keys' hash code", expectedHash, dkv.hashCode());
                                                                                                        }

    @Test
                                                                                                       public void testHashCodeWithNullKeys5() {
                                                                                                           // Setup - create instance with null keys
                                                                                                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                           // Use reflection to set keys to null since it's private
                                                                                                           try {
                                                                                                               java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                               keysField.setAccessible(true);
                                                                                                               keysField.set(dkv, null);
                                                                                                           } catch (Exception e) {
                                                                                                               fail("Failed to set keys to null via reflection");
                                                                                                           }
                                                                                                           
                                                                                                           // Test and verify
                                                                                                           assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                       }

    @Test
                                                                                                       public void testHashCodeWithNonNullKeys3() {
                                                                                                           // Setup - create instance with some keys
                                                                                                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                           ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                                                           testKeys.add("key1");
                                                                                                           testKeys.add("key2");
                                                                                                           
                                                                                                           // Use reflection to set keys since it's private
                                                                                                           try {
                                                                                                               java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                               keysField.setAccessible(true);
                                                                                                               keysField.set(dkv, testKeys);
                                                                                                           } catch (Exception e) {
                                                                                                               fail("Failed to set keys via reflection");
                                                                                                           }
                                                                                                           
                                                                                                           // Test and verify
                                                                                                           int expectedHash = testKeys.hashCode();
                                                                                                           assertEquals("Hash code should match keys' hash code", expectedHash, dkv.hashCode());
                                                                                                       }

    @Test
                                                                                                 public void testHashCodeWithNullKeys6() throws Exception {
                                                                                                     // Create instance with null keys
                                                                                                     DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                     
                                                                                                     // Use reflection to set private keys field to null
                                                                                                     Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                     keysField.setAccessible(true);
                                                                                                     keysField.set(dkv, null);
                                                                                                     
                                                                                                     // Test that hashCode returns 0 when keys is null
                                                                                                     assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                     
                                                                                                     // The mutant would return dkv.hashCode() which would be different from 0
                                                                                                     // since it's the default object hash code
                                                                                                 }

    @Test
                                                                                            public void testHashCodeWithNonNullKeys4() {
                                                                                                // Setup
                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                List<String> testKeys = Arrays.asList("key1", "key2", "key3");
                                                                                                
                                                                                                try {
                                                                                                    // Use reflection to set private keys field
                                                                                                    Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                    keysField.setAccessible(true);
                                                                                                    keysField.set(dkv, new ArrayList<>(testKeys));
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to set keys field via reflection: " + e.getMessage());
                                                                                                }
                                                                                                
                                                                                                // Expected value is the hash code of the keys list
                                                                                                int expectedHash = testKeys.hashCode();
                                                                                                
                                                                                                // Test
                                                                                                int actualHash = dkv.hashCode();
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals("Hash code should equal keys' hash code", expectedHash, actualHash);
                                                                                                
                                                                                                // Additional verification that it's not using super.hashCode()
                                                                                                assertNotEquals("Hash code should not equal superclass hash code", 
                                                                                                               dkv.getClass().getSuperclass().hashCode(), actualHash);
                                                                                            }

    @Test
                                                                                            public void testHashCodeWhenKeysIsNull2() {
                                                                                                // Create an instance with null keys
                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                // Use reflection to set keys to null since it's private
                                                                                                try {
                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                    keysField.setAccessible(true);
                                                                                                    keysField.set(dkv, null);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to set keys to null via reflection");
                                                                                                }
                                                                                                
                                                                                                // Test that hashCode returns 0 when keys is null
                                                                                                assertEquals(0, dkv.hashCode());
                                                                                            }

    @Test
                                                                                            public void testHashCodeWhenKeysIsNotNull1() {
                                                                                                // Create an instance with non-null keys
                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                dkv.addValue("key1", 1.0);
                                                                                                
                                                                                                // Calculate expected hash code
                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                
                                                                                                // Test that hashCode returns the hash of keys list
                                                                                                assertEquals(expectedHash, dkv.hashCode());
                                                                                            }

    @Test
                                                                                       public void testHashCodeDetectsMutant2() {
                                                                                           // Create test objects
                                                                                           DefaultKeyedValues nullKeysInstance = new DefaultKeyedValues();
                                                                                           DefaultKeyedValues emptyKeysInstance = new DefaultKeyedValues();
                                                                                           emptyKeysInstance.addValue("key1", 1.0);
                                                                                           DefaultKeyedValues nonEmptyKeysInstance = new DefaultKeyedValues();
                                                                                           nonEmptyKeysInstance.addValue("key2", 2.0);
                                                                                           
                                                                                           // Test null keys case (should return 0)
                                                                                           assertEquals(0, nullKeysInstance.hashCode());
                                                                                           
                                                                                           // Test non-null keys cases (should return different hash codes)
                                                                                           assertNotEquals(0, emptyKeysInstance.hashCode());
                                                                                           assertNotEquals(0, nonEmptyKeysInstance.hashCode());
                                                                                           
                                                                                           // Verify different key lists produce different hash codes
                                                                                           assertNotEquals(emptyKeysInstance.hashCode(), nonEmptyKeysInstance.hashCode());
                                                                                           
                                                                                           // Additional check: verify hash code matches keys.hashCode()
                                                                                           assertEquals(emptyKeysInstance.getKeys().hashCode(), emptyKeysInstance.hashCode());
                                                                                           assertEquals(nonEmptyKeysInstance.getKeys().hashCode(), nonEmptyKeysInstance.hashCode());
                                                                                       }

    @Test
                                                                                     public void testHashCodeWithNonNullKeys5() {
                                                                                         // Setup
                                                                                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                         List<Comparable> testKeys = Arrays.asList("Key1", "Key2", "Key3");
                                                                                         
                                                                                         // Add values using public API
                                                                                         for (Comparable key : testKeys) {
                                                                                             dkv.addValue(key, 0); // value doesn't matter for hashCode test
                                                                                         }
                                                                                         
                                                                                         // Calculate expected hash code
                                                                                         int expectedHash = testKeys.hashCode();
                                                                                         
                                                                                         // Test
                                                                                         int actualHash = dkv.hashCode();
                                                                                         
                                                                                         // Assert - mutant will return expectedHash << 1 instead of expectedHash
                                                                                         assertEquals("Hash code should match keys list's hash code", 
                                                                                                     expectedHash, actualHash);
                                                                                         
                                                                                         // Additional check to explicitly catch the shift mutation
                                                                                         assertNotEquals("Hash code should not be double the expected value",
                                                                                                        expectedHash << 1, actualHash);
                                                                                     }

    @Test
                                                                                     public void testHashCodeWithNullKeys7() throws Exception {
                                                                                         // Setup
                                                                                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                         
                                                                                         // Use reflection to set private field
                                                                                         Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                         keysField.setAccessible(true);
                                                                                         keysField.set(dkv, null);
                                                                                         
                                                                                         // Test and assert
                                                                                         assertEquals("Hash code should be 0 when keys is null", 
                                                                                                     0, dkv.hashCode());
                                                                                     }

    @Test
                                                                                     public void testHashCodeWithNonNullKeys6() {
                                                                                         // Setup
                                                                                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                         ArrayList<Comparable> keys = new ArrayList<>();
                                                                                         keys.add("key1");
                                                                                         keys.add("key2");
                                                                                         
                                                                                         // Use reflection to set the private keys field since there's no public setter
                                                                                         try {
                                                                                             java.lang.reflect.Field field = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                             field.setAccessible(true);
                                                                                             field.set(dkv, keys);
                                                                                         } catch (Exception e) {
                                                                                             fail("Failed to set keys field via reflection");
                                                                                         }
                                                                                         
                                                                                         // Calculate expected hash code (original behavior)
                                                                                         int expectedHashCode = keys.hashCode();
                                                                                         
                                                                                         // Test
                                                                                         int actualHashCode = dkv.hashCode();
                                                                                         
                                                                                         // Assert
                                                                                         assertEquals("Hash code should equal keys.hashCode() without any bit shifting", 
                                                                                                     expectedHashCode, actualHashCode);
                                                                                         
                                                                                         // Additional check to ensure the mutant would be caught
                                                                                         // The mutant would return expectedHashCode >> 1, which would fail this assertion
                                                                                         assertNotEquals("Hash code should not equal keys.hashCode() >> 1", 
                                                                                                        expectedHashCode >> 1, actualHashCode);
                                                                                     }

    @Test
                                                                                     public void testHashCodeWithNullKeys8() {
                                                                                         // Setup
                                                                                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                         
                                                                                         // Test
                                                                                         int hashCode = dkv.hashCode();
                                                                                         
                                                                                         // Assert
                                                                                         assertEquals("Hash code should be 0 when keys is null", 0, hashCode);
                                                                                     }

    @Test
                                                                                    public void testHashCodeWithNonNullKeys7() {
                                                                                        // Setup
                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                        ArrayList<Comparable> keys = new ArrayList<>();
                                                                                        keys.add("key1");
                                                                                        keys.add("key2");
                                                                                        
                                                                                        // Use reflection to set the private keys field since there's no public setter
                                                                                        try {
                                                                                            java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                            keysField.setAccessible(true);
                                                                                            keysField.set(dkv, keys);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set keys field via reflection");
                                                                                        }
                                                                                        
                                                                                        // Calculate expected hash code
                                                                                        int expectedHashCode = keys.hashCode();
                                                                                        
                                                                                        // Test
                                                                                        assertEquals("Hash code should match keys list's hash code", 
                                                                                                    expectedHashCode, dkv.hashCode());
                                                                                        
                                                                                        // The mutant would return ~expectedHashCode, which would fail this assertion
                                                                                    }

    @Test
                                                                                    public void testHashCodeWithNullKeys9() {
                                                                                        // Setup - new instance has empty keys list, not null
                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                        
                                                                                        // Use reflection to set keys to null
                                                                                        try {
                                                                                            java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                            keysField.setAccessible(true);
                                                                                            keysField.set(dkv, null);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set keys field via reflection");
                                                                                        }
                                                                                        
                                                                                        // Test
                                                                                        assertEquals("Hash code should be 0 when keys is null", 
                                                                                                    0, dkv.hashCode());
                                                                                    }

    @Test
                                                                               public void testHashCodeWithNonNullKeys8() {
                                                                                   // Setup
                                                                                   DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                   List<Comparable> testKeys = new ArrayList<>();
                                                                                   testKeys.add("key1");
                                                                                   testKeys.add("key2");
                                                                                   
                                                                                   // Use reflection to set the private keys field since there's no public setter
                                                                                   try {
                                                                                       Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                       keysField.setAccessible(true);
                                                                                       keysField.set(dkv, testKeys);
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to set keys field via reflection");
                                                                                   }
                                                                                   
                                                                                   // Calculate expected hash code (original behavior)
                                                                                   int expectedHash = testKeys.hashCode();
                                                                                   
                                                                                   // Get actual hash code
                                                                                   int actualHash = dkv.hashCode();
                                                                                   
                                                                                   // Assert - this will fail for the mutated version
                                                                                   assertEquals("Hash code should equal keys.hashCode() without modification", 
                                                                                                expectedHash, actualHash);
                                                                               }

    @Test
                                                                               public void testHashCodeWithNullKeys10() {
                                                                                   // Setup - new instance has non-null keys by default
                                                                                   DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                   
                                                                                   // Use reflection to set keys to null
                                                                                   try {
                                                                                       Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                       keysField.setAccessible(true);
                                                                                       keysField.set(dkv, null);
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to set keys field via reflection");
                                                                                   }
                                                                                   
                                                                                   // Test - should return 0 for null keys
                                                                                   assertEquals("Hash code should be 0 when keys is null", 
                                                                                                0, dkv.hashCode());
                                                                               }

    @Test
                                                                             public void testHashCodeReturnsExactKeysHashCode() {
                                                                                 // Setup
                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                 List<String> testKeys = Arrays.asList("key1", "key2", "key3");
                                                                                 
                                                                                 // Add values using public API
                                                                                 for (String key : testKeys) {
                                                                                     dkv.addValue(key, 0); // value doesn't matter for hashCode test
                                                                                 }
                                                                                 
                                                                                 // Expected - should match keys.hashCode() exactly
                                                                                 int expectedHash = testKeys.hashCode();
                                                                                 
                                                                                 // Actual
                                                                                 int actualHash = dkv.hashCode();
                                                                                 
                                                                                 // Assert - verify hash codes match exactly (not OR'ed with 1)
                                                                                 assertEquals("Hash code should exactly match keys.hashCode()", 
                                                                                             expectedHash, actualHash);
                                                                                 
                                                                                 // Additional check - if keys.hashCode() was even, mutant would make it odd
                                                                                 // This helps detect the OR 1 mutation
                                                                                 if (expectedHash % 2 == 0) {
                                                                                     assertTrue("Hash code should maintain original parity", 
                                                                                              actualHash % 2 == 0);
                                                                                 }
                                                                             }

    @Test
                                                                             public void testHashCodeWithNonNullKeys9() {
                                                                                 // Setup
                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                 ArrayList<Comparable> keys = new ArrayList<>();
                                                                                 keys.add("key1");
                                                                                 keys.add("key2");
                                                                                 
                                                                                 // Use reflection to set the private keys field since there's no public setter
                                                                                 try {
                                                                                     java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                     keysField.setAccessible(true);
                                                                                     keysField.set(dkv, keys);
                                                                                 } catch (Exception e) {
                                                                                     fail("Failed to set keys field via reflection");
                                                                                 }
                                                                                 
                                                                                 // Test - original should return non-zero, mutant will return 0
                                                                                 int hashCode = dkv.hashCode();
                                                                                 assertNotEquals("Hash code should not be 0 when keys are non-null", 0, hashCode);
                                                                             }

    @Test
                                                                             public void testHashCodeWithNullKeys11() {
                                                                                 // Setup - new instance has non-null keys by default
                                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                 
                                                                                 // Use reflection to set keys to null
                                                                                 try {
                                                                                     java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                     keysField.setAccessible(true);
                                                                                     keysField.set(dkv, null);
                                                                                 } catch (Exception e) {
                                                                                     fail("Failed to set keys field via reflection");
                                                                                 }
                                                                                 
                                                                                 // Test - both original and mutant should return 0
                                                                                 assertEquals(0, dkv.hashCode());
                                                                             }

    @Test
                                                                        public void testHashCodeWithNonNullKeys10() {
                                                                            // Setup
                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                            List<String> testKeys = Arrays.asList("key1", "key2", "key3");
                                                                            
                                                                            // Add keys to make keys list non-null
                                                                            for (String key : testKeys) {
                                                                                dkv.addValue(key, 1.0);
                                                                            }
                                                                            
                                                                            // Get the expected hash code from the keys list directly
                                                                            int expectedHashCode = dkv.getKeys().hashCode();
                                                                            
                                                                            // Test
                                                                            int actualHashCode = dkv.hashCode();
                                                                            
                                                                            // Assert
                                                                            assertEquals("Hash code should be equal to keys.hashCode()", 
                                                                                         expectedHashCode, actualHashCode);
                                                                            
                                                                            // Additional check to ensure we're testing the right thing
                                                                            assertNotEquals("Hash code should not be keys.hashCode() + 1 (mutant check)",
                                                                                           expectedHashCode + 1, actualHashCode);
                                                                        }

    @Test
                                                                        public void testHashCodeWithNullKeys12() {
                                                                            // Setup - create object with reflection to make keys null
                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                            try {
                                                                                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                keysField.setAccessible(true);
                                                                                keysField.set(dkv, null);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set keys to null via reflection");
                                                                            }
                                                                            
                                                                            // Test and assert
                                                                            assertEquals("Hash code should be 0 when keys is null", 
                                                                                         0, dkv.hashCode());
                                                                        }

    @Test
                                                                           public void testHashCodeWithNonNullKeys11() {
                                                                               // Setup
                                                                               DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                               ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                               testKeys.add("key1");
                                                                               testKeys.add("key2");
                                                                               
                                                                               // Use reflection to set the private keys field since there's no public setter
                                                                               try {
                                                                                   java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                   keysField.setAccessible(true);
                                                                                   keysField.set(dkv, testKeys);
                                                                               } catch (Exception e) {
                                                                                   fail("Failed to set keys field via reflection");
                                                                               }
                                                                               
                                                                               // Calculate expected hash code
                                                                               int expectedHashCode = testKeys.hashCode();
                                                                               
                                                                               // Test
                                                                               assertEquals("Hash code should match keys list's hash code", 
                                                                                           expectedHashCode, 
                                                                                           dkv.hashCode());
                                                                           }

    @Test
                                                                           public void testHashCodeWithNullKeys13() {
                                                                               // Setup - new instance has non-null keys by default
                                                                               DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                               
                                                                               // Use reflection to set keys to null
                                                                               try {
                                                                                   java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                   keysField.setAccessible(true);
                                                                                   keysField.set(dkv, null);
                                                                               } catch (Exception e) {
                                                                                   fail("Failed to set keys field via reflection");
                                                                               }
                                                                               
                                                                               // Test
                                                                               assertEquals("Hash code should be 0 when keys is null", 
                                                                                           0, 
                                                                                           dkv.hashCode());
                                                                           }

    @Test
                                                                          public void testHashCodeWithNonNullKeys12() {
                                                                              // Setup
                                                                              DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                              dkv.addValue("Key1", 10);  // This will add to keys list
                                                                              
                                                                              // Get the expected hash code directly from the keys list
                                                                              int expectedHash = dkv.getKeys().hashCode();
                                                                              
                                                                              // Test - should return the exact hash code of keys list
                                                                              assertEquals("Hash code should match keys list's hash code exactly", 
                                                                                           expectedHash, dkv.hashCode());
                                                                              
                                                                              // Additional test with different keys
                                                                              DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                              dkv2.addValue("Key2", 20);
                                                                              int expectedHash2 = dkv2.getKeys().hashCode();
                                                                              assertEquals("Hash code should match keys list's hash code exactly", 
                                                                                           expectedHash2, dkv2.hashCode());
                                                                          }

    @Test
                                                                          public void testHashCodeWithNullKeys14() {
                                                                              // Setup - new object has empty keys list (not null)
                                                                              // To test null case, we need to set keys to null through reflection
                                                                              DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                              try {
                                                                                  java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                  keysField.setAccessible(true);
                                                                                  keysField.set(dkv, null);
                                                                                  
                                                                                  // Test
                                                                                  assertEquals("Hash code should be 0 when keys is null", 
                                                                                               0, dkv.hashCode());
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to set keys to null for testing");
                                                                              }
                                                                          }

    @Test
                                                                     public void testHashCodeWithNonNullKeys13() {
                                                                         // Setup
                                                                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                         List<String> testKeys = Arrays.asList("key1", "key2", "key3");
                                                                         List<Number> testValues = Arrays.asList(1, 2, 3);
                                                                         
                                                                         // Add test data (using reflection since add methods aren't visible in given info)
                                                                         try {
                                                                             Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                             keysField.setAccessible(true);
                                                                             keysField.set(dkv, new ArrayList(testKeys));
                                                                             
                                                                             Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                                                                             valuesField.setAccessible(true);
                                                                             valuesField.set(dkv, new ArrayList(testValues));
                                                                         } catch (Exception e) {
                                                                             fail("Failed to setup test data via reflection");
                                                                         }
                                                                         
                                                                         // Calculate expected hash code
                                                                         int expectedHash = testKeys.hashCode();
                                                                         
                                                                         // Test
                                                                         assertEquals("Hash code should equal keys' hash code", 
                                                                                      expectedHash, dkv.hashCode());
                                                                         
                                                                         // Additional check to ensure test would catch the mutant
                                                                         // The mutant would return expectedHash/2, which would fail the assertion
                                                                         assertNotEquals("Test should fail if hash code is halved", 
                                                                                        expectedHash/2, dkv.hashCode());
                                                                     }

    @Test
                                                                     public void testHashCodeWithNullKeys15() {
                                                                         // Setup
                                                                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                         
                                                                         // Set keys to null via reflection
                                                                         try {
                                                                             Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                             keysField.setAccessible(true);
                                                                             keysField.set(dkv, null);
                                                                         } catch (Exception e) {
                                                                             fail("Failed to set keys to null via reflection");
                                                                         }
                                                                         
                                                                         // Test
                                                                         assertEquals("Hash code should be 0 when keys is null", 
                                                                                      0, dkv.hashCode());
                                                                     }

    @Test
                                                                    public void testHashCodeWithNegativeHash() {
                                                                        // Setup - create a keys list that will produce negative hash code
                                                                        DefaultKeyedValues instance = new DefaultKeyedValues();
                                                                        
                                                                        // ArrayList's hashCode is computed as: 31*element1.hashCode() + element2.hashCode()...
                                                                        // We need elements that will produce negative result when combined
                                                                        // Using Integer objects since their hashCode() is their int value
                                                                        instance.addValue("key1", 1000000);  // large positive number
                                                                        instance.addValue("key2", -1000000); // large negative number
                                                                        
                                                                        // Calculate expected hash code manually
                                                                        int expectedHash = 31 * "key1".hashCode() + "key2".hashCode();
                                                                        
                                                                        // Verify the hash code is negative (our test condition)
                                                                        assertTrue("Test setup failed - hash code should be negative", expectedHash < 0);
                                                                        
                                                                        // Test - the original should return negative, mutant would return positive
                                                                        int actualHash = instance.hashCode();
                                                                        assertEquals("Hash code should match ArrayList's hashCode()", expectedHash, actualHash);
                                                                        
                                                                        // Additional check that would fail with the mutant
                                                                        assertTrue("Hash code should be negative", actualHash < 0);
                                                                    }

    @Test
                                                                       public void testHashCodeWithNonNullKeys14() {
                                                                           // Setup
                                                                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                           ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                           testKeys.add("key1");
                                                                           testKeys.add("key2");
                                                                           
                                                                           // Use reflection to set the private keys field since there's no public setter
                                                                           try {
                                                                               java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                               keysField.setAccessible(true);
                                                                               keysField.set(dkv, testKeys);
                                                                           } catch (Exception e) {
                                                                               fail("Failed to set keys field via reflection");
                                                                           }
                                                                           
                                                                           // Calculate expected hash code (positive value)
                                                                           int expectedHash = testKeys.hashCode();
                                                                           
                                                                           // Verify the hash code is positive and matches expected
                                                                           int actualHash = dkv.hashCode();
                                                                           assertTrue("Hash code should be positive", actualHash > 0);
                                                                           assertEquals("Hash code should match keys' hash code", expectedHash, actualHash);
                                                                       }

    @Test
                                                                       public void testHashCodeWithNullKeys16() {
                                                                           // Setup object with null keys (default constructor initializes empty list)
                                                                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                           
                                                                           // Use reflection to set keys to null
                                                                           try {
                                                                               java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                               keysField.setAccessible(true);
                                                                               keysField.set(dkv, null);
                                                                           } catch (Exception e) {
                                                                               fail("Failed to set keys field via reflection");
                                                                           }
                                                                           
                                                                           // Verify hash code is 0 when keys is null
                                                                           assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                       }

    @Test
                                                                      public void testHashCodeWithKeysHavingLargeHashCode() {
                                                                          // Create a DefaultKeyedValues instance
                                                                          DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                          
                                                                          // Create a keys list that will have a large hash code (>= 100)
                                                                          ArrayList<Comparable> keys = new ArrayList<>();
                                                                          // Adding enough elements to ensure the hash code will be >= 100
                                                                          for (int i = 0; i < 10; i++) {
                                                                              keys.add("Key" + i);
                                                                          }
                                                                          
                                                                          // Set the keys list (using reflection since keys is private)
                                                                          try {
                                                                              java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                              keysField.setAccessible(true);
                                                                              keysField.set(dkv, keys);
                                                                          } catch (Exception e) {
                                                                              fail("Failed to set keys field via reflection");
                                                                          }
                                                                          
                                                                          // Calculate expected and actual hash codes
                                                                          int expectedHashCode = keys.hashCode();
                                                                          int actualHashCode = dkv.hashCode();
                                                                          
                                                                          // Verify the hash code is not modified by modulo operation
                                                                          // This will fail if the mutant is present (hashCode % 100)
                                                                          assertEquals("Hash code should equal keys.hashCode() without modification", 
                                                                                       expectedHashCode, actualHashCode);
                                                                      }

    @Test
                                                                      public void testHashCodeWithNullKeys17() {
                                                                          // Create a DefaultKeyedValues instance
                                                                          DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                          
                                                                          // Set keys to null (using reflection since keys is private)
                                                                          try {
                                                                              java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                              keysField.setAccessible(true);
                                                                              keysField.set(dkv, null);
                                                                          } catch (Exception e) {
                                                                              fail("Failed to set keys field via reflection");
                                                                          }
                                                                          
                                                                          // Verify hash code is 0 when keys is null
                                                                          assertEquals("Hash code should be 0 when keys is null", 
                                                                                       0, dkv.hashCode());
                                                                      }

    @Test
                                                                     public void testHashCodeWithNullKeys18() {
                                                                         DefaultKeyedValues instance = new DefaultKeyedValues();
                                                                         // By default, keys is initialized as empty ArrayList in constructor
                                                                         // So we need to set it to null to test this case
                                                                         try {
                                                                             java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                             keysField.setAccessible(true);
                                                                             keysField.set(instance, null);
                                                                             
                                                                             // Original should return 0, mutant would return 1
                                                                             assertEquals(0, instance.hashCode());
                                                                         } catch (Exception e) {
                                                                             fail("Failed to set keys to null via reflection");
                                                                         }
                                                                     }

    @Test
                                                                     public void testHashCodeWithNonNullKeys15() {
                                                                         DefaultKeyedValues instance = new DefaultKeyedValues();
                                                                         ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                         testKeys.add("key1");
                                                                         
                                                                         try {
                                                                             java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                             keysField.setAccessible(true);
                                                                             keysField.set(instance, testKeys);
                                                                             
                                                                             int expected = testKeys.hashCode();
                                                                             assertEquals(expected, instance.hashCode());
                                                                         } catch (Exception e) {
                                                                             fail("Failed to set keys via reflection");
                                                                         }
                                                                     }

    @Test
                                                                    public void testHashCodeWithNullKeys19() {
                                                                        // Create instance with null keys
                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                        
                                                                        // Use reflection to set keys to null since it's private
                                                                        try {
                                                                            java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                            keysField.setAccessible(true);
                                                                            keysField.set(dkv, null);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set keys to null via reflection");
                                                                        }
                                                                        
                                                                        // Test that hashCode returns 0 for null keys (original behavior)
                                                                        assertEquals(0, dkv.hashCode());
                                                                    }

    @Test
                                                                    public void testHashCodeWithNonNullKeys16() {
                                                                        // Create normal instance
                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                        
                                                                        // Add some keys to ensure keys is not null
                                                                        dkv.addValue("Key1", 10);
                                                                        
                                                                        // Get expected hash code from the keys list
                                                                        int expectedHash = dkv.getKeys().hashCode();
                                                                        
                                                                        // Test that hashCode returns the same as keys.hashCode()
                                                                        assertEquals(expectedHash, dkv.hashCode());
                                                                    }

    @Test
                                                                   public void testHashCodeWhenKeysIsNull3() {
                                                                       // Create instance and set keys to null through reflection
                                                                       DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                       try {
                                                                           java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                           keysField.setAccessible(true);
                                                                           keysField.set(dkv, null);
                                                                       } catch (Exception e) {
                                                                           fail("Failed to set keys to null via reflection");
                                                                       }
                                                                       
                                                                       // Test that hashCode returns 0 when keys is null
                                                                       assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                   }

    @Test
                                                                   public void testHashCodeWhenKeysIsNotNull2() {
                                                                       // Create instance with non-null keys
                                                                       DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                       dkv.addValue("key1", 10); // This will populate the keys list
                                                                       
                                                                       // Test that hashCode returns keys.hashCode()
                                                                       assertEquals("Hash code should equal keys.hashCode()", 
                                                                                  dkv.getKeys().hashCode(), dkv.hashCode());
                                                                   }

    @Test
                                                             public void testHashCodeWithNullKeys20() throws Exception {
                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                 Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                 keysField.setAccessible(true);
                                                                 keysField.set(dkv, null); // Force null keys using reflection
                                                                 assertEquals(0, dkv.hashCode());
                                                             }

    @Test
                                                             public void testHashCodeWithNonNullKeys17() {
                                                                 DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                 // Use public methods to add keys and values
                                                                 dkv.addValue("key1", 1.0);
                                                                 dkv.addValue("key2", 2.0);
                                                                 
                                                                 // Get the expected hash from the keys list
                                                                 List<Comparable> keys = dkv.getKeys();
                                                                 int expectedHash = keys.hashCode();
                                                                 assertEquals(expectedHash, dkv.hashCode());
                                                             }

    @Test
                                                        public void testHashCodeWithNullKeys21() throws Exception {
                                                            // Create instance
                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                            
                                                            // Use reflection to set private keys field to null
                                                            Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                            keysField.setAccessible(true);
                                                            keysField.set(dkv, null);
                                                            
                                                            // Original behavior should return 0 for null keys
                                                            // Mutant would return -1
                                                            assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                        }

    @Test
                                                        public void testHashCodeWithNonNullKeys18() throws Exception {
                                                            // Create instance with non-null keys
                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                            ArrayList<Comparable> testKeys = new ArrayList<>();
                                                            testKeys.add("key1");
                                                            
                                                            // Use reflection to set private keys field
                                                            Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                            keysField.setAccessible(true);
                                                            keysField.set(dkv, testKeys);
                                                            
                                                            // Both original and mutant should return same hash for non-null case
                                                            assertEquals("Hash code should match keys' hash code", 
                                                                        testKeys.hashCode(), dkv.hashCode());
                                                        }

    @Test
                                                   public void testHashCodeWithNullKeys22() throws Exception {
                                                       // Create instance with null keys
                                                       DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                       
                                                       // Use reflection to set private keys field to null
                                                       Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                       keysField.setAccessible(true);
                                                       keysField.set(dkv, null);
                                                       
                                                       // Original should return 0, mutant would return -1
                                                       assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                   }

    @Test
                                                   public void testHashCodeWithNonNullKeys19() {
                                                       // Create instance with non-null keys
                                                       DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                       // Use public API to add a key-value pair
                                                       dkv.addValue("testKey", 1.0);
                                                       
                                                       // Get the keys list through public API
                                                       List<?> keys = dkv.getKeys();
                                                       
                                                       // Both original and mutant should return same hash code when keys is not null
                                                       assertEquals("Hash code should match keys.hashCode()", 
                                                                   keys.hashCode(), dkv.hashCode());
                                                   }

    @Test
                                              public void testHashCodeWhenKeysIsNull4() {
                                                  // Setup
                                                  DefaultKeyedValues instance = new DefaultKeyedValues();
                                                  
                                                  // Use reflection to set private keys field to null
                                                  try {
                                                      Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                      keysField.setAccessible(true);
                                                      keysField.set(instance, null);
                                                  } catch (NoSuchFieldException | IllegalAccessException e) {
                                                      fail("Failed to set keys field to null via reflection");
                                                  }
                                                  
                                                  // Test
                                                  int result = instance.hashCode();
                                                  
                                                  // Verify - original returns 0, mutant returns 42
                                                  assertEquals("Hash code should be 0 when keys is null", 0, result);
                                              }

    @Test
                                              public void testHashCodeWhenKeysIsNotNull3() {
                                                  // Setup
                                                  DefaultKeyedValues instance = new DefaultKeyedValues();
                                                  // keys is initialized by constructor as empty ArrayList
                                                  int expectedHash = instance.getKeys().hashCode();
                                                  
                                                  // Test
                                                  int result = instance.hashCode();
                                                  
                                                  // Verify - both original and mutant should return same value
                                                  assertEquals("Hash code should equal keys.hashCode() when keys is not null", 
                                                              expectedHash, result);
                                              }

    @Test
                                              public void testHashCodeWithNullKeys23() {
                                                  DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                  // Set keys to null through reflection since it's private
                                                  try {
                                                      java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                      keysField.setAccessible(true);
                                                      keysField.set(dkv, null);
                                                      
                                                      // Verify hashCode returns exactly 0
                                                      assertEquals(0, dkv.hashCode());
                                                  } catch (Exception e) {
                                                      fail("Failed to set keys to null via reflection");
                                                  }
                                              }

    @Test
                                              public void testHashCodeWithNonNullKeys20() {
                                                  DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                  ArrayList<Comparable> testKeys = new ArrayList<>();
                                                  testKeys.add("key1");
                                                  testKeys.add("key2");
                                                  
                                                  // Set keys to our test list through reflection
                                                  try {
                                                      java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                      keysField.setAccessible(true);
                                                      keysField.set(dkv, testKeys);
                                                      
                                                      // Verify hashCode delegates to keys' hashCode
                                                      assertEquals(testKeys.hashCode(), dkv.hashCode());
                                                  } catch (Exception e) {
                                                      fail("Failed to set keys via reflection");
                                                  }
                                              }

    @Test
                                             public void testHashCodeWhenKeysIsNull5() {
                                                 // Setup
                                                 DefaultKeyedValues instance = new DefaultKeyedValues();
                                                 // Set keys to null through reflection since it's private
                                                 try {
                                                     java.lang.reflect.Field field = DefaultKeyedValues.class.getDeclaredField("keys");
                                                     field.setAccessible(true);
                                                     field.set(instance, null);
                                                 } catch (Exception e) {
                                                     fail("Failed to set keys to null via reflection");
                                                 }
                                                 
                                                 // Test - original returns 0, mutant would also return 0 in this case
                                                 // So this test alone wouldn't catch the mutant
                                                 assertEquals(0, instance.hashCode());
                                                 
                                                 // Additional test to catch the mutant
                                                 // The mutant's behavior is only different in the unreachable else branch,
                                                 // but we can verify the complete behavior
                                                 instance = new DefaultKeyedValues(); // keys is initialized to empty ArrayList
                                                 int originalHash = instance.hashCode();
                                                 // If mutant is present, hash would be different when keys is not null
                                                 assertNotEquals(1, originalHash); // Mutant would return 1 in else branch
                                                 assertEquals(instance.getKeys().hashCode(), originalHash); // Original behavior
                                             }

    @Test
                                             public void testHashCodeWhenKeysIsNotNull4() {
                                                 // Setup
                                                 DefaultKeyedValues instance = new DefaultKeyedValues();
                                                 ArrayList<Comparable> keys = new ArrayList<>();
                                                 keys.add("testKey");
                                                 try {
                                                     java.lang.reflect.Field field = DefaultKeyedValues.class.getDeclaredField("keys");
                                                     field.setAccessible(true);
                                                     field.set(instance, keys);
                                                 } catch (Exception e) {
                                                     fail("Failed to set keys via reflection");
                                                 }
                                                 
                                                 // Test
                                                 int expectedHash = keys.hashCode();
                                                 assertEquals(expectedHash, instance.hashCode());
                                                 // This would fail with mutant since mutant would return 1 in the else branch
                                             }

    @Test
                                        public void testHashCodeWhenKeysIsNull6() {
                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                            // Set keys to null using reflection since it's private
                                            try {
                                                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                keysField.setAccessible(true);
                                                keysField.set(dkv, null);
                                            } catch (Exception e) {
                                                fail("Failed to set keys to null via reflection");
                                            }
                                            
                                            // Original should return 0, mutant would return 1
                                            assertEquals(0, dkv.hashCode());
                                        }

    @Test
                                      public void testHashCodeWhenKeysIsNull7() throws Exception {
                                          DefaultKeyedValues dkv = new DefaultKeyedValues();
                                          
                                          // Use reflection to set private 'keys' field to null
                                          Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                          keysField.setAccessible(true);
                                          keysField.set(dkv, null);
                                          
                                          // Original returns 0, mutant returns -1
                                          assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                      }

    @Test
                                      public void testHashCodeWhenKeysIsNotNull5() {
                                          DefaultKeyedValues dkv = new DefaultKeyedValues();
                                          dkv.addValue("testKey", 1.0); // Using public method to add key-value pair
                                          
                                          // Create a separate list with same content to get expected hash code
                                          List<String> expectedKeys = new ArrayList<String>();
                                          expectedKeys.add("testKey");
                                          
                                          assertEquals("Hash code should match keys' hash code", 
                                                      expectedKeys.hashCode(), dkv.hashCode());
                                      }

    @Test
                                 public void testHashCode() throws NoSuchFieldException, IllegalAccessException {
                                     // Get the private 'keys' field using reflection
                                     Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                     keysField.setAccessible(true);
                                     
                                     // Test case 1: keys is null
                                     DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                     keysField.set(dkv1, null); // Set keys to null via reflection
                                     assertEquals("Hash code should be 0 when keys is null", 0, dkv1.hashCode());
                                     
                                     // Test case 2: keys is not null
                                     DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                     List<String> testKeys = new ArrayList<>();
                                     testKeys.add("key1");
                                     testKeys.add("key2");
                                     keysField.set(dkv2, testKeys); // Set test keys via reflection
                                     int expectedHash = testKeys.hashCode();
                                     assertEquals("Hash code should equal keys.hashCode() when keys is not null", 
                                                  expectedHash, dkv2.hashCode());
                                     
                                     // Test case 3: keys is empty list
                                     DefaultKeyedValues dkv3 = new DefaultKeyedValues();
                                     keysField.set(dkv3, new ArrayList<>()); // Set empty list via reflection
                                     assertEquals("Hash code should equal empty list's hash code", 
                                                  new ArrayList<>().hashCode(), dkv3.hashCode());
                                 }

    @Test
                            public void testHashCodeWithNullKeys24() throws Exception {
                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                keysField.setAccessible(true);
                                keysField.set(dkv, null);
                                assertEquals(0, dkv.hashCode());
                            }

    @Test
                            public void testHashCodeWithEmptyKeys() {
                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                assertEquals(dkv.getKeys().hashCode(), dkv.hashCode());
                            }

    @Test
                            public void testHashCodeWithNonEmptyKeys() {
                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                dkv.addValue("key1", 1.0);
                                dkv.addValue("key2", 2.0);
                                
                                // Get the keys list through reflection to verify hashCode
                                try {
                                    Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                    keysField.setAccessible(true);
                                    List<?> keys = (List<?>) keysField.get(dkv);
                                    assertEquals(keys.hashCode(), dkv.hashCode());
                                } catch (Exception e) {
                                    fail("Failed to access private keys field: " + e.getMessage());
                                }
                            }

    @Test
                            public void testHashCodeConsistency() {
                                DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                
                                // Two equal objects must have same hash code
                                ArrayList<String> keys = new ArrayList<>();
                                keys.add("test");
                                
                                try {
                                    // Use reflection to set private fields
                                    Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                    keysField.setAccessible(true);
                                    keysField.set(dkv1, keys);
                                    keysField.set(dkv2, keys);
                                } catch (Exception e) {
                                    fail("Failed to set private fields via reflection: " + e.getMessage());
                                }
                                
                                assertEquals(dkv1.hashCode(), dkv2.hashCode());
                            }

    @Test
                       public void testHashCodeWithNullKeys25() throws Exception {
                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                           Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                           keysField.setAccessible(true);
                           keysField.set(dkv, null);
                           assertEquals(0, dkv.hashCode());
                       }

    @Test
                       public void testHashCodeWithEmptyKeys1() {
                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                           try {
                               Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                               keysField.setAccessible(true);
                               List emptyList = new ArrayList();
                               keysField.set(dkv, emptyList);
                               int expected = emptyList.hashCode();
                               assertEquals(expected, dkv.hashCode());
                           } catch (Exception e) {
                               fail("Failed to access private field through reflection: " + e.getMessage());
                           }
                       }

    @Test
                       public void testHashCodeWithNonEmptyKeys1() {
                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                           dkv.addValue("key1", 1.0);
                           dkv.addValue("key2", 2.0);
                           List keys = dkv.getKeys();
                           int expected = keys.hashCode();
                           assertEquals(expected, dkv.hashCode());
                       }

    @Test
                       public void testHashCodeWithNonNullKeys21() {
                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                           ArrayList<Comparable> testKeys = new ArrayList<>();
                           testKeys.add("key1");
                           testKeys.add("key2");
                           
                           // Using reflection to set private field since there's no setter
                           try {
                               java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                               keysField.setAccessible(true);
                               keysField.set(dkv, testKeys);
                           } catch (Exception e) {
                               fail("Failed to set keys field via reflection");
                           }
                           
                           assertEquals("Hash code should match keys' hash code", 
                                        testKeys.hashCode(), dkv.hashCode());
                       }

    @Test
                       public void testHashCodeWithNullKeys26() {
                           DefaultKeyedValues dkv = new DefaultKeyedValues();
                           
                           // Using reflection to set private field to null
                           try {
                               java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                               keysField.setAccessible(true);
                               keysField.set(dkv, null);
                           } catch (Exception e) {
                               fail("Failed to set keys field to null via reflection");
                           }
                           
                           assertEquals("Hash code should be 0 when keys is null", 
                                        0, dkv.hashCode());
                       }

    @Test
                      public void testHashCodeWithNonNullKeys22() {
                          DefaultKeyedValues dkv = new DefaultKeyedValues();
                          ArrayList<Comparable> testKeys = new ArrayList<>();
                          testKeys.add("key1");
                          testKeys.add("key2");
                          
                          // Use reflection to set the private keys field since there's no public setter
                          try {
                              java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                              keysField.setAccessible(true);
                              keysField.set(dkv, testKeys);
                          } catch (Exception e) {
                              fail("Failed to set keys field via reflection");
                          }
                          
                          assertEquals("Hash code should match keys' hash code", 
                                       testKeys.hashCode(), dkv.hashCode());
                      }

    @Test
                      public void testHashCodeWithNullKeys27() {
                          DefaultKeyedValues dkv = new DefaultKeyedValues();
                          
                          // Use reflection to set the private keys field to null
                          try {
                              java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                              keysField.setAccessible(true);
                              keysField.set(dkv, null);
                          } catch (Exception e) {
                              fail("Failed to set keys field via reflection");
                          }
                          
                          assertEquals("Hash code should be 0 when keys is null", 
                                       0, dkv.hashCode());
                      }

    @Test
                     public void testHashCodeWithNonNullKeys23() {
                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                         ArrayList<Comparable> testKeys = new ArrayList<>();
                         testKeys.add("key1");
                         testKeys.add("key2");
                         
                         // Use reflection to set the private keys field
                         try {
                             java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                             keysField.setAccessible(true);
                             keysField.set(dkv, testKeys);
                         } catch (Exception e) {
                             fail("Failed to set keys field via reflection");
                         }
                         
                         // Verify hash code matches the keys' hash code
                         assertEquals(testKeys.hashCode(), dkv.hashCode());
                     }

    @Test
                     public void testHashCodeWithNullKeys28() {
                         DefaultKeyedValues dkv = new DefaultKeyedValues();
                         
                         // Use reflection to set the private keys field to null
                         try {
                             java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                             keysField.setAccessible(true);
                             keysField.set(dkv, null);
                         } catch (Exception e) {
                             fail("Failed to set keys field via reflection");
                         }
                         
                         // Verify hash code is 0 when keys is null
                         assertEquals(0, dkv.hashCode());
                     }

    @Test
                    public void testHashCodeWithNonNullKeys24() {
                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                        ArrayList<Comparable> testKeys = new ArrayList<>();
                        testKeys.add("key1");
                        testKeys.add("key2");
                        
                        // Use reflection to set the private keys field since there's no setter
                        try {
                            java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                            keysField.setAccessible(true);
                            keysField.set(dkv, testKeys);
                        } catch (Exception e) {
                            fail("Failed to set keys field via reflection");
                        }
                        
                        // Verify the method completes and returns correct hash code
                        assertEquals(testKeys.hashCode(), dkv.hashCode());
                    }

    @Test
                    public void testHashCodeWithNullKeys29() {
                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                        
                        // Use reflection to set keys to null
                        try {
                            java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                            keysField.setAccessible(true);
                            keysField.set(dkv, null);
                        } catch (Exception e) {
                            fail("Failed to set keys field via reflection");
                        }
                        
                        // Verify the method completes and returns 0
                        assertEquals(0, dkv.hashCode());
                    }

    @Test
              public void testHashCodeWithNullKeys30() {
                  DefaultKeyedValues dkv = new DefaultKeyedValues();
                  try {
                      Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                      keysField.setAccessible(true);
                      keysField.set(dkv, null);
                      assertEquals(0, dkv.hashCode());
                  } catch (NoSuchFieldException | IllegalAccessException e) {
                      fail("Failed to set keys field to null via reflection");
                  }
              }

    @Test
              public void testHashCodeWithEmptyKeys2() {
                  DefaultKeyedValues dkv = new DefaultKeyedValues();
                  dkv.clear(); // This will make keys empty but not null
                  int expectedHash = dkv.getKeys().hashCode(); // Use public getter
                  assertEquals(expectedHash, dkv.hashCode());
              }

    @Test
              public void testHashCodeWithPopulatedKeys() {
                  DefaultKeyedValues dkv = new DefaultKeyedValues();
                  dkv.addValue("key1", 1.0);
                  dkv.addValue("key2", 2.0);
                  int expectedHash = dkv.getKeys().hashCode();
                  assertEquals(expectedHash, dkv.hashCode());
              }

    @Test
              public void testHashCodeConsistency1() {
                  DefaultKeyedValues dkv = new DefaultKeyedValues();
                  dkv.addValue("key1", 1.0); // Using public method to add key-value pair
                  int firstHash = dkv.hashCode();
                  int secondHash = dkv.hashCode();
                  assertEquals(firstHash, secondHash);
              }

    @Test
              public void testHashCodeEqualsContract() {
                  DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                  DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                  
                  // Use public API to add values
                  dkv1.addValue("key1", 1.0);
                  dkv2.addValue("key1", 1.0);
                  
                  // If objects are equal, their hash codes must be equal
                  if (dkv1.equals(dkv2)) {
                      assertEquals(dkv1.hashCode(), dkv2.hashCode());
                  }
              }

    @Test
         public void testHashCode1() throws NoSuchFieldException, IllegalAccessException {
             // Test case 1: keys is null
             DefaultKeyedValues dkv1 = new DefaultKeyedValues();
             Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
             keysField.setAccessible(true);
             keysField.set(dkv1, null);
             assertEquals(0, dkv1.hashCode());
             
             // Test case 2: keys is empty
             DefaultKeyedValues dkv2 = new DefaultKeyedValues();
             assertEquals(new ArrayList().hashCode(), dkv2.hashCode());
             
             // Test case 3: keys has elements
             DefaultKeyedValues dkv3 = new DefaultKeyedValues();
             dkv3.addValue("key1", 1);
             dkv3.addValue("key2", 2);
             List<Comparable> keysList = dkv3.getKeys();
             assertEquals(keysList.hashCode(), dkv3.hashCode());
             
             // This would catch the mutant where condition is inverted
             // If mutant changes to 'keys == null', case 2 and 3 would fail
         }

    @Test
    public void testHashCodeWithNonNullKeys25() {
        DefaultKeyedValues dkv = new DefaultKeyedValues();
        ArrayList<Comparable> keys = new ArrayList<>();
        keys.add("key1");
        keys.add("key2");
        
        try {
            Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
            keysField.setAccessible(true);
            keysField.set(dkv, keys);
        } catch (Exception e) {
            fail("Failed to set keys field via reflection: " + e.getMessage());
        }
        
        int expectedHash = keys.hashCode();
        assertEquals("Hash code should match keys' hash code", 
                     expectedHash, dkv.hashCode());
    }

    @Test
    public void testHashCodeWithNullKeys31() throws Exception {
        DefaultKeyedValues dkv = new DefaultKeyedValues();
        
        // Use reflection to set private 'keys' field to null
        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
        keysField.setAccessible(true);
        keysField.set(dkv, null);
        
        assertEquals("Hash code should be 0 when keys is null", 
                    0, dkv.hashCode());
    }


}
