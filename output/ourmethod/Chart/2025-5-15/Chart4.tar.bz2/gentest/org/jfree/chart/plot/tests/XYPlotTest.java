package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.RenderingSource;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYAnnotationBoundsInfo;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.TickType;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.event.ChartChangeEventType;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.renderer.RendererUtilities;
import org.jfree.chart.renderer.xy.AbstractXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.ResourceBundleWrapper;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.data.Range;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.AbstractXYDataset;
import org.jfree.data.xy.SelectableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYDatasetSelectionState;
 
public class XYPlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                        public void testGetDataRange_NullAxis() {
                                                                                                                                                                                                                                                                                                                            XYPlot plot = new XYPlot();  // Initialize the plot object
                                                                                                                                                                                                                                                                                                                            Range result = plot.getDataRange(null);
                                                                                                                                                                                                                                                                                                                            assertNull("Range should be null for null axis", result);
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testGetDataRange_DomainAxisWithNoDatasets() {
                                                                                                                                                                                                                                                                                                                            // Create mock objects
                                                                                                                                                                                                                                                                                                                            XYPlot plot = mock(XYPlot.class);
                                                                                                                                                                                                                                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Set up mock behavior
                                                                                                                                                                                                                                                                                                                            when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                                                                                                                                                                                                                                                                                            when(plot.getRangeAxisIndex(mockAxis)).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Test the method
                                                                                                                                                                                                                                                                                                                            Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                                                                            assertNull("Range should be null when no datasets mapped", result);
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                        public void testGetDataRange_RangeAxisWithNoDatasets() {
                                                                                                                                                                                                                                                                                                                            // Create mock objects
                                                                                                                                                                                                                                                                                                                            XYPlot plot = mock(XYPlot.class);
                                                                                                                                                                                                                                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Set up mock behavior
                                                                                                                                                                                                                                                                                                                            when(plot.getDomainAxisIndex(mockAxis)).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                            when(plot.getRangeAxisIndex(mockAxis)).thenReturn(0);
                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                            // Test the method
                                                                                                                                                                                                                                                                                                                            Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                                                                            assertNull("Range should be null when no datasets mapped", result);
                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                    public void testGetDataRange_DomainAxisWithDatasetAndRenderer() {
                                                                                                                                                                                                                                                                                                                        // Create mock objects
                                                                                                                                                                                                                                                                                                                        XYPlot plot = mock(XYPlot.class);
                                                                                                                                                                                                                                                                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                                                                        XYDataset mockDataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                                                                                        XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Set up mock behavior
                                                                                                                                                                                                                                                                                                                        when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                                                                                                                                                                                                                                                                                        when(plot.getRangeAxisIndex(mockAxis)).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Create a list of datasets to return
                                                                                                                                                                                                                                                                                                                        List<XYDataset> datasets = new ArrayList<>();
                                                                                                                                                                                                                                                                                                                        datasets.add(mockDataset);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Use reflection to access private method if needed
                                                                                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                                                                                            Method method = XYPlot.class.getDeclaredMethod("getDatasetsMappedToDomainAxis", Integer.class);
                                                                                                                                                                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                                                                                                                                                                            when(method.invoke(plot, 0)).thenReturn(datasets);
                                                                                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                            fail("Failed to set up mock for private method");
                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        when(plot.getRendererForDataset(mockDataset)).thenReturn(mockRenderer);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        Range expectedRange = new Range(1.0, 10.0);
                                                                                                                                                                                                                                                                                                                        when(mockRenderer.findRangeBounds(mockDataset)).thenReturn(expectedRange);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Execute test
                                                                                                                                                                                                                                                                                                                        Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                                                                                                                        assertEquals("Should return correct domain range from renderer", expectedRange, result);
                                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                                    public void testGetDataRange_RangeAxisWithDatasetNoRenderer() {
                                                                                                                                                                                                                                                                                                                        // Create mock objects
                                                                                                                                                                                                                                                                                                                        XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                                                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                                                                        XYDataset mockDataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Set up the plot configuration
                                                                                                                                                                                                                                                                                                                        plot.setRangeAxis(0, mockAxis);
                                                                                                                                                                                                                                                                                                                        plot.setDataset(0, mockDataset);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Use reflection to map dataset to range axis since the method is private
                                                                                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                                                                                            Method mapDatasetToRangeAxis = XYPlot.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                "mapDatasetToRangeAxis", int.class, int.class);
                                                                                                                                                                                                                                                                                                                            mapDatasetToRangeAxis.setAccessible(true);
                                                                                                                                                                                                                                                                                                                            mapDatasetToRangeAxis.invoke(plot, 0, 0);
                                                                                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                            fail("Failed to map dataset to range axis via reflection");
                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Set up mock behavior
                                                                                                                                                                                                                                                                                                                        when(plot.getDomainAxisIndex(mockAxis)).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                        when(plot.getRangeAxisIndex(mockAxis)).thenReturn(0);
                                                                                                                                                                                                                                                                                                                        when(plot.getRendererForDataset(mockDataset)).thenReturn(null);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        Range expectedRange = new Range(5.0, 15.0);
                                                                                                                                                                                                                                                                                                                        when(DatasetUtilities.findRangeBounds(mockDataset)).thenReturn(expectedRange);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                                                                        assertEquals("Should return correct range from DatasetUtilities", expectedRange, result);
                                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                                    public void testGetDataRange_CombinedRangesFromMultipleDatasets() {
                                                                                                                                                                                                                                                                                                                        // Create mock objects
                                                                                                                                                                                                                                                                                                                        XYPlot plot = mock(XYPlot.class);
                                                                                                                                                                                                                                                                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Set up mock behavior
                                                                                                                                                                                                                                                                                                                        when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                                                                                                                                                                                                                                                                                        when(plot.getRangeAxisIndex(mockAxis)).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        XYDataset dataset1 = mock(XYDataset.class);
                                                                                                                                                                                                                                                                                                                        XYDataset dataset2 = mock(XYDataset.class);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Instead of mocking private method, set up the plot's internal state
                                                                                                                                                                                                                                                                                                                        // to return the datasets when getDataset() is called
                                                                                                                                                                                                                                                                                                                        when(plot.getDataset(0)).thenReturn(dataset1);
                                                                                                                                                                                                                                                                                                                        when(plot.getDataset(1)).thenReturn(dataset2);
                                                                                                                                                                                                                                                                                                                        when(plot.getDatasetCount()).thenReturn(2);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        // Mock that both datasets are mapped to domain axis 0
                                                                                                                                                                                                                                                                                                                        when(plot.getDomainAxisForDataset(0)).thenReturn(mockAxis);
                                                                                                                                                                                                                                                                                                                        when(plot.getDomainAxisForDataset(1)).thenReturn(mockAxis);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        XYItemRenderer renderer1 = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                                                                                                        XYItemRenderer renderer2 = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                                                                                                        when(plot.getRendererForDataset(dataset1)).thenReturn(renderer1);
                                                                                                                                                                                                                                                                                                                        when(plot.getRendererForDataset(dataset2)).thenReturn(renderer2);
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        when(renderer1.findDomainBounds(dataset1)).thenReturn(new Range(1.0, 5.0));
                                                                                                                                                                                                                                                                                                                        when(renderer2.findDomainBounds(dataset2)).thenReturn(new Range(3.0, 8.0));
                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                        Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                                                                        assertEquals("Should return combined range from multiple datasets", new Range(1.0, 8.0), result);
                                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                                public void testGetDataRange_AnnotationNotIncludedInBounds() {
                                                                                                                                                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                                                                                                                                                    XYPlot plot = mock(XYPlot.class);
                                                                                                                                                                                                                                                                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                                                                    XYAnnotation mockAnnotation = mock(XYAnnotation.class);
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    // Set up stubs
                                                                                                                                                                                                                                                                                                                    when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                                                                                                                                                                                                                                                                                    when(plot.getRangeAxisIndex(mockAxis)).thenReturn(-1);
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    // Set up empty dataset list without mocking private method
                                                                                                                                                                                                                                                                                                                    when(plot.getDatasetCount()).thenReturn(0);
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    // Add annotation to plot but mark it as not included in bounds
                                                                                                                                                                                                                                                                                                                    // We'll use reflection to test the behavior since we can't directly mock these methods
                                                                                                                                                                                                                                                                                                                    plot.addAnnotation(mockAnnotation);
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                                                                    assertNull("Range should be null when no datasets and annotation not included", result);
                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                        public void testGetDataRange_CombinedRangesFromDatasetAndAnnotation() {
                                                                                                                                                                                                                                                                                            // Create mock objects
                                                                                                                                                                                                                                                                                            XYPlot plot = mock(XYPlot.class);
                                                                                                                                                                                                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                                            XYDataset mockDataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                                                            XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                                                                            XYAnnotation mockAnnotation = mock(XYAnnotation.class);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Set up mock behavior
                                                                                                                                                                                                                                                                                            when(plot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                                                                                                                                                                                                                                                            when(plot.getRangeAxisIndex(mockAxis)).thenReturn(-1);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Use reflection to access private method
                                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                                Method method = XYPlot.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                    "getDatasetsMappedToDomainAxis", Integer.TYPE);
                                                                                                                                                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                                                                                                                                                List<XYDataset> datasetList = new ArrayList<XYDataset>();
                                                                                                                                                                                                                                                                                                datasetList.add(mockDataset);
                                                                                                                                                                                                                                                                                                when((List<XYDataset>) method.invoke(plot, 0)).thenReturn(datasetList);
                                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                                fail("Failed to set up private method access");
                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            when(plot.getRendererForDataset(mockDataset)).thenReturn(mockRenderer);
                                                                                                                                                                                                                                                                                            when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(2.0, 6.0));
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Add annotation to plot
                                                                                                                                                                                                                                                                                            List<XYAnnotation> annotationList = new ArrayList<XYAnnotation>();
                                                                                                                                                                                                                                                                                            annotationList.add(mockAnnotation);
                                                                                                                                                                                                                                                                                            when(plot.getAnnotations()).thenReturn(annotationList);
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            // Mock annotation bounds behavior using proper XYAnnotation method
                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                            Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                                            assertEquals("Should return combined range from dataset and annotation", 
                                                                                                                                                                                                                                                                                                new Range(1.0, 7.0), result);
                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                        public void testGetDataRange_DomainAxisWithAnnotations() {
                                                                                                                                                                                                                                                                            // Create mock objects with proper types
                                                                                                                                                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                                            ValueAxis domainAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                            ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                            XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Create plot with required parameters
                                                                                                                                                                                                                                                                            XYPlot plot = new XYPlot(dataset, domainAxis, rangeAxis, renderer);
                                                                                                                                                                                                                                                                            XYPlot spyPlot = spy(plot);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Create range and mock axis
                                                                                                                                                                                                                                                                            Range range = new Range(2.0, 8.0);
                                                                                                                                                                                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Create mock annotation
                                                                                                                                                                                                                                                                            XYAnnotation mockAnnotation = mock(XYAnnotation.class);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Setup plot
                                                                                                                                                                                                                                                                            spyPlot.setDataset(0, dataset);
                                                                                                                                                                                                                                                                            spyPlot.mapDatasetToDomainAxis(0, 0);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Mock annotation behavior
                                                                                                                                                                                                                                                                            spyPlot.addAnnotation(mockAnnotation);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Mock axis behavior
                                                                                                                                                                                                                                                                            when(mockAxis.getRange()).thenReturn(range);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Test and verify
                                                                                                                                                                                                                                                                            Range result = spyPlot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                            assertEquals("Should return range from annotation", range, result);
                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                        public void testGetDataRange_RangeAxisWithAnnotations() {
                                                                                                                                                                                                                                                                            // Create mock objects
                                                                                                                                                                                                                                                                            org.jfree.data.Range mockRange = new org.jfree.data.Range(4.9, 5.1);
                                                                                                                                                                                                                                                                            org.jfree.chart.axis.ValueAxis mockAxis = mock(org.jfree.chart.axis.ValueAxis.class);
                                                                                                                                                                                                                                                                            org.jfree.chart.annotations.XYAnnotation mockAnnotation = mock(org.jfree.chart.annotations.XYAnnotation.class);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Create plot with empty dataset
                                                                                                                                                                                                                                                                            org.jfree.chart.plot.XYPlot plot = new org.jfree.chart.plot.XYPlot();
                                                                                                                                                                                                                                                                            when(plot.getDomainAxisIndex(mockAxis)).thenReturn(-1);
                                                                                                                                                                                                                                                                            when(plot.getRangeAxisIndex(mockAxis)).thenReturn(0);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Set up dataset mapping
                                                                                                                                                                                                                                                                            plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Configure mock annotation to affect range
                                                                                                                                                                                                                                                                            // XYAnnotation doesn't have getRange() or getRangeAxis() methods,
                                                                                                                                                                                                                                                                            // so we'll just add the annotation and verify it affects the range
                                                                                                                                                                                                                                                                            plot.addAnnotation(mockAnnotation);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // The actual implementation of getDataRange() should consider annotations
                                                                                                                                                                                                                                                                            org.jfree.data.Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Since we have an empty plot with just an annotation, the range might be null
                                                                                                                                                                                                                                                                            // or some default. We'll just verify the method executes without error.
                                                                                                                                                                                                                                                                            assertNotNull("Should return a range (might be null for empty plot)", result);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Verify mock interactions
                                                                                                                                                                                                                                                                            verify(plot).getRangeAxisIndex(mockAxis);
                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                           public void testGetDataRange_IncludesRendererAnnotations() throws Exception {
                                                                                                                                                                                                                                                               // Setup test data
                                                                                                                                                                                                                                                               ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                               XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                               XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                                               Object annotation = mock(Object.class); // Using Object as generic mock
                                                                                                                                                                                                                                                               Range annotationRange = new Range(1.0, 2.0);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Create plot first
                                                                                                                                                                                                                                                               XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                                               plot.setDataset(0, dataset);
                                                                                                                                                                                                                                                               plot.setRenderer(0, renderer);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Setup renderer to return annotation with bounds
                                                                                                                                                                                                                                                               Collection<Object> rendererAnnotations = new ArrayList<>();
                                                                                                                                                                                                                                                               rendererAnnotations.add(annotation);
                                                                                                                                                                                                                                                               when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                                                                                                                                                                                                                                                               when(annotation.toString()).thenReturn("XYAnnotationBoundsInfo"); // Mock toString for debugging
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Mock annotation methods using reflection
                                                                                                                                                                                                                                                               Method getIncludeInDataBounds = mock(Method.class);
                                                                                                                                                                                                                                                               Method getYRange = mock(Method.class);
                                                                                                                                                                                                                                                               when(annotation.getClass().getMethod("getIncludeInDataBounds")).thenReturn(getIncludeInDataBounds);
                                                                                                                                                                                                                                                               when(annotation.getClass().getMethod("getYRange")).thenReturn(getYRange);
                                                                                                                                                                                                                                                               when(getIncludeInDataBounds.invoke(annotation)).thenReturn(true);
                                                                                                                                                                                                                                                               when(getYRange.invoke(annotation)).thenReturn(annotationRange);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Setup dataset to return some base range
                                                                                                                                                                                                                                                               Range datasetRange = new Range(0.5, 1.5);
                                                                                                                                                                                                                                                               when(renderer.findRangeBounds(dataset)).thenReturn(datasetRange);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Mock axis index lookup
                                                                                                                                                                                                                                                               when(axis.getPlot()).thenReturn(plot);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Expected range is combination of dataset range and annotation range
                                                                                                                                                                                                                                                               Range expected = new Range(0.5, 2.0);
                                                                                                                                                                                                                                                               Range actual = plot.getDataRange(axis);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               assertEquals("Range should include renderer annotation bounds", 
                                                                                                                                                                                                                                                                           expected, actual);
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                  public void testGetDataRange_IncludesRendererAnnotations1() {
                                                                                                                                                                                                                                                      // Setup test objects
                                                                                                                                                                                                                                                      ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                      XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Create a mock dataset and renderer
                                                                                                                                                                                                                                                      XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                      XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Create annotation that affects bounds
                                                                                                                                                                                                                                                      XYAnnotation annotation = mock(XYAnnotation.class, withSettings().extraInterfaces(XYAnnotationBoundsInfo.class));
                                                                                                                                                                                                                                                      when(((XYAnnotationBoundsInfo)annotation).getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                                                                                                      when(((XYAnnotationBoundsInfo)annotation).getYRange()).thenReturn(new Range(5, 10));
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Configure renderer to return the annotation
                                                                                                                                                                                                                                                      Collection<XYAnnotation> rendererAnnotations = new ArrayList<>();
                                                                                                                                                                                                                                                      rendererAnnotations.add(annotation);
                                                                                                                                                                                                                                                      when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Configure plot to use our test objects
                                                                                                                                                                                                                                                      plot.setDataset(0, dataset);
                                                                                                                                                                                                                                                      plot.setRenderer(0, renderer);
                                                                                                                                                                                                                                                      plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                                                                                                      plot.setRangeAxis(0, axis);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Configure axis index lookup
                                                                                                                                                                                                                                                      when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Execute and verify
                                                                                                                                                                                                                                                      Range result = plot.getDataRange(axis);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // The annotation's range (5,10) should be included in the result
                                                                                                                                                                                                                                                      assertNotNull("Result should not be null", result);
                                                                                                                                                                                                                                                      assertEquals("Lower bound should include annotation", 5.0, result.getLowerBound(), 0.0001);
                                                                                                                                                                                                                                                      assertEquals("Upper bound should include annotation", 10.0, result.getUpperBound(), 0.0001);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                         public void testGetDataRange_IncludesRendererAnnotations2() {
                                                                                                                                                                                                                                             // Setup test data
                                                                                                                                                                                                                                             ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                                             XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create a dataset and add it to plot
                                                                                                                                                                                                                                             XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                                                             plot.setDataset(0, dataset);
                                                                                                                                                                                                                                             plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create a renderer with annotations
                                                                                                                                                                                                                                             XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                             plot.setRenderer(0, renderer);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create mock annotation that affects bounds
                                                                                                                                                                                                                                             XYAnnotation annotation = mock(XYAnnotation.class, withSettings().extraInterfaces(XYAnnotationBoundsInfo.class));
                                                                                                                                                                                                                                             XYAnnotationBoundsInfo boundsInfo = (XYAnnotationBoundsInfo) annotation;
                                                                                                                                                                                                                                             Range annotationRange = new Range(5, 10);
                                                                                                                                                                                                                                             when(boundsInfo.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                                                                                             when(boundsInfo.getYRange()).thenReturn(annotationRange);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Set renderer to return our annotation
                                                                                                                                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                             Collection<XYAnnotation> annotations = Collections.<XYAnnotation>singleton(annotation);
                                                                                                                                                                                                                                             when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Mock dataset range
                                                                                                                                                                                                                                             Range datasetRange = new Range(1, 5);
                                                                                                                                                                                                                                             when(renderer.findRangeBounds(dataset)).thenReturn(datasetRange);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Mock axis mapping
                                                                                                                                                                                                                                             when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Execute
                                                                                                                                                                                                                                             Range result = plot.getDataRange(axis);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Verify - combined range should include both dataset and annotation ranges
                                                                                                                                                                                                                                             assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                                                                                                                             assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Additional verification that annotation was processed
                                                                                                                                                                                                                                             verify(boundsInfo, atLeastOnce()).getIncludeInDataBounds();
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                public void testGetDataRangeWithNullAnnotation() {
                                                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                                                    ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                                    XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                                                    XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Create a collection with one null annotation
                                                                                                                                                                                                                                    Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                                                                                                    annotations.add(null);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Create XYPlot instance and spy on it
                                                                                                                                                                                                                                    XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                    XYPlot plotSpy = spy(plot);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Mock behavior
                                                                                                                                                                                                                                    when(plotSpy.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                                                                                    when(plotSpy.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                                                                                                                    when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                                                                                    when(renderer.findRangeBounds(dataset)).thenReturn(new Range(0, 10));
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Add the mocked dataset to the plot and map it to range axis 0
                                                                                                                                                                                                                                    plotSpy.setDataset(0, dataset);
                                                                                                                                                                                                                                    plotSpy.setRenderer(0, renderer);
                                                                                                                                                                                                                                    plotSpy.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Track annotation additions
                                                                                                                                                                                                                                    List<XYAnnotation> addedAnnotations = new ArrayList<>();
                                                                                                                                                                                                                                    doAnswer(invocation -> {
                                                                                                                                                                                                                                        XYAnnotation a = invocation.getArgument(0);
                                                                                                                                                                                                                                        addedAnnotations.add(a);
                                                                                                                                                                                                                                        return null;
                                                                                                                                                                                                                                    }).when(plotSpy).addAnnotation(any());
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                    Range result = plotSpy.getDataRange(axis);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert that null annotation was attempted to be processed
                                                                                                                                                                                                                                    assertTrue("Null annotation should be in added annotations", 
                                                                                                                                                                                                                                               addedAnnotations.contains(null));
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                       public void testAnnotationOrderInGetDataRange() {
                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                           XYPlot plot = new XYPlot();
                                                                                                                                                                                                                           ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Create mock renderer with annotations
                                                                                                                                                                                                                           XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                           XYAnnotation annotation1 = mock(XYAnnotation.class);
                                                                                                                                                                                                                           XYAnnotation annotation2 = mock(XYAnnotation.class);
                                                                                                                                                                                                                           Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                                                                                           annotations.add(annotation1);
                                                                                                                                                                                                                           annotations.add(annotation2);
                                                                                                                                                                                                                           when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Create mock dataset
                                                                                                                                                                                                                           XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                                           when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Configure plot to use our dataset and axis
                                                                                                                                                                                                                           plot.setDataset(0, dataset);
                                                                                                                                                                                                                           plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                                                                           plot.setRangeAxis(0, axis);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                           plot.getDataRange(axis);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Get the internal annotations list through reflection
                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                               Field annotationsField = XYPlot.class.getDeclaredField("annotations");
                                                                                                                                                                                                                               annotationsField.setAccessible(true);
                                                                                                                                                                                                                               @SuppressWarnings("unchecked")
                                                                                                                                                                                                                               List<XYAnnotation> plotAnnotations = (List<XYAnnotation>) annotationsField.get(plot);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify annotation order
                                                                                                                                                                                                                               // Original behavior: annotation1 should be first, annotation2 second
                                                                                                                                                                                                                               // Mutant behavior: annotation2 would be first (added at position 0)
                                                                                                                                                                                                                               assertEquals("First annotation should be annotation1", annotation1, plotAnnotations.get(0));
                                                                                                                                                                                                                               assertEquals("Second annotation should be annotation2", annotation2, plotAnnotations.get(1));
                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                               fail("Failed to access annotations field through reflection: " + e.getMessage());
                                                                                                                                                                                                                           }
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                  public void testGetDataRange_DetectsAnnotationAddMutant() {
                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                      XYPlot plot = new XYPlot();
                                                                                                                                                                                                                      ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create a dataset and mock its renderer
                                                                                                                                                                                                                      XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                                      XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Setup plot with dataset and mapping
                                                                                                                                                                                                                      plot.setDataset(0, dataset);
                                                                                                                                                                                                                      plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                                                                      plot.setRenderer(0, renderer);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create test annotation
                                                                                                                                                                                                                      XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                                                                                      when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                                                                      when(annotation.getYRange()).thenReturn(new Range(0, 10));
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Setup renderer to return our annotation
                                                                                                                                                                                                                      Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                                                                                      annotations.add((XYAnnotation)annotation);
                                                                                                                                                                                                                      when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create a spy to monitor the includedAnnotations list
                                                                                                                                                                                                                      XYPlot spyPlot = spy(plot);
                                                                                                                                                                                                                      List<XYAnnotation> includedAnnotations = new ArrayList<>();
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                      spyPlot.getDataRange(axis);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify - the original code would call add() once, mutant calls addAll()
                                                                                                                                                                                                                      // Both result in size 1, but we can verify the exact modification count
                                                                                                                                                                                                                      assertEquals("Should have exactly one annotation", 1, includedAnnotations.size());
                                                                                                                                                                                                                      assertTrue("Annotation should be present", includedAnnotations.contains(annotation));
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Additional verification to catch the mutant
                                                                                                                                                                                                                      // The mutant would use addAll(Collections.singleton()) instead of direct add()
                                                                                                                                                                                                                      // We can verify the final state is exactly as expected
                                                                                                                                                                                                                      assertEquals("First element should be our annotation", annotation, includedAnnotations.get(0));
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                         public void testGetDataRangeWithMoreThan10Annotations() {
                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                             XYPlot plot = new XYPlot();
                                                                                                                                                                                                             ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create a dataset with a renderer that will return annotations
                                                                                                                                                                                                             XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                             XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create more than 10 annotations (11 in this case)
                                                                                                                                                                                                             Collection<XYAnnotationBoundsInfo> annotations = new ArrayList<>();
                                                                                                                                                                                                             for (int i = 0; i < 11; i++) {
                                                                                                                                                                                                                 XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                                                                                 when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                                                                 when(annotation.getXRange()).thenReturn(new Range(i, i+1));
                                                                                                                                                                                                                 annotations.add(annotation);
                                                                                                                                                                                                             }
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Mock behavior
                                                                                                                                                                                                             when(plot.getDomainAxisIndex(axis)).thenReturn(0); // Make it a domain axis
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Set up the plot's internal state to return our dataset for axis 0
                                                                                                                                                                                                             try {
                                                                                                                                                                                                                 Method mapMethod = XYPlot.class.getDeclaredMethod("mapDatasetToDomainAxis", Integer.TYPE, Integer.TYPE);
                                                                                                                                                                                                                 mapMethod.setAccessible(true);
                                                                                                                                                                                                                 mapMethod.invoke(plot, 0, 0);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 Field datasetsField = XYPlot.class.getDeclaredField("datasets");
                                                                                                                                                                                                                 datasetsField.setAccessible(true);
                                                                                                                                                                                                                 ObjectList datasets = (ObjectList) datasetsField.get(plot);
                                                                                                                                                                                                                 datasets.set(0, dataset);
                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                 fail("Failed to set up plot's internal state via reflection");
                                                                                                                                                                                                             }
                                                                                                                                                                                                             
                                                                                                                                                                                                             when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                                                                                             when(renderer.getAnnotations()).thenReturn((Collection)annotations);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Expected range should combine all 11 annotations (0-1, 1-2, ..., 10-11)
                                                                                                                                                                                                             Range expectedRange = new Range(0, 11);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Execute
                                                                                                                                                                                                             Range result = plot.getDataRange(axis);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                             assertEquals("Range should include all annotations", expectedRange, result);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Additional verification that all annotations were processed
                                                                                                                                                                                                             for (XYAnnotationBoundsInfo annotation : annotations) {
                                                                                                                                                                                                                 Range annotationRange = annotation.getXRange();
                                                                                                                                                                                                                 assertTrue("Result range should contain all annotation ranges", 
                                                                                                                                                                                                                          result.contains(annotationRange.getLowerBound()) &&
                                                                                                                                                                                                                          result.contains(annotationRange.getUpperBound()));
                                                                                                                                                                                                             }
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                public void testGetDataRange_IncludesRendererAnnotations3() {
                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                    ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                    XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                    XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                    XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                                                                    Range annotationRange = new Range(5, 10);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create plot with axis
                                                                                                                                                                                                    XYPlot plot = new XYPlot();
                                                                                                                                                                                                    plot.setDataset(0, dataset);
                                                                                                                                                                                                    plot.setRenderer(0, renderer);
                                                                                                                                                                                                    plot.setRangeAxis(0, axis);
                                                                                                                                                                                                    plot.mapDatasetToRangeAxis(0, 0);  // Map dataset to range axis
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Configure mocks
                                                                                                                                                                                                    when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                                                    when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Setup renderer to return annotation
                                                                                                                                                                                                    Collection<XYAnnotation> rendererAnnotations = new ArrayList<>();
                                                                                                                                                                                                    rendererAnnotations.add((XYAnnotation)annotation);
                                                                                                                                                                                                    when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                                                                                                                                                                                                    when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                                                    when(annotation.getYRange()).thenReturn(annotationRange);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Setup dataset range
                                                                                                                                                                                                    Range datasetRange = new Range(1, 2);
                                                                                                                                                                                                    when(renderer.findRangeBounds(dataset)).thenReturn(datasetRange);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify the combined range includes both dataset and annotation ranges
                                                                                                                                                                                                    Range result = plot.getDataRange(axis);
                                                                                                                                                                                                    assertNotNull("Result should not be null", result);
                                                                                                                                                                                                    assertEquals("Range should start at minimum of both ranges", 
                                                                                                                                                                                                        1.0, result.getLowerBound(), 0.0001);
                                                                                                                                                                                                    assertEquals("Range should end at maximum of both ranges", 
                                                                                                                                                                                                        10.0, result.getUpperBound(), 0.0001);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Additional verification that annotation was actually included
                                                                                                                                                                                                    verify(annotation, atLeastOnce()).getIncludeInDataBounds();
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                           public void testGetDataRange_ShouldNotDuplicateRendererAnnotations() {
                                                                                                                                                                                               // Setup test data
                                                                                                                                                                                               ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                               XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                               XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                               
                                                                                                                                                                                               // Create test annotation that implements both interfaces
                                                                                                                                                                                               XYAnnotation testAnnotation = new XYAnnotation() {
                                                                                                                                                                                                   @Override
                                                                                                                                                                                                   public void draw(Graphics2D g2, XYPlot plot, Rectangle2D dataArea,
                                                                                                                                                                                                           ValueAxis domainAxis, ValueAxis rangeAxis, 
                                                                                                                                                                                                           int rendererIndex, PlotRenderingInfo info) {
                                                                                                                                                                                                       // empty implementation for test
                                                                                                                                                                                                   }
                                                                                                                                                                                               };
                                                                                                                                                                                               XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                                                               when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                                               
                                                                                                                                                                                               // Configure renderer to return our test annotation
                                                                                                                                                                                               Collection<XYAnnotation> rendererAnnotations = new ArrayList<>();
                                                                                                                                                                                               rendererAnnotations.add(testAnnotation);
                                                                                                                                                                                               when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                                                                                                                                                                                               
                                                                                                                                                                                               // Configure plot to use our test components
                                                                                                                                                                                               XYPlot plot = new XYPlot();
                                                                                                                                                                                               plot.setDataset(0, dataset);
                                                                                                                                                                                               plot.setRenderer(0, renderer);
                                                                                                                                                                                               when(plot.getDomainAxisIndex(axis)).thenReturn(0); // Make it a domain axis
                                                                                                                                                                                               when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                                                                               
                                                                                                                                                                                               // Execute the method
                                                                                                                                                                                               Range result = plot.getDataRange(axis);
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify annotations were processed correctly
                                                                                                                                                                                               // Get the private annotations field through reflection for verification
                                                                                                                                                                                               try {
                                                                                                                                                                                                   Field annotationsField = XYPlot.class.getDeclaredField("annotations");
                                                                                                                                                                                                   annotationsField.setAccessible(true);
                                                                                                                                                                                                   List<?> annotations = (List<?>) annotationsField.get(plot);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Should only contain one instance of our test annotation
                                                                                                                                                                                                   long annotationCount = annotations.stream()
                                                                                                                                                                                                       .filter(a -> a == testAnnotation)
                                                                                                                                                                                                       .count();
                                                                                                                                                                                                   assertEquals("Annotation should only appear once in the list", 
                                                                                                                                                                                                               1, annotationCount);
                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                   fail("Failed to verify annotations through reflection: " + e.getMessage());
                                                                                                                                                                                               }
                                                                                                                                                                                               
                                                                                                                                                                                               // Additional verification that the range calculation wasn't affected
                                                                                                                                                                                               assertNotNull("Resulting range should not be null", result);
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                  public void testGetDataRange_DetectsAnnotationBoundsInfoNotXYAnnotation() {
                                                                                                                                                                                      // Setup test data
                                                                                                                                                                                      XYPlot plot = new XYPlot();
                                                                                                                                                                                      ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                      XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                      XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                      
                                                                                                                                                                                      // Create a special annotation that implements both interfaces
                                                                                                                                                                                      XYAnnotationBoundsInfo boundsAnnotation = new XYAnnotationBoundsInfo() {
                                                                                                                                                                                          @Override
                                                                                                                                                                                          public Range getXRange() { return new Range(1, 2); }
                                                                                                                                                                                          @Override
                                                                                                                                                                                          public Range getYRange() { return new Range(3, 4); }
                                                                                                                                                                                          @Override
                                                                                                                                                                                          public boolean getIncludeInDataBounds() { return true; }
                                                                                                                                                                                      };
                                                                                                                                                                                      
                                                                                                                                                                                      // Setup plot with dataset and renderer
                                                                                                                                                                                      plot.setDataset(0, dataset);
                                                                                                                                                                                      plot.setRenderer(0, renderer);
                                                                                                                                                                                      plot.setDomainAxis(0, axis);
                                                                                                                                                                                      
                                                                                                                                                                                      // Mock behavior
                                                                                                                                                                                      when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                                      when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                                                                      when(renderer.findDomainBounds(dataset)).thenReturn(new Range(0, 1));
                                                                                                                                                                                      
                                                                                                                                                                                      // Setup renderer annotations
                                                                                                                                                                                      Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                                                      annotations.add((XYAnnotation)boundsAnnotation);
                                                                                                                                                                                      when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                                      
                                                                                                                                                                                      // Execute
                                                                                                                                                                                      Range result = plot.getDataRange(axis);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify - the annotation's range should be included
                                                                                                                                                                                      assertEquals(0.0, result.getLowerBound(), 0.0001);
                                                                                                                                                                                      assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                                                                                                                                      
                                                                                                                                                                                      // Additional verification that annotation was processed
                                                                                                                                                                                      verify(renderer, times(1)).getAnnotations();
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                             public void testGetDataRangeWithNonBoundsInfoAnnotations() {
                                                                                                                                                                                 // Setup test data
                                                                                                                                                                                 ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                 XYPlot plot = new XYPlot();
                                                                                                                                                                                 
                                                                                                                                                                                 // Mock dataset and renderer
                                                                                                                                                                                 XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                 XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                 
                                                                                                                                                                                 // Setup mock behavior
                                                                                                                                                                                 when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                                 
                                                                                                                                                                                 // Instead of mocking private method, we'll set up the plot's internal state
                                                                                                                                                                                 plot.setDataset(0, dataset);
                                                                                                                                                                                 plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                                 plot.setRenderer(0, renderer);
                                                                                                                                                                                 
                                                                                                                                                                                 // Create a regular XYAnnotation (not XYAnnotationBoundsInfo)
                                                                                                                                                                                 XYAnnotation regularAnnotation = mock(XYAnnotation.class);
                                                                                                                                                                                 Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                                                 annotations.add(regularAnnotation);
                                                                                                                                                                                 when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                                 
                                                                                                                                                                                 // Test - should not throw exception with original code
                                                                                                                                                                                 // Mutated version would throw ClassCastException here
                                                                                                                                                                                 Range result = plot.getDataRange(axis);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify the annotation was processed (though it shouldn't affect the range)
                                                                                                                                                                                 // The main assertion is that no exception was thrown
                                                                                                                                                                                 assertNotNull(result);
                                                                                                                                                                                 
                                                                                                                                                                                 // Additional verification that the annotation was considered
                                                                                                                                                                                 // (though not added to includedAnnotations in mutated version)
                                                                                                                                                                                 verify(renderer).getAnnotations();
                                                                                                                                                                             }

    @Test
                                                                                                                                                                        public void testGetDataRange_IncludesAllRendererAnnotations() {
                                                                                                                                                                            // Setup test data
                                                                                                                                                                            ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                            XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                            XYAnnotationBoundsInfo annotation1 = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                                            XYAnnotationBoundsInfo annotation2 = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                                            
                                                                                                                                                                            // Configure mocks
                                                                                                                                                                            when(annotation1.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                            when(annotation2.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                            Range annotationRange1 = new Range(1.0, 2.0);
                                                                                                                                                                            Range annotationRange2 = new Range(3.0, 4.0);
                                                                                                                                                                            when(annotation1.getYRange()).thenReturn(annotationRange1);
                                                                                                                                                                            when(annotation2.getYRange()).thenReturn(annotationRange2);
                                                                                                                                                                            
                                                                                                                                                                            Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                                            annotations.add((XYAnnotation) annotation1);
                                                                                                                                                                            annotations.add((XYAnnotation) annotation2);
                                                                                                                                                                            when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                            
                                                                                                                                                                            Range datasetRange = new Range(0.0, 5.0);
                                                                                                                                                                            when(renderer.findRangeBounds(dataset)).thenReturn(datasetRange);
                                                                                                                                                                            
                                                                                                                                                                            // Setup XYPlot
                                                                                                                                                                            XYPlot plot = new XYPlot();
                                                                                                                                                                            plot.setDataset(0, dataset);
                                                                                                                                                                            plot.setRenderer(0, renderer);
                                                                                                                                                                            plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Expected range is combination of dataset range and all annotation ranges
                                                                                                                                                                            Range expectedRange = new Range(0.0, 5.0);
                                                                                                                                                                            expectedRange = Range.combine(expectedRange, annotationRange1);
                                                                                                                                                                            expectedRange = Range.combine(expectedRange, annotationRange2);
                                                                                                                                                                            
                                                                                                                                                                            // Execute and verify
                                                                                                                                                                            Range actualRange = plot.getDataRange(axis);
                                                                                                                                                                            assertEquals("Range should include all annotation bounds", 
                                                                                                                                                                                         expectedRange, actualRange);
                                                                                                                                                                            
                                                                                                                                                                            // Verify annotations were processed by checking the combined range
                                                                                                                                                                            assertTrue("Range should include first annotation's bounds",
                                                                                                                                                                                       actualRange.contains(annotationRange1.getLowerBound()));
                                                                                                                                                                            assertTrue("Range should include second annotation's bounds",
                                                                                                                                                                                       actualRange.contains(annotationRange2.getLowerBound()));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                    public void testGetDataRange_IncludesRendererAnnotations4() {
                                                                                                                                                                        // Setup test data
                                                                                                                                                                        ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                        XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                        XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                                        Range annotationRange = new Range(1.0, 2.0);
                                                                                                                                                                        
                                                                                                                                                                        // Configure mocks
                                                                                                                                                                        when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                        when(annotation.getYRange()).thenReturn(annotationRange);
                                                                                                                                                                        when(renderer.getAnnotations()).thenReturn(Collections.singletonList(annotation));
                                                                                                                                                                        when(renderer.findRangeBounds(dataset)).thenReturn(new Range(0.5, 1.5));
                                                                                                                                                                        
                                                                                                                                                                        // Create plot and configure it
                                                                                                                                                                        XYPlot plot = new XYPlot();
                                                                                                                                                                        plot.setDataset(0, dataset);
                                                                                                                                                                        plot.setRenderer(0, renderer);
                                                                                                                                                                        plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                                                        plot.setRangeAxis(0, axis);
                                                                                                                                                                        
                                                                                                                                                                        // Add some plot annotations that shouldn't affect this test
                                                                                                                                                                        XYAnnotation plotAnnotation = mock(XYAnnotation.class);
                                                                                                                                                                        plot.addAnnotation(plotAnnotation);
                                                                                                                                                                        
                                                                                                                                                                        // Execute and verify
                                                                                                                                                                        Range result = plot.getDataRange(axis);
                                                                                                                                                                        
                                                                                                                                                                        // The expected range should combine the dataset range (0.5-1.5) and annotation range (1.0-2.0)
                                                                                                                                                                        assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                                                                                                                        assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                                                                                                                        
                                                                                                                                                                        // Verify interactions
                                                                                                                                                                        verify(renderer).getAnnotations();
                                                                                                                                                                        verify(annotation).getIncludeInDataBounds();
                                                                                                                                                                        verify(annotation).getYRange();
                                                                                                                                                                    }

    @Test
                                                                                                                                                      public void testGetDataRange_IncludesRendererAnnotations5() {
                                                                                                                                                          // Setup test data
                                                                                                                                                          XYPlot plot = new XYPlot();
                                                                                                                                                          ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                          XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                          XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                          XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                          
                                                                                                                                                          // Configure mocks
                                                                                                                                                          when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                                          
                                                                                                                                                          // Setup datasets mapping using reflection
                                                                                                                                                          try {
                                                                                                                                                              // Get the private datasetToRangeAxesMap field
                                                                                                                                                              Field mapField = XYPlot.class.getDeclaredField("datasetToRangeAxesMap");
                                                                                                                                                              mapField.setAccessible(true);
                                                                                                                                                              
                                                                                                                                                              // Create and populate the map
                                                                                                                                                              Map<Integer, Integer> mapping = new HashMap<>();
                                                                                                                                                              mapping.put(0, 0);  // Map dataset 0 to axis 0
                                                                                                                                                              mapField.set(plot, mapping);
                                                                                                                                                              
                                                                                                                                                              // Add the dataset to the plot's datasets list
                                                                                                                                                              Field datasetsField = XYPlot.class.getDeclaredField("datasets");
                                                                                                                                                              datasetsField.setAccessible(true);
                                                                                                                                                              ObjectList datasets = (ObjectList) datasetsField.get(plot);
                                                                                                                                                              datasets.set(0, dataset);
                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                              fail("Failed to setup test data via reflection: " + e.getMessage());
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                                          
                                                                                                                                                          // Setup renderer annotations
                                                                                                                                                          Collection<XYAnnotation> rendererAnnotations = new ArrayList<>();
                                                                                                                                                          rendererAnnotations.add((XYAnnotation)annotation);
                                                                                                                                                          when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                                                                                                                                                          when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                          when(annotation.getYRange()).thenReturn(new Range(5.0, 10.0));
                                                                                                                                                          
                                                                                                                                                          // Setup dataset range
                                                                                                                                                          when(renderer.findRangeBounds(dataset)).thenReturn(new Range(1.0, 2.0));
                                                                                                                                                          
                                                                                                                                                          // Execute test
                                                                                                                                                          Range result = plot.getDataRange(axis);
                                                                                                                                                          
                                                                                                                                                          // Verify annotations were processed
                                                                                                                                                          assertEquals("Result should combine dataset range and annotation range", 
                                                                                                                                                              new Range(1.0, 10.0), result);
                                                                                                                                                          
                                                                                                                                                          // Additional verification that annotation was actually added
                                                                                                                                                          verify(renderer, times(1)).getAnnotations();
                                                                                                                                                          verify(annotation, atLeastOnce()).getIncludeInDataBounds();
                                                                                                                                                          verify(annotation, atLeastOnce()).getYRange();
                                                                                                                                                      }

    @Test
                                                                                                                                                 public void testGetDataRange_DetectsAnnotationMutation() {
                                                                                                                                                     // Setup test data
                                                                                                                                                     ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                     XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                     XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                     XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                     
                                                                                                                                                     // Configure mocks
                                                                                                                                                     when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                     when(annotation.getXRange()).thenReturn(new Range(1, 10));
                                                                                                                                                     when(annotation.getYRange()).thenReturn(new Range(2, 20));
                                                                                                                                                     
                                                                                                                                                     Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                     annotations.add((XYAnnotation) annotation);
                                                                                                                                                     when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                     when(renderer.findDomainBounds(dataset)).thenReturn(new Range(5, 15));
                                                                                                                                                     when(renderer.findRangeBounds(dataset)).thenReturn(new Range(7, 17));
                                                                                                                                                     
                                                                                                                                                     // Setup plot
                                                                                                                                                     XYPlot plot = new XYPlot();
                                                                                                                                                     plot.setDataset(0, dataset);
                                                                                                                                                     plot.setRenderer(0, renderer);
                                                                                                                                                     
                                                                                                                                                     // Test domain axis case
                                                                                                                                                     when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                                                                                                                                                     when(plot.getRangeAxisIndex(axis)).thenReturn(-1);
                                                                                                                                                     
                                                                                                                                                     Range domainRange = plot.getDataRange(axis);
                                                                                                                                                     assertNotNull(domainRange);
                                                                                                                                                     assertEquals(1.0, domainRange.getLowerBound(), 0.001); // Should include annotation bounds (1-15)
                                                                                                                                                     assertEquals(15.0, domainRange.getUpperBound(), 0.001);
                                                                                                                                                     
                                                                                                                                                     // Test range axis case
                                                                                                                                                     when(plot.getDomainAxisIndex(axis)).thenReturn(-1);
                                                                                                                                                     when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                                     
                                                                                                                                                     Range rangeRange = plot.getDataRange(axis);
                                                                                                                                                     assertNotNull(rangeRange);
                                                                                                                                                     assertEquals(2.0, rangeRange.getLowerBound(), 0.001); // Should include annotation bounds (2-20)
                                                                                                                                                     assertEquals(20.0, rangeRange.getUpperBound(), 0.001);
                                                                                                                                                     
                                                                                                                                                     // Verify annotations were properly processed
                                                                                                                                                     // This would fail if mutation was present (null would be added instead)
                                                                                                                                                     verify(renderer, times(2)).getAnnotations();
                                                                                                                                                 }

    @Test
                                                                                                                                        public void testGetDataRangeWithNullAnnotations() {
                                                                                                                                            // Setup test data
                                                                                                                                            XYPlot plot = new XYPlot();
                                                                                                                                            ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                            XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                            
                                                                                                                                            // Create annotations list with both null and non-null annotations
                                                                                                                                            XYAnnotationBoundsInfo validAnnotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                            Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                            annotations.add(null); // null annotation
                                                                                                                                            annotations.add((XYAnnotation)validAnnotation); // valid annotation
                                                                                                                                            
                                                                                                                                            // Set up plot with dataset and axis mapping
                                                                                                                                            plot.setDataset(0, dataset);
                                                                                                                                            plot.setRangeAxis(0, axis);
                                                                                                                                            plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                                            plot.setRenderer(0, renderer);
                                                                                                                                            
                                                                                                                                            // Mock behavior
                                                                                                                                            when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                            when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                            when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                            when(renderer.findRangeBounds(dataset)).thenReturn(new Range(0, 10));
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            Range result = plot.getDataRange(axis);
                                                                                                                                            
                                                                                                                                            // Verify - should include both null and non-null annotations in original code
                                                                                                                                            // The mutant would only include the non-null annotation
                                                                                                                                            // Check if the valid annotation was processed by verifying the range
                                                                                                                                            assertNotNull(result);
                                                                                                                                            assertEquals(0.0, result.getLowerBound(), 0.0001);
                                                                                                                                            assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                                                                            
                                                                                                                                            // Additional verification - the test would fail for the mutant
                                                                                                                                            // because the null annotation wouldn't be added to includedAnnotations
                                                                                                                                            // and thus wouldn't affect the range calculation
                                                                                                                                        }

    @Test
                                                                                                                               public void testGetDataRange_AnnotationOrderAffectsRangeCombination() {
                                                                                                                                   // Setup
                                                                                                                                   XYPlot plot = new XYPlot();
                                                                                                                                   ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                   
                                                                                                                                   // Create a renderer with annotations
                                                                                                                                   XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                   XYDataset dataset = mock(XYDataset.class);
                                                                                                                                   
                                                                                                                                   // Create two annotations with different ranges
                                                                                                                                   XYAnnotationBoundsInfo annotation1 = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                   Range range1 = new Range(1, 2);
                                                                                                                                   when(annotation1.getYRange()).thenReturn(range1);
                                                                                                                                   when(annotation1.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                   
                                                                                                                                   XYAnnotationBoundsInfo annotation2 = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                   Range range2 = new Range(3, 4);
                                                                                                                                   when(annotation2.getYRange()).thenReturn(range2);
                                                                                                                                   when(annotation2.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                   
                                                                                                                                   // Set up renderer to return these annotations
                                                                                                                                   Collection<XYAnnotationBoundsInfo> annotations = new ArrayList<>();
                                                                                                                                   annotations.add(annotation1);
                                                                                                                                   annotations.add(annotation2);
                                                                                                                                   when(renderer.getAnnotations()).thenReturn((Collection)annotations);
                                                                                                                                   
                                                                                                                                   // Configure plot
                                                                                                                                   plot.setDataset(0, dataset);
                                                                                                                                   plot.setRenderer(0, renderer);
                                                                                                                                   when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                                   when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                   
                                                                                                                                   // Test
                                                                                                                                   Range result = plot.getDataRange(axis);
                                                                                                                                   
                                                                                                                                   // Verify - original behavior should combine ranges in order (1-2 then 3-4)
                                                                                                                                   assertEquals(new Range(1, 4), result);
                                                                                                                                   
                                                                                                                                   // Additional verification with non-overlapping ranges
                                                                                                                                   Range range3 = new Range(1, 2);
                                                                                                                                   Range range4 = new Range(5, 6);
                                                                                                                                   when(annotation1.getYRange()).thenReturn(range3);
                                                                                                                                   when(annotation2.getYRange()).thenReturn(range4);
                                                                                                                                   
                                                                                                                                   result = plot.getDataRange(axis);
                                                                                                                                   assertEquals(new Range(1, 6), result);
                                                                                                                               }

    @Test
                                                                                                                          public void testGetDataRange_DetectsAnnotationAddMutation() {
                                                                                                                              // Setup
                                                                                                                              XYPlot plot = new XYPlot();
                                                                                                                              ValueAxis axis = mock(ValueAxis.class);
                                                                                                                              
                                                                                                                              // Mock dataset and renderer setup
                                                                                                                              XYDataset dataset = mock(XYDataset.class);
                                                                                                                              XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                              // Create a mock that implements both interfaces
                                                                                                                              XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                              
                                                                                                                              // Configure mocks
                                                                                                                              when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                                              // Instead of calling private method, directly set up the plot's dataset mapping
                                                                                                                              plot.setDataset(0, dataset);
                                                                                                                              plot.mapDatasetToRangeAxis(0, 0);
                                                                                                                              when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                              when(renderer.getAnnotations()).thenReturn(Collections.singletonList((XYAnnotation)annotation));
                                                                                                                              when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                              
                                                                                                                              // Use a spy to track list modifications
                                                                                                                              List<XYAnnotation> annotationsSpy = spy(new ArrayList<>());
                                                                                                                              // This is needed because the original method creates new lists internally
                                                                                                                              doReturn(annotationsSpy).when(plot).getAnnotations();
                                                                                                                              
                                                                                                                              // Execute
                                                                                                                              plot.getDataRange(axis);
                                                                                                                              
                                                                                                                              // Verify the mutation by checking exact add operations
                                                                                                                              // Original code would use add() once per annotation
                                                                                                                              // Mutant would use addAll() once per annotation
                                                                                                                              verify(annotationsSpy, times(1)).add(any(XYAnnotation.class));
                                                                                                                              verify(annotationsSpy, never()).addAll(anyCollection());
                                                                                                                              
                                                                                                                              // Also verify the annotation was actually processed
                                                                                                                              verify(annotation).getIncludeInDataBounds();
                                                                                                                          }

    @Test
                                                                                                                     public void testGetDataRangeWithManyAnnotations() {
                                                                                                                         // Setup
                                                                                                                         XYPlot plot = new XYPlot();
                                                                                                                         ValueAxis axis = mock(ValueAxis.class);
                                                                                                                         
                                                                                                                         // Create a dataset and mock its renderer
                                                                                                                         XYDataset dataset = mock(XYDataset.class);
                                                                                                                         XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                         
                                                                                                                         // Setup 11 annotations (more than the mutant's limit)
                                                                                                                         Collection<XYAnnotationBoundsInfo> annotations = new ArrayList<>();
                                                                                                                         for (int i = 0; i < 11; i++) {
                                                                                                                             XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                                             when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                             when(annotation.getXRange()).thenReturn(new Range(i, i+1));
                                                                                                                             annotations.add(annotation);
                                                                                                                         }
                                                                                                                         
                                                                                                                         // Setup plot properly instead of mocking private methods
                                                                                                                         plot.setDataset(0, dataset);
                                                                                                                         plot.mapDatasetToDomainAxis(0, 0);
                                                                                                                         plot.setDomainAxis(0, axis);
                                                                                                                         
                                                                                                                         // Mock behavior
                                                                                                                         when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                                                                                                                         when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                         when(renderer.findDomainBounds(dataset)).thenReturn(new Range(0, 10));
                                                                                                                         when(renderer.getAnnotations()).thenReturn((Collection)annotations);
                                                                                                                         
                                                                                                                         // Execute
                                                                                                                         Range result = plot.getDataRange(axis);
                                                                                                                         
                                                                                                                         // Verify - the range should include all annotations (0-12)
                                                                                                                         // If mutant is present, it would only include first 10 (0-10)
                                                                                                                         assertEquals(0.0, result.getLowerBound(), 0.0001);
                                                                                                                         assertEquals(12.0, result.getUpperBound(), 0.0001);
                                                                                                                         
                                                                                                                         // Additional verification - check all annotations were processed
                                                                                                                         // This would fail with the mutant as it would stop after 10
                                                                                                                         verify(renderer, times(11)).getAnnotations();
                                                                                                                     }

    @Test
                                                                                                        public void testGetDataRange_IncludesRendererAnnotations6() {
                                                                                                            // Setup test data
                                                                                                            ValueAxis axis = mock(ValueAxis.class);
                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                            XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                            XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                            Range annotationRange = new Range(1.0, 2.0);
                                                                                                            
                                                                                                            // Create test instance first
                                                                                                            XYPlot plot = new XYPlot();
                                                                                                            
                                                                                                            // Configure mocks
                                                                                                            when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                            
                                                                                                            // Mock private getDatasetsMappedToRangeAxis method
                                                                                                            try {
                                                                                                                Method method = XYPlot.class.getDeclaredMethod("getDatasetsMappedToRangeAxis", Integer.TYPE);
                                                                                                                method.setAccessible(true);
                                                                                                                // Use doReturn().when() pattern for mocking private methods
                                                                                                                List<XYDataset> datasets = Collections.singletonList(dataset);
                                                                                                                doReturn(datasets).when((XYPlot)method.invoke(plot, 0));
                                                                                                            } catch (Exception e) {
                                                                                                                fail("Failed to mock private method");
                                                                                                            }
                                                                                                            
                                                                                                            when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                            
                                                                                                            // Setup renderer to return annotation and range
                                                                                                            Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                                            annotations.add((XYAnnotation)annotation); // Cast to XYAnnotation
                                                                                                            when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                            when(renderer.findRangeBounds(dataset)).thenReturn(new Range(0.5, 1.5));
                                                                                                            when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                            when(annotation.getYRange()).thenReturn(annotationRange);
                                                                                                            
                                                                                                            // Set required state
                                                                                                            plot.setRangeAxis(0, axis);
                                                                                                            plot.setDataset(0, dataset);
                                                                                                            plot.setRenderer(0, renderer);
                                                                                                            
                                                                                                            // Execute and verify
                                                                                                            Range result = plot.getDataRange(axis);
                                                                                                            
                                                                                                            // The combined range should be min(0.5,1.0) to max(1.5,2.0) = 0.5 to 2.0
                                                                                                            assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                                                            assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                                                            
                                                                                                            // This test will fail with the mutant because the annotation range won't be included
                                                                                                            // since the mutant replaces the annotations list instead of adding to it
                                                                                                        }

    @Test
                                                                                                   public void testGetDataRange_ShouldNotDuplicateRendererAnnotations1() {
                                                                                                       // Setup test data
                                                                                                       ValueAxis axis = mock(ValueAxis.class);
                                                                                                       XYDataset dataset = mock(XYDataset.class);
                                                                                                       XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                       XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                                                       
                                                                                                       // Configure mocks
                                                                                                       when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                                                       when(annotation.getYRange()).thenReturn(new Range(5.0, 10.0));
                                                                                                       
                                                                                                       Collection<XYAnnotation> rendererAnnotations = new ArrayList<>();
                                                                                                       rendererAnnotations.add((XYAnnotation) annotation);
                                                                                                       when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                                                                                                       
                                                                                                       // Setup XYPlot
                                                                                                       XYPlot plot = new XYPlot();
                                                                                                       plot.setDataset(0, dataset);
                                                                                                       plot.setRenderer(0, renderer);
                                                                                                       plot.mapDatasetToRangeAxis(0, 0);  // Use public API instead of mocking private method
                                                                                                       
                                                                                                       when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                                                       when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                       
                                                                                                       // Execute
                                                                                                       Range result = plot.getDataRange(axis);
                                                                                                       
                                                                                                       // Verify
                                                                                                       // The range should be exactly the annotation's range (5,10)
                                                                                                       // If the mutation exists, the range would be calculated twice
                                                                                                       assertEquals(5.0, result.getLowerBound(), 0.0001);
                                                                                                       assertEquals(10.0, result.getUpperBound(), 0.0001);
                                                                                                       
                                                                                                       // Alternative verification - check annotations weren't added twice
                                                                                                       // This requires reflection to access includedAnnotations
                                                                                                       try {
                                                                                                           Field annotationsField = XYPlot.class.getDeclaredField("annotations");
                                                                                                           annotationsField.setAccessible(true);
                                                                                                           List<?> plotAnnotations = (List<?>) annotationsField.get(plot);
                                                                                                           assertEquals(1, plotAnnotations.size()); // Should only contain the original annotation once
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to verify annotations through reflection");
                                                                                                       }
                                                                                                   }

    @Test
                                                                                          public void testGetDataRange_DetectsMutantInAnnotationHandling() {
                                                                                              // Setup test data
                                                                                              ValueAxis axis = mock(ValueAxis.class);
                                                                                              XYDataset dataset = mock(XYDataset.class);
                                                                                              XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                              
                                                                                              // Create annotations - one regular and one bounds info
                                                                                              XYAnnotation regularAnnotation = mock(XYAnnotation.class);
                                                                                              XYAnnotation boundsAnnotation = mock(XYAnnotation.class, withSettings().extraInterfaces(XYAnnotationBoundsInfo.class));
                                                                                              when(((XYAnnotationBoundsInfo)boundsAnnotation).getIncludeInDataBounds()).thenReturn(true);
                                                                                              when(((XYAnnotationBoundsInfo)boundsAnnotation).getXRange()).thenReturn(new Range(1, 2));
                                                                                              when(((XYAnnotationBoundsInfo)boundsAnnotation).getYRange()).thenReturn(new Range(3, 4));
                                                                                              
                                                                                              // Configure renderer behavior
                                                                                              Collection<XYAnnotation> rendererAnnotations = new ArrayList<>();
                                                                                              rendererAnnotations.add(regularAnnotation);
                                                                                              rendererAnnotations.add(boundsAnnotation);
                                                                                              when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                                                                                              when(renderer.findDomainBounds(dataset)).thenReturn(new Range(0, 10));
                                                                                              when(renderer.findRangeBounds(dataset)).thenReturn(new Range(0, 20));
                                                                                              
                                                                                              // Setup plot
                                                                                              XYPlot plot = new XYPlot();
                                                                                              plot.setDataset(0, dataset);
                                                                                              plot.setRenderer(0, renderer);
                                                                                              plot.mapDatasetToDomainAxis(0, 0);
                                                                                              
                                                                                              // Mock axis index lookup
                                                                                              when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                                                                                              
                                                                                              // Execute
                                                                                              Range result = plot.getDataRange(axis);
                                                                                              
                                                                                              // Verify - the bounds annotation should affect the range
                                                                                              // Original code would include both annotations' bounds
                                                                                              // Mutant would only include XYAnnotation instances (but boundsAnnotation is also XYAnnotation)
                                                                                              // To catch the mutant, we need to verify the exact range combination
                                                                                              
                                                                                              // Expected range is combination of dataset (0,10) and annotation (1,2)
                                                                                              assertEquals(0.0, result.getLowerBound(), 0.001);
                                                                                              assertEquals(10.0, result.getUpperBound(), 0.001);
                                                                                              
                                                                                              // Additional verification - check if annotation was processed
                                                                                              // This would fail if the mutant skipped the bounds annotation
                                                                                              verify((XYAnnotationBoundsInfo)boundsAnnotation, atLeastOnce()).getIncludeInDataBounds();
                                                                                          }

    @Test
                                                                             public void testGetDataRangeWithNonBoundsAnnotations() {
                                                                                 // Setup test data
                                                                                 ValueAxis axis = mock(ValueAxis.class);
                                                                                 XYDataset dataset = mock(XYDataset.class);
                                                                                 XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                 
                                                                                 // Create a mock annotation that doesn't implement XYAnnotationBoundsInfo
                                                                                 XYAnnotation regularAnnotation = mock(XYAnnotation.class);
                                                                                 Collection<XYAnnotation> annotations = new ArrayList<>();
                                                                                 annotations.add(regularAnnotation);
                                                                                 
                                                                                 // Create test subject as spy to mock instance methods
                                                                                 XYPlot plot = spy(new XYPlot());
                                                                                 
                                                                                 // Configure mocks
                                                                                 doReturn(0).when(plot).getRangeAxisIndex(axis);
                                                                                 // Instead of mocking private method, set up the plot with public methods
                                                                                 plot.setDataset(0, dataset);
                                                                                 plot.mapDatasetToRangeAxis(0, 0);
                                                                                 doReturn(renderer).when(plot).getRendererForDataset(dataset);
                                                                                 when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                 
                                                                                 // Test - should not throw exception with original code
                                                                                 // If the mutation is present, this would throw ClassCastException
                                                                                 Range result = plot.getDataRange(axis);
                                                                                 
                                                                                 // Verify the annotation was processed (though not included in bounds)
                                                                                 // We can't directly check the internal list, but we can verify the renderer was called
                                                                                 verify(renderer).getAnnotations();
                                                                                 
                                                                                 // Additional assertions about the result if needed
                                                                                 assertNotNull(result); // Basic sanity check
                                                                             }

    @Test
                                                                        public void testGetDataRange_AlwaysIncludesRendererAnnotations() {
                                                                            // Setup test data
                                                                            ValueAxis axis = mock(ValueAxis.class);
                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                            XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                            XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                            Range annotationRange = new Range(1.0, 2.0);
                                                                            
                                                                            // Configure mocks
                                                                            when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                            when(annotation.getYRange()).thenReturn(annotationRange);
                                                                            when(renderer.getAnnotations()).thenReturn(Collections.singletonList(annotation));
                                                                            when(renderer.findRangeBounds(dataset)).thenReturn(new Range(0.5, 1.5));
                                                                            
                                                                            // Create plot and configure it
                                                                            XYPlot plot = new XYPlot();
                                                                            plot.setDataset(0, dataset);
                                                                            plot.setRenderer(0, renderer);
                                                                            plot.mapDatasetToRangeAxis(0, 0);
                                                                            plot.setRangeAxis(0, axis);
                                                                            
                                                                            // Add some annotations to plot to ensure they're processed too
                                                                            XYAnnotationBoundsInfo plotAnnotation = mock(XYAnnotationBoundsInfo.class);
                                                                            when(plotAnnotation.getIncludeInDataBounds()).thenReturn(true);
                                                                            when(plotAnnotation.getYRange()).thenReturn(new Range(0.8, 1.8));
                                                                            plot.addAnnotation((XYAnnotation) plotAnnotation);
                                                                            
                                                                            // Execute and verify
                                                                            Range result = plot.getDataRange(axis);
                                                                            
                                                                            // The expected range should combine:
                                                                            // - Renderer's dataset range (0.5-1.5)
                                                                            // - Renderer's annotation range (1.0-2.0)
                                                                            // - Plot's annotation range (0.8-1.8)
                                                                            // So final range should be 0.5-2.0
                                                                            assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                            assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                            
                                                                            // Verify the renderer's annotation was processed by checking mock interactions
                                                                            verify(annotation, atLeastOnce()).getIncludeInDataBounds();
                                                                            verify(annotation, atLeastOnce()).getYRange();
                                                                        }

    @Test
                                                                    public void testGetDataRange_ShouldIncludeRendererAnnotations() {
                                                                        // Setup test data
                                                                        ValueAxis axis = mock(ValueAxis.class);
                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                        XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                        XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                        Range annotationRange = new Range(5, 10);
                                                                        
                                                                        // Configure mocks
                                                                        when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                        when(annotation.getYRange()).thenReturn(annotationRange);
                                                                        when(renderer.getAnnotations()).thenReturn(Collections.singletonList(annotation));
                                                                        when(renderer.findRangeBounds(dataset)).thenReturn(new Range(1, 5));
                                                                        
                                                                        // Setup plot
                                                                        XYPlot plot = new XYPlot();
                                                                        plot.setDataset(0, dataset);
                                                                        plot.setRenderer(0, renderer);
                                                                        plot.mapDatasetToRangeAxis(0, 0);
                                                                        plot.setRangeAxis(0, axis);
                                                                        
                                                                        // Execute and verify
                                                                        Range result = plot.getDataRange(axis);
                                                                        // Should combine dataset range (1,5) with annotation range (5,10)
                                                                        assertEquals(new Range(1, 10), result);
                                                                        
                                                                        // Verify annotation was processed
                                                                        verify(annotation).getIncludeInDataBounds();
                                                                        verify(annotation).getYRange();
                                                                    }

    @Test
                                                                   public void testGetDataRange_IncludesRendererAnnotations7() {
                                                                       // Setup test data
                                                                       ValueAxis axis = mock(ValueAxis.class);
                                                                       XYDataset dataset = mock(XYDataset.class);
                                                                       XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                       XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                       Range annotationRange = new Range(1.0, 2.0);
                                                                       
                                                                       // Configure mocks
                                                                       when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                       when(annotation.getYRange()).thenReturn(annotationRange);
                                                                       when(renderer.getAnnotations()).thenReturn(Collections.singletonList(annotation));
                                                                       when(renderer.findRangeBounds(dataset)).thenReturn(new Range(0.5, 1.5));
                                                                       
                                                                       // Create plot and configure it
                                                                       XYPlot plot = new XYPlot();
                                                                       plot.setDataset(0, dataset);
                                                                       plot.setRenderer(0, renderer);
                                                                       plot.mapDatasetToRangeAxis(0, 0);
                                                                       plot.setRangeAxis(0, axis);
                                                                       
                                                                       // Execute and verify
                                                                       Range result = plot.getDataRange(axis);
                                                                       
                                                                       // The combined range should include both the dataset range (0.5-1.5) and annotation range (1.0-2.0)
                                                                       assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                                       assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                                       
                                                                       // Additional verification that annotation was processed
                                                                       verify(annotation, atLeastOnce()).getIncludeInDataBounds();
                                                                       verify(annotation, atLeastOnce()).getYRange();
                                                                   }

    @Test
                                                                 public void testGetDataRange_DetectsAnnotationMutation1() {
                                                                     // Setup test data
                                                                     ValueAxis axis = mock(ValueAxis.class);
                                                                     XYDataset dataset = mock(XYDataset.class);
                                                                     XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                     XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                                                     Range annotationRange = new Range(1.0, 2.0);
                                                                     
                                                                     // Configure mocks
                                                                     when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                                                     when(annotation.getYRange()).thenReturn(annotationRange);
                                                                     
                                                                     Collection<XYAnnotation> rendererAnnotations = new ArrayList<>();
                                                                     rendererAnnotations.add((XYAnnotation) annotation);
                                                                     when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                                                                     
                                                                     // Setup XYPlot
                                                                     XYPlot plot = new XYPlot();
                                                                     plot.setDataset(0, dataset);
                                                                     plot.setRenderer(0, renderer);
                                                                     plot.mapDatasetToRangeAxis(0, 0);
                                                                     plot.setRangeAxis(0, axis);
                                                                     
                                                                     // Mock axis index lookup
                                                                     when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                                     
                                                                     // Execute and verify
                                                                     Range result = plot.getDataRange(axis);
                                                                     
                                                                     // Verify the annotation was properly processed
                                                                     // If mutation exists, this would either throw NPE or not include the annotation range
                                                                     assertTrue("Result range should include annotation range", 
                                                                                result.getUpperBound() >= annotationRange.getUpperBound());
                                                                     assertTrue("Result range should include annotation range",
                                                                                result.getLowerBound() <= annotationRange.getLowerBound());
                                                                     
                                                                     // Additional verification that annotations were properly added
                                                                     // This would fail if mutation exists (null added instead of annotation)
                                                                     try {
                                                                         Field field = XYPlot.class.getDeclaredField("includedAnnotations");
                                                                         field.setAccessible(true);
                                                                         List<?> includedAnnotations = (List<?>) field.get(plot);
                                                                         assertFalse("Annotations list should not contain null", includedAnnotations.contains(null));
                                                                         assertTrue("Annotations list should contain our test annotation", 
                                                                                    includedAnnotations.contains(annotation));
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                 }

    @Test
                                                        public void testGetDataRangeWithNullAnnotations1() {
                                                            // Setup test data
                                                            ValueAxis axis = mock(ValueAxis.class);
                                                            XYDataset dataset = mock(XYDataset.class);
                                                            XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                            
                                                            // Create mock annotations - need to be XYAnnotation that also implements XYAnnotationBoundsInfo
                                                            XYAnnotationBoundsInfo annotation1 = mock(XYAnnotationBoundsInfo.class);
                                                            XYAnnotationBoundsInfo annotation2 = mock(XYAnnotationBoundsInfo.class);
                                                            
                                                            // Create a list of annotations that includes a null value
                                                            List<XYAnnotation> annotations = new ArrayList<>();
                                                            annotations.add((XYAnnotation) annotation1);
                                                            annotations.add(null); // This is the key part for testing the mutation
                                                            annotations.add((XYAnnotation) annotation2);
                                                            
                                                            // Mock behavior
                                                            XYPlot plot = spy(new XYPlot());
                                                            when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                            
                                                            // Instead of mocking private method, set up the mapping through public API
                                                            plot.setDataset(0, dataset);
                                                            plot.mapDatasetToRangeAxis(0, 0);
                                                            
                                                            when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                            when(renderer.getAnnotations()).thenReturn(annotations);
                                                            
                                                            // Set up test conditions
                                                            plot.setRangeAxis(0, axis);
                                                            plot.setDataset(0, dataset);
                                                            plot.setRenderer(0, renderer);
                                                            
                                                            // Execute
                                                            Range result = plot.getDataRange(axis);
                                                            
                                                            // Verify the behavior difference caused by mutation
                                                            // Original version would try to add null annotation, mutated version would skip it
                                                            // We can't directly check includedAnnotations size, but we can verify the final range
                                                            // is calculated correctly despite null annotations
                                                            
                                                            // Additional verification that renderer annotations were processed
                                                            verify(renderer, times(1)).getAnnotations();
                                                            
                                                            // If we had access to includedAnnotations, we would assert its size is 2 (skipping null)
                                                            // Since we can't, we just verify the method completes successfully
                                                            assertNotNull(result);
                                                        }

    @Test
                                               public void testAnnotationOrderInIncludedAnnotations() {
                                                   // Setup
                                                   XYPlot plot = new XYPlot();
                                                   ValueAxis axis = mock(ValueAxis.class);
                                                   
                                                   // Mock renderer with annotations
                                                   XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                   XYAnnotation annotation1 = mock(XYAnnotation.class);
                                                   XYAnnotation annotation2 = mock(XYAnnotation.class);
                                                   Collection<XYAnnotation> annotations = new ArrayList<>();
                                                   annotations.add(annotation1);
                                                   annotations.add(annotation2);
                                                   when(renderer.getAnnotations()).thenReturn(annotations);
                                                   
                                                   // Mock dataset and its mapping
                                                   XYDataset dataset = mock(XYDataset.class);
                                                   when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                   when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                                   
                                                   // Mock private method using doReturn pattern
                                                   List<XYDataset> datasets = Collections.singletonList(dataset);
                                                   try {
                                                       Method method = XYPlot.class.getDeclaredMethod("getDatasetsMappedToRangeAxis", Integer.class);
                                                       method.setAccessible(true);
                                                       when(method.invoke(plot, any())).thenReturn(datasets);
                                                   } catch (Exception e) {
                                                       fail("Failed to mock private method: " + e.getMessage());
                                                   }
                                                   
                                                   // Execute
                                                   plot.getDataRange(axis);
                                                   
                                                   // Verify annotation order by checking the internal list
                                                   try {
                                                       Field field = XYPlot.class.getDeclaredField("annotations");
                                                       field.setAccessible(true);
                                                       List<?> actualAnnotations = (List<?>) field.get(plot);
                                                       
                                                       // Original behavior: annotations should be in order [annotation1, annotation2]
                                                       // Mutant behavior: would be [annotation2, annotation1]
                                                       assertEquals("First annotation should be annotation1", annotation1, actualAnnotations.get(0));
                                                       assertEquals("Second annotation should be annotation2", annotation2, actualAnnotations.get(1));
                                                   } catch (Exception e) {
                                                       fail("Failed to verify annotation order: " + e.getMessage());
                                                   }
                                               }

    @Test
                                          public void testGetDataRange_DetectsAnnotationAddMutation1() {
                                              // Setup test data
                                              ValueAxis axis = mock(ValueAxis.class);
                                              XYPlot plot = new XYPlot();
                                              
                                              // Create mock dataset and renderer
                                              XYDataset dataset = mock(XYDataset.class);
                                              XYItemRenderer renderer = mock(XYItemRenderer.class);
                                              
                                              // Setup mock behavior
                                              when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                              plot.mapDatasetToRangeAxis(0, 0);  // Use public method instead of mocking private one
                                              when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                              
                                              // Create test annotation
                                              XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                              when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                              when(annotation.getYRange()).thenReturn(new Range(1, 2));
                                              
                                              // Setup renderer to return our annotation
                                              Collection<XYAnnotation> annotations = new ArrayList<>();
                                              annotations.add((XYAnnotation) annotation);  // Proper casting
                                              when(renderer.getAnnotations()).thenReturn(annotations);
                                              
                                              // Create a spy list to verify method calls
                                              List<XYAnnotation> spyList = spy(new ArrayList<>());
                                              
                                              try {
                                                  // Use reflection to inject our spy list
                                                  Field field = XYPlot.class.getDeclaredField("includedAnnotations");
                                                  field.setAccessible(true);
                                                  field.set(plot, spyList);
                                                  
                                                  // Execute the method
                                                  plot.getDataRange(axis);
                                                  
                                                  // Verify the exact method call was made
                                                  verify(spyList).add((XYAnnotation) annotation);  // Proper casting
                                                  
                                              } catch (Exception e) {
                                                  fail("Test setup failed: " + e.getMessage());
                                              }
                                          }

    @Test
                                     public void testGetDataRange_IncludesAllRendererAnnotations_RegardlessOfCount() {
                                         // Setup
                                         XYPlot plot = new XYPlot();
                                         ValueAxis axis = mock(ValueAxis.class);
                                         
                                         // Create a renderer with 11 annotations
                                         XYItemRenderer renderer = mock(XYItemRenderer.class);
                                         Collection<XYAnnotationBoundsInfo> annotations = new ArrayList<>();
                                         for (int i = 0; i < 11; i++) {
                                             XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                             when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                             when(annotation.getYRange()).thenReturn(new Range(i, i+1));
                                             annotations.add(annotation);
                                         }
                                         when(renderer.getAnnotations()).thenReturn((Collection)annotations);
                                         
                                         // Setup dataset and mappings
                                         XYDataset dataset = mock(XYDataset.class);
                                         plot.setDataset(0, dataset);
                                         plot.setRenderer(0, renderer);
                                         when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                         when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                         when(renderer.findRangeBounds(dataset)).thenReturn(new Range(0, 10));
                                         
                                         // Execute
                                         Range result = plot.getDataRange(axis);
                                         
                                         // Verify - should include all 11 annotations (range 0-12)
                                         // If mutation is present, it would only include first 10 (range 0-11)
                                         assertEquals(0.0, result.getLowerBound(), 0.0001);
                                         assertEquals(12.0, result.getUpperBound(), 0.0001);
                                     }

    @Test
                            public void testGetDataRange_IncludesRendererAnnotations8() {
                                // Setup test data
                                ValueAxis axis = mock(ValueAxis.class);
                                XYDataset dataset = mock(XYDataset.class);
                                XYItemRenderer renderer = mock(XYItemRenderer.class);
                                XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                                Range annotationRange = new Range(5, 10);
                                
                                // Create plot and configure
                                XYPlot plot = new XYPlot();
                                plot.setDataset(0, dataset);
                                plot.setRenderer(0, renderer);
                                plot.setRangeAxis(0, axis);
                                plot.mapDatasetToRangeAxis(0, 0);  // explicitly map dataset to range axis
                                
                                // Configure mocks
                                when(plot.getRangeAxisIndex(axis)).thenReturn(0);
                                when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                
                                // Setup renderer to return annotation
                                Collection<XYAnnotation> annotations = new ArrayList<>();
                                annotations.add((XYAnnotation)annotation);
                                when(renderer.getAnnotations()).thenReturn(annotations);
                                when(annotation.getIncludeInDataBounds()).thenReturn(true);
                                when(annotation.getYRange()).thenReturn(annotationRange);
                                
                                // Setup dataset range
                                Range datasetRange = new Range(1, 5);
                                when(renderer.findRangeBounds(dataset)).thenReturn(datasetRange);
                                
                                // Expected range is combination of dataset range and annotation range
                                Range expected = new Range(1, 10);
                                Range actual = plot.getDataRange(axis);
                                
                                assertEquals("Range should include annotation bounds", expected, actual);
                            }

    @Test
                       public void testGetDataRange_DetectDuplicateAnnotationMutation() throws NoSuchFieldException, IllegalAccessException {
                           // Setup test data
                           ValueAxis axis = mock(ValueAxis.class);
                           XYPlot plot = new XYPlot();
                           
                           // Create mock dataset and renderer
                           XYDataset dataset = mock(XYDataset.class);
                           XYItemRenderer renderer = mock(XYItemRenderer.class);
                           
                           // Create mock annotation that affects bounds
                           XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
                           when(annotation.getIncludeInDataBounds()).thenReturn(true);
                           when(annotation.getXRange()).thenReturn(new Range(1, 10));
                           when(annotation.getYRange()).thenReturn(new Range(1, 10));
                           
                           // Configure renderer to return our annotation
                           Collection<XYAnnotation> annotations = new ArrayList<>();
                           annotations.add((XYAnnotation) annotation);
                           when(renderer.getAnnotations()).thenReturn(annotations);
                           
                           // Configure plot to use our mock objects
                           plot.setDataset(0, dataset);
                           plot.setRenderer(0, renderer);
                           when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                           when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                           
                           // Execute the method
                           Range result = plot.getDataRange(axis);
                           
                           // Verify the annotation was processed correctly
                           // In original code, the range should be 1-10 (from one annotation)
                           // In mutated code, the range would be combined twice (still 1-10 but wrong calculation path)
                           
                           // More importantly, we can verify the annotation count in the processing
                           // This is a white-box test to catch the duplicate addition
                           Field includedAnnotationsField = XYPlot.class.getDeclaredField("includedAnnotations");
                           includedAnnotationsField.setAccessible(true);
                           @SuppressWarnings("unchecked")
                           List<XYAnnotation> includedAnnotations = (List<XYAnnotation>) includedAnnotationsField.get(plot);
                           
                           // Assert that each annotation was only added once
                           // In mutated code, this would be 2 instead of 1
                           assertEquals("Annotation should only be added once", 1, includedAnnotations.size());
                           
                           // Also verify the final range is correct
                           assertEquals(new Range(1, 10), result);
                       }

    @Test
                  public void testGetDataRange_DetectsAnnotationBoundsInfoFromRenderer() {
                      // Setup test data
                      ValueAxis axis = mock(ValueAxis.class);
                      XYPlot plot = new XYPlot();
                      
                      // Create mock dataset and renderer
                      XYDataset dataset = mock(XYDataset.class);
                      XYItemRenderer renderer = mock(XYItemRenderer.class);
                      
                      // Setup mock behavior - map dataset to domain axis 0
                      when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                      plot.setDataset(0, dataset);
                      plot.mapDatasetToDomainAxis(0, 0);
                      when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                      
                      // Create test annotations - boundsAnnotation needs to implement both interfaces
                      XYAnnotation regularAnnotation = mock(XYAnnotation.class);
                      XYAnnotation boundsAnnotation = mock(XYAnnotation.class, withSettings().extraInterfaces(XYAnnotationBoundsInfo.class));
                      when(((XYAnnotationBoundsInfo)boundsAnnotation).getIncludeInDataBounds()).thenReturn(true);
                      when(((XYAnnotationBoundsInfo)boundsAnnotation).getXRange()).thenReturn(new Range(1, 2));
                      
                      // Set renderer to return both types of annotations
                      Collection<XYAnnotation> rendererAnnotations = new ArrayList<>();
                      rendererAnnotations.add(regularAnnotation);
                      rendererAnnotations.add(boundsAnnotation);
                      when(renderer.getAnnotations()).thenReturn(rendererAnnotations);
                      
                      // Execute
                      Range result = plot.getDataRange(axis);
                      
                      // Verify - should only consider boundsAnnotation in range calculation
                      assertNotNull("Result should not be null", result);
                      assertEquals("Range lower bound should match bounds annotation", 1.0, result.getLowerBound(), 0.0001);
                      assertEquals("Range upper bound should match bounds annotation", 2.0, result.getUpperBound(), 0.0001);
                      
                      // Second test case for complete coverage
                      XYAnnotationBoundsInfo boundsOnlyAnnotation = mock(XYAnnotationBoundsInfo.class);
                      when(boundsOnlyAnnotation.getIncludeInDataBounds()).thenReturn(true);
                      when(boundsOnlyAnnotation.getXRange()).thenReturn(new Range(3, 4));
                      
                      // Create special case where the annotation implements XYAnnotationBoundsInfo but not XYAnnotation
                      Collection<?> specialAnnotations = new ArrayList<Object>() {{
                          add(boundsOnlyAnnotation);
                      }};
                      when(renderer.getAnnotations()).thenReturn((Collection)specialAnnotations);
                      
                      Range result2 = plot.getDataRange(axis);
                      assertNotNull("Result should not be null for special case", result2);
                      assertEquals("Should include bounds from special annotation", 3.0, result2.getLowerBound(), 0.0001);
                      assertEquals("Should include bounds from special annotation", 4.0, result2.getUpperBound(), 0.0001);
                  }

    @Test
         public void testGetDataRangeWithNonBoundsAnnotation() {
             // Setup test objects
             XYPlot plot = new XYPlot();
             ValueAxis axis = mock(ValueAxis.class);
             
             // Mock dataset and renderer
             XYDataset dataset = mock(XYDataset.class);
             XYItemRenderer renderer = mock(XYItemRenderer.class);
             
             // Setup mock behavior
             when(plot.getRangeAxisIndex(axis)).thenReturn(0);
             
             // Use reflection to access private method
             try {
                 Method method = XYPlot.class.getDeclaredMethod("getDatasetsMappedToRangeAxis", Integer.class);
                 method.setAccessible(true);
                 // Fix: Use anyInt() instead of any() for primitive wrapper
                 when(method.invoke(plot, anyInt())).thenReturn(java.util.Arrays.asList(dataset));
             } catch (Exception e) {
                 fail("Failed to access private method via reflection");
             }
             
             when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
             
             // Create a regular annotation (not XYAnnotationBoundsInfo)
             XYAnnotation regularAnnotation = mock(XYAnnotation.class);
             Collection<XYAnnotation> annotations = new ArrayList<>();
             annotations.add(regularAnnotation);
             when(renderer.getAnnotations()).thenReturn(annotations);
             
             // Execute and verify
             try {
                 Range result = plot.getDataRange(axis);
                 // Original behavior: annotation is added without casting
                 // No assertion needed here as we're testing for absence of exception
             } catch (ClassCastException e) {
                 fail("Should not throw ClassCastException for non-XYAnnotationBoundsInfo annotations");
             }
             
             // Additional verification that the method completed successfully
             assertNotNull(plot.getAnnotations());
         }

    @Test
    public void testGetDataRange_AlwaysIncludesRendererAnnotations1() {
        // Setup test data
        ValueAxis axis = mock(ValueAxis.class);
        XYPlot plot = new XYPlot();
        
        // Create mock dataset and renderer
        XYDataset dataset = mock(XYDataset.class);
        XYItemRenderer renderer = mock(XYItemRenderer.class);
        
        // Create annotation with bounds info
        XYAnnotationBoundsInfo annotation = mock(XYAnnotationBoundsInfo.class);
        when(annotation.getIncludeInDataBounds()).thenReturn(true);
        when(annotation.getYRange()).thenReturn(new Range(5, 10));
        
        // Configure renderer to return the annotation
        Collection<XYAnnotation> annotations = new ArrayList<>();
        annotations.add((XYAnnotation) annotation);
        when(renderer.getAnnotations()).thenReturn(annotations);
        
        // Configure plot
        plot.setDataset(0, dataset);
        plot.setRenderer(0, renderer);
        plot.mapDatasetToRangeAxis(0, 0);
        
        // Test multiple times to catch the non-deterministic mutant
        Range expectedRange = new Range(5, 10);
        for (int i = 0; i < 10; i++) {
            Range result = plot.getDataRange(axis);
            assertNotNull("Range should not be null", result);
            assertEquals("Range should include annotation bounds", 
                        expectedRange.getLowerBound(), result.getLowerBound(), 0.0001);
            assertEquals("Range should include annotation bounds",
                        expectedRange.getUpperBound(), result.getUpperBound(), 0.0001);
        }
    }


}
