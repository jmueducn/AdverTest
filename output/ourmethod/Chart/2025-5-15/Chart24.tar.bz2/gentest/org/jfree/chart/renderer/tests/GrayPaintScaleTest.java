package gentest.org.jfree.chart.renderer.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.*;
import java.awt.Color;
import java.awt.Paint;
import java.io.Serializable;
import org.jfree.chart.util.PublicCloneable;
 
public class GrayPaintScaleTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testConstructor_InvalidBounds() {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("Requires lowerBound < upperBound.");
                new GrayPaintScale(1.0, 1.0);
            }

    @Test
    public void testGetPaint_ValueWithinBounds() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0);
        
        // Middle value
        Color middle = (Color) scale.getPaint(50.0);
        assertEquals(127, middle.getRed());
        assertEquals(127, middle.getGreen());
        assertEquals(127, middle.getBlue());
        
        // Quarter value
        Color quarter = (Color) scale.getPaint(25.0);
        assertEquals(63, quarter.getRed());
        assertEquals(63, quarter.getGreen());
        assertEquals(63, quarter.getBlue());
    }

    @Test
    public void testGetPaint_ValueAtBounds() {
        GrayPaintScale scale = new GrayPaintScale(10.0, 20.0);
        
        // Lower bound
        Color lower = (Color) scale.getPaint(10.0);
        assertEquals(0, lower.getRed());
        assertEquals(0, lower.getGreen());
        assertEquals(0, lower.getBlue());
        
        // Upper bound
        Color upper = (Color) scale.getPaint(20.0);
        assertEquals(255, upper.getRed());
        assertEquals(255, upper.getGreen());
        assertEquals(255, upper.getBlue());
    }

    @Test
    public void testGetPaint_ValueOutsideBounds() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
        
        // Below lower bound
        Paint belowPaint = scale.getPaint(-10.0);
        Color below = (Color) belowPaint;
        assertEquals(0, below.getRed());
        assertEquals(0, below.getGreen());
        assertEquals(0, below.getBlue());
        
        // Above upper bound
        Paint abovePaint = scale.getPaint(10.0);
        Color above = (Color) abovePaint;
        assertEquals(255, above.getRed());
        assertEquals(255, above.getGreen());
        assertEquals(255, above.getBlue());
    }

    @Test
    public void testGetPaint_ReverseBounds() throws Exception {
        // Use reflection to create instance with reverse bounds
        Constructor<GrayPaintScale> constructor = GrayPaintScale.class.getDeclaredConstructor(
            double.class, double.class);
        constructor.setAccessible(true);
        GrayPaintScale scale = constructor.newInstance(100.0, 0.0);
        
        // Test middle value
        Color middle = (Color) scale.getPaint(50.0);
        assertEquals(127, middle.getRed());
        assertEquals(127, middle.getGreen());
        assertEquals(127, middle.getBlue());
    }

    @Test
    public void testGetPaint_SpecialCases() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
        
        // NaN should be treated as lower bound
        Color nanColor = (Color) scale.getPaint(Double.NaN);
        assertEquals(0, nanColor.getRed());
        assertEquals(0, nanColor.getGreen());
        assertEquals(0, nanColor.getBlue());
        
        // Infinity should be clamped to bounds
        Color posInf = (Color) scale.getPaint(Double.POSITIVE_INFINITY);
        assertEquals(255, posInf.getRed());
        assertEquals(255, posInf.getGreen());
        assertEquals(255, posInf.getBlue());
        
        Color negInf = (Color) scale.getPaint(Double.NEGATIVE_INFINITY);
        assertEquals(0, negInf.getRed());
        assertEquals(0, negInf.getGreen());
        assertEquals(0, negInf.getBlue());
    }

    @Test
    public void testGetPaint_ZeroRange() {
        // Even though constructor prevents this, test for robustness
        try {
            GrayPaintScale scale = new GrayPaintScale(5.0, 5.0);
            Color color = (Color) scale.getPaint(5.0);
            assertEquals(0, color.getRed());  // Special case when range is 0
            assertEquals(0, color.getGreen());
            assertEquals(0, color.getBlue());
        } catch (IllegalArgumentException e) {
            // Expected behavior since constructor prevents zero range
            assertTrue(true);
        }
    }


}
