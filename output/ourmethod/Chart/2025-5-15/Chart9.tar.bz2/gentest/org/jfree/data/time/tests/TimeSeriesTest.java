package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                         public void testCreateCopy_NegativeStartIndex() throws Exception {
                             TimeSeries series = new TimeSeries("Test Series");
                             thrown.expect(IllegalArgumentException.class);
                             thrown.expectMessage("Requires start >= 0.");
                             series.createCopy(-1, 0);
                         }

    @Test
                         public void testCreateCopy_EndLessThanStart() throws Exception {
                             TimeSeries series = new TimeSeries("Test Series");
                             thrown.expect(IllegalArgumentException.class);
                             thrown.expectMessage("Requires start <= end.");
                             series.createCopy(2, 1);
                         }

    @Test
                         public void testCreateCopy_EmptySeries() throws Exception {
                             TimeSeries series = new TimeSeries("Test Series");
                             TimeSeries copy = series.createCopy(0, 0);
                             assertNotNull(copy);
                             assertEquals(0, copy.getItemCount());
                         }

    @Test
                         public void testCreateCopy_SingleItem() throws Exception {
                             TimeSeries series = new TimeSeries("Test Series");
                             RegularTimePeriod period = mock(RegularTimePeriod.class);
                             TimeSeriesDataItem item = new TimeSeriesDataItem(period, 10.0);
                             series.add(item);
                             
                             TimeSeries copy = series.createCopy(0, 0);
                             assertEquals(1, copy.getItemCount());
                             assertNotSame(series.getDataItem(0), copy.getDataItem(0)); // Verify deep copy
                             assertEquals(series.getValue(0), copy.getValue(0));
                         }

    @Test
                         public void testCreateCopy_MultipleItems() throws Exception {
                             TimeSeries series = new TimeSeries("Test Series");
                             // Add 5 items
                             for (int i = 0; i < 5; i++) {
                                 RegularTimePeriod period = mock(RegularTimePeriod.class);
                                 series.add(new TimeSeriesDataItem(period, i * 10.0));
                             }
                             
                             // Copy middle 3 items (indices 1-3)
                             TimeSeries copy = series.createCopy(1, 3);
                             assertEquals(3, copy.getItemCount());
                             assertEquals(series.getValue(1), copy.getValue(0));
                             assertEquals(series.getValue(2), copy.getValue(1));
                             assertEquals(series.getValue(3), copy.getValue(2));
                         }

    @Test
                         public void testCreateCopy_FullRange() throws Exception {
                             TimeSeries series = new TimeSeries("Test Series");
                             // Add 3 items
                             for (int i = 0; i < 3; i++) {
                                 RegularTimePeriod period = mock(RegularTimePeriod.class);
                                 series.add(new TimeSeriesDataItem(period, i * 5.0));
                             }
                             
                             TimeSeries copy = series.createCopy(0, 2);
                             assertEquals(3, copy.getItemCount());
                             for (int i = 0; i < 3; i++) {
                                 assertEquals(series.getValue(i), copy.getValue(i));
                                 assertNotSame(series.getDataItem(i), copy.getDataItem(i));
                             }
                         }

    @Test
                         public void testCreateCopy_BoundaryConditions() throws Exception {
                             TimeSeries series = new TimeSeries("Test Series");
                             // Add 2 items
                             RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                             RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                             series.add(new TimeSeriesDataItem(period1, 100.0));
                             series.add(new TimeSeriesDataItem(period2, 200.0));
                             
                             // Test start equals end
                             TimeSeries copy1 = series.createCopy(1, 1);
                             assertEquals(1, copy1.getItemCount());
                             assertEquals(series.getValue(1), copy1.getValue(0));
                             
                             // Test start equals 0
                             TimeSeries copy2 = series.createCopy(0, 1);
                             assertEquals(2, copy2.getItemCount());
                         }

    @Test
                         public void testCreateCopy_VerifyDeepCopy() throws Exception {
                             TimeSeries series = new TimeSeries("Test Series");
                             RegularTimePeriod period = mock(RegularTimePeriod.class);
                             TimeSeriesDataItem originalItem = new TimeSeriesDataItem(period, 42.0);
                             series.add(originalItem);
                             
                             TimeSeries copy = series.createCopy(0, 0);
                             TimeSeriesDataItem copiedItem = copy.getDataItem(0);
                             
                             // Verify it's a different object
                             assertNotSame(originalItem, copiedItem);
                             // But with same values
                             assertEquals(originalItem.getValue(), copiedItem.getValue());
                             assertSame(originalItem.getPeriod(), copiedItem.getPeriod()); // Period is not cloned
                         }

    @Test
         public void testCreateCopy_NullStartPeriod_ThrowsIllegalArgumentException() throws CloneNotSupportedException {
             // Setup
             ExpectedException thrown = ExpectedException.none();
             TimeSeries timeSeries = new TimeSeries("Test Series");
             RegularTimePeriod endPeriod = mock(RegularTimePeriod.class);
             
             // Expect exception
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("Null 'start' argument.");
             
             // Test
             timeSeries.createCopy(null, endPeriod);
         }

    @Test
         public void testCreateCopy_EmptyRange_ReturnsEmptySeries() throws CloneNotSupportedException {
             TimeSeries timeSeries = new TimeSeries("Test Series");
             Day startDay = new Day(5, 1, 2023); // After all data points
             Day endDay = new Day(10, 1, 2023);  // After all data points
             
             TimeSeries result = timeSeries.createCopy(startDay, endDay);
             assertEquals(0, result.getItemCount());
         }

    @Test
         public void testCreateCopy_StartBeforeData_EndInData() throws CloneNotSupportedException {
             TimeSeries timeSeries = new TimeSeries("Test Series");
             // Add test data points
             timeSeries.add(new Day(1, 1, 2023), 10.0);  // First data point
             timeSeries.add(new Day(2, 1, 2023), 20.0);  // Second data point
             
             Day startDay = new Day(31, 12, 2022); // Before first data point
             Day endDay = new Day(2, 1, 2023);    // In the middle of data
             
             TimeSeries result = timeSeries.createCopy(startDay, endDay);
             assertEquals(2, result.getItemCount());
             assertEquals(10.0, result.getValue(0).doubleValue(), 0.001);
             assertEquals(20.0, result.getValue(1).doubleValue(), 0.001);
         }

    @Test
         public void testCreateCopy_StartInData_EndAfterData() throws CloneNotSupportedException {
             // Create and populate the time series
             TimeSeries timeSeries = new TimeSeries("Test Series");
             timeSeries.add(new Day(1, 1, 2023), 10.0);  // First data point
             timeSeries.add(new Day(2, 1, 2023), 20.0); // Second data point
             timeSeries.add(new Day(3, 1, 2023), 30.0); // Third data point
             
             Day startDay = new Day(2, 1, 2023);  // In the middle of data
             Day endDay = new Day(10, 1, 2023);   // After last data point
             
             TimeSeries result = timeSeries.createCopy(startDay, endDay);
             assertEquals(2, result.getItemCount());
             assertEquals(20.0, result.getValue(0).doubleValue(), 0.001);
             assertEquals(30.0, result.getValue(1).doubleValue(), 0.001);
         }

    @Test
         public void testCreateCopy_ExactRange() throws CloneNotSupportedException {
             TimeSeries timeSeries = new TimeSeries("Test Series");
             // Add test data points
             timeSeries.add(new Day(1, 1, 2023), 10.0);
             timeSeries.add(new Day(2, 1, 2023), 20.0);
             timeSeries.add(new Day(3, 1, 2023), 30.0);
             
             Day startDay = new Day(1, 1, 2023);
             Day endDay = new Day(3, 1, 2023);
             
             TimeSeries result = timeSeries.createCopy(startDay, endDay);
             assertEquals(3, result.getItemCount());
             assertEquals(10.0, result.getValue(0).doubleValue(), 0.001);
             assertEquals(20.0, result.getValue(1).doubleValue(), 0.001);
             assertEquals(30.0, result.getValue(2).doubleValue(), 0.001);
         }

    @Test
         public void testCreateCopy_PartialRange() throws CloneNotSupportedException {
             // Create and initialize time series
             TimeSeries timeSeries = new TimeSeries("Test Series");
             Day testDay = new Day(2, 1, 2023);
             timeSeries.add(testDay, 20.0);
             
             // Define test range (same day)
             Day startDay = new Day(2, 1, 2023);
             Day endDay = new Day(2, 1, 2023);
             
             // Test createCopy
             TimeSeries result = timeSeries.createCopy(startDay, endDay);
             assertEquals(1, result.getItemCount());
             assertEquals(20.0, result.getValue(0).doubleValue(), 0.001);
         }

    @Test
         public void testCreateCopy_StartNotInData_EndNotInData_ButRangeContainsData() throws CloneNotSupportedException {
             // Create test TimeSeries with some data
             TimeSeries timeSeries = new TimeSeries("Test Series");
             timeSeries.add(new Day(2, 1, 2023), 100.0);
             timeSeries.add(new Day(2, 1, 2023), 200.0);
             timeSeries.add(new Day(2, 1, 2023), 300.0);
             
             // Create test days (using correct Day constructor)
             Day startDay = new Day(1, 1, 2023); // Start not in data
             Day endDay = new Day(3, 1, 2023);   // End not in data
             
             TimeSeries result = timeSeries.createCopy(startDay, endDay);
             assertEquals(3, result.getItemCount());
         }

    @Test
         public void testCreateCopy_NullEndPeriod_ThrowsIllegalArgumentException() {
             TimeSeries timeSeries = new TimeSeries("Test Series");
             RegularTimePeriod start = mock(RegularTimePeriod.class);
             
             try {
                 try {
                     timeSeries.createCopy(start, null);
                     fail("Expected IllegalArgumentException to be thrown");
                 } catch (CloneNotSupportedException e) {
                     // This shouldn't happen in this test case
                     fail("Unexpected CloneNotSupportedException");
                 }
             } catch (IllegalArgumentException e) {
                 assertEquals("Null 'end' argument.", e.getMessage());
             }
         }

    @Test
         public void testCreateCopy_StartAfterEnd_ThrowsIllegalArgumentException() throws CloneNotSupportedException {
             TimeSeries timeSeries = new TimeSeries("Test Series");
             Day startDay = new Day(5, 1, 2023);
             Day endDay = new Day(1, 1, 2023);
             
             try {
                 timeSeries.createCopy(startDay, endDay);
                 fail("Expected IllegalArgumentException to be thrown");
             } catch (IllegalArgumentException e) {
                 assertEquals("Requires start on or before end.", e.getMessage());
             }
         }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateCopy_EndNegativeButGreaterThanStart_ShouldThrow() throws CloneNotSupportedException {
        // Setup
        TimeSeries series = new TimeSeries("Test Series");
        // Add some data to make sure the method tries to process it
        series.add(new TimeSeriesDataItem(new Day(), 1.0));
        series.add(new TimeSeriesDataItem(new Day(), 2.0));
        
        // This should throw because end (-1) is negative, even though it's > start (-2)
        // The mutant won't throw because it requires both conditions (end<0 AND end<start)
        series.createCopy(-2, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateCopy_EndPositiveButLessThanStart_ShouldThrow() throws CloneNotSupportedException {
        // Setup
        TimeSeries series = new TimeSeries("Test Series");
        // Add some data to make sure the method tries to process it
        series.add(new TimeSeriesDataItem(new Day(), 1.0));
        series.add(new TimeSeriesDataItem(new Day(), 2.0));
        
        // This should throw because end (1) is less than start (2)
        // The mutant won't throw because end is not negative
        series.createCopy(2, 1);
    }

    @Test
    public void testCreateCopy_EndNegativeAndLessThanStart_ShouldThrow() {
        // Setup
        TimeSeries series = new TimeSeries("Test Series");
        // Add some data to make sure the method tries to process it
        series.add(new TimeSeriesDataItem(new Day(), 1.0));
        series.add(new TimeSeriesDataItem(new Day(), 2.0));
        
        try {
            // This should throw and the mutant will also throw
            // because both conditions are met (end<0 AND end<start)
            series.createCopy(0, -1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Expected exception
        } catch (CloneNotSupportedException e) {
            fail("Unexpected CloneNotSupportedException");
        }
    }

    @Test
    public void testCreateCopyDetectsEmptyRangeWithOrCondition() throws CloneNotSupportedException {
        // Setup test data
        TimeSeries series = new TimeSeries("Test Series");
        
        // Add some data to the series (assuming Day is a valid RegularTimePeriod)
        Day day1 = new Day(1, 1, 2000);
        Day day2 = new Day(2, 1, 2000);
        Day day3 = new Day(3, 1, 2000);
        series.add(day1, 100);
        series.add(day2, 200);
        series.add(day3, 300);
        
        // Case 1: endIndex < 0 (but startIndex valid)
        // Create a day before any data exists
        Day start1 = day1;
        Day end1 = new Day(31, 12, 1999); // before first data point
        
        // Case 2: endIndex < startIndex (but endIndex >= 0)
        Day start2 = day2;
        Day end2 = day1; // end before start
        
        // Test both cases - should both result in empty ranges
        
        // Test Case 1
        TimeSeries result1 = series.createCopy(start1, end1);
        assertEquals(0, result1.getItemCount()); // Should be empty
        
        // Test Case 2
        TimeSeries result2 = series.createCopy(start2, end2);
        assertEquals(0, result2.getItemCount()); // Should be empty
        
        // The mutant would fail one of these cases because it requires BOTH conditions
        // Original code passes both because either condition triggers empty range
    }


}
