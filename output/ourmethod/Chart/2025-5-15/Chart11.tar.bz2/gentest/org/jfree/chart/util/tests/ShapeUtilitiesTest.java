package gentest.org.jfree.chart.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.util.*;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
 
public class ShapeUtilitiesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                           public void testEqual_Line2DShapes() {
                                                                                                                                                               Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                               Line2D line2 = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                               Line2D line3 = new Line2D.Double(1, 2, 3, 5);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line1, line3));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Ellipse2DShapes() {
                                                                                                                                                               Ellipse2D ellipse1 = new Ellipse2D.Double(1, 2, 3, 4);
                                                                                                                                                               Ellipse2D ellipse2 = new Ellipse2D.Double(1, 2, 3, 4);
                                                                                                                                                               Ellipse2D ellipse3 = new Ellipse2D.Double(1, 2, 3, 5);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(ellipse1, ellipse2));
                                                                                                                                                               assertFalse(ShapeUtilities.equal(ellipse1, ellipse3));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2DShapes() {
                                                                                                                                                               Arc2D arc1 = new Arc2D.Double(1, 2, 3, 4, 5, 6, Arc2D.PIE);
                                                                                                                                                               Arc2D arc2 = new Arc2D.Double(1, 2, 3, 4, 5, 6, Arc2D.PIE);
                                                                                                                                                               Arc2D arc3 = new Arc2D.Double(1, 2, 3, 4, 5, 7, Arc2D.PIE);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                               assertFalse(ShapeUtilities.equal(arc1, arc3));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_PolygonShapes() {
                                                                                                                                                               Polygon poly1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               Polygon poly2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               Polygon poly3 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 7}, 3);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(poly1, poly2));
                                                                                                                                                               assertFalse(ShapeUtilities.equal(poly1, poly3));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_GeneralPathShapes() {
                                                                                                                                                               GeneralPath path1 = new GeneralPath();
                                                                                                                                                               path1.moveTo(1, 2);
                                                                                                                                                               path1.lineTo(3, 4);
                                                                                                                                                               
                                                                                                                                                               GeneralPath path2 = new GeneralPath();
                                                                                                                                                               path2.moveTo(1, 2);
                                                                                                                                                               path2.lineTo(3, 4);
                                                                                                                                                               
                                                                                                                                                               GeneralPath path3 = new GeneralPath();
                                                                                                                                                               path3.moveTo(1, 2);
                                                                                                                                                               path3.lineTo(3, 5);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(path1, path2));
                                                                                                                                                               assertFalse(ShapeUtilities.equal(path1, path3));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Rectangle2DShapes() {
                                                                                                                                                               Rectangle2D rect1 = new Rectangle2D.Double(1, 2, 3, 4);
                                                                                                                                                               Rectangle2D rect2 = new Rectangle2D.Double(1, 2, 3, 4);
                                                                                                                                                               Rectangle2D rect3 = new Rectangle2D.Double(1, 2, 3, 5);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(rect1, rect2));
                                                                                                                                                               assertFalse(ShapeUtilities.equal(rect1, rect3));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_DifferentShapeTypes() {
                                                                                                                                                               Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                               Ellipse2D ellipse = new Ellipse2D.Double(1, 2, 3, 4);
                                                                                                                                                               
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line, ellipse));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_UnsupportedShapeType() {
                                                                                                                                                               Shape unsupportedShape = mock(Shape.class);
                                                                                                                                                               Shape unsupportedShape2 = mock(Shape.class);
                                                                                                                                                               
                                                                                                                                                               // Mock ObjectUtilities.equal to return true for this test
                                                                                                                                                               when(ObjectUtilities.equal(unsupportedShape, unsupportedShape2)).thenReturn(true);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(unsupportedShape, unsupportedShape2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_OneSupportedOneUnsupported() {
                                                                                                                                                               Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                               Shape unsupportedShape = mock(Shape.class);
                                                                                                                                                               
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line, unsupportedShape));
                                                                                                                                                               assertFalse(ShapeUtilities.equal(unsupportedShape, line));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_FirstLineNullSecondNotNull() {
                                                                                                                                                               Line2D line = mock(Line2D.class);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(null, line));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_FirstLineNotNullSecondNull() {
                                                                                                                                                               Line2D line = mock(Line2D.class);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line, null));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_LinesWithSamePoints() {
                                                                                                                                                               Line2D line1 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                                                                               Line2D line2 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                                                                               assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_LinesWithDifferentP() {
                                                                                                                                                               Line2D line1 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                                                                               Line2D line2 = new Line2D.Double(5.0, 6.0, 3.0, 4.0);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_LinesWithDifferentP1() {
                                                                                                                                                               Line2D line1 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                                                                               Line2D line2 = new Line2D.Double(1.0, 2.0, 5.0, 6.0);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_LinesWithBothPointsDifferent() {
                                                                                                                                                               Line2D line1 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                                                                               Line2D line2 = new Line2D.Double(5.0, 6.0, 7.0, 8.0);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_LinesWithSamePointsReversed() {
                                                                                                                                                               Line2D line1 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                                                                               Line2D line2 = new Line2D.Double(3.0, 4.0, 1.0, 2.0);
                                                                                                                                                               // Depending on requirements, this might be considered equal or not
                                                                                                                                                               // Current implementation would return false
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_WithMockedLines() {
                                                                                                                                                               Line2D line1 = mock(Line2D.class);
                                                                                                                                                               Line2D line2 = mock(Line2D.class);
                                                                                                                                                               Point2D p1 = new Point2D.Double(1.0, 2.0);
                                                                                                                                                               Point2D p2 = new Point2D.Double(3.0, 4.0);
                                                                                                                                                               
                                                                                                                                                               when(line1.getP1()).thenReturn(p1);
                                                                                                                                                               when(line1.getP2()).thenReturn(p2);
                                                                                                                                                               when(line2.getP1()).thenReturn(p1);
                                                                                                                                                               when(line2.getP2()).thenReturn(p2);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_WithMockedLinesDifferentPoints() {
                                                                                                                                                               Line2D line1 = mock(Line2D.class);
                                                                                                                                                               Line2D line2 = mock(Line2D.class);
                                                                                                                                                               Point2D p1 = new Point2D.Double(1.0, 2.0);
                                                                                                                                                               Point2D p2 = new Point2D.Double(3.0, 4.0);
                                                                                                                                                               Point2D p3 = new Point2D.Double(5.0, 6.0);
                                                                                                                                                               
                                                                                                                                                               when(line1.getP1()).thenReturn(p1);
                                                                                                                                                               when(line1.getP2()).thenReturn(p2);
                                                                                                                                                               when(line2.getP1()).thenReturn(p1);
                                                                                                                                                               when(line2.getP2()).thenReturn(p3);
                                                                                                                                                               
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_FirstNullSecondNotNull() {
                                                                                                                                                               Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(null, e2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_FirstNotNullSecondNull() {
                                                                                                                                                               Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(e1, null));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_BothHaveNullFrames() {
                                                                                                                                                               Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                               Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                               when(e1.getFrame()).thenReturn(null);
                                                                                                                                                               when(e2.getFrame()).thenReturn(null);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_BothNull() {
                                                                                                                                                               assertTrue(ShapeUtilities.equal((Arc2D)null, null));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_FirstNullSecondNotNull() {
                                                                                                                                                               Arc2D arc = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(null, arc));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_FirstNotNullSecondNull() {
                                                                                                                                                               Arc2D arc = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(arc, null));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_SameObject() {
                                                                                                                                                               Arc2D arc = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               assertTrue(ShapeUtilities.equal(arc, arc));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_EqualObjects() {
                                                                                                                                                               Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               Arc2D arc2 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_DifferentFrame() {
                                                                                                                                                               Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               Arc2D arc2 = new Arc2D.Double(1, 1, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_DifferentAngleStart() {
                                                                                                                                                               Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               Arc2D arc2 = new Arc2D.Double(0, 0, 10, 10, 1, 90, Arc2D.PIE);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_DifferentAngleExtent() {
                                                                                                                                                               Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               Arc2D arc2 = new Arc2D.Double(0, 0, 10, 10, 0, 91, Arc2D.PIE);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_DifferentArcType() {
                                                                                                                                                               Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               Arc2D arc2 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.CHORD);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_AllDifferentProperties() {
                                                                                                                                                               Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.PIE);
                                                                                                                                                               Arc2D arc2 = new Arc2D.Double(1, 1, 20, 20, 10, 180, Arc2D.CHORD);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_Arc2D_WithDifferentPrecision() {
                                                                                                                                                               // Tests that floating point precision doesn't affect equality
                                                                                                                                                               Arc2D arc1 = new Arc2D.Double(0.0, 0.0, 10.0, 10.0, 0.0, 90.0, Arc2D.PIE);
                                                                                                                                                               Arc2D arc2 = new Arc2D.Double(0.0000001, 0.0000001, 10.0000001, 10.0000001, 
                                                                                                                                                                                             0.0000001, 90.0000001, Arc2D.PIE);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_FirstNullSecondNotNull1() {
                                                                                                                                                               Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(null, p2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_FirstNotNullSecondNull1() {
                                                                                                                                                               Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(p1, null));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_DifferentNumberOfPoints() {
                                                                                                                                                               Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               Polygon p2 = new Polygon(new int[]{1, 2}, new int[]{4, 5}, 2);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_SameNumberOfPointsDifferentXPoints() {
                                                                                                                                                               Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               Polygon p2 = new Polygon(new int[]{1, 2, 4}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_SameNumberOfPointsDifferentYPoints() {
                                                                                                                                                               Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 7}, 3);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_IdenticalPolygons() {
                                                                                                                                                               Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_EmptyPolygons() {
                                                                                                                                                               Polygon p1 = new Polygon(new int[]{}, new int[]{}, 0);
                                                                                                                                                               Polygon p2 = new Polygon(new int[]{}, new int[]{}, 0);
                                                                                                                                                               assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_SamePointsDifferentOrder() {
                                                                                                                                                               Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                               Polygon p2 = new Polygon(new int[]{3, 2, 1}, new int[]{6, 5, 4}, 3);
                                                                                                                                                               // Note: This test expects false because the points are in different order
                                                                                                                                                               // even though they represent the same geometric shape
                                                                                                                                                               assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_LargePolygons() {
                                                                                                                                                               int size = 1000;
                                                                                                                                                               int[] xpoints = new int[size];
                                                                                                                                                               int[] ypoints = new int[size];
                                                                                                                                                               for (int i = 0; i < size; i++) {
                                                                                                                                                                   xpoints[i] = i;
                                                                                                                                                                   ypoints[i] = i * 2;
                                                                                                                                                               }
                                                                                                                                                               Polygon p1 = new Polygon(xpoints, ypoints, size);
                                                                                                                                                               Polygon p2 = new Polygon(xpoints, ypoints, size);
                                                                                                                                                               assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_FirstNullSecondNotNull2() {
                                                                                                                                                               Shape nonNullShape = mock(Shape.class);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(null, nonNullShape));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_FirstNotNullSecondNull2() {
                                                                                                                                                               Shape nonNullShape = mock(Shape.class);
                                                                                                                                                               assertFalse(ShapeUtilities.equal(nonNullShape, null));
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testEqual_RealShapes() {
                                                                                                                                                               // Test with actual Shape implementations
                                                                                                                                                               Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                               Line2D line2 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                               Line2D line3 = new Line2D.Double(0, 0, 20, 20);
                                                                                                                                                               
                                                                                                                                                               assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                               assertFalse(ShapeUtilities.equal(line1, line3));
                                                                                                                                                           }

    @Test
                                                                                                                                                   public void testEqual_NullInputs() {
                                                                                                                                                       Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                       
                                                                                                                                                       assertTrue(ShapeUtilities.equal((Shape)null, (Shape)null));
                                                                                                                                                       assertFalse(ShapeUtilities.equal(line, (Shape)null));
                                                                                                                                                       assertFalse(ShapeUtilities.equal((Shape)null, line));
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testEqual_BothLinesNull() {
                                                                                                                                                       assertTrue(ShapeUtilities.equal((Line2D) null, (Line2D) null));
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testEqual_BothNull() {
                                                                                                                                                       assertTrue(ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testEqual_DifferentFrames() {
                                                                                                                                                       Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                       Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                       when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                       when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 20, 20));
                                                                                                                                                       
                                                                                                                                                       assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testEqual_SameObject() {
                                                                                                                                                       Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                       when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                       
                                                                                                                                                       assertTrue(ShapeUtilities.equal(e1, e1));
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testEqual_FirstHasNullFrame() {
                                                                                                                                                       Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                       Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                       when(e1.getFrame()).thenReturn(null);
                                                                                                                                                       when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                       
                                                                                                                                                       assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testEqual_SecondHasNullFrame() {
                                                                                                                                                       Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                       Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                       Rectangle2D frame = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                                                                                       when(e1.getFrame()).thenReturn(frame);
                                                                                                                                                       when(e2.getFrame()).thenReturn(null);
                                                                                                                                                       
                                                                                                                                                       assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testEqual_BothNull1() {
                                                                                                                                                       Polygon p1 = null;
                                                                                                                                                       Polygon p2 = null;
                                                                                                                                                       assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testEqual_BothNull2() {
                                                                                                                                                       assertTrue(ShapeUtilities.equal((Shape) null, (Shape) null));
                                                                                                                                                   }

    @Test
                                                                                                                                               public void testEqual_SameFrames() {
                                                                                                                                                   Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                   Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                   Rectangle2D sameFrame = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                                                                                   when(e1.getFrame()).thenReturn(sameFrame);
                                                                                                                                                   when(e2.getFrame()).thenReturn(sameFrame);
                                                                                                                                                   
                                                                                                                                                   assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                                               }

    @Test
                                                                                                                                   public void testEqual_EmptyPaths() {
                                                                                                                                       Shape shape1 = mock(Shape.class);
                                                                                                                                       Shape shape2 = mock(Shape.class);
                                                                                                                                       PathIterator iterator1 = mock(PathIterator.class);
                                                                                                                                       PathIterator iterator2 = mock(PathIterator.class);
                                                                                                                                       
                                                                                                                                       when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                                       when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                                       
                                                                                                                                       // Both paths are empty (done immediately)
                                                                                                                                       when(iterator1.isDone()).thenReturn(true);
                                                                                                                                       when(iterator2.isDone()).thenReturn(true);
                                                                                                                                       
                                                                                                                                       assertTrue(ShapeUtilities.equal(shape1, shape2));
                                                                                                                                   }

    @Test
                                                                                                                               public void testEqual_SamePathsDifferentCoordinates() {
                                                                                                                                   // Create mock objects
                                                                                                                                   Shape shape1 = mock(Shape.class);
                                                                                                                                   Shape shape2 = mock(Shape.class);
                                                                                                                                   PathIterator iterator1 = mock(PathIterator.class);
                                                                                                                                   PathIterator iterator2 = mock(PathIterator.class);
                                                                                                                                   
                                                                                                                                   // Set up mock behavior
                                                                                                                                   when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                                   when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                                   when(iterator1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                                                   when(iterator2.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                                                   
                                                                                                                                   // Same segment types but different coordinates
                                                                                                                                   when(iterator1.isDone())
                                                                                                                                       .thenReturn(false)
                                                                                                                                       .thenReturn(true);
                                                                                                                                   when(iterator2.isDone())
                                                                                                                                       .thenReturn(false)
                                                                                                                                       .thenReturn(true);
                                                                                                                                   when(iterator1.currentSegment(any(double[].class)))
                                                                                                                                       .thenAnswer(invocation -> {
                                                                                                                                           double[] coords = invocation.getArgument(0);
                                                                                                                                           Arrays.fill(coords, 1.0);
                                                                                                                                           return PathIterator.SEG_MOVETO;
                                                                                                                                       });
                                                                                                                                   when(iterator2.currentSegment(any(double[].class)))
                                                                                                                                       .thenAnswer(invocation -> {
                                                                                                                                           double[] coords = invocation.getArgument(0);
                                                                                                                                           Arrays.fill(coords, 2.0);
                                                                                                                                           return PathIterator.SEG_MOVETO;
                                                                                                                                       });
                                                                                                                                   
                                                                                                                                   // Verify the shapes are not considered equal
                                                                                                                                   assertFalse(ShapeUtilities.equal(shape1, shape2));
                                                                                                                               }

    @Test
                                                                                                                           public void testEqual_DifferentPathLengths() {
                                                                                                                               // Create mock objects
                                                                                                                               java.awt.Shape shape1 = mock(java.awt.Shape.class);
                                                                                                                               java.awt.Shape shape2 = mock(java.awt.Shape.class);
                                                                                                                               java.awt.geom.PathIterator iterator1 = mock(java.awt.geom.PathIterator.class);
                                                                                                                               java.awt.geom.PathIterator iterator2 = mock(java.awt.geom.PathIterator.class);
                                                                                                                               
                                                                                                                               // Setup mock behavior
                                                                                                                               when(iterator1.getWindingRule()).thenReturn(java.awt.geom.PathIterator.WIND_NON_ZERO);
                                                                                                                               when(iterator2.getWindingRule()).thenReturn(java.awt.geom.PathIterator.WIND_NON_ZERO);
                                                                                                                               when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                               when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                               
                                                                                                                               // First shape has more segments
                                                                                                                               when(iterator1.isDone())
                                                                                                                                   .thenReturn(false)
                                                                                                                                   .thenReturn(false)
                                                                                                                                   .thenReturn(true);
                                                                                                                               when(iterator2.isDone())
                                                                                                                                   .thenReturn(false)
                                                                                                                                   .thenReturn(true);
                                                                                                                               when(iterator1.currentSegment(any(double[].class)))
                                                                                                                                   .thenReturn(java.awt.geom.PathIterator.SEG_MOVETO);
                                                                                                                               when(iterator2.currentSegment(any(double[].class)))
                                                                                                                                   .thenReturn(java.awt.geom.PathIterator.SEG_MOVETO);
                                                                                                                               
                                                                                                                               // Verify the result
                                                                                                                               assertFalse(ShapeUtilities.equal(shape1, shape2));
                                                                                                                           }

    @Test
                                                                                                                       public void testEqual_SameWindingRulesSamePaths() {
                                                                                                                           // Create mock objects
                                                                                                                           java.awt.Shape shape1 = mock(java.awt.Shape.class);
                                                                                                                           java.awt.Shape shape2 = mock(java.awt.Shape.class);
                                                                                                                           java.awt.geom.PathIterator iterator1 = mock(java.awt.geom.PathIterator.class);
                                                                                                                           java.awt.geom.PathIterator iterator2 = mock(java.awt.geom.PathIterator.class);
                                                                                                                           
                                                                                                                           // Set up winding rules
                                                                                                                           when(shape1.getPathIterator(null).getWindingRule())
                                                                                                                               .thenReturn(java.awt.geom.PathIterator.WIND_NON_ZERO);
                                                                                                                           when(shape2.getPathIterator(null).getWindingRule())
                                                                                                                               .thenReturn(java.awt.geom.PathIterator.WIND_NON_ZERO);
                                                                                                                           
                                                                                                                           // Set up path iterators
                                                                                                                           when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                           when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                           
                                                                                                                           // Mock iterator behavior - same segments
                                                                                                                           when(iterator1.isDone()).thenReturn(false).thenReturn(true);
                                                                                                                           when(iterator2.isDone()).thenReturn(false).thenReturn(true);
                                                                                                                           when(iterator1.currentSegment(any(double[].class)))
                                                                                                                               .thenAnswer(invocation -> {
                                                                                                                                   double[] coords = invocation.getArgument(0);
                                                                                                                                   java.util.Arrays.fill(coords, 1.0);
                                                                                                                                   return java.awt.geom.PathIterator.SEG_MOVETO;
                                                                                                                               });
                                                                                                                           when(iterator2.currentSegment(any(double[].class)))
                                                                                                                               .thenAnswer(invocation -> {
                                                                                                                                   double[] coords = invocation.getArgument(0);
                                                                                                                                   java.util.Arrays.fill(coords, 1.0);
                                                                                                                                   return java.awt.geom.PathIterator.SEG_MOVETO;
                                                                                                                               });
                                                                                                                           
                                                                                                                           // Assert equality
                                                                                                                           assertTrue(org.jfree.chart.util.ShapeUtilities.equal(shape1, shape2));
                                                                                                                       }

    @Test
                                                                                                           public void testEqual_DifferentWindingRules() {
                                                                                                               // Create mock Shape objects
                                                                                                               Shape shape1 = mock(Shape.class);
                                                                                                               Shape shape2 = mock(Shape.class);
                                                                                                               
                                                                                                               // Set up mock behavior for path iterators
                                                                                                               PathIterator iterator1 = mock(PathIterator.class);
                                                                                                               PathIterator iterator2 = mock(PathIterator.class);
                                                                                                               
                                                                                                               // Set up mock behavior for winding rules
                                                                                                               when(iterator1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                               when(iterator2.getWindingRule()).thenReturn(PathIterator.WIND_EVEN_ODD);
                                                                                                               
                                                                                                               // Set up mock behavior for path iterators
                                                                                                               when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                               when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                               when(iterator1.isDone()).thenReturn(true);
                                                                                                               when(iterator2.isDone()).thenReturn(true);
                                                                                                               
                                                                                                               // Test that shapes with different winding rules are not equal
                                                                                                               assertFalse(ShapeUtilities.equal(shape1, shape2));
                                                                                                           }

    @Test
                                                                                                           public void testEqual_SameWindingRulesDifferentPaths() {
                                                                                                               // Create mock GeneralPath objects
                                                                                                               GeneralPath shape1 = new GeneralPath();
                                                                                                               shape1.moveTo(0, 0);
                                                                                                               shape1.lineTo(10, 10);
                                                                                                               
                                                                                                               GeneralPath shape2 = new GeneralPath();
                                                                                                               shape2.moveTo(0, 0);
                                                                                                               shape2.lineTo(20, 20);  // Different path
                                                                                                               
                                                                                                               // Set same winding rule for both shapes
                                                                                                               shape1.setWindingRule(GeneralPath.WIND_EVEN_ODD);
                                                                                                               shape2.setWindingRule(GeneralPath.WIND_EVEN_ODD);
                                                                                                               
                                                                                                               assertFalse(org.jfree.chart.util.ShapeUtilities.equal(shape1, shape2));
                                                                                                           }

    @Test
                                                                                                           public void testEqual_Rectangle2D_DifferentReferencesSameValues() {
                                                                                                               // Create two distinct Rectangle2D objects with same values
                                                                                                               Rectangle2D rect1 = new Rectangle2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                               Rectangle2D rect2 = new Rectangle2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                               
                                                                                                               // Verify they are different references
                                                                                                               assertNotSame(rect1, rect2);
                                                                                                               
                                                                                                               // Test the equality comparison
                                                                                                               boolean result = ShapeUtilities.equal(rect1, rect2);
                                                                                                               
                                                                                                               // Original would return true (deep equality), mutant would return false (reference equality)
                                                                                                               assertTrue("Should return true for logically equal Rectangle2D objects", result);
                                                                                                           }

    @Test
                                                                                                           public void testEqual_Rectangle2D_DifferentReferencesDifferentValues() {
                                                                                                               // Create two distinct Rectangle2D objects with different values
                                                                                                               Rectangle2D rect1 = new Rectangle2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                               Rectangle2D rect2 = new Rectangle2D.Double(5.0, 6.0, 7.0, 8.0);
                                                                                                               
                                                                                                               // Test the equality comparison
                                                                                                               boolean result = ShapeUtilities.equal(rect1, rect2);
                                                                                                               
                                                                                                               // Both original and mutant should return false
                                                                                                               assertFalse("Should return false for different Rectangle2D objects", result);
                                                                                                           }

    @Test
                                                                                                           public void testEqual_Rectangle2D_SameReference() {
                                                                                                               // Create one Rectangle2D object
                                                                                                               Rectangle2D rect1 = new Rectangle2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                                                               
                                                                                                               // Test the equality comparison with itself
                                                                                                               boolean result = ShapeUtilities.equal(rect1, rect1);
                                                                                                               
                                                                                                               // Both original and mutant should return true
                                                                                                               assertTrue("Should return true for same reference", result);
                                                                                                           }

    @Test
                                                                                                           public void testEqual_Line2D_ShouldReturnFalseWhenL2IsNull() {
                                                                                                               // Create a mock Line2D where p1 equals p2
                                                                                                               Line2D l1 = mock(Line2D.class);
                                                                                                               Point2D p1 = new Point2D.Double(1.0, 2.0);
                                                                                                               Point2D p2 = new Point2D.Double(1.0, 2.0); // same as p1
                                                                                                               
                                                                                                               when(l1.getP1()).thenReturn(p1);
                                                                                                               when(l1.getP2()).thenReturn(p2);
                                                                                                               
                                                                                                               // l2 is null
                                                                                                               Line2D l2 = null;
                                                                                                               
                                                                                                               // Original should return false, mutant would return true (p1 == p2)
                                                                                                               assertFalse("Should return false when l2 is null but l1 isn't", 
                                                                                                                          ShapeUtilities.equal(l1, l2));
                                                                                                           }

    @Test
                                                                                                       public void testEqual_Ellipse2D_SecondNull() {
                                                                                                           // Create a non-null Ellipse2D for e1
                                                                                                           Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                           
                                                                                                           // e2 is null
                                                                                                           Ellipse2D e2 = null;
                                                                                                           
                                                                                                           // The original method should return false when e2 is null and e1 isn't
                                                                                                           assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                           
                                                                                                           // The mutant would return (p1 == p2) which could be true or false depending on references,
                                                                                                           // but we want to ensure it returns false in this case
                                                                                                       }

    @Test
                                                                                                           public void testEqual_Arc2D_WhenA1NotNullAndA2Null_ShouldReturnFalse() {
                                                                                                               // Create a mock Arc2D object for a1
                                                                                                               Arc2D a1 = mock(Arc2D.class);
                                                                                                               when(a1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double());
                                                                                                               when(a1.getAngleStart()).thenReturn(0.0);
                                                                                                               when(a1.getAngleExtent()).thenReturn(90.0);
                                                                                                               when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                               
                                                                                                               Arc2D a2 = null;
                                                                                                               
                                                                                                               // The original method would return false because a2 is null
                                                                                                               // The mutant would return a1 == a2 (which is also false, but for wrong reason)
                                                                                                               // To catch this, we need to verify the behavior is specifically checking null
                                                                                                               
                                                                                                               // This test will pass for both original and mutant, so we need a more sophisticated test
                                                                                                               // Let's verify the behavior through interaction testing
                                                                                                               boolean result = ShapeUtilities.equal(a1, a2);
                                                                                                               assertFalse(result);
                                                                                                               
                                                                                                               // Additional verification that we didn't check any properties when a2 is null
                                                                                                               verify(a1, never()).getFrame();
                                                                                                               verify(a1, never()).getAngleStart();
                                                                                                               verify(a1, never()).getAngleExtent();
                                                                                                               verify(a1, never()).getArcType();
                                                                                                           }

    @Test
                                                                                                           public void testEqual_Arc2D_WhenBothNull_ShouldReturnTrue() {
                                                                                                               Arc2D a1 = null;
                                                                                                               Arc2D a2 = null;
                                                                                                               assertTrue(ShapeUtilities.equal(a1, a2));
                                                                                                           }

    @Test
                                                                                                           public void testEqual_Arc2D_WhenA1NullAndA2NotNull_ShouldReturnFalse() {
                                                                                                               Arc2D a1 = null;
                                                                                                               Arc2D a2 = mock(Arc2D.class);
                                                                                                               assertFalse(ShapeUtilities.equal(a1, a2));
                                                                                                           }

    @Test
                                                                                                           public void testEqual_Arc2D_WhenBothNotNullAndEqual_ShouldReturnTrue() {
                                                                                                               Arc2D a1 = mock(Arc2D.class);
                                                                                                               Arc2D a2 = mock(Arc2D.class);
                                                                                                               
                                                                                                               Rectangle2D frame = new java.awt.geom.Rectangle2D.Double(0, 0, 100, 100);
                                                                                                               when(a1.getFrame()).thenReturn(frame);
                                                                                                               when(a2.getFrame()).thenReturn(frame);
                                                                                                               when(a1.getAngleStart()).thenReturn(0.0);
                                                                                                               when(a2.getAngleStart()).thenReturn(0.0);
                                                                                                               when(a1.getAngleExtent()).thenReturn(90.0);
                                                                                                               when(a2.getAngleExtent()).thenReturn(90.0);
                                                                                                               when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                               when(a2.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                               
                                                                                                               assertTrue(ShapeUtilities.equal(a1, a2));
                                                                                                           }

    @Test
                                                                                                       public void testEqual_WhenFirstNonNullAndSecondNull_ShouldReturnFalse() {
                                                                                                           // Arrange
                                                                                                           Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                           Polygon p2 = null;
                                                                                                           
                                                                                                           // Act
                                                                                                           boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                           
                                                                                                           // Assert
                                                                                                           assertFalse("Should return false when first polygon is non-null and second is null", result);
                                                                                                           
                                                                                                           // This test would catch the mutant because:
                                                                                                           // Original code: returns false (correct)
                                                                                                           // Mutant code: returns p1 == p2 (which happens to be false in this case)
                                                                                                           // However, the mutant changes the semantic meaning of the check
                                                                                                           // The test ensures we're testing for null specifically, not reference equality
                                                                                                       }

    @Test
                                                                                                       public void testEqual_WhenFirstShapeNotNullAndSecondNull_ShouldReturnFalse() {
                                                                                                           // Create a mock Shape object for p1
                                                                                                           Shape p1 = mock(Shape.class);
                                                                                                           // p2 is explicitly null
                                                                                                           
                                                                                                           // The original method should return false when p1 is not null and p2 is null
                                                                                                           boolean result = ShapeUtilities.equal(p1, null);
                                                                                                           
                                                                                                           // Assert that the result is false (original behavior)
                                                                                                           assertFalse("Should return false when first shape is not null and second is null", result);
                                                                                                           
                                                                                                           // This test will catch the mutant because:
                                                                                                           // Original: returns false (correct)
                                                                                                           // Mutant: returns p1 == null (which is false, but for wrong reason)
                                                                                                           // The test ensures we're testing the specific null check logic
                                                                                                       }

    @Test(timeout = 1000) // Add timeout to detect infinite loops
                                                                                                          public void testEqualGeneralPath() {
                                                                                                              // Create two identical GeneralPath objects
                                                                                                              GeneralPath path1 = new GeneralPath();
                                                                                                              path1.moveTo(1, 1);
                                                                                                              path1.lineTo(2, 2);
                                                                                                              
                                                                                                              GeneralPath path2 = new GeneralPath();
                                                                                                              path2.moveTo(1, 1);
                                                                                                              path2.lineTo(2, 2);
                                                                                                              
                                                                                                              // Should return true for identical paths
                                                                                                              assertTrue(ShapeUtilities.equal(path1, path2));
                                                                                                              
                                                                                                              // Create a different GeneralPath
                                                                                                              GeneralPath path3 = new GeneralPath();
                                                                                                              path3.moveTo(1, 1);
                                                                                                              path3.lineTo(3, 3); // Different endpoint
                                                                                                              
                                                                                                              // Should return false for different paths
                                                                                                              assertFalse(ShapeUtilities.equal(path1, path3));
                                                                                                              
                                                                                                              // Test with empty paths
                                                                                                              GeneralPath empty1 = new GeneralPath();
                                                                                                              GeneralPath empty2 = new GeneralPath();
                                                                                                              assertTrue(ShapeUtilities.equal(empty1, empty2));
                                                                                                          }

    @Test
                                                                                                          public void testEqualEllipse2D_FrameEquality() {
                                                                                                              // Create two ellipses with same frame
                                                                                                              Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                              Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                              assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                              
                                                                                                              // Create two ellipses with different frames
                                                                                                              Ellipse2D e3 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                              Ellipse2D e4 = new Ellipse2D.Double(0, 0, 20, 20);
                                                                                                              assertFalse(ShapeUtilities.equal(e3, e4));
                                                                                                          }

    @Test
                                                                                                          public void testEqualEllipse2D_WithMockedObjects() {
                                                                                                              // Mock two ellipses with same frame
                                                                                                              Ellipse2D mockE1 = mock(Ellipse2D.class);
                                                                                                              Ellipse2D mockE2 = mock(Ellipse2D.class);
                                                                                                              when(mockE1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0,0,10,10));
                                                                                                              when(mockE2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0,0,10,10));
                                                                                                              assertTrue(ShapeUtilities.equal(mockE1, mockE2));
                                                                                                              
                                                                                                              // Mock two ellipses with different frames
                                                                                                              Ellipse2D mockE3 = mock(Ellipse2D.class);
                                                                                                              Ellipse2D mockE4 = mock(Ellipse2D.class);
                                                                                                              when(mockE3.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0,0,10,10));
                                                                                                              when(mockE4.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0,0,20,20));
                                                                                                              assertFalse(ShapeUtilities.equal(mockE3, mockE4));
                                                                                                          }

    @Test
                                                                                                          public void testEqualPolygon_FirstNull() {
                                                                                                              Polygon p2 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                                                                                                              assertFalse(ShapeUtilities.equal(null, p2));
                                                                                                          }

    @Test
                                                                                                          public void testEqualPolygon_SecondNull() {
                                                                                                              Polygon p1 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                                                                                                              assertFalse(ShapeUtilities.equal(p1, null));
                                                                                                          }

    @Test
                                                                                                          public void testEqualPolygon_DifferentPointCounts() {
                                                                                                              Polygon p1 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                                                                                                              Polygon p2 = new Polygon(new int[]{1,2,3}, new int[]{3,4,5}, 3);
                                                                                                              assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                          }

    @Test
                                                                                                          public void testEqualPolygon_DifferentXPoints() {
                                                                                                              Polygon p1 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                                                                                                              Polygon p2 = new Polygon(new int[]{1,3}, new int[]{3,4}, 2);
                                                                                                              assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                          }

    @Test
                                                                                                          public void testEqualPolygon_DifferentYPoints() {
                                                                                                              Polygon p1 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                                                                                                              Polygon p2 = new Polygon(new int[]{1,2}, new int[]{3,5}, 2);
                                                                                                              assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                          }

    @Test
                                                                                                          public void testEqualPolygon_EqualPolygons() {
                                                                                                              Polygon p1 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                                                                                                              Polygon p2 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                                                                                                              assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                          }

    @Test
                                                                                                          public void testEqualPolygon_EmptyPolygons() {
                                                                                                              Polygon p1 = new Polygon(new int[]{}, new int[]{}, 0);
                                                                                                              Polygon p2 = new Polygon(new int[]{}, new int[]{}, 0);
                                                                                                              assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                          }

    @Test
                                                                                                      public void testEqualWithEmptyShapes() {
                                                                                                          // Create two empty shapes (their iterators would be done immediately)
                                                                                                          Shape emptyShape1 = new GeneralPath();
                                                                                                          Shape emptyShape2 = new GeneralPath();
                                                                                                          
                                                                                                          // Original would return true since both are empty and equal
                                                                                                          // Mutant would enter the loop and potentially return false or throw exception
                                                                                                          assertTrue(ShapeUtilities.equal(emptyShape1, emptyShape2));
                                                                                                          
                                                                                                          // Also test with non-empty vs empty shape
                                                                                                          Shape nonEmptyShape = new GeneralPath();
                                                                                                          ((GeneralPath)nonEmptyShape).moveTo(1, 1);
                                                                                                          ((GeneralPath)nonEmptyShape).lineTo(2, 2);
                                                                                                          
                                                                                                          assertFalse(ShapeUtilities.equal(emptyShape1, nonEmptyShape));
                                                                                                          assertFalse(ShapeUtilities.equal(nonEmptyShape, emptyShape1));
                                                                                                      }

    @Test
                                                                                                     public void testEqualEllipse2D_NullCases() {
                                                                                                         // Both null
                                                                                                         assertTrue(ShapeUtilities.equal((Ellipse2D)null, (Ellipse2D)null));
                                                                                                         
                                                                                                         // First null, second not null
                                                                                                         assertFalse(ShapeUtilities.equal(null, new Ellipse2D.Double()));
                                                                                                         
                                                                                                         // First not null, second null
                                                                                                         assertFalse(ShapeUtilities.equal(new Ellipse2D.Double(), null));
                                                                                                     }

    @Test
                                                                                                     public void testEqualArc2D() {
                                                                                                         // Create two identical arcs
                                                                                                         Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                         Arc2D arc1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                                                                                         Arc2D arc2 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                                                                                         
                                                                                                         // Test equal arcs
                                                                                                         assertTrue(ShapeUtilities.equal((Arc2D) arc1, (Arc2D) arc2));
                                                                                                         
                                                                                                         // Test with null values
                                                                                                         assertTrue(ShapeUtilities.equal((Arc2D) null, (Arc2D) null));
                                                                                                         assertFalse(ShapeUtilities.equal((Arc2D) arc1, (Arc2D) null));
                                                                                                         assertFalse(ShapeUtilities.equal((Arc2D) null, (Arc2D) arc2));
                                                                                                         
                                                                                                         // Test with different frames
                                                                                                         Rectangle2D differentFrame = new Rectangle2D.Double(0, 0, 200, 200);
                                                                                                         Arc2D arc3 = new Arc2D.Double(differentFrame, 0, 90, Arc2D.PIE);
                                                                                                         assertFalse(ShapeUtilities.equal((Arc2D) arc1, (Arc2D) arc3));
                                                                                                         
                                                                                                         // Test with different angle starts
                                                                                                         Arc2D arc4 = new Arc2D.Double(frame, 45, 90, Arc2D.PIE);
                                                                                                         assertFalse(ShapeUtilities.equal((Arc2D) arc1, (Arc2D) arc4));
                                                                                                         
                                                                                                         // Test with different angle extents
                                                                                                         Arc2D arc5 = new Arc2D.Double(frame, 0, 180, Arc2D.PIE);
                                                                                                         assertFalse(ShapeUtilities.equal((Arc2D) arc1, (Arc2D) arc5));
                                                                                                         
                                                                                                         // Test with different arc types
                                                                                                         Arc2D arc6 = new Arc2D.Double(frame, 0, 90, Arc2D.CHORD);
                                                                                                         assertFalse(ShapeUtilities.equal((Arc2D) arc1, (Arc2D) arc6));
                                                                                                         
                                                                                                         // Test with all different properties
                                                                                                         Arc2D arc7 = new Arc2D.Double(differentFrame, 45, 180, Arc2D.CHORD);
                                                                                                         assertFalse(ShapeUtilities.equal((Arc2D) arc1, (Arc2D) arc7));
                                                                                                     }

    @Test
                                                                                                     public void testEqualPolygon_BothNull() {
                                                                                                         assertTrue(ShapeUtilities.equal((Polygon)null, (Polygon)null));
                                                                                                     }

    @Test
                                                                                                 public void testEqualLine2DWithMultipleSegments() {
                                                                                                     // Create two identical complex lines with multiple segments
                                                                                                     Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                     Line2D line2 = new Line2D.Double(0, 0, 10, 10);
                                                                                                     
                                                                                                     // Create two different complex lines
                                                                                                     Line2D line3 = new Line2D.Double(0, 0, 10, 10);
                                                                                                     Line2D line4 = new Line2D.Double(0, 0, 10, 20);
                                                                                                     
                                                                                                     // Test equal lines
                                                                                                     assertTrue("Identical lines should be equal", 
                                                                                                         ShapeUtilities.equal((Shape)line1, (Shape)line2));
                                                                                                         
                                                                                                     // Test unequal lines
                                                                                                     assertFalse("Different lines should not be equal", 
                                                                                                         ShapeUtilities.equal((Shape)line3, (Shape)line4));
                                                                                                         
                                                                                                     // Test with null cases
                                                                                                     assertTrue("Two null lines should be equal", 
                                                                                                         ShapeUtilities.equal((Shape)null, (Shape)null));
                                                                                                     assertFalse("Null and non-null lines should not be equal", 
                                                                                                         ShapeUtilities.equal(null, (Shape)line1));
                                                                                                     assertFalse("Non-null and null lines should not be equal", 
                                                                                                         ShapeUtilities.equal((Shape)line1, null));
                                                                                                         
                                                                                                     // Test with lines that have same start/end but different paths
                                                                                                     // This would fail if the iterator termination condition is mutated
                                                                                                     Line2D line5 = new Line2D.Double(0, 0, 10, 10) {
                                                                                                         @Override
                                                                                                         public PathIterator getPathIterator(AffineTransform at) {
                                                                                                             return new PathIterator() {
                                                                                                                 private int index = 0;
                                                                                                                 
                                                                                                                 public int getWindingRule() { return WIND_NON_ZERO; }
                                                                                                                 public boolean isDone() { return index > 1; }
                                                                                                                 public void next() { index++; }
                                                                                                                 
                                                                                                                 public int currentSegment(float[] coords) {
                                                                                                                     if (index == 0) {
                                                                                                                         coords[0] = 0; coords[1] = 0;
                                                                                                                         return SEG_MOVETO;
                                                                                                                     } else {
                                                                                                                         coords[0] = 10; coords[1] = 10;
                                                                                                                         return SEG_LINETO;
                                                                                                                     }
                                                                                                                 }
                                                                                                                 
                                                                                                                 public int currentSegment(double[] coords) {
                                                                                                                     if (index == 0) {
                                                                                                                         coords[0] = 0; coords[1] = 0;
                                                                                                                         return SEG_MOVETO;
                                                                                                                     } else {
                                                                                                                         coords[0] = 10; coords[1] = 10;
                                                                                                                         return SEG_LINETO;
                                                                                                                     }
                                                                                                                 }
                                                                                                             };
                                                                                                         }
                                                                                                     };
                                                                                                     
                                                                                                     Line2D line6 = new Line2D.Double(0, 0, 10, 10);
                                                                                                     assertTrue("Lines with same path should be equal", 
                                                                                                         ShapeUtilities.equal((Shape)line5, (Shape)line6));
                                                                                                 }

    @Test
                                                                                                 public void testEqualPolygonWithNullValues() {
                                                                                                     // Create a non-null polygon for testing
                                                                                                     Polygon nonNullPolygon = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                                                                     
                                                                                                     // Case 1: Both polygons are null - should return true (original) vs false (mutant)
                                                                                                     assertTrue("Two null polygons should be considered equal", 
                                                                                                         ShapeUtilities.equal((Polygon)null, (Polygon)null));
                                                                                                     
                                                                                                     // Case 2: First polygon is null, second is not - should return false
                                                                                                     assertFalse("Null and non-null polygons should not be equal", 
                                                                                                         ShapeUtilities.equal(null, nonNullPolygon));
                                                                                                         
                                                                                                     // Case 3: Second polygon is null, first is not - should return false (original) vs true (mutant)
                                                                                                     // This is the key test that will catch the mutant
                                                                                                     assertFalse("Non-null and null polygons should not be equal", 
                                                                                                         ShapeUtilities.equal(nonNullPolygon, null));
                                                                                                         
                                                                                                     // Case 4: Neither is null - delegate to actual comparison
                                                                                                     // (Assuming equal implementation compares polygon points)
                                                                                                     Polygon samePolygon = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                                                                     assertTrue("Identical polygons should be equal", 
                                                                                                         ShapeUtilities.equal(nonNullPolygon, samePolygon));
                                                                                                         
                                                                                                     Polygon differentPolygon = new Polygon(new int[]{7,8,9}, new int[]{10,11,12}, 3);
                                                                                                     assertFalse("Different polygons should not be equal", 
                                                                                                         ShapeUtilities.equal(nonNullPolygon, differentPolygon));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_FirstLineNullSecondNotNull1() {
                                                                                                     Line2D line = new Line2D.Double(0, 0, 1, 1);
                                                                                                     // This should return false in original, true in mutant
                                                                                                     assertFalse(ShapeUtilities.equal(null, line));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_SecondLineNullFirstNotNull() {
                                                                                                     Line2D line = new Line2D.Double(0, 0, 1, 1);
                                                                                                     // Both original and mutant should return false
                                                                                                     assertFalse(ShapeUtilities.equal(line, null));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_NonNullLinesEqual() {
                                                                                                     Line2D line1 = new Line2D.Double(0, 0, 1, 1);
                                                                                                     Line2D line2 = new Line2D.Double(0, 0, 1, 1);
                                                                                                     assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_NonNullLinesDifferent() {
                                                                                                     Line2D line1 = new Line2D.Double(0, 0, 1, 1);
                                                                                                     Line2D line2 = new Line2D.Double(0, 0, 2, 2);
                                                                                                     assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Ellipse2D_BothNull() {
                                                                                                     // Test case where both ellipses are null
                                                                                                     // Original should return true, mutant returns false
                                                                                                     assertTrue(ShapeUtilities.equal((Ellipse2D)null, (Ellipse2D)null));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Ellipse2D_FirstNullSecondNotNull() {
                                                                                                     // Test case where first ellipse is null but second isn't
                                                                                                     // Original should return false, mutant returns true
                                                                                                     Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                     assertFalse(ShapeUtilities.equal(null, e2));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Ellipse2D_SecondNullFirstNotNull() {
                                                                                                     // Test case where second ellipse is null but first isn't
                                                                                                     // Both original and mutant should return false
                                                                                                     Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                     assertFalse(ShapeUtilities.equal(e1, null));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Ellipse2D_BothNotNullSameFrame() {
                                                                                                     // Test case where both ellipses are not null and have same frame
                                                                                                     // Both should return true
                                                                                                     Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                     Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                     assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Ellipse2D_BothNotNullDifferentFrame() {
                                                                                                     // Test case where both ellipses are not null but have different frames
                                                                                                     // Both should return false
                                                                                                     Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                     Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                                                                                                     assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Arc2D_BothNull1() {
                                                                                                     // Test case where both arcs are null
                                                                                                     Arc2D a1 = null;
                                                                                                     Arc2D a2 = null;
                                                                                                     assertTrue("Both null arcs should be considered equal", 
                                                                                                         ShapeUtilities.equal(a1, a2));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Arc2D_FirstNullSecondNotNull1() {
                                                                                                     // Test case where first arc is null and second isn't
                                                                                                     Arc2D a1 = null;
                                                                                                     Arc2D a2 = new Arc2D.Double();
                                                                                                     assertFalse("Null arc should not equal non-null arc", 
                                                                                                         ShapeUtilities.equal(a1, a2));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Arc2D_FirstNotNullSecondNull1() {
                                                                                                     // Test case where first arc isn't null and second is null
                                                                                                     Arc2D a1 = new Arc2D.Double();
                                                                                                     Arc2D a2 = null;
                                                                                                     assertFalse("Non-null arc should not equal null arc", 
                                                                                                         ShapeUtilities.equal(a1, a2));
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Polygon_BothNull() {
                                                                                                     // This test should catch the mutant
                                                                                                     Polygon p1 = null;
                                                                                                     Polygon p2 = null;
                                                                                                     boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                     assertTrue("Two null polygons should be considered equal", result);
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Polygon_FirstNullSecondNotNull() {
                                                                                                     // This test should also catch the mutant
                                                                                                     Polygon p1 = null;
                                                                                                     Polygon p2 = new Polygon(new int[]{0}, new int[]{0}, 1);
                                                                                                     boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                     assertFalse("Null polygon should not equal non-null polygon", result);
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Polygon_SecondNullFirstNotNull() {
                                                                                                     Polygon p1 = new Polygon(new int[]{0}, new int[]{0}, 1);
                                                                                                     Polygon p2 = null;
                                                                                                     boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                     assertFalse("Non-null polygon should not equal null polygon", result);
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Polygon_BothNonNullAndEqual() {
                                                                                                     Polygon p1 = new Polygon(new int[]{0,1}, new int[]{0,1}, 2);
                                                                                                     Polygon p2 = new Polygon(new int[]{0,1}, new int[]{0,1}, 2);
                                                                                                     boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                     assertTrue("Identical polygons should be equal", result);
                                                                                                 }

    @Test
                                                                                                 public void testEqual_Polygon_BothNonNullAndDifferent() {
                                                                                                     Polygon p1 = new Polygon(new int[]{0,1}, new int[]{0,1}, 2);
                                                                                                     Polygon p2 = new Polygon(new int[]{0,2}, new int[]{0,1}, 2);
                                                                                                     boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                     assertFalse("Different polygons should not be equal", result);
                                                                                                 }

    @Test
                                                                                                 public void testEqual_WhenBothShapesAreNull_ShouldReturnTrue() {
                                                                                                     // Test case where both shapes are null
                                                                                                     Shape p1 = null;
                                                                                                     Shape p2 = null;
                                                                                                     
                                                                                                     boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                     
                                                                                                     // Original would return true, mutant would return false
                                                                                                     assertTrue("Both shapes are null should return true", result);
                                                                                                 }

    @Test
                                                                                                 public void testEqual_WhenFirstShapeIsNullAndSecondIsNotNull_ShouldReturnFalse() {
                                                                                                     // Test case where first shape is null and second is not
                                                                                                     Shape p1 = null;
                                                                                                     Shape p2 = mock(Shape.class);
                                                                                                     
                                                                                                     boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                     
                                                                                                     // Original would return false, mutant would return true
                                                                                                     assertFalse("First shape null and second not null should return false", result);
                                                                                                 }

    @Test
                                                                                            public void testEqual_BothLinesNull1() {
                                                                                                // This should return true in original, false in mutant
                                                                                                assertTrue(ShapeUtilities.equal((Line2D) null, (Line2D) null));
                                                                                            }

    @Test
                                                                                            public void testEqualWithNonNullShapes() {
                                                                                                // Additional test cases for completeness
                                                                                                Shape shape1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                Shape shape2 = new Line2D.Double(0, 0, 10, 10);
                                                                                                Shape shape3 = new Line2D.Double(0, 0, 20, 20);
                                                                                                
                                                                                                assertTrue("Equal shapes should return true",
                                                                                                          ShapeUtilities.equal(shape1, shape2));
                                                                                                assertFalse("Different shapes should return false",
                                                                                                           ShapeUtilities.equal(shape1, shape3));
                                                                                            }

    @Test
                                                                                            public void testEqual_Line2D_FirstNullSecondNotNull() {
                                                                                                // Setup
                                                                                                Line2D line1 = null;
                                                                                                Line2D line2 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                                                                                                
                                                                                                // Test
                                                                                                boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                
                                                                                                // Verify
                                                                                                assertFalse("Expected false when first line is null and second is not", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_Line2D_BothNull() {
                                                                                                // Setup
                                                                                                Line2D line1 = null;
                                                                                                Line2D line2 = null;
                                                                                                
                                                                                                // Test
                                                                                                boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                
                                                                                                // Verify
                                                                                                assertTrue("Expected true when both lines are null", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_Line2D_FirstNotNullSecondNull() {
                                                                                                // Setup
                                                                                                Line2D line1 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                                                                                                Line2D line2 = null;
                                                                                                
                                                                                                // Test
                                                                                                boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                
                                                                                                // Verify
                                                                                                assertFalse("Expected false when second line is null and first is not", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_Line2D_BothNotNullEqual() {
                                                                                                // Setup
                                                                                                Point2D p1 = new Point2D.Double(1, 1);
                                                                                                Point2D p2 = new Point2D.Double(2, 2);
                                                                                                Line2D line1 = new Line2D.Double(p1, p2);
                                                                                                Line2D line2 = new Line2D.Double(p1, p2);
                                                                                                
                                                                                                // Test
                                                                                                boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                
                                                                                                // Verify
                                                                                                assertTrue("Expected true when lines have same points", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_Line2D_BothNotNullDifferent() {
                                                                                                // Setup
                                                                                                Line2D line1 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                                                                                                Line2D line2 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(3, 3));
                                                                                                
                                                                                                // Test
                                                                                                boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                
                                                                                                // Verify
                                                                                                assertFalse("Expected false when lines have different points", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_Ellipse2D_FirstNullSecondNotNull1() {
                                                                                                // Setup
                                                                                                Ellipse2D e1 = null;
                                                                                                Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                
                                                                                                // Execute
                                                                                                boolean result = ShapeUtilities.equal(e1, e2);
                                                                                                
                                                                                                // Verify
                                                                                                assertFalse("Expected false when first ellipse is null and second is not null", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_WhenA1IsNullAndA2IsNotNull_ShouldReturnFalse() {
                                                                                                // Arrange
                                                                                                Arc2D a1 = null;
                                                                                                Arc2D a2 = new Arc2D.Double();
                                                                                                
                                                                                                // Act
                                                                                                boolean result = ShapeUtilities.equal(a1, a2);
                                                                                                
                                                                                                // Assert
                                                                                                assertFalse("When a1 is null and a2 is not null, should return false", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_WhenBothAreNull_ShouldReturnTrue() {
                                                                                                // Arrange
                                                                                                Arc2D a1 = null;
                                                                                                Arc2D a2 = null;
                                                                                                
                                                                                                // Act
                                                                                                boolean result = ShapeUtilities.equal(a1, a2);
                                                                                                
                                                                                                // Assert
                                                                                                assertTrue("When both a1 and a2 are null, should return true", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_WhenA1IsNotNullAndA2IsNull_ShouldReturnFalse() {
                                                                                                // Arrange
                                                                                                Arc2D a1 = new Arc2D.Double();
                                                                                                Arc2D a2 = null;
                                                                                                
                                                                                                // Act
                                                                                                boolean result = ShapeUtilities.equal(a1, a2);
                                                                                                
                                                                                                // Assert
                                                                                                assertFalse("When a1 is not null and a2 is null, should return false", result);
                                                                                            }

    @Test
                                                                                            public void testEqualPolygonWithFirstNullSecondNotNull() {
                                                                                                // Create test data
                                                                                                Polygon p1 = null;
                                                                                                Polygon p2 = new Polygon(new int[]{1,2,3}, new int[]{1,2,3}, 3);
                                                                                                
                                                                                                // Test the behavior
                                                                                                boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                
                                                                                                // Assert the expected behavior (should be false when p1 is null and p2 is not)
                                                                                                assertFalse("Should return false when first polygon is null and second is not", result);
                                                                                            }

    @Test
                                                                                            public void testEqualPolygonWithBothNull() {
                                                                                                // Test data
                                                                                                Polygon p1 = null;
                                                                                                Polygon p2 = null;
                                                                                                
                                                                                                // Test the behavior
                                                                                                boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                
                                                                                                // Assert the expected behavior (should be true when both are null)
                                                                                                assertTrue("Should return true when both polygons are null", result);
                                                                                            }

    @Test
                                                                                            public void testEqualPolygonWithFirstNotNullSecondNull() {
                                                                                                // Test data
                                                                                                Polygon p1 = new Polygon(new int[]{1,2,3}, new int[]{1,2,3}, 3);
                                                                                                Polygon p2 = null;
                                                                                                
                                                                                                // Test the behavior
                                                                                                boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                
                                                                                                // Assert the expected behavior (should be false when p2 is null and p1 is not)
                                                                                                assertFalse("Should return false when second polygon is null and first is not", result);
                                                                                            }

    @Test
                                                                                            public void testEqual_WhenP1IsNullAndP2IsNotNull_ShouldReturnFalse() {
                                                                                                // Create a non-null Shape object for p2
                                                                                                Shape p2 = mock(Shape.class);
                                                                                                
                                                                                                // Call the method with p1=null and p2=non-null
                                                                                                boolean result = ShapeUtilities.equal(null, p2);
                                                                                                
                                                                                                // Verify the result is false (original behavior)
                                                                                                // This will catch the mutant which would return true
                                                                                                assertFalse(result);
                                                                                            }

    @Test
                                                                                       public void testEqualWithNullShapes() {
                                                                                           // Test case that will catch the mutant
                                                                                           Shape nonNullShape = new Line2D.Double(0, 0, 10, 10);
                                                                                           Shape nullShape = null;
                                                                                           
                                                                                           // Original behavior should return false when comparing non-null with null
                                                                                           // Mutant would return true here
                                                                                           assertFalse("Comparing non-null with null should return false", 
                                                                                                      ShapeUtilities.equal(nonNullShape, nullShape));
                                                                                           
                                                                                           // Also test null vs null case
                                                                                           assertTrue("Comparing null with null should return true",
                                                                                                     ShapeUtilities.equal((Shape)null, (Shape)null));
                                                                                           
                                                                                           // Test with actual Polygon objects to ensure the specific mutant is caught
                                                                                           Polygon p1 = new Polygon(new int[]{0,10,10,0}, new int[]{0,0,10,10}, 4);
                                                                                           Polygon p2 = null;
                                                                                           assertFalse("Comparing non-null Polygon with null should return false",
                                                                                                      ShapeUtilities.equal(p1, p2));
                                                                                       }

    @Test
                                                                                       public void testEqual_WhenBothAreNull_ShouldReturnTrue1() {
                                                                                           // Verify the case where both are null still works
                                                                                           boolean result = ShapeUtilities.equal((Shape)null, (Shape)null);
                                                                                           assertTrue(result);
                                                                                       }

    @Test
                                                                                       public void testEqualWithRectangle2DShouldUseObjectUtilities() {
                                                                                           // Create two different Rectangle2D objects
                                                                                           Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                           Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 20, 20);
                                                                                           
                                                                                           // These rectangles are not equal
                                                                                           assertFalse("Different rectangles should not be equal", 
                                                                                                      ShapeUtilities.equal(rect1, rect2));
                                                                                           
                                                                                           // Create two equal Rectangle2D objects
                                                                                           Rectangle2D rect3 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                           Rectangle2D rect4 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                           
                                                                                           // These rectangles should be equal
                                                                                           assertTrue("Equal rectangles should be equal",
                                                                                                     ShapeUtilities.equal(rect3, rect4));
                                                                                       }

    @Test
                                                                                       public void testEqual_Line2D_FirstNonNullSecondNull_ShouldReturnFalse() {
                                                                                           // Setup
                                                                                           Line2D l1 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                                                                                           Line2D l2 = null;
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(l1, l2);
                                                                                           
                                                                                           // Verify
                                                                                           assertFalse("A non-null Line2D should not be equal to null", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_Line2D_BothNull_ShouldReturnTrue() {
                                                                                           // Setup
                                                                                           Line2D l1 = null;
                                                                                           Line2D l2 = null;
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(l1, l2);
                                                                                           
                                                                                           // Verify
                                                                                           assertTrue("Two null Line2D objects should be considered equal", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_Line2D_FirstNullSecondNonNull_ShouldReturnFalse() {
                                                                                           // Setup
                                                                                           Line2D l1 = null;
                                                                                           Line2D l2 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(l1, l2);
                                                                                           
                                                                                           // Verify
                                                                                           assertFalse("A null Line2D should not be equal to non-null Line2D", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_Line2D_SamePoints_ShouldReturnTrue() {
                                                                                           // Setup
                                                                                           Point2D p1 = new Point2D.Double(1, 1);
                                                                                           Point2D p2 = new Point2D.Double(2, 2);
                                                                                           Line2D l1 = new Line2D.Double(p1, p2);
                                                                                           Line2D l2 = new Line2D.Double(p1, p2);
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(l1, l2);
                                                                                           
                                                                                           // Verify
                                                                                           assertTrue("Line2D objects with same points should be equal", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_Line2D_DifferentPoints_ShouldReturnFalse() {
                                                                                           // Setup
                                                                                           Line2D l1 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                                                                                           Line2D l2 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(3, 3));
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(l1, l2);
                                                                                           
                                                                                           // Verify
                                                                                           assertFalse("Line2D objects with different points should not be equal", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_WhenE1NotNullAndE2Null_ShouldReturnFalse() {
                                                                                           // Setup
                                                                                           Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                           Ellipse2D e2 = null;
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(e1, e2);
                                                                                           
                                                                                           // Verify
                                                                                           assertFalse("Should return false when e1 is not null and e2 is null", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_WhenE1NullAndE2NotNull_ShouldReturnFalse() {
                                                                                           // Setup
                                                                                           Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(null, e2);
                                                                                           
                                                                                           // Verify
                                                                                           assertFalse("Should return false when e1 is null and e2 is not null", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_WhenFramesDifferent_ShouldReturnFalse() {
                                                                                           // Setup
                                                                                           Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                           Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(e1, e2);
                                                                                           
                                                                                           // Verify
                                                                                           assertFalse("Should return false when frames are different", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_WhenFramesSame_ShouldReturnTrue() {
                                                                                           // Setup
                                                                                           Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                           Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                           
                                                                                           // Test
                                                                                           boolean result = ShapeUtilities.equal(e1, e2);
                                                                                           
                                                                                           // Verify
                                                                                           assertTrue("Should return true when frames are equal", result);
                                                                                       }

    @Test
                                                                                       public void testEqual_WhenA1NotNullAndA2Null_ShouldReturnFalse() {
                                                                                           // Create a non-null Arc2D mock object
                                                                                           Arc2D a1 = mock(Arc2D.class);
                                                                                           when(a1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Float());
                                                                                           when(a1.getAngleStart()).thenReturn(0.0);
                                                                                           when(a1.getAngleExtent()).thenReturn(90.0);
                                                                                           when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                           
                                                                                           // a2 is null
                                                                                           Arc2D a2 = null;
                                                                                           
                                                                                           // The original code should return false when a1 is not null and a2 is null
                                                                                           assertFalse(ShapeUtilities.equal(a1, a2));
                                                                                           
                                                                                           // This test will catch the mutant because:
                                                                                           // Original: returns false (correct behavior)
                                                                                           // Mutant: returns true (incorrect behavior)
                                                                                       }

    @Test
                                                                                   public void testEqual_WhenFirstPolygonNotNullAndSecondNull_ShouldReturnFalse() {
                                                                                       // Create a non-null polygon
                                                                                       Polygon p1 = new Polygon();
                                                                                       p1.addPoint(1, 1);
                                                                                       p1.addPoint(2, 2);
                                                                                       
                                                                                       // Second polygon is null
                                                                                       Polygon p2 = null;
                                                                                       
                                                                                       // The method should return false when comparing non-null with null
                                                                                       assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                       
                                                                                       // This test would fail if the mutant is present, since the mutant would return true
                                                                                   }

    @Test
                                                                                   public void testEqual_WhenFirstNullAndSecondNotNull_ShouldReturnFalse() {
                                                                                       Polygon p2 = new Polygon();
                                                                                       p2.addPoint(1, 1);
                                                                                       assertFalse(ShapeUtilities.equal(null, p2));
                                                                                   }

    @Test
                                                                                   public void testEqual_WhenDifferentPointCounts_ShouldReturnFalse() {
                                                                                       Polygon p1 = new Polygon();
                                                                                       p1.addPoint(1, 1);
                                                                                       
                                                                                       Polygon p2 = new Polygon();
                                                                                       p2.addPoint(1, 1);
                                                                                       p2.addPoint(2, 2);
                                                                                       
                                                                                       assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                   }

    @Test
                                                                                   public void testEqual_WhenSamePoints_ShouldReturnTrue() {
                                                                                       Polygon p1 = new Polygon();
                                                                                       p1.addPoint(1, 1);
                                                                                       p1.addPoint(2, 2);
                                                                                       
                                                                                       Polygon p2 = new Polygon();
                                                                                       p2.addPoint(1, 1);
                                                                                       p2.addPoint(2, 2);
                                                                                       
                                                                                       assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                   }

    @Test
                                                                                   public void testEqual_WhenDifferentXPoints_ShouldReturnFalse() {
                                                                                       Polygon p1 = new Polygon();
                                                                                       p1.addPoint(1, 1);
                                                                                       p1.addPoint(2, 2);
                                                                                       
                                                                                       Polygon p2 = new Polygon();
                                                                                       p2.addPoint(1, 1);
                                                                                       p2.addPoint(3, 2); // Different x coordinate
                                                                                       
                                                                                       assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                   }

    @Test
                                                                                   public void testEqual_WhenDifferentYPoints_ShouldReturnFalse() {
                                                                                       Polygon p1 = new Polygon();
                                                                                       p1.addPoint(1, 1);
                                                                                       p1.addPoint(2, 2);
                                                                                       
                                                                                       Polygon p2 = new Polygon();
                                                                                       p2.addPoint(1, 1);
                                                                                       p2.addPoint(2, 3); // Different y coordinate
                                                                                       
                                                                                       assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                   }

    @Test
                                                                                  public void testEqualWithNullInputs() {
                                                                                      // Test with one null input
                                                                                      Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                      assertFalse("Null and non-null should not be equal",
                                                                                                 ShapeUtilities.equal((Shape) null, rect));
                                                                                      assertFalse("Non-null and null should not be equal",
                                                                                                 ShapeUtilities.equal(rect, (Shape) null));
                                                                                      
                                                                                      // Test with both null inputs
                                                                                      assertTrue("Both null inputs should be equal",
                                                                                                 ShapeUtilities.equal((Shape) null, (Shape) null));
                                                                                  }

    @Test
                                                                                  public void testEqual_WhenBothNull_ShouldReturnTrue() {
                                                                                      // Test
                                                                                      boolean result = ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null);
                                                                                      
                                                                                      // Verify
                                                                                      assertTrue("Should return true when both parameters are null", result);
                                                                                  }

    @Test
                                                                                  public void testEqual_WhenBothNull_ShouldReturnTrue1() {
                                                                                      Polygon p1 = null;
                                                                                      Polygon p2 = null;
                                                                                      assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                  }

    @Test
                                                                              public void testEqual_WhenFirstShapeNotNullAndSecondNull_ShouldReturnFalse1() {
                                                                                  // Create a mock Shape object for p1
                                                                                  Shape p1 = mock(Shape.class);
                                                                                  
                                                                                  // The test - should return false when p1 is not null and p2 is null
                                                                                  boolean result = ShapeUtilities.equal(p1, null);
                                                                                  
                                                                                  // Assert that it returns false (original behavior)
                                                                                  assertFalse("Should return false when first shape is not null and second is null", result);
                                                                                  
                                                                                  // Verify no interactions with the mock since equal() should return immediately
                                                                                  verifyNoInteractions(p1);
                                                                              }

    @Test
                                                                              public void testEqualWithRectangle2DShouldReturnFalseForNonEqualRectangles() {
                                                                                  // Arrange
                                                                                  Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                  Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 20, 20);
                                                                                  
                                                                                  // Act
                                                                                  boolean result = ShapeUtilities.equal(rect1, rect2);
                                                                                  
                                                                                  // Assert
                                                                                  assertFalse("Comparing two different Rectangle2D objects should return false", result);
                                                                              }

    @Test
                                                                              public void testEqualWithRectangle2DShouldReturnTrueForEqualRectangles() {
                                                                                  // Arrange
                                                                                  Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                  Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                  
                                                                                  // Act
                                                                                  boolean result = ShapeUtilities.equal(rect1, rect2);
                                                                                  
                                                                                  // Assert
                                                                                  assertTrue("Comparing two equal Rectangle2D objects should return true", result);
                                                                              }

    @Test
                                                                          public void testEqual_Line2D_OneNullOneNotNull_ShouldReturnFalse() {
                                                                              // Create a non-null Line2D object
                                                                              Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                                              Line2D line2 = null;
                                                                              
                                                                              // The original method should return false when one line is null and the other isn't
                                                                              // The mutant would return true in this case
                                                                              boolean result = ShapeUtilities.equal(line1, line2);
                                                                              
                                                                              // Assert that the result is false (original behavior)
                                                                              assertFalse("Method should return false when one line is null and the other isn't", result);
                                                                          }

    @Test
                                                                              public void testEqual_Ellipse2D_SecondNull1() {
                                                                                  // Setup
                                                                                  Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                  when(e1.getFrame()).thenReturn(mock(Rectangle2D.class));
                                                                                  Ellipse2D e2 = null;
                                                                                  
                                                                                  // Test and verify
                                                                                  assertFalse("Should return false when first ellipse is not null but second is null", 
                                                                                             ShapeUtilities.equal(e1, e2));
                                                                              }

    @Test
                                                                              public void testEqual_Arc2D_WhenA1NotNullAndA2Null_ShouldReturnFalse1() {
                                                                                  // Create a non-null Arc2D object for a1
                                                                                  Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
                                                                                  Arc2D a2 = null;
                                                                                  
                                                                                  // The original method should return false when a1 is not null and a2 is null
                                                                                  // The mutant would return true in this case
                                                                                  boolean result = ShapeUtilities.equal(a1, a2);
                                                                                  
                                                                                  assertFalse("Should return false when first arc is not null and second is null", result);
                                                                              }

    @Test
                                                                          public void testEqual_WhenFirstPolygonNotNullAndSecondNull_ShouldReturnFalse1() {
                                                                              // Arrange
                                                                              Polygon nonNullPolygon = new Polygon();
                                                                              nonNullPolygon.addPoint(1, 1);
                                                                              nonNullPolygon.addPoint(2, 2);
                                                                              
                                                                              // Act
                                                                              boolean result = ShapeUtilities.equal(nonNullPolygon, null);
                                                                              
                                                                              // Assert
                                                                              assertFalse("Method should return false when first polygon is not null and second is null", result);
                                                                          }

    @Test
                                                                              public void testEqual_NonNullShapeAndNullShape_ShouldReturnFalse() {
                                                                                  // Create a non-null shape (using Line2D as a concrete implementation)
                                                                                  Shape nonNullShape = new Line2D.Double(0, 0, 10, 10);
                                                                                  
                                                                                  // Test with non-null shape and null shape
                                                                                  boolean result = ShapeUtilities.equal(nonNullShape, null);
                                                                                  
                                                                                  // Assert that the result is false (original behavior)
                                                                                  // This will catch the mutant that returns true in this case
                                                                                  assertFalse("Comparing non-null shape with null shape should return false", result);
                                                                              }

    @Test
                                                                              public void testEqual_NullShapeAndNonNullShape_ShouldReturnFalse() {
                                                                                  // Create a non-null shape (using Line2D as a concrete implementation)
                                                                                  Shape nonNullShape = new Line2D.Double(0, 0, 10, 10);
                                                                                  
                                                                                  // Test with null shape and non-null shape
                                                                                  boolean result = ShapeUtilities.equal(null, nonNullShape);
                                                                                  
                                                                                  // Assert that the result is false (original behavior)
                                                                                  assertFalse("Comparing null shape with non-null shape should return false", result);
                                                                              }

    @Test
                                                                         public void testEqual_TwoNullShapes_ShouldReturnTrue() {
                                                                             // Test with both shapes null
                                                                             Shape shape1 = null;
                                                                             Shape shape2 = null;
                                                                             boolean result = ShapeUtilities.equal(shape1, shape2);
                                                                             
                                                                             // Assert that the result is true (original behavior)
                                                                             assertTrue("Comparing two null shapes should return true", result);
                                                                         }

    @Test
                                                                         public void testEqual_WithDifferentShapeTypes_ShouldReturnFalse() {
                                                                             // Create two different shape types
                                                                             Shape s1 = new Line2D.Double(0, 0, 10, 10);
                                                                             Shape s2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                             
                                                                             // Should return false since types are different
                                                                             assertFalse(ShapeUtilities.equal(s1, s2));
                                                                         }

    @Test
                                                                         public void testEqual_WithUnhandledShapeType_ShouldReturnFalse() {
                                                                             // Create two shapes of type not explicitly handled (Rectangle2D)
                                                                             Shape s1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                             Shape s2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                             
                                                                             // Should return false (or delegate to ObjectUtilities.equal)
                                                                             // This will catch the mutant that returns true
                                                                             assertFalse(ShapeUtilities.equal(s1, s2));
                                                                         }

    @Test
                                                                         public void testEqual_Line2D_SecondParameterNull() {
                                                                             // Create a non-null Line2D object for l1
                                                                             Line2D l1 = new Line2D.Double(
                                                                                 new Point2D.Double(1.0, 2.0), 
                                                                                 new Point2D.Double(3.0, 4.0)
                                                                             );
                                                                             
                                                                             // l2 is null
                                                                             Line2D l2 = null;
                                                                             
                                                                             // The original method should return false when l1 is not null but l2 is null
                                                                             // The mutant would return true in this case
                                                                             assertFalse("Should return false when second parameter is null", 
                                                                                        ShapeUtilities.equal(l1, l2));
                                                                         }

    @Test
                                                                         public void testEqual_Ellipse2D_WhenFirstNonNullAndSecondNull_ShouldReturnFalse() {
                                                                             // Arrange
                                                                             Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                             Ellipse2D e2 = null;
                                                                             
                                                                             // Act
                                                                             boolean result = ShapeUtilities.equal(e1, e2);
                                                                             
                                                                             // Assert
                                                                             assertFalse("Should return false when first ellipse is non-null and second is null", result);
                                                                         }

    @Test
                                                                         public void testEqual_WhenA1NotNullAndA2Null_ShouldReturnFalse1() {
                                                                             // Create a mock Arc2D object for a1
                                                                             Arc2D a1 = mock(Arc2D.class);
                                                                             when(a1.getFrame()).thenReturn(mock(java.awt.geom.Rectangle2D.class));
                                                                             when(a1.getAngleStart()).thenReturn(0.0);
                                                                             when(a1.getAngleExtent()).thenReturn(90.0);
                                                                             when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                             
                                                                             // a2 is null
                                                                             Arc2D a2 = null;
                                                                             
                                                                             // The original method should return false when a1 is not null and a2 is null
                                                                             // The mutant would return true in this case
                                                                             assertFalse(ShapeUtilities.equal(a1, a2));
                                                                         }

    @Test
                                                                         public void testEqual_WhenA1NullAndA2NotNull_ShouldReturnFalse() {
                                                                             Arc2D a2 = mock(Arc2D.class);
                                                                             assertFalse(ShapeUtilities.equal(null, a2));
                                                                         }

    @Test
                                                                         public void testEqual_WhenAllAttributesMatch_ShouldReturnTrue() {
                                                                             Arc2D a1 = mock(Arc2D.class);
                                                                             Arc2D a2 = mock(Arc2D.class);
                                                                             
                                                                             Rectangle2D frame = mock(Rectangle2D.class);
                                                                             when(a1.getFrame()).thenReturn(frame);
                                                                             when(a2.getFrame()).thenReturn(frame);
                                                                             when(a1.getAngleStart()).thenReturn(45.0);
                                                                             when(a2.getAngleStart()).thenReturn(45.0);
                                                                             when(a1.getAngleExtent()).thenReturn(90.0);
                                                                             when(a2.getAngleExtent()).thenReturn(90.0);
                                                                             when(a1.getArcType()).thenReturn(Arc2D.PIE);
                                                                             when(a2.getArcType()).thenReturn(Arc2D.PIE);
                                                                             
                                                                             assertTrue(ShapeUtilities.equal(a1, a2));
                                                                         }

    @Test
                                                                         public void testEqual_WhenFramesDiffer_ShouldReturnFalse() {
                                                                             Arc2D a1 = mock(Arc2D.class);
                                                                             Arc2D a2 = mock(Arc2D.class);
                                                                             
                                                                             when(a1.getFrame()).thenReturn(mock(Rectangle2D.class));
                                                                             when(a2.getFrame()).thenReturn(mock(Rectangle2D.class));
                                                                             // Other attributes are the same
                                                                             when(a1.getAngleStart()).thenReturn(45.0);
                                                                             when(a2.getAngleStart()).thenReturn(45.0);
                                                                             when(a1.getAngleExtent()).thenReturn(90.0);
                                                                             when(a2.getAngleExtent()).thenReturn(90.0);
                                                                             when(a1.getArcType()).thenReturn(Arc2D.PIE);
                                                                             when(a2.getArcType()).thenReturn(Arc2D.PIE);
                                                                             
                                                                             assertFalse(ShapeUtilities.equal(a1, a2));
                                                                         }

    @Test
                                                                         public void testEqual_PolygonWithNull() {
                                                                             // Create a non-null polygon
                                                                             int[] xpoints = {0, 10, 10, 0};
                                                                             int[] ypoints = {0, 0, 10, 10};
                                                                             Polygon p1 = new Polygon(xpoints, ypoints, 4);
                                                                             
                                                                             // Test case where p1 is not null but p2 is null
                                                                             boolean result = ShapeUtilities.equal(p1, null);
                                                                             
                                                                             // Assert that it should return false (original behavior)
                                                                             // This will catch the mutant that returns !false (true)
                                                                             assertFalse(result);
                                                                         }

    @Test
                                                                         public void testEqual_FirstNullSecondNotNull3() {
                                                                             // Create a non-null polygon
                                                                             int[] xpoints = {0, 10, 10, 0};
                                                                             int[] ypoints = {0, 0, 10, 10};
                                                                             Polygon p2 = new Polygon(xpoints, ypoints, 4);
                                                                             
                                                                             // Test case where p1 is null but p2 is not null
                                                                             boolean result = ShapeUtilities.equal(null, p2);
                                                                             
                                                                             // Should return false
                                                                             assertFalse(result);
                                                                         }

    @Test
                                                                    public void testEqual_WithNullInput_ShouldReturnFalse() {
                                                                        // Test with null inputs
                                                                        Shape s1 = new Line2D.Double(0, 0, 10, 10);
                                                                        
                                                                        // Should return false when comparing with null
                                                                        assertFalse(ShapeUtilities.equal(s1, null));
                                                                        assertFalse(ShapeUtilities.equal(null, (Shape)s1));
                                                                        assertFalse(ShapeUtilities.equal(null, (Shape)null));
                                                                    }

    @Test
                                                                    public void testEqual_WhenBothNull_ShouldReturnTrue2() {
                                                                        Arc2D a1 = null;
                                                                        Arc2D a2 = null;
                                                                        assertTrue(ShapeUtilities.equal(a1, a2));
                                                                    }

    @Test
                                                                    public void testEqual_BothNull3() {
                                                                        // Test case where both polygons are null
                                                                        boolean result = ShapeUtilities.equal((Polygon) null, (Polygon) null);
                                                                        
                                                                        // Should return true
                                                                        assertTrue(result);
                                                                    }

    @Test
                                                                    public void testEqual_WhenFirstShapeNotNullAndSecondNull_ShouldReturnFalse2() {
                                                                        // Create a mock Shape object for p1
                                                                        Shape p1 = mock(Shape.class);
                                                                        
                                                                        // p2 is null
                                                                        Shape p2 = null;
                                                                        
                                                                        // Call the method under test
                                                                        boolean result = ShapeUtilities.equal(p1, p2);
                                                                        
                                                                        // Verify the result is false (original behavior)
                                                                        assertFalse("Should return false when first shape is not null and second is null", result);
                                                                        
                                                                        // No need to verify interactions since method should return immediately when p2 is null
                                                                    }

    @Test
                                                                    public void testEqualWithDifferentRectanglesShouldReturnFalse() {
                                                                        // Arrange
                                                                        Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                        Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 20, 20);
                                                                        
                                                                        // Act & Assert
                                                                        assertFalse("Different rectangles should not be equal", 
                                                                                   ShapeUtilities.equal(rect1, rect2));
                                                                    }

    @Test
                                                                    public void testEqualWithSameRectanglesShouldReturnTrue() {
                                                                        // Arrange
                                                                        Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                        Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                        
                                                                        // Act & Assert
                                                                        assertTrue("Same rectangles should be equal", 
                                                                                  ShapeUtilities.equal(rect1, rect2));
                                                                    }

    @Test
                                                                public void testEqual_Line2D_OneNull() {
                                                                    // Create a non-null Line2D object
                                                                    Line2D l1 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                    
                                                                    // Keep l2 null
                                                                    Line2D l2 = null;
                                                                    
                                                                    // Test the case where l1 is not null but l2 is null
                                                                    // Original behavior should return false, mutant would return true
                                                                    assertFalse("Should return false when one Line2D is null and the other isn't", 
                                                                               ShapeUtilities.equal(l1, l2));
                                                                    
                                                                    // Also test the reverse case (l1 null, l2 not null)
                                                                    assertFalse("Should return false when one Line2D is null and the other isn't",
                                                                               ShapeUtilities.equal(null, l1));
                                                                }

    @Test
                                                                    public void testEqual_Ellipse2D_WhenFirstNonNullAndSecondNull_ShouldReturnFalse1() {
                                                                        // Arrange
                                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                        Ellipse2D e2 = null;
                                                                        
                                                                        // Act
                                                                        boolean result = ShapeUtilities.equal(e1, e2);
                                                                        
                                                                        // Assert
                                                                        assertFalse("Should return false when first ellipse is non-null and second is null", result);
                                                                    }

    @Test
                                                                    public void testEqual_Ellipse2D_WhenBothNull_ShouldReturnTrue() {
                                                                        // Arrange
                                                                        Ellipse2D e1 = null;
                                                                        Ellipse2D e2 = null;
                                                                        
                                                                        // Act
                                                                        boolean result = ShapeUtilities.equal(e1, e2);
                                                                        
                                                                        // Assert
                                                                        assertTrue("Should return true when both ellipses are null", result);
                                                                    }

    @Test
                                                                    public void testEqual_Ellipse2D_WhenFirstNullAndSecondNonNull_ShouldReturnFalse() {
                                                                        // Arrange
                                                                        Ellipse2D e1 = null;
                                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                        
                                                                        // Act
                                                                        boolean result = ShapeUtilities.equal(e1, e2);
                                                                        
                                                                        // Assert
                                                                        assertFalse("Should return false when first ellipse is null and second is non-null", result);
                                                                    }

    @Test
                                                                    public void testEqual_Ellipse2D_WhenFramesDifferent_ShouldReturnFalse() {
                                                                        // Arrange
                                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                                                                        
                                                                        // Act
                                                                        boolean result = ShapeUtilities.equal(e1, e2);
                                                                        
                                                                        // Assert
                                                                        assertFalse("Should return false when frames are different", result);
                                                                    }

    @Test
                                                                    public void testEqual_Ellipse2D_WhenFramesSame_ShouldReturnTrue() {
                                                                        // Arrange
                                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                        
                                                                        // Act
                                                                        boolean result = ShapeUtilities.equal(e1, e2);
                                                                        
                                                                        // Assert
                                                                        assertTrue("Should return true when frames are equal", result);
                                                                    }

    @Test
                                                                    public void testEqual_Arc2D_WhenFirstNonNullAndSecondNull_ShouldReturnFalse() {
                                                                        // Arrange
                                                                        Arc2D a1 = mock(Arc2D.class);
                                                                        Arc2D a2 = null;
                                                                        
                                                                        // Act
                                                                        boolean result = ShapeUtilities.equal(a1, a2);
                                                                        
                                                                        // Assert
                                                                        assertFalse("Expected false when first arc is non-null and second is null", result);
                                                                    }

    @Test
                                                                    public void testEqualPolygonWithNonNullAndNull() {
                                                                        // Create a non-null polygon
                                                                        int[] xpoints = {1, 2, 3};
                                                                        int[] ypoints = {4, 5, 6};
                                                                        Polygon p1 = new Polygon(xpoints, ypoints, 3);
                                                                        
                                                                        // p2 is null
                                                                        Polygon p2 = null;
                                                                        
                                                                        // The original should return false when comparing non-null with null
                                                                        assertFalse("Comparing non-null with null should return false", 
                                                                                   ShapeUtilities.equal(p1, p2));
                                                                        
                                                                        // This test will catch the mutant that returns true in this case
                                                                    }

    @Test
                                                           public void testEqual_FirstNonNullSecondNull_ShouldReturnFalse() {
                                                               // Create a GeneralPath object for p1 instead of Path2D
                                                               GeneralPath p1 = new GeneralPath();
                                                               p1.moveTo(0, 0);
                                                               p1.lineTo(10, 10);
                                                               
                                                               // p2 is null
                                                               Shape p2 = null;
                                                               
                                                               // Call the method under test
                                                               boolean result = ShapeUtilities.equal(p1, p2);
                                                               
                                                               // Verify the result - should be false for original code, true for mutant
                                                               assertFalse("Expected false when first shape is non-null and second is null", result);
                                                               
                                                               // No need to verify interactions since we're using a real object
                                                           }

    @Test
                                                           public void testEqual_WithDifferentShapeTypes_ShouldReturnFalse1() {
                                                               // Arrange
                                                               Shape line = new Line2D.Double(0, 0, 10, 10);
                                                               Shape ellipse = new Ellipse2D.Double(0, 0, 10, 10);
                                                               
                                                               // Act
                                                               boolean result = ShapeUtilities.equal(line, ellipse);
                                                               
                                                               // Assert
                                                               assertFalse("Different shape types should not be equal", result);
                                                           }

    @Test
                                                           public void testEqual_WithUnhandledShapeType_ShouldReturnFalse1() {
                                                               // Arrange
                                                               Shape rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                               Shape rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                               
                                                               // Act
                                                               boolean result = ShapeUtilities.equal(rect1, rect2);
                                                               
                                                               // Assert
                                                               assertFalse("Unhandled shape types should delegate to ObjectUtilities.equal", result);
                                                           }

    @Test
                                                           public void testEqual_Line2D_WhenL1NotNullAndL2Null_ShouldReturnFalse() {
                                                               // Create a non-null Line2D object for l1
                                                               Line2D l1 = new Line2D.Double(
                                                                   new Point2D.Double(1.0, 2.0), 
                                                                   new Point2D.Double(3.0, 4.0)
                                                               );
                                                               
                                                               // l2 is null
                                                               Line2D l2 = null;
                                                               
                                                               // The method should return false when l1 is not null and l2 is null
                                                               assertFalse(ShapeUtilities.equal(l1, l2));
                                                               
                                                               // This test will fail if the mutant (return !false) is present,
                                                               // as it would return true instead of false
                                                           }

    @Test
                                                           public void testEqual_Ellipse2D_SecondNull2() {
                                                               // Create a non-null Ellipse2D object
                                                               Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                               
                                                               // Test when e2 is null
                                                               boolean result = ShapeUtilities.equal(e1, null);
                                                               
                                                               // Original behavior should return false, mutant would return true
                                                               assertFalse("Expected false when first ellipse is non-null and second is null", result);
                                                           }

    @Test
                                                           public void testEqual_Ellipse2D_FirstNull() {
                                                               // Test when e1 is null and e2 is not
                                                               Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                               boolean result = ShapeUtilities.equal(null, e2);
                                                               assertEquals("Expected result to match whether e2 is null", false, result);
                                                           }

    @Test
                                                           public void testEqual_Ellipse2D_NonNullDifferentFrames() {
                                                               // Test with non-null ellipses having different frames
                                                               Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                               Ellipse2D e2 = new Ellipse2D.Double(5, 5, 10, 10);
                                                               boolean result = ShapeUtilities.equal(e1, e2);
                                                               assertFalse("Expected false when frames are different", result);
                                                           }

    @Test
                                                           public void testEqual_Ellipse2D_NonNullSameFrames() {
                                                               // Test with non-null ellipses having same frames
                                                               Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                               Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                               boolean result = ShapeUtilities.equal(e1, e2);
                                                               assertTrue("Expected true when frames are equal", result);
                                                           }

    @Test
                                                       public void testEqual_WhenFirstPolygonNotNullAndSecondNull_ShouldReturnFalse2() {
                                                           // Create a non-null polygon
                                                           Polygon p1 = new Polygon();
                                                           p1.addPoint(1, 1);
                                                           p1.addPoint(2, 2);
                                                           
                                                           // Second polygon is null
                                                           Polygon p2 = null;
                                                           
                                                           // The method should return false when p1 is not null and p2 is null
                                                           boolean result = ShapeUtilities.equal(p1, p2);
                                                           
                                                           // Assert that the result is false (original behavior)
                                                           // This will catch the mutant that returns true in this case
                                                           assertFalse(result);
                                                       }

    @Test
                                                       public void testEqual_WhenFirstShapeNotNullAndSecondNull_ShouldReturnFalse3() {
                                                           // Arrange
                                                           Shape p1 = mock(Shape.class);
                                                           Shape p2 = null;
                                                           
                                                           // Act
                                                           boolean result = ShapeUtilities.equal(p1, p2);
                                                           
                                                           // Assert
                                                           assertFalse("Should return false when first shape is not null and second is null", result);
                                                       }

    @Test
                                                      public void testEqual_WithNullShapes_ShouldDelegateToObjectUtilities() {
                                                          // Arrange
                                                          Shape rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                          Shape rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                          
                                                          // Act & Assert
                                                          assertFalse("Null vs non-null should return false", 
                                                              ShapeUtilities.equal((Shape)null, rect1));
                                                          assertFalse("Non-null vs null should return false", 
                                                              ShapeUtilities.equal(rect1, (Shape)null));
                                                          assertTrue("Both null should return true", 
                                                              ShapeUtilities.equal((Shape)null, (Shape)null));
                                                      }

    @Test
                                                      public void testEqual_Ellipse2D_BothNull1() {
                                                          // Test when both are null
                                                          boolean result = ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null);
                                                          assertTrue("Expected true when both ellipses are null", result);
                                                      }

    @Test
                                                      public void testEqual_WhenA1NotNullAndA2Null_ShouldReturnFalse2() {
                                                          // Create a mock Arc2D object for a1
                                                          Arc2D a1 = mock(Arc2D.class);
                                                          when(a1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10)); // Return proper Rectangle2D
                                                          when(a1.getAngleStart()).thenReturn(0.0);
                                                          when(a1.getAngleExtent()).thenReturn(90.0);
                                                          when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                          
                                                          // a2 is null
                                                          Arc2D a2 = null;
                                                          
                                                          // Test the method
                                                          boolean result = ShapeUtilities.equal(a1, a2);
                                                          
                                                          // Assert that it should return false when a1 is not null and a2 is null
                                                          assertFalse(result);
                                                      }

    @Test
                                                      public void testEqualWithDifferentRectangle2DShouldReturnFalse() {
                                                          // Create two different Rectangle2D objects
                                                          Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                          Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 20, 20);
                                                          
                                                          // The original method should return false since the rectangles are different
                                                          // The mutant would return true here
                                                          boolean result = ShapeUtilities.equal(rect1, rect2);
                                                          
                                                          // Assert that the rectangles are not equal
                                                          assertFalse("Different Rectangle2D objects should not be equal", result);
                                                      }

    @Test
                                                      public void testEqualWithSameRectangle2DShouldReturnTrue() {
                                                          // Create two identical Rectangle2D objects
                                                          Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                          Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                          
                                                          // Both original and mutant would return true here
                                                          boolean result = ShapeUtilities.equal(rect1, rect2);
                                                          
                                                          // Assert that the rectangles are equal
                                                          assertTrue("Identical Rectangle2D objects should be equal", result);
                                                      }

    @Test
                                                  public void testEqual_Line2D_OneNullOneNonNull_ShouldReturnFalse() {
                                                      // Create a non-null Line2D object
                                                      Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                      
                                                      // Test when l1 is non-null and l2 is null
                                                      boolean result = ShapeUtilities.equal(line1, null);
                                                      
                                                      // Assert that it should return false (non-null cannot equal null)
                                                      assertFalse("A non-null Line2D should not equal null", result);
                                                  }

    @Test
                                                      public void testEqual_Arc2D_WhenFirstNonNullAndSecondNull_ShouldReturnFalse1() {
                                                          // Create a mock Arc2D object for a1
                                                          Arc2D a1 = mock(Arc2D.class);
                                                          when(a1.getFrame()).thenReturn(mock(java.awt.geom.Rectangle2D.class));
                                                          when(a1.getAngleStart()).thenReturn(0.0);
                                                          when(a1.getAngleExtent()).thenReturn(90.0);
                                                          when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                          
                                                          // a2 is null
                                                          Arc2D a2 = null;
                                                          
                                                          // The original method should return false when a1 is not null and a2 is null
                                                          // The mutant would return true in this case
                                                          assertFalse("Should return false when first Arc2D is not null and second is null", 
                                                                     ShapeUtilities.equal(a1, a2));
                                                      }

    @Test
                                                  public void testEqual_WhenFirstPolygonNotNullAndSecondNull_ShouldReturnFalse3() {
                                                      // Create a non-null polygon
                                                      Polygon p1 = new Polygon();
                                                      p1.addPoint(1, 1);
                                                      p1.addPoint(2, 2);
                                                      
                                                      // Second polygon is null
                                                      Polygon p2 = null;
                                                      
                                                      // The method should return false when comparing non-null with null
                                                      assertFalse(ShapeUtilities.equal(p1, p2));
                                                      
                                                      // This test will fail when the mutant is present (which returns true instead of false)
                                                      // and pass with the original implementation
                                                  }

    @Test
                                                      public void testEqual_FirstNonNullSecondNull_ShouldReturnFalse1() {
                                                          // Create a mock Shape object for p1
                                                          Shape p1 = mock(Shape.class);
                                                          // p2 is null
                                                          Shape p2 = null;
                                                          
                                                          // Set up mock behavior for p1
                                                          PathIterator mockIterator = mock(PathIterator.class);
                                                          when(p1.getPathIterator(null)).thenReturn(mockIterator);
                                                          when(mockIterator.isDone()).thenReturn(true);
                                                          
                                                          // Test the method
                                                          boolean result = ShapeUtilities.equal(p1, p2);
                                                          
                                                          // Assert that it returns false (non-null can't equal null)
                                                          assertFalse(result);
                                                      }

    @Test
                                                 public void testEqualEllipse2D_NullCases1() {
                                                     // Case 1: Both null should return true
                                                     assertTrue(ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
                                                     
                                                     // Case 2: e1 null, e2 not null should return false
                                                     assertFalse(ShapeUtilities.equal((Ellipse2D) null, new Ellipse2D.Double()));
                                                     
                                                     // Case 3: e1 not null, e2 null should return false
                                                     // This is the case that catches the mutant
                                                     assertFalse(ShapeUtilities.equal(new Ellipse2D.Double(), (Ellipse2D) null));
                                                     
                                                     // Additional cases for completeness
                                                     Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                     Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                     Ellipse2D e3 = new Ellipse2D.Double(0, 0, 20, 20);
                                                     
                                                     // Case 4: Both non-null with same frame
                                                     assertTrue(ShapeUtilities.equal(e1, e2));
                                                     
                                                     // Case 5: Both non-null with different frames
                                                     assertFalse(ShapeUtilities.equal(e1, e3));
                                                 }

    @Test
                                                 public void testEqual_WithDifferentRectangle2DObjects_ShouldReturnFalse() {
                                                     // Arrange
                                                     Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                     Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 20, 20);
                                                     
                                                     // Act
                                                     boolean result = ShapeUtilities.equal(rect1, rect2);
                                                     
                                                     // Assert
                                                     assertFalse("Different Rectangle2D objects should not be equal", result);
                                                 }

    @Test
                                                 public void testEqual_WithDifferentShapeTypes_ShouldReturnFalse2() {
                                                     // Arrange
                                                     Rectangle2D rect = new Rectangle2D.Double(0, 0, 10, 10);
                                                     Polygon poly = new Polygon(new int[]{0, 10, 10, 0}, new int[]{0, 0, 10, 10}, 4);
                                                     
                                                     // Act
                                                     boolean result = ShapeUtilities.equal(rect, poly);
                                                     
                                                     // Assert
                                                     assertFalse("Shapes of different types should not be equal", result);
                                                 }

    @Test
                                                 public void testEqual_Line2D_WhenFirstNotNullSecondNull() {
                                                     // Create a non-null Line2D object for l1
                                                     Line2D l1 = new Line2D.Double(
                                                         new Point2D.Double(1.0, 2.0),
                                                         new Point2D.Double(3.0, 4.0)
                                                     );
                                                     
                                                     // l2 is null
                                                     Line2D l2 = null;
                                                     
                                                     // The original method should return false when l1 is not null but l2 is null
                                                     // The mutant would return true in this case
                                                     assertFalse("Should return false when first line is not null but second is null", 
                                                                ShapeUtilities.equal(l1, l2));
                                                 }

    @Test
                                                 public void testEqual_WhenA1NotNullAndA2Null_ShouldReturnFalse3() {
                                                     // Create a mock Arc2D object for a1
                                                     Arc2D a1 = mock(Arc2D.class);
                                                     when(a1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double());
                                                     when(a1.getAngleStart()).thenReturn(0.0);
                                                     when(a1.getAngleExtent()).thenReturn(90.0);
                                                     when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                     
                                                     // a2 is null
                                                     Arc2D a2 = null;
                                                     
                                                     // Test the method
                                                     boolean result = ShapeUtilities.equal(a1, a2);
                                                     
                                                     // Assert that it returns false (original behavior)
                                                     // This will fail if the mutant is present (which would return true)
                                                     assertFalse(result);
                                                 }

    @Test
                                                 public void testEqual_WhenBothNull_ShouldReturnTrue3() {
                                                     // Both a1 and a2 are null
                                                     Arc2D a1 = null;
                                                     Arc2D a2 = null;
                                                     
                                                     boolean result = ShapeUtilities.equal(a1, a2);
                                                     
                                                     // This tests the first null check
                                                     assertTrue(result);
                                                 }

    @Test
                                                 public void testEqual_WhenA1NullAndA2NotNull_ShouldReturnFalse1() {
                                                     // a1 is null, a2 is not null
                                                     Arc2D a1 = null;
                                                     Arc2D a2 = mock(Arc2D.class);
                                                     
                                                     boolean result = ShapeUtilities.equal(a1, a2);
                                                     
                                                     assertFalse(result);
                                                 }

    @Test
                                                 public void testEqual_WhenAllFieldsEqual_ShouldReturnTrue() {
                                                     // Create two identical Arc2D objects
                                                     Arc2D a1 = mock(Arc2D.class);
                                                     Arc2D a2 = mock(Arc2D.class);
                                                     
                                                     java.awt.geom.Rectangle2D frame = new java.awt.geom.Rectangle2D.Double();
                                                     when(a1.getFrame()).thenReturn(frame);
                                                     when(a2.getFrame()).thenReturn(frame);
                                                     when(a1.getAngleStart()).thenReturn(45.0);
                                                     when(a2.getAngleStart()).thenReturn(45.0);
                                                     when(a1.getAngleExtent()).thenReturn(90.0);
                                                     when(a2.getAngleExtent()).thenReturn(90.0);
                                                     when(a1.getArcType()).thenReturn(Arc2D.PIE);
                                                     when(a2.getArcType()).thenReturn(Arc2D.PIE);
                                                     
                                                     boolean result = ShapeUtilities.equal(a1, a2);
                                                     
                                                     assertTrue(result);
                                                 }

    @Test
                                             public void testEqual_WhenFirstPolygonNotNullAndSecondNull_ShouldReturnFalse4() {
                                                 // Arrange
                                                 Polygon p1 = new Polygon();
                                                 p1.addPoint(1, 1);
                                                 p1.addPoint(2, 2);
                                                 Polygon p2 = null;
                                                 
                                                 // Act
                                                 boolean result = ShapeUtilities.equal(p1, p2);
                                                 
                                                 // Assert
                                                 assertFalse("Should return false when first polygon is not null and second is null", result);
                                             }

    @Test
                                             public void testEqual_WhenFirstShapeNotNullAndSecondNull_ShouldReturnFalse4() {
                                                 // Create a mock Shape object for p1
                                                 Shape p1 = mock(Shape.class);
                                                 // p2 is null
                                                 
                                                 // The original method should return false when p1 is not null and p2 is null
                                                 // The mutant would return true in this case
                                                 boolean result = ShapeUtilities.equal(p1, null);
                                                 
                                                 // Assert that the result is false (original behavior)
                                                 assertFalse(result);
                                                 
                                                 // This test will fail if the mutant is present (which would return true)
                                                 // Thus detecting the mutant
                                             }

    @Test
                                            public void testEqual_Ellipse2D_WhenE1NotNullAndE2Null_ShouldReturnFalse() {
                                                // Create a real Ellipse2D object for e1 instead of mocking
                                                Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                
                                                // e2 is null
                                                Ellipse2D e2 = null;
                                                
                                                // The original method should return false when e1 is not null and e2 is null
                                                assertFalse(ShapeUtilities.equal(e1, e2));
                                                
                                                // The mutant would return true here, so this test would fail on the mutant
                                            }

    @Test
                                            public void testEqual_Ellipse2D_WhenBothNull_ShouldReturnTrue1() {
                                                // Both parameters are null
                                                assertTrue(ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
                                            }

    @Test
                                            public void testEqual_Ellipse2D_WhenFramesEqual_ShouldReturnTrue() {
                                                // Create mock Ellipse2D objects with equal frames
                                                Rectangle2D frame = mock(Rectangle2D.class);
                                                Ellipse2D e1 = mock(Ellipse2D.class);
                                                Ellipse2D e2 = mock(Ellipse2D.class);
                                                
                                                when(e1.getFrame()).thenReturn(frame);
                                                when(e2.getFrame()).thenReturn(frame);
                                                
                                                assertTrue(ShapeUtilities.equal(e1, e2));
                                            }

    @Test
                                            public void testEqual_Ellipse2D_WhenFramesNotEqual_ShouldReturnFalse() {
                                                // Create mock Ellipse2D objects with different frames
                                                Ellipse2D e1 = mock(Ellipse2D.class);
                                                Ellipse2D e2 = mock(Ellipse2D.class);
                                                
                                                // Mock getFrame() to return different Rectangle2D objects
                                                when(e1.getFrame()).thenReturn(mock(Rectangle2D.class));
                                                when(e2.getFrame()).thenReturn(mock(Rectangle2D.class));
                                                
                                                assertFalse(ShapeUtilities.equal(e1, e2));
                                            }

    @Test
                                            public void testEqualRectangle2DWithSameContentDifferentReferences() {
                                                // Create two distinct Rectangle2D objects with identical properties
                                                Rectangle2D rect1 = new Rectangle2D.Double(1.0, 2.0, 3.0, 4.0);
                                                Rectangle2D rect2 = new Rectangle2D.Double(1.0, 2.0, 3.0, 4.0);
                                                
                                                // Verify they are distinct objects
                                                assertNotSame(rect1, rect2);
                                                
                                                // Test the equal method - should return true for equal content
                                                // This will fail if the mutant (using == instead of ObjectUtilities.equal) is present
                                                assertTrue(ShapeUtilities.equal(rect1, rect2));
                                            }

    @Test
                                            public void testEqualRectangle2DWithDifferentContent() {
                                                // Create two Rectangle2D objects with different properties
                                                Rectangle2D rect1 = new Rectangle2D.Double(1.0, 2.0, 3.0, 4.0);
                                                Rectangle2D rect2 = new Rectangle2D.Double(5.0, 6.0, 7.0, 8.0);
                                                
                                                // Test the equal method - should return false for different content
                                                assertFalse(ShapeUtilities.equal(rect1, rect2));
                                            }

    @Test
                                            public void testEqualRectangle2DSameReference() {
                                                // Create one Rectangle2D object
                                                Rectangle2D rect1 = new Rectangle2D.Double(1.0, 2.0, 3.0, 4.0);
                                                
                                                // Test the equal method with same reference - should return true
                                                assertTrue(ShapeUtilities.equal(rect1, rect1));
                                            }

    @Test
                                            public void testEqual_Line2D_SecondNull() {
                                                // Create a non-null Line2D with distinct points
                                                Point2D p1 = new Point2D.Double(1.0, 2.0);
                                                Point2D p2 = new Point2D.Double(3.0, 4.0);
                                                Line2D l1 = new Line2D.Double(p1, p2);
                                                Line2D l2 = null;
                                                
                                                // The original method should return false when l2 is null and l1 isn't
                                                // The mutant would return p1 == p2 (which is false in this case, but could be true in others)
                                                assertFalse(ShapeUtilities.equal(l1, l2));
                                                
                                                // Additional test case where p1 and p2 are the same to catch the mutant
                                                Point2D samePoint = new Point2D.Double(5.0, 6.0);
                                                Line2D l3 = new Line2D.Double(samePoint, samePoint);
                                                Line2D l4 = null;
                                                
                                                // Original would return false, mutant would return true (since p1 == p2)
                                                assertFalse(ShapeUtilities.equal(l3, l4));
                                            }

    @Test
                                        public void testEqual_WhenE1NonNullAndE2Null_ShouldReturnFalse() {
                                            // Create a non-null Ellipse2D object
                                            Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                            Ellipse2D e2 = null;
                                            
                                            // The original code should return false when e2 is null and e1 is not
                                            // The mutant would return e1 == e2 (which is false in this case, but might not be in others)
                                            boolean result = ShapeUtilities.equal(e1, e2);
                                            
                                            // Assert that the result is false as per original behavior
                                            assertFalse(result);
                                            
                                            // Additional test to ensure the mutant is caught even if references are different
                                            Ellipse2D e3 = e1;  // same reference
                                            boolean resultSameRef = ShapeUtilities.equal(e1, e3);
                                            assertTrue(resultSameRef);  // This would be true for both original and mutant
                                            
                                            // But the key test is with null which should always return false when e1 is not null
                                            assertFalse(ShapeUtilities.equal(e1, null));
                                        }

    @Test
                                            public void testEqual_Arc2D_WhenFirstNonNullAndSecondNull_ShouldReturnFalse2() {
                                                // Arrange
                                                Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
                                                Arc2D a2 = null;
                                                
                                                // Act
                                                boolean result = ShapeUtilities.equal(a1, a2);
                                                
                                                // Assert
                                                assertFalse("Should return false when first Arc2D is non-null and second is null", result);
                                            }

    @Test
                                        public void testEqual_WhenFirstPolygonNonNullAndSecondNull_ShouldReturnFalse() {
                                            // Create a non-null polygon
                                            Polygon p1 = new Polygon();
                                            p1.addPoint(1, 2);
                                            p1.addPoint(3, 4);
                                            
                                            // Second polygon is null
                                            Polygon p2 = null;
                                            
                                            // The test should fail if the mutant is present because:
                                            // Original: returns false (correct)
                                            // Mutant: returns p1 == p2 (which is false, but for wrong reason)
                                            // We need to verify the method returns false for the right reason
                                            
                                            // Additional check to ensure the mutant is caught
                                            // Create another identical polygon to p1
                                            Polygon p3 = new Polygon();
                                            p3.addPoint(1, 2);
                                            p3.addPoint(3, 4);
                                            
                                            // First verify equal polygons work
                                            assertTrue(ShapeUtilities.equal(p1, p3));
                                            
                                            // Then test our case
                                            assertFalse(ShapeUtilities.equal(p1, p2));
                                            
                                            // This would catch the mutant because:
                                            // - The mutant would pass p1==p2 check (false)
                                            // - But we're verifying it's false for the correct reason (p2 is null)
                                            // - The test would fail if the mutant changed the logic to reference equality
                                        }

    @Test
                                        public void testEqual_WhenFirstNullAndSecondNotNull_ShouldReturnFalse1() {
                                            Shape nonNullShape = new Rectangle2D.Double(0, 0, 10, 10);
                                            boolean result = ShapeUtilities.equal(null, nonNullShape);
                                            assertFalse(result);  // Would catch mutant if it was in first null check
                                        }

    @Test
                                       public void testEqual_WhenFirstNonNullAndSecondNull_ShouldReturnFalse1() {
                                           // Create a non-null shape
                                           Shape nonNullShape = new Rectangle2D.Double(0, 0, 10, 10);
                                           
                                           // Test with non-null first shape and null second shape
                                           boolean result = ShapeUtilities.equal(nonNullShape, null);
                                           
                                           // Assert that it returns false (original behavior)
                                           // The mutant would also return false in this case, so this test wouldn't actually kill it
                                           // But this is the test that would be needed if the mutant were detectable
                                           assertFalse(result);
                                           
                                           // Additional test to verify the complete null handling
                                           assertTrue(ShapeUtilities.equal((Shape)null, (Shape)null));
                                           assertFalse(ShapeUtilities.equal(null, nonNullShape));
                                       }

    @Test
                                       public void testEqualWithNullShapes1() {
                                           // Test case for null comparison mutation
                                           Shape nullShape = null;
                                           Shape nonNullShape = new Line2D.Double(0, 0, 10, 10);
                                           
                                           // Case 1: Both shapes are null
                                           assertTrue("Two null shapes should be equal", 
                                               ShapeUtilities.equal(nullShape, nullShape));
                                           
                                           // Case 2: First shape is null, second is not
                                           assertFalse("Null and non-null shapes should not be equal", 
                                               ShapeUtilities.equal(nullShape, nonNullShape));
                                           
                                           // Case 3: Second shape is null, first is not
                                           assertFalse("Non-null and null shapes should not be equal", 
                                               ShapeUtilities.equal(nonNullShape, nullShape));
                                           
                                           // Case 4: Both shapes are non-null
                                           Shape anotherNonNullShape = new Line2D.Double(0, 0, 10, 10);
                                           assertTrue("Two identical non-null shapes should be equal", 
                                               ShapeUtilities.equal(nonNullShape, anotherNonNullShape));
                                       }

    @Test
                                       public void testEqualWithDifferentShapeTypes() {
                                           // Additional test cases for different shape types
                                           Shape line1 = new Line2D.Double(0, 0, 10, 10);
                                           Shape line2 = new Line2D.Double(0, 0, 10, 10);
                                           Shape ellipse = new Ellipse2D.Double(0, 0, 10, 10);
                                           
                                           assertTrue("Two identical lines should be equal",
                                               ShapeUtilities.equal(line1, line2));
                                           assertFalse("Different shape types should not be equal",
                                               ShapeUtilities.equal(line1, ellipse));
                                       }

    @Test
                                       public void testEqual_Line2D_NullCases() {
                                           // Test case where both lines are null (should return true)
                                           Line2D l1 = null;
                                           Line2D l2 = null;
                                           assertTrue("Two null lines should be equal", ShapeUtilities.equal(l1, l2));
                                           
                                           // Test case where first line is null and second is not (should return false)
                                           l2 = new Line2D.Double(new Point2D.Double(0, 0), new Point2D.Double(1, 1));
                                           assertFalse("Null line should not equal non-null line", ShapeUtilities.equal(l1, l2));
                                       }

    @Test
                                       public void testEqual_Line2D_NonNullCases() {
                                           // Create some test lines
                                           Point2D p1 = new Point2D.Double(0, 0);
                                           Point2D p2 = new Point2D.Double(1, 1);
                                           Line2D line1 = new Line2D.Double(p1, p2);
                                           Line2D line2 = new Line2D.Double(p1, p2);
                                           Line2D line3 = new Line2D.Double(p2, p1); // Different order
                                           Line2D line4 = new Line2D.Double(new Point2D.Double(0, 0), new Point2D.Double(2, 2));
                                           
                                           // Test equal lines
                                           assertTrue("Identical lines should be equal", ShapeUtilities.equal(line1, line2));
                                           
                                           // Test different lines
                                           assertFalse("Lines with different points should not be equal", ShapeUtilities.equal(line1, line3));
                                           assertFalse("Lines with different points should not be equal", ShapeUtilities.equal(line1, line4));
                                           
                                           // Test with one null line
                                           assertFalse("Non-null line should not equal null line", ShapeUtilities.equal(line1, null));
                                       }

    @Test
                                       public void testEqual_Ellipse2D_BothNull2() {
                                           // Test case where both ellipses are null
                                           boolean result = ShapeUtilities.equal((Ellipse2D)null, (Ellipse2D)null);
                                           assertTrue("Both null ellipses should be considered equal", result);
                                       }

    @Test
                                       public void testEqual_Ellipse2D_FirstNullSecondNotNull2() {
                                           // Test case where first ellipse is null and second is not null
                                           Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                           boolean result = ShapeUtilities.equal((Ellipse2D)null, e2);
                                           assertFalse("Null ellipse should not equal non-null ellipse", result);
                                       }

    @Test
                                       public void testEqual_Ellipse2D_SecondNull3() {
                                           // Test case where second ellipse is null (first not null)
                                           Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                           boolean result = ShapeUtilities.equal(e1, (Ellipse2D)null);
                                           assertFalse("Non-null ellipse should not equal null ellipse", result);
                                       }

    @Test
                                       public void testEqual_Ellipse2D_SameFrame() {
                                           // Test case where both ellipses have same frame
                                           Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                           Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                           boolean result = ShapeUtilities.equal(e1, e2);
                                           assertTrue("Ellipses with same frame should be equal", result);
                                       }

    @Test
                                       public void testEqual_Ellipse2D_DifferentFrame() {
                                           // Test case where ellipses have different frames
                                           Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                           Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                                           boolean result = ShapeUtilities.equal(e1, e2);
                                           assertFalse("Ellipses with different frames should not be equal", result);
                                       }

    @Test
                                       public void testEqual_Arc2D_BothNull2() {
                                           // Test case where both Arc2D objects are null
                                           assertTrue("Both null arcs should be considered equal", 
                                               ShapeUtilities.equal((Arc2D)null, (Arc2D)null));
                                       }

    @Test
                                       public void testEqual_Arc2D_FirstNullSecondNotNull2() {
                                           // Test case where first Arc2D is null and second is not null
                                           Arc2D nonNullArc = new Arc2D.Double();
                                           assertFalse("When first arc is null and second isn't, should return false",
                                               ShapeUtilities.equal((Arc2D)null, nonNullArc));
                                       }

    @Test
                                       public void testEqual_Arc2D_FirstNotNullSecondNull2() {
                                           // Test case where first Arc2D is not null and second is null
                                           Arc2D nonNullArc = new Arc2D.Double();
                                           assertFalse("When first arc is not null and second is null, should return false",
                                               ShapeUtilities.equal(nonNullArc, (Arc2D)null));
                                       }

    @Test
                                       public void testEqualPolygonBothNull() {
                                           // Test case where both polygons are null
                                           boolean result = ShapeUtilities.equal((Polygon)null, (Polygon)null);
                                           assertTrue("Two null polygons should be considered equal", result);
                                       }

    @Test
                                       public void testEqualPolygonFirstNullSecondNotNull() {
                                           // Test case where first polygon is null and second is not
                                           Polygon p2 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                           boolean result = ShapeUtilities.equal((Polygon)null, p2);
                                           assertFalse("When first polygon is null and second is not, should return false", result);
                                       }

    @Test
                                       public void testEqualPolygonSecondNullFirstNotNull() {
                                           // Test case where second polygon is null and first is not
                                           Polygon p1 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                           boolean result = ShapeUtilities.equal(p1, (Polygon)null);
                                           assertFalse("When second polygon is null and first is not, should return false", result);
                                       }

    @Test
                                       public void testEqualPolygonSameObject() {
                                           // Test case with same polygon object
                                           Polygon p = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                           boolean result = ShapeUtilities.equal(p, p);
                                           assertTrue("Same polygon object should be equal", result);
                                       }

    @Test
                                       public void testEqualPolygonEqualContents() {
                                           // Test case with different but equal polygons
                                           Polygon p1 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                           Polygon p2 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                           boolean result = ShapeUtilities.equal(p1, p2);
                                           assertTrue("Polygons with same contents should be equal", result);
                                       }

    @Test
                                       public void testEqualPolygonDifferentContents() {
                                           // Test case with different polygons
                                           Polygon p1 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                           Polygon p2 = new Polygon(new int[]{1,2,4}, new int[]{4,5,6}, 3);
                                           boolean result = ShapeUtilities.equal(p1, p2);
                                           assertFalse("Polygons with different contents should not be equal", result);
                                       }

    @Test
                                  public void testEqual_NullCases_ShouldDetectMutant() {
                                      // Create a mock Shape object for non-null cases
                                      Shape nonNullShape = mock(Shape.class);
                                      
                                      // Test case 1: Both shapes are null - should return true
                                      boolean result1 = ShapeUtilities.equal((Shape)null, (Shape)null);
                                      assertTrue("Both null shapes should be equal", result1);
                                      
                                      // Test case 2: First shape is null, second is not - should return false
                                      boolean result2 = ShapeUtilities.equal((Shape)null, nonNullShape);
                                      assertFalse("Null and non-null shapes should not be equal", result2);
                                      
                                      // Test case 3: First shape is not null, second is null - should return false
                                      boolean result3 = ShapeUtilities.equal(nonNullShape, (Shape)null);
                                      assertFalse("Non-null and null shapes should not be equal", result3);
                                      
                                      // Test case 4: Both shapes are not null - will be tested by other test cases
                                      // (This case is included for completeness but not strictly needed for this mutant)
                                      boolean result4 = ShapeUtilities.equal(nonNullShape, nonNullShape);
                                      // Don't assert here as the actual comparison depends on shape contents
                                  }

    @Test
                                  public void testEqualPolygonWithNonNull() {
                                      // Create two different polygons
                                      Polygon p1 = new Polygon(new int[]{0, 10, 10, 0}, new int[]{0, 0, 10, 10}, 4);
                                      Polygon p2 = new Polygon(new int[]{0, 20, 20, 0}, new int[]{0, 0, 20, 20}, 4);
                                      
                                      // Test case: Compare two different non-null polygons
                                      boolean result = ShapeUtilities.equal(p1, p2);
                                      assertFalse("Different polygons should not be equal", result);
                                      
                                      // Test case: Compare polygon with itself
                                      result = ShapeUtilities.equal(p1, p1);
                                      assertTrue("Polygon compared with itself should be equal", result);
                                  }

    @Test
                                  public void testEqual_Line2D_FirstNullSecondNotNull1() {
                                      // Create a non-null Line2D object
                                      Line2D line = new Line2D.Double(
                                          new Point2D.Double(1.0, 2.0),
                                          new Point2D.Double(3.0, 4.0)
                                      );
                                      
                                      // Test when l1 is null and l2 is not null
                                      boolean result = ShapeUtilities.equal(null, line);
                                      
                                      // Should return false since one is null and other isn't
                                      assertFalse("Expected false when first line is null and second is not", result);
                                  }

    @Test
                                  public void testEqual_Line2D_FirstNotNullSecondNull1() {
                                      // Create a non-null Line2D object
                                      Line2D line = new Line2D.Double(
                                          new Point2D.Double(1.0, 2.0),
                                          new Point2D.Double(3.0, 4.0)
                                      );
                                      
                                      // Test when l1 is not null and l2 is null
                                      boolean result = ShapeUtilities.equal(line, null);
                                      
                                      // Should return false since one is null and other isn't
                                      assertFalse("Expected false when first line is not null and second is null", result);
                                  }

    @Test
                                  public void testEqual_Ellipse2D_WhenFirstNullSecondNotNull() {
                                      // Setup
                                      Ellipse2D e1 = null;
                                      Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                      
                                      // Execute & Verify
                                      assertFalse("Should return false when first is null and second is not null", 
                                                 ShapeUtilities.equal(e1, e2));
                                  }

    @Test
                                  public void testEqual_Polygon_NullP1NonNullP() {
                                      // Create a non-null polygon
                                      int[] xpoints = {0, 10, 10, 0};
                                      int[] ypoints = {0, 0, 10, 10};
                                      Polygon p2 = new Polygon(xpoints, ypoints, 4);
                                      
                                      // Test when p1 is null and p2 is not null
                                      boolean result = ShapeUtilities.equal(null, p2);
                                      
                                      // Original would return false, mutant returns true
                                      assertFalse("Should return false when p1 is null and p2 is not null", result);
                                  }

    @Test
                              public void testEqual_FirstParameterNullSecondNotNull_ShouldReturnFalse() {
                                  // Arrange
                                  Shape p1 = null;
                                  Shape p2 = mock(Shape.class);
                                  
                                  // Act
                                  boolean result = ShapeUtilities.equal(p1, p2);
                                  
                                  // Assert
                                  assertFalse("Should return false when first shape is null and second is not", result);
                              }

    @Test
                             public void testEqualPolygonWithNull() {
                                 // Create a non-null polygon
                                 Polygon p1 = new Polygon(new int[]{0, 10, 10, 0}, new int[]{0, 0, 10, 10}, 4);
                                 
                                 // Test case 1: Compare non-null polygon with null
                                 boolean result = ShapeUtilities.equal(p1, (Polygon) null);
                                 assertFalse("Comparing polygon with null should return false", result);
                                 
                                 // Test case 2: Compare null with non-null polygon
                                 result = ShapeUtilities.equal((Polygon) null, p1);
                                 assertFalse("Comparing null with polygon should return false", result);
                                 
                                 // Test case 3: Compare two null polygons
                                 result = ShapeUtilities.equal((Polygon) null, (Polygon) null);
                                 assertTrue("Comparing two null polygons should return true", result);
                             }

    @Test
                             public void testEqual_Line2D_BothNull1() {
                                 // Test when both lines are null
                                 boolean result = ShapeUtilities.equal((Line2D) null, (Line2D) null);
                                 
                                 // Should return true since both are null
                                 assertTrue("Expected true when both lines are null", result);
                             }

    @Test
                             public void testEqual_Arc2D_NullCases() {
                                 // Case 1: a1 is null, a2 is not null
                                 Arc2D a2 = mock(Arc2D.class);
                                 when(a2.getFrame()).thenReturn(new Rectangle2D.Double());
                                 when(a2.getAngleStart()).thenReturn(0.0);
                                 when(a2.getAngleExtent()).thenReturn(0.0);
                                 when(a2.getArcType()).thenReturn(0);
                                 assertFalse("Should return false when a1 is null and a2 is not null", 
                                            ShapeUtilities.equal((Arc2D)null, a2));
                                 
                                 // Case 2: both a1 and a2 are null
                                 assertTrue("Should return true when both arcs are null", 
                                           ShapeUtilities.equal((Arc2D)null, (Arc2D)null));
                                 
                                 // Case 3: a1 is not null, a2 is null
                                 Arc2D a1 = mock(Arc2D.class);
                                 when(a1.getFrame()).thenReturn(new Rectangle2D.Double());
                                 when(a1.getAngleStart()).thenReturn(0.0);
                                 when(a1.getAngleExtent()).thenReturn(0.0);
                                 when(a1.getArcType()).thenReturn(0);
                                 assertFalse("Should return false when a1 is not null and a2 is null", 
                                            ShapeUtilities.equal(a1, (Arc2D)null));
                             }

    @Test
                             public void testEqual_Polygon_BothNull1() {
                                 // Test when both polygons are null
                                 boolean result = ShapeUtilities.equal((Polygon)null, (Polygon)null);
                                 
                                 // Both original and mutant would return true
                                 assertTrue("Should return true when both polygons are null", result);
                             }

    @Test
                             public void testEqual_Line2D_FirstNonNullSecondNull_ShouldReturnFalse1() {
                                 // Create a non-null Line2D object
                                 Line2D line1 = new Line2D.Double(
                                     new Point2D.Double(1.0, 2.0), 
                                     new Point2D.Double(3.0, 4.0)
                                 );
                                 
                                 // Test with line1 non-null and line2 null
                                 boolean result = ShapeUtilities.equal(line1, null);
                                 
                                 // Assert that it should return false (original behavior)
                                 // This will fail if the mutant is present (which returns true)
                                 assertFalse("Comparing non-null line with null should return false", result);
                             }

    @Test
                             public void testEqual_Line2D_FirstNullSecondNonNull_ShouldReturnFalse1() {
                                 // Create a non-null Line2D object
                                 Line2D line2 = new Line2D.Double(
                                     new Point2D.Double(1.0, 2.0), 
                                     new Point2D.Double(3.0, 4.0)
                                 );
                                 
                                 // Test with line1 null and line2 non-null
                                 boolean result = ShapeUtilities.equal(null, line2);
                                 
                                 // Assert that it should return false
                                 assertFalse("Comparing null with non-null line should return false", result);
                             }

    @Test
                             public void testEqual_Ellipse2D_WhenFirstNonNullAndSecondNull_ShouldReturnFalse2() {
                                 // Arrange
                                 Ellipse2D nonNullEllipse = mock(Ellipse2D.class);
                                 
                                 // Act
                                 boolean result = ShapeUtilities.equal(nonNullEllipse, null);
                                 
                                 // Assert
                                 assertFalse("Should return false when first ellipse is non-null and second is null", result);
                             }

    @Test
                             public void testEqual_Ellipse2D_WhenFirstNullAndSecondNonNull_ShouldReturnFalse1() {
                                 // Arrange
                                 Ellipse2D nonNullEllipse = mock(Ellipse2D.class);
                                 
                                 // Act
                                 boolean result = ShapeUtilities.equal(null, nonNullEllipse);
                                 
                                 // Assert
                                 assertFalse("Should return false when first ellipse is null and second is non-null", result);
                             }

    @Test
                             public void testEqual_Ellipse2D_WhenFramesDiffer_ShouldReturnFalse() {
                                 // Arrange
                                 Ellipse2D e1 = mock(Ellipse2D.class);
                                 Ellipse2D e2 = mock(Ellipse2D.class);
                                 when(e1.getFrame()).thenReturn(mock(Rectangle2D.class));
                                 when(e2.getFrame()).thenReturn(mock(Rectangle2D.class));
                                 
                                 // Act
                                 boolean result = ShapeUtilities.equal(e1, e2);
                                 
                                 // Assert
                                 assertFalse("Should return false when frames are different", result);
                             }

    @Test
                             public void testEqual_Ellipse2D_WhenFramesEqual_ShouldReturnTrue1() {
                                 // Arrange
                                 Ellipse2D e1 = mock(Ellipse2D.class);
                                 Ellipse2D e2 = mock(Ellipse2D.class);
                                 Rectangle2D sameFrame = mock(Rectangle2D.class);
                                 when(e1.getFrame()).thenReturn(sameFrame);
                                 when(e2.getFrame()).thenReturn(sameFrame);
                                 
                                 // Act
                                 boolean result = ShapeUtilities.equal(e1, e2);
                                 
                                 // Assert
                                 assertTrue("Should return true when frames are equal", result);
                             }

    @Test
                             public void testEqual_Arc2D_WhenFirstNotNullAndSecondNull_ShouldReturnFalse() {
                                 // Create a mock Arc2D object for a1
                                 Arc2D a1 = mock(Arc2D.class);
                                 when(a1.getFrame()).thenReturn(mock(java.awt.geom.Rectangle2D.class));
                                 when(a1.getAngleStart()).thenReturn(0.0);
                                 when(a1.getAngleExtent()).thenReturn(90.0);
                                 when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                 
                                 // a2 is null
                                 Arc2D a2 = null;
                                 
                                 // Test the behavior - should return false when a1 is not null and a2 is null
                                 assertFalse(ShapeUtilities.equal(a1, a2));
                             }

    @Test
                             public void testEqualPolygonWhenFirstNotNullAndSecondNull() {
                                 // Create a non-null polygon
                                 int[] xpoints = {0, 10, 10, 0};
                                 int[] ypoints = {0, 0, 10, 10};
                                 Polygon p1 = new Polygon(xpoints, ypoints, 4);
                                 
                                 // Second polygon is null
                                 Polygon p2 = null;
                                 
                                 // The original method should return false when p1 is not null and p2 is null
                                 // The mutant would return true in this case
                                 assertFalse("Should return false when first polygon is not null and second is null", 
                                            ShapeUtilities.equal(p1, p2));
                             }

    @Test
                             public void testEqual_FirstShapeNonNullSecondShapeNull_ShouldReturnFalse() {
                                 // Create a non-null shape (we'll use Rectangle2D as a concrete implementation)
                                 Shape nonNullShape = new Rectangle2D.Double(0, 0, 10, 10);
                                 
                                 // Test when first shape is non-null and second is null
                                 boolean result = ShapeUtilities.equal(nonNullShape, null);
                                 
                                 // Assert that it returns false (original behavior)
                                 assertFalse("A non-null shape should not be equal to null", result);
                             }

    @Test
                        public void testEqual_Line2D_BothNull_ShouldReturnTrue1() {
                            // Test with both lines null
                            boolean result = ShapeUtilities.equal((Line2D) null, (Line2D) null);
                            
                            // Assert that it should return true
                            assertTrue("Comparing two null lines should return true", result);
                        }

    @Test
                        public void testEqual_Ellipse2D_WhenBothNull_ShouldReturnTrue2() {
                            // Act
                            boolean result = ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null);
                            
                            // Assert
                            assertTrue("Should return true when both ellipses are null", result);
                        }

    @Test
                    public void testEqualWithNonHandledShapeTypes() {
                        // Create two different Rectangle2D objects (not one of the explicitly handled types)
                        java.awt.geom.Rectangle2D rect1 = new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10);
                        java.awt.geom.Rectangle2D rect2 = new java.awt.geom.Rectangle2D.Double(0, 0, 20, 20);
                        
                        // The original method should return false since they're different
                        // The mutant would return true here
                        assertFalse("Different Rectangle2D objects should not be equal", 
                                   ShapeUtilities.equal((Shape)rect1, (Shape)rect2));
                        
                        // Also test with null inputs
                        assertFalse("Null shapes should not be equal", 
                                   ShapeUtilities.equal(null, (Shape)rect1));
                        assertFalse("Null shapes should not be equal", 
                                   ShapeUtilities.equal((Shape)rect1, null));
                        assertFalse("Both null shapes should not be equal (though ObjectUtilities might handle differently)", 
                                   ShapeUtilities.equal((Shape)null, (Shape)null));
                    }

    @Test
                    public void testEqualWithUnsupportedShapeTypes() {
                        // Create two Rectangle2D objects (not explicitly handled in the method)
                        Shape rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                        Shape rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                        
                        // The original method should return false for unsupported types
                        // The mutant would return true (!false)
                        assertFalse("Should return false for unsupported shape types", 
                                   ShapeUtilities.equal(rect1, rect2));
                        
                        // Also test with different rectangles to ensure it's not just comparing references
                        Shape rect3 = new Rectangle2D.Double(5, 5, 10, 10);
                        assertFalse("Should return false for different unsupported shapes",
                                   ShapeUtilities.equal(rect1, rect3));
                    }

    @Test
                    public void testEqual_Line2D_WhenFirstNotNullSecondNull1() {
                        // Create a non-null Line2D object
                        Line2D l1 = new Line2D.Double(
                            new Point2D.Double(1.0, 2.0),
                            new Point2D.Double(3.0, 4.0)
                        );
                        
                        // Second Line2D is null
                        Line2D l2 = null;
                        
                        // The correct behavior should return false when l1 is not null and l2 is null
                        assertFalse(ShapeUtilities.equal(l1, l2));
                        
                        // The mutant would return true (!false) in this case, so this test would fail on the mutant
                    }

    @Test
                    public void testEqual_Ellipse2D_SecondNull4() {
                        // Create a non-null Ellipse2D object
                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                        
                        // Test when e1 is not null and e2 is null
                        boolean result = ShapeUtilities.equal(e1, null);
                        
                        // Original method should return false, mutant returns true
                        assertFalse("Non-null ellipse should not equal null", result);
                    }

    @Test
                    public void testEqual_Ellipse2D_FirstNull1() {
                        // Create a non-null Ellipse2D object
                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                        
                        // Test when e1 is null and e2 is not null
                        boolean result = ShapeUtilities.equal(null, e2);
                        assertFalse("Null should not equal non-null ellipse", result);
                    }

    @Test
                    public void testEqual_Ellipse2D_SameFrame1() {
                        // Create two ellipses with same frame
                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                        
                        boolean result = ShapeUtilities.equal(e1, e2);
                        assertTrue("Ellipses with same frame should be equal", result);
                    }

    @Test
                    public void testEqual_Ellipse2D_DifferentFrame1() {
                        // Create two ellipses with different frames
                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                        
                        boolean result = ShapeUtilities.equal(e1, e2);
                        assertFalse("Ellipses with different frames should not be equal", result);
                    }

    @Test
                    public void testEqual_WhenFirstArcNonNullAndSecondArcNull_ShouldReturnFalse() {
                        // Arrange
                        Arc2D a1 = mock(Arc2D.class);
                        Arc2D a2 = null;
                        
                        // Act
                        boolean result = ShapeUtilities.equal(a1, a2);
                        
                        // Assert
                        assertFalse("Expected false when first arc is non-null and second is null", result);
                    }

    @Test
                    public void testEqual_WhenBothArcsNull_ShouldReturnTrue() {
                        // Arrange
                        Arc2D a1 = null;
                        Arc2D a2 = null;
                        
                        // Act
                        boolean result = ShapeUtilities.equal(a1, a2);
                        
                        // Assert
                        assertTrue("Expected true when both arcs are null", result);
                    }

    @Test
                    public void testEqual_WhenFirstArcNullAndSecondArcNonNull_ShouldReturnFalse() {
                        // Arrange
                        Arc2D a1 = null;
                        Arc2D a2 = mock(Arc2D.class);
                        
                        // Act
                        boolean result = ShapeUtilities.equal(a1, a2);
                        
                        // Assert
                        assertFalse("Expected false when first arc is null and second is non-null", result);
                    }

    @Test
                public void testEqual_WhenFirstPolygonNotNullAndSecondNull_ShouldReturnFalse5() {
                    // Arrange
                    Polygon p1 = new Polygon();
                    p1.addPoint(1, 1);
                    Polygon p2 = null;
                    
                    // Act
                    boolean result = ShapeUtilities.equal(p1, p2);
                    
                    // Assert
                    assertFalse("Should return false when first polygon is not null and second is null", result);
                }

    @Test
               public void testEqual_Ellipse2D_BothNull3() {
                   // Test when both are null
                   boolean result = ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null);
                   assertTrue("Two null ellipses should be considered equal", result);
               }

    @Test
               public void testEqual_NonNullWithNull_ShouldReturnFalse() {
                   // Create a non-null shape (using Rectangle2D as a concrete implementation)
                   Shape nonNullShape = new java.awt.geom.Rectangle2D.Double();
                   
                   // Test when p1 is non-null and p2 is null
                   boolean result = ShapeUtilities.equal(nonNullShape, null);
                   
                   // Assert that the result is false (original behavior)
                   // This will catch the mutant that returns true in this case
                   assertFalse("Method should return false when comparing non-null shape with null", result);
               }

    @Test
               public void testEqual_NonSpecifiedShapeTypes_ReturnsCorrectEquality() {
                   // Create two different Rectangle2D objects (not one of the specifically handled types)
                   Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                   Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 20, 20);
                   
                   // Test with original code - should return false since rectangles are different
                   // With mutant (!false), this would incorrectly return true
                   boolean result = ShapeUtilities.equal(rect1, rect2);
                   
                   assertFalse("Method should return false for unequal Rectangle2D objects", result);
               }

    @Test
               public void testEqual_NonSpecifiedShapeTypes_ReturnsTrueForEqualObjects() {
                   // Create two equal Rectangle2D objects to verify the fallback works correctly
                   Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                   Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                   
                   boolean result = ShapeUtilities.equal(rect1, rect2);
                   
                   assertTrue("Method should return true for equal Rectangle2D objects", result);
               }

    @Test
           public void testEqual_Line2D_OneNull1() {
               // Create a non-null Line2D object
               Line2D line1 = new Line2D.Double(0, 0, 10, 10);
               
               // Test case where l1 is not null and l2 is null
               boolean result = ShapeUtilities.equal(line1, null);
               
               // Assert that the result should be false
               assertFalse("Method should return false when first line is not null and second is null", result);
           }

    @Test
               public void testEqual_Ellipse2D_NonNullVsNull() {
                   // Create a non-null Ellipse2D object
                   Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                   Ellipse2D e2 = null;
                   
                   // The original method should return false when comparing non-null with null
                   // The mutant would return true here
                   assertFalse("Should return false when comparing non-null with null", 
                              ShapeUtilities.equal(e1, e2));
               }

    @Test
               public void testEqual_Ellipse2D_NullVsNonNull() {
                   // Test case where first is null and second is not
                   Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                   assertFalse("Should return false when comparing null with non-null",
                              ShapeUtilities.equal(null, e2));
               }

    @Test
               public void testEqual_Ellipse2D_SameFrame2() {
                   // Test case with two ellipses with same frame
                   Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                   Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                   assertTrue("Should return true for equal frames",
                             ShapeUtilities.equal(e1, e2));
               }

    @Test
               public void testEqual_Ellipse2D_DifferentFrame2() {
                   // Test case with two ellipses with different frames
                   Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                   Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                   assertFalse("Should return false for different frames",
                              ShapeUtilities.equal(e1, e2));
               }

    @Test
               public void testEqual_WhenA1NotNullAndA2Null_ShouldReturnFalse4() {
                   // Create a non-null Arc2D object for a1
                   Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
                   Arc2D a2 = null;
                   
                   // The original method should return false when a1 is not null and a2 is null
                   // The mutant would return true in this case
                   boolean result = ShapeUtilities.equal(a1, a2);
                   
                   assertFalse("Should return false when a1 is not null and a2 is null", result);
               }

    @Test
               public void testEqualPolygonWithNonNullP1AndNullP() {
                   // Create a non-null polygon for p1
                   Polygon p1 = new Polygon();
                   p1.addPoint(1, 2);
                   p1.addPoint(3, 4);
                   
                   // p2 remains null
                   Polygon p2 = null;
                   
                   // The original method should return false when p1 is not null and p2 is null
                   // The mutant would return true here
                   assertFalse("Should return false when first polygon is non-null and second is null", 
                              ShapeUtilities.equal(p1, p2));
               }

    @Test
               public void testEqualPolygonSameObject1() {
                   Polygon p = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                   assertTrue("Should return true for same polygon object", 
                             ShapeUtilities.equal(p, p));
               }

    @Test
               public void testEqualPolygonDifferentPoints() {
                   Polygon p1 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                   Polygon p2 = new Polygon(new int[]{1,2}, new int[]{3,5}, 2);
                   assertFalse("Should return false when ypoints differ", 
                              ShapeUtilities.equal(p1, p2));
               }

    @Test
          public void testEqual_Ellipse2D_NullVsNull() {
              // Test case where both are null
              assertTrue("Should return true when comparing null with null",
                        ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
          }

    @Test
          public void testEqualPolygonBothNull1() {
              assertTrue("Should return true when both polygons are null", 
                        ShapeUtilities.equal((Polygon)null, (Polygon)null));
          }

    @Test
          public void testEqual_FirstNonNullSecondNull_ShouldReturnFalse2() {
              // Arrange
              Shape p1 = new Rectangle2D.Double(0, 0, 10, 10); // non-null shape
              Shape p2 = null;
              
              // Act
              boolean result = ShapeUtilities.equal(p1, p2);
              
              // Assert
              assertFalse("Should return false when first shape is non-null and second is null", result);
          }

    @Test
          public void testEqual_NonHandledShapeTypes_ShouldUseObjectUtilitiesEqual() {
              // Create two different Rectangle2D objects (not one of the specifically handled types)
              Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
              Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 20, 20);
              
              // The original method should return false since the rectangles are different
              // The mutant would return true here
              assertFalse("Different Rectangle2D objects should not be equal", 
                         ShapeUtilities.equal(rect1, rect2));
              
              // Also test with equal rectangles for completeness
              Rectangle2D rect3 = new Rectangle2D.Double(0, 0, 10, 10);
              assertTrue("Equal Rectangle2D objects should be equal",
                        ShapeUtilities.equal(rect1, rect3));
          }

    @Test
          public void testEqual_Line2D_FirstNonNullSecondNull_ShouldReturnFalse2() {
              // Setup
              Line2D l1 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
              Line2D l2 = null;
              
              // Execute
              boolean result = ShapeUtilities.equal(l1, l2);
              
              // Verify
              assertFalse("Comparing non-null Line2D with null should return false", result);
          }

    @Test
      public void testEqual_Ellipse2D_WhenFirstNonNullAndSecondNull_ShouldReturnFalse3() {
          // Create a non-null Ellipse2D object
          Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
          Ellipse2D e2 = null;
          
          // Test the behavior
          boolean result = ShapeUtilities.equal(e1, e2);
          
          // Assert that it returns false (original correct behavior)
          // This will catch the mutant that returns true
          assertFalse(result);
      }

    @Test
          public void testEqual_Arc2D_WhenFirstNotNullAndSecondNull_ShouldReturnFalse1() {
              // Arrange
              Arc2D a1 = mock(Arc2D.class);
              Arc2D a2 = null;
              
              // Act
              boolean result = ShapeUtilities.equal(a1, a2);
              
              // Assert
              assertFalse("Should return false when first Arc2D is not null and second is null", result);
          }

    @Test
          public void testEqualPolygonWithNull1() {
              // Create a non-null polygon
              int[] xpoints = {1, 2, 3};
              int[] ypoints = {4, 5, 6};
              Polygon p1 = new Polygon(xpoints, ypoints, 3);
              
              // Test case where p1 is non-null and p2 is null
              boolean result = ShapeUtilities.equal(p1, null);
              
              // Original behavior should return false, mutant would return true
              assertFalse("Comparing non-null polygon with null should return false", result);
          }

    @Test
      public void testEqual_FirstNonNullSecondNull_ShouldReturnFalse3() {
          // Create a mock Shape object for p1
          Shape p1 = mock(Shape.class);
          // p2 is null
          
          // Test the method
          boolean result = ShapeUtilities.equal(p1, null);
          
          // Assert that it should return false when first is non-null and second is null
          assertFalse("Expected false when first shape is non-null and second is null", result);
          
          // This test will catch the mutant because:
          // Original code: returns false (correct)
          // Mutant code: returns true (incorrect)
          // Our assertion expects false, so it will fail on the mutant
      }

    @Test
     public void testEqualWithUnhandledShapeTypes() {
         // Create two different Rectangle2D objects (not handled in specific cases)
         Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
         Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 20, 20);
         
         // Also test with null inputs
         Rectangle2D rect3 = null;
         
         // Test case 1: Different rectangles should return false
         assertFalse(ShapeUtilities.equal(rect1, rect2));
         
         // Test case 2: Same rectangle should return true (via ObjectUtilities.equal)
         assertTrue(ShapeUtilities.equal(rect1, rect1));
         
         // Test case 3: First shape null should return false
         assertFalse(ShapeUtilities.equal(rect3, rect1));
         
         // Test case 4: Second shape null should return false
         assertFalse(ShapeUtilities.equal(rect1, rect3));
         
         // Test case 5: Both null should return true (via ObjectUtilities.equal)
         assertTrue(ShapeUtilities.equal(rect3, rect3));
     }

    @Test
         public void testEqual_Line2D_WhenL1NotNullAndL2Null_ShouldReturnFalse1() {
             // Create a non-null Line2D object for l1
             Line2D l1 = new Line2D.Double(
                 new Point2D.Double(1.0, 2.0), 
                 new Point2D.Double(3.0, 4.0)
             );
             
             // l2 is null
             Line2D l2 = null;
             
             // The method should return false when l1 is not null and l2 is null
             // This will catch the mutant that returns true in this case
             assertFalse(ShapeUtilities.equal(l1, l2));
         }

    @Test
         public void testEqual_Ellipse2D_WhenE1NotNullAndE2Null_ShouldReturnFalse1() {
             // Setup
             Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
             Ellipse2D e2 = null;
             
             // Execute
             boolean result = ShapeUtilities.equal(e1, e2);
             
             // Verify
             assertFalse("Should return false when e1 is not null and e2 is null", result);
         }

    @Test
         public void testEqual_WhenA1NotNullAndA2Null_ShouldReturnFalse5() {
             // Create a non-null Arc2D object for a1
             Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
             
             // Test when a1 is not null and a2 is null
             boolean result = ShapeUtilities.equal(a1, null);
             
             // Assert that it should return false (original behavior)
             // This will catch the mutant that returns !false (true) in this case
             assertFalse(result);
         }

    @Test
         public void testEqual_WhenA1NullAndA2NotNull_ShouldReturnFalse2() {
             Arc2D a2 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
             assertFalse(ShapeUtilities.equal(null, a2));
         }

    @Test
         public void testEqual_WhenArcsEqual_ShouldReturnTrue() {
             Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
             Arc2D a2 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
             assertTrue(ShapeUtilities.equal(a1, a2));
         }

    @Test
         public void testEqual_WhenFramesDifferent_ShouldReturnFalse1() {
             Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
             Arc2D a2 = new Arc2D.Double(10, 10, 100, 100, 0, 90, Arc2D.PIE);
             assertFalse(ShapeUtilities.equal(a1, a2));
         }

    @Test
         public void testEqual_WhenAngleStartsDifferent_ShouldReturnFalse() {
             Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
             Arc2D a2 = new Arc2D.Double(0, 0, 100, 100, 10, 90, Arc2D.PIE);
             assertFalse(ShapeUtilities.equal(a1, a2));
         }

    @Test
         public void testEqual_WhenAngleExtentsDifferent_ShouldReturnFalse() {
             Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
             Arc2D a2 = new Arc2D.Double(0, 0, 100, 100, 0, 100, Arc2D.PIE);
             assertFalse(ShapeUtilities.equal(a1, a2));
         }

    @Test
         public void testEqual_WhenArcTypesDifferent_ShouldReturnFalse() {
             Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
             Arc2D a2 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.CHORD);
             assertFalse(ShapeUtilities.equal(a1, a2));
         }

    @Test
         public void testEqual_PolygonWithNull1() {
             // Create a non-null polygon
             int[] xpoints = {1, 2, 3};
             int[] ypoints = {4, 5, 6};
             Polygon p1 = new Polygon(xpoints, ypoints, 3);
             
             // Test case where p1 is not null but p2 is null
             boolean result = ShapeUtilities.equal(p1, null);
             
             // Assert that it should return false (original behavior)
             // This will catch the mutant that returns true
             assertFalse("Should return false when first polygon is not null but second is null", result);
         }

    @Test
    public void testEqual_WhenBothNull_ShouldReturnTrue4() {
        Arc2D a1 = null;
        Arc2D a2 = null;
        assertTrue(ShapeUtilities.equal(a1, a2));
    }

    @Test
    public void testEqual_WhenFirstShapeNotNullAndSecondNull_ShouldReturnFalse5() {
        // Create a non-null shape (using Path2D as a concrete implementation)
        Shape nonNullShape = new java.awt.geom.Path2D.Double();
        
        // Test the case where p1 is not null and p2 is null
        boolean result = ShapeUtilities.equal(nonNullShape, null);
        
        // Assert that the result should be false (original behavior)
        // This will catch the mutant that returns true in this case
        assertFalse("Should return false when first shape is not null and second is null", result);
    }


}
