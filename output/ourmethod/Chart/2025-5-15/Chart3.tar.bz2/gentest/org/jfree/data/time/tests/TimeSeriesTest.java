package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.event.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_EmptySeries_ReturnsEmptyCopy() {
                                                                                                                                                                                                                                                                      TimeSeries emptySeries = new TimeSeries("Empty Series");
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_NullStartArgument() {
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                      thrown.expectMessage("Null 'start' argument.");
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_NullEndArgument() {
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                      thrown.expectMessage("Null 'end' argument.");
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_StartAfterEnd() {
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                                                                                                                                      RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                                                                                                                                      when(start.compareTo(end)).thenReturn(1);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                      thrown.expectMessage("Requires start on or before end.");
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_EmptyRange_StartAfterLastItem() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                      // Setup series with some data
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      Day day1 = new Day(1, 1, 2000);
                                                                                                                                                                                                                                                                      Day day2 = new Day(2, 1, 2000);
                                                                                                                                                                                                                                                                      series.add(day1, 1.0);
                                                                                                                                                                                                                                                                      series.add(day2, 2.0);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Create start period after last item
                                                                                                                                                                                                                                                                      Day start = new Day(3, 1, 2000);
                                                                                                                                                                                                                                                                      Day end = new Day(4, 1, 2000);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      TimeSeries result = series.createCopy(start, end);
                                                                                                                                                                                                                                                                      assertEquals(0, result.getItemCount());
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_EmptyRange_EndBeforeFirstItem() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                      // Setup series with some data
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      Day day1 = new Day(2, 1, 2000);
                                                                                                                                                                                                                                                                      Day day2 = new Day(3, 1, 2000);
                                                                                                                                                                                                                                                                      series.add(day1, 1.0);
                                                                                                                                                                                                                                                                      series.add(day2, 2.0);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Create end period before first item
                                                                                                                                                                                                                                                                      Day start = new Day(1, 1, 2000);
                                                                                                                                                                                                                                                                      Day end = new Day(1, 1, 2000);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      TimeSeries result = series.createCopy(start, end);
                                                                                                                                                                                                                                                                      assertEquals(0, result.getItemCount());
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_NormalRange() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                      // Setup series with data
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      Day day1 = new Day(1, 1, 2000);
                                                                                                                                                                                                                                                                      Day day2 = new Day(2, 1, 2000);
                                                                                                                                                                                                                                                                      Day day3 = new Day(3, 1, 2000);
                                                                                                                                                                                                                                                                      series.add(day1, 1.0);
                                                                                                                                                                                                                                                                      series.add(day2, 2.0);
                                                                                                                                                                                                                                                                      series.add(day3, 3.0);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Create copy of middle range
                                                                                                                                                                                                                                                                      TimeSeries result = series.createCopy(day1, day2);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      assertEquals(2, result.getItemCount());
                                                                                                                                                                                                                                                                      assertEquals(1.0, result.getValue(0).doubleValue(), 0.0001);
                                                                                                                                                                                                                                                                      assertEquals(2.0, result.getValue(1).doubleValue(), 0.0001);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_EndPeriodNotInSeries() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                      // Setup series with data
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      Day day1 = new Day(1, 1, 2000);
                                                                                                                                                                                                                                                                      Day day2 = new Day(2, 1, 2000);
                                                                                                                                                                                                                                                                      Day day3 = new Day(3, 1, 2000);
                                                                                                                                                                                                                                                                      series.add(day1, 1.0);
                                                                                                                                                                                                                                                                      series.add(day2, 2.0);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // End period is not in series (between day2 and day3)
                                                                                                                                                                                                                                                                      Day start = new Day(1, 1, 2000);
                                                                                                                                                                                                                                                                      Day end = new Day(3, 1, 2000);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      TimeSeries result = series.createCopy(start, end);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      assertEquals(2, result.getItemCount());
                                                                                                                                                                                                                                                                      assertEquals(1.0, result.getValue(0).doubleValue(), 0.0001);
                                                                                                                                                                                                                                                                      assertEquals(2.0, result.getValue(1).doubleValue(), 0.0001);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_StartAndEndSame() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                      // Setup series with data
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      Day day1 = new Day(1, 1, 2000);
                                                                                                                                                                                                                                                                      Day day2 = new Day(2, 1, 2000);
                                                                                                                                                                                                                                                                      series.add(day1, 1.0);
                                                                                                                                                                                                                                                                      series.add(day2, 2.0);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Start and end are the same and exist in series
                                                                                                                                                                                                                                                                      TimeSeries result = series.createCopy(day1, day1);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      assertEquals(1, result.getItemCount());
                                                                                                                                                                                                                                                                      assertEquals(1.0, result.getValue(0).doubleValue(), 0.0001);
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                  public void testCreateCopy_StartAndEndSameNotInSeries() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                      // Setup series with data
                                                                                                                                                                                                                                                                      TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                                      Day day1 = new Day(1, 1, 2000);
                                                                                                                                                                                                                                                                      Day day2 = new Day(3, 1, 2000);
                                                                                                                                                                                                                                                                      series.add(day1, 1.0);
                                                                                                                                                                                                                                                                      series.add(day2, 2.0);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      // Start and end are the same but not in series
                                                                                                                                                                                                                                                                      Day startEnd = new Day(2, 1, 2000);
                                                                                                                                                                                                                                                                      TimeSeries result = series.createCopy(startEnd, startEnd);
                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                      assertEquals(0, result.getItemCount());
                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                          public void testCreateCopy_NegativeStartIndex_ThrowsException() {
                                                                                                                                                                                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                                                                              TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                              thrown.expectMessage("Requires start >= 0.");
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                          public void testCreateCopy_SingleItem_CorrectCopy() {
                                                                                                                                                                                                                                                              // Create test series and add one item
                                                                                                                                                                                                                                                              TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                              RegularTimePeriod period = new Day(); // Assuming Day is available
                                                                                                                                                                                                                                                              TimeSeriesDataItem item1 = new TimeSeriesDataItem(period, 100.0);
                                                                                                                                                                                                                                                              timeSeries.add(item1);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create copy and verify
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                          public void testCreateCopy_MultipleItems_CorrectCopy() {
                                                                                                                                                                                                                                                              // Create test time series
                                                                                                                                                                                                                                                              TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create test items
                                                                                                                                                                                                                                                              RegularTimePeriod period1 = new Day(1, 1, 2023);
                                                                                                                                                                                                                                                              TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 10.0);
                                                                                                                                                                                                                                                              RegularTimePeriod period2 = new Day(2, 1, 2023);
                                                                                                                                                                                                                                                              TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 20.0);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Add items to series
                                                                                                                                                                                                                                                              timeSeries.add(item1);
                                                                                                                                                                                                                                                              timeSeries.add(item2);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create copy and verify
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                          public void testCreateCopy_EntireRange_CorrectCopy() {
                                                                                                                                                                                                                                                              // Create test time series
                                                                                                                                                                                                                                                              TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create test items
                                                                                                                                                                                                                                                              RegularTimePeriod period1 = new Day(1, 1, 2023);
                                                                                                                                                                                                                                                              TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 10.0);
                                                                                                                                                                                                                                                              RegularTimePeriod period2 = new Day(2, 1, 2023);
                                                                                                                                                                                                                                                              TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 20.0);
                                                                                                                                                                                                                                                              RegularTimePeriod period3 = new Day(3, 1, 2023);
                                                                                                                                                                                                                                                              TimeSeriesDataItem item3 = new TimeSeriesDataItem(period3, 30.0);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Add items to series
                                                                                                                                                                                                                                                              timeSeries.add(item1);
                                                                                                                                                                                                                                                              timeSeries.add(item2);
                                                                                                                                                                                                                                                              timeSeries.add(item3);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Test the copy
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Verify the copy
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                          public void testCreateCopy_ItemsAreCloned_NotSameReferences() {
                                                                                                                                                                                                                                                              // Create and initialize a time series with one item
                                                                                                                                                                                                                                                              TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                                                                                                              RegularTimePeriod period = new Day();
                                                                                                                                                                                                                                                              TimeSeriesDataItem item = new TimeSeriesDataItem(period, 100.0);
                                                                                                                                                                                                                                                              timeSeries.add(item);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Create copy and test
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                                          public void testCreateCopy_StartEqualsEnd_CorrectSingleItemCopy() {
                                                                                                                                                                                                                                                              // Create test series
                                                                                                                                                                                                                                                              TimeSeries series = new TimeSeries("Test");
                                                                                                                                                                                                                                                              RegularTimePeriod period = new Day(); // Assuming Day is available
                                                                                                                                                                                                                                                              TimeSeriesDataItem item2 = new TimeSeriesDataItem(period, 100.0);
                                                                                                                                                                                                                                                              series.add(item2);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Test createCopy
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Verify results
                                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                  public void testCreateCopy_EndLessThanStart_ThrowsException() {
                                                                                                                                                                                                                      TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                          fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                          assertEquals("Requires start <= end.", e.getMessage());
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                 public void testCreateCopyWithStartGreaterThanEndShouldThrow() throws CloneNotSupportedException {
                                                                                                                                                                     TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                     series.createCopy(1, 0); // start > end should always throw
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testCreateCopyWithEqualStartAndEnd() {
                                                                                                                                                                     // Setup test data
                                                                                                                                                                     TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                     RegularTimePeriod period = mock(RegularTimePeriod.class);
                                                                                                                                                                     
                                                                                                                                                                     // Mock behavior for compareTo
                                                                                                                                                                     when(period.compareTo(period)).thenReturn(0);
                                                                                                                                                                     
                                                                                                                                                                     // Mock behavior for getIndex (assuming it returns positive for existing periods)
                                                                                                                                                                     when(series.getIndex(period)).thenReturn(0);
                                                                                                                                                                     
                                                                                                                                                                     try {
                                                                                                                                                                         // Test the method with equal start and end
                                                                                                                                                                         TimeSeries result = series.createCopy(period, period);
                                                                                                                                                                         assertNotNull(result);
                                                                                                                                                                         
                                                                                                                                                                         // If we get here, the test passes (original behavior)
                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                         // Check if the exception message matches the mutated version
                                                                                                                                                                         if (e.getMessage().equals("Requires start < end.")) {
                                                                                                                                                                             fail("Mutant detected: start == end case was rejected");
                                                                                                                                                                         } else {
                                                                                                                                                                             fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                                         }
                                                                                                                                                                     } catch (CloneNotSupportedException e) {
                                                                                                                                                                         fail("Clone not supported: " + e.getMessage());
                                                                                                                                                                     }
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testCreateCopyWithEqualStartEndShouldWork() throws CloneNotSupportedException {
                                                                                                                                                                     // Setup - create a TimeSeries with some data
                                                                                                                                                                     TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                     series.add(new TimeSeriesDataItem(new Day(1, 1, 2000), 1.0)); // Use concrete Day class
                                                                                                                                                                     
                                                                                                                                                                     // This should work in original code (start == end is valid)
                                                                                                                                                                     TimeSeries copy = series.createCopy(0, 0);
                                                                                                                                                                     
                                                                                                                                                                     // Verify the copy was created successfully
                                                                                                                                                                     assertNotNull(copy);
                                                                                                                                                                     assertEquals(1, copy.getItemCount());
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testCreateCopyWithEqualStartEndShouldNotThrowException() throws CloneNotSupportedException {
                                                                                                                                                                     // Setup - create a TimeSeries with some data
                                                                                                                                                                     TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                     // Use Day class which is a concrete implementation of RegularTimePeriod
                                                                                                                                                                     series.add(new TimeSeriesDataItem(new Day(1, 1, 2000), 1.0)); // Add one item
                                                                                                                                                                     
                                                                                                                                                                     // This should NOT throw exception in original code, but WILL throw in mutated code
                                                                                                                                                                     // We're testing the boundary case where start == end == 0
                                                                                                                                                                     series.createCopy(0, 0);
                                                                                                                                                                     
                                                                                                                                                                     // If we reach here, the test fails (original behavior passed)
                                                                                                                                                                     // The expected exception annotation will catch the mutant's behavior
                                                                                                                                                                 }

    @Test
                                                                                                                                                        public void testCreateCopy_StartBeforeEnd_ShouldThrowCorrectException() throws CloneNotSupportedException {
                                                                                                                                                            // Setup
                                                                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                            RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                            RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                            
                                                                                                                                                            // Mock the compareTo behavior to simulate start < end
                                                                                                                                                            when(start.compareTo(end)).thenReturn(-1);
                                                                                                                                                            
                                                                                                                                                            // Expect exception
                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                            thrown.expectMessage("Requires start on or before end.");
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            series.createCopy(start, end);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testCreateCopy_StartEqualsEnd_ShouldNotThrowException() throws CloneNotSupportedException {
                                                                                                                                                            // Setup
                                                                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                            RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                            RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                            
                                                                                                                                                            // Mock the compareTo behavior to simulate start == end
                                                                                                                                                            when(start.compareTo(end)).thenReturn(0);
                                                                                                                                                            
                                                                                                                                                            // Test - should not throw exception
                                                                                                                                                            series.createCopy(start, end);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testCreateCopy_StartAfterEnd_ShouldThrowException() throws CloneNotSupportedException {
                                                                                                                                                            // Setup
                                                                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                            RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                            RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                            
                                                                                                                                                            // Mock the compareTo behavior to simulate start > end
                                                                                                                                                            when(start.compareTo(end)).thenReturn(1);
                                                                                                                                                            
                                                                                                                                                            // Expect exception
                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                            thrown.expectMessage("Requires start on or before end.");
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            series.createCopy(start, end);
                                                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                        public void testCreateCopy_StartLessThanEnd_ShouldNotThrowExceptionButMutantDoes() {
                                                                                                                                                            // Setup test data
                                                                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                            
                                                                                                                                                            // Add some data to the series (at least 2 items) using Day as concrete RegularTimePeriod
                                                                                                                                                            series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 1.0));
                                                                                                                                                            series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 2.0));
                                                                                                                                                            
                                                                                                                                                            // This should NOT throw exception in original code (start < end is valid)
                                                                                                                                                            // But mutant will throw exception with wrong message
                                                                                                                                                            try {
                                                                                                                                                                series.createCopy(0, 1);
                                                                                                                                                                // If we get here in original code, test will fail (expected exception)
                                                                                                                                                                // But we want mutant to fail by throwing exception
                                                                                                                                                                fail("Expected IllegalArgumentException but none was thrown");
                                                                                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                                                                                fail("Unexpected CloneNotSupportedException: " + e.getMessage());
                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                // Verify the exception message matches original expected message
                                                                                                                                                                assertEquals("Requires start <= end.", e.getMessage());
                                                                                                                                                                throw e; // rethrow to satisfy @Test(expected)
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                               public void testCreateCopyWithStartAfterEndShouldThrowIllegalArgumentException() throws CloneNotSupportedException {
                                                                                                                                                   // Setup test data
                                                                                                                                                   Day startDay = new Day(15, 1, 2023);  // January 15, 2023
                                                                                                                                                   Day endDay = new Day(10, 1, 2023);    // January 10, 2023 (before start)
                                                                                                                                                   
                                                                                                                                                   // Create time series
                                                                                                                                                   TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                   
                                                                                                                                                   // Set expectation for the original behavior
                                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                                   thrown.expectMessage("Requires start on or before end.");
                                                                                                                                                   
                                                                                                                                                   // This should throw IllegalArgumentException in original code,
                                                                                                                                                   // but would throw NullPointerException in mutated code
                                                                                                                                                   series.createCopy(startDay, endDay);
                                                                                                                                               }

    @Test
                                                                                                                                               public void testCreateCopyWithInvalidRangeThrowsIllegalArgumentException() {
                                                                                                                                                   // Setup
                                                                                                                                                   TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                   
                                                                                                                                                   // Add some test data using concrete RegularTimePeriod implementation (Day)
                                                                                                                                                   timeSeries.add(new TimeSeriesDataItem(new Day(1, 1, 2000), 1.0));
                                                                                                                                                   timeSeries.add(new TimeSeriesDataItem(new Day(2, 1, 2000), 2.0));
                                                                                                                                                   
                                                                                                                                                   // Set expectations
                                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                                   thrown.expectMessage("Requires start <= end.");
                                                                                                                                                   
                                                                                                                                                   // Test - start > end should throw IllegalArgumentException
                                                                                                                                                   try {
                                                                                                                                                       timeSeries.createCopy(1, 0);
                                                                                                                                                   } catch (CloneNotSupportedException e) {
                                                                                                                                                       fail("Unexpected CloneNotSupportedException occurred");
                                                                                                                                                   }
                                                                                                                                               }

    @Test
                                                                                                                                      public void testCreateCopyMinYInitialization() throws CloneNotSupportedException {
                                                                                                                                          // Create a sample TimeSeries with some data
                                                                                                                                          TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                          series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
                                                                                                                                          series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0));
                                                                                                                                          
                                                                                                                                          // Create a copy of the entire series
                                                                                                                                          TimeSeries copy = series.createCopy(0, 1);
                                                                                                                                          
                                                                                                                                          // Verify minY is initialized to NaN (original behavior)
                                                                                                                                          // This will fail if mutant is present (would be POSITIVE_INFINITY)
                                                                                                                                          assertTrue("minY should be initialized to NaN", 
                                                                                                                                                    Double.isNaN(copy.getMinY()));
                                                                                                                                          
                                                                                                                                          // Also verify maxY is initialized to NaN for completeness
                                                                                                                                          assertTrue("maxY should be initialized to NaN",
                                                                                                                                                    Double.isNaN(copy.getMaxY()));
                                                                                                                                          
                                                                                                                                          // Verify data was copied correctly
                                                                                                                                          assertEquals(2, copy.getItemCount());
                                                                                                                                          assertEquals(10.0, copy.getValue(0).doubleValue(), 0.0001);
                                                                                                                                          assertEquals(20.0, copy.getValue(1).doubleValue(), 0.0001);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testCreateCopyEmptyRangeMinYInitialization() throws CloneNotSupportedException {
                                                                                                                                          // Setup - create a time series with some data
                                                                                                                                          TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                          series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
                                                                                                                                          series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0));
                                                                                                                                          
                                                                                                                                          // Create start/end periods that will result in an empty range
                                                                                                                                          RegularTimePeriod start = new Day(3, 1, 2023); // After last data point
                                                                                                                                          RegularTimePeriod end = new Day(4, 1, 2023);
                                                                                                                                          
                                                                                                                                          // Execute
                                                                                                                                          TimeSeries copy = series.createCopy(start, end);
                                                                                                                                          
                                                                                                                                          // Verify minY is initialized to NaN (not POSITIVE_INFINITY)
                                                                                                                                          assertEquals(Double.NaN, copy.getMinY(), 0.0001);
                                                                                                                                          
                                                                                                                                          // Additional verification that it's indeed an empty copy
                                                                                                                                          assertEquals(0, copy.getItemCount());
                                                                                                                                      }

    @Test
                                                                                                                                 public void testCreateCopyResetsMinYToNaN() throws CloneNotSupportedException {
                                                                                                                                     // Create a time series (data not needed for this test)
                                                                                                                                     TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                     
                                                                                                                                     // Create a copy with valid range (though no data exists)
                                                                                                                                     TimeSeries copy = series.createCopy(0, 0);
                                                                                                                                     
                                                                                                                                     // Verify minY was reset to NaN (original behavior)
                                                                                                                                     // This will fail if mutant (minY = 0.0) is present
                                                                                                                                     assertTrue("minY should be NaN after copy creation", 
                                                                                                                                               Double.isNaN(copy.getMinY()));
                                                                                                                                     
                                                                                                                                     // Also verify maxY was reset to NaN for completeness
                                                                                                                                     assertTrue("maxY should be NaN after copy creation",
                                                                                                                                               Double.isNaN(copy.getMaxY()));
                                                                                                                                 }

    @Test
                                                                                                                                 public void testCreateCopyEmptyRangeMinY() throws CloneNotSupportedException {
                                                                                                                                     // Setup - create a time series with some data
                                                                                                                                     TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                     Day startDay = new Day(1, 1, 2023);
                                                                                                                                     Day endDay = new Day(2, 1, 2023);
                                                                                                                                     
                                                                                                                                     // Add some data that won't be included in our test range
                                                                                                                                     series.add(new Day(3, 1, 2023), 10.0);
                                                                                                                                     series.add(new Day(4, 1, 2023), 20.0);
                                                                                                                                     
                                                                                                                                     // Test - create copy with range that will be empty
                                                                                                                                     TimeSeries copy = series.createCopy(startDay, endDay);
                                                                                                                                     
                                                                                                                                     // Verify minY is NaN (original behavior)
                                                                                                                                     // This will fail if mutant is present (would be 0.0)
                                                                                                                                     assertTrue("minY should be NaN for empty range", 
                                                                                                                                                Double.isNaN(copy.getMinY()));
                                                                                                                                     
                                                                                                                                     // Additional verification that the copy is indeed empty
                                                                                                                                     assertEquals(0, copy.getItemCount());
                                                                                                                                 }

    @Test
                                                                                                                            public void testCreateCopyMaxYInitialization() {
                                                                                                                                // Create a sample TimeSeries with some data
                                                                                                                                TimeSeries originalSeries = new TimeSeries("Test Series");
                                                                                                                                originalSeries.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
                                                                                                                                originalSeries.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0));
                                                                                                                                originalSeries.add(new TimeSeriesDataItem(new Day(3, 1, 2023), 30.0));
                                                                                                                                
                                                                                                                                // Create a copy of the entire series
                                                                                                                                TimeSeries copy = null;
                                                                                                                                try {
                                                                                                                                    copy = originalSeries.createCopy(0, 2);
                                                                                                                                } catch (CloneNotSupportedException e) {
                                                                                                                                    fail("CloneNotSupportedException should not be thrown");
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Verify maxY is initialized to NaN (original behavior)
                                                                                                                                // This will fail if mutant (NEGATIVE_INFINITY) is present
                                                                                                                                assertTrue("maxY should be initialized to NaN after copy", 
                                                                                                                                           Double.isNaN(copy.getMaxY()));
                                                                                                                                
                                                                                                                                // Also verify minY is initialized to NaN for completeness
                                                                                                                                assertTrue("minY should be initialized to NaN after copy",
                                                                                                                                           Double.isNaN(copy.getMinY()));
                                                                                                                            }

    @Test
                                                                                                                            public void testCreateCopyEmptyRangeMaxY() throws CloneNotSupportedException {
                                                                                                                                // Setup
                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                Day start = new Day(1, 1, 2023);  // Assuming Day implements RegularTimePeriod
                                                                                                                                Day end = new Day(1, 1, 2023);    // Same as start
                                                                                                                                
                                                                                                                                // Test empty range case (start equals end)
                                                                                                                                TimeSeries copy = series.createCopy(start, end);
                                                                                                                                
                                                                                                                                // Verify maxY is initialized to NaN (original behavior)
                                                                                                                                // This will catch the mutant that sets it to NEGATIVE_INFINITY
                                                                                                                                assertEquals(Double.NaN, copy.getMaxY(), 0.0001);
                                                                                                                                
                                                                                                                                // Additional verification for minY to be thorough
                                                                                                                                assertEquals(Double.NaN, copy.getMinY(), 0.0001);
                                                                                                                                
                                                                                                                                // Verify the copy is indeed empty
                                                                                                                                assertEquals(0, copy.getItemCount());
                                                                                                                            }

    @Test
                                                                                                                   public void testCreateCopyMaxYInitialization1() throws CloneNotSupportedException {
                                                                                                                       // Create a sample TimeSeries with some data
                                                                                                                       TimeSeries originalSeries = new TimeSeries("Test Series");
                                                                                                                       originalSeries.add(new TimeSeriesDataItem(new Day(1, 1, 2000), 10.0));
                                                                                                                       originalSeries.add(new TimeSeriesDataItem(new Day(2, 1, 2000), 20.0));
                                                                                                                       
                                                                                                                       // Create a copy of the entire series
                                                                                                                       TimeSeries copy = originalSeries.createCopy(0, 1);
                                                                                                                       
                                                                                                                       // Verify that maxY is initialized to Double.NaN (not 0.0)
                                                                                                                       assertTrue("maxY should be initialized to Double.NaN", 
                                                                                                                                  Double.isNaN(copy.getMaxY()));
                                                                                                                       
                                                                                                                       // Additional verification that minY is also NaN
                                                                                                                       assertTrue("minY should be initialized to Double.NaN", 
                                                                                                                                  Double.isNaN(copy.getMinY()));
                                                                                                                   }

    @Test
                                                                                                                   public void testCreateCopyEmptyRangeMaxY1() throws CloneNotSupportedException {
                                                                                                                       // Setup test data
                                                                                                                       TimeSeries series = new TimeSeries("Test Series");
                                                                                                                       RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                       RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                       
                                                                                                                       // Mock behavior to create empty range scenario
                                                                                                                       when(start.compareTo(end)).thenReturn(-1); // start < end
                                                                                                                       when(series.getIndex(start)).thenReturn(-(series.getItemCount() + 1)); // start after last item
                                                                                                                       
                                                                                                                       // Execute
                                                                                                                       TimeSeries copy = series.createCopy(start, end);
                                                                                                                       
                                                                                                                       // Verify - original sets maxY to NaN, mutant sets to 0.0
                                                                                                                       assertTrue("MaxY should be NaN for empty range copy", 
                                                                                                                                  Double.isNaN(copy.getMaxY()));
                                                                                                                       
                                                                                                                       // Additional verification that it's indeed an empty copy
                                                                                                                       assertEquals(0, copy.getItemCount());
                                                                                                                   }

    @Test
                                                                                                              public void testCreateCopyWithEmptyDataShouldNotEnterLoop() throws CloneNotSupportedException {
                                                                                                                  // Create empty TimeSeries
                                                                                                                  TimeSeries series = new TimeSeries("Test Series");
                                                                                                                  
                                                                                                                  // Verify data is empty
                                                                                                                  assertEquals(0, series.getItemCount());
                                                                                                                  
                                                                                                                  // Try to create copy (valid indices but empty data)
                                                                                                                  // Original code should skip loop, mutant will enter loop and throw exception
                                                                                                                  series.createCopy(0, 0);
                                                                                                                  
                                                                                                                  // If we reach here, test passes for original code
                                                                                                                  // Mutant will throw IndexOutOfBoundsException when trying to get(0) from empty list
                                                                                                              }

    @Test
                                                                                                              public void testCreateCopyWithEmptyDataShouldReturnEmptyCopy() throws CloneNotSupportedException {
                                                                                                                  // Setup empty TimeSeries
                                                                                                                  TimeSeries series = new TimeSeries("Test Series");
                                                                                                                  // Verify data is empty
                                                                                                                  assertEquals(0, series.getItemCount());
                                                                                                                  
                                                                                                                  // Create test periods (valid but irrelevant since data is empty)
                                                                                                                  RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                  RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                  when(start.compareTo(end)).thenReturn(-1); // start < end
                                                                                                                  
                                                                                                                  // Call method and verify result
                                                                                                                  TimeSeries result = series.createCopy(start, end);
                                                                                                                  
                                                                                                                  // Verify returned copy is empty
                                                                                                                  assertNotNull(result);
                                                                                                                  assertEquals(0, result.getItemCount());
                                                                                                                  
                                                                                                                  // Verify no interaction with data processing for empty series
                                                                                                                  // (This would fail with the mutant since it would try to process empty data)
                                                                                                              }

    @Test
                                                                                                         public void testCreateCopyWithEmptySeriesShouldNotAttemptCopy() throws CloneNotSupportedException {
                                                                                                             // Create empty TimeSeries
                                                                                                             TimeSeries series = new TimeSeries("Test Series");
                                                                                                             
                                                                                                             // Valid indices (though series is empty)
                                                                                                             int start = 0;
                                                                                                             int end = 0;
                                                                                                             
                                                                                                             // Should not throw exception (original behavior)
                                                                                                             // Mutated version would throw IndexOutOfBoundsException
                                                                                                             TimeSeries copy = series.createCopy(start, end);
                                                                                                             
                                                                                                             // Verify the copy was created properly
                                                                                                             assertNotNull(copy);
                                                                                                             assertEquals(0, copy.getItemCount());
                                                                                                             assertTrue(Double.isNaN(copy.getMinY()));
                                                                                                             assertTrue(Double.isNaN(copy.getMaxY()));
                                                                                                         }

    @Test
                                                                                                         public void testCreateCopyWithEmptyDataShouldReturnEmptyCopy1() throws CloneNotSupportedException {
                                                                                                             // Create empty time series
                                                                                                             TimeSeries series = new TimeSeries("Test Series");
                                                                                                             
                                                                                                             // Create valid time periods (implementation depends on RegularTimePeriod class)
                                                                                                             RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                             RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                             
                                                                                                             // Mock compareTo to ensure start <= end
                                                                                                             when(start.compareTo(end)).thenReturn(-1);
                                                                                                             
                                                                                                             // Mock getIndex to return negative values (not found)
                                                                                                             when(series.getIndex(start)).thenReturn(-1);
                                                                                                             when(series.getIndex(end)).thenReturn(-1);
                                                                                                             
                                                                                                             // Call createCopy
                                                                                                             TimeSeries result = series.createCopy(start, end);
                                                                                                             
                                                                                                             // Verify result is an empty copy
                                                                                                             assertNotNull(result);
                                                                                                             assertEquals(0, result.getItemCount());
                                                                                                             // Also verify no attempt was made to create a subset copy
                                                                                                             // (assuming createCopy(int, int) would throw if called with empty data)
                                                                                                         }

    @Test
                                                                                                    public void testCreateCopyMaintainsItemOrder() throws CloneNotSupportedException {
                                                                                                        // Setup test data
                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                        
                                                                                                        // Add items in a specific order
                                                                                                        TimeSeriesDataItem item1 = new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0);
                                                                                                        TimeSeriesDataItem item2 = new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0);
                                                                                                        TimeSeriesDataItem item3 = new TimeSeriesDataItem(new Day(3, 1, 2023), 30.0);
                                                                                                        
                                                                                                        series.add(item1);
                                                                                                        series.add(item2);
                                                                                                        series.add(item3);
                                                                                                        
                                                                                                        // Create copy of the entire range
                                                                                                        TimeSeries copy = series.createCopy(0, 2);
                                                                                                        
                                                                                                        // Verify the order is maintained
                                                                                                        assertEquals("First item should match", item1, copy.getDataItem(0));
                                                                                                        assertEquals("Second item should match", item2, copy.getDataItem(1));
                                                                                                        assertEquals("Third item should match", item3, copy.getDataItem(2));
                                                                                                        
                                                                                                        // Also verify the values to be thorough
                                                                                                        assertEquals(10.0, copy.getValue(0).doubleValue(), 0.0001);
                                                                                                        assertEquals(20.0, copy.getValue(1).doubleValue(), 0.0001);
                                                                                                        assertEquals(30.0, copy.getValue(2).doubleValue(), 0.0001);
                                                                                                    }

    @Test
                                                                                                    public void testCreateCopyPreservesItemOrder() throws CloneNotSupportedException {
                                                                                                        // Setup test data
                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                        Day day1 = new Day(1, 1, 2000);
                                                                                                        Day day2 = new Day(2, 1, 2000);
                                                                                                        Day day3 = new Day(3, 1, 2000);
                                                                                                        
                                                                                                        series.add(day1, 1.0);
                                                                                                        series.add(day2, 2.0);
                                                                                                        series.add(day3, 3.0);
                                                                                                        
                                                                                                        // Test copying a range
                                                                                                        TimeSeries copy = series.createCopy(day1, day3);
                                                                                                        
                                                                                                        // Verify order is preserved
                                                                                                        assertEquals(3, copy.getItemCount());
                                                                                                        assertEquals(day1, copy.getTimePeriod(0));
                                                                                                        assertEquals(day2, copy.getTimePeriod(1));
                                                                                                        assertEquals(day3, copy.getTimePeriod(2));
                                                                                                        
                                                                                                        // Test single item copy
                                                                                                        TimeSeries singleItemCopy = series.createCopy(day2, day2);
                                                                                                        assertEquals(1, singleItemCopy.getItemCount());
                                                                                                        assertEquals(day2, singleItemCopy.getTimePeriod(0));
                                                                                                        
                                                                                                        // Test adjacent items
                                                                                                        TimeSeries adjacentCopy = series.createCopy(day1, day2);
                                                                                                        assertEquals(2, adjacentCopy.getItemCount());
                                                                                                        assertEquals(day1, adjacentCopy.getTimePeriod(0));
                                                                                                        assertEquals(day2, adjacentCopy.getTimePeriod(1));
                                                                                                    }

    @Test
                                                                                               public void testCreateCopyWithEmptyRangeShouldReturnIndependentEmptySeries() throws CloneNotSupportedException {
                                                                                                   // Setup original series with some data
                                                                                                   TimeSeries original = new TimeSeries("Test");
                                                                                                   RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                                                                                   RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                                                                                   when(period1.compareTo(period2)).thenReturn(1); // start > end to trigger emptyRange
                                                                                                   
                                                                                                   // Mock getIndex to return negative values (indicating periods not in series)
                                                                                                   TimeSeries spySeries = spy(original);
                                                                                                   when(spySeries.getIndex(any(RegularTimePeriod.class))).thenReturn(-1);
                                                                                                   
                                                                                                   // Create copy with empty range
                                                                                                   TimeSeries copy = spySeries.createCopy(period1, period2);
                                                                                                   
                                                                                                   // Verify copy is truly independent using public methods
                                                                                                   assertNotSame("Copy should be a different object", original, copy);
                                                                                                   assertEquals("Copy should be empty", 0, copy.getItemCount());
                                                                                                   
                                                                                                   // Verify modifying copy doesn't affect original
                                                                                                   copy.add(period1, 100.0);
                                                                                                   assertEquals("Original should remain unchanged", 0, original.getItemCount());
                                                                                                   assertEquals("Copy should have new item", 1, copy.getItemCount());
                                                                                               }

    @Test
                                                                                           public void testCreateCopyDataIsIndependent() throws CloneNotSupportedException {
                                                                                               // Setup original TimeSeries with some data
                                                                                               TimeSeries original = new TimeSeries("Test Series");
                                                                                               TimeSeriesDataItem item1 = new TimeSeriesDataItem(new Day(), 1.0);
                                                                                               TimeSeriesDataItem item2 = new TimeSeriesDataItem(new Day(), 2.0);
                                                                                               original.add(item1);
                                                                                               original.add(item2);
                                                                                               
                                                                                               // Create copy
                                                                                               TimeSeries copy = original.createCopy(0, 1);
                                                                                               
                                                                                               // Verify initial state
                                                                                               assertEquals(2, copy.getItemCount());
                                                                                               
                                                                                               // Modify copy's data
                                                                                               copy.delete(0, 0); // Remove first item from copy
                                                                                               
                                                                                               // Verify original's data remains unchanged (would fail with mutant)
                                                                                               assertEquals(2, original.getItemCount());
                                                                                               
                                                                                               // Verify copy's data changed (would fail with mutant if copy.data == this.data)
                                                                                               assertEquals(1, copy.getItemCount());
                                                                                               
                                                                                               // Verify they are different objects
                                                                                               assertNotSame(original.getItems(), copy.getItems());
                                                                                           }

    @Test
                                                                              public void testCreateCopyPreservesItemOrder1() throws CloneNotSupportedException {
                                                                                  // Setup test data
                                                                                  TimeSeries series = new TimeSeries("Test Series");
                                                                                  Day day1 = new Day(1, 1, 2000);
                                                                                  Day day2 = new Day(2, 1, 2000);
                                                                                  Day day3 = new Day(3, 1, 2000);
                                                                                  
                                                                                  series.add(day1, 1.0);
                                                                                  series.add(day2, 2.0);
                                                                                  series.add(day3, 3.0);
                                                                                  
                                                                                  // Create copy
                                                                                  TimeSeries copy = series.createCopy(day1, day3);
                                                                                  
                                                                                  // Verify item count
                                                                                  assertEquals(3, copy.getItemCount());
                                                                                  
                                                                                  // Verify order of items matches original
                                                                                  assertEquals(day1, copy.getTimePeriod(0));
                                                                                  assertEquals(day2, copy.getTimePeriod(1));
                                                                                  assertEquals(day3, copy.getTimePeriod(2));
                                                                                  
                                                                                  // Verify values match original
                                                                                  assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                                                                                  assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                                                                                  assertEquals(3.0, copy.getValue(2).doubleValue(), 0.0001);
                                                                              }

    @Test
                                                                              public void testCreateCopyMaintainsItemOrder1() throws CloneNotSupportedException {
                                                                                  // Setup test data
                                                                                  TimeSeries series = new TimeSeries("Test Series");
                                                                                  
                                                                                  // Add items in a specific order (order matters for this test)
                                                                                  series.add(new Day(1, 1, 2000), 10.0);
                                                                                  series.add(new Day(2, 1, 2000), 20.0);
                                                                                  series.add(new Day(3, 1, 2000), 30.0);
                                                                                  series.add(new Day(4, 1, 2000), 40.0);
                                                                                  
                                                                                  // Create copy of middle two items (indices 1-2)
                                                                                  TimeSeries copy = series.createCopy(1, 2);
                                                                                  
                                                                                  // Verify the copy has correct items in correct order
                                                                                  assertEquals(2, copy.getItemCount());
                                                                                  
                                                                                  // Check first item in copy matches second item in original (index 1)
                                                                                  assertEquals(series.getDataItem(1), copy.getDataItem(0));
                                                                                  
                                                                                  // Check second item in copy matches third item in original (index 2)
                                                                                  assertEquals(series.getDataItem(2), copy.getDataItem(1));
                                                                                  
                                                                                  // Verify the values are in the expected order
                                                                                  assertEquals(20.0, copy.getValue(0).doubleValue(), 0.0001);
                                                                                  assertEquals(30.0, copy.getValue(1).doubleValue(), 0.0001);
                                                                              }

    @Test
                                                                         public void testCreateCopyEmptyRangeReturnsArrayList() throws CloneNotSupportedException {
                                                                             // Setup - create a time series with some data
                                                                             TimeSeries series = new TimeSeries("Test Series");
                                                                             series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 100));
                                                                             series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 200));
                                                                             
                                                                             // Create start/end periods that will result in empty range
                                                                             // (start after last data item)
                                                                             RegularTimePeriod start = new Day(3, 1, 2023);
                                                                             RegularTimePeriod end = new Day(4, 1, 2023);
                                                                             
                                                                             // Execute
                                                                             TimeSeries copy = series.createCopy(start, end);
                                                                             
                                                                             // Verify the data is stored in an ArrayList (not LinkedList) by checking the class
                                                                             // of the collection returned by getItems()
                                                                             List items = copy.getItems();
                                                                             assertNotNull(items);
                                                                             assertEquals(ArrayList.class, items.getClass());
                                                                             
                                                                             // Additional verification that the copy is indeed empty
                                                                             assertEquals(0, copy.getItemCount());
                                                                         }

    @Test
                                                                     public void testCreateCopyDataCollectionType() throws CloneNotSupportedException {
                                                                         // Setup test data
                                                                         TimeSeries original = new TimeSeries("Test Series");
                                                                         // Use concrete RegularTimePeriod implementation (Day) with actual dates
                                                                         original.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 1.0));
                                                                         original.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 2.0));
                                                                         
                                                                         // Create copy
                                                                         TimeSeries copy = original.createCopy(0, 1);
                                                                         
                                                                         // Get the data collection and verify its type
                                                                         List<?> data = copy.getItems();
                                                                         assertNotNull("Data collection should not be null", data);
                                                                         assertEquals("Data collection should be ArrayList", 
                                                                                      java.util.ArrayList.class, 
                                                                                      data.getClass());
                                                                         
                                                                         // Additional verification that the copy works correctly
                                                                         assertEquals("Copy should have same item count", 
                                                                                      original.getItemCount(), 
                                                                                      copy.getItemCount());
                                                                     }

    @Test
                                                        public void testCreateCopyWithStartAfterEndShouldThrowCorrectException() throws CloneNotSupportedException {
                                                            // Setup test data
                                                            TimeSeries series = new TimeSeries("Test Series");
                                                            
                                                            // Create mock periods where start is after end
                                                            RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                            RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                            
                                                            // Configure mock behavior
                                                            when(start.compareTo(end)).thenReturn(1); // start > end
                                                            
                                                            try {
                                                                series.createCopy(start, end);
                                                                fail("Expected IllegalArgumentException to be thrown");
                                                            } catch (IllegalArgumentException e) {
                                                                // Verify the exception message matches the original (not mutated) version
                                                                assertEquals("Requires start on or before end.", e.getMessage());
                                                                throw e;
                                                            }
                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                        public void testCreateCopyWithNegativeStartThrowsExceptionWithCorrectMessage() {
                                                            // Setup
                                                            TimeSeries series = new TimeSeries("Test Series");
                                                            
                                                            // Add some test data using concrete RegularTimePeriod implementation (Day)
                                                            series.add(new TimeSeriesDataItem(new Day(1, 1, 2000), 1.0));
                                                            series.add(new TimeSeriesDataItem(new Day(2, 1, 2000), 2.0));
                                                            
                                                            try {
                                                                // Trigger exception with invalid start index
                                                                series.createCopy(-1, 1);
                                                                fail("Expected IllegalArgumentException to be thrown");
                                                            } catch (IllegalArgumentException e) {
                                                                // Verify the exact exception message
                                                                assertEquals("Requires start >= 0.", e.getMessage());
                                                                throw e; // rethrow for @Test expected
                                                            } catch (CloneNotSupportedException e) {
                                                                fail("Unexpected CloneNotSupportedException occurred");
                                                            }
                                                        }

    @Test(expected = IllegalArgumentException.class)
                                           public void testCreateCopyWithNegativeStartThrowsIllegalArgumentException() throws CloneNotSupportedException {
                                               // Setup test data
                                               TimeSeries series = new TimeSeries("Test Series");
                                               series.add(new TimeSeriesDataItem(new Day(1, 1, 2000), 1.0));
                                               series.add(new TimeSeriesDataItem(new Day(2, 1, 2000), 2.0));
                                               
                                               // This should throw IllegalArgumentException
                                               series.createCopy(-1, 1);
                                           }

    @Test(expected = IllegalArgumentException.class)
                                   public void testCreateCopyWithStartAfterEndShouldThrowIllegalArgumentException1() throws CloneNotSupportedException {
                                       // Setup test data where start > end
                                       RegularTimePeriod start = mock(RegularTimePeriod.class);
                                       RegularTimePeriod end = mock(RegularTimePeriod.class);
                                       
                                       // Mock the compareTo behavior to simulate start > end
                                       when(start.compareTo(end)).thenReturn(1);
                                       
                                       // Create the TimeSeries instance
                                       TimeSeries series = new TimeSeries("Test Series");
                                       
                                       // This should throw IllegalArgumentException
                                       series.createCopy(start, end);
                                   }

    @Test(expected = RuntimeException.class)
                               public void testCreateCopy_ShouldNotCatchNonSeriesException() throws Exception {
                                   // Setup
                                   TimeSeries series = new TimeSeries("Test Series");
                                   
                                   // Create a mock TimeSeriesDataItem that throws RuntimeException when cloned
                                   TimeSeriesDataItem mockItem = mock(TimeSeriesDataItem.class);
                                   when(mockItem.clone()).thenThrow(new RuntimeException("Test exception"));
                                   
                                   // Add the mock item to the series
                                   // Need to use reflection to access the protected data list since there's no public add method
                                   Field dataField = TimeSeries.class.getDeclaredField("data");
                                   dataField.setAccessible(true);
                                   List data = (List) dataField.get(series);
                                   data.add(mockItem);
                                   
                                   // Exercise - this should throw RuntimeException, not catch it
                                   series.createCopy(0, 0);
                                   
                                   // If we get here, the test fails because the exception was caught
                                   fail("Expected RuntimeException to be thrown");
                               }

    @Test(expected = RuntimeException.class)
                               public void testCreateCopy_ShouldNotCatchGenericException() throws Exception {
                                   // Setup
                                   TimeSeries series = new TimeSeries("Test Series");
                                   RegularTimePeriod start = mock(RegularTimePeriod.class);
                                   RegularTimePeriod end = mock(RegularTimePeriod.class);
                                   
                                   // Mock getIndex() to throw a RuntimeException (not SeriesException)
                                   TimeSeries spySeries = spy(series);
                                   doThrow(new RuntimeException("Test exception")).when(spySeries).getIndex(any(RegularTimePeriod.class));
                                   
                                   // Exercise - this should throw the RuntimeException
                                   spySeries.createCopy(start, end);
                                   
                                   // The test will pass if the exception propagates (original behavior)
                                   // It would fail if the mutant catches the generic exception
                               }

    @Test
                         public void testCreateCopyExceptionHandling() throws CloneNotSupportedException {
                             // Setup
                             TimeSeries originalSeries = new TimeSeries("Test Series");
                             TimeSeriesDataItem mockItem = mock(TimeSeriesDataItem.class);
                             when(mockItem.clone()).thenReturn(mockItem); // Return itself when cloned
                             
                             // Add an item that will cause SeriesException when added to copy
                             originalSeries.add(mockItem);
                             
                             // Mock System.err to verify output
                             java.io.PrintStream originalErr = System.err;
                             java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                             System.setErr(new java.io.PrintStream(errContent));
                             
                             try {
                                 // Test
                                 TimeSeries copy = originalSeries.createCopy(0, 0);
                                 
                                 // Verify exception handling output
                                 String errOutput = errContent.toString();
                                 assertTrue("Should output exception message to System.err", 
                                           errOutput.contains("SeriesException") || errOutput.length() > 0);
                             } finally {
                                 // Restore System.err
                                 System.setErr(originalErr);
                             }
                         }

    @Test
                     public void testCreateCopyExceptionOutput() {
                         TimeSeries series = new TimeSeries("Test Series");
                         try {
                             // Force null argument exception
                             series.createCopy(null, null);
                             fail("Expected IllegalArgumentException");
                         } catch (IllegalArgumentException e) {
                             // Verify correct exception is thrown
                             assertTrue(e.getMessage().contains("Null 'start' argument.") || 
                                      e.getMessage().contains("Null 'end' argument."));
                         } catch (CloneNotSupportedException e) {
                             fail("Unexpected CloneNotSupportedException");
                         }
                     }

    @Test
                     public void testCreateCopyInvalidRangeOutput() {
                         TimeSeries series = new TimeSeries("Test Series");
                         // Add some test data
                         RegularTimePeriod start = mock(RegularTimePeriod.class);
                         RegularTimePeriod end = mock(RegularTimePeriod.class);
                         
                         when(start.compareTo(end)).thenReturn(1); // start > end
                         
                         try {
                             try {
                                 series.createCopy(start, end);
                                 fail("Expected IllegalArgumentException");
                             } catch (CloneNotSupportedException e) {
                                 fail("Unexpected CloneNotSupportedException");
                             }
                         } catch (IllegalArgumentException e) {
                             // Verify the correct exception was thrown
                             assertEquals("Requires start on or before end.", e.getMessage());
                         }
                     }

    @Test
            public void testCreateCopyPrintsStackTraceOnException() throws Exception {
                // Create a TimeSeries instance
                TimeSeries timeSeries = new TimeSeries("Test Series");
                
                // Create a mock RegularTimePeriod that throws exception on compareTo
                RegularTimePeriod mockStart = mock(RegularTimePeriod.class);
                RegularTimePeriod mockEnd = mock(RegularTimePeriod.class);
                
                when(mockStart.compareTo(any(RegularTimePeriod.class)))
                    .thenThrow(new RuntimeException("Test exception"));
                
                // Save original System.err and mock it
                java.io.PrintStream originalErr = System.err;
                java.io.PrintStream mockErr = mock(java.io.PrintStream.class);
                System.setErr(mockErr);
                
                try {
                    timeSeries.createCopy(mockStart, mockEnd);
                } catch (IllegalArgumentException e) {
                    // Verify that the exception stack trace was printed to System.err
                    verify(mockErr, atLeastOnce()).println(contains("Test exception"));
                }
                
                // Reset System.err to original
                System.setErr(originalErr);
            }

    @Test
    public void testCreateCopyHandlesSeriesException() throws Exception {
        // Setup test data
        org.jfree.data.time.TimeSeries originalSeries = new org.jfree.data.time.TimeSeries("Test Series");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(1, 1, 2000);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(2, 1, 2000);
        org.jfree.data.time.TimeSeriesDataItem item1 = new org.jfree.data.time.TimeSeriesDataItem(day1, 1.0);
        org.jfree.data.time.TimeSeriesDataItem item2 = new org.jfree.data.time.TimeSeriesDataItem(day2, 2.0);
        originalSeries.add(item1);
        originalSeries.add(item2);
        
        // Create a problematic item that will throw SeriesException when cloned
        org.jfree.data.time.TimeSeriesDataItem problematicItem = new org.jfree.data.time.TimeSeriesDataItem(day2, 2.0) {
            @Override
            public Object clone() {
                throw new org.jfree.data.general.SeriesException("Test exception");
            }
        };
        
        // Use reflection to access the protected data field
        java.lang.reflect.Field dataField = org.jfree.data.time.TimeSeries.class.getDeclaredField("data");
        dataField.setAccessible(true);
        @SuppressWarnings("unchecked")
        java.util.List<org.jfree.data.time.TimeSeriesDataItem> data = (java.util.List<org.jfree.data.time.TimeSeriesDataItem>) dataField.get(originalSeries);
        // Replace one item with our problematic item
        data.set(1, problematicItem);
        
        // Redirect System.err to capture output
        java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
        java.io.PrintStream originalErr = System.err;
        System.setErr(new java.io.PrintStream(errContent));
        
        try {
            // Test the method
            org.jfree.data.time.TimeSeries copy = originalSeries.createCopy(0, 1);
            
            // Verify the copy contains the first item (exception shouldn't prevent copying other items)
            assertEquals(1, copy.getItemCount());
            assertEquals(item1, copy.getDataItem(0));
            
            // Verify the exception was printed to System.err
            String errOutput = errContent.toString();
            assertTrue("Exception stack trace should be printed", 
                      errOutput.contains("SeriesException: Test exception"));
        } finally {
            // Restore System.err
            System.setErr(originalErr);
        }
    }


}
