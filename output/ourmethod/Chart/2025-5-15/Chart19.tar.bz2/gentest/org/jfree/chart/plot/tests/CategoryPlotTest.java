package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.CategoryAnchor;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.event.ChartChangeEventType;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
 
public class CategoryPlotTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                                                          public void testGetDomainAxisIndex_NullAxis() {
                                                              // Setup
                                                              CategoryPlot plot = new CategoryPlot();
                                                              
                                                              // Expect exception
                                                              thrown.expect(IllegalArgumentException.class);
                                                              thrown.expectMessage("Null 'axis' argument.");
                                                              
                                                              // Test
                                                              plot.getDomainAxisIndex(null);
                                                          }

 @Test
                                                          public void testGetDomainAxisIndex_AxisNotPresent() {
                                                              // Setup
                                                              CategoryPlot plot = new CategoryPlot();
                                                              CategoryAxis axis1 = mock(CategoryAxis.class);
                                                              CategoryAxis axis2 = mock(CategoryAxis.class);
                                                              
                                                              // Add only axis1 to the plot
                                                              plot.setDomainAxis(0, axis1);
                                                              
                                                              // Test
                                                              int result = plot.getDomainAxisIndex(axis2);
                                                              
                                                              // Verify
                                                              assertEquals(-1, result);
                                                          }

 @Test
                                                          public void testGetDomainAxisIndex_SingleAxis() {
                                                              // Setup
                                                              CategoryPlot plot = new CategoryPlot();
                                                              CategoryAxis axis = mock(CategoryAxis.class);
                                                              
                                                              // Add axis to the plot
                                                              plot.setDomainAxis(0, axis);
                                                              
                                                              // Test
                                                              int result = plot.getDomainAxisIndex(axis);
                                                              
                                                              // Verify
                                                              assertEquals(0, result);
                                                          }

 @Test
                                                          public void testGetDomainAxisIndex_MultipleAxes() {
                                                              // Setup
                                                              CategoryPlot plot = new CategoryPlot();
                                                              CategoryAxis axis1 = mock(CategoryAxis.class);
                                                              CategoryAxis axis2 = mock(CategoryAxis.class);
                                                              CategoryAxis axis3 = mock(CategoryAxis.class);
                                                              
                                                              // Add multiple axes to the plot
                                                              plot.setDomainAxis(0, axis1);
                                                              plot.setDomainAxis(1, axis2);
                                                              plot.setDomainAxis(2, axis3);
                                                              
                                                              // Test and verify each axis
                                                              assertEquals(0, plot.getDomainAxisIndex(axis1));
                                                              assertEquals(1, plot.getDomainAxisIndex(axis2));
                                                              assertEquals(2, plot.getDomainAxisIndex(axis3));
                                                          }

 @Test
                                                          public void testGetDomainAxisIndex_EmptyAxesList() {
                                                              // Setup
                                                              CategoryPlot plot = new CategoryPlot();
                                                              CategoryAxis axis = mock(CategoryAxis.class);
                                                              
                                                              // Test
                                                              int result = plot.getDomainAxisIndex(axis);
                                                              
                                                              // Verify
                                                              assertEquals(-1, result);
                                                          }

 @Test
                                                          public void testGetDomainAxisIndex_AfterAxisRemoval() {
                                                              // Setup
                                                              CategoryPlot plot = new CategoryPlot();
                                                              CategoryAxis axis1 = mock(CategoryAxis.class);
                                                              CategoryAxis axis2 = mock(CategoryAxis.class);
                                                              
                                                              // Add axes
                                                              plot.setDomainAxis(0, axis1);
                                                              plot.setDomainAxis(1, axis2);
                                                              
                                                              // Remove axis1
                                                              plot.setDomainAxis(0, null);
                                                              
                                                              // Test
                                                              assertEquals(-1, plot.getDomainAxisIndex(axis1));
                                                              assertEquals(1, plot.getDomainAxisIndex(axis2));
                                                          }

 @Test
                                                          public void testGetRangeAxisIndex_NullAxisThrowsException() {
                                                              CategoryPlot plot = new CategoryPlot();
                                                              thrown.expect(IllegalArgumentException.class);
                                                              thrown.expectMessage("Null 'axis' argument.");
                                                              plot.getRangeAxisIndex(null);
                                                          }

 @Test
                                                          public void testGetRangeAxisIndex_AxisFoundInCurrentPlot() {
                                                              CategoryPlot plot = new CategoryPlot();
                                                              ValueAxis axis = mock(ValueAxis.class);
                                                              plot.setRangeAxis(0, axis);
                                                              
                                                              int result = plot.getRangeAxisIndex(axis);
                                                              assertEquals(0, result);
                                                          }

 @Test
                                                          public void testGetRangeAxisIndex_AxisNotFoundInCurrentPlot() {
                                                              CategoryPlot plot = new CategoryPlot();
                                                              ValueAxis axis = mock(ValueAxis.class);
                                                              
                                                              int result = plot.getRangeAxisIndex(axis);
                                                              assertEquals(-1, result);
                                                          }

 @Test
                                                          public void testGetRangeAxisIndex_AxisFoundInParentPlot() {
                                                              // Create parent plot with axis
                                                              CategoryPlot parentPlot = new CategoryPlot();
                                                              ValueAxis axis = mock(ValueAxis.class);
                                                              parentPlot.setRangeAxis(0, axis);
                                                              
                                                              // Create child plot with no axes
                                                              CategoryPlot childPlot = new CategoryPlot();
                                                              childPlot.setParent(parentPlot);
                                                              
                                                              int result = childPlot.getRangeAxisIndex(axis);
                                                              assertEquals(0, result);
                                                          }

 @Test
                                                          public void testGetRangeAxisIndex_AxisNotFoundInParentPlot() {
                                                              // Create parent plot with different axis
                                                              CategoryPlot parentPlot = new CategoryPlot();
                                                              ValueAxis parentAxis = mock(ValueAxis.class);
                                                              parentPlot.setRangeAxis(0, parentAxis);
                                                              
                                                              // Create child plot with no axes
                                                              CategoryPlot childPlot = new CategoryPlot();
                                                              childPlot.setParent(parentPlot);
                                                              
                                                              // Test with different axis
                                                              ValueAxis testAxis = mock(ValueAxis.class);
                                                              int result = childPlot.getRangeAxisIndex(testAxis);
                                                              assertEquals(-1, result);
                                                          }

 @Test
                                                          public void testGetRangeAxisIndex_ParentPlotNotCategoryPlot() {
                                                              // Create parent plot that's not a CategoryPlot
                                                              Plot parentPlot = mock(Plot.class);
                                                              
                                                              // Create child plot with parent
                                                              CategoryPlot childPlot = new CategoryPlot();
                                                              childPlot.setParent(parentPlot);
                                                              
                                                              ValueAxis axis = mock(ValueAxis.class);
                                                              int result = childPlot.getRangeAxisIndex(axis);
                                                              assertEquals(-1, result);
                                                          }

 @Test
                                                          public void testGetRangeAxisIndex_MultipleAxesInCurrentPlot() {
                                                              CategoryPlot plot = new CategoryPlot();
                                                              ValueAxis axis1 = mock(ValueAxis.class);
                                                              ValueAxis axis2 = mock(ValueAxis.class);
                                                              ValueAxis axis3 = mock(ValueAxis.class);
                                                              
                                                              plot.setRangeAxis(0, axis1);
                                                              plot.setRangeAxis(1, axis2);
                                                              plot.setRangeAxis(2, axis3);
                                                              
                                                              assertEquals(0, plot.getRangeAxisIndex(axis1));
                                                              assertEquals(1, plot.getRangeAxisIndex(axis2));
                                                              assertEquals(2, plot.getRangeAxisIndex(axis3));
                                                          }

 @Test
                                                          public void testGetRangeAxisIndex_EmptyPlotReturnsNegativeOne() {
                                                              CategoryPlot plot = new CategoryPlot();
                                                              ValueAxis axis = mock(ValueAxis.class);
                                                              
                                                              int result = plot.getRangeAxisIndex(axis);
                                                              assertEquals(-1, result);
                                                          }

 @Test
                                                  public void testGetRangeAxisIndex_WhenAxisAtZeroIndex_ShouldNotCheckParent() {
                                                      // Setup
                                                      ValueAxis localAxis = mock(ValueAxis.class);
                                                      ValueAxis parentAxis = mock(ValueAxis.class); // same object reference
                                                      
                                                      // Create parent plot with axis at index 1
                                                      CategoryPlot parentPlot = new CategoryPlot();
                                                      parentPlot.setRangeAxis(1, localAxis);
                                                      
                                                      // Create main plot with axis at index 0 and set parent
                                                      CategoryPlot plot = new CategoryPlot();
                                                      plot.setRangeAxis(0, localAxis);
                                                      plot.setParent(parentPlot);
                                                      
                                                      // Test - should return 0 (local index) not check parent
                                                      int result = plot.getRangeAxisIndex(localAxis);
                                                      
                                                      // Verify
                                                      assertEquals("Should return local index when axis found at index 0", 
                                                                  0, result);
                                                      
                                                      // Additional verification that parent wasn't checked
                                                      // If mutant is present, it would return 1 (parent's index)
                                                      assertNotEquals("Should not return parent's index", 
                                                                     1, result);
                                                  }

 @Test
                                                 public void testGetRangeAxisIndexBoundaryConditions() {
                                                     // Create test axes
                                                     ValueAxis axis1 = mock(ValueAxis.class);
                                                     ValueAxis axis2 = mock(ValueAxis.class);
                                                     ValueAxis axis3 = mock(ValueAxis.class);
                                                     ValueAxis nonExistentAxis = mock(ValueAxis.class);
                                                     
                                                     // Create parent plot with axes
                                                     CategoryPlot parentPlot = new CategoryPlot();
                                                     parentPlot.setRangeAxes(new ValueAxis[]{axis1, axis2});
                                                     
                                                     // Create test plot with parent and axes
                                                     CategoryPlot plot = new CategoryPlot();
                                                     plot.setParent(parentPlot);
                                                     plot.setRangeAxes(new ValueAxis[]{axis3});
                                                     
                                                     // Test boundary cases
                                                     // 1. Test finding last axis in current plot
                                                     assertEquals(0, plot.getRangeAxisIndex(axis3));
                                                     
                                                     // 2. Test finding last axis in parent plot
                                                     assertEquals(1, plot.getRangeAxisIndex(axis2));
                                                     
                                                     // 3. Test non-existent axis (should not throw exception)
                                                     assertEquals(-1, plot.getRangeAxisIndex(nonExistentAxis));
                                                     
                                                     // 4. Test null axis (should throw exception)
                                                     try {
                                                         plot.getRangeAxisIndex(null);
                                                         fail("Expected IllegalArgumentException for null axis");
                                                     } catch (IllegalArgumentException e) {
                                                         assertEquals("Null 'axis' argument.", e.getMessage());
                                                     }
                                                     
                                                     // 5. Test empty axes case
                                                     CategoryPlot emptyPlot = new CategoryPlot();
                                                     assertEquals(-1, emptyPlot.getRangeAxisIndex(axis1));
                                                 }

 @Test
                                                public void testGetRangeAxisIndexFindsFirstAxis() {
                                                    // Setup
                                                    CategoryPlot plot = new CategoryPlot();
                                                    ValueAxis axis = mock(ValueAxis.class);
                                                    plot.setRangeAxis(0, axis);  // This adds the axis at index 0
                                                    
                                                    // Test
                                                    int index = plot.getRangeAxisIndex(axis);
                                                    
                                                    // Verify
                                                    assertEquals("Should find axis at index 0", 0, index);
                                                    
                                                    // Additional test to ensure it works with parent plot case
                                                    CategoryPlot parentPlot = new CategoryPlot();
                                                    CategoryPlot childPlot = new CategoryPlot();
                                                    childPlot.setParent(parentPlot);
                                                    parentPlot.setRangeAxis(0, axis);
                                                    
                                                    int parentIndex = childPlot.getRangeAxisIndex(axis);
                                                    assertEquals("Should find axis in parent plot", 0, parentIndex);
                                                }

 @Test(expected = IllegalArgumentException.class)
                                                public void testGetRangeAxisIndexWithNullAxis() {
                                                    CategoryPlot plot = new CategoryPlot();
                                                    plot.getRangeAxisIndex(null);
                                                }

 @Test
                                                public void testGetRangeAxisIndexReturnsMinusOneForNotFound() {
                                                    CategoryPlot plot = new CategoryPlot();
                                                    ValueAxis axis1 = mock(ValueAxis.class);
                                                    ValueAxis axis2 = mock(ValueAxis.class);
                                                    plot.setRangeAxis(0, axis1);
                                                    
                                                    int index = plot.getRangeAxisIndex(axis2);
                                                    assertEquals("Should return -1 for axis not in plot", -1, index);
                                                }

 @Test
                                               public void testSetDomainAxisPreservesIndex() {
                                                   // Setup test data
                                                   CategoryPlot plot = new CategoryPlot();
                                                   CategoryAxis[] axes = new CategoryAxis[] {
                                                       mock(CategoryAxis.class),
                                                       mock(CategoryAxis.class),
                                                       mock(CategoryAxis.class)
                                                   };
                                                   
                                                   // Set axes at different indices
                                                   plot.setDomainAxes(axes);
                                                   
                                                   // Verify each axis was set at correct index
                                                   assertEquals("Axis 0 should be at index 0", axes[0], plot.getDomainAxis(0));
                                                   assertEquals("Axis 1 should be at index 1", axes[1], plot.getDomainAxis(1));
                                                   assertEquals("Axis 2 should be at index 2", axes[2], plot.getDomainAxis(2));
                                                   
                                                   // Additional verification that indices are correct
                                                   for (int i = 0; i < axes.length; i++) {
                                                       assertEquals("Axis index should match position", 
                                                                  i, plot.getDomainAxisIndex(axes[i]));
                                                   }
                                               }

 @Test
                                             public void testGetRangeAxisIndex_CompleteExecution() {
                                                 // Setup test objects
                                                 CategoryPlot plot = new CategoryPlot();
                                                 ValueAxis axis = mock(ValueAxis.class);
                                                 
                                                 // Case 1: Test local axis search
                                                 plot.setRangeAxis(0, axis);
                                                 int result = plot.getRangeAxisIndex(axis);
                                                 assertEquals(0, result);
                                                 
                                                 // Case 2: Test parent plot search
                                                 CategoryPlot parentPlot = new CategoryPlot();
                                                 parentPlot.setRangeAxis(1, axis);
                                                 plot.setParent(parentPlot);
                                                 result = plot.getRangeAxisIndex(axis);
                                                 assertEquals(1, result);
                                                 
                                                 // Case 3: Test axis not found
                                                 ValueAxis otherAxis = mock(ValueAxis.class);
                                                 result = plot.getRangeAxisIndex(otherAxis);
                                                 assertEquals(-1, result);
                                                 
                                                 // Case 4: Test null input
                                                 try {
                                                     plot.getRangeAxisIndex(null);
                                                     fail("Expected IllegalArgumentException");
                                                 } catch (IllegalArgumentException e) {
                                                     assertEquals("Null 'axis' argument.", e.getMessage());
                                                 }
                                             }

 @Test
                                         public void testGetRangeAxisIndexWithNonExistentAxis() {
                                             // Setup test data
                                             ValueAxis axis1 = mock(ValueAxis.class);
                                             ValueAxis axis2 = mock(ValueAxis.class);
                                             ValueAxis nonExistentAxis = mock(ValueAxis.class);
                                             
                                             // Create a CategoryPlot with 2 range axes
                                             CategoryPlot plot = new CategoryPlot();
                                             plot.setRangeAxes(new ValueAxis[] {axis1, axis2});
                                             
                                             // Test with axis not in the list
                                             int result = plot.getRangeAxisIndex(nonExistentAxis);
                                             
                                             // Verify - original returns -1, mutant would throw exception
                                             assertEquals(-1, result);
                                             
                                             // Additional verification that parent plot isn't checked in this case
                                             // (since we didn't set a parent plot)
                                             verify(axis1, never()).equals(any());
                                             verify(axis2, never()).equals(any());
                                         }

 @Test(expected = IllegalArgumentException.class)
                                         public void testGetRangeAxisIndexWithNullAxis1() {
                                             CategoryPlot plot = new CategoryPlot();
                                             plot.getRangeAxisIndex(null); // Should throw exception
                                         }

 @Test
                                         public void testGetRangeAxisIndexWithParentPlot() {
                                             // Setup test data
                                             ValueAxis axis1 = mock(ValueAxis.class);
                                             ValueAxis axis2 = mock(ValueAxis.class);
                                             ValueAxis parentAxis = mock(ValueAxis.class);
                                             
                                             // Create parent plot
                                             CategoryPlot parentPlot = new CategoryPlot();
                                             parentPlot.setRangeAxes(new ValueAxis[] {parentAxis});
                                             
                                             // Create child plot
                                             CategoryPlot plot = new CategoryPlot();
                                             plot.setRangeAxes(new ValueAxis[] {axis1, axis2});
                                             plot.setParent(parentPlot);
                                             
                                             // Test - should find axis in parent plot
                                             int result = plot.getRangeAxisIndex(parentAxis);
                                             
                                             // Verify it checked parent plot
                                             assertEquals(0, result); // Should be index 0 in parent plot
                                         }

 @Test
                                        public void testGetRangeAxisIndex_ShouldFindFirstAxis() {
                                            // Setup
                                            CategoryPlot plot = new CategoryPlot();
                                            ValueAxis axis1 = mock(ValueAxis.class);
                                            ValueAxis axis2 = mock(ValueAxis.class);
                                            
                                            // Add axes to plot (using reflection since rangeAxes is private)
                                            try {
                                                Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                                rangeAxesField.setAccessible(true);
                                                ObjectList rangeAxes = (ObjectList) rangeAxesField.get(plot);
                                                rangeAxes.set(0, axis1);
                                                rangeAxes.set(1, axis2);
                                            } catch (Exception e) {
                                                fail("Failed to setup test due to reflection error: " + e.getMessage());
                                            }
                                            
                                            // Test - should find first axis at index 0
                                            int result = plot.getRangeAxisIndex(axis1);
                                            
                                            // Verify
                                            assertEquals("Should find first axis at index 0", 0, result);
                                        }

 @Test
                                       public void testGetRangeAxisIndexWithMultipleAxes() {
                                           // Setup
                                           CategoryPlot plot = new CategoryPlot();
                                           ValueAxis axis1 = mock(ValueAxis.class);
                                           ValueAxis axis2 = mock(ValueAxis.class);
                                           
                                           // Original behavior would set axis1 at 0, axis2 at 1
                                           // Mutated behavior would set both at 0 (axis2 overwrites axis1)
                                           plot.setRangeAxes(new ValueAxis[] {axis1, axis2});
                                           
                                           // Test axis1
                                           int index1 = plot.getRangeAxisIndex(axis1);
                                           assertEquals("First axis should be at index 0", 0, index1);
                                           
                                           // Test axis2
                                           int index2 = plot.getRangeAxisIndex(axis2);
                                           assertEquals("Second axis should be at index 1", 1, index2);
                                           
                                           // Verify both axes are present and at correct positions
                                           assertEquals("Should find axis1 at index 0", axis1, plot.getRangeAxis(0));
                                           assertEquals("Should find axis2 at index 1", axis2, plot.getRangeAxis(1));
                                       }

 @Test
     public void testNotifyListenersWithCorrectSource() {
         // Setup test objects
         CategoryPlot plot = new CategoryPlot();
         org.jfree.chart.event.PlotChangeListener mockListener = 
             mock(org.jfree.chart.event.PlotChangeListener.class);
         plot.addChangeListener(mockListener);
         
         // Create a dummy axis to trigger the notification
         org.jfree.chart.axis.ValueAxis axis = new org.jfree.chart.axis.NumberAxis();
         plot.setRangeAxis(axis);
         
         // Verify the notification was called with plot as source
         org.mockito.ArgumentCaptor<org.jfree.chart.event.PlotChangeEvent> eventCaptor = 
             org.mockito.ArgumentCaptor.forClass(org.jfree.chart.event.PlotChangeEvent.class);
         verify(mockListener).plotChanged(eventCaptor.capture());
         
         // Assert the event source is the plot itself, not null
         assertSame("Event source should be the plot", plot, eventCaptor.getValue().getSource());
     }

 @Test(expected = IllegalArgumentException.class)
     public void testGetRangeAxisIndexWithNullAxis2() {
         CategoryPlot plot = new CategoryPlot();
         plot.getRangeAxisIndex(null);
     }

 @Test
     public void testGetRangeAxisIndexFoundLocally() {
         // Setup
         CategoryPlot plot = new CategoryPlot();
         ValueAxis axis = mock(ValueAxis.class);
         plot.setRangeAxis(0, axis);
         
         // Test
         int result = plot.getRangeAxisIndex(axis);
         
         // Verify
         assertEquals(0, result);
     }

 @Test
     public void testGetRangeAxisIndexFoundInParent() {
         // Setup
         CategoryPlot parentPlot = new CategoryPlot();
         ValueAxis axis = mock(ValueAxis.class);
         parentPlot.setRangeAxis(0, axis);
         
         CategoryPlot plot = new CategoryPlot();
         plot.setParent(parentPlot);
         
         // Test
         int result = plot.getRangeAxisIndex(axis);
         
         // Verify
         assertEquals(0, result);
     }

 @Test
     public void testGetRangeAxisIndexNotFound() {
         // Setup
         CategoryPlot plot = new CategoryPlot();
         ValueAxis axis = mock(ValueAxis.class);
         
         // Test
         int result = plot.getRangeAxisIndex(axis);
         
         // Verify
         assertEquals(-1, result);
     }

 @Test
     public void testGetRangeAxisIndexWithNonCategoryPlotParent() {
         // Setup
         Plot nonCategoryParent = mock(Plot.class);
         CategoryPlot plot = new CategoryPlot();
         plot.setParent(nonCategoryParent);
         ValueAxis axis = mock(ValueAxis.class);
         
         // Test
         int result = plot.getRangeAxisIndex(axis);
         
         // Verify
         assertEquals(-1, result);
     }

}
