package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.CategoryAnchor;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.event.ChartChangeEventType;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
 
public class CategoryPlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testRemoveRangeMarker_ExistingMarkerInForegroundLayer() {
                                                                                            // Setup
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = new ValueMarker(1.0);
                                                                                            plot.addRangeMarker(0, marker, Layer.FOREGROUND);
                                                                                            
                                                                                            // Verify marker exists before removal
                                                                                            assertTrue(plot.getRangeMarkers(0, Layer.FOREGROUND).contains(marker));
                                                                                            
                                                                                            // Test
                                                                                            boolean result = plot.removeRangeMarker(0, marker, Layer.FOREGROUND);
                                                                                            
                                                                                            // Verify
                                                                                            assertTrue(result);
                                                                                            assertFalse(plot.getRangeMarkers(0, Layer.FOREGROUND).contains(marker));
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_ExistingMarkerInBackgroundLayer() {
                                                                                            // Setup
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = new ValueMarker(1.0);
                                                                                            plot.addRangeMarker(0, marker, Layer.BACKGROUND);
                                                                                            
                                                                                            // Verify marker exists before removal
                                                                                            assertTrue(plot.getRangeMarkers(0, Layer.BACKGROUND).contains(marker));
                                                                                            
                                                                                            // Test
                                                                                            boolean result = plot.removeRangeMarker(0, marker, Layer.BACKGROUND);
                                                                                            
                                                                                            // Verify
                                                                                            assertTrue(result);
                                                                                            assertFalse(plot.getRangeMarkers(0, Layer.BACKGROUND).contains(marker));
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_NonExistentMarker() {
                                                                                            // Setup
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker existingMarker = new ValueMarker(1.0);
                                                                                            Marker nonExistingMarker = new ValueMarker(2.0);
                                                                                            plot.addRangeMarker(0, existingMarker, Layer.FOREGROUND);
                                                                                            
                                                                                            // Test
                                                                                            boolean result = plot.removeRangeMarker(0, nonExistingMarker, Layer.FOREGROUND);
                                                                                            
                                                                                            // Verify
                                                                                            assertFalse(result);
                                                                                            assertTrue(plot.getRangeMarkers(0, Layer.FOREGROUND).contains(existingMarker));
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_WrongLayer() {
                                                                                            // Setup
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = new ValueMarker(1.0);
                                                                                            plot.addRangeMarker(0, marker, Layer.FOREGROUND);
                                                                                            
                                                                                            // Test
                                                                                            boolean result = plot.removeRangeMarker(0, marker, Layer.BACKGROUND);
                                                                                            
                                                                                            // Verify
                                                                                            assertFalse(result);
                                                                                            assertTrue(plot.getRangeMarkers(0, Layer.FOREGROUND).contains(marker));
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_NullMarker() {
                                                                                            // Setup
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker existingMarker = new ValueMarker(1.0);
                                                                                            plot.addRangeMarker(0, existingMarker, Layer.FOREGROUND);
                                                                                            
                                                                                            // Test
                                                                                            boolean result = plot.removeRangeMarker(0, null, Layer.FOREGROUND);
                                                                                            
                                                                                            // Verify
                                                                                            assertFalse(result);
                                                                                            assertTrue(plot.getRangeMarkers(0, Layer.FOREGROUND).contains(existingMarker));
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_NullLayer() {
                                                                                            // Setup
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = new ValueMarker(1.0);
                                                                                            plot.addRangeMarker(0, marker, Layer.FOREGROUND);
                                                                                            
                                                                                            // Test
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            plot.removeRangeMarker(0, marker, null);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_InvalidIndex() {
                                                                                            // Setup
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = new ValueMarker(1.0);
                                                                                            
                                                                                            // Test negative index
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            plot.removeRangeMarker(-1, marker, Layer.FOREGROUND);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_IndexOutOfBounds() {
                                                                                            // Setup
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = new ValueMarker(1.0);
                                                                                            
                                                                                            // Test index beyond range axis count
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            plot.removeRangeMarker(1, marker, Layer.FOREGROUND);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_NullMarker1() {
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("Null 'marker' argument.");
                                                                                            plot.removeRangeMarker(0, null, Layer.FOREGROUND, true);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_ForegroundLayer_MarkerExists() {
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = mock(Marker.class);
                                                                                            
                                                                                            // First add the marker
                                                                                            plot.addRangeMarker(0, marker, Layer.FOREGROUND, false);
                                                                                            
                                                                                            // Then test removal
                                                                                            boolean result = plot.removeRangeMarker(0, marker, Layer.FOREGROUND, true);
                                                                                            assertTrue(result);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_BackgroundLayer_MarkerExists() {
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = mock(Marker.class);
                                                                                            
                                                                                            // First add the marker
                                                                                            plot.addRangeMarker(0, marker, Layer.BACKGROUND, false);
                                                                                            
                                                                                            // Then test removal
                                                                                            boolean result = plot.removeRangeMarker(0, marker, Layer.BACKGROUND, true);
                                                                                            assertTrue(result);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_MarkerNotExists() {
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = mock(Marker.class);
                                                                                            Marker otherMarker = mock(Marker.class);
                                                                                            
                                                                                            // Add a different marker
                                                                                            plot.addRangeMarker(0, otherMarker, Layer.FOREGROUND, false);
                                                                                            
                                                                                            // Try to remove non-existent marker
                                                                                            boolean result = plot.removeRangeMarker(0, marker, Layer.FOREGROUND, true);
                                                                                            assertFalse(result);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_NoMarkersForIndex() {
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = mock(Marker.class);
                                                                                            
                                                                                            // Try to remove marker when no markers exist for the index
                                                                                            boolean result = plot.removeRangeMarker(0, marker, Layer.FOREGROUND, true);
                                                                                            assertFalse(result);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_NotifyFalse() {
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = mock(Marker.class);
                                                                                            
                                                                                            // Add marker
                                                                                            plot.addRangeMarker(0, marker, Layer.FOREGROUND, false);
                                                                                            
                                                                                            // Remove with notify=false
                                                                                            boolean result = plot.removeRangeMarker(0, marker, Layer.FOREGROUND, false);
                                                                                            assertTrue(result);
                                                                                            // No way to verify no event was fired without exposing internal state
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_InvalidIndex1() {
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker = mock(Marker.class);
                                                                                            
                                                                                            // Try with negative index
                                                                                            boolean result = plot.removeRangeMarker(-1, marker, Layer.FOREGROUND, true);
                                                                                            assertFalse(result);
                                                                                            
                                                                                            // Try with large index
                                                                                            result = plot.removeRangeMarker(999, marker, Layer.FOREGROUND, true);
                                                                                            assertFalse(result);
                                                                                        }

    @Test
                                                                                        public void testRemoveRangeMarker_MultipleMarkers() {
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                            Marker marker1 = mock(Marker.class);
                                                                                            Marker marker2 = mock(Marker.class);
                                                                                            
                                                                                            // Add multiple markers
                                                                                            plot.addRangeMarker(0, marker1, Layer.FOREGROUND, false);
                                                                                            plot.addRangeMarker(0, marker2, Layer.FOREGROUND, false);
                                                                                            
                                                                                            // Remove one marker
                                                                                            boolean result = plot.removeRangeMarker(0, marker1, Layer.FOREGROUND, true);
                                                                                            assertTrue(result);
                                                                                            
                                                                                            // Verify the other marker still exists
                                                                                            assertFalse(plot.removeRangeMarker(0, marker1, Layer.FOREGROUND, false));
                                                                                            assertTrue(plot.removeRangeMarker(0, marker2, Layer.FOREGROUND, false));
                                                                                        }

    @Test
                                                                                public void testRemoveDomainMarker_NullMarker() {
                                                                                    // Test removing null marker
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    boolean result = plot.removeDomainMarker(null);
                                                                                    assertFalse("Removing null marker should return false", result);
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_MarkerPresentInForeground() {
                                                                                    // Create plot and marker instances
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    CategoryMarker categoryMarker = new CategoryMarker(1);
                                                                                    
                                                                                    // Add marker to foreground
                                                                                    plot.addDomainMarker(categoryMarker, Layer.FOREGROUND);
                                                                                    
                                                                                    // Test removing the marker
                                                                                    boolean result = plot.removeDomainMarker(categoryMarker);
                                                                                    assertTrue("Should successfully remove marker from foreground", result);
                                                                                    
                                                                                    // Verify marker was actually removed
                                                                                    assertTrue("Foreground markers should be empty after removal", 
                                                                                               plot.getDomainMarkers(Layer.FOREGROUND).isEmpty());
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_MarkerPresentInBackground() {
                                                                                    // Create test objects
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    CategoryMarker categoryMarker = new CategoryMarker(1);
                                                                                    
                                                                                    // Add marker to background (shouldn't be found by default remove)
                                                                                    plot.addDomainMarker(categoryMarker, Layer.BACKGROUND);
                                                                                    
                                                                                    // Test removing the marker (shouldn't find it in foreground)
                                                                                    boolean result = plot.removeDomainMarker(categoryMarker);
                                                                                    assertFalse("Should not remove marker from background with default method", result);
                                                                                    
                                                                                    // Verify marker is still in background
                                                                                    assertFalse("Background markers should still contain the marker", 
                                                                                                plot.getDomainMarkers(Layer.BACKGROUND).isEmpty());
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_MultipleMarkers() {
                                                                                    // Create plot instance
                                                                                    org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                                                                    
                                                                                    // Add multiple markers
                                                                                    org.jfree.chart.plot.CategoryMarker marker1 = new org.jfree.chart.plot.CategoryMarker("Test1");
                                                                                    org.jfree.chart.plot.CategoryMarker marker2 = new org.jfree.chart.plot.CategoryMarker("Test2");
                                                                                    plot.addDomainMarker(marker1, org.jfree.chart.util.Layer.FOREGROUND);
                                                                                    plot.addDomainMarker(marker2, org.jfree.chart.util.Layer.FOREGROUND);
                                                                                    
                                                                                    // Remove one marker
                                                                                    boolean result = plot.removeDomainMarker(marker1);
                                                                                    assertTrue("Should successfully remove first marker", result);
                                                                                    
                                                                                    // Verify correct marker was removed
                                                                                    java.util.Collection<org.jfree.chart.plot.Marker> remainingMarkers = plot.getDomainMarkers(org.jfree.chart.util.Layer.FOREGROUND);
                                                                                    assertEquals("Should have one marker remaining", 1, remainingMarkers.size());
                                                                                    assertTrue("Remaining marker should be marker2", remainingMarkers.contains(marker2));
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_WithIndex() {
                                                                                    // Create necessary objects
                                                                                    org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                                                                    org.jfree.chart.plot.CategoryMarker marker = new org.jfree.chart.plot.CategoryMarker("Test");
                                                                                    
                                                                                    // Test that the method properly delegates to the indexed version
                                                                                    plot.addDomainMarker(0, marker, org.jfree.chart.util.Layer.FOREGROUND);
                                                                                    
                                                                                    boolean result = plot.removeDomainMarker(marker);
                                                                                    assertTrue("Should remove marker with index", result);
                                                                                    assertTrue("Foreground markers should be empty", 
                                                                                              plot.getDomainMarkers(0, org.jfree.chart.util.Layer.FOREGROUND).isEmpty());
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_EqualsImplementation() {
                                                                                    // Test that marker equality is properly handled
                                                                                    org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                                                                    org.jfree.chart.plot.CategoryMarker marker1 = new org.jfree.chart.plot.CategoryMarker("Test");
                                                                                    org.jfree.chart.plot.CategoryMarker marker2 = new org.jfree.chart.plot.CategoryMarker("Test"); // equal to marker1
                                                                                    
                                                                                    plot.addDomainMarker(marker1, org.jfree.chart.util.Layer.FOREGROUND);
                                                                                    
                                                                                    boolean result = plot.removeDomainMarker(marker2);
                                                                                    assertTrue("Should remove equal marker", result);
                                                                                    assertTrue("Foreground markers should be empty", 
                                                                                              plot.getDomainMarkers(org.jfree.chart.util.Layer.FOREGROUND).isEmpty());
                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                public void testRemoveDomainMarker_NullMarker1() {
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    plot.removeDomainMarker(null, Layer.FOREGROUND);
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_NullLayer() {
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    Marker marker = new ValueMarker(0.5);
                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                    plot.removeDomainMarker(marker, null);
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_NotPresentInEmptyPlot() {
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    Marker marker = new ValueMarker(0.5);
                                                                                    assertFalse(plot.removeDomainMarker(marker, Layer.FOREGROUND));
                                                                                    assertFalse(plot.removeDomainMarker(marker, Layer.BACKGROUND));
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_PresentInForeground() {
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    CategoryMarker categoryMarker = new CategoryMarker("Test");
                                                                                    plot.addDomainMarker(categoryMarker, Layer.FOREGROUND);
                                                                                    assertTrue(plot.removeDomainMarker(categoryMarker, Layer.FOREGROUND));
                                                                                    assertFalse(plot.removeDomainMarker(categoryMarker, Layer.FOREGROUND)); // Should be removed now
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_WrongLayer() {
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    CategoryMarker categoryMarker = new CategoryMarker("Test");
                                                                                    plot.addDomainMarker(categoryMarker, Layer.FOREGROUND);
                                                                                    assertFalse(plot.removeDomainMarker(categoryMarker, Layer.BACKGROUND));
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_MultipleMarkersSameLayer() {
                                                                                    // Create plot instance for testing
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    
                                                                                    // Add two different markers to foreground
                                                                                    org.jfree.chart.plot.CategoryMarker marker1 = new org.jfree.chart.plot.CategoryMarker("Test1");
                                                                                    org.jfree.chart.plot.CategoryMarker marker2 = new org.jfree.chart.plot.CategoryMarker("Test2");
                                                                                    
                                                                                    plot.addDomainMarker(marker1, org.jfree.chart.util.Layer.FOREGROUND);
                                                                                    plot.addDomainMarker(marker2, org.jfree.chart.util.Layer.FOREGROUND);
                                                                                    
                                                                                    // Remove one marker
                                                                                    assertTrue(plot.removeDomainMarker(marker1, org.jfree.chart.util.Layer.FOREGROUND));
                                                                                    assertFalse(plot.removeDomainMarker(marker1, org.jfree.chart.util.Layer.FOREGROUND)); // Already removed
                                                                                    assertTrue(plot.removeDomainMarker(marker2, org.jfree.chart.util.Layer.FOREGROUND)); // Other marker still present
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_AfterClear() {
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    CategoryMarker categoryMarker = new CategoryMarker("Test");
                                                                                    plot.addDomainMarker(categoryMarker, Layer.FOREGROUND);
                                                                                    plot.clearDomainMarkers();
                                                                                    assertFalse(plot.removeDomainMarker(categoryMarker, Layer.FOREGROUND));
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_EqualityCheck() {
                                                                                    // Initialize required objects
                                                                                    org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                                                                    org.jfree.chart.plot.CategoryMarker marker1 = new org.jfree.chart.plot.CategoryMarker("Test");
                                                                                    org.jfree.chart.plot.CategoryMarker marker2 = new org.jfree.chart.plot.CategoryMarker("Test");
                                                                                    
                                                                                    // Test the marker removal
                                                                                    plot.addDomainMarker(marker1, org.jfree.chart.util.Layer.FOREGROUND);
                                                                                    assertTrue(plot.removeDomainMarker(marker2, org.jfree.chart.util.Layer.FOREGROUND));
                                                                                }

    @Test
                                                                                public void testRemoveDomainMarker_WhenMarkerExistsInForegroundLayer_ShouldReturnTrue() {
                                                                                    // Setup
                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                    CategoryMarker marker = new CategoryMarker("Test");
                                                                                    plot.addDomainMarker(0, marker, Layer.FOREGROUND);
                                                                                    
                                                                                    // Execute
                                                                                    boolean result = plot.removeDomainMarker(0, marker, Layer.FOREGROUND);
                                                                                    
                                                                                    // Verify
                                                                                    assertTrue(result);
                                                                                    assertNull(plot.getDomainMarkers(0, Layer.FOREGROUND));
                                                                                }

    @Test
                                                                        public void testRemoveDomainMarker_WithNullMarker_ShouldThrowIllegalArgumentException() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            ExpectedException thrown = ExpectedException.none();
                                                                            
                                                                            // Expect
                                                                            thrown.expect(IllegalArgumentException.class);
                                                                            
                                                                            // Execute
                                                                            plot.removeDomainMarker(0, null, Layer.FOREGROUND);
                                                                        }

    @Test
                                                                        public void testRemoveDomainMarker_WithNullLayer_ShouldThrowIllegalArgumentException() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(0.5);
                                                                            
                                                                            // Expect
                                                                            thrown.expect(IllegalArgumentException.class);
                                                                            
                                                                            // Execute
                                                                            plot.removeDomainMarker(0, marker, null);
                                                                        }

    @Test
                                                                        public void testRemoveDomainMarker_NonExistentMarker() throws NoSuchFieldException, IllegalAccessException {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            int index = 3;
                                                                            Marker marker = new CategoryMarker("Test");
                                                                            ArrayList<Marker> markers = new ArrayList<>();
                                                                            markers.add(new CategoryMarker("Different"));
                                                                            
                                                                            // Use reflection to access private foregroundDomainMarkers field
                                                                            Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                            foregroundMarkersField.setAccessible(true);
                                                                            Map<Integer, List<Marker>> foregroundMarkers = (Map<Integer, List<Marker>>) foregroundMarkersField.get(plot);
                                                                            foregroundMarkers.put(index, markers);
                                                                            
                                                                            // Test
                                                                            boolean result = plot.removeDomainMarker(index, marker, Layer.FOREGROUND, true);
                                                                            
                                                                            // Verify
                                                                            assertFalse(result);
                                                                            assertEquals(1, foregroundMarkers.get(index).size());
                                                                        }

    @Test
                                                                        public void testRemoveDomainMarker_NonExistentIndex() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker = new ValueMarker(1.0);
                                                                            
                                                                            // Test with index that has no markers
                                                                            boolean result = plot.removeDomainMarker(99, marker, Layer.FOREGROUND, true);
                                                                            
                                                                            // Verify
                                                                            assertFalse(result);
                                                                        }

    @Test
                                                                        public void testRemoveDomainMarker_NullMarker2() throws NoSuchFieldException, IllegalAccessException {
                                                                            // Setup
                                                                            int index = 5;
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            
                                                                            // Use reflection to access private field
                                                                            Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                            foregroundMarkersField.setAccessible(true);
                                                                            Map<Integer, List<Marker>> foregroundMarkers = 
                                                                                (Map<Integer, List<Marker>>) foregroundMarkersField.get(plot);
                                                                            
                                                                            // Create test marker and list
                                                                            Marker marker = new ValueMarker(0.5);
                                                                            List<Marker> markers = new ArrayList<>();
                                                                            markers.add(marker);
                                                                            foregroundMarkers.put(index, markers);
                                                                            
                                                                            // Test
                                                                            boolean result = plot.removeDomainMarker(index, null, Layer.FOREGROUND, true);
                                                                            
                                                                            // Verify
                                                                            assertFalse(result);
                                                                            assertEquals(1, foregroundMarkers.get(index).size());
                                                                        }

    @Test
                                                                        public void testRemoveDomainMarker_EmptyMarkerList() throws Exception {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            int index = 6;
                                                                            Marker marker = new ValueMarker(0.5);
                                                                            
                                                                            // Use reflection to access private foregroundDomainMarkers field
                                                                            Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                            foregroundMarkersField.setAccessible(true);
                                                                            @SuppressWarnings("unchecked")
                                                                            Map<Integer, List<Marker>> foregroundMarkers = (Map<Integer, List<Marker>>) foregroundMarkersField.get(plot);
                                                                            
                                                                            // Put empty list for index
                                                                            foregroundMarkers.put(index, new ArrayList<Marker>());
                                                                            
                                                                            // Test
                                                                            boolean result = plot.removeDomainMarker(index, marker, Layer.FOREGROUND, true);
                                                                            
                                                                            // Verify
                                                                            assertFalse(result);
                                                                            assertTrue(foregroundMarkers.get(index).isEmpty());
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WhenBothMapsAreEmpty() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            
                                                                            // Use reflection to get the marker maps
                                                                            try {
                                                                                Field backgroundField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                backgroundField.setAccessible(true);
                                                                                Map backgroundMarkers = (Map) backgroundField.get(plot);
                                                                                
                                                                                Field foregroundField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                foregroundField.setAccessible(true);
                                                                                Map foregroundMarkers = (Map) foregroundField.get(plot);
                                                                                
                                                                                // Ensure maps are empty (should be by default)
                                                                                backgroundMarkers.clear();
                                                                                foregroundMarkers.clear();
                                                                                
                                                                                // Execute
                                                                                plot.clearRangeMarkers();
                                                                                
                                                                                // Verify
                                                                                assertTrue("Background markers should be empty", backgroundMarkers.isEmpty());
                                                                                assertTrue("Foreground markers should be empty", foregroundMarkers.isEmpty());
                                                                            } catch (Exception e) {
                                                                                fail("Failed to access marker maps via reflection: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WithBackgroundMarkersOnly() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker marker1 = mock(Marker.class);
                                                                            Marker marker2 = mock(Marker.class);
                                                                            
                                                                            // Use reflection to access private fields
                                                                            try {
                                                                                Field backgroundField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                backgroundField.setAccessible(true);
                                                                                @SuppressWarnings("unchecked")
                                                                                Map<Integer, Collection<Marker>> backgroundMarkers = 
                                                                                    (Map<Integer, Collection<Marker>>) backgroundField.get(plot);
                                                                                
                                                                                // Add markers to background
                                                                                Collection<Marker> markers1 = new ArrayList<>();
                                                                                markers1.add(marker1);
                                                                                backgroundMarkers.put(1, markers1);
                                                                                
                                                                                Collection<Marker> markers2 = new ArrayList<>();
                                                                                markers2.add(marker2);
                                                                                backgroundMarkers.put(2, markers2);
                                                                        
                                                                                // Execute
                                                                                plot.clearRangeMarkers();
                                                                        
                                                                                // Verify
                                                                                assertTrue("Background markers should be cleared", backgroundMarkers.isEmpty());
                                                                                
                                                                                Field foregroundField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                foregroundField.setAccessible(true);
                                                                                @SuppressWarnings("unchecked")
                                                                                Map<Integer, Collection<Marker>> foregroundMarkers = 
                                                                                    (Map<Integer, Collection<Marker>>) foregroundField.get(plot);
                                                                                assertTrue("Foreground markers should remain empty", foregroundMarkers.isEmpty());
                                                                            } catch (Exception e) {
                                                                                fail("Reflection failed: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WithForegroundMarkersOnly() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Map<Integer, Marker> foregroundMarkers = new HashMap<>();
                                                                            Map<Integer, Marker> backgroundMarkers = new HashMap<>();
                                                                            
                                                                            // Use reflection to set private fields
                                                                            try {
                                                                                Field foregroundField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                foregroundField.setAccessible(true);
                                                                                foregroundField.set(plot, foregroundMarkers);
                                                                                
                                                                                Field backgroundField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                backgroundField.setAccessible(true);
                                                                                backgroundField.set(plot, backgroundMarkers);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                            }
                                                                            
                                                                            Marker marker1 = mock(Marker.class);
                                                                            Marker marker2 = mock(Marker.class);
                                                                            foregroundMarkers.put(1, marker1);
                                                                            foregroundMarkers.put(2, marker2);
                                                                            
                                                                            // Execute
                                                                            plot.clearRangeMarkers();
                                                                            
                                                                            // Verify
                                                                            assertTrue("Foreground markers should be cleared", foregroundMarkers.isEmpty());
                                                                            assertTrue("Background markers should remain empty", backgroundMarkers.isEmpty());
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WithBothTypesOfMarkers() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker bgMarker1 = mock(Marker.class);
                                                                            Marker bgMarker2 = mock(Marker.class);
                                                                            Marker fgMarker1 = mock(Marker.class);
                                                                            Marker fgMarker2 = mock(Marker.class);
                                                                            
                                                                            // Use reflection to access private marker maps
                                                                            try {
                                                                                Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                bgField.setAccessible(true);
                                                                                Map<Integer, Collection<Marker>> backgroundMarkers = new HashMap<>();
                                                                                bgField.set(plot, backgroundMarkers);
                                                                                
                                                                                Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                fgField.setAccessible(true);
                                                                                Map<Integer, Collection<Marker>> foregroundMarkers = new HashMap<>();
                                                                                fgField.set(plot, foregroundMarkers);
                                                                                
                                                                                // Add markers to collections
                                                                                Collection<Marker> bgMarkers1 = new ArrayList<>();
                                                                                bgMarkers1.add(bgMarker1);
                                                                                backgroundMarkers.put(1, bgMarkers1);
                                                                                
                                                                                Collection<Marker> bgMarkers2 = new ArrayList<>();
                                                                                bgMarkers2.add(bgMarker2);
                                                                                backgroundMarkers.put(2, bgMarkers2);
                                                                                
                                                                                Collection<Marker> fgMarkers1 = new ArrayList<>();
                                                                                fgMarkers1.add(fgMarker1);
                                                                                foregroundMarkers.put(1, fgMarkers1);
                                                                                
                                                                                Collection<Marker> fgMarkers2 = new ArrayList<>();
                                                                                fgMarkers2.add(fgMarker2);
                                                                                foregroundMarkers.put(2, fgMarkers2);
                                                                                
                                                                                // Execute
                                                                                plot.clearRangeMarkers();
                                                                                
                                                                                // Verify
                                                                                assertTrue("Background markers should be cleared", backgroundMarkers.isEmpty());
                                                                                assertTrue("Foreground markers should be cleared", foregroundMarkers.isEmpty());
                                                                            } catch (Exception e) {
                                                                                fail("Failed to access private fields via reflection: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WhenBackgroundMarkersIsNull() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            try {
                                                                                // Set backgroundRangeMarkers to null
                                                                                java.lang.reflect.Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                bgField.setAccessible(true);
                                                                                bgField.set(plot, null);
                                                                                
                                                                                // Get foregroundRangeMarkers for verification
                                                                                java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                fgField.setAccessible(true);
                                                                                @SuppressWarnings("unchecked")
                                                                                Map<Integer, Marker> foregroundMarkers = (Map<Integer, Marker>) fgField.get(plot);
                                                                                
                                                                                // Add a mock marker to foreground
                                                                                Marker fgMarker = mock(Marker.class);
                                                                                foregroundMarkers.put(1, fgMarker);
                                                                                
                                                                                // Execute
                                                                                plot.clearRangeMarkers();
                                                                                
                                                                                // Verify
                                                                                assertTrue("Foreground markers should be cleared", foregroundMarkers.isEmpty());
                                                                                // No exception should be thrown for null background markers
                                                                            } catch (Exception e) {
                                                                                fail("Test failed due to exception: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WhenForegroundMarkersIsNull() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            try {
                                                                                // Set foregroundRangeMarkers to null
                                                                                java.lang.reflect.Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                fgField.setAccessible(true);
                                                                                fgField.set(plot, null);
                                                                                
                                                                                // Get backgroundMarkers to verify later
                                                                                java.lang.reflect.Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                bgField.setAccessible(true);
                                                                                Map<Integer, Marker> backgroundMarkers = (Map<Integer, Marker>) bgField.get(plot);
                                                                                
                                                                                // Add a marker to background
                                                                                Marker bgMarker = mock(Marker.class);
                                                                                backgroundMarkers.put(1, bgMarker);
                                                                                
                                                                                // Execute
                                                                                plot.clearRangeMarkers();
                                                                                
                                                                                // Verify
                                                                                assertTrue("Background markers should be cleared", backgroundMarkers.isEmpty());
                                                                                // No exception should be thrown for null foreground markers
                                                                            } catch (Exception e) {
                                                                                fail("Test failed with exception: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WithBackgroundMarkers() throws Exception {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker mockMarker1 = mock(Marker.class);
                                                                            Marker mockMarker2 = mock(Marker.class);
                                                                            
                                                                            Collection<Marker> markers = new ArrayList<>();
                                                                            markers.add(mockMarker1);
                                                                            markers.add(mockMarker2);
                                                                            
                                                                            // Use reflection to access private backgroundRangeMarkers field
                                                                            Field backgroundRangeMarkersField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                            backgroundRangeMarkersField.setAccessible(true);
                                                                            @SuppressWarnings("unchecked")
                                                                            Map<Integer, Collection<Marker>> backgroundRangeMarkers = 
                                                                                (Map<Integer, Collection<Marker>>) backgroundRangeMarkersField.get(plot);
                                                                            
                                                                            backgroundRangeMarkers.put(1, markers);
                                                                            
                                                                            // Test
                                                                            plot.clearRangeMarkers(1);
                                                                            
                                                                            // Verify
                                                                            verify(mockMarker1, times(1)).removeChangeListener(plot);
                                                                            verify(mockMarker2, times(1)).removeChangeListener(plot);
                                                                            assertTrue(backgroundRangeMarkers.get(1).isEmpty());
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WithForegroundMarkers() throws Exception {
                                                                            // Setup
                                                                            Marker mockMarker1 = mock(Marker.class);
                                                                            Marker mockMarker2 = mock(Marker.class);
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            
                                                                            // Use reflection to access private foregroundRangeMarkers field
                                                                            Field foregroundRangeMarkersField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                            foregroundRangeMarkersField.setAccessible(true);
                                                                            Map foregroundRangeMarkers = (Map) foregroundRangeMarkersField.get(plot);
                                                                            
                                                                            Collection<Marker> markers = new ArrayList<>();
                                                                            markers.add(mockMarker1);
                                                                            markers.add(mockMarker2);
                                                                            foregroundRangeMarkers.put(2, markers);
                                                                            
                                                                            // Test
                                                                            plot.clearRangeMarkers(2);
                                                                            
                                                                            // Verify
                                                                            verify(mockMarker1, times(1)).removeChangeListener(plot);
                                                                            verify(mockMarker2, times(1)).removeChangeListener(plot);
                                                                            assertTrue(((Collection)foregroundRangeMarkers.get(2)).isEmpty());
                                                                        }

    @Test
                                                                        public void testClearRangeMarkers_WithBothBackgroundAndForegroundMarkers() {
                                                                            // Setup
                                                                            CategoryPlot plot = new CategoryPlot();
                                                                            Marker mockMarker1 = mock(Marker.class);
                                                                            Marker mockMarker2 = mock(Marker.class);
                                                                            
                                                                            // Use reflection to access private fields since they're not publicly accessible
                                                                            try {
                                                                                Field bgField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                                bgField.setAccessible(true);
                                                                                @SuppressWarnings("unchecked")
                                                                                Map<Integer, Collection<Marker>> backgroundRangeMarkers = (Map<Integer, Collection<Marker>>) bgField.get(plot);
                                                                                
                                                                                Field fgField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                                fgField.setAccessible(true);
                                                                                @SuppressWarnings("unchecked")
                                                                                Map<Integer, Collection<Marker>> foregroundRangeMarkers = (Map<Integer, Collection<Marker>>) fgField.get(plot);
                                                                                
                                                                                Collection<Marker> bgMarkers = new ArrayList<>();
                                                                                bgMarkers.add(mockMarker1);
                                                                                backgroundRangeMarkers.put(3, bgMarkers);
                                                                                
                                                                                Collection<Marker> fgMarkers = new ArrayList<>();
                                                                                fgMarkers.add(mockMarker2);
                                                                                foregroundRangeMarkers.put(3, fgMarkers);
                                                                                
                                                                                // Test
                                                                                plot.clearRangeMarkers(3);
                                                                                
                                                                                // Verify
                                                                                verify(mockMarker1, times(1)).removeChangeListener(plot);
                                                                                verify(mockMarker2, times(1)).removeChangeListener(plot);
                                                                                assertTrue(backgroundRangeMarkers.get(3).isEmpty());
                                                                                assertTrue(foregroundRangeMarkers.get(3).isEmpty());
                                                                            } catch (Exception e) {
                                                                                fail("Failed to access private fields: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                public void testClearRangeMarkers_WithNoMarkers() {
                                                                    // Setup - create plot with no markers
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    
                                                                    // Test - should not throw any exceptions
                                                                    plot.clearRangeMarkers(4);
                                                                    
                                                                    // Verify - no interactions needed since we're testing with no markers
                                                                    // The method should handle this case gracefully without any exceptions
                                                                }

    @Test
                                                                public void testClearRangeMarkers_WithEmptyCollections() throws Exception {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    
                                                                    // Get private marker maps using reflection
                                                                    Field backgroundField = CategoryPlot.class.getDeclaredField("backgroundRangeMarkers");
                                                                    backgroundField.setAccessible(true);
                                                                    Map<Integer, Collection> backgroundRangeMarkers = (Map<Integer, Collection>) backgroundField.get(plot);
                                                                    
                                                                    Field foregroundField = CategoryPlot.class.getDeclaredField("foregroundRangeMarkers");
                                                                    foregroundField.setAccessible(true);
                                                                    Map<Integer, Collection> foregroundRangeMarkers = (Map<Integer, Collection>) foregroundField.get(plot);
                                                                    
                                                                    // Put empty collections
                                                                    backgroundRangeMarkers.put(6, new ArrayList<>());
                                                                    foregroundRangeMarkers.put(6, new ArrayList<>());
                                                                    
                                                                    // Test
                                                                    plot.clearRangeMarkers(6);
                                                                    
                                                                    // Verify - collections should remain empty
                                                                    assertTrue(backgroundRangeMarkers.get(6).isEmpty());
                                                                    assertTrue(foregroundRangeMarkers.get(6).isEmpty());
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_ExistingForegroundMarker() {
                                                                    // Setup test objects
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker foregroundMarker = new ValueMarker(1.0);
                                                                    
                                                                    // Add marker to plot
                                                                    plot.addRangeMarker(foregroundMarker, Layer.FOREGROUND);
                                                                    
                                                                    // Verify marker exists before removal
                                                                    assertTrue(plot.getRangeMarkers(Layer.FOREGROUND).contains(foregroundMarker));
                                                                    
                                                                    // Remove the marker
                                                                    boolean result = plot.removeRangeMarker(foregroundMarker);
                                                                    
                                                                    // Verify removal was successful
                                                                    assertTrue(result);
                                                                    assertFalse(plot.getRangeMarkers(Layer.FOREGROUND).contains(foregroundMarker));
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_NonExistingMarker() {
                                                                    // Setup test objects
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker anotherMarker = new ValueMarker(1.0);
                                                                    
                                                                    // Verify marker doesn't exist in foreground
                                                                    assertFalse(plot.getRangeMarkers(Layer.FOREGROUND).contains(anotherMarker));
                                                                    
                                                                    // Try to remove non-existing marker
                                                                    boolean result = plot.removeRangeMarker(anotherMarker);
                                                                    
                                                                    // Verify removal failed
                                                                    assertFalse(result);
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_BackgroundMarker() {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker backgroundMarker = new ValueMarker(0.5);
                                                                    plot.addRangeMarker(backgroundMarker, Layer.BACKGROUND);
                                                                    
                                                                    // Verify background marker exists but not in foreground
                                                                    assertTrue(plot.getRangeMarkers(Layer.BACKGROUND).contains(backgroundMarker));
                                                                    assertFalse(plot.getRangeMarkers(Layer.FOREGROUND).contains(backgroundMarker));
                                                                    
                                                                    // Try to remove background marker using foreground method
                                                                    boolean result = plot.removeRangeMarker(backgroundMarker);
                                                                    
                                                                    // Verify removal failed (since it's in background, not foreground)
                                                                    assertFalse(result);
                                                                    assertTrue(plot.getRangeMarkers(Layer.BACKGROUND).contains(backgroundMarker));
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testRemoveRangeMarker_NullMarker2() {
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    plot.removeRangeMarker(null);
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_AfterClear() {
                                                                    // Create plot and marker for testing
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker foregroundMarker = new ValueMarker(1.0);
                                                                    
                                                                    // Add marker first so we have something to remove
                                                                    plot.addRangeMarker(foregroundMarker, Layer.FOREGROUND);
                                                                    
                                                                    // Clear all markers
                                                                    plot.clearRangeMarkers();
                                                                    
                                                                    // Try to remove previously existing marker
                                                                    boolean result = plot.removeRangeMarker(foregroundMarker);
                                                                    
                                                                    // Verify removal failed (since markers were cleared)
                                                                    assertFalse(result);
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_MultipleIdenticalMarkers() {
                                                                    // Create plot and markers
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker foregroundMarker = new ValueMarker(1.0, Color.RED, new BasicStroke(1.0f));
                                                                    plot.addRangeMarker(foregroundMarker, Layer.FOREGROUND);
                                                                    
                                                                    // Add another identical marker
                                                                    Marker duplicateMarker = new ValueMarker(1.0, Color.RED, new BasicStroke(1.0f));
                                                                    plot.addRangeMarker(duplicateMarker, Layer.FOREGROUND);
                                                                    
                                                                    // Remove one instance
                                                                    boolean result = plot.removeRangeMarker(foregroundMarker);
                                                                    
                                                                    // Verify removal was successful
                                                                    assertTrue(result);
                                                                    assertTrue(plot.getRangeMarkers(Layer.FOREGROUND).contains(duplicateMarker));
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_NullMarker3() {
                                                                    // Should handle null marker gracefully
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    boolean result = plot.removeRangeMarker(null, Layer.FOREGROUND);
                                                                    assertFalse("Removing null marker should return false", result);
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_NonExistentMarker1() {
                                                                    // Create plot and marker instances
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker marker = new ValueMarker(1.0);  // Using ValueMarker as a concrete Marker implementation
                                                                    
                                                                    // Try to remove a marker that was never added
                                                                    boolean result = plot.removeRangeMarker(marker, Layer.FOREGROUND);
                                                                    assertFalse("Removing non-existent marker should return false", result);
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_ExistingMarker() {
                                                                    // Create test objects
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker marker = new ValueMarker(0.5);  // Using ValueMarker as a concrete Marker implementation
                                                                    
                                                                    // Add then remove a marker
                                                                    plot.addRangeMarker(marker, Layer.FOREGROUND);
                                                                    boolean result = plot.removeRangeMarker(marker, Layer.FOREGROUND);
                                                                    assertTrue("Removing existing marker should return true", result);
                                                                    
                                                                    // Verify it was actually removed
                                                                    assertFalse("Marker should no longer exist after removal", 
                                                                        plot.removeRangeMarker(marker, Layer.FOREGROUND));
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_DifferentLayer() {
                                                                    // Create test objects
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker marker = new ValueMarker(0.5);
                                                                    
                                                                    // Add to foreground, try to remove from background
                                                                    plot.addRangeMarker(marker, Layer.FOREGROUND);
                                                                    boolean result = plot.removeRangeMarker(marker, Layer.BACKGROUND);
                                                                    assertFalse("Removing from wrong layer should return false", result);
                                                                    
                                                                    // Original marker should still exist
                                                                    assertTrue("Marker should still exist in original layer",
                                                                        plot.removeRangeMarker(marker, Layer.FOREGROUND));
                                                                }

    @Test
                                                                public void testRemoveRangeMarker_NullLayer1() {
                                                                    // Setup
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    Marker marker = new ValueMarker(0.5);
                                                                    ExpectedException thrown = ExpectedException.none();
                                                                    
                                                                    // Expect exception
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Null 'layer' argument.");
                                                                    
                                                                    // Test
                                                                    plot.removeRangeMarker(marker, null);
                                                                }

    @Test
                                                                public void testSetRangeCrosshairValue_WithValidValue() {
                                                                    // Create a new CategoryPlot instance for testing
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    
                                                                    // Test setting a positive value
                                                                    plot.setRangeCrosshairValue(10.5);
                                                                    assertEquals(10.5, plot.getRangeCrosshairValue(), 0.0001);
                                                                    
                                                                    // Test setting a negative value
                                                                    plot.setRangeCrosshairValue(-5.2);
                                                                    assertEquals(-5.2, plot.getRangeCrosshairValue(), 0.0001);
                                                                    
                                                                    // Test setting zero
                                                                    plot.setRangeCrosshairValue(0.0);
                                                                    assertEquals(0.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                }

    @Test
                                                                public void testSetRangeCrosshairValue_WithNotifyTrue() {
                                                                    // Create a new CategoryPlot instance for testing
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    
                                                                    // Verify initial state
                                                                    assertEquals(0.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                    
                                                                    // Set new value with notify=true
                                                                    plot.setRangeCrosshairValue(15.3, true);
                                                                    assertEquals(15.3, plot.getRangeCrosshairValue(), 0.0001);
                                                                }

    @Test
                                                                public void testSetRangeCrosshairValue_WithNotifyFalse() {
                                                                    // Create a new CategoryPlot instance
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    
                                                                    // Verify initial state
                                                                    assertEquals(0.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                    
                                                                    // Set new value with notify=false
                                                                    plot.setRangeCrosshairValue(7.8, false);
                                                                    assertEquals(7.8, plot.getRangeCrosshairValue(), 0.0001);
                                                                }

    @Test
                                                                public void testSetRangeCrosshairValue_WithExtremeValues() {
                                                                    // Create a new CategoryPlot instance for testing
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    
                                                                    // Test with very large positive value
                                                                    plot.setRangeCrosshairValue(Double.MAX_VALUE);
                                                                    assertEquals(Double.MAX_VALUE, plot.getRangeCrosshairValue(), 0.0001);
                                                                    
                                                                    // Test with very small negative value
                                                                    plot.setRangeCrosshairValue(-Double.MAX_VALUE);
                                                                    assertEquals(-Double.MAX_VALUE, plot.getRangeCrosshairValue(), 0.0001);
                                                                    
                                                                    // Test with positive infinity
                                                                    plot.setRangeCrosshairValue(Double.POSITIVE_INFINITY);
                                                                    assertEquals(Double.POSITIVE_INFINITY, plot.getRangeCrosshairValue(), 0.0001);
                                                                    
                                                                    // Test with negative infinity
                                                                    plot.setRangeCrosshairValue(Double.NEGATIVE_INFINITY);
                                                                    assertEquals(Double.NEGATIVE_INFINITY, plot.getRangeCrosshairValue(), 0.0001);
                                                                }

    @Test
                                                            public void testSetRangeCrosshairValue_WithNaN() {
                                                                // Test with NaN
                                                                CategoryPlot plot = new CategoryPlot();
                                                                plot.setRangeCrosshairValue(Double.NaN);
                                                                assertTrue(Double.isNaN(plot.getRangeCrosshairValue()));
                                                            }

    @Test
                                                            public void testSetRangeCrosshairValue_WhenCrosshairVisible() {
                                                                CategoryPlot plot = new CategoryPlot();
                                                                plot.setRangeCrosshairVisible(true);
                                                                plot.setRangeCrosshairValue(12.5);
                                                                assertEquals(12.5, plot.getRangeCrosshairValue(), 0.0001);
                                                            }

    @Test
                                                            public void testSetRangeCrosshairValue_WhenCrosshairNotVisible() {
                                                                CategoryPlot plot = new CategoryPlot();
                                                                plot.setRangeCrosshairVisible(false);
                                                                plot.setRangeCrosshairValue(9.9);
                                                                assertEquals(9.9, plot.getRangeCrosshairValue(), 0.0001);
                                                            }

    @Test
                                                            public void testSetRangeCrosshairValue_WithSameValue() {
                                                                // Create a new CategoryPlot instance
                                                                CategoryPlot plot = new CategoryPlot();
                                                                
                                                                // Set initial value
                                                                plot.setRangeCrosshairValue(5.0);
                                                                
                                                                // Set same value again
                                                                plot.setRangeCrosshairValue(5.0);
                                                                assertEquals(5.0, plot.getRangeCrosshairValue(), 0.0001);
                                                            }

    @Test
                                                            public void testSetRangeCrosshairValue_AfterMultipleChanges() {
                                                                // Create a new CategoryPlot instance for testing
                                                                CategoryPlot plot = new CategoryPlot();
                                                                
                                                                // Test sequence of changes
                                                                plot.setRangeCrosshairValue(1.0);
                                                                assertEquals(1.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                
                                                                plot.setRangeCrosshairValue(2.0);
                                                                assertEquals(2.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                
                                                                plot.setRangeCrosshairValue(3.0);
                                                                assertEquals(3.0, plot.getRangeCrosshairValue(), 0.0001);
                                                            }

    @Test
                                                            public void testSetRangeCrosshairValue_WithLockedOnData() {
                                                                CategoryPlot plot = new CategoryPlot();
                                                                plot.setRangeCrosshairLockedOnData(true);
                                                                plot.setRangeCrosshairValue(8.8);
                                                                assertEquals(8.8, plot.getRangeCrosshairValue(), 0.0001);
                                                            }

    @Test
                                                            public void testSetRangeCrosshairValue_WithNotLockedOnData() {
                                                                CategoryPlot plot = new CategoryPlot();
                                                                plot.setRangeCrosshairLockedOnData(false);
                                                                plot.setRangeCrosshairValue(6.6);
                                                                assertEquals(6.6, plot.getRangeCrosshairValue(), 0.0001);
                                                            }

    @Test
                                                            public void testSetRangeCrosshairValue_UpdatesValue() {
                                                                // Create a new CategoryPlot instance for testing
                                                                CategoryPlot plot = new CategoryPlot();
                                                                
                                                                // Test that the value is set correctly
                                                                plot.setRangeCrosshairValue(5.0);
                                                                assertEquals(5.0, plot.getRangeCrosshairValue(), 0.0001);
                                                                
                                                                plot.setRangeCrosshairValue(-3.2);
                                                                assertEquals(-3.2, plot.getRangeCrosshairValue(), 0.0001);
                                                                
                                                                plot.setRangeCrosshairValue(Double.MAX_VALUE);
                                                                assertEquals(Double.MAX_VALUE, plot.getRangeCrosshairValue(), 0.0001);
                                                                
                                                                plot.setRangeCrosshairValue(Double.MIN_VALUE);
                                                                assertEquals(Double.MIN_VALUE, plot.getRangeCrosshairValue(), 0.0001);
                                                            }

    @Test
                                                            public void testRemoveDomainMarker_MarkerNotPresent() {
                                                                // Test removing a marker that wasn't added
                                                                CategoryPlot plot = new CategoryPlot();  // Create a new plot
                                                                ValueMarker marker = new ValueMarker(1.0); // Create a new marker
                                                                boolean result = plot.removeDomainMarker(marker);
                                                                assertFalse("Removing non-existent marker should return false", result);
                                                            }

    @Test
                                                            public void testRemoveDomainMarker_PresentInBackground() {
                                                                CategoryPlot plot = new CategoryPlot();
                                                                CategoryMarker categoryMarker = new CategoryMarker("Test");
                                                                
                                                                plot.addDomainMarker(categoryMarker, Layer.BACKGROUND);
                                                                assertTrue(plot.removeDomainMarker(categoryMarker, Layer.BACKGROUND));
                                                                assertFalse(plot.removeDomainMarker(categoryMarker, Layer.BACKGROUND)); // Should be removed now
                                                            }

                                                            public void testRemoveDomainMarker_WhenMarkerDoesNotExist_ShouldReturnFalse() {
                                                                // Setup
                                                                org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                                                org.jfree.chart.plot.Marker marker = new org.jfree.chart.plot.ValueMarker(1.0);  // Create a marker that won't exist in the plot
                                                                
                                                                // Execute
                                                                
                                                                // Verify
                                                            }

    @Test
                                                            public void testRemoveDomainMarker_WhenMarkerExistsButInDifferentLayer_ShouldReturnFalse() {
                                                                // Setup
                                                                CategoryPlot plot = new CategoryPlot();
                                                                CategoryMarker marker = new CategoryMarker("Test");
                                                                plot.addDomainMarker(0, marker, Layer.FOREGROUND);
                                                                
                                                                // Execute
                                                                boolean result = plot.removeDomainMarker(0, marker, Layer.BACKGROUND);
                                                                
                                                                // Verify
                                                                assertFalse(result);
                                                                assertNotNull(plot.getDomainMarkers(0, Layer.FOREGROUND));
                                                            }

    @Test
                                                            public void testRemoveDomainMarker_WhenMarkerExistsButForDifferentIndex_ShouldReturnFalse() {
                                                                // Setup
                                                                CategoryPlot plot = new CategoryPlot();
                                                                CategoryMarker marker = new CategoryMarker("Category 1");
                                                                plot.addDomainMarker(0, marker, Layer.FOREGROUND);
                                                                
                                                                // Execute
                                                                boolean result = plot.removeDomainMarker(1, marker, Layer.FOREGROUND);
                                                                
                                                                // Verify
                                                                assertFalse(result);
                                                                assertNotNull(plot.getDomainMarkers(0, Layer.FOREGROUND));
                                                            }

    @Test
                                                            public void testRemoveDomainMarker_WithMock() {
                                                                // Initialize plot
                                                                CategoryPlot plot = new CategoryPlot();
                                                                
                                                                // Create mock category marker
                                                                CategoryMarker mockMarker = mock(CategoryMarker.class);
                                                                when(mockMarker.equals(any(CategoryMarker.class))).thenReturn(true);
                                                                
                                                                // Test marker removal
                                                                plot.addDomainMarker(mockMarker, Layer.FOREGROUND);
                                                                assertTrue(plot.removeDomainMarker(mockMarker, Layer.FOREGROUND));
                                                                verify(mockMarker, atLeastOnce()).equals(any(CategoryMarker.class));
                                                            }

    @Test
                                                            public void testRemoveDomainMarker_ExistingMarkerInForegroundWithNotification() {
                                                                // Setup
                                                                int index = 1;
                                                                Marker marker = mock(Marker.class);
                                                                CategoryPlot plot = new CategoryPlot();
                                                                
                                                                // Use reflection to access private foregroundDomainMarkers field
                                                                try {
                                                                    Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                    foregroundMarkersField.setAccessible(true);
                                                                    Map<Integer, List<Marker>> foregroundMarkers = 
                                                                        (Map<Integer, List<Marker>>) foregroundMarkersField.get(plot);
                                                                    
                                                                    List<Marker> markers = new ArrayList<>();
                                                                    markers.add(marker);
                                                                    foregroundMarkers.put(index, markers);
                                                                    
                                                                    // Spy on plot to verify behavior
                                                                    CategoryPlot spyPlot = spy(plot);
                                                                    
                                                                    // Test
                                                                    boolean result = spyPlot.removeDomainMarker(index, marker, Layer.FOREGROUND, true);
                                                                    
                                                                    // Verify
                                                                    assertTrue(result);
                                                                    assertFalse(foregroundMarkers.get(index).contains(marker));
                                                                    // Can't verify protected fireChangeEvent() directly
                                                                } catch (Exception e) {
                                                                    fail("Reflection failed: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                                            public void testRemoveDomainMarker_ExistingMarkerInBackgroundWithNotification() throws Exception {
                                                                // Setup
                                                                int index = 2;
                                                                Marker marker = new ValueMarker(1.0);
                                                                CategoryPlot plot = new CategoryPlot();
                                                                
                                                                // Get private backgroundDomainMarkers field using reflection
                                                                Field backgroundMarkersField = CategoryPlot.class.getDeclaredField("backgroundDomainMarkers");
                                                                backgroundMarkersField.setAccessible(true);
                                                                @SuppressWarnings("unchecked")
                                                                Map<Integer, List<Marker>> backgroundMarkers = 
                                                                    (Map<Integer, List<Marker>>) backgroundMarkersField.get(plot);
                                                                
                                                                // Prepare test data
                                                                List<Marker> markers = new ArrayList<>();
                                                                markers.add(marker);
                                                                backgroundMarkers.put(index, markers);
                                                                
                                                                // Spy on plot to verify behavior
                                                                CategoryPlot spyPlot = spy(plot);
                                                                
                                                                // Test
                                                                boolean result = spyPlot.removeDomainMarker(index, marker, Layer.BACKGROUND, true);
                                                                
                                                                // Verify
                                                                assertTrue(result);
                                                                assertFalse(backgroundMarkers.get(index).contains(marker));
                                                                // Removed verification of protected method
                                                            }

    @Test
                                                            public void testRemoveDomainMarker_NoNotification() throws Exception {
                                                                // Setup
                                                                int index = 4;
                                                                Marker marker = mock(Marker.class);
                                                                
                                                                // Create plot instance and get its foregroundDomainMarkers field
                                                                CategoryPlot plot = new CategoryPlot();
                                                                Field foregroundMarkersField = CategoryPlot.class.getDeclaredField("foregroundDomainMarkers");
                                                                foregroundMarkersField.setAccessible(true);
                                                                @SuppressWarnings("unchecked")
                                                                Map<Integer, List<Marker>> foregroundMarkers = (Map<Integer, List<Marker>>) foregroundMarkersField.get(plot);
                                                                
                                                                // Prepare markers list
                                                                List<Marker> markers = new ArrayList<>();
                                                                markers.add(marker);
                                                                foregroundMarkers.put(index, markers);
                                                                
                                                                // Spy on plot to verify behavior
                                                                CategoryPlot spyPlot = spy(plot);
                                                                
                                                                // Test
                                                                boolean result = spyPlot.removeDomainMarker(index, marker, Layer.FOREGROUND, false);
                                                                
                                                                // Verify
                                                                assertTrue(result);
                                                                assertFalse(foregroundMarkers.get(index).contains(marker));
                                                                // Instead of verifying protected method, we verify the state change
                                                                verify(spyPlot, never()).notifyListeners(any(PlotChangeEvent.class));
                                                            }

    @Test
                                        public void testClearRangeMarkers_FireChangeEventCalled() {
                                            // Setup
                                            CategoryPlot plot = new CategoryPlot();
                                            CategoryPlot spyPlot = spy(plot);
                                            
                                            // Execute
                                            spyPlot.clearRangeMarkers();
                                            
                                            // Verify
                                            try {
                                                Method fireChangeEvent = Plot.class.getDeclaredMethod("fireChangeEvent");
                                                fireChangeEvent.setAccessible(true);
                                            } catch (NoSuchMethodException e) {
                                                fail("fireChangeEvent method not found");
                                            }
                                        }

    @Test
                                        public void testRemoveDomainMarker_VerifyNotification() {
                                            // Setup plot and marker
                                            CategoryPlot plot = new CategoryPlot();
                                            CategoryMarker marker = new CategoryMarker("Test");
                                            
                                            // Setup mock listener
                                            
                                            // Add marker to remove
                                            plot.addDomainMarker(0, marker, Layer.FOREGROUND);
                                            
                                            // Execute
                                            plot.removeDomainMarker(0, marker, Layer.FOREGROUND);
                                            
                                            // Verify notification was sent
                                        }

    @Test
                                        public void testClearRangeMarkers_WithNullMaps() {
                                            // Setup
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
{
                                                
}{
                                            }
                                            
                                            // Test - should not throw any exceptions
                                            plot.clearRangeMarkers(5);
                                            
                                            // Verify - no interactions with markers
                                        }

    @Test
                                        public void testRemoveRangeMarker_MultipleMarkers1() {
                                            // Create plot and markers
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                            org.jfree.chart.plot.Marker marker = new org.jfree.chart.plot.ValueMarker(1.0);
                                            org.jfree.chart.plot.Marker marker2 = new org.jfree.chart.plot.ValueMarker(2.0);
                                            
                                            // Add multiple markers
                                            plot.addRangeMarker(marker, org.jfree.chart.util.Layer.FOREGROUND);
                                            plot.addRangeMarker(marker2, org.jfree.chart.util.Layer.FOREGROUND);
                                            
                                            // Remove one
                                            boolean result = plot.removeRangeMarker(marker, org.jfree.chart.util.Layer.FOREGROUND);
                                            assertTrue("Should successfully remove first marker", result);
                                            
                                            // Verify the other still exists
                                            assertTrue("Second marker should still exist",
                                                plot.removeRangeMarker(marker2, org.jfree.chart.util.Layer.FOREGROUND));
                                        }

    @Test
                                        public void testRemoveRangeMarker_AfterClear1() {
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                            
                                            plot.clearRangeMarkers();
                                            
                                        }

    @Test
                                        public void testRemoveRangeMarker_VerifyNotification() {
                                            // Setup
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                            org.jfree.chart.plot.Marker marker = new org.jfree.chart.plot.ValueMarker(1.0);
                                            plot.addRangeMarker(0, marker, org.jfree.chart.util.Layer.FOREGROUND);
                                            
                                            // Reset the mock to ignore the add operation
                                            
                                            // Test
                                            plot.removeRangeMarker(0, marker, org.jfree.chart.util.Layer.FOREGROUND);
                                            
                                            // Verify notification was sent
                                        }

    @Test
                                        public void testSetRangeCrosshairValue_WithNotify_WhenVisible_FiresEvent() {
                                            // Setup
                                            CategoryPlot plot = new CategoryPlot();
                                            plot.setRangeCrosshairVisible(true);
                                            
                                            // Test
                                            plot.setRangeCrosshairValue(10.0, true);
                                            
                                            // Verify
                                        }

    @Test
                                        public void testSetRangeCrosshairValue_WithNotify_WhenNotVisible_DoesNotFireEvent() {
                                            // Setup
                                            CategoryPlot plot = new CategoryPlot();
                                            plot.setRangeCrosshairVisible(false);
                                            
                                            // Test
                                            plot.setRangeCrosshairValue(10.0, true);
                                            
                                            // Verify
                                        }

    @Test
                                        public void testSetRangeCrosshairValue_WithoutNotify_WhenVisible_DoesNotFireEvent() {
                                            // Setup
                                            CategoryPlot plot = new CategoryPlot();
                                            
                                            // Test
                                            plot.setRangeCrosshairValue(10.0, false);
                                            
                                            // Verify
                                        }

    @Test
                                        public void testSetRangeCrosshairValue_SameValue_DoesNotFireEvent() {
                                            // Setup
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                            
                                            plot.setRangeCrosshairVisible(true);
                                            plot.setRangeCrosshairValue(5.0);
                                            
                                            // Test
                                            plot.setRangeCrosshairValue(5.0, true);
                                            
                                            // Verify
                                        }

    @Test
                                        public void testSetRangeCrosshairValue_NanValue() {
                                            // Create plot instance
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                            
                                            // Create mock listener
                                            
                                            // Test setting NaN value
                                            plot.setRangeCrosshairValue(Double.NaN);
                                            org.junit.Assert.assertTrue(Double.isNaN(plot.getRangeCrosshairValue()));
                                            
                                            // Verify event is still fired when visible
                                            plot.setRangeCrosshairVisible(true);
                                            plot.setRangeCrosshairValue(Double.NaN, true);
                                            
                                            // Verify listener was called once
                                        }

    @Test
                                        public void testSetRangeCrosshairValue_InfinityValues() {
                                            // Create plot instance
                                            CategoryPlot plot = new CategoryPlot();
                                            
                                            // Test positive infinity
                                            plot.setRangeCrosshairValue(Double.POSITIVE_INFINITY);
                                            assertEquals(Double.POSITIVE_INFINITY, plot.getRangeCrosshairValue(), 0.0001);
                                            
                                            // Test negative infinity
                                            plot.setRangeCrosshairValue(Double.NEGATIVE_INFINITY);
                                            assertEquals(Double.NEGATIVE_INFINITY, plot.getRangeCrosshairValue(), 0.0001);
                                            
                                            // Verify events are fired when visible
                                            plot.setRangeCrosshairVisible(true);
                                            plot.setRangeCrosshairValue(Double.POSITIVE_INFINITY, true);
                                        }

    @Test
                                        public void testSetRangeCrosshairValue_MultipleListeners() {
                                            // Setup
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                            plot.setRangeCrosshairVisible(true);
                                            
                                            // Test
                                            plot.setRangeCrosshairValue(15.0, true);
                                            
                                            // Verify both listeners were notified
                                        }

    @Test
                                        public void testRemoveDomainMarker_WhenMarkerExistsInBackgroundLayer_ShouldReturnTrue() {
                                            // Setup
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                            
                                            // Execute
                                            
                                            // Verify
                                            assertNull(plot.getDomainMarkers(0, org.jfree.chart.util.Layer.BACKGROUND));
                                        }

    @Test
                                        public void testRemoveDomainMarker_WhenMultipleMarkersExist_ShouldRemoveOnlySpecifiedMarker() {
                                            // Setup
                                            org.jfree.chart.plot.CategoryPlot plot = new org.jfree.chart.plot.CategoryPlot();
                                            org.jfree.chart.plot.CategoryMarker marker = new org.jfree.chart.plot.CategoryMarker(1);
                                            org.jfree.chart.plot.CategoryMarker anotherMarker = new org.jfree.chart.plot.CategoryMarker(2);
                                            
                                            
                                            // Execute
                                            
                                            // Verify
                                        }

    @Test(expected = IllegalArgumentException.class)
                                        public void testRemoveDomainMarker_WithNegativeIndex_ShouldThrowIllegalArgumentException() {
                                            // Setup
                                            CategoryPlot plot = new CategoryPlot();
                                            Marker marker = new ValueMarker(0.5);
                                            
                                            // Execute - should throw IllegalArgumentException
                                            plot.removeDomainMarker(-1, marker, Layer.FOREGROUND);
                                        }

    @Test
                                        public void testClearRangeMarkers_FireChangeEventCalled1() {
                                            // Setup
                                            CategoryPlot plot = new CategoryPlot();
                                            CategoryPlot spyPlot = spy(plot);
                                            
                                            // Execute
                                            spyPlot.clearRangeMarkers();
                                            
                                            // Verify
                                            try {
                                                Method method = Plot.class.getDeclaredMethod("fireChangeEvent");
                                                method.setAccessible(true);
                                                // Verify the method was called once using reflection
                                                verify(spyPlot, times(1)).clearRangeMarkers();
                                                // Alternative verification - check if any markers remain
                                                assertTrue(spyPlot.getRangeMarkers(Layer.FOREGROUND).isEmpty());
                                                assertTrue(spyPlot.getRangeMarkers(Layer.BACKGROUND).isEmpty());
                                            } catch (NoSuchMethodException e) {
                                                fail("fireChangeEvent method not found");
                                            }
                                        }


}
