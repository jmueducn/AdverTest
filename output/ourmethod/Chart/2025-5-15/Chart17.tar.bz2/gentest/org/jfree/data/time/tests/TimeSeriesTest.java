package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                     public void testClone_EmptySeries() throws CloneNotSupportedException {
                                                         // Arrange
                                                         TimeSeries original = new TimeSeries("Test Series");
                                                         
                                                         // Act
                                                         TimeSeries cloned = (TimeSeries) original.clone();
                                                         
                                                         // Assert
                                                         assertNotSame(original, cloned);
                                                         assertEquals(original.getDomainDescription(), cloned.getDomainDescription());
                                                         assertEquals(original.getRangeDescription(), cloned.getRangeDescription());
                                                         assertEquals(original.getTimePeriodClass(), cloned.getTimePeriodClass());
                                                         assertEquals(original.getMaximumItemCount(), cloned.getMaximumItemCount());
                                                         assertEquals(original.getMaximumItemAge(), cloned.getMaximumItemAge());
                                                         assertEquals(original.getItemCount(), cloned.getItemCount());
                                                         assertNotSame(original.getItems(), cloned.getItems());
                                                         assertTrue(cloned.getItems().isEmpty());
                                                     }

    @Test
                                                     public void testClone_WithDataItems() throws CloneNotSupportedException {
                                                         // Arrange
                                                         TimeSeries original = new TimeSeries("Test Series");
                                                         RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                                         RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                                         TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 10.0);
                                                         TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 20.0);
                                                         original.add(item1);
                                                         original.add(item2);
                                                         
                                                         // Act
                                                         TimeSeries cloned = (TimeSeries) original.clone();
                                                         
                                                         // Assert
                                                         assertEquals(original.getItemCount(), cloned.getItemCount());
                                                         assertNotSame(original.getItems(), cloned.getItems());
                                                         
                                                         // Verify data items are deep copied
                                                         List<TimeSeriesDataItem> originalItems = original.getItems();
                                                         List<TimeSeriesDataItem> clonedItems = cloned.getItems();
                                                         for (int i = 0; i < originalItems.size(); i++) {
                                                             assertNotSame(originalItems.get(i), clonedItems.get(i));
                                                             assertEquals(originalItems.get(i).getPeriod(), clonedItems.get(i).getPeriod());
                                                             assertEquals(originalItems.get(i).getValue(), clonedItems.get(i).getValue());
                                                         }
                                                     }

    @Test
                                                     public void testClone_ModifiedCloneDoesNotAffectOriginal() throws CloneNotSupportedException {
                                                         // Arrange
                                                         TimeSeries original = new TimeSeries("Test Series");
                                                         RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                                         TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 10.0);
                                                         original.add(item1);
                                                         
                                                         // Act
                                                         TimeSeries cloned = (TimeSeries) original.clone();
                                                         RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                                         TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 20.0);
                                                         cloned.add(item2);
                                                         
                                                         // Assert
                                                         assertEquals(1, original.getItemCount());
                                                         assertEquals(2, cloned.getItemCount());
                                                         assertFalse(original.getItems().contains(item2));
                                                     }

    @Test
                                                     public void testClone_WithCustomSettings() throws CloneNotSupportedException {
                                                         // Arrange
                                                         TimeSeries original = new TimeSeries("Test Series", "Custom Domain", "Custom Range", Day.class);
                                                         original.setMaximumItemCount(100);
                                                         original.setMaximumItemAge(1000L);
                                                         
                                                         // Act
                                                         TimeSeries cloned = (TimeSeries) original.clone();
                                                         
                                                         // Assert
                                                         assertEquals(original.getDomainDescription(), cloned.getDomainDescription());
                                                         assertEquals(original.getRangeDescription(), cloned.getRangeDescription());
                                                         assertEquals(original.getTimePeriodClass(), cloned.getTimePeriodClass());
                                                         assertEquals(original.getMaximumItemCount(), cloned.getMaximumItemCount());
                                                         assertEquals(original.getMaximumItemAge(), cloned.getMaximumItemAge());
                                                     }

    @Test
                                                     public void testClone_VerifyDeepCopyOfDataList() throws CloneNotSupportedException {
                                                         // Arrange
                                                         TimeSeries original = new TimeSeries("Test Series");
                                                         List<TimeSeriesDataItem> mockData = new ArrayList<>();
                                                         mockData.add(mock(TimeSeriesDataItem.class));
                                                         mockData.add(mock(TimeSeriesDataItem.class));
                                                         
                                                         // Use reflection to set the data field directly for testing purposes
                                                         try {
                                                             java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                             dataField.setAccessible(true);
                                                             dataField.set(original, mockData);
                                                         } catch (Exception e) {
                                                             fail("Failed to set data field via reflection");
                                                         }
                                                         
                                                         // Act
                                                         TimeSeries cloned = (TimeSeries) original.clone();
                                                         
                                                         // Assert
                                                         assertNotSame(mockData, cloned.getItems());
                                                         assertEquals(mockData.size(), cloned.getItems().size());
                                                     }

    @Test
                                             public void testDeleteWhenStartEqualsEndShouldRemoveOneItem() {
                                                 // Setup test data
                                                 TimeSeries series = new TimeSeries("Test Series");
                                                 Day day1 = new Day(1, 1, 2023);
                                                 Day day2 = new Day(2, 1, 2023);
                                                 series.add(day1, 100);
                                                 series.add(day2, 200);
                                                 
                                                 // Get initial count
                                                 int initialCount = series.getItemCount();
                                                 
                                                 // Find index where start equals end
                                                 int index = series.getIndex(day1);
                                                 
                                                 // Perform deletion with start == end
                                                 series.delete(index, index);
                                                 
                                                 // Verify results
                                                 if (index >= 0) {
                                                     // Original behavior: should delete one item when start == end
                                                     assertEquals(initialCount - 1, series.getItemCount());
                                                 } else {
                                                     fail("Test setup failed - couldn't find index for test day");
                                                 }
                                             }

    @Test
                                            public void testDeleteWhenStartEqualsEnd() {
                                                // Setup test data
                                                TimeSeries series = new TimeSeries("Test Series");
                                                series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 100));
                                                series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 200));
                                                series.add(new TimeSeriesDataItem(new Day(3, 1, 2023), 300));
                                                
                                                int initialCount = series.getItemCount();
                                                int testIndex = 1; // middle index
                                                
                                                try {
                                                    // This should remove one item at index 1 in original code
                                                    // But would throw exception in mutated code
                                                    series.delete(testIndex, testIndex);
                                                    
                                                    // Verify one item was removed
                                                    assertEquals(initialCount - 1, series.getItemCount());
                                                    // Verify correct item was removed (original item at index 1 was 200)
                                                    assertEquals(300, series.getValue(1).doubleValue(), 0.0001);
                                                } catch (IllegalArgumentException e) {
                                                    // If we get here, the mutant was detected
                                                    fail("Mutation detected: delete() threw exception when start equals end");
                                                }
                                            }

    @Test
                                        public void testDeleteWithInvalidRangeShouldNotDelete() {
                                            // Setup test data
                                            TimeSeries series = new TimeSeries("Test Series");
                                            Day day1 = new Day(1, 1, 2023);
                                            Day day2 = new Day(2, 1, 2023);
                                            series.add(day1, 100.0);
                                            series.add(day2, 200.0);
                                            
                                            // Get initial state
                                            int initialSize = series.getItemCount();
                                            
                                            // Test delete with invalid range (start > end)
                                            series.delete(1, 0); // start > end
                                            
                                            // Verify no items were deleted
                                            assertEquals("No items should be deleted when start > end", 
                                                         initialSize, series.getItemCount());
                                            
                                            // Verify items remain unchanged
                                            assertEquals(100.0, series.getValue(0).doubleValue(), 0.0001);
                                            assertEquals(200.0, series.getValue(1).doubleValue(), 0.0001);
                                        }

    @Test
                                       public void testDelete_EndLessThanStart_ShouldThrowException() {
                                           org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                           thrown.expect(IllegalArgumentException.class);
                                           thrown.expectMessage("Requires start <= end.");
                                           TimeSeries timeSeries = new TimeSeries("Test Series");
                                           timeSeries.delete(2, 1); // end < start
                                       }

    @Test
                                       public void testDelete_StartEqualsEnd_ShouldNotThrowException() {
                                           TimeSeries timeSeries = new TimeSeries("Test Series");
                                           try {
                                               timeSeries.delete(1, 1); // start == end
                                               // If we get here, the test passes (no exception thrown)
                                           } catch (IllegalArgumentException e) {
                                               fail("Should not throw exception when start == end");
                                           }
                                       }

    @Test
                               public void testDelete_StartLessThanEnd_ShouldNotThrowException() {
                                   // Create a time series with some test data
                                   TimeSeries timeSeries = new TimeSeries("Test Series");
                                   timeSeries.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 1.0));
                                   timeSeries.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 2.0));
                                   timeSeries.add(new TimeSeriesDataItem(new Day(3, 1, 2023), 3.0));
                                   
                                   try {
                                       timeSeries.delete(1, 2); // start < end
                                       // If we get here, the test passes (no exception thrown)
                                   } catch (IllegalArgumentException e) {
                                       fail("Should not throw exception when start < end");
                                   }
                               }

    @Test
                               public void testDeleteWithInvalidRangeThrowsCorrectException() {
                                   TimeSeries series = new TimeSeries("Test Series");
                                   
                                   // Set up expectation for the specific exception message
                                   thrown.expect(IllegalArgumentException.class);
                                   thrown.expectMessage("Requires start <= end.");
                                   
                                   // Call delete with invalid range (start > end)
                                   series.delete(5, 3); // start > end should throw exception
                               }

    @Test
                               public void testDelete_StartGreaterThanEnd_ThrowsExceptionWithCorrectMessage() {
                                   // Setup
                                   TimeSeries series = new TimeSeries("Test Series");
                                   // Add some data to ensure the test isn't failing for empty series
                                   series.add(new TimeSeriesDataItem(new Day(), 1.0));
                                   series.add(new TimeSeriesDataItem(new Day(), 2.0));
                                   
                                   // Set expectations
                                   thrown.expect(IllegalArgumentException.class);
                                   thrown.expectMessage("Requires start <= end.");
                                   
                                   // Test - start > end should throw exception
                                   series.delete(1, 0);
                               }

    @Test(expected = IllegalArgumentException.class)
                          public void testDeleteWithInvalidRangeThrowsIllegalArgumentException() {
                              // Setup test data
                              TimeSeries series = new TimeSeries("Test Series");
                              Day day1 = new Day(1, 1, 2023);
                              Day day2 = new Day(2, 1, 2023);
                              series.add(day1, 100.0);
                              series.add(day2, 200.0);
                              
                              // This should throw IllegalArgumentException since start > end
                              // If it throws NullPointerException instead, the test will fail
                              series.delete(1, 0);
                          }

    @Test
                         public void testDelete_StartGreaterThanEnd_ThrowsIllegalArgumentException() {
                             // Setup
                             TimeSeries timeSeries = new TimeSeries("Test Series");
                             // Initialize with some data using public methods
                             timeSeries.add(new TimeSeriesDataItem(new Day(), 1.0));
                             timeSeries.add(new TimeSeriesDataItem(new Day(), 2.0));
                             
                             // Set expectation for the correct exception
                             thrown.expect(IllegalArgumentException.class);
                             thrown.expectMessage("Requires start <= end.");
                             
                             // Test - start > end should throw IllegalArgumentException
                             timeSeries.delete(1, 0);
                         }

    @Test
                     public void testDeleteRangeShouldRemoveAllItemsIncludingEndIndex() {
                         // Setup - create a time series with 5 items
                         TimeSeries series = new TimeSeries("Test");
                         for (int i = 0; i < 5; i++) {
                             series.add(new Day(i+1, 1, 2000), i+1); // Adding sample data
                         }
                         
                         // Verify initial state
                         assertEquals(5, series.getItemCount());
                         
                         // Execute - delete items from index 1 to 3 (inclusive)
                         series.delete(1, 3);
                         
                         // Verify - should have 2 items left (index 0 and 4)
                         assertEquals(2, series.getItemCount());
                         
                         // Verify specific items - index 0 and 4 should remain
                         assertEquals(1, series.getValue(0).intValue()); // First item remains
                         assertEquals(5, series.getValue(1).intValue()); // Last item remains
                         
                         // This test will fail with the mutant because:
                         // Original: deletes indices 1,2,3 (3 items)
                         // Mutant: would only delete indices 1,2 (2 items), leaving index 3
                         // So with mutant, itemCount would be 3 instead of 2
                         // and series.getValue(1) would be 3 instead of 5
                     }

    @Test
                     public void testDeleteRangeShouldRemoveAllElementsInRange() {
                         // Setup test data
                         TimeSeries series = new TimeSeries("Test");
                         // Add 5 items to the series
                         for (int i = 0; i < 5; i++) {
                             series.add(new Day(i+1, 1, 2000), i);
                         }
                         
                         // Verify initial state
                         assertEquals(5, series.getItemCount());
                         
                         // Test deleting range from index 1 to 3 (should remove 3 elements)
                         series.delete(1, 3);
                         
                         // Verify correct number of elements removed
                         // Original code would leave 2 elements (5 - 3 = 2)
                         // Mutant would leave 3 elements (5 - 2 = 3)
                         assertEquals(2, series.getItemCount());
                         
                         // Verify remaining elements are correct
                         assertEquals(0, series.getValue(0).intValue()); // First element remains
                         assertEquals(4, series.getValue(1).intValue()); // Last element remains
                     }

    @Test
                     public void testDeleteSingleElementRange() {
                         // Setup test data
                         TimeSeries series = new TimeSeries("Test");
                         series.add(new Day(1, 1, 2000), 10);
                         series.add(new Day(2, 1, 2000), 20);
                         
                         // Test deleting single element (start == end)
                         series.delete(1, 1);
                         
                         // Both original and mutant should behave same for single element
                         assertEquals(1, series.getItemCount());
                         assertEquals(10, series.getValue(0).intValue());
                     }

    @Test(expected = IllegalArgumentException.class)
                     public void testDeleteInvalidRangeThrowsException() {
                         TimeSeries series = new TimeSeries("Test");
                         series.delete(2, 1); // start > end should throw
                     }

    @Test
                    public void testDeleteRangeShouldRemoveAllItemsIncludingFirst() {
                        // Setup
                        TimeSeries series = new TimeSeries("Test Series");
                        Day day1 = new Day(1, 1, 2023);
                        Day day2 = new Day(2, 1, 2023);
                        Day day3 = new Day(3, 1, 2023);
                        Day day4 = new Day(4, 1, 2023);
                        
                        series.add(day1, 1.0);
                        series.add(day2, 2.0);
                        series.add(day3, 3.0);
                        series.add(day4, 4.0);
                        
                        // Action - delete items at indices 1 to 2 (day2 and day3)
                        series.delete(1, 2);
                        
                        // Verification
                        assertEquals(2, series.getItemCount());
                        assertEquals(day1, series.getTimePeriod(0));  // Should remain
                        assertEquals(day4, series.getTimePeriod(1));  // Should remain
                        
                        // Verify day2 and day3 were deleted
                        try {
                            series.getTimePeriod(2);
                            fail("Should throw IndexOutOfBoundsException");
                        } catch (IndexOutOfBoundsException e) {
                            // expected
                        }
                        
                        // Specifically verify first item in range (day2) was deleted
                        assertNull(series.getDataItem(day2));
                        
                        // Specifically verify last item in range (day3) was deleted
                        assertNull(series.getDataItem(day3));
                    }

    @Test
                    public void testDeleteShouldRemoveAllElementsBetweenStartAndEndInclusive() {
                        // Setup test data
                        TimeSeries series = new TimeSeries("Test Series");
                        // Add 5 items to the series (indices 0-4)
                        for (int i = 0; i < 5; i++) {
                            series.add(new Day(i+1, 1, 2000), i);
                        }
                        
                        // Verify initial state
                        assertEquals(5, series.getItemCount());
                        
                        // Test deletion of 3 items (indices 1-3)
                        series.delete(1, 3);
                        
                        // Verify correct items remain
                        assertEquals(2, series.getItemCount());  // Should have items at 0 and 4 left
                        assertNotNull(series.getDataItem(0));   // First item should remain
                        assertNotNull(series.getDataItem(1));   // Last item should remain (now at index 1)
                        
                        // This test will fail with the mutant because:
                        // Original: removes 3 items (indices 1,2,3) -> 2 items remain
                        // Mutant: removes only 2 items (indices 1,2) -> 3 items remain (would fail assertEquals(2,...))
                    }

    @Test
                   public void testDeleteStartEndShouldNotDeleteExtraItem() {
                       // Setup test data
                       TimeSeries series = new TimeSeries("Test");
                       Day day1 = new Day(1, 1, 2023);
                       Day day2 = new Day(2, 1, 2023);
                       Day day3 = new Day(3, 1, 2023);
                       
                       series.add(day1, 1.0);
                       series.add(day2, 2.0);
                       series.add(day3, 3.0);
                       
                       // Original behavior should delete only items 1-2 (indices 0-1)
                       series.delete(0, 1);
                       
                       // Verify only two items were deleted (original would pass, mutant would fail)
                       assertEquals(1, series.getItemCount());
                       assertEquals(day3, series.getTimePeriod(0));
                       
                       // Test boundary case where end is last index
                       series = new TimeSeries("Test2");
                       series.add(day1, 1.0);
                       series.add(day2, 2.0);
                       
                       // This should only delete one item (index 1)
                       series.delete(1, 1);
                       
                       // Verify correct behavior (mutant would throw IndexOutOfBoundsException)
                       assertEquals(1, series.getItemCount());
                       assertEquals(day1, series.getTimePeriod(0));
                       
                       // Test case where start equals end (should delete exactly one item)
                       series = new TimeSeries("Test3");
                       series.add(day1, 1.0);
                       series.add(day2, 2.0);
                       series.add(day3, 3.0);
                       
                       series.delete(1, 1);
                       
                       assertEquals(2, series.getItemCount());
                       assertEquals(day1, series.getTimePeriod(0));
                       assertEquals(day3, series.getTimePeriod(1));
                   }

    @Test
                   public void testDeleteShouldRemoveExactlyEndMinusStartPlusOneItems() {
                       // Setup test data
                       TimeSeries series = new TimeSeries("Test Series");
                       // Add 5 items to the series (indices 0-4)
                       for (int i = 0; i < 5; i++) {
                           series.add(new TimeSeriesDataItem(new Day(i+1, 1, 2023), i));
                       }
                       
                       // Original list size
                       int originalSize = series.getItemCount();
                       
                       // Test parameters - delete items 1 to 3 (3 items total)
                       int start = 1;
                       int end = 3;
                       int expectedRemoved = end - start + 1;
                       
                       // Execute delete
                       series.delete(start, end);
                       
                       // Verify correct number of items removed
                       assertEquals(originalSize - expectedRemoved, series.getItemCount());
                       
                       // Verify remaining items - index 0 should remain, index 1 should now be original index 4
                       assertEquals(0.0, series.getValue(0).doubleValue(), 0.0001);
                       assertEquals(4.0, series.getValue(1).doubleValue(), 0.0001);
                   }

    @Test
                  public void testDeleteRemovesCorrectItem() {
                      // Setup test data
                      TimeSeries series = new TimeSeries("Test Series");
                      Day day1 = new Day(1, 1, 2023);
                      Day day2 = new Day(2, 1, 2023);
                      Day day3 = new Day(3, 1, 2023);
                      
                      // Add items to the series
                      series.add(day1, 10.0);
                      series.add(day2, 20.0);
                      series.add(day3, 30.0);
                      
                      // Verify initial state
                      assertEquals(3, series.getItemCount());
                      assertEquals(day1, series.getTimePeriod(0));
                      assertEquals(day2, series.getTimePeriod(1));
                      assertEquals(day3, series.getTimePeriod(2));
                      
                      // Delete middle item (day2)
                      series.delete(day2);
                      
                      // Verify correct item was removed
                      assertEquals(2, series.getItemCount());
                      assertEquals(day1, series.getTimePeriod(0));  // First item should remain
                      assertEquals(day3, series.getTimePeriod(1));  // Last item should remain
                      
                      // The mutant would incorrectly remove the last item (day3) instead of day2,
                      // leaving the series with day1 and day2, which this test would catch
                  }

    @Test
                  public void testDeleteRangeShouldRemoveCorrectElements() {
                      // Setup test data
                      TimeSeries series = new TimeSeries("Test");
                      List<TimeSeriesDataItem> testItems = new ArrayList<>();
                      for (int i = 0; i < 5; i++) {
                          TimeSeriesDataItem item = new TimeSeriesDataItem(new Day(i+1, 1, 2023), i);
                          testItems.add(item);
                          series.add(item);
                      }
                      
                      // Expected remaining items after deletion (remove indices 1-3)
                      List<TimeSeriesDataItem> expectedRemaining = new ArrayList<>();
                      expectedRemaining.add(testItems.get(0));
                      expectedRemaining.add(testItems.get(4));
                      
                      // Execute deletion
                      series.delete(1, 3);
                      
                      // Verify remaining items
                      assertEquals(2, series.getItemCount());
                      assertEquals(expectedRemaining.get(0), series.getDataItem(0));
                      assertEquals(expectedRemaining.get(1), series.getDataItem(1));
                      
                      // This test would fail with the mutant because:
                      // - Original: Would remove indices 1,2,3 (correct)
                      // - Mutant: Would remove index 3 three times (incorrect)
                      //   Leaving indices 0,1,2,4 (wrong)
                  }

    @Test
                 public void testDelete_ShouldRemoveCorrectItem_WhenIndexIsValid() {
                     // Setup test data
                     TimeSeries series = new TimeSeries("Test Series");
                     RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                     RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                     RegularTimePeriod period3 = mock(RegularTimePeriod.class);
                     
                     TimeSeriesDataItem item1 = new TimeSeriesDataItem(period1, 1.0);
                     TimeSeriesDataItem item2 = new TimeSeriesDataItem(period2, 2.0);
                     TimeSeriesDataItem item3 = new TimeSeriesDataItem(period3, 3.0);
                     
                     // Mock getIndex to return specific indices for test periods
                     when(series.getIndex(period1)).thenReturn(0);
                     when(series.getIndex(period2)).thenReturn(1);
                     when(series.getIndex(period3)).thenReturn(2);
                     
                     // Add items to series (using reflection since add methods might be complex)
                     try {
                         Field dataField = TimeSeries.class.getDeclaredField("data");
                         dataField.setAccessible(true);
                         List<TimeSeriesDataItem> data = new ArrayList<>();
                         data.add(item1);
                         data.add(item2);
                         data.add(item3);
                         dataField.set(series, data);
                     } catch (Exception e) {
                         fail("Failed to setup test data");
                     }
                     
                     // Test deletion of middle item
                     series.delete(period2);
                     
                     // Verify correct item was removed
                     assertEquals(2, series.getItemCount());
                     assertEquals(item1, series.getDataItem(0));
                     assertEquals(item3, series.getDataItem(1));
                     
                     // Verify the item at index+1 wasn't removed (would happen with mutant)
                     assertNotNull(series.getDataItem(1));
                 }

    @Test
                public void testDeleteRangeShouldRemoveCorrectElements1() {
                    // Setup test data
                    TimeSeries series = new TimeSeries("Test");
                    for (int i = 0; i < 5; i++) {
                        series.add(new TimeSeriesDataItem(new Day(i+1, 1, 2023), i));
                    }
                    
                    // Execute deletion
                    series.delete(1, 3); // Should remove indices 1, 2, 3
                    
                    // Verify results
                    assertEquals(2, series.getItemCount()); // Should have 2 items left
                    assertEquals(0, series.getValue(0).intValue()); // First item remains
                    assertEquals(4, series.getValue(1).intValue()); // Last item remains
                    
                    // The mutant would fail here because:
                    // Original: removes index 1 three times (removes 1, then new 1, then new 1)
                    // Mutant: tries to remove 1, 2, 3 - but after first removal, indices shift
                    // So mutant would leave different elements (likely 0 and 3)
                }

    @Test
            public void testDeleteShouldRemoveCorrectItemWhenNotFirst() {
                // Setup test data
                TimeSeries series = new TimeSeries("Test Series");
                Day day1 = new Day(1, 1, 2023);
                Day day2 = new Day(2, 1, 2023);
                Day day3 = new Day(3, 1, 2023);
                
                // Add multiple items to the series
                series.add(day1, 10.0);
                series.add(day2, 20.0);
                series.add(day3, 30.0);
                
                // Verify initial state
                assertEquals(3, series.getItemCount());
                assertEquals(10.0, series.getValue(0).doubleValue(), 0.001);
                assertEquals(20.0, series.getValue(1).doubleValue(), 0.001);
                assertEquals(30.0, series.getValue(2).doubleValue(), 0.001);
                
                // Delete the middle item (index 1)
                series.delete(day2);
                
                // Verify correct item was removed
                assertEquals(2, series.getItemCount());
                assertEquals(10.0, series.getValue(0).doubleValue(), 0.001);  // First item should remain
                assertEquals(30.0, series.getValue(1).doubleValue(), 0.001);  // Third item should move to position 1
                
                // The mutant would fail here because:
                // - It would remove index 0 instead of index 1
                // - We'd see 20.0 at position 0 and 30.0 at position 1
                // - Item count would still be 2, but wrong items would remain
            }

    @Test
           public void testDeleteRangeShouldRemoveCorrectItems() {
               // Setup - create TimeSeries with sample data
               TimeSeries series = new TimeSeries("Test");
               series.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10)); // index 0
               series.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 20)); // index 1
               series.add(new TimeSeriesDataItem(new Day(3, 1, 2023), 30)); // index 2
               series.add(new TimeSeriesDataItem(new Day(4, 1, 2023), 40)); // index 3
               
               // Execute - delete items from index 1 to 2
               series.delete(1, 2);
               
               // Verify - only items at index 1 and 2 should be removed
               assertEquals(2, series.getItemCount());
               assertEquals(10, series.getValue(0)); // first item remains
               assertEquals(40, series.getValue(1)); // last item remains (originally index 3)
               
               // With the mutant, this would fail because:
               // - It would remove index 0 first (value 10)
               // - Then remove the new index 0 (now value 20)
               // - Leaving items 30 and 40, which is wrong
           }

    @Test
       public void testDeleteShouldFireSeriesChangedEvent() {
           // Setup test data
           TimeSeries series = new TimeSeries("Test Series");
           RegularTimePeriod period = new Day(); // Using Day as example time period
           TimeSeriesDataItem item = new TimeSeriesDataItem(period, 100);
           
           // Add item to series
           series.add(item);
           
           // Create spy to verify method calls
           TimeSeries spySeries = spy(series);
           
           // Perform deletion
           spySeries.delete(period);
           
           // Verify fireSeriesChanged was called
           verify(spySeries).fireSeriesChanged();
           
           // Additional verification that item was actually removed
           assertEquals(0, spySeries.getItemCount());
       }

    @Test
       public void testDeleteShouldFireSeriesChanged() {
           // Setup
           TimeSeries series = spy(new TimeSeries("Test Series"));
           series.add(new TimeSeriesDataItem(new Day(), 1.0));
           series.add(new TimeSeriesDataItem(new Day(), 2.0));
           series.add(new TimeSeriesDataItem(new Day(), 3.0));
           
           // Action
           series.delete(0, 1); // Delete first two items
           
           // Verification
           verify(series, times(1)).fireSeriesChanged();
           
           // Additional check to ensure data was actually deleted
           assertEquals(1, series.getItemCount());
       }

    @Test
          public void testDeleteShouldFireSeriesChangedExactlyOnce() {
              // Setup
              TimeSeries series = spy(new TimeSeries("Test Series"));
              RegularTimePeriod period = mock(RegularTimePeriod.class);
              
              // Stub getIndex to return a valid index
              when(series.getIndex(period)).thenReturn(0);
              
              // Execute
              series.delete(period);
              
              // Verify fireSeriesChanged was called exactly once
              verify(series, times(1)).fireSeriesChanged();
          }

    @Test
          public void testDeleteShouldFireSeriesChangedExactlyOnce1() {
              // Create a spy of TimeSeries to track method calls
              TimeSeries series = spy(new TimeSeries("Test Series"));
              
              // Add some test data
              series.add(new TimeSeriesDataItem(new Day(), 1.0));
              series.add(new TimeSeriesDataItem(new Day(), 2.0));
              series.add(new TimeSeriesDataItem(new Day(), 3.0));
              
              // Perform the delete operation
              series.delete(0, 1);
              
              // Verify fireSeriesChanged was called exactly once
              verify(series, times(1)).fireSeriesChanged();
              
              // Additional verification that items were actually deleted
              assertEquals(1, series.getItemCount());
          }

    @Test
    public void testCloneCreatesIndependentDataCopy() throws CloneNotSupportedException {
        // Setup original series with test data
        TimeSeries original = new TimeSeries("Test");
        RegularTimePeriod period1 = new Day(); // assuming Day is a RegularTimePeriod
        RegularTimePeriod period2 = new Day();
        original.add(period1, 10.0);
        original.add(period2, 20.0);
        
        // Create clone
        TimeSeries clone = (TimeSeries) original.clone();
        
        // Verify initial state
        assertEquals(2, original.getItemCount());
        assertEquals(2, clone.getItemCount());
        
        // Modify original (delete an item)
        original.delete(period1);
        
        // Verify clone remains unchanged (should have independent data)
        assertEquals(1, original.getItemCount()); // original modified
        assertEquals(2, clone.getItemCount());    // clone should remain unchanged
        
        // Additional verification that clone still has the deleted item
        assertNotNull(clone.getDataItem(period1));
        assertEquals(10.0, clone.getValue(period1).doubleValue(), 0.0001);
    }

    @Test
    public void testCloneCreatesDeepCopyOfData() throws CloneNotSupportedException {
        // Setup original series with test data
        TimeSeries original = new TimeSeries("Test");
        original.add(new Day(1, 1, 2023), 100);
        original.add(new Day(2, 1, 2023), 200);
        original.add(new Day(3, 1, 2023), 300);
        
        // Create clone
        TimeSeries clone = (TimeSeries) original.clone();
        
        // Verify initial equality
        assertEquals(original.getItemCount(), clone.getItemCount());
        
        // Modify original (delete some items)
        original.delete(0, 1); // Delete first two items
        
        // Verify clone remains unchanged (should be deep copy)
        assertEquals(3, clone.getItemCount()); // Clone should still have 3 items
        assertNotEquals(original.getItemCount(), clone.getItemCount());
        
        // Verify clone data is independent
        assertNotSame(original.getItems(), clone.getItems());
    }


}
