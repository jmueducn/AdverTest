package gentest.org.jfree.chart.renderer.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.category.*;
import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.RenderingSource;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.CategoryItemEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.CategorySeriesLabelGenerator;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategorySeriesLabelGenerator;
import org.jfree.chart.plot.CategoryCrosshairState;
import org.jfree.chart.plot.CategoryMarker;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DrawingSupplier;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.AbstractRenderer;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.urls.CategoryURLGenerator;
import org.jfree.chart.util.GradientPaintTransformer;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.LengthAdjustmentType;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleAnchor;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryDatasetSelectionState;
import org.jfree.data.category.SelectableCategoryDataset;
import org.jfree.data.general.DatasetUtilities;
 
public class AbstractCategoryItemRendererTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                           public void testGetLegendItems_WhenDatasetIsNull_ReturnsEmptyCollection() {
                                                                                                                               // Create mocks
                                                                                                                               AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                                                               CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                               
                                                                                                                               // Set up mock behavior
                                                                                                                               when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                               when(plot.getDataset(0)).thenReturn(null);
                                                                                                                               
                                                                                                                               // Set the plot on the renderer
                                                                                                                               renderer.setPlot(plot);
                                                                                                                               
                                                                                                                               // Call the method under test
                                                                                                                               LegendItemCollection result = renderer.getLegendItems();
                                                                                                                               
                                                                                                                               // Verify results
                                                                                                                               assertNotNull(result);
                                                                                                                               assertEquals(0, result.getItemCount());
                                                                                                                           }

    @Test
                                                                                                                           public void testGetLegendItems_WithAscendingOrder_ReturnsItemsInOrder() {
                                                                                                                               // Create mock objects
                                                                                                                               AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                                                               CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                               CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                               
                                                                                                                               // Set up mock behavior
                                                                                                                               renderer.setPlot(plot);
                                                                                                                               when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                               when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                               when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                               when(dataset.getRowCount()).thenReturn(3);
                                                                                                                               
                                                                                                                               // Mock legend items
                                                                                                                               LegendItem item1 = new LegendItem("Series 1");
                                                                                                                               LegendItem item2 = new LegendItem("Series 2");
                                                                                                                               LegendItem item3 = new LegendItem("Series 3");
                                                                                                                               
                                                                                                                               // Mock series visibility and legend items
                                                                                                                               doReturn(true).when(renderer).isSeriesVisibleInLegend(0);
                                                                                                                               doReturn(true).when(renderer).isSeriesVisibleInLegend(1);
                                                                                                                               doReturn(true).when(renderer).isSeriesVisibleInLegend(2);
                                                                                                                               doReturn(item1).when(renderer).getLegendItem(0, 0);
                                                                                                                               doReturn(item2).when(renderer).getLegendItem(0, 1);
                                                                                                                               doReturn(item3).when(renderer).getLegendItem(0, 2);
                                                                                                                               
                                                                                                                               LegendItemCollection result = renderer.getLegendItems();
                                                                                                                               assertNotNull(result);
                                                                                                                               assertEquals(3, result.getItemCount());
                                                                                                                               assertEquals(item1, result.get(0));
                                                                                                                               assertEquals(item2, result.get(1));
                                                                                                                               assertEquals(item3, result.get(2));
                                                                                                                           }

    @Test
                                                                                                                           public void testGetLegendItems_WithDescendingOrder_ReturnsItemsInReverseOrder() {
                                                                                                                               // Create mock objects
                                                                                                                               AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                                                               CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                               CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                               
                                                                                                                               // Set up mock behavior
                                                                                                                               renderer.setPlot(plot);
                                                                                                                               when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                               when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                               when(plot.getRowRenderingOrder()).thenReturn(SortOrder.DESCENDING);
                                                                                                                               when(dataset.getRowCount()).thenReturn(3);
                                                                                                                               
                                                                                                                               // Mock legend items
                                                                                                                               LegendItem item1 = new LegendItem("Series 1");
                                                                                                                               LegendItem item2 = new LegendItem("Series 2");
                                                                                                                               LegendItem item3 = new LegendItem("Series 3");
                                                                                                                               
                                                                                                                               // Mock series visibility and legend items
                                                                                                                               doReturn(true).when(renderer).isSeriesVisibleInLegend(0);
                                                                                                                               doReturn(true).when(renderer).isSeriesVisibleInLegend(1);
                                                                                                                               doReturn(true).when(renderer).isSeriesVisibleInLegend(2);
                                                                                                                               doReturn(item1).when(renderer).getLegendItem(0, 0);
                                                                                                                               doReturn(item2).when(renderer).getLegendItem(0, 1);
                                                                                                                               doReturn(item3).when(renderer).getLegendItem(0, 2);
                                                                                                                               
                                                                                                                               LegendItemCollection result = renderer.getLegendItems();
                                                                                                                               assertNotNull(result);
                                                                                                                               assertEquals(3, result.getItemCount());
                                                                                                                               assertEquals(item3, result.get(0));
                                                                                                                               assertEquals(item2, result.get(1));
                                                                                                                               assertEquals(item1, result.get(2));
                                                                                                                           }

    @Test
                                                                                                                           public void testGetLegendItems_WithSomeInvisibleSeries_ReturnsOnlyVisibleItems() {
                                                                                                                               // Create mock objects
                                                                                                                               AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                                                               CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                               CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                               
                                                                                                                               // Setup mock behavior
                                                                                                                               renderer.setPlot(plot);
                                                                                                                               when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                               when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                               when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                               when(dataset.getRowCount()).thenReturn(3);
                                                                                                                               
                                                                                                                               // Mock legend items
                                                                                                                               LegendItem item1 = new LegendItem("Series 1");
                                                                                                                               LegendItem item3 = new LegendItem("Series 3");
                                                                                                                               
                                                                                                                               // Mock series visibility (series 2 is invisible)
                                                                                                                               doReturn(true).when(renderer).isSeriesVisibleInLegend(0);
                                                                                                                               doReturn(false).when(renderer).isSeriesVisibleInLegend(1);
                                                                                                                               doReturn(true).when(renderer).isSeriesVisibleInLegend(2);
                                                                                                                               doReturn(item1).when(renderer).getLegendItem(0, 0);
                                                                                                                               doReturn(null).when(renderer).getLegendItem(0, 1);
                                                                                                                               doReturn(item3).when(renderer).getLegendItem(0, 2);
                                                                                                                               
                                                                                                                               LegendItemCollection result = renderer.getLegendItems();
                                                                                                                               assertNotNull(result);
                                                                                                                               assertEquals(2, result.getItemCount());
                                                                                                                               assertEquals(item1, result.get(0));
                                                                                                                               assertEquals(item3, result.get(1));
                                                                                                                           }

    @Test
                                                                                                                       public void testGetLegendItems_WhenPlotIsNull_ReturnsEmptyCollection() {
                                                                                                                           AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                               // Implement required abstract method
                                                                                                                               @Override
                                                                                                                               public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                       Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                       ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                       boolean selected, int pass) {
                                                                                                                                   // Empty implementation for testing
                                                                                                                               }
                                                                                                                           };
                                                                                                                           renderer.setPlot(null);
                                                                                                                           LegendItemCollection result = renderer.getLegendItems();
                                                                                                                           assertNotNull(result);
                                                                                                                           assertEquals(0, result.getItemCount());
                                                                                                                       }

    @Test
                                                                                                                       public void testGetLegendItems_WithNullLegendItems_ReturnsOnlyNonNullItems() {
                                                                                                                           // Create the renderer instance
                                                                                                                           AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                               // Implement abstract methods
                                                                                                                               @Override
                                                                                                                               public void drawItem(Graphics2D g2, CategoryItemRendererState state, 
                                                                                                                                       Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis, 
                                                                                                                                       ValueAxis rangeAxis, CategoryDataset dataset, int row, int column, 
                                                                                                                                       boolean selected, int pass) {
                                                                                                                                   // Empty implementation for testing
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Create mock objects
                                                                                                                           CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                           CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                           
                                                                                                                           // Set up mock behavior
                                                                                                                           renderer.setPlot(plot);
                                                                                                                           when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                           when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                           when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                           when(dataset.getRowCount()).thenReturn(3);
                                                                                                                           
                                                                                                                           // Mock legend items (series 2 returns null)
                                                                                                                           LegendItem item1 = new LegendItem("Series 1");
                                                                                                                           LegendItem item3 = new LegendItem("Series 3");
                                                                                                                           
                                                                                                                           // Mock series visibility
                                                                                                                           doReturn(true).when(renderer).isSeriesVisibleInLegend(0);
                                                                                                                           doReturn(true).when(renderer).isSeriesVisibleInLegend(1);
                                                                                                                           doReturn(true).when(renderer).isSeriesVisibleInLegend(2);
                                                                                                                           doReturn(item1).when(renderer).getLegendItem(0, 0);
                                                                                                                           doReturn(null).when(renderer).getLegendItem(0, 1);
                                                                                                                           doReturn(item3).when(renderer).getLegendItem(0, 2);
                                                                                                                           
                                                                                                                           LegendItemCollection result = renderer.getLegendItems();
                                                                                                                           assertNotNull(result);
                                                                                                                           assertEquals(2, result.getItemCount());
                                                                                                                           assertEquals(item1, result.get(0));
                                                                                                                           assertEquals(item3, result.get(1));
                                                                                                                       }

    @Test
                                                                                                                       public void testGetLegendItems_WithEmptyDataset_ReturnsEmptyCollection() {
                                                                                                                           // Create mock objects
                                                                                                                           CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                           CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                           AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                                                           
                                                                                                                           // Set up mock behavior
                                                                                                                           when(renderer.getPlot()).thenReturn(plot);
                                                                                                                           when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                           when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                           when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                           when(dataset.getRowCount()).thenReturn(0);
                                                                                                                           when(renderer.getLegendItems()).thenCallRealMethod();
                                                                                                                           
                                                                                                                           // Execute and verify
                                                                                                                           LegendItemCollection result = renderer.getLegendItems();
                                                                                                                           assertNotNull(result);
                                                                                                                           assertEquals(0, result.getItemCount());
                                                                                                                       }

    @Test
                                                                                                                  public void testGetLegendItemsUsesCorrectDatasetIndex() {
                                                                                                                      // Setup test data
                                                                                                                      AbstractCategoryItemRenderer renderer1 = new AbstractCategoryItemRenderer() {
                                                                                                                          @Override
                                                                                                                          public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                                              return new LegendItem("Series " + series + " from renderer at index " + datasetIndex);
                                                                                                                          }
                                                                                                                          
                                                                                                                          @Override
                                                                                                                          public boolean isSeriesVisibleInLegend(int series) {
                                                                                                                              return true;
                                                                                                                          }
                                                                                                                  
                                                                                                                          @Override
                                                                                                                          public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                  Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                  ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                  boolean selected, int pass) {
                                                                                                                              // Empty implementation for test
                                                                                                                          }
                                                                                                                      };
                                                                                                                      
                                                                                                                      AbstractCategoryItemRenderer renderer2 = new AbstractCategoryItemRenderer() {
                                                                                                                          @Override
                                                                                                                          public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                                              return new LegendItem("Series " + series + " from renderer at index " + datasetIndex);
                                                                                                                          }
                                                                                                                          
                                                                                                                          @Override
                                                                                                                          public boolean isSeriesVisibleInLegend(int series) {
                                                                                                                              return true;
                                                                                                                          }
                                                                                                                  
                                                                                                                          @Override
                                                                                                                          public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                  Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                  ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                  boolean selected, int pass) {
                                                                                                                              // Empty implementation for test
                                                                                                                          }
                                                                                                                      };
                                                                                                                      
                                                                                                                      // Mock plot and dataset
                                                                                                                      CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                      CategoryDataset dataset1 = mock(CategoryDataset.class);
                                                                                                                      CategoryDataset dataset2 = mock(CategoryDataset.class);
                                                                                                                      
                                                                                                                      when(dataset1.getRowCount()).thenReturn(1);
                                                                                                                      when(dataset2.getRowCount()).thenReturn(1);
                                                                                                                      when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                      
                                                                                                                      // Set different indices for each renderer
                                                                                                                      when(plot.getIndexOf(renderer1)).thenReturn(0);
                                                                                                                      when(plot.getIndexOf(renderer2)).thenReturn(1);
                                                                                                                      
                                                                                                                      when(plot.getDataset(0)).thenReturn(dataset1);
                                                                                                                      when(plot.getDataset(1)).thenReturn(dataset2);
                                                                                                                      
                                                                                                                      // Set plot for renderers
                                                                                                                      renderer1.setPlot(plot);
                                                                                                                      renderer2.setPlot(plot);
                                                                                                                      
                                                                                                                      // Test renderer1 (should use dataset1)
                                                                                                                      LegendItemCollection result1 = renderer1.getLegendItems();
                                                                                                                      assertEquals(1, result1.getItemCount());
                                                                                                                      assertEquals("Series 0 from renderer at index 0", result1.get(0).getLabel());
                                                                                                                      
                                                                                                                      // Test renderer2 (should use dataset2)
                                                                                                                      LegendItemCollection result2 = renderer2.getLegendItems();
                                                                                                                      assertEquals(1, result2.getItemCount());
                                                                                                                      assertEquals("Series 0 from renderer at index 1", result2.get(0).getLabel());
                                                                                                                      
                                                                                                                      // Verify interactions
                                                                                                                      verify(plot).getIndexOf(renderer1);
                                                                                                                      verify(plot).getIndexOf(renderer2);
                                                                                                                      verify(plot).getDataset(0);
                                                                                                                      verify(plot).getDataset(1);
                                                                                                                  }

    @Test
                                                                                                             public void testGetLegendItems_DetectsNullIndexMutant() {
                                                                                                                 // Create test objects
                                                                                                                 AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                     // Implement abstract methods needed for test
                                                                                                                     @Override
                                                                                                                     public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                                         return new LegendItem("Test");
                                                                                                                     }
                                                                                                                     
                                                                                                                     @Override
                                                                                                                     public boolean isSeriesVisibleInLegend(int series) {
                                                                                                                         return true;
                                                                                                                     }
                                                                                                                     
                                                                                                                     @Override
                                                                                                                     public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                             Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                             ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                             boolean selected, int pass) {
                                                                                                                         // Empty implementation for test purposes
                                                                                                                     }
                                                                                                                 };
                                                                                                                 
                                                                                                                 // Mock the plot and its behavior
                                                                                                                 CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                 CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                 
                                                                                                                 // Set up expected behavior
                                                                                                                 when(plot.getIndexOf(renderer)).thenReturn(0); // Correct behavior
                                                                                                                 when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                 when(dataset.getRowCount()).thenReturn(1);
                                                                                                                 when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                 
                                                                                                                 // Set the plot on the renderer
                                                                                                                 renderer.setPlot(plot);
                                                                                                                 
                                                                                                                 // Execute the method
                                                                                                                 LegendItemCollection result = renderer.getLegendItems();
                                                                                                                 
                                                                                                                 // Verify the plot.getIndexOf() was called with the renderer instance (this)
                                                                                                                 verify(plot).getIndexOf(renderer);
                                                                                                                 
                                                                                                                 // Additional assertions to ensure proper behavior
                                                                                                                 assertNotNull(result);
                                                                                                                 assertEquals(1, result.getItemCount());
                                                                                                                 
                                                                                                                 // Test would fail if mutant was present because:
                                                                                                                 // 1. getIndexOf(null) would likely return -1
                                                                                                                 // 2. Then getDataset(-1) would return null
                                                                                                                 // 3. Method would return empty collection
                                                                                                                 // So verification of getIndexOf(renderer) would catch the mutant
                                                                                                             }

    @Test
                                                                                                        public void testGetLegendItemsWithValidDatasetShouldReturnNonEmptyCollection() {
                                                                                                            // Setup test objects
                                                                                                            BarRenderer renderer = new BarRenderer() {
                                                                                                                @Override
                                                                                                                public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                                    return new LegendItem("Test");
                                                                                                                }
                                                                                                                
                                                                                                                @Override
                                                                                                                public boolean isSeriesVisibleInLegend(int series) {
                                                                                                                    return true;
                                                                                                                }
                                                                                                            };
                                                                                                            
                                                                                                            // Mock the plot and dataset
                                                                                                            CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                            
                                                                                                            // Configure mocks
                                                                                                            when(plot.getDataset(anyInt())).thenReturn(dataset);
                                                                                                            when(dataset.getRowCount()).thenReturn(1); // One series
                                                                                                            when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                            when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                            
                                                                                                            // Set the plot to renderer
                                                                                                            renderer.setPlot(plot);
                                                                                                            
                                                                                                            // Execute test
                                                                                                            LegendItemCollection result = renderer.getLegendItems();
                                                                                                            
                                                                                                            // Verify results
                                                                                                            assertNotNull("Result should not be null", result);
                                                                                                            assertEquals("Should contain one legend item", 1, result.getItemCount());
                                                                                                            
                                                                                                            // Verify interactions
                                                                                                            verify(plot).getDataset(anyInt());
                                                                                                            verify(dataset).getRowCount();
                                                                                                            verify(plot).getIndexOf(renderer);
                                                                                                        }

    @Test
                                                                                                    public void testGetLegendItemsWithMultipleRenderers() {
                                                                                                        // Create test data
                                                                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                        AbstractCategoryItemRenderer renderer1 = mock(AbstractCategoryItemRenderer.class);
                                                                                                        AbstractCategoryItemRenderer renderer2 = mock(AbstractCategoryItemRenderer.class);
                                                                                                        
                                                                                                        // Mock datasets with different contents
                                                                                                        CategoryDataset dataset1 = mock(CategoryDataset.class);
                                                                                                        when(dataset1.getRowCount()).thenReturn(1);
                                                                                                        CategoryDataset dataset2 = mock(CategoryDataset.class);
                                                                                                        when(dataset2.getRowCount()).thenReturn(1);
                                                                                                        
                                                                                                        // Mock legend items
                                                                                                        LegendItem item1 = new LegendItem("Dataset1");
                                                                                                        LegendItem item2 = new LegendItem("Dataset2");
                                                                                                        
                                                                                                        // Setup renderer1 (index 0)
                                                                                                        when(renderer1.getPlot()).thenReturn(plot);
                                                                                                        when(plot.getIndexOf(renderer1)).thenReturn(0);
                                                                                                        when(plot.getDataset(0)).thenReturn(dataset1);
                                                                                                        when(renderer1.isSeriesVisibleInLegend(0)).thenReturn(true);
                                                                                                        when(renderer1.getLegendItem(0, 0)).thenReturn(item1);
                                                                                                        
                                                                                                        // Setup renderer2 (index 1)
                                                                                                        when(renderer2.getPlot()).thenReturn(plot);
                                                                                                        when(plot.getIndexOf(renderer2)).thenReturn(1);
                                                                                                        when(plot.getDataset(1)).thenReturn(dataset2);
                                                                                                        when(renderer2.isSeriesVisibleInLegend(0)).thenReturn(true);
                                                                                                        when(renderer2.getLegendItem(1, 0)).thenReturn(item2);
                                                                                                        
                                                                                                        // Test renderer1
                                                                                                        LegendItemCollection result1 = renderer1.getLegendItems();
                                                                                                        assertEquals(1, result1.getItemCount());
                                                                                                        assertEquals(item1, result1.get(0));
                                                                                                        
                                                                                                        // Test renderer2 - this would fail with the mutant since it would get dataset1 instead of dataset2
                                                                                                        LegendItemCollection result2 = renderer2.getLegendItems();
                                                                                                        assertEquals(1, result2.getItemCount());
                                                                                                        assertEquals(item2, result2.get(0));  // This assertion would catch the mutant
                                                                                                    }

    @Test
                                                                                                  public void testGetLegendItemsWithNullDataset() {
                                                                                                      // Setup
                                                                                                      AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                                      CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                      when(renderer.getPlot()).thenReturn(plot);
                                                                                                      
                                                                                                      // Configure plot to return index 0 for this renderer
                                                                                                      when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                      // Configure plot to return null dataset
                                                                                                      when(plot.getDataset(0)).thenReturn(null);
                                                                                                      
                                                                                                      // Stub the getLegendItems method to return empty collection when dataset is null
                                                                                                      LegendItemCollection emptyCollection = new LegendItemCollection();
                                                                                                      when(renderer.getLegendItems()).thenCallRealMethod();
                                                                                                      
                                                                                                      // Execute
                                                                                                      LegendItemCollection result = renderer.getLegendItems();
                                                                                                      
                                                                                                      // Verify
                                                                                                      assertNotNull("Result should not be null", result);
                                                                                                      assertEquals("Result should be empty when dataset is null", 
                                                                                                                  0, result.getItemCount());
                                                                                                      
                                                                                                      // Verify plot interactions
                                                                                                      verify(plot).getIndexOf(renderer);
                                                                                                      verify(plot).getDataset(0);
                                                                                                  }

    @Test
                                                                                             public void testGetLegendItemsWithNullDataset1() {
                                                                                                 // Setup
                                                                                                 AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                                 when(renderer.getLegendItem(anyInt(), anyInt())).thenReturn(null);
                                                                                                 when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
                                                                                                 
                                                                                                 CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                 when(renderer.getPlot()).thenReturn(plot);
                                                                                                 
                                                                                                 // Configure plot to return null dataset
                                                                                                 when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                 when(plot.getDataset(0)).thenReturn(null);
                                                                                                 
                                                                                                 // Test
                                                                                                 LegendItemCollection result = renderer.getLegendItems();
                                                                                                 
                                                                                                 // Verify
                                                                                                 assertNotNull("Result should not be null", result);
                                                                                                 assertEquals("Result should be empty when dataset is null", 0, result.getItemCount());
                                                                                                 
                                                                                                 // Verify plot interactions
                                                                                                 verify(plot).getIndexOf(renderer);
                                                                                                 verify(plot).getDataset(0);
                                                                                             }

    @Test
                                                                                        public void testGetLegendItemsWithNullDataset2() {
                                                                                            // Setup test objects
                                                                                            AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                // Override abstract methods needed for test
                                                                                                @Override
                                                                                                public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                    return new LegendItem("Test");
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public boolean isSeriesVisibleInLegend(int series) {
                                                                                                    return true;
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                        Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                        ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                        boolean selected, int pass) {
                                                                                                    // Empty implementation for test
                                                                                                }
                                                                                            };
                                                                                            
                                                                                            // Mock plot that returns null dataset
                                                                                            CategoryPlot mockPlot = mock(CategoryPlot.class);
                                                                                            when(mockPlot.getIndexOf(renderer)).thenReturn(0);
                                                                                            when(mockPlot.getDataset(0)).thenReturn(null);
                                                                                            when(mockPlot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                            
                                                                                            // Set the mock plot
                                                                                            renderer.setPlot(mockPlot);
                                                                                            
                                                                                            // Execute and verify
                                                                                            LegendItemCollection result = renderer.getLegendItems();
                                                                                            assertNotNull("Result should not be null", result);
                                                                                            assertEquals("Result should be empty when dataset is null", 0, result.getItemCount());
                                                                                        }

    @Test
                                                                                   public void testGetLegendItemsReturnsEmptyCollectionWhenPlotIsNull() {
                                                                                       // Setup
                                                                                       AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                           // Create anonymous subclass and implement required abstract method
                                                                                           @Override
                                                                                           public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                   Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                   ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                   boolean selected, int pass) {
                                                                                               // Empty implementation for test purposes
                                                                                           }
                                                                                       };
                                                                                       
                                                                                       // Force plot to be null
                                                                                       renderer.setPlot(null);
                                                                                       
                                                                                       // Execute
                                                                                       LegendItemCollection result = renderer.getLegendItems();
                                                                                       
                                                                                       // Verify
                                                                                       assertNotNull("Should return empty collection instead of null", result);
                                                                                       assertEquals("Collection should be empty", 0, result.getItemCount());
                                                                                   }

    @Test
                                                                                   public void testGetLegendItemsReturnsEmptyCollectionWhenDatasetIsNull() {
                                                                                       // Setup
                                                                                       AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                       when(renderer.getLegendItems()).thenCallRealMethod();
                                                                                       
                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                       renderer.setPlot(plot);
                                                                                       
                                                                                       // Mock behavior - return -1 for index, which will lead to null dataset
                                                                                       when(plot.getIndexOf(renderer)).thenReturn(-1);
                                                                                       
                                                                                       // Execute
                                                                                       LegendItemCollection result = renderer.getLegendItems();
                                                                                       
                                                                                       // Verify
                                                                                       assertNotNull("Should return empty collection instead of null", result);
                                                                                       assertEquals("Collection should be empty", 0, result.getItemCount());
                                                                                   }

    @Test
                                                                              public void testGetLegendItemsReturnsOriginalCollectionWhenPlotIsNull() {
                                                                                  // Setup
                                                                                  AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                      @Override
                                                                                      public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                              Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                              ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                              boolean selected, int pass) {
                                                                                          // Empty implementation for test
                                                                                      }
                                                                                  };
                                                                                  
                                                                                  try {
                                                                                      // Use reflection to set private plot field to null
                                                                                      Field plotField = AbstractCategoryItemRenderer.class.getDeclaredField("plot");
                                                                                      plotField.setAccessible(true);
                                                                                      plotField.set(renderer, null);
                                                                                  } catch (Exception e) {
                                                                                      fail("Failed to set plot field to null via reflection");
                                                                                  }
                                                                                  
                                                                                  // Execute
                                                                                  LegendItemCollection result = renderer.getLegendItems();
                                                                                  
                                                                                  // Verify - should return the same collection object created at start
                                                                                  assertNotNull(result);
                                                                                  assertEquals(0, result.getItemCount());
                                                                                  
                                                                                  // This is the key assertion that would catch the mutant
                                                                                  // The mutant would return a new collection instead of the original one
                                                                                  LegendItemCollection secondCall = renderer.getLegendItems();
                                                                                  assertSame("Should return same collection instance on multiple calls", 
                                                                                          result, secondCall);
                                                                              }

    @Test
                                                                              public void testGetLegendItemsReturnsOriginalCollectionWhenDatasetIsNull() {
                                                                                  // Setup
                                                                                  AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                                  CategoryPlot plot = mock(CategoryPlot.class);
                                                                                  when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                  when(plot.getDataset(0)).thenReturn(null);
                                                                                  when(renderer.getPlot()).thenReturn(plot);
                                                                                  
                                                                                  // Mock the getLegendItems behavior to return new empty collection
                                                                                  LegendItemCollection emptyCollection = new LegendItemCollection();
                                                                                  when(renderer.getLegendItems()).thenCallRealMethod();
                                                                                  
                                                                                  // Execute
                                                                                  LegendItemCollection result = renderer.getLegendItems();
                                                                                  
                                                                                  // Verify
                                                                                  assertNotNull(result);
                                                                                  assertEquals(0, result.getItemCount());
                                                                                  
                                                                                  // Key assertion to catch the mutant
                                                                                  LegendItemCollection secondCall = renderer.getLegendItems();
                                                                                  assertSame("Should return same collection instance on multiple calls", 
                                                                                            result, secondCall);
                                                                              }

    @Test
                                                                         public void testGetLegendItemsWithNonEmptyDatasetShouldReturnItems() {
                                                                             // Setup test data and mocks
                                                                             AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                             CategoryPlot plot = mock(CategoryPlot.class);
                                                                             CategoryDataset dataset = mock(CategoryDataset.class);
                                                                             LegendItem legendItem = mock(LegendItem.class);
                                                                             
                                                                             // Configure mocks
                                                                             when(plot.getDataset(anyInt())).thenReturn(dataset);
                                                                             when(dataset.getRowCount()).thenReturn(2); // Dataset has 2 rows
                                                                             when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                             when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
                                                                             when(renderer.getLegendItem(anyInt(), anyInt())).thenReturn(legendItem);
                                                                             
                                                                             // Set the plot
                                                                             renderer.setPlot(plot);
                                                                             
                                                                             // Execute
                                                                             LegendItemCollection result = renderer.getLegendItems();
                                                                             
                                                                             // Verify
                                                                             assertNotNull("Result should not be null", result);
                                                                             assertEquals("Should return 2 legend items for 2-row dataset", 
                                                                                         2, result.getItemCount());
                                                                             
                                                                             // Additional verification that items were actually added
                                                                             assertSame("First item should match", legendItem, result.get(0));
                                                                             assertSame("Second item should match", legendItem, result.get(1));
                                                                         }

    @Test
                                                                    public void testGetLegendItemsWithDifferentRowAndColumnCounts() {
                                                                        // Setup test objects
                                                                        AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                        when(renderer.getLegendItem(anyInt(), anyInt())).thenAnswer(invocation -> {
                                                                            int series = invocation.getArgument(1);
                                                                            return new LegendItem("Series " + series);
                                                                        });
                                                                        when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
                                                                        
                                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                                        when(renderer.getPlot()).thenReturn(plot);
                                                                        
                                                                        // Create dataset with different row and column counts
                                                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                                                        when(dataset.getRowCount()).thenReturn(3);  // 3 rows
                                                                        when(dataset.getColumnCount()).thenReturn(5); // 5 columns
                                                                        
                                                                        // Configure plot mock
                                                                        when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                        when(plot.getDataset(0)).thenReturn(dataset);
                                                                        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                        
                                                                        // Execute method
                                                                        LegendItemCollection result = renderer.getLegendItems();
                                                                        
                                                                        // Verify results
                                                                        assertEquals(3, result.getItemCount());  // Should be row count (3), not column count (5)
                                                                        
                                                                        // Verify correct series indices were used (0,1,2)
                                                                        assertEquals("Series 0", result.get(0).getLabel());
                                                                        assertEquals("Series 1", result.get(1).getLabel());
                                                                        assertEquals("Series 2", result.get(2).getLabel());
                                                                    }

    @Test
                                                               public void testGetLegendItemsDetectsRowCountMutation() {
                                                                   // Setup test data using mock instead of anonymous class
                                                                   AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                                   when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
                                                                   when(renderer.getLegendItem(anyInt(), anyInt())).thenAnswer(invocation -> 
                                                                       new LegendItem("Series " + invocation.getArgument(1)));
                                                               
                                                                   // Create mock plot and dataset
                                                                   CategoryPlot plot = mock(CategoryPlot.class);
                                                                   CategoryDataset dataset = mock(CategoryDataset.class);
                                                                   
                                                                   // Configure mocks
                                                                   when(plot.getDataset(anyInt())).thenReturn(dataset);
                                                                   when(dataset.getRowCount()).thenReturn(3); // Dataset has 3 rows
                                                                   when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                   when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                   
                                                                   renderer.setPlot(plot);
                                                                   
                                                                   // Execute test
                                                                   LegendItemCollection result = renderer.getLegendItems();
                                                                   
                                                                   // Verify results
                                                                   assertEquals("Should have exactly 3 legend items", 3, result.getItemCount());
                                                                   
                                                                   // Verify each expected legend item exists
                                                                   assertNotNull(result.get(0));
                                                                   assertNotNull(result.get(1));
                                                                   assertNotNull(result.get(2));
                                                                   
                                                                   // The mutant would try to process Integer.MAX_VALUE items and either:
                                                                   // 1. Fail with IndexOutOfBoundsException when trying to access dataset rows
                                                                   // 2. Return wrong number of items (if getLegendItem handles invalid series)
                                                                   // 3. Take extremely long time to process
                                                               }

    @Test
                                                          public void testGetLegendItemsWithCorrectDatasetIndex() {
                                                              // Setup test data
                                                              AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                  @Override
                                                                  public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                      return new LegendItem("Series " + series);
                                                                  }
                                                                  
                                                                  @Override
                                                                  public boolean isSeriesVisibleInLegend(int series) {
                                                                      return true;
                                                                  }
                                                                  
                                                                  @Override
                                                                  public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                          Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                          ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                          boolean selected, int pass) {
                                                                      // Empty implementation for testing purposes
                                                                  }
                                                              };
                                                              
                                                              // Create mock plot with datasets
                                                              CategoryPlot plot = mock(CategoryPlot.class);
                                                              CategoryDataset dataset1 = mock(CategoryDataset.class);
                                                              CategoryDataset dataset2 = mock(CategoryDataset.class);
                                                              
                                                              // Configure mocks
                                                              when(plot.getIndexOf(renderer)).thenReturn(0);
                                                              when(plot.getDataset(0)).thenReturn(dataset1);
                                                              when(plot.getDataset(1)).thenReturn(dataset2); // This would be wrong index
                                                              when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                              when(dataset1.getRowCount()).thenReturn(2);
                                                              
                                                              // Set the plot on the renderer
                                                              renderer.setPlot(plot);
                                                              
                                                              // Execute and verify
                                                              LegendItemCollection result = renderer.getLegendItems();
                                                              
                                                              // Verify correct dataset was accessed (index 0, not 1)
                                                              verify(plot).getDataset(0);
                                                              
                                                              // Verify legend items were created from correct dataset
                                                              assertEquals(2, result.getItemCount());
                                                              assertEquals("Series 0", result.get(0).getLabel());
                                                              assertEquals("Series 1", result.get(1).getLabel());
                                                              
                                                              // This test would fail if the mutant was present because:
                                                              // 1. It would try to access dataset at index 1 (which might be null or wrong)
                                                              // 2. The verify check would fail since it would call getDataset(1)
                                                          }

    @Test
                                                     public void testGetLegendItems_DetectsDatasetIndexMutation() {
                                                         // Setup test data
                                                         AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                             @Override
                                                             public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                 return new LegendItem("Series " + series);
                                                             }
                                                             
                                                             @Override
                                                             public boolean isSeriesVisibleInLegend(int series) {
                                                                 return true;
                                                             }
                                                             
                                                             @Override
                                                             public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                     Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                     ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                     boolean selected, int pass) {
                                                                 // Empty implementation for test
                                                             }
                                                         };
                                                         
                                                         // Create mock plot with multiple datasets
                                                         CategoryPlot plot = mock(CategoryPlot.class);
                                                         CategoryDataset dataset0 = mock(CategoryDataset.class);
                                                         CategoryDataset dataset1 = mock(CategoryDataset.class);
                                                         when(dataset0.getRowCount()).thenReturn(2);
                                                         when(dataset1.getRowCount()).thenReturn(3);
                                                         
                                                         // Set renderer index to 1 (so mutation would try to access index 0)
                                                         when(plot.getIndexOf(renderer)).thenReturn(1);
                                                         when(plot.getDataset(1)).thenReturn(dataset1);
                                                         when(plot.getDataset(0)).thenReturn(dataset0); // This would be accessed by mutant
                                                         when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                         
                                                         renderer.setPlot(plot);
                                                         
                                                         // Execute and verify
                                                         LegendItemCollection result = renderer.getLegendItems();
                                                         
                                                         // Should get 3 items from dataset1 (index 1)
                                                         // Mutant would get 2 items from dataset0 (index 0)
                                                         assertEquals(3, result.getItemCount());
                                                         
                                                         // Verify the items came from the correct dataset
                                                         assertEquals("Series 0", result.get(0).getLabel());
                                                         assertEquals("Series 1", result.get(1).getLabel());
                                                         assertEquals("Series 2", result.get(2).getLabel());
                                                         
                                                         // Additional test for index=0 case
                                                         when(plot.getIndexOf(renderer)).thenReturn(0);
                                                         when(plot.getDataset(0)).thenReturn(dataset0);
                                                         
                                                         result = renderer.getLegendItems();
                                                         assertEquals(2, result.getItemCount());
                                                         // Mutant would throw IndexOutOfBoundsException here
                                                     }

    @Test
                                                public void testGetLegendItems_DescendingOrder_DetectsIndexOutOfBoundsMutant() {
                                                    // Setup test data
                                                    AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                                                    when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true); // All series visible for this test
                                                    when(renderer.getLegendItem(anyInt(), anyInt())).thenAnswer(invocation -> {
                                                        int series = invocation.getArgument(1);
                                                        return new LegendItem("Series " + series);
                                                    });
                                                    
                                                    // Create mock plot with descending order
                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                    when(plot.getRowRenderingOrder()).thenReturn(SortOrder.DESCENDING);
                                                    when(plot.getIndexOf(renderer)).thenReturn(0);
                                                    
                                                    // Create mock dataset with 3 series
                                                    CategoryDataset dataset = mock(CategoryDataset.class);
                                                    when(dataset.getRowCount()).thenReturn(3);
                                                    when(plot.getDataset(0)).thenReturn(dataset);
                                                    
                                                    renderer.setPlot(plot);
                                                    
                                                    // Execute and verify
                                                    LegendItemCollection result = renderer.getLegendItems();
                                                    
                                                    // Verify correct number of items (original behavior)
                                                    assertEquals(3, result.getItemCount());
                                                    
                                                    // Verify items are in reverse order (original behavior)
                                                    assertEquals("Series 2", result.get(0).getLabel());
                                                    assertEquals("Series 1", result.get(1).getLabel());
                                                    assertEquals("Series 0", result.get(2).getLabel());
                                                    
                                                    // The mutated version would throw ArrayIndexOutOfBoundsException
                                                    // before reaching these assertions
                                                }

    @Test
                                           public void testGetLegendItems_DescendingOrderWithSingleSeries_IncludesFirstSeries() {
                                               // Setup test data
                                               AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                   @Override
                                                   public boolean isSeriesVisibleInLegend(int series) {
                                                       return true; // All series visible for this test
                                                   }
                                                   
                                                   @Override
                                                   public LegendItem getLegendItem(int datasetIndex, int series) {
                                                       return new LegendItem("Series " + series); // Return simple legend item
                                                   }
                                                   
                                                   @Override
                                                   public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                           Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                           ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                           boolean selected, int pass) {
                                                       // Empty implementation for test
                                                   }
                                               };
                                               
                                               // Mock required objects
                                               CategoryPlot plot = mock(CategoryPlot.class);
                                               CategoryDataset dataset = mock(CategoryDataset.class);
                                               
                                               // Configure mocks
                                               when(plot.getRowRenderingOrder()).thenReturn(SortOrder.DESCENDING);
                                               when(plot.getIndexOf(renderer)).thenReturn(0);
                                               when(plot.getDataset(0)).thenReturn(dataset);
                                               when(dataset.getRowCount()).thenReturn(1); // Single series
                                               
                                               // Set the plot on renderer
                                               renderer.setPlot(plot);
                                               
                                               // Execute
                                               LegendItemCollection result = renderer.getLegendItems();
                                               
                                               // Verify
                                               assertEquals(1, result.getItemCount()); // Should have one item
                                               assertEquals("Series 0", result.get(0).getLabel()); // Should include series 0
                                           }

    @Test
                                      public void testGetLegendItems_DetectsMutatedVisibilityCheck() {
                                          // Setup test data
                                          AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                              // Override methods needed for test
                                              @Override
                                              public boolean isSeriesVisibleInLegend(int series) {
                                                  // Series 0: visible, Series 1: not visible
                                                  return series == 0;
                                              }
                                              
                                              @Override
                                              public LegendItem getLegendItem(int datasetIndex, int series) {
                                                  return new LegendItem("Series " + series);
                                              }
                                              
                                              @Override
                                              public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                      Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                      ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                      boolean selected, int pass) {
                                                  // Empty implementation for test
                                              }
                                          };
                                          
                                          // Mock plot and dataset
                                          CategoryPlot plot = mock(CategoryPlot.class);
                                          CategoryDataset dataset = mock(CategoryDataset.class);
                                          
                                          // Configure mocks
                                          when(plot.getIndexOf(renderer)).thenReturn(0);
                                          when(plot.getDataset(0)).thenReturn(dataset);
                                          when(dataset.getRowCount()).thenReturn(2); // 2 series
                                          when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                          
                                          // Set the plot
                                          renderer.setPlot(plot);
                                          
                                          // Execute test
                                          LegendItemCollection result = renderer.getLegendItems();
                                          
                                          // Verify results
                                          assertEquals(1, result.getItemCount()); // Should only include visible series (series 0)
                                          assertEquals("Series 0", result.get(0).getLabel());
                                          
                                          // Additional verification to ensure mutant is caught
                                          // If mutant is present, it would return series 1 instead of series 0
                                          boolean containsSeries0 = false;
                                          boolean containsSeries1 = false;
                                          for (int i = 0; i < result.getItemCount(); i++) {
                                              if (result.get(i).getLabel().equals("Series 0")) {
                                                  containsSeries0 = true;
                                              }
                                              if (result.get(i).getLabel().equals("Series 1")) {
                                                  containsSeries1 = true;
                                              }
                                          }
                                          assertTrue(containsSeries0);
                                          assertFalse(containsSeries1);
                                      }

    @Test
                             public void testGetLegendItems_ShouldOnlyIncludeVisibleSeries() {
                                 // Setup test data
                                 AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                     @Override
                                     public boolean isSeriesVisibleInLegend(int series) {
                                         // Series 0: visible, Series 1: not visible
                                         return series == 0;
                                     }
                                     
                                     @Override
                                     public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                             Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                             ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                             boolean selected, int pass) {
                                         // Empty implementation for test
                                     }
                                 };
                                 
                                 // Mock dependencies
                                 CategoryPlot plot = mock(CategoryPlot.class);
                                 CategoryDataset dataset = mock(CategoryDataset.class);
                                 LegendItem visibleItem = mock(LegendItem.class);
                                 LegendItem hiddenItem = mock(LegendItem.class);
                                 
                                 // Configure mocks
                                 when(plot.getIndexOf(renderer)).thenReturn(0);
                                 when(plot.getDataset(0)).thenReturn(dataset);
                                 when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                 when(dataset.getRowCount()).thenReturn(2);
                                 
                                 // Stub getLegendItem to return different items based on series
                                 when(renderer.getLegendItem(0, 0)).thenReturn(visibleItem);
                                 when(renderer.getLegendItem(0, 1)).thenReturn(hiddenItem);
                                 
                                 // Set the plot
                                 renderer.setPlot(plot);
                                 
                                 // Execute
                                 LegendItemCollection result = renderer.getLegendItems();
                                 
                                 // Verify
                                 assertEquals(1, result.getItemCount());  // Should only contain visible item
                                 assertEquals(visibleItem, result.get(0));
                                 
                                 // Check that hiddenItem is not in the collection
                                 boolean containsHiddenItem = false;
                                 for (int i = 0; i < result.getItemCount(); i++) {
                                     if (result.get(i) == hiddenItem) {
                                         containsHiddenItem = true;
                                         break;
                                     }
                                 }
                                 assertFalse(containsHiddenItem);
                             }

    @Test
                        public void testGetLegendItemsDetectsParameterSwapMutant() {
                            // Setup test data with different dataset index and series indices
                            final int datasetIndex = 1;
                            final int seriesCount = 3;
                            
                            // Create mock objects
                            CategoryPlot plot = mock(CategoryPlot.class);
                            CategoryDataset dataset = mock(CategoryDataset.class);
                            AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                            
                            // Configure renderer mock
                            when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
                            when(renderer.getLegendItem(anyInt(), anyInt())).thenAnswer(invocation -> {
                                int dsIndex = invocation.getArgument(0);
                                int series = invocation.getArgument(1);
                                return new LegendItem("Dataset " + dsIndex + ", Series " + series);
                            });
                            
                            // Configure plot mock
                            when(plot.getIndexOf(renderer)).thenReturn(datasetIndex);
                            when(plot.getDataset(datasetIndex)).thenReturn(dataset);
                            when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                            when(dataset.getRowCount()).thenReturn(seriesCount);
                            
                            // Set the plot on the renderer
                            when(renderer.getPlot()).thenReturn(plot);
                            
                            // Execute test
                            LegendItemCollection result = renderer.getLegendItems();
                            
                            // Verify results - should have seriesCount items
                            assertEquals(seriesCount, result.getItemCount());
                            
                            // Verify each legend item was created with correct parameters
                            for (int i = 0; i < seriesCount; i++) {
                                LegendItem item = result.get(i);
                                // This assertion will fail if parameters were swapped in mutation
                                assertEquals("Dataset " + datasetIndex + ", Series " + i, item.getDescription());
                            }
                        }

    @Test
                   public void testGetLegendItems_DetectsNullLegendItemMutation() {
                       // Setup test objects
                       AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                           @Override
                           public LegendItem getLegendItem(int datasetIndex, int series) {
                               return new LegendItem("Series " + series);
                           }
                           
                           @Override
                           public boolean isSeriesVisibleInLegend(int series) {
                               return true; // All series visible for this test
                           }
                           
                           @Override
                           public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                   Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                   ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                   boolean selected, int pass) {
                               // Empty implementation for test purposes
                           }
                       };
                       
                       // Mock required dependencies
                       CategoryPlot plot = mock(CategoryPlot.class);
                       CategoryDataset dataset = mock(CategoryDataset.class);
                       
                       // Configure mocks
                       when(plot.getIndexOf(renderer)).thenReturn(0);
                       when(plot.getDataset(0)).thenReturn(dataset);
                       when(dataset.getRowCount()).thenReturn(3); // 3 series
                       when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                       
                       // Set the plot on the renderer
                       renderer.setPlot(plot);
                       
                       // Execute test
                       LegendItemCollection result = renderer.getLegendItems();
                       
                       // Verify results
                       assertNotNull("Result should not be null", result);
                       assertEquals("Should have 3 legend items", 3, result.getItemCount());
                       
                       // Verify each legend item
                       for (int i = 0; i < 3; i++) {
                           LegendItem item = result.get(i);
                           assertNotNull("Legend item " + i + " should not be null", item);
                           assertEquals("Series " + i, item.getLabel());
                       }
                   }

    @Test
              public void testGetLegendItems_ShouldNotAddNullItems() {
                  // Setup test data and mocks
                  AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
                  CategoryPlot plot = mock(CategoryPlot.class);
                  CategoryDataset dataset = mock(CategoryDataset.class);
                  LegendItem validItem = mock(LegendItem.class);
                  
                  // Configure mocks
                  when(plot.getDataset(anyInt())).thenReturn(dataset);
                  when(dataset.getRowCount()).thenReturn(2);
                  when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                  
                  // Make renderer return one valid and one null item
                  when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
                  when(renderer.getLegendItem(anyInt(), eq(0))).thenReturn(validItem); // valid item for series 0
                  when(renderer.getLegendItem(anyInt(), eq(1))).thenReturn(null); // null item for series 1
                  
                  // Set the plot and execute
                  when(renderer.getPlot()).thenReturn(plot);
                  when(renderer.getLegendItems()).thenCallRealMethod();
                  
                  LegendItemCollection result = renderer.getLegendItems();
                  
                  // Verify results
                  assertEquals(1, result.getItemCount()); // Should only contain the valid item
                  assertSame(validItem, result.get(0)); // The item should be our valid mock
              }

    @Test
         public void testGetLegendItems_ShouldNotAddNullLegendItems() {
             // Setup test data
             AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                 @Override
                 public LegendItem getLegendItem(int datasetIndex, int series) {
                     return null; // Return null to test the null check
                 }
                 
                 @Override
                 public boolean isSeriesVisibleInLegend(int series) {
                     return true; // Make all series visible
                 }
                 
                 @Override
                 public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                         Rectangle2D dataArea, CategoryPlot plot,
                         CategoryAxis domainAxis, ValueAxis rangeAxis,
                         CategoryDataset dataset, int row, int column,
                         boolean selected, int pass) {
                     // Empty implementation for testing
                 }
             };
             
             // Mock required objects
             CategoryPlot plot = mock(CategoryPlot.class);
             CategoryDataset dataset = mock(CategoryDataset.class);
             
             // Configure mocks
             when(plot.getIndexOf(renderer)).thenReturn(0);
             when(plot.getDataset(0)).thenReturn(dataset);
             when(dataset.getRowCount()).thenReturn(3); // 3 series
             when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
             
             // Set the plot
             renderer.setPlot(plot);
             
             // Execute test
             LegendItemCollection result = renderer.getLegendItems();
             
             // Verify results - should be empty since all legend items are null
             assertEquals(0, result.getItemCount());
             
             // Additional verification to ensure the loop ran
             verify(dataset, times(1)).getRowCount();
             verify(plot, times(1)).getRowRenderingOrder();
         }

    @Test
    public void testGetLegendItems_ShouldAddNonNullLegendItems() {
        // Setup test data and mocks
        AbstractCategoryItemRenderer renderer = mock(AbstractCategoryItemRenderer.class);
        
        // Stub methods
        when(renderer.isSeriesVisibleInLegend(anyInt())).thenReturn(true);
        when(renderer.getLegendItem(anyInt(), anyInt())).thenAnswer(invocation -> {
            int series = invocation.getArgument(1);
            return new LegendItem("Series " + series);
        });
        
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        // Configure mocks
        when(plot.getDataset(anyInt())).thenReturn(dataset);
        when(plot.getIndexOf(renderer)).thenReturn(0);
        when(dataset.getRowCount()).thenReturn(3); // 3 series
        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
        
        renderer.setPlot(plot);
        
        // Execute method
        LegendItemCollection result = renderer.getLegendItems();
        
        // Verify results
        assertNotNull("Result collection should not be null", result);
        assertEquals("Should have 3 legend items", 3, result.getItemCount());
        
        // Verify all items are non-null (this will catch the mutant)
        for (int i = 0; i < result.getItemCount(); i++) {
            assertNotNull("Legend item should not be null", result.get(i));
        }
        
        // Additional verification of item contents
        for (int i = 0; i < result.getItemCount(); i++) {
            assertEquals("Series label should match", 
                        "Series " + i, 
                        result.get(i).getLabel());
        }
    }


}
