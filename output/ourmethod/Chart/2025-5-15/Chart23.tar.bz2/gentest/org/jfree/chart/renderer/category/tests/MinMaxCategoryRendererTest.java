package gentest.org.jfree.chart.renderer.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.category.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.Icon;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.data.category.CategoryDataset;
 
public class MinMaxCategoryRendererTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                                                                                                                                                                                                   public void testEquals_Reflexive() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       assertTrue(renderer.equals(renderer));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_NullObject() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       assertFalse(renderer.equals(null));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_DifferentClass() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       Object other = new Object();
                                                                                                                                                                                                       assertFalse(renderer.equals(other));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_SameValues() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Set same values for all relevant fields
                                                                                                                                                                                                       renderer1.setDrawLines(true);
                                                                                                                                                                                                       renderer2.setDrawLines(true);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Paint paint = mock(Paint.class);
                                                                                                                                                                                                       Stroke stroke = mock(Stroke.class);
                                                                                                                                                                                                       renderer1.setGroupPaint(paint);
                                                                                                                                                                                                       renderer2.setGroupPaint(paint);
                                                                                                                                                                                                       renderer1.setGroupStroke(stroke);
                                                                                                                                                                                                       renderer2.setGroupStroke(stroke);
                                                                                                                                                                                                       
                                                                                                                                                                                                       assertTrue(renderer1.equals(renderer2));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_DifferentPlotLines() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       
                                                                                                                                                                                                       renderer1.setDrawLines(true);
                                                                                                                                                                                                       renderer2.setDrawLines(false);
                                                                                                                                                                                                       
                                                                                                                                                                                                       assertFalse(renderer1.equals(renderer2));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_DifferentGroupPaint() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       
                                                                                                                                                                                                       Paint paint1 = mock(Paint.class);
                                                                                                                                                                                                       Paint paint2 = mock(Paint.class);
                                                                                                                                                                                                       renderer1.setGroupPaint(paint1);
                                                                                                                                                                                                       renderer2.setGroupPaint(paint2);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Mock PaintUtilities.equal to return false for different paints
                                                                                                                                                                                                       when(PaintUtilities.equal(paint1, paint2)).thenReturn(false);
                                                                                                                                                                                                       
                                                                                                                                                                                                       assertFalse(renderer1.equals(renderer2));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_DifferentGroupStroke() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       
                                                                                                                                                                                                       Stroke stroke1 = mock(Stroke.class);
                                                                                                                                                                                                       Stroke stroke2 = mock(Stroke.class);
                                                                                                                                                                                                       renderer1.setGroupStroke(stroke1);
                                                                                                                                                                                                       renderer2.setGroupStroke(stroke2);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Mock Stroke.equals to return false for different strokes
                                                                                                                                                                                                       when(stroke1.equals(stroke2)).thenReturn(false);
                                                                                                                                                                                                       
                                                                                                                                                                                                       assertFalse(renderer1.equals(renderer2));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_DifferentSuperClassFields() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Mock super.equals to return false
                                                                                                                                                                                                       // This is a bit tricky since we can't easily mock super.equals
                                                                                                                                                                                                       // So we'll create a situation where super.equals would return false
                                                                                                                                                                                                       // by setting different icons (which are part of super class)
                                                                                                                                                                                                       Icon icon1 = mock(Icon.class);
                                                                                                                                                                                                       Icon icon2 = mock(Icon.class);
                                                                                                                                                                                                       renderer1.setMinIcon(icon1);
                                                                                                                                                                                                       renderer2.setMinIcon(icon2);
                                                                                                                                                                                                       
                                                                                                                                                                                                       assertFalse(renderer1.equals(renderer2));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_TransitiveProperty() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Set same values for all relevant fields
                                                                                                                                                                                                       renderer1.setDrawLines(true);
                                                                                                                                                                                                       renderer2.setDrawLines(true);
                                                                                                                                                                                                       renderer3.setDrawLines(true);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Paint paint = mock(Paint.class);
                                                                                                                                                                                                       Stroke stroke = mock(Stroke.class);
                                                                                                                                                                                                       renderer1.setGroupPaint(paint);
                                                                                                                                                                                                       renderer2.setGroupPaint(paint);
                                                                                                                                                                                                       renderer3.setGroupPaint(paint);
                                                                                                                                                                                                       renderer1.setGroupStroke(stroke);
                                                                                                                                                                                                       renderer2.setGroupStroke(stroke);
                                                                                                                                                                                                       renderer3.setGroupStroke(stroke);
                                                                                                                                                                                                       
                                                                                                                                                                                                       assertTrue(renderer1.equals(renderer2));
                                                                                                                                                                                                       assertTrue(renderer2.equals(renderer3));
                                                                                                                                                                                                       assertTrue(renderer1.equals(renderer3));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                                   public void testEquals_SymmetricProperty() {
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Set same values for all relevant fields
                                                                                                                                                                                                       renderer1.setDrawLines(true);
                                                                                                                                                                                                       renderer2.setDrawLines(true);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Paint paint = mock(Paint.class);
                                                                                                                                                                                                       Stroke stroke = mock(Stroke.class);
                                                                                                                                                                                                       renderer1.setGroupPaint(paint);
                                                                                                                                                                                                       renderer2.setGroupPaint(paint);
                                                                                                                                                                                                       renderer1.setGroupStroke(stroke);
                                                                                                                                                                                                       renderer2.setGroupStroke(stroke);
                                                                                                                                                                                                       
                                                                                                                                                                                                       assertTrue(renderer1.equals(renderer2));
                                                                                                                                                                                                       assertTrue(renderer2.equals(renderer1));
                                                                                                                                                                                                   }

 @Test
                                                                                                                                                                                               public void testEqualsSameInstance() {
                                                                                                                                                                                                   // Create a renderer instance
                                                                                                                                                                                                   MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set some properties to ensure they would fail if compared
                                                                                                                                                                                                   renderer.setDrawLines(true);
                                                                                                                                                                                                   renderer.setGroupPaint(mock(Paint.class));
                                                                                                                                                                                                   renderer.setGroupStroke(mock(Stroke.class));
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Test equals with itself - should return true immediately due to identity check
                                                                                                                                                                                                   long startTime = System.nanoTime();
                                                                                                                                                                                                   boolean result = renderer.equals(renderer);
                                                                                                                                                                                                   long duration = System.nanoTime() - startTime;
                                                                                                                                                                                                   
                                                                                                                                                                                                   assertTrue("Equals should return true for same instance", result);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify it took less than 1ms (identity check is very fast)
                                                                                                                                                                                                   // If mutant is present, this will take longer due to full comparison
                                                                                                                                                                                                   assertTrue("Identity check should be nearly instantaneous", duration < 1000000);
                                                                                                                                                                                               }

 @Test
                                                                                                                                                                                          public void testEqualsWithDifferentGroupPaintShouldReturnFalse() {
                                                                                                                                                                                              // Create two renderers with all fields equal except groupPaint
                                                                                                                                                                                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                              
                                                                                                                                                                                              // Set all fields to be equal
                                                                                                                                                                                              renderer1.setDrawLines(true);
                                                                                                                                                                                              renderer2.setDrawLines(true);
                                                                                                                                                                                              
                                                                                                                                                                                              // Mock the groupStroke to be equal
                                                                                                                                                                                              Stroke mockStroke = mock(Stroke.class);
                                                                                                                                                                                              renderer1.setGroupStroke(mockStroke);
                                                                                                                                                                                              renderer2.setGroupStroke(mockStroke);
                                                                                                                                                                                              
                                                                                                                                                                                              // Set different groupPaint values
                                                                                                                                                                                              Paint paint1 = new Color(255, 0, 0); // Red
                                                                                                                                                                                              Paint paint2 = new Color(0, 0, 255); // Blue
                                                                                                                                                                                              renderer1.setGroupPaint(paint1);
                                                                                                                                                                                              renderer2.setGroupPaint(paint2);
                                                                                                                                                                                              
                                                                                                                                                                                              // The original method should return false because groupPaints are different
                                                                                                                                                                                              // The mutant would return true because it skips the groupPaint check
                                                                                                                                                                                              assertFalse("Objects with different groupPaint should not be equal", 
                                                                                                                                                                                                          renderer1.equals(renderer2));
                                                                                                                                                                                              
                                                                                                                                                                                              // Also test symmetry
                                                                                                                                                                                              assertFalse("Objects with different groupPaint should not be equal", 
                                                                                                                                                                                                          renderer2.equals(renderer1));
                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                         public void testEqualsWithDifferentGroupStroke() {
                                                                                                                                                                                             // Create two renderers with same properties except groupStroke
                                                                                                                                                                                             MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                             MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                             
                                                                                                                                                                                             // Set all other properties to be equal
                                                                                                                                                                                             renderer1.setDrawLines(true);
                                                                                                                                                                                             renderer2.setDrawLines(true);
                                                                                                                                                                                             renderer1.setGroupPaint(Color.RED);
                                                                                                                                                                                             renderer2.setGroupPaint(Color.RED);
                                                                                                                                                                                             
                                                                                                                                                                                             // Create mock Stroke objects with different equals behavior
                                                                                                                                                                                             Stroke stroke1 = mock(Stroke.class);
                                                                                                                                                                                             Stroke stroke2 = mock(Stroke.class);
                                                                                                                                                                                             when(stroke1.equals(stroke2)).thenReturn(false);
                                                                                                                                                                                             
                                                                                                                                                                                             // Set different strokes
                                                                                                                                                                                             renderer1.setGroupStroke(stroke1);
                                                                                                                                                                                             renderer2.setGroupStroke(stroke2);
                                                                                                                                                                                             
                                                                                                                                                                                             // Original code should return false, mutant would return true
                                                                                                                                                                                             assertFalse("Objects with different groupStroke should not be equal", 
                                                                                                                                                                                                        renderer1.equals(renderer2));
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the strokes were actually compared
                                                                                                                                                                                             verify(stroke1).equals(stroke2);
                                                                                                                                                                                         }

 @Test
                                                                                                                                                                                        public void testEqualsWithDifferentSuperclassProperties() {
                                                                                                                                                                                            // Create two renderers with identical properties that this class checks
                                                                                                                                                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                            
                                                                                                                                                                                            // Set all properties that this class's equals() checks to be equal
                                                                                                                                                                                            renderer1.setDrawLines(true);
                                                                                                                                                                                            renderer2.setDrawLines(true);
                                                                                                                                                                                            
                                                                                                                                                                                            // Mock Paint and Stroke objects that will be considered equal by PaintUtilities.equal()
                                                                                                                                                                                            Paint mockPaint = mock(Paint.class);
                                                                                                                                                                                            Stroke mockStroke = mock(Stroke.class);
                                                                                                                                                                                            renderer1.setGroupPaint(mockPaint);
                                                                                                                                                                                            renderer2.setGroupPaint(mockPaint);
                                                                                                                                                                                            renderer1.setGroupStroke(mockStroke);
                                                                                                                                                                                            renderer2.setGroupStroke(mockStroke);
                                                                                                                                                                                            
                                                                                                                                                                                            // The objects should be equal at this level
                                                                                                                                                                                            assertTrue(renderer1.equals(renderer2));
                                                                                                                                                                                            
                                                                                                                                                                                            // Now create a subclass that overrides super.equals() to return false
                                                                                                                                                                                            MinMaxCategoryRenderer differentSuper = new MinMaxCategoryRenderer() {
                                                                                                                                                                                                @Override
                                                                                                                                                                                                public boolean equals(Object obj) {
                                                                                                                                                                                                    return false; // Superclass considers them different
                                                                                                                                                                                                }
                                                                                                                                                                                            };
                                                                                                                                                                                            
                                                                                                                                                                                            // Set the same properties on the subclass instance
                                                                                                                                                                                            differentSuper.setDrawLines(true);
                                                                                                                                                                                            differentSuper.setGroupPaint(mockPaint);
                                                                                                                                                                                            differentSuper.setGroupStroke(mockStroke);
                                                                                                                                                                                            
                                                                                                                                                                                            // Original implementation should return false because super.equals() returns false
                                                                                                                                                                                            // Mutated version would return true
                                                                                                                                                                                            assertFalse("Should return false when super.equals() returns false", 
                                                                                                                                                                                                       renderer1.equals(differentSuper));
                                                                                                                                                                                        }

 @Test
                                                                                                                                                                                      public void testEqualsWithDifferentGroupPaintShouldReturnFalse1() {
                                                                                                                                                                                          // Create two renderer objects with same properties except groupPaint
                                                                                                                                                                                          MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                          MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                          
                                                                                                                                                                                          // Set same values for other fields that affect equality
                                                                                                                                                                                          renderer1.setDrawLines(true);
                                                                                                                                                                                          renderer2.setDrawLines(true);
                                                                                                                                                                                          
                                                                                                                                                                                          Stroke mockStroke = mock(Stroke.class);
                                                                                                                                                                                          renderer1.setGroupStroke(mockStroke);
                                                                                                                                                                                          renderer2.setGroupStroke(mockStroke);
                                                                                                                                                                                          
                                                                                                                                                                                          // Set different group paints
                                                                                                                                                                                          Paint paint1 = mock(Paint.class);
                                                                                                                                                                                          Paint paint2 = mock(Paint.class);
                                                                                                                                                                                          renderer1.setGroupPaint(paint1);
                                                                                                                                                                                          renderer2.setGroupPaint(paint2);
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock PaintUtilities.equal to return false when comparing different paints
                                                                                                                                                                                          when(PaintUtilities.equal(eq(paint1), eq(paint2))).thenReturn(false);
                                                                                                                                                                                          
                                                                                                                                                                                          // The original should return false since groupPaints are different
                                                                                                                                                                                          assertFalse(renderer1.equals(renderer2));
                                                                                                                                                                                      }

 @Test
                                                                                                                                                                                  public void testEqualsWithDifferentGroupStroke1() {
                                                                                                                                                                                      // Create two renderers with identical properties except groupStroke
                                                                                                                                                                                      MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                      MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                      
                                                                                                                                                                                      // Set all properties the same
                                                                                                                                                                                      renderer1.setDrawLines(true);
                                                                                                                                                                                      renderer2.setDrawLines(true);
                                                                                                                                                                                      
                                                                                                                                                                                      Paint testPaint = Color.RED;
                                                                                                                                                                                      renderer1.setGroupPaint(testPaint);
                                                                                                                                                                                      renderer2.setGroupPaint(testPaint);
                                                                                                                                                                                      
                                                                                                                                                                                      // Set different strokes
                                                                                                                                                                                      Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                                                                                      Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                                                                                                      renderer1.setGroupStroke(stroke1);
                                                                                                                                                                                      renderer2.setGroupStroke(stroke2);
                                                                                                                                                                                      
                                                                                                                                                                                      // Test that they are not equal due to different strokes
                                                                                                                                                                                      assertFalse("Renderers with different groupStroke should not be equal", 
                                                                                                                                                                                                 renderer1.equals(renderer2));
                                                                                                                                                                                      
                                                                                                                                                                                      // Also test with same strokes to ensure equals works when they should be equal
                                                                                                                                                                                      renderer2.setGroupStroke(stroke1);
                                                                                                                                                                                      assertTrue("Renderers with same groupStroke should be equal", 
                                                                                                                                                                                                renderer1.equals(renderer2));
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                 public void testEqualsWithDifferentGroupPaint() {
                                                                                                                                                                                     // Create two renderers with all fields equal except groupPaint
                                                                                                                                                                                     MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                     MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                     
                                                                                                                                                                                     // Set all other fields to be equal
                                                                                                                                                                                     renderer1.setDrawLines(true);
                                                                                                                                                                                     renderer2.setDrawLines(true);
                                                                                                                                                                                     renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                                                                     renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                                                                     
                                                                                                                                                                                     // Set different paints that should make them unequal
                                                                                                                                                                                     Paint paint1 = new Color(255, 0, 0); // Red
                                                                                                                                                                                     Paint paint2 = new Color(0, 0, 255); // Blue
                                                                                                                                                                                     
                                                                                                                                                                                     // Test both orders of paint assignment
                                                                                                                                                                                     renderer1.setGroupPaint(paint1);
                                                                                                                                                                                     renderer2.setGroupPaint(paint2);
                                                                                                                                                                                     assertFalse("Renderers with different paints should not be equal", 
                                                                                                                                                                                                renderer1.equals(renderer2));
                                                                                                                                                                                     
                                                                                                                                                                                     renderer1.setGroupPaint(paint2);
                                                                                                                                                                                     renderer2.setGroupPaint(paint1);
                                                                                                                                                                                     assertFalse("Renderers with different paints should not be equal (reverse order)", 
                                                                                                                                                                                                renderer1.equals(renderer2));
                                                                                                                                                                                     
                                                                                                                                                                                     // Also test with equal paints
                                                                                                                                                                                     renderer1.setGroupPaint(paint1);
                                                                                                                                                                                     renderer2.setGroupPaint(paint1);
                                                                                                                                                                                     assertTrue("Renderers with equal paints should be equal", 
                                                                                                                                                                                               renderer1.equals(renderer2));
                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                    public void testEqualsWithNullGroupStroke() {
                                                                                                                                                                                        // Create two renderers with same values except groupStroke
                                                                                                                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                        
                                                                                                                                                                                        // Set same values for other fields
                                                                                                                                                                                        renderer1.setDrawLines(true);
                                                                                                                                                                                        renderer2.setDrawLines(true);
                                                                                                                                                                                        
                                                                                                                                                                                        Paint mockPaint = mock(Paint.class);
                                                                                                                                                                                        renderer1.setGroupPaint(mockPaint);
                                                                                                                                                                                        renderer2.setGroupPaint(mockPaint);
                                                                                                                                                                                        
                                                                                                                                                                                        // Make renderer1 have null groupStroke and renderer2 have non-null
                                                                                                                                                                                        renderer1.setGroupStroke(null);
                                                                                                                                                                                        Stroke mockStroke = mock(Stroke.class);
                                                                                                                                                                                        renderer2.setGroupStroke(mockStroke);
                                                                                                                                                                                        
                                                                                                                                                                                        // When mockStroke.equals(null) is called (in mutated version), return false
                                                                                                                                                                                        when(mockStroke.equals(null)).thenReturn(false);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test equality in both directions
                                                                                                                                                                                        assertFalse("Should not be equal when groupStroke differs", 
                                                                                                                                                                                                   renderer1.equals(renderer2));
                                                                                                                                                                                        assertFalse("Should not be equal when groupStroke differs (reverse)", 
                                                                                                                                                                                                   renderer2.equals(renderer1));
                                                                                                                                                                                        
                                                                                                                                                                                        // The original code would throw NPE when renderer1.equals(renderer2) is called
                                                                                                                                                                                        // The mutated version would work but give wrong result if equals wasn't symmetric
                                                                                                                                                                                    }

 @Test
                                                                                                                                                                               public void testEqualsWithDifferentSuperClassFields() {
                                                                                                                                                                                   // Create two renderers with same field values but different superclass states
                                                                                                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer() {
                                                                                                                                                                                       // Anonymous subclass to make super.equals() return false
                                                                                                                                                                                       @Override
                                                                                                                                                                                       public boolean equals(Object obj) {
                                                                                                                                                                                           return false;
                                                                                                                                                                                       }
                                                                                                                                                                                   };
                                                                                                                                                                                   
                                                                                                                                                                                   // Set same field values
                                                                                                                                                                                   renderer1.setDrawLines(true);
                                                                                                                                                                                   renderer2.setDrawLines(true);
                                                                                                                                                                                   
                                                                                                                                                                                   Paint mockPaint = mock(Paint.class);
                                                                                                                                                                                   renderer1.setGroupPaint(mockPaint);
                                                                                                                                                                                   renderer2.setGroupPaint(mockPaint);
                                                                                                                                                                                   
                                                                                                                                                                                   Stroke mockStroke = mock(Stroke.class);
                                                                                                                                                                                   renderer1.setGroupStroke(mockStroke);
                                                                                                                                                                                   renderer2.setGroupStroke(mockStroke);
                                                                                                                                                                                   
                                                                                                                                                                                   // Original should return false (due to super.equals())
                                                                                                                                                                                   // Mutated version would return true (incorrectly)
                                                                                                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                                                                                                                   
                                                                                                                                                                                   // Additional check for symmetry
                                                                                                                                                                                   assertFalse(renderer2.equals(renderer1));
                                                                                                                                                                               }

 @Test
                                                                                                                                                                                  public void testEqualsIdentityCheck() {
                                                                                                                                                                                      // Create a renderer instance
                                                                                                                                                                                      MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                                      
                                                                                                                                                                                      // Set some properties to ensure we're not testing default values
                                                                                                                                                                                      renderer.setDrawLines(true);
                                                                                                                                                                                      renderer.setGroupPaint(mock(Paint.class));
                                                                                                                                                                                      renderer.setGroupStroke(mock(Stroke.class));
                                                                                                                                                                                      
                                                                                                                                                                                      // Test identity check - should return true when comparing with itself
                                                                                                                                                                                      assertTrue("Object should be equal to itself", renderer.equals(renderer));
                                                                                                                                                                                      
                                                                                                                                                                                      // Test that equals is reflexive
                                                                                                                                                                                      assertTrue("Equals should be reflexive", renderer.equals(renderer));
                                                                                                                                                                                      
                                                                                                                                                                                      // Create another renderer with same properties
                                                                                                                                                                                      MinMaxCategoryRenderer sameRenderer = new MinMaxCategoryRenderer();
                                                                                                                                                                                      sameRenderer.setDrawLines(true);
                                                                                                                                                                                      sameRenderer.setGroupPaint(renderer.getGroupPaint());
                                                                                                                                                                                      sameRenderer.setGroupStroke(renderer.getGroupStroke());
                                                                                                                                                                                      
                                                                                                                                                                                      // Should not be equal (different instances despite same properties)
                                                                                                                                                                                      assertFalse("Different instances should not be equal via identity check", 
                                                                                                                                                                                                 renderer.equals(sameRenderer));
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                 public void testEqualsWithDifferentPlotLines() {
                                                                                                                                                                                     // Create two renderers with different plotLines values
                                                                                                                                                                                     MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                     MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                     
                                                                                                                                                                                     // Set up identical fields except plotLines
                                                                                                                                                                                     Paint testPaint = Color.RED;
                                                                                                                                                                                     Stroke testStroke = new BasicStroke(1.0f);
                                                                                                                                                                                     
                                                                                                                                                                                     renderer1.setDrawLines(true);
                                                                                                                                                                                     renderer1.setGroupPaint(testPaint);
                                                                                                                                                                                     renderer1.setGroupStroke(testStroke);
                                                                                                                                                                                     
                                                                                                                                                                                     renderer2.setDrawLines(false); // Different plotLines
                                                                                                                                                                                     renderer2.setGroupPaint(testPaint);
                                                                                                                                                                                     renderer2.setGroupStroke(testStroke);
                                                                                                                                                                                     
                                                                                                                                                                                     // Test equals in both directions to catch the mutation
                                                                                                                                                                                     assertFalse("Objects with different plotLines should not be equal", 
                                                                                                                                                                                                renderer1.equals(renderer2));
                                                                                                                                                                                     assertFalse("Objects with different plotLines should not be equal (reverse)", 
                                                                                                                                                                                                renderer2.equals(renderer1));
                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                 public void testEqualsWithSamePlotLines() {
                                                                                                                                                                                     // Create two identical renderers
                                                                                                                                                                                     MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                                     MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                                     
                                                                                                                                                                                     Paint testPaint = Color.BLUE;
                                                                                                                                                                                     Stroke testStroke = new BasicStroke(2.0f);
                                                                                                                                                                                     
                                                                                                                                                                                     renderer1.setDrawLines(true);
                                                                                                                                                                                     renderer1.setGroupPaint(testPaint);
                                                                                                                                                                                     renderer1.setGroupStroke(testStroke);
                                                                                                                                                                                     
                                                                                                                                                                                     renderer2.setDrawLines(true); // Same plotLines
                                                                                                                                                                                     renderer2.setGroupPaint(testPaint);
                                                                                                                                                                                     renderer2.setGroupStroke(testStroke);
                                                                                                                                                                                     
                                                                                                                                                                                     // Test equals in both directions
                                                                                                                                                                                     assertTrue("Objects with same fields should be equal", 
                                                                                                                                                                                               renderer1.equals(renderer2));
                                                                                                                                                                                     assertTrue("Objects with same fields should be equal (reverse)", 
                                                                                                                                                                                               renderer2.equals(renderer1));
                                                                                                                                                                                 }

 @Test
                                                                                                                                                                           public void testEqualsWithDifferentSuperClassBehavior() {
                                                                                                                                                                               // Create two renderers with same field values
                                                                                                                                                                               MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                               renderer1.setDrawLines(true);
                                                                                                                                                                               
                                                                                                                                                                               MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                               renderer2.setDrawLines(true);
                                                                                                                                                                               
                                                                                                                                                                               // Create a wrapper object that would make super.equals() behave differently
                                                                                                                                                                               // with the original object vs the cast version
                                                                                                                                                                               Object wrapper = new Object() {
                                                                                                                                                                                   @Override
                                                                                                                                                                                   public boolean equals(Object obj) {
                                                                                                                                                                                       // This implementation would return true for MinMaxCategoryRenderer
                                                                                                                                                                                       // but false for Object (the wrapper itself)
                                                                                                                                                                                       return obj instanceof MinMaxCategoryRenderer;
                                                                                                                                                                                   }
                                                                                                                                                                               };
                                                                                                                                                                               
                                                                                                                                                                               // Create a custom renderer that returns our wrapper when super.equals() is called
                                                                                                                                                                               MinMaxCategoryRenderer rendererWithWrapper = new MinMaxCategoryRenderer() {
                                                                                                                                                                                   @Override
                                                                                                                                                                                   public boolean equals(Object obj) {
                                                                                                                                                                                       if (obj == this) return true;
                                                                                                                                                                                       if (!(obj instanceof MinMaxCategoryRenderer)) return false;
                                                                                                                                                                                       MinMaxCategoryRenderer that = (MinMaxCategoryRenderer) obj;
                                                                                                                                                                                       if (this.isDrawLines() != that.isDrawLines()) return false;
                                                                                                                                                                                       if (!PaintUtilities.equal(this.getGroupPaint(), that.getGroupPaint())) return false;
                                                                                                                                                                                       if (!this.getGroupStroke().equals(that.getGroupStroke())) return false;
                                                                                                                                                                                       return wrapper.equals(obj); // This would be different for obj vs that
                                                                                                                                                                                   }
                                                                                                                                                                               };
                                                                                                                                                                               
                                                                                                                                                                               rendererWithWrapper.setDrawLines(true);
                                                                                                                                                                               
                                                                                                                                                                               // Test with original implementation (should be equal)
                                                                                                                                                                               assertTrue(renderer1.equals(renderer2));
                                                                                                                                                                               
                                                                                                                                                                               // Test with mutated implementation
                                                                                                                                                                               // The wrapper's equals would return:
                                                                                                                                                                               // - false for wrapper.equals(obj) where obj is rendererWithWrapper (original)
                                                                                                                                                                               // - true for wrapper.equals(that) where that is the cast version
                                                                                                                                                                               // So this would fail if the mutant exists
                                                                                                                                                                               assertFalse(rendererWithWrapper.equals(renderer1));
                                                                                                                                                                           }

 @Test
                                                                                                                                                                       public void testEqualsWithNullGroupPaint() {
                                                                                                                                                                           // Create two renderers with same values except one has null groupPaint
                                                                                                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                           renderer1.setGroupPaint(Color.RED);
                                                                                                                                                                           renderer1.setGroupStroke(new BasicStroke());
                                                                                                                                                                           renderer1.setDrawLines(true);
                                                                                                                                                                       
                                                                                                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                           renderer2.setGroupPaint(null);  // This is the key difference
                                                                                                                                                                           renderer2.setGroupStroke(new BasicStroke());
                                                                                                                                                                           renderer2.setDrawLines(true);
                                                                                                                                                                       
                                                                                                                                                                           // Test original behavior - should safely return false
                                                                                                                                                                           boolean result = renderer1.equals(renderer2);
                                                                                                                                                                           assertFalse(result);
                                                                                                                                                                       
                                                                                                                                                                           // Test mutant behavior - would throw NullPointerException
                                                                                                                                                                           // The test will fail if mutant exists (throws exception)
                                                                                                                                                                           // If no exception thrown, we verify the false result
                                                                                                                                                                       }

 @Test
                                                                                                                                                                       public void testEqualsWithAsymmetricPaintComparison() {
                                                                                                                                                                           // Mock two paints that have asymmetric equals() implementation
                                                                                                                                                                           Paint paint1 = mock(Paint.class);
                                                                                                                                                                           Paint paint2 = mock(Paint.class);
                                                                                                                                                                           
                                                                                                                                                                           // Set up asymmetric equals
                                                                                                                                                                           when(paint1.equals(paint2)).thenReturn(false);
                                                                                                                                                                           when(paint2.equals(paint1)).thenReturn(true);  // Different result
                                                                                                                                                                       
                                                                                                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                           renderer1.setGroupPaint(paint1);
                                                                                                                                                                           renderer1.setGroupStroke(new BasicStroke());
                                                                                                                                                                           renderer1.setDrawLines(true);
                                                                                                                                                                       
                                                                                                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                           renderer2.setGroupPaint(paint2);
                                                                                                                                                                           renderer2.setGroupStroke(new BasicStroke());
                                                                                                                                                                           renderer2.setDrawLines(true);
                                                                                                                                                                       
                                                                                                                                                                           // Original behavior (PaintUtilities.equal) would handle this consistently
                                                                                                                                                                           // Mutant behavior would depend on comparison order
                                                                                                                                                                           boolean result1 = renderer1.equals(renderer2);
                                                                                                                                                                           boolean result2 = renderer2.equals(renderer1);
                                                                                                                                                                           
                                                                                                                                                                           // With original code, results should be consistent
                                                                                                                                                                           assertEquals(result1, result2);
                                                                                                                                                                           
                                                                                                                                                                           // With mutant code, results might differ due to asymmetric equals
                                                                                                                                                                           // This would make the assertion fail
                                                                                                                                                                       }

 @Test
                                                                                                                                                                          public void testEqualsWithNullGroupStroke1() {
                                                                                                                                                                              // Create two renderers with different groupStroke null scenarios
                                                                                                                                                                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                              
                                                                                                                                                                              // Set up renderer1 with non-null groupStroke and renderer2 with null
                                                                                                                                                                              Stroke mockStroke = mock(Stroke.class);
                                                                                                                                                                              renderer1.setGroupStroke(mockStroke);
                                                                                                                                                                              renderer2.setGroupStroke(null);
                                                                                                                                                                              
                                                                                                                                                                              // Make all other fields equal
                                                                                                                                                                              renderer1.setDrawLines(true);
                                                                                                                                                                              renderer2.setDrawLines(true);
                                                                                                                                                                              Paint mockPaint = mock(Paint.class);
                                                                                                                                                                              renderer1.setGroupPaint(mockPaint);
                                                                                                                                                                              renderer2.setGroupPaint(mockPaint);
                                                                                                                                                                              
                                                                                                                                                                              // Test both directions
                                                                                                                                                                              assertFalse("Should return false when this.groupStroke is non-null and that.groupStroke is null", 
                                                                                                                                                                                         renderer1.equals(renderer2));
                                                                                                                                                                              assertFalse("Should return false when that.groupStroke is non-null and this.groupStroke is null", 
                                                                                                                                                                                         renderer2.equals(renderer1));
                                                                                                                                                                              
                                                                                                                                                                              // Now test with both having null groupStroke
                                                                                                                                                                              renderer1.setGroupStroke(null);
                                                                                                                                                                              assertTrue("Should return true when both groupStroke are null", 
                                                                                                                                                                                        renderer1.equals(renderer2));
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testEqualsWithNonNullGroupStroke() {
                                                                                                                                                                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                              
                                                                                                                                                                              // Set up equal strokes
                                                                                                                                                                              Stroke stroke1 = mock(Stroke.class);
                                                                                                                                                                              Stroke stroke2 = mock(Stroke.class);
                                                                                                                                                                              when(stroke1.equals(stroke2)).thenReturn(true);
                                                                                                                                                                              
                                                                                                                                                                              renderer1.setGroupStroke(stroke1);
                                                                                                                                                                              renderer2.setGroupStroke(stroke2);
                                                                                                                                                                              renderer1.setDrawLines(true);
                                                                                                                                                                              renderer2.setDrawLines(true);
                                                                                                                                                                              Paint mockPaint = mock(Paint.class);
                                                                                                                                                                              renderer1.setGroupPaint(mockPaint);
                                                                                                                                                                              renderer2.setGroupPaint(mockPaint);
                                                                                                                                                                              
                                                                                                                                                                              assertTrue("Should return true when groupStrokes are equal", 
                                                                                                                                                                                        renderer1.equals(renderer2));
                                                                                                                                                                              
                                                                                                                                                                              // Set up unequal strokes
                                                                                                                                                                              Stroke stroke3 = mock(Stroke.class);
                                                                                                                                                                              when(stroke1.equals(stroke3)).thenReturn(false);
                                                                                                                                                                              renderer2.setGroupStroke(stroke3);
                                                                                                                                                                              
                                                                                                                                                                              assertFalse("Should return false when groupStrokes are not equal", 
                                                                                                                                                                                         renderer1.equals(renderer2));
                                                                                                                                                                          }

 @Test
                                                                                                                                                                         public void testEqualsWithSameObject() {
                                                                                                                                                                             // Create a MinMaxCategoryRenderer instance
                                                                                                                                                                             MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                             
                                                                                                                                                                             // Set some properties to ensure the object isn't empty
                                                                                                                                                                             renderer.setDrawLines(true);
                                                                                                                                                                             
                                                                                                                                                                             // Test equality with itself
                                                                                                                                                                             boolean result = renderer.equals(renderer);
                                                                                                                                                                             
                                                                                                                                                                             // Assert that it should return true for same object reference
                                                                                                                                                                             assertTrue("Equals should return true when comparing object with itself", result);
                                                                                                                                                                             
                                                                                                                                                                             // The mutant would fail this test because it would skip the quick reference check
                                                                                                                                                                             // and proceed with full comparison (though it might still return true)
                                                                                                                                                                         }

 @Test
                                                                                                                                                                        public void testEqualsWithDifferentParentClassFields() {
                                                                                                                                                                            // Create two renderers with identical MinMaxCategoryRenderer fields
                                                                                                                                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                            
                                                                                                                                                                            // Set identical fields
                                                                                                                                                                            renderer1.setDrawLines(true);
                                                                                                                                                                            renderer2.setDrawLines(true);
                                                                                                                                                                            
                                                                                                                                                                            // Mock identical paint and stroke (assuming PaintUtilities.equal() works correctly)
                                                                                                                                                                            Paint mockPaint = mock(Paint.class);
                                                                                                                                                                            Stroke mockStroke = mock(Stroke.class);
                                                                                                                                                                            renderer1.setGroupPaint(mockPaint);
                                                                                                                                                                            renderer2.setGroupPaint(mockPaint);
                                                                                                                                                                            renderer1.setGroupStroke(mockStroke);
                                                                                                                                                                            renderer2.setGroupStroke(mockStroke);
                                                                                                                                                                            
                                                                                                                                                                            // Normally, the objects should be equal only if their parent class fields are equal
                                                                                                                                                                            // The mutation would make them equal regardless of parent class fields
                                                                                                                                                                            // We expect false if parent class fields are different (original behavior)
                                                                                                                                                                            // The mutation would make it return true
                                                                                                                                                                            
                                                                                                                                                                            // The test will pass for original code (assertFalse) and fail for mutated code
                                                                                                                                                                            // This detects the mutant that changes super.equals(obj) to true
                                                                                                                                                                            assertFalse(renderer1.equals(renderer2));
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testEqualsWithSameParentClassFields() {
                                                                                                                                                                            // Create two renderers with identical fields including parent class
                                                                                                                                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                            MinMaxCategoryRenderer renderer2 = renderer1;
                                                                                                                                                                            
                                                                                                                                                                            // This should return true for both original and mutated code
                                                                                                                                                                            assertTrue(renderer1.equals(renderer2));
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testEqualsWithDifferentRendererFields() {
                                                                                                                                                                            // Create two renderers with different fields
                                                                                                                                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                            
                                                                                                                                                                            renderer1.setDrawLines(true);
                                                                                                                                                                            renderer2.setDrawLines(false);
                                                                                                                                                                            
                                                                                                                                                                            // Should return false regardless of mutation
                                                                                                                                                                            assertFalse(renderer1.equals(renderer2));
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testEqualsWithNull() {
                                                                                                                                                                            MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                            assertFalse(renderer.equals(null));
                                                                                                                                                                        }

 @Test
                                                                                                                                                                        public void testEqualsWithDifferentClass() {
                                                                                                                                                                            MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                            assertFalse(renderer.equals(new Object()));
                                                                                                                                                                        }

 @Test
                                                                                                                                                                  public void testEqualsWithDifferentGroupPaintShouldReturnFalse2() {
                                                                                                                                                                      // Create two renderers with different groupPaint values
                                                                                                                                                                      MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                      MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                      
                                                                                                                                                                      // Mock PaintUtilities.equal() to be non-commutative
                                                                                                                                                                      // This ensures the test will fail if parameter order is swapped
                                                                                                                                                                      Paint mockPaint1 = mock(Paint.class);
                                                                                                                                                                      Paint mockPaint2 = mock(Paint.class);
                                                                                                                                                                      
                                                                                                                                                                      // Set up mocks to return different values based on parameter order
                                                                                                                                                                      when(PaintUtilities.equal(mockPaint1, mockPaint2)).thenReturn(false);
                                                                                                                                                                      when(PaintUtilities.equal(mockPaint2, mockPaint1)).thenReturn(true); // Different result
                                                                                                                                                                      
                                                                                                                                                                      // Set the group paints
                                                                                                                                                                      renderer1.setGroupPaint(mockPaint1);
                                                                                                                                                                      renderer2.setGroupPaint(mockPaint2);
                                                                                                                                                                      
                                                                                                                                                                      // Set all other fields to be equal
                                                                                                                                                                      renderer1.setDrawLines(true);
                                                                                                                                                                      renderer2.setDrawLines(true);
                                                                                                                                                                      Stroke sameStroke = new BasicStroke(1.0f);
                                                                                                                                                                      renderer1.setGroupStroke(sameStroke);
                                                                                                                                                                      renderer2.setGroupStroke(sameStroke);
                                                                                                                                                                      
                                                                                                                                                                      // Test equality in both directions
                                                                                                                                                                      assertFalse("Should return false when groupPaint differs (order 1)", 
                                                                                                                                                                                 renderer1.equals(renderer2));
                                                                                                                                                                      assertFalse("Should return false when groupPaint differs (order 2)", 
                                                                                                                                                                                 renderer2.equals(renderer1));
                                                                                                                                                                  }

 @Test
                                                                                                                                                              public void testEqualsWithNullGroupStroke2() {
                                                                                                                                                                  // Create two renderers with same values except groupStroke
                                                                                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                  
                                                                                                                                                                  // Set same values for other fields
                                                                                                                                                                  renderer1.setDrawLines(true);
                                                                                                                                                                  renderer2.setDrawLines(true);
                                                                                                                                                                  renderer1.setGroupPaint(Color.RED);
                                                                                                                                                                  renderer2.setGroupPaint(Color.RED);
                                                                                                                                                                  
                                                                                                                                                                  // Make renderer1's groupStroke null and renderer2's non-null
                                                                                                                                                                  renderer1.setGroupStroke(null);
                                                                                                                                                                  renderer2.setGroupStroke(new BasicStroke());
                                                                                                                                                                  
                                                                                                                                                                  // Test equality in both directions
                                                                                                                                                                  assertFalse("Should return false when groupStroke differs (this null)", 
                                                                                                                                                                      renderer1.equals(renderer2));
                                                                                                                                                                  assertFalse("Should return false when groupStroke differs (that null)", 
                                                                                                                                                                      renderer2.equals(renderer1));
                                                                                                                                                                  
                                                                                                                                                                  // Also test with both null
                                                                                                                                                                  renderer2.setGroupStroke(null);
                                                                                                                                                                  assertTrue("Should return true when both groupStrokes are null",
                                                                                                                                                                      renderer1.equals(renderer2));
                                                                                                                                                              }

 @Test
                                                                                                                                                                 public void testEqualsWithSameObject1() {
                                                                                                                                                                     // Create a MinMaxCategoryRenderer instance
                                                                                                                                                                     MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                                                     
                                                                                                                                                                     // Set some properties to ensure we're not just testing default values
                                                                                                                                                                     renderer.setDrawLines(true);
                                                                                                                                                                     
                                                                                                                                                                     // Test that the object equals itself
                                                                                                                                                                     assertTrue("Object should be equal to itself", renderer.equals(renderer));
                                                                                                                                                                     
                                                                                                                                                                     // Test that equals is reflexive
                                                                                                                                                                     assertTrue("Equals should be reflexive", renderer.equals(renderer));
                                                                                                                                                                     
                                                                                                                                                                     // Test with the object as both arguments in different orders
                                                                                                                                                                     Object obj = renderer;
                                                                                                                                                                     assertTrue("Equals should work regardless of comparison order", 
                                                                                                                                                                                renderer.equals(obj) && obj.equals(renderer));
                                                                                                                                                                 }

 @Test
                                                                                                                                                            public void testEqualsWithDifferentPlotLinesShouldBeFalse() {
                                                                                                                                                                // Create two renderers with different plotLines values
                                                                                                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                                renderer1.setDrawLines(true);  // plotLines = true
                                                                                                                                                                
                                                                                                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                                renderer2.setDrawLines(false); // plotLines = false
                                                                                                                                                                
                                                                                                                                                                // Test equality in both directions
                                                                                                                                                                assertFalse("Renderer with true plotLines should not equal false", 
                                                                                                                                                                           renderer1.equals(renderer2));
                                                                                                                                                                assertFalse("Renderer with false plotLines should not equal true", 
                                                                                                                                                                           renderer2.equals(renderer1));
                                                                                                                                                                
                                                                                                                                                                // Now set both to same value and verify equality
                                                                                                                                                                renderer2.setDrawLines(true);
                                                                                                                                                                assertTrue("Renderers with same plotLines should be equal", 
                                                                                                                                                                          renderer1.equals(renderer2));
                                                                                                                                                                assertTrue("Equality should be symmetric", 
                                                                                                                                                                          renderer2.equals(renderer1));
                                                                                                                                                            }

 @Test
                                                                                                                                                           public void testEqualsWithSubclassShouldDetectMutant() {
                                                                                                                                                               // Create a subclass that overrides equals differently
                                                                                                                                                               class SubRenderer extends MinMaxCategoryRenderer {
                                                                                                                                                                   @Override
                                                                                                                                                                   public boolean equals(Object obj) {
                                                                                                                                                                       // Different implementation than parent
                                                                                                                                                                       return false;
                                                                                                                                                                   }
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               // Create test objects
                                                                                                                                                               MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                               SubRenderer renderer2 = new SubRenderer();
                                                                                                                                                               
                                                                                                                                                               // Configure them to be equal in parent class fields
                                                                                                                                                               renderer1.setDrawLines(true);
                                                                                                                                                               renderer2.setDrawLines(true);
                                                                                                                                                               renderer1.setGroupPaint(Color.RED);
                                                                                                                                                               renderer2.setGroupPaint(Color.RED);
                                                                                                                                                               renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                                               renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                                               
                                                                                                                                                               // Original behavior: should return false because super.equals(obj) 
                                                                                                                                                               // would call SubRenderer's equals which returns false
                                                                                                                                                               // Mutated behavior: would return true because super.equals(that) 
                                                                                                                                                               // would bypass SubRenderer's equals and use parent's equals
                                                                                                                                                               assertFalse("Should return false for subclass comparison", 
                                                                                                                                                                           renderer1.equals(renderer2));
                                                                                                                                                           }

 @Test
                                                                                                                                                          public void testEqualsWithNullGroupPaint1() {
                                                                                                                                                              // Create two renderers with different groupPaint values
                                                                                                                                                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                              
                                                                                                                                                              // Set up renderer1 with non-null groupPaint and renderer2 with null groupPaint
                                                                                                                                                              renderer1.setGroupPaint(new Color(255, 0, 0)); // Any non-null Paint
                                                                                                                                                              renderer2.setGroupPaint(null);
                                                                                                                                                              
                                                                                                                                                              // Make all other fields equal
                                                                                                                                                              renderer1.setDrawLines(true);
                                                                                                                                                              renderer2.setDrawLines(true);
                                                                                                                                                              renderer1.setGroupStroke(new BasicStroke());
                                                                                                                                                              renderer2.setGroupStroke(new BasicStroke());
                                                                                                                                                              
                                                                                                                                                              // Test equality in both directions
                                                                                                                                                              assertFalse("Renderers with different groupPaint should not be equal", 
                                                                                                                                                                         renderer1.equals(renderer2));
                                                                                                                                                              assertFalse("Renderers with different groupPaint should not be equal", 
                                                                                                                                                                         renderer2.equals(renderer1));
                                                                                                                                                              
                                                                                                                                                              // The mutant would throw NullPointerException when comparing renderer2.equals(renderer1)
                                                                                                                                                              // because it tries to call equals() on renderer2's null groupPaint
                                                                                                                                                          }

 @Test
                                                                                                                                                         public void testEqualsWithDifferentGroupStrokeNullScenarios() {
                                                                                                                                                             // Create two renderers with all fields equal except groupStroke
                                                                                                                                                             MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                             MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                             
                                                                                                                                                             // Set all other fields to be equal
                                                                                                                                                             renderer1.setDrawLines(true);
                                                                                                                                                             renderer2.setDrawLines(true);
                                                                                                                                                             renderer1.setGroupPaint(Color.RED);
                                                                                                                                                             renderer2.setGroupPaint(Color.RED);
                                                                                                                                                             
                                                                                                                                                             // Scenario 1: this.groupStroke is null, that.groupStroke is not null
                                                                                                                                                             renderer1.setGroupStroke(null);
                                                                                                                                                             renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                                             assertFalse("Should return false when this.groupStroke is null and that.groupStroke is not", 
                                                                                                                                                                 renderer1.equals(renderer2));
                                                                                                                                                             
                                                                                                                                                             // Scenario 2: that.groupStroke is null, this.groupStroke is not null
                                                                                                                                                             renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                                             renderer2.setGroupStroke(null);
                                                                                                                                                             assertFalse("Should return false when that.groupStroke is null and this.groupStroke is not", 
                                                                                                                                                                 renderer1.equals(renderer2));
                                                                                                                                                             
                                                                                                                                                             // Scenario 3: both groupStrokes are null
                                                                                                                                                             renderer1.setGroupStroke(null);
                                                                                                                                                             renderer2.setGroupStroke(null);
                                                                                                                                                             assertTrue("Should return true when both groupStrokes are null", 
                                                                                                                                                                 renderer1.equals(renderer2));
                                                                                                                                                             
                                                                                                                                                             // Scenario 4: both groupStrokes are equal and not null
                                                                                                                                                             Stroke stroke = new BasicStroke(1.0f);
                                                                                                                                                             renderer1.setGroupStroke(stroke);
                                                                                                                                                             renderer2.setGroupStroke(stroke);
                                                                                                                                                             assertTrue("Should return true when both groupStrokes are equal", 
                                                                                                                                                                 renderer1.equals(renderer2));
                                                                                                                                                         }

 @Test
                                                                                                                                                       public void testLastCategoryUpdatedCorrectly() throws NoSuchFieldException, IllegalAccessException {
                                                                                                                                                           // Setup
                                                                                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                           
                                                                                                                                                           // Mock necessary objects for drawItem
                                                                                                                                                           Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                           CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                           Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                           CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                           CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                           ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                           CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                                           
                                                                                                                                                           // Original behavior should set different lastCategory values
                                                                                                                                                           renderer1.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
                                                                                                                                                           renderer2.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 2, 0);
                                                                                                                                                           
                                                                                                                                                           // Get lastCategory fields using reflection
                                                                                                                                                           Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
                                                                                                                                                           lastCategoryField.setAccessible(true);
                                                                                                                                                           int lastCategory1 = (int) lastCategoryField.get(renderer1);
                                                                                                                                                           int lastCategory2 = (int) lastCategoryField.get(renderer2);
                                                                                                                                                           
                                                                                                                                                           // Verify lastCategory was updated differently
                                                                                                                                                           assertNotEquals("lastCategory should be different after drawing different columns", 
                                                                                                                                                                          lastCategory1, lastCategory2);
                                                                                                                                                           
                                                                                                                                                           // For mutant detection: the above assertion would fail with the mutant
                                                                                                                                                           // since both would keep their initial lastCategory values (likely 0)
                                                                                                                                                       }

 @Test
                                                                                                                                                   public void testEqualsWithDifferentMinMaxValues() {
                                                                                                                                                       // Create first renderer with default values
                                                                                                                                                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                       renderer1.setDrawLines(true);
                                                                                                                                                       
                                                                                                                                                       // Create second renderer with same properties but different min/max
                                                                                                                                                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                       renderer2.setDrawLines(true);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set min/max values since they're private
                                                                                                                                                       try {
                                                                                                                                                           Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                                                                                                                                           Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                                                                                                                           minField.setAccessible(true);
                                                                                                                                                           maxField.setAccessible(true);
                                                                                                                                                           
                                                                                                                                                           // Set different min/max values
                                                                                                                                                           minField.setDouble(renderer1, 1.0);
                                                                                                                                                           maxField.setDouble(renderer1, 10.0);
                                                                                                                                                           minField.setDouble(renderer2, 2.0);
                                                                                                                                                           maxField.setDouble(renderer2, 20.0);
                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                           fail("Failed to set min/max fields via reflection");
                                                                                                                                                       }
                                                                                                                                                       
                                                                                                                                                       // These should NOT be equal since min/max are different
                                                                                                                                                       assertFalse(renderer1.equals(renderer2));
                                                                                                                                                       assertFalse(renderer2.equals(renderer1));
                                                                                                                                                       
                                                                                                                                                       // Check symmetry
                                                                                                                                                       assertEquals(renderer1.equals(renderer2), renderer2.equals(renderer1));
                                                                                                                                                       
                                                                                                                                                       // Check reflexivity
                                                                                                                                                       assertTrue(renderer1.equals(renderer1));
                                                                                                                                                       assertTrue(renderer2.equals(renderer2));
                                                                                                                                                       
                                                                                                                                                       // Check null case
                                                                                                                                                       assertFalse(renderer1.equals(null));
                                                                                                                                                   }

 @Test
                                                                                                                                                      public void testEqualsWithNonIntegerMinValue() {
                                                                                                                                                          // Create two identical renderers with non-integer min value
                                                                                                                                                          MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                          MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                          
                                                                                                                                                          // Set same properties
                                                                                                                                                          renderer1.setDrawLines(true);
                                                                                                                                                          renderer2.setDrawLines(true);
                                                                                                                                                          renderer1.setGroupPaint(Color.RED);
                                                                                                                                                          renderer2.setGroupPaint(Color.RED);
                                                                                                                                                          renderer1.setGroupStroke(new BasicStroke(1.5f));
                                                                                                                                                          renderer2.setGroupStroke(new BasicStroke(1.5f));
                                                                                                                                                          
                                                                                                                                                          // Set non-integer min values (3.14)
                                                                                                                                                          // Original code would store 3.14 in both
                                                                                                                                                          // Mutant would store 3 in both due to intValue()
                                                                                                                                                          // So we need to modify equals() to check min field
                                                                                                                                                          try {
                                                                                                                                                              java.lang.reflect.Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                                                                                                                                              minField.setAccessible(true);
                                                                                                                                                              minField.set(renderer1, 3.14);
                                                                                                                                                              minField.set(renderer2, 3.14);
                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                              fail("Failed to set min field via reflection");
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          // Test equality - should be equal
                                                                                                                                                          assertTrue(renderer1.equals(renderer2));
                                                                                                                                                          
                                                                                                                                                          // Now test with slightly different min values
                                                                                                                                                          try {
                                                                                                                                                              java.lang.reflect.Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                                                                                                                                              minField.setAccessible(true);
                                                                                                                                                              minField.set(renderer2, 3.15); // slightly different
                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                              fail("Failed to set min field via reflection");
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          // Should not be equal now
                                                                                                                                                          assertFalse(renderer1.equals(renderer2));
                                                                                                                                                      }

 @Test
                                                                                                                                                public void testEqualsWithMaxValuePrecision() throws Exception {
                                                                                                                                                    // Create two renderers with same properties
                                                                                                                                                    MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                                    MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                                    
                                                                                                                                                    // Set same properties
                                                                                                                                                    renderer1.setDrawLines(true);
                                                                                                                                                    renderer2.setDrawLines(true);
                                                                                                                                                    renderer1.setGroupPaint(Color.RED);
                                                                                                                                                    renderer2.setGroupPaint(Color.RED);
                                                                                                                                                    renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                                    renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                                    
                                                                                                                                                    // Get the private max field using reflection
                                                                                                                                                    Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                                                                                                                    maxField.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Set max values that would differ in float vs double precision
                                                                                                                                                    // Using a value that can't be precisely represented in float
                                                                                                                                                    double preciseValue = 0.1 + 0.2; // 0.30000000000000004 in double
                                                                                                                                                    maxField.set(renderer1, preciseValue); // original would store as double
                                                                                                                                                    maxField.set(renderer2, (float)preciseValue); // mutant would store as float
                                                                                                                                                    
                                                                                                                                                    // Verify equals detects the difference
                                                                                                                                                    assertFalse("Should detect max value precision difference", 
                                                                                                                                                               renderer1.equals(renderer2));
                                                                                                                                                    
                                                                                                                                                    // Also test with exactly same values
                                                                                                                                                    maxField.set(renderer2, preciseValue);
                                                                                                                                                    assertTrue("Should return true for exactly equal objects",
                                                                                                                                                               renderer1.equals(renderer2));
                                                                                                                                                }

 @Test
                                                                                                                                           public void testEqualsWithDecimalMaxValue() throws Exception {
                                                                                                                                               // Create two renderers with same properties but different max values
                                                                                                                                               MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                               MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                               
                                                                                                                                               // Set same properties for both
                                                                                                                                               renderer1.setDrawLines(true);
                                                                                                                                               renderer2.setDrawLines(true);
                                                                                                                                               
                                                                                                                                               // Mock same paint and stroke
                                                                                                                                               Paint mockPaint = mock(Paint.class);
                                                                                                                                               Stroke mockStroke = mock(Stroke.class);
                                                                                                                                               renderer1.setGroupPaint(mockPaint);
                                                                                                                                               renderer1.setGroupStroke(mockStroke);
                                                                                                                                               renderer2.setGroupPaint(mockPaint);
                                                                                                                                               renderer2.setGroupStroke(mockStroke);
                                                                                                                                               
                                                                                                                                               // Use reflection to set private max field
                                                                                                                                               Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                                                                                                               maxField.setAccessible(true);
                                                                                                                                               
                                                                                                                                               // Set max values - one with decimal, one with int
                                                                                                                                               maxField.setDouble(renderer1, 10.5);
                                                                                                                                               maxField.setDouble(renderer2, 10.0);
                                                                                                                                               
                                                                                                                                               // They should NOT be equal due to different max values
                                                                                                                                               assertFalse(renderer1.equals(renderer2));
                                                                                                                                               
                                                                                                                                               // Test with very large decimal number
                                                                                                                                               maxField.setDouble(renderer1, Double.MAX_VALUE);
                                                                                                                                               maxField.setDouble(renderer2, (double)Integer.MAX_VALUE);
                                                                                                                                               assertFalse(renderer1.equals(renderer2));
                                                                                                                                               
                                                                                                                                               // Test case where decimal is just below .5
                                                                                                                                               maxField.setDouble(renderer1, 10.499999999999999);
                                                                                                                                               maxField.setDouble(renderer2, 10.0);
                                                                                                                                               assertFalse(renderer1.equals(renderer2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEqualsWithDifferentPlotLinesShouldReturnFalse() {
                                                                                                                                               // Create two renderers with different plotLines values
                                                                                                                                               MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                               MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                               
                                                                                                                                               // Mock necessary objects to ensure other equality checks pass
                                                                                                                                               Paint mockPaint = mock(Paint.class);
                                                                                                                                               Stroke mockStroke = mock(Stroke.class);
                                                                                                                                               
                                                                                                                                               // Set up renderer1 with plotLines=true
                                                                                                                                               renderer1.setDrawLines(true);
                                                                                                                                               renderer1.setGroupPaint(mockPaint);
                                                                                                                                               renderer1.setGroupStroke(mockStroke);
                                                                                                                                               
                                                                                                                                               // Set up renderer2 with plotLines=false (different from renderer1)
                                                                                                                                               renderer2.setDrawLines(false);
                                                                                                                                               renderer2.setGroupPaint(mockPaint);
                                                                                                                                               renderer2.setGroupStroke(mockStroke);
                                                                                                                                               
                                                                                                                                               // Configure mocks to return true for equality checks
                                                                                                                                               when(mockStroke.equals(mockStroke)).thenReturn(true);
                                                                                                                                               
                                                                                                                                               // The objects should not be equal because plotLines differ
                                                                                                                                               assertFalse(renderer1.equals(renderer2));
                                                                                                                                               
                                                                                                                                               // Test the reverse case (false vs true)
                                                                                                                                               MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                                                                               renderer3.setDrawLines(false);
                                                                                                                                               renderer3.setGroupPaint(mockPaint);
                                                                                                                                               renderer3.setGroupStroke(mockStroke);
                                                                                                                                               
                                                                                                                                               MinMaxCategoryRenderer renderer4 = new MinMaxCategoryRenderer();
                                                                                                                                               renderer4.setDrawLines(true);
                                                                                                                                               renderer4.setGroupPaint(mockPaint);
                                                                                                                                               renderer4.setGroupStroke(mockStroke);
                                                                                                                                               
                                                                                                                                               assertFalse(renderer3.equals(renderer4));
                                                                                                                                           }

 @Test
                                                                                                                                      public void testEquals_ShouldReturnFalseWhenPlotLinesDiffer() {
                                                                                                                                          // Create two renderers with different plotLines values
                                                                                                                                          MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                          renderer1.setDrawLines(true);  // plotLines = true
                                                                                                                                          
                                                                                                                                          MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                          renderer2.setDrawLines(false); // plotLines = false
                                                                                                                                          
                                                                                                                                          // Set all other fields to be equal
                                                                                                                                          Paint mockPaint = mock(Paint.class);
                                                                                                                                          Stroke mockStroke = mock(Stroke.class);
                                                                                                                                          
                                                                                                                                          renderer1.setGroupPaint(mockPaint);
                                                                                                                                          renderer1.setGroupStroke(mockStroke);
                                                                                                                                          
                                                                                                                                          renderer2.setGroupPaint(mockPaint);
                                                                                                                                          renderer2.setGroupStroke(mockStroke);
                                                                                                                                          
                                                                                                                                          // Test: with original code, should return false
                                                                                                                                          // With mutated code (if(true)), would return true
                                                                                                                                          assertFalse("Objects with different plotLines should not be equal", 
                                                                                                                                                     renderer1.equals(renderer2));
                                                                                                                                          
                                                                                                                                          // Also test the reverse comparison
                                                                                                                                          assertFalse("Objects with different plotLines should not be equal", 
                                                                                                                                                     renderer2.equals(renderer1));
                                                                                                                                      }

 @Test
                                                                                                                                         public void testEquals_SameInstance() {
                                                                                                                                             MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                             assertTrue(renderer.equals(renderer));
                                                                                                                                         }

 @Test
                                                                                                                                         public void testEquals_Null() {
                                                                                                                                             MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                             assertFalse(renderer.equals(null));
                                                                                                                                         }

 @Test
                                                                                                                                         public void testEquals_DifferentClass1() {
                                                                                                                                             MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                             assertFalse(renderer.equals("Not a renderer"));
                                                                                                                                         }

 @Test
                                                                                                                                         public void testEquals_EqualObjects() {
                                                                                                                                             MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                                             MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                                             assertTrue(r1.equals(r2));
                                                                                                                                         }

 @Test
                                                                                                                                         public void testEquals_DifferentPlotLines1() {
                                                                                                                                             MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                                             MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                                             r1.setDrawLines(true);
                                                                                                                                             r2.setDrawLines(false);
                                                                                                                                             assertFalse(r1.equals(r2));
                                                                                                                                         }

 @Test
                                                                                                                                         public void testEquals_DifferentGroupPaint1() {
                                                                                                                                             MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                                             MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                                             r1.setGroupPaint(Color.RED);
                                                                                                                                             r2.setGroupPaint(Color.BLUE);
                                                                                                                                             assertFalse(r1.equals(r2));
                                                                                                                                         }

 @Test
                                                                                                                                         public void testEquals_DifferentGroupStroke1() {
                                                                                                                                             MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                                             MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                                             r1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                             r2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                                             assertFalse(r1.equals(r2));
                                                                                                                                         }

 @Test
                                                                                                                                         public void testEquals_WithSuperClassDifferences() {
                                                                                                                                             // This would require mocking or creating a subclass that overrides equals
                                                                                                                                             // Since we don't know the superclass behavior, we can't reliably test this
                                                                                                                                             // In practice, we'd need to know what super.equals() checks
                                                                                                                                         }

 @Test
                                                                                                                                        public void testEquals() {
                                                                                                                                            // Create two identical renderers
                                                                                                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                            renderer1.setDrawLines(true);
                                                                                                                                            renderer1.setGroupPaint(Color.RED);
                                                                                                                                            renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                            
                                                                                                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                            renderer2.setDrawLines(true);
                                                                                                                                            renderer2.setGroupPaint(Color.RED);
                                                                                                                                            renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                            
                                                                                                                                            // Test equality with itself
                                                                                                                                            assertTrue(renderer1.equals(renderer1));
                                                                                                                                            
                                                                                                                                            // Test equality with identical renderer
                                                                                                                                            assertTrue(renderer1.equals(renderer2));
                                                                                                                                            assertTrue(renderer2.equals(renderer1));
                                                                                                                                            
                                                                                                                                            // Test inequality with different plotLines
                                                                                                                                            MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                                                                            renderer3.setDrawLines(false);
                                                                                                                                            renderer3.setGroupPaint(Color.RED);
                                                                                                                                            renderer3.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                            assertFalse(renderer1.equals(renderer3));
                                                                                                                                            
                                                                                                                                            // Test inequality with different groupPaint
                                                                                                                                            MinMaxCategoryRenderer renderer4 = new MinMaxCategoryRenderer();
                                                                                                                                            renderer4.setDrawLines(true);
                                                                                                                                            renderer4.setGroupPaint(Color.BLUE);
                                                                                                                                            renderer4.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                            assertFalse(renderer1.equals(renderer4));
                                                                                                                                            
                                                                                                                                            // Test inequality with different groupStroke
                                                                                                                                            MinMaxCategoryRenderer renderer5 = new MinMaxCategoryRenderer();
                                                                                                                                            renderer5.setDrawLines(true);
                                                                                                                                            renderer5.setGroupPaint(Color.RED);
                                                                                                                                            renderer5.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                                            assertFalse(renderer1.equals(renderer5));
                                                                                                                                            
                                                                                                                                            // Test with null
                                                                                                                                            assertFalse(renderer1.equals(null));
                                                                                                                                            
                                                                                                                                            // Test with different type
                                                                                                                                            assertFalse(renderer1.equals("Not a renderer"));
                                                                                                                                        }

 @Test
                                                                                                                                   public void testDrawItemAccessesPreviousColumnValue() {
                                                                                                                                       // Setup
                                                                                                                                       MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                       CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                       
                                                                                                                                       // Mock dataset to return different values for adjacent columns
                                                                                                                                       when(dataset.getValue(0, 0)).thenReturn(10); // first column
                                                                                                                                       when(dataset.getValue(0, 1)).thenReturn(20); // second column
                                                                                                                                       
                                                                                                                                       // We need to verify that when drawing column 1, it accesses column 0's value
                                                                                                                                       renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
                                                                                                                                       
                                                                                                                                       // Verify the renderer accessed the previous column's value (column 0)
                                                                                                                                       verify(dataset).getValue(0, 0);
                                                                                                                                       
                                                                                                                                       // Also verify it didn't just access the current column again
                                                                                                                                       verify(dataset, never()).getValue(0, 1);
                                                                                                                                       
                                                                                                                                       // Additional verification that the rendering occurred
                                                                                                                                       verify(g2).setPaint(any(Paint.class));
                                                                                                                                       verify(g2).setStroke(any(Stroke.class));
                                                                                                                                   }

 @Test
                                                                                                                                      public void testEquals1() {
                                                                                                                                          // Create two renderers with same values
                                                                                                                                          MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                                          MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                                          
                                                                                                                                          // Test reference equality
                                                                                                                                          assertTrue(r1.equals(r1));
                                                                                                                                          
                                                                                                                                          // Test with null
                                                                                                                                          assertFalse(r1.equals(null));
                                                                                                                                          
                                                                                                                                          // Test with different class
                                                                                                                                          assertFalse(r1.equals(new Object()));
                                                                                                                                          
                                                                                                                                          // Test with equal objects
                                                                                                                                          assertTrue(r1.equals(r2));
                                                                                                                                          
                                                                                                                                          // Test plotLines difference
                                                                                                                                          r1.setDrawLines(true);
                                                                                                                                          assertFalse(r1.equals(r2));
                                                                                                                                          r2.setDrawLines(true);
                                                                                                                                          assertTrue(r1.equals(r2));
                                                                                                                                          
                                                                                                                                          // Test groupPaint difference
                                                                                                                                          r1.setGroupPaint(Color.RED);
                                                                                                                                          assertFalse(r1.equals(r2));
                                                                                                                                          r2.setGroupPaint(Color.RED);
                                                                                                                                          assertTrue(r1.equals(r2));
                                                                                                                                          
                                                                                                                                          // Test groupStroke difference
                                                                                                                                          Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                                          Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                                                          r1.setGroupStroke(stroke1);
                                                                                                                                          assertFalse(r1.equals(r2));
                                                                                                                                          r2.setGroupStroke(stroke1);
                                                                                                                                          assertTrue(r1.equals(r2));
                                                                                                                                          
                                                                                                                                          // Test with different stroke objects but same attributes
                                                                                                                                          r1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                          r2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                          assertTrue(r1.equals(r2));
                                                                                                                                      }

 @Test
                                                                                                                                     public void testEqualsWithDifferentPlotLines1() {
                                                                                                                                         // Create two renderers with different plotLines values
                                                                                                                                         MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                         MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                         
                                                                                                                                         // Set up identical properties except for plotLines
                                                                                                                                         renderer1.setDrawLines(true);
                                                                                                                                         renderer2.setDrawLines(false);
                                                                                                                                         renderer1.setGroupPaint(Color.RED);
                                                                                                                                         renderer2.setGroupPaint(Color.RED);
                                                                                                                                         renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                         renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                         
                                                                                                                                         // The original method should return false since plotLines differ
                                                                                                                                         // The mutant would return true here
                                                                                                                                         assertFalse("Renderers with different plotLines should not be equal", 
                                                                                                                                                    renderer1.equals(renderer2));
                                                                                                                                         
                                                                                                                                         // Also test symmetry
                                                                                                                                         assertFalse("Renderers with different plotLines should not be equal (symmetry)", 
                                                                                                                                                    renderer2.equals(renderer1));
                                                                                                                                     }

 @Test
                                                                                                                                     public void testEqualsWithSamePlotLines1() {
                                                                                                                                         // Create two renderers with same plotLines values
                                                                                                                                         MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                         MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                         
                                                                                                                                         // Set up identical properties including plotLines
                                                                                                                                         renderer1.setDrawLines(true);
                                                                                                                                         renderer2.setDrawLines(true);
                                                                                                                                         renderer1.setGroupPaint(Color.BLUE);
                                                                                                                                         renderer2.setGroupPaint(Color.BLUE);
                                                                                                                                         renderer1.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                                         renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                                         
                                                                                                                                         // Should return true when all fields match
                                                                                                                                         assertTrue("Renderers with same properties should be equal", 
                                                                                                                                                   renderer1.equals(renderer2));
                                                                                                                                     }

 @Test
                                                                                                                                    public void testEqualsWithDifferentGroupPaint1() {
                                                                                                                                        // Create two renderers with same properties except groupPaint
                                                                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                        
                                                                                                                                        renderer1.setGroupPaint(Color.RED);
                                                                                                                                        renderer2.setGroupPaint(Color.BLUE);
                                                                                                                                        
                                                                                                                                        assertFalse("Renderers with different groupPaint should not be equal", 
                                                                                                                                                   renderer1.equals(renderer2));
                                                                                                                                    }

 @Test
                                                                                                                                    public void testEqualsWithNullGroupPaint2() {
                                                                                                                                        // Create two renderers where one has null groupPaint
                                                                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                        
                                                                                                                                        renderer1.setGroupPaint(null);
                                                                                                                                        renderer2.setGroupPaint(Color.BLUE);
                                                                                                                                        
                                                                                                                                        assertFalse("Renderer with null groupPaint should not equal one with non-null groupPaint",
                                                                                                                                                   renderer1.equals(renderer2));
                                                                                                                                    }

 @Test
                                                                                                                                    public void testEqualsWithDifferentGroupStroke2() {
                                                                                                                                        // Create two renderers with same properties except groupStroke
                                                                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                        
                                                                                                                                        renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                        renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                                        
                                                                                                                                        assertFalse("Renderers with different groupStroke should not be equal",
                                                                                                                                                   renderer1.equals(renderer2));
                                                                                                                                    }

 @Test
                                                                                                                                    public void testEqualsWithNullGroupStroke3() {
                                                                                                                                        // Create two renderers where one has null groupStroke
                                                                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                        
                                                                                                                                        renderer1.setGroupStroke(null);
                                                                                                                                        renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                        
                                                                                                                                        assertFalse("Renderer with null groupStroke should not equal one with non-null groupStroke",
                                                                                                                                                   renderer1.equals(renderer2));
                                                                                                                                    }

 @Test
                                                                                                                                    public void testEqualsWithDifferentPlotLines2() {
                                                                                                                                        // Create two renderers with different plotLines values
                                                                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                        
                                                                                                                                        renderer1.setDrawLines(true);
                                                                                                                                        renderer2.setDrawLines(false);
                                                                                                                                        
                                                                                                                                        assertFalse("Renderers with different plotLines should not be equal",
                                                                                                                                                   renderer1.equals(renderer2));
                                                                                                                                    }

 @Test
                                                                                                                                    public void testEqualsWithSameProperties() {
                                                                                                                                        // Create two identical renderers
                                                                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                        
                                                                                                                                        renderer1.setDrawLines(true);
                                                                                                                                        renderer2.setDrawLines(true);
                                                                                                                                        renderer1.setGroupPaint(Color.RED);
                                                                                                                                        renderer2.setGroupPaint(Color.RED);
                                                                                                                                        renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                        renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                                        
                                                                                                                                        assertTrue("Identical renderers should be equal", renderer1.equals(renderer2));
                                                                                                                                    }

 @Test
                                                                                                                                    public void testEqualsWithNull1() {
                                                                                                                                        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                        assertFalse("Equals with null should return false", renderer.equals(null));
                                                                                                                                    }

 @Test
                                                                                                                                    public void testEqualsWithDifferentClass1() {
                                                                                                                                        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                                        assertFalse("Equals with different class should return false", 
                                                                                                                                                   renderer.equals(new Object()));
                                                                                                                                    }

 @Test
                                                                                                                               public void testEqualsWithPrecisionDifference() {
                                                                                                                                   // Create two renderers that should be considered equal
                                                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                   
                                                                                                                                   // Set identical properties
                                                                                                                                   renderer1.setDrawLines(true);
                                                                                                                                   renderer2.setDrawLines(true);
                                                                                                                                   
                                                                                                                                   // Create paints that are equal
                                                                                                                                   Paint paint = new Color(100, 100, 100);
                                                                                                                                   renderer1.setGroupPaint(paint);
                                                                                                                                   renderer2.setGroupPaint(paint);
                                                                                                                                   
                                                                                                                                   // Create strokes that are equal
                                                                                                                                   Stroke stroke = new BasicStroke(1.0f);
                                                                                                                                   renderer1.setGroupStroke(stroke);
                                                                                                                                   renderer2.setGroupStroke(stroke);
                                                                                                                                   
                                                                                                                                   // Set min/max values that are very close but would differ in float precision
                                                                                                                                   // This value is chosen because 1.0000001 can be represented exactly in double
                                                                                                                                   // but when converted to float, it becomes 1.0 due to precision loss
                                                                                                                                   double preciseValue = 1.0000001;
                                                                                                                                   
                                                                                                                                   // Using reflection to set private fields since there are no public setters
                                                                                                                                   try {
                                                                                                                                       Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                                                                                                                       Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                                                                                                       minField.setAccessible(true);
                                                                                                                                       maxField.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Set values that are very close but would be equal in double precision
                                                                                                                                       minField.set(renderer1, preciseValue);
                                                                                                                                       maxField.set(renderer1, preciseValue);
                                                                                                                                       minField.set(renderer2, preciseValue);
                                                                                                                                       maxField.set(renderer2, preciseValue);
                                                                                                                                   } catch (Exception e) {
                                                                                                                                       fail("Failed to set private fields via reflection");
                                                                                                                                   }
                                                                                                                                   
                                                                                                                                   // The original implementation should consider them equal
                                                                                                                                   assertTrue(renderer1.equals(renderer2));
                                                                                                                                   assertTrue(renderer2.equals(renderer1));
                                                                                                                                   
                                                                                                                                   // The mutant using floatValue() would fail this test because:
                                                                                                                                   // 1.0000001 as float becomes 1.0, but the comparison would be done at double precision
                                                                                                                                   // revealing the precision difference
                                                                                                                               }

 @Test
                                                                                                                                  public void testEquals2() {
                                                                                                                                      // Create two renderers with same values
                                                                                                                                      MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                                      MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                                      
                                                                                                                                      // Test reference equality
                                                                                                                                      assertTrue(r1.equals(r1));
                                                                                                                                      
                                                                                                                                      // Test with null
                                                                                                                                      assertFalse(r1.equals(null));
                                                                                                                                      
                                                                                                                                      // Test with different class
                                                                                                                                      assertFalse(r1.equals(new Object()));
                                                                                                                                      
                                                                                                                                      // Test with equal objects
                                                                                                                                      assertTrue(r1.equals(r2));
                                                                                                                                      
                                                                                                                                      // Test plotLines difference
                                                                                                                                      r1.setDrawLines(true);
                                                                                                                                      r2.setDrawLines(false);
                                                                                                                                      assertFalse(r1.equals(r2));
                                                                                                                                      r2.setDrawLines(true);
                                                                                                                                      
                                                                                                                                      // Test groupPaint difference
                                                                                                                                      r1.setGroupPaint(Color.RED);
                                                                                                                                      r2.setGroupPaint(Color.BLUE);
                                                                                                                                      assertFalse(r1.equals(r2));
                                                                                                                                      r2.setGroupPaint(Color.RED);
                                                                                                                                      
                                                                                                                                      // Test groupStroke difference
                                                                                                                                      Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                                      Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                                                      r1.setGroupStroke(stroke1);
                                                                                                                                      r2.setGroupStroke(stroke2);
                                                                                                                                      assertFalse(r1.equals(r2));
                                                                                                                                      r2.setGroupStroke(stroke1);
                                                                                                                                      
                                                                                                                                      // Should be equal again after resetting all fields
                                                                                                                                      assertTrue(r1.equals(r2));
                                                                                                                                  }

 @Test
                                                                                                                                 public void testEquals3() {
                                                                                                                                     // Create two equal renderers
                                                                                                                                     MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                     MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                     
                                                                                                                                     // Test reference equality
                                                                                                                                     assertTrue(renderer1.equals(renderer1));
                                                                                                                                     
                                                                                                                                     // Test with null
                                                                                                                                     assertFalse(renderer1.equals(null));
                                                                                                                                     
                                                                                                                                     // Test with different type
                                                                                                                                     assertFalse(renderer1.equals(new Object()));
                                                                                                                                     
                                                                                                                                     // Test equal objects
                                                                                                                                     assertTrue(renderer1.equals(renderer2));
                                                                                                                                     
                                                                                                                                     // Test plotLines difference
                                                                                                                                     renderer1.setDrawLines(true);
                                                                                                                                     renderer2.setDrawLines(false);
                                                                                                                                     assertFalse(renderer1.equals(renderer2));
                                                                                                                                     renderer2.setDrawLines(true);
                                                                                                                                     
                                                                                                                                     // Test groupPaint difference
                                                                                                                                     Paint paint1 = Color.RED;
                                                                                                                                     Paint paint2 = Color.BLUE;
                                                                                                                                     renderer1.setGroupPaint(paint1);
                                                                                                                                     renderer2.setGroupPaint(paint2);
                                                                                                                                     assertFalse(renderer1.equals(renderer2));
                                                                                                                                     renderer2.setGroupPaint(paint1);
                                                                                                                                     
                                                                                                                                     // Test groupStroke difference
                                                                                                                                     Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                                     Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                                                     renderer1.setGroupStroke(stroke1);
                                                                                                                                     renderer2.setGroupStroke(stroke2);
                                                                                                                                     assertFalse(renderer1.equals(renderer2));
                                                                                                                                     renderer2.setGroupStroke(stroke1);
                                                                                                                                     
                                                                                                                                     // Should be equal again after resetting all properties
                                                                                                                                     assertTrue(renderer1.equals(renderer2));
                                                                                                                                 }

 @Test
                                                                                                                            public void testEqualsWithDifferentPlotLines3() {
                                                                                                                                // Create two renderers with all fields equal except plotLines
                                                                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                                
                                                                                                                                // Mock paint and stroke to be equal
                                                                                                                                Paint mockPaint = mock(Paint.class);
                                                                                                                                Stroke mockStroke = mock(Stroke.class);
                                                                                                                                when(PaintUtilities.equal(mockPaint, mockPaint)).thenReturn(true);
                                                                                                                                when(mockStroke.equals(mockStroke)).thenReturn(true);
                                                                                                                                
                                                                                                                                // Set equal properties
                                                                                                                                renderer1.setGroupPaint(mockPaint);
                                                                                                                                renderer2.setGroupPaint(mockPaint);
                                                                                                                                renderer1.setGroupStroke(mockStroke);
                                                                                                                                renderer2.setGroupStroke(mockStroke);
                                                                                                                                
                                                                                                                                // Set different plotLines values
                                                                                                                                renderer1.setDrawLines(true);
                                                                                                                                renderer2.setDrawLines(false);
                                                                                                                                
                                                                                                                                // Test that they are not equal
                                                                                                                                assertFalse(renderer1.equals(renderer2));
                                                                                                                                
                                                                                                                                // Also test symmetry
                                                                                                                                assertFalse(renderer2.equals(renderer1));
                                                                                                                                
                                                                                                                                // Test equal case
                                                                                                                                renderer2.setDrawLines(true);
                                                                                                                                assertTrue(renderer1.equals(renderer2));
                                                                                                                            }

 @Test
                                                                                                                          public void testDrawItemYCoordinateCalculation() throws Exception {
                                                                                                                              // Setup test data
                                                                                                                              MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                              CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                              Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                              CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                              CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                              ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                              CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                              
                                                                                                                              // Configure mocks
                                                                                                                              when(dataset.getValue(anyInt(), anyInt())).thenReturn(50.0);
                                                                                                                              when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any())).thenAnswer(inv -> {
                                                                                                                                  double value = inv.getArgument(0);
                                                                                                                                  return 100 - value; // Simple conversion for testing
                                                                                                                              });
                                                                                                                              
                                                                                                                              // Call method under test
                                                                                                                              renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                                                                                                              
                                                                                                                              // Verify the y-coordinate calculation used the dataset value (50.0)
                                                                                                                              verify(rangeAxis).valueToJava2D(eq(50.0), eq(dataArea), any());
                                                                                                                              
                                                                                                                              // Also verify the resulting y position is correct (100 - 50 = 50)
                                                                                                                              // This is an additional check to ensure proper rendering position
                                                                                                                              verify(g2).drawLine(anyInt(), eq(50), anyInt(), anyInt());
                                                                                                                          }

 @Test(expected = NullPointerException.class)
                                                                                                                      public void testDrawItemWithNullDataArea() {
                                                                                                                          // Setup test objects
                                                                                                                          MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                          renderer.setDrawLines(true);
                                                                                                                          
                                                                                                                          // Mock required objects
                                                                                                                          Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                          CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                          CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                          CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                          ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                          CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                          
                                                                                                                          // Mock behavior
                                                                                                                          when(dataset.getRowCount()).thenReturn(1);
                                                                                                                          when(dataset.getColumnCount()).thenReturn(1);
                                                                                                                          when(dataset.getValue(0, 0)).thenReturn(10.0);
                                                                                                                          
                                                                                                                          // This should throw NullPointerException due to the mutation
                                                                                                                          renderer.drawItem(g2, state, null, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                                                                                                          
                                                                                                                          // If no exception is thrown, verify incorrect behavior
                                                                                                                          verify(rangeAxis, never()).valueToJava2D(anyDouble(), any(), any());
                                                                                                                      }

 @Test
                                                                                                                         public void testEquals4() {
                                                                                                                             // Create two renderers with same values
                                                                                                                             MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                             MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                             
                                                                                                                             // Test reference equality
                                                                                                                             assertTrue(r1.equals(r1));
                                                                                                                             
                                                                                                                             // Test with null
                                                                                                                             assertFalse(r1.equals(null));
                                                                                                                             
                                                                                                                             // Test with different type
                                                                                                                             assertFalse(r1.equals(new Object()));
                                                                                                                             
                                                                                                                             // Test equal objects
                                                                                                                             assertTrue(r1.equals(r2));
                                                                                                                             
                                                                                                                             // Test plotLines difference
                                                                                                                             r1.setDrawLines(true);
                                                                                                                             r2.setDrawLines(false);
                                                                                                                             assertFalse(r1.equals(r2));
                                                                                                                             r2.setDrawLines(true);
                                                                                                                             
                                                                                                                             // Test groupPaint difference
                                                                                                                             r1.setGroupPaint(Color.RED);
                                                                                                                             r2.setGroupPaint(Color.BLUE);
                                                                                                                             assertFalse(r1.equals(r2));
                                                                                                                             r2.setGroupPaint(Color.RED);
                                                                                                                             
                                                                                                                             // Test groupStroke difference
                                                                                                                             BasicStroke stroke1 = new BasicStroke(1.0f);
                                                                                                                             BasicStroke stroke2 = new BasicStroke(2.0f);
                                                                                                                             r1.setGroupStroke(stroke1);
                                                                                                                             r2.setGroupStroke(stroke2);
                                                                                                                             assertFalse(r1.equals(r2));
                                                                                                                             r2.setGroupStroke(stroke1);
                                                                                                                             
                                                                                                                             // Test super.equals() by mocking parent class behavior
                                                                                                                             // (Assuming parent class has some fields that affect equality)
                                                                                                                             // This would require more complex setup with partial mocks
                                                                                                                             
                                                                                                                             // Test with all fields equal again
                                                                                                                             assertTrue(r1.equals(r2));
                                                                                                                         }

 @Test
                                                                                                                         public void testEqualsWithNullPaint() {
                                                                                                                             MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                             MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                             
                                                                                                                             // Test when one has null groupPaint
                                                                                                                             r1.setGroupPaint(null);
                                                                                                                             r2.setGroupPaint(Color.RED);
                                                                                                                             assertFalse(r1.equals(r2));
                                                                                                                             
                                                                                                                             // Test when both have null groupPaint
                                                                                                                             r2.setGroupPaint(null);
                                                                                                                             assertTrue(r1.equals(r2));
                                                                                                                         }

 @Test
                                                                                                                         public void testEqualsWithNullStroke() {
                                                                                                                             MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                             MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                             
                                                                                                                             // Test when one has null groupStroke
                                                                                                                             r1.setGroupStroke(null);
                                                                                                                             r2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                             assertFalse(r1.equals(r2));
                                                                                                                             
                                                                                                                             // Test when both have null groupStroke
                                                                                                                             r2.setGroupStroke(null);
                                                                                                                             assertTrue(r1.equals(r2));
                                                                                                                         }

 @Test
                                                                                                                    public void testDrawItemCallsGetItemPaintWithCorrectParameters() {
                                                                                                                        // Setup test data
                                                                                                                        MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                        Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                        CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                        ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                        
                                                                                                                        // Set test row and column values that would show the difference
                                                                                                                        int testRow = 1;
                                                                                                                        int testColumn = 2;
                                                                                                                        
                                                                                                                        // Mock the getItemPaint method to verify call order
                                                                                                                        when(renderer.getItemPaint(anyInt(), anyInt())).thenReturn(Color.RED);
                                                                                                                        
                                                                                                                        // Execute the method
                                                                                                                        renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, 
                                                                                                                                         dataset, testRow, testColumn, 0);
                                                                                                                        
                                                                                                                        // Verify getItemPaint was called with correct row/column order
                                                                                                                        verify(renderer).getItemPaint(eq(testRow), eq(testColumn));
                                                                                                                        
                                                                                                                        // This would fail if the mutant (swapped row/column) is present
                                                                                                                        // because it would expect getItemPaint(column, row) instead
                                                                                                                    }

 @Test
                                                                                                                       public void testEqualsWithDifferentStrokes() {
                                                                                                                           // Create two renderers with identical properties except stroke
                                                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                           
                                                                                                                           // Set same properties
                                                                                                                           renderer1.setDrawLines(true);
                                                                                                                           renderer2.setDrawLines(true);
                                                                                                                           
                                                                                                                           // Set different strokes
                                                                                                                           Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                           Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                                           renderer1.setGroupStroke(stroke1);
                                                                                                                           renderer2.setGroupStroke(stroke2);
                                                                                                                           
                                                                                                                           // They should not be equal due to different strokes
                                                                                                                           assertFalse(renderer1.equals(renderer2));
                                                                                                                       }

 @Test
                                                                                                                       public void testEqualsWithNullStroke1() {
                                                                                                                           // Create two renderers - one with stroke, one with null stroke
                                                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                           
                                                                                                                           // Set same properties
                                                                                                                           renderer1.setDrawLines(false);
                                                                                                                           renderer2.setDrawLines(false);
                                                                                                                           
                                                                                                                           // Set different strokes
                                                                                                                           renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                           renderer2.setGroupStroke(null);
                                                                                                                           
                                                                                                                           // They should not be equal when one stroke is null
                                                                                                                           assertFalse(renderer1.equals(renderer2));
                                                                                                                           
                                                                                                                           // Both null strokes should be equal
                                                                                                                           renderer1.setGroupStroke(null);
                                                                                                                           assertTrue(renderer1.equals(renderer2));
                                                                                                                       }

 @Test
                                                                                                                       public void testEqualsWithSameStrokes() {
                                                                                                                           // Create two renderers with identical strokes
                                                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                           
                                                                                                                           // Set same properties
                                                                                                                           renderer1.setDrawLines(true);
                                                                                                                           renderer2.setDrawLines(true);
                                                                                                                           
                                                                                                                           // Set same stroke
                                                                                                                           Stroke stroke = new BasicStroke(1.5f);
                                                                                                                           renderer1.setGroupStroke(stroke);
                                                                                                                           renderer2.setGroupStroke(stroke);
                                                                                                                           
                                                                                                                           // They should be equal when strokes are the same
                                                                                                                           assertTrue(renderer1.equals(renderer2));
                                                                                                                       }

 @Test
                                                                                                                  public void testDrawItemStrokeOrderMutant() {
                                                                                                                      // Setup
                                                                                                                      MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                      MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                      
                                                                                                                      // Create different strokes for row/column combinations
                                                                                                                      Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                      Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                                      
                                                                                                                      // Mock necessary objects
                                                                                                                      Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                      CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                      Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                      CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                      CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                      ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                      CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                      
                                                                                                                      // Stub getItemStroke to return different strokes based on parameters
                                                                                                                      when(renderer1.getItemStroke(0, 1)).thenReturn(stroke1);
                                                                                                                      when(renderer1.getItemStroke(1, 0)).thenReturn(stroke2);
                                                                                                                      
                                                                                                                      // For mutant version, the parameters would be reversed
                                                                                                                      when(renderer2.getItemStroke(1, 0)).thenReturn(stroke1); // reversed
                                                                                                                      when(renderer2.getItemStroke(0, 1)).thenReturn(stroke2); // reversed
                                                                                                                      
                                                                                                                      // Execute original and mutated versions
                                                                                                                      renderer1.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
                                                                                                                      renderer2.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1, 0);
                                                                                                                      
                                                                                                                      // Verify stroke was set correctly for original
                                                                                                                      verify(g2).setStroke(stroke1);
                                                                                                                      
                                                                                                                      // Clear invocations to test again
                                                                                                                      reset(g2);
                                                                                                                      
                                                                                                                      // Execute with different row/column
                                                                                                                      renderer1.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0, 0);
                                                                                                                      renderer2.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0, 0);
                                                                                                                      
                                                                                                                      // Verify stroke was set correctly for original
                                                                                                                      verify(g2).setStroke(stroke2);
                                                                                                                      
                                                                                                                      // The mutant would fail these verifications because it reverses the parameters
                                                                                                                  }

 @Test
                                                                                                                     public void testEquals5() {
                                                                                                                         // Create two renderers with same values
                                                                                                                         MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                         MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                         
                                                                                                                         // Test same object
                                                                                                                         assertTrue(r1.equals(r1));
                                                                                                                         
                                                                                                                         // Test equal objects
                                                                                                                         assertTrue(r1.equals(r2));
                                                                                                                         
                                                                                                                         // Test with null
                                                                                                                         assertFalse(r1.equals(null));
                                                                                                                         
                                                                                                                         // Test with different class
                                                                                                                         assertFalse(r1.equals(new Object()));
                                                                                                                         
                                                                                                                         // Test plotLines difference
                                                                                                                         r1.setDrawLines(true);
                                                                                                                         assertFalse(r1.equals(r2));
                                                                                                                         r2.setDrawLines(true);
                                                                                                                         assertTrue(r1.equals(r2));
                                                                                                                         
                                                                                                                         // Test groupPaint difference
                                                                                                                         r1.setGroupPaint(Color.RED);
                                                                                                                         assertFalse(r1.equals(r2));
                                                                                                                         r2.setGroupPaint(Color.RED);
                                                                                                                         assertTrue(r1.equals(r2));
                                                                                                                         
                                                                                                                         // Test groupStroke difference
                                                                                                                         BasicStroke stroke1 = new BasicStroke(1.0f);
                                                                                                                         BasicStroke stroke2 = new BasicStroke(2.0f);
                                                                                                                         r1.setGroupStroke(stroke1);
                                                                                                                         assertFalse(r1.equals(r2));
                                                                                                                         r2.setGroupStroke(stroke1);
                                                                                                                         assertTrue(r1.equals(r2));
                                                                                                                         
                                                                                                                         // Test with different stroke
                                                                                                                         r2.setGroupStroke(stroke2);
                                                                                                                         assertFalse(r1.equals(r2));
                                                                                                                         
                                                                                                                         // Test super.equals() behavior
                                                                                                                         // (Assuming super class has some fields to compare)
                                                                                                                         // This would require mocking or knowing super class behavior
                                                                                                                     }

 @Test
                                                                                                                    public void testEquals6() {
                                                                                                                        // Create two identical renderers
                                                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                        
                                                                                                                        // Should be equal
                                                                                                                        assertTrue(renderer1.equals(renderer2));
                                                                                                                        
                                                                                                                        // Test with different plotLines
                                                                                                                        renderer1.setDrawLines(true);
                                                                                                                        renderer2.setDrawLines(false);
                                                                                                                        assertFalse(renderer1.equals(renderer2));
                                                                                                                        renderer2.setDrawLines(true); // reset
                                                                                                                        
                                                                                                                        // Test with different groupPaint
                                                                                                                        renderer1.setGroupPaint(Color.RED);
                                                                                                                        renderer2.setGroupPaint(Color.BLUE);
                                                                                                                        assertFalse(renderer1.equals(renderer2));
                                                                                                                        renderer2.setGroupPaint(Color.RED); // reset
                                                                                                                        
                                                                                                                        // Test with different groupStroke
                                                                                                                        Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                        Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                                        renderer1.setGroupStroke(stroke1);
                                                                                                                        renderer2.setGroupStroke(stroke2);
                                                                                                                        assertFalse(renderer1.equals(renderer2));
                                                                                                                        
                                                                                                                        // Test with null
                                                                                                                        assertFalse(renderer1.equals(null));
                                                                                                                        
                                                                                                                        // Test with different object type
                                                                                                                        assertFalse(renderer1.equals("Not a renderer"));
                                                                                                                        
                                                                                                                        // Test with same object
                                                                                                                        assertTrue(renderer1.equals(renderer1));
                                                                                                                    }

 @Test
                                                                                                               public void testEquals7() {
                                                                                                                   // Create two identical renderers
                                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                   
                                                                                                                   // Test identity case
                                                                                                                   assertTrue(renderer1.equals(renderer1));
                                                                                                                   
                                                                                                                   // Test equality of default instances
                                                                                                                   assertTrue(renderer1.equals(renderer2));
                                                                                                                   
                                                                                                                   // Test with different plotLines values
                                                                                                                   renderer1.setDrawLines(true);
                                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                                                   renderer2.setDrawLines(true);
                                                                                                                   assertTrue(renderer1.equals(renderer2));
                                                                                                                   
                                                                                                                   // Test with different groupPaint
                                                                                                                   renderer1.setGroupPaint(Color.RED);
                                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                                                   renderer2.setGroupPaint(Color.RED);
                                                                                                                   assertTrue(renderer1.equals(renderer2));
                                                                                                                   
                                                                                                                   // Test with different groupStroke
                                                                                                                   Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                   Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                                   renderer1.setGroupStroke(stroke1);
                                                                                                                   renderer2.setGroupStroke(stroke2);
                                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                                                   renderer2.setGroupStroke(stroke1);
                                                                                                                   assertTrue(renderer1.equals(renderer2));
                                                                                                                   
                                                                                                                   // Test with null
                                                                                                                   assertFalse(renderer1.equals(null));
                                                                                                                   
                                                                                                                   // Test with different class
                                                                                                                   assertFalse(renderer1.equals(new Object()));
                                                                                                                   
                                                                                                                   // Test parent class equality
                                                                                                                   // (Assuming parent class has some fields that affect equality)
                                                                                                                   // This would require mocking or knowing parent class behavior
                                                                                                               }

 @Test
                                                                                                                  public void testEquals8() {
                                                                                                                      // Create test objects
                                                                                                                      MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                      MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                      MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                                                      
                                                                                                                      // Set different properties for renderer3
                                                                                                                      renderer3.setDrawLines(!renderer1.isDrawLines());
                                                                                                                      renderer3.setGroupPaint(Color.RED);
                                                                                                                      renderer3.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                      
                                                                                                                      // Test identity
                                                                                                                      assertTrue(renderer1.equals(renderer1));
                                                                                                                      
                                                                                                                      // Test null
                                                                                                                      assertFalse(renderer1.equals(null));
                                                                                                                      
                                                                                                                      // Test wrong class
                                                                                                                      assertFalse(renderer1.equals(new Object()));
                                                                                                                      
                                                                                                                      // Test equal objects
                                                                                                                      assertTrue(renderer1.equals(renderer2));
                                                                                                                      
                                                                                                                      // Test unequal plotLines
                                                                                                                      renderer2.setDrawLines(!renderer1.isDrawLines());
                                                                                                                      assertFalse(renderer1.equals(renderer2));
                                                                                                                      renderer2.setDrawLines(renderer1.isDrawLines()); // reset
                                                                                                                      
                                                                                                                      // Test unequal groupPaint
                                                                                                                      renderer2.setGroupPaint(Color.BLUE);
                                                                                                                      assertFalse(renderer1.equals(renderer2));
                                                                                                                      renderer2.setGroupPaint(renderer1.getGroupPaint()); // reset
                                                                                                                      
                                                                                                                      // Test unequal groupStroke
                                                                                                                      renderer2.setGroupStroke(new BasicStroke(1.5f));
                                                                                                                      assertFalse(renderer1.equals(renderer2));
                                                                                                                      
                                                                                                                      // Test completely different object
                                                                                                                      assertFalse(renderer1.equals(renderer3));
                                                                                                                  }

 @Test
                                                                                                                 public void testEquals9() {
                                                                                                                     // Create two identical renderers
                                                                                                                     MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                     MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                     
                                                                                                                     // Test reference equality
                                                                                                                     assertTrue(r1.equals(r1));
                                                                                                                     
                                                                                                                     // Test equality of default instances
                                                                                                                     assertTrue(r1.equals(r2));
                                                                                                                     
                                                                                                                     // Test with null
                                                                                                                     assertFalse(r1.equals(null));
                                                                                                                     
                                                                                                                     // Test with different class
                                                                                                                     assertFalse(r1.equals(new Object()));
                                                                                                                     
                                                                                                                     // Test plotLines difference
                                                                                                                     r1.setDrawLines(true);
                                                                                                                     r2.setDrawLines(false);
                                                                                                                     assertFalse(r1.equals(r2));
                                                                                                                     r2.setDrawLines(true);
                                                                                                                     
                                                                                                                     // Test groupPaint difference
                                                                                                                     r1.setGroupPaint(Color.RED);
                                                                                                                     assertFalse(r1.equals(r2));
                                                                                                                     r2.setGroupPaint(Color.RED);
                                                                                                                     assertTrue(r1.equals(r2));
                                                                                                                     
                                                                                                                     // Test groupStroke difference
                                                                                                                     Stroke s1 = new BasicStroke(1.0f);
                                                                                                                     Stroke s2 = new BasicStroke(2.0f);
                                                                                                                     r1.setGroupStroke(s1);
                                                                                                                     r2.setGroupStroke(s2);
                                                                                                                     assertFalse(r1.equals(r2));
                                                                                                                     r2.setGroupStroke(s1);
                                                                                                                     assertTrue(r1.equals(r2));
                                                                                                                     
                                                                                                                     // Test with different icons (shouldn't affect equals)
                                                                                                                     r1.setMinIcon(null);
                                                                                                                     r2.setMinIcon(null);
                                                                                                                     assertTrue(r1.equals(r2));
                                                                                                                 }

 @Test
                                                                                                                public void testEquals10() {
                                                                                                                    // Create two renderers with same values
                                                                                                                    MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                    MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                    
                                                                                                                    // Test reference equality
                                                                                                                    assertTrue(r1.equals(r1));
                                                                                                                    
                                                                                                                    // Test with null
                                                                                                                    assertFalse(r1.equals(null));
                                                                                                                    
                                                                                                                    // Test with different type
                                                                                                                    assertFalse(r1.equals(new Object()));
                                                                                                                    
                                                                                                                    // Test with equal objects
                                                                                                                    assertTrue(r1.equals(r2));
                                                                                                                    
                                                                                                                    // Test plotLines difference
                                                                                                                    r1.setDrawLines(true);
                                                                                                                    assertFalse(r1.equals(r2));
                                                                                                                    r2.setDrawLines(true);
                                                                                                                    assertTrue(r1.equals(r2));
                                                                                                                    
                                                                                                                    // Test groupPaint difference
                                                                                                                    r1.setGroupPaint(Color.RED);
                                                                                                                    assertFalse(r1.equals(r2));
                                                                                                                    r2.setGroupPaint(Color.RED);
                                                                                                                    assertTrue(r1.equals(r2));
                                                                                                                    
                                                                                                                    // Test groupStroke difference
                                                                                                                    r1.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                    assertFalse(r1.equals(r2));
                                                                                                                    r2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                    assertTrue(r1.equals(r2));
                                                                                                                    
                                                                                                                    // Test with different superclass fields
                                                                                                                    // (Assuming superclass has some fields that affect equality)
                                                                                                                    // This would require mocking or knowing the superclass behavior
                                                                                                                }

 @Test
                                                                                                                public void testPaintUtilitiesEqualForNull() {
                                                                                                                    // Test PaintUtilities.equal handles null properly
                                                                                                                    MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                                    MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                                    
                                                                                                                    r1.setGroupPaint(null);
                                                                                                                    r2.setGroupPaint(Color.BLUE);
                                                                                                                    assertFalse(r1.equals(r2));
                                                                                                                    
                                                                                                                    r1.setGroupPaint(Color.BLUE);
                                                                                                                    r2.setGroupPaint(null);
                                                                                                                    assertFalse(r1.equals(r2));
                                                                                                                    
                                                                                                                    r1.setGroupPaint(null);
                                                                                                                    r2.setGroupPaint(null);
                                                                                                                    assertTrue(r1.equals(r2));
                                                                                                                }

 @Test
                                                                                                               public void testEquals_SameInstance1() {
                                                                                                                   MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                   assertTrue(renderer.equals(renderer));
                                                                                                               }

 @Test
                                                                                                               public void testEquals_NullObject1() {
                                                                                                                   MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                   assertFalse(renderer.equals(null));
                                                                                                               }

 @Test
                                                                                                               public void testEquals_DifferentClass2() {
                                                                                                                   MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                                   assertFalse(renderer.equals(new Object()));
                                                                                                               }

 @Test
                                                                                                               public void testEquals_EqualObjects1() {
                                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                   
                                                                                                                   // Set same values for all fields
                                                                                                                   renderer1.setDrawLines(true);
                                                                                                                   renderer2.setDrawLines(true);
                                                                                                                   
                                                                                                                   Paint paint = mock(Paint.class);
                                                                                                                   renderer1.setGroupPaint(paint);
                                                                                                                   renderer2.setGroupPaint(paint);
                                                                                                                   
                                                                                                                   Stroke stroke = new BasicStroke(1.0f);
                                                                                                                   renderer1.setGroupStroke(stroke);
                                                                                                                   renderer2.setGroupStroke(stroke);
                                                                                                                   
                                                                                                                   assertTrue(renderer1.equals(renderer2));
                                                                                                               }

 @Test
                                                                                                               public void testEquals_DifferentPlotLines2() {
                                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                   
                                                                                                                   renderer1.setDrawLines(true);
                                                                                                                   renderer2.setDrawLines(false);
                                                                                                                   
                                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                                               }

 @Test
                                                                                                               public void testEquals_DifferentGroupPaint2() {
                                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                   
                                                                                                                   renderer1.setGroupPaint(mock(Paint.class));
                                                                                                                   renderer2.setGroupPaint(mock(Paint.class));
                                                                                                                   
                                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                                               }

 @Test
                                                                                                               public void testEquals_DifferentGroupStroke2() {
                                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                   
                                                                                                                   renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                   renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                   
                                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                                               }

 @Test
                                                                                                               public void testEquals_AllFieldsDifferent() {
                                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                   
                                                                                                                   renderer1.setDrawLines(true);
                                                                                                                   renderer2.setDrawLines(false);
                                                                                                                   
                                                                                                                   renderer1.setGroupPaint(mock(Paint.class));
                                                                                                                   renderer2.setGroupPaint(mock(Paint.class));
                                                                                                                   
                                                                                                                   renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                                   renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                   
                                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                                               }

 @Test
                                                                                                              public void testEquals11() {
                                                                                                                  // Create test paints and strokes
                                                                                                                  Paint paint1 = Color.RED;
                                                                                                                  Paint paint2 = Color.BLUE;
                                                                                                                  Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                                  Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                          
                                                                                                                  // Create test instances
                                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                  renderer1.setDrawLines(true);
                                                                                                                  renderer1.setGroupPaint(paint1);
                                                                                                                  renderer1.setGroupStroke(stroke1);
                                                                                                          
                                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                  renderer2.setDrawLines(true);
                                                                                                                  renderer2.setGroupPaint(paint1);
                                                                                                                  renderer2.setGroupStroke(stroke1);
                                                                                                          
                                                                                                                  MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                                                  renderer3.setDrawLines(false); // different plotLines
                                                                                                                  renderer3.setGroupPaint(paint1);
                                                                                                                  renderer3.setGroupStroke(stroke1);
                                                                                                          
                                                                                                                  MinMaxCategoryRenderer renderer4 = new MinMaxCategoryRenderer();
                                                                                                                  renderer4.setDrawLines(true);
                                                                                                                  renderer4.setGroupPaint(paint2); // different paint
                                                                                                                  renderer4.setGroupStroke(stroke1);
                                                                                                          
                                                                                                                  MinMaxCategoryRenderer renderer5 = new MinMaxCategoryRenderer();
                                                                                                                  renderer5.setDrawLines(true);
                                                                                                                  renderer5.setGroupPaint(paint1);
                                                                                                                  renderer5.setGroupStroke(stroke2); // different stroke
                                                                                                          
                                                                                                                  // Test reflexivity
                                                                                                                  assertTrue(renderer1.equals(renderer1));
                                                                                                          
                                                                                                                  // Test symmetry
                                                                                                                  assertTrue(renderer1.equals(renderer2));
                                                                                                                  assertTrue(renderer2.equals(renderer1));
                                                                                                          
                                                                                                                  // Test null handling
                                                                                                                  assertFalse(renderer1.equals(null));
                                                                                                          
                                                                                                                  // Test wrong type handling
                                                                                                                  assertFalse(renderer1.equals("not a renderer"));
                                                                                                          
                                                                                                                  // Test field differences
                                                                                                                  assertFalse(renderer1.equals(renderer3)); // plotLines difference
                                                                                                                  assertFalse(renderer1.equals(renderer4)); // groupPaint difference
                                                                                                                  assertFalse(renderer1.equals(renderer5)); // groupStroke difference
                                                                                                          
                                                                                                                  // Test consistency
                                                                                                                  assertTrue(renderer1.equals(renderer2));
                                                                                                                  assertTrue(renderer1.equals(renderer2)); // multiple calls
                                                                                                              }

 @Test
                                                                                                             public void testEquals12() {
                                                                                                                 // Create test objects
                                                                                                                 MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                 MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                 MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                                                 
                                                                                                                 // Set different properties for renderer3
                                                                                                                 renderer3.setDrawLines(!renderer1.isDrawLines());
                                                                                                                 renderer3.setGroupPaint(Color.RED);
                                                                                                                 renderer3.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                 
                                                                                                                 // Test identity
                                                                                                                 assertTrue(renderer1.equals(renderer1));
                                                                                                                 
                                                                                                                 // Test against null
                                                                                                                 assertFalse(renderer1.equals(null));
                                                                                                                 
                                                                                                                 // Test against different class
                                                                                                                 assertFalse(renderer1.equals(new Object()));
                                                                                                                 
                                                                                                                 // Test equal objects
                                                                                                                 assertTrue(renderer1.equals(renderer2));
                                                                                                                 assertTrue(renderer2.equals(renderer1));
                                                                                                                 
                                                                                                                 // Test unequal objects - plotLines
                                                                                                                 renderer2.setDrawLines(!renderer1.isDrawLines());
                                                                                                                 assertFalse(renderer1.equals(renderer2));
                                                                                                                 renderer2.setDrawLines(renderer1.isDrawLines());
                                                                                                                 
                                                                                                                 // Test unequal objects - groupPaint
                                                                                                                 renderer2.setGroupPaint(Color.BLUE);
                                                                                                                 assertFalse(renderer1.equals(renderer2));
                                                                                                                 renderer2.setGroupPaint(renderer1.getGroupPaint());
                                                                                                                 
                                                                                                                 // Test unequal objects - groupStroke
                                                                                                                 renderer2.setGroupStroke(new BasicStroke(1.5f));
                                                                                                                 assertFalse(renderer1.equals(renderer2));
                                                                                                                 
                                                                                                                 // Test completely different object
                                                                                                                 assertFalse(renderer1.equals(renderer3));
                                                                                                             }

 @Test
                                                                                                            public void testEquals13() {
                                                                                                                // Create test objects
                                                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                                MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                                                
                                                                                                                // Set different properties for renderer3
                                                                                                                renderer3.setDrawLines(!renderer1.isDrawLines());
                                                                                                                renderer3.setGroupPaint(Color.RED);
                                                                                                                renderer3.setGroupStroke(new BasicStroke(2.0f));
                                                                                                                
                                                                                                                // Test identity
                                                                                                                assertTrue(renderer1.equals(renderer1));
                                                                                                                
                                                                                                                // Test with null
                                                                                                                assertFalse(renderer1.equals(null));
                                                                                                                
                                                                                                                // Test with different type
                                                                                                                assertFalse(renderer1.equals("Not a renderer"));
                                                                                                                
                                                                                                                // Test equal objects
                                                                                                                assertTrue(renderer1.equals(renderer2));
                                                                                                                assertTrue(renderer2.equals(renderer1));
                                                                                                                
                                                                                                                // Test different plotLines
                                                                                                                MinMaxCategoryRenderer renderer4 = new MinMaxCategoryRenderer();
                                                                                                                renderer4.setDrawLines(!renderer1.isDrawLines());
                                                                                                                assertFalse(renderer1.equals(renderer4));
                                                                                                                
                                                                                                                // Test different groupPaint
                                                                                                                MinMaxCategoryRenderer renderer5 = new MinMaxCategoryRenderer();
                                                                                                                renderer5.setGroupPaint(Color.BLUE);
                                                                                                                assertFalse(renderer1.equals(renderer5));
                                                                                                                
                                                                                                                // Test different groupStroke
                                                                                                                MinMaxCategoryRenderer renderer6 = new MinMaxCategoryRenderer();
                                                                                                                renderer6.setGroupStroke(new BasicStroke(1.5f));
                                                                                                                assertFalse(renderer1.equals(renderer6));
                                                                                                                
                                                                                                                // Test completely different object
                                                                                                                assertFalse(renderer1.equals(renderer3));
                                                                                                            }

 @Test
                                                                                                           public void testEquals14() {
                                                                                                               // Create two renderers with same values
                                                                                                               MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                               MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                               
                                                                                                               // Test reference equality
                                                                                                               assertTrue(r1.equals(r1));
                                                                                                               
                                                                                                               // Test with null
                                                                                                               assertFalse(r1.equals(null));
                                                                                                               
                                                                                                               // Test with different type
                                                                                                               assertFalse(r1.equals("not a renderer"));
                                                                                                               
                                                                                                               // Test equal objects
                                                                                                               assertTrue(r1.equals(r2));
                                                                                                               
                                                                                                               // Test plotLines difference
                                                                                                               r1.setDrawLines(true);
                                                                                                               r2.setDrawLines(false);
                                                                                                               assertFalse(r1.equals(r2));
                                                                                                               r2.setDrawLines(true);
                                                                                                               assertTrue(r1.equals(r2));
                                                                                                               
                                                                                                               // Test groupPaint difference
                                                                                                               r1.setGroupPaint(Color.RED);
                                                                                                               r2.setGroupPaint(Color.BLUE);
                                                                                                               assertFalse(r1.equals(r2));
                                                                                                               r2.setGroupPaint(Color.RED);
                                                                                                               assertTrue(r1.equals(r2));
                                                                                                               
                                                                                                               // Test groupStroke difference
                                                                                                               BasicStroke stroke1 = new BasicStroke(1.0f);
                                                                                                               BasicStroke stroke2 = new BasicStroke(2.0f);
                                                                                                               r1.setGroupStroke(stroke1);
                                                                                                               r2.setGroupStroke(stroke2);
                                                                                                               assertFalse(r1.equals(r2));
                                                                                                               r2.setGroupStroke(stroke1);
                                                                                                               assertTrue(r1.equals(r2));
                                                                                                               
                                                                                                               // Note: Testing super.equals() would require knowledge of parent class
                                                                                                           }

 @Test
                                                                                                          public void testEquals_SameInstance2() {
                                                                                                              MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                              assertTrue(renderer.equals(renderer));
                                                                                                          }

 @Test
                                                                                                          public void testEquals_Null1() {
                                                                                                              MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                              assertFalse(renderer.equals(null));
                                                                                                          }

 @Test
                                                                                                          public void testEquals_DifferentType() {
                                                                                                              MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                              assertFalse(renderer.equals("Not a renderer"));
                                                                                                          }

 @Test
                                                                                                          public void testEquals_DifferentPlotLines3() {
                                                                                                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                              
                                                                                                              renderer1.setDrawLines(true);
                                                                                                              renderer2.setDrawLines(false);
                                                                                                              
                                                                                                              assertFalse(renderer1.equals(renderer2));
                                                                                                          }

 @Test
                                                                                                          public void testEquals_DifferentGroupPaint3() {
                                                                                                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                              
                                                                                                              Paint paint1 = Color.RED;
                                                                                                              Paint paint2 = Color.BLUE;
                                                                                                              
                                                                                                              renderer1.setGroupPaint(paint1);
                                                                                                              renderer2.setGroupPaint(paint2);
                                                                                                              
                                                                                                              assertFalse(renderer1.equals(renderer2));
                                                                                                          }

 @Test
                                                                                                          public void testEquals_DifferentGroupStroke3() {
                                                                                                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                              
                                                                                                              Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                              Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                              
                                                                                                              renderer1.setGroupStroke(stroke1);
                                                                                                              renderer2.setGroupStroke(stroke2);
                                                                                                              
                                                                                                              assertFalse(renderer1.equals(renderer2));
                                                                                                          }

 @Test
                                                                                                          public void testEquals_EqualObjects2() {
                                                                                                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                              
                                                                                                              Paint paint = Color.RED;
                                                                                                              Stroke stroke = new BasicStroke(1.0f);
                                                                                                              
                                                                                                              renderer1.setDrawLines(true);
                                                                                                              renderer1.setGroupPaint(paint);
                                                                                                              renderer1.setGroupStroke(stroke);
                                                                                                              
                                                                                                              renderer2.setDrawLines(true);
                                                                                                              renderer2.setGroupPaint(paint);
                                                                                                              renderer2.setGroupStroke(stroke);
                                                                                                              
                                                                                                              assertTrue(renderer1.equals(renderer2));
                                                                                                          }

 @Test
                                                                                                          public void testEquals_SuperClassDifference() {
                                                                                                              // This would require mocking or extending the class to test super.equals()
                                                                                                              // Since we don't have visibility into the super class behavior,
                                                                                                              // we'll skip this test case as we can't properly verify it
                                                                                                          }

 @Test
                                                                                                         public void testEquals15() {
                                                                                                             // Create test objects
                                                                                                             MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                             MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                             
                                                                                                             // Test self-equality
                                                                                                             assertTrue(renderer1.equals(renderer1));
                                                                                                             
                                                                                                             // Test with null
                                                                                                             assertFalse(renderer1.equals(null));
                                                                                                             
                                                                                                             // Test with different type
                                                                                                             assertFalse(renderer1.equals(new Object()));
                                                                                                             
                                                                                                             // Test with equal objects
                                                                                                             assertTrue(renderer1.equals(renderer2));
                                                                                                             
                                                                                                             // Test with different plotLines
                                                                                                             renderer2.setDrawLines(!renderer1.isDrawLines());
                                                                                                             assertFalse(renderer1.equals(renderer2));
                                                                                                             renderer2.setDrawLines(renderer1.isDrawLines());
                                                                                                             
                                                                                                             // Test with different groupPaint
                                                                                                             renderer2.setGroupPaint(Color.RED);
                                                                                                             assertFalse(renderer1.equals(renderer2));
                                                                                                             renderer2.setGroupPaint(renderer1.getGroupPaint());
                                                                                                             
                                                                                                             // Test with different groupStroke
                                                                                                             renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                             assertFalse(renderer1.equals(renderer2));
                                                                                                             
                                                                                                             // Verify super.equals() is called by testing with different icons
                                                                                                             // (assuming super class equality check includes these)
                                                                                                             renderer2.setMinIcon(new Icon() {
                                                                                                                 public int getIconWidth() { return 1; }
                                                                                                                 public int getIconHeight() { return 1; }
                                                                                                                 public void paintIcon(Component c, Graphics g, int x, int y) {}
                                                                                                             });
                                                                                                             assertFalse(renderer1.equals(renderer2));
                                                                                                         }

 @Test
                                                                                                        public void testEquals16() {
                                                                                                            // Create two identical renderers
                                                                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                            
                                                                                                            // Test reference equality
                                                                                                            assertTrue(renderer1.equals(renderer1));
                                                                                                            
                                                                                                            // Test with null
                                                                                                            assertFalse(renderer1.equals(null));
                                                                                                            
                                                                                                            // Test with different class
                                                                                                            assertFalse(renderer1.equals(new Object()));
                                                                                                            
                                                                                                            // Test with equal objects
                                                                                                            assertTrue(renderer1.equals(renderer2));
                                                                                                            
                                                                                                            // Test plotLines difference
                                                                                                            renderer1.setDrawLines(true);
                                                                                                            renderer2.setDrawLines(false);
                                                                                                            assertFalse(renderer1.equals(renderer2));
                                                                                                            renderer2.setDrawLines(true);
                                                                                                            
                                                                                                            // Test groupPaint difference
                                                                                                            Paint paint1 = Color.RED;
                                                                                                            Paint paint2 = Color.BLUE;
                                                                                                            renderer1.setGroupPaint(paint1);
                                                                                                            renderer2.setGroupPaint(paint2);
                                                                                                            assertFalse(renderer1.equals(renderer2));
                                                                                                            renderer2.setGroupPaint(paint1);
                                                                                                            
                                                                                                            // Test groupStroke difference
                                                                                                            Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                            Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                            renderer1.setGroupStroke(stroke1);
                                                                                                            renderer2.setGroupStroke(stroke2);
                                                                                                            assertFalse(renderer1.equals(renderer2));
                                                                                                            renderer2.setGroupStroke(stroke1);
                                                                                                            
                                                                                                            // Should be equal again after resetting all fields
                                                                                                            assertTrue(renderer1.equals(renderer2));
                                                                                                        }

 @Test
                                                                                                       public void testEqualsWithSuperclassDifferences() {
                                                                                                           // This would require mocking or creating a subclass that overrides super.equals
                                                                                                           // Since we don't have access to the superclass implementation,
                                                                                                           // we can't fully test this part without more information
                                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                           
                                                                                                           // Assuming super.equals works correctly
                                                                                                           assertTrue(renderer1.equals(renderer2));
                                                                                                       }

 @Test
                                                                                                  public void testEquals17() {
                                                                                                      // Create two renderers with same values
                                                                                                      MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                      MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                      
                                                                                                      // Test reference equality
                                                                                                      assertTrue(renderer1.equals(renderer1));
                                                                                                      
                                                                                                      // Test equality with same values
                                                                                                      assertTrue(renderer1.equals(renderer2));
                                                                                                      
                                                                                                      // Test with null
                                                                                                      assertFalse(renderer1.equals(null));
                                                                                                      
                                                                                                      // Test with wrong type
                                                                                                      assertFalse(renderer1.equals(new Object()));
                                                                                                      
                                                                                                      // Test plotLines difference
                                                                                                      renderer2.setDrawLines(!renderer1.isDrawLines());
                                                                                                      assertFalse(renderer1.equals(renderer2));
                                                                                                      renderer2.setDrawLines(renderer1.isDrawLines()); // reset
                                                                                                      
                                                                                                      // Test groupPaint difference
                                                                                                      renderer2.setGroupPaint(Color.RED);
                                                                                                      assertFalse(renderer1.equals(renderer2));
                                                                                                      renderer2.setGroupPaint(renderer1.getGroupPaint()); // reset
                                                                                                      
                                                                                                      // Test groupStroke difference
                                                                                                      renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                      assertFalse(renderer1.equals(renderer2));
                                                                                                      renderer2.setGroupStroke(renderer1.getGroupStroke()); // reset
                                                                                                      
                                                                                                      // Since equals method doesn't consider icons, we can skip testing with icons
                                                                                                      // as it wouldn't affect the equality comparison
                                                                                                  }

 @Test
                                                                                              public void testEqualsWithNullGroupPaint3() {
                                                                                                  // Create two renderers with same values except groupPaint
                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                  
                                                                                                  // Set same values for other fields
                                                                                                  renderer1.setDrawLines(true);
                                                                                                  renderer2.setDrawLines(true);
                                                                                                  renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                  renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                  
                                                                                                  // Set one groupPaint to null, other to non-null
                                                                                                  renderer1.setGroupPaint(null);
                                                                                                  renderer2.setGroupPaint(Color.RED);
                                                                                                  
                                                                                                  // They should not be equal
                                                                                                  assertFalse(renderer1.equals(renderer2));
                                                                                              }

 @Test
                                                                                              public void testEqualsWithNullGroupStroke4() {
                                                                                                  // Create two renderers with same values except groupStroke
                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                  
                                                                                                  // Set same values for other fields
                                                                                                  renderer1.setDrawLines(true);
                                                                                                  renderer2.setDrawLines(true);
                                                                                                  renderer1.setGroupPaint(Color.BLUE);
                                                                                                  renderer2.setGroupPaint(Color.BLUE);
                                                                                                  
                                                                                                  // Set one groupStroke to null, other to non-null
                                                                                                  renderer1.setGroupStroke(null);
                                                                                                  renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                  
                                                                                                  // They should not be equal
                                                                                                  assertFalse(renderer1.equals(renderer2));
                                                                                              }

 @Test
                                                                                              public void testEqualsWithBothNullGroupPaint() {
                                                                                                  // Create two renderers with null groupPaint
                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                  
                                                                                                  // Set same values for other fields
                                                                                                  renderer1.setDrawLines(true);
                                                                                                  renderer2.setDrawLines(true);
                                                                                                  renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                  renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                  
                                                                                                  // Set both groupPaint to null
                                                                                                  renderer1.setGroupPaint(null);
                                                                                                  renderer2.setGroupPaint(null);
                                                                                                  
                                                                                                  // They should be equal
                                                                                                  assertTrue(renderer1.equals(renderer2));
                                                                                              }

 @Test
                                                                                              public void testEqualsWithBothNullGroupStroke() {
                                                                                                  // Create two renderers with null groupStroke
                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                  
                                                                                                  // Set same values for other fields
                                                                                                  renderer1.setDrawLines(true);
                                                                                                  renderer2.setDrawLines(true);
                                                                                                  renderer1.setGroupPaint(Color.BLUE);
                                                                                                  renderer2.setGroupPaint(Color.BLUE);
                                                                                                  
                                                                                                  // Set both groupStroke to null
                                                                                                  renderer1.setGroupStroke(null);
                                                                                                  renderer2.setGroupStroke(null);
                                                                                                  
                                                                                                  // They should be equal
                                                                                                  assertTrue(renderer1.equals(renderer2));
                                                                                              }

 @Test
                                                                                             public void testEqualsWithNullGroupPaint4() {
                                                                                                 // Create two renderers with same field values but null groupPaint
                                                                                                 MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                 MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                 
                                                                                                 // Set same values for other fields that are compared
                                                                                                 renderer1.setDrawLines(true);
                                                                                                 renderer2.setDrawLines(true);
                                                                                                 
                                                                                                 // Create a non-null stroke to ensure we reach groupPaint comparison
                                                                                                 Stroke testStroke = new BasicStroke(1.0f);
                                                                                                 renderer1.setGroupStroke(testStroke);
                                                                                                 renderer2.setGroupStroke(testStroke);
                                                                                                 
                                                                                                 // Set null groupPaint for both
                                                                                                 renderer1.setGroupPaint(null);
                                                                                                 renderer2.setGroupPaint(null);
                                                                                                 
                                                                                                 // Should return true since all fields including null groupPaint are equal
                                                                                                 assertTrue(renderer1.equals(renderer2));
                                                                                                 
                                                                                                 // Test with one null and one non-null groupPaint
                                                                                                 renderer2.setGroupPaint(Color.BLACK);
                                                                                                 assertFalse(renderer1.equals(renderer2));
                                                                                                 
                                                                                                 // Test with both having different non-null groupPaint
                                                                                                 renderer1.setGroupPaint(Color.RED);
                                                                                                 assertFalse(renderer1.equals(renderer2));
                                                                                             }

 @Test
                                                                                                public void testEquals_SameReference() {
                                                                                                    MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                    assertTrue(renderer.equals(renderer));
                                                                                                }

 @Test
                                                                                                public void testEquals_NullInput() {
                                                                                                    MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                    assertFalse(renderer.equals(null));
                                                                                                }

 @Test
                                                                                                public void testEquals_WrongType() {
                                                                                                    MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                    assertFalse(renderer.equals(new Object()));
                                                                                                }

 @Test
                                                                                                public void testEquals_EqualObjects3() {
                                                                                                    MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                    r1.setDrawLines(true);
                                                                                                    r1.setGroupPaint(Color.RED);
                                                                                                    r1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                    
                                                                                                    MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                    r2.setDrawLines(true);
                                                                                                    r2.setGroupPaint(Color.RED);
                                                                                                    r2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                    
                                                                                                    assertTrue(r1.equals(r2));
                                                                                                }

 @Test
                                                                                                public void testEquals_DifferentPlotLines4() {
                                                                                                    MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                    r1.setDrawLines(true);
                                                                                                    
                                                                                                    MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                    r2.setDrawLines(false);
                                                                                                    
                                                                                                    assertFalse(r1.equals(r2));
                                                                                                }

 @Test
                                                                                                public void testEquals_DifferentGroupPaint4() {
                                                                                                    MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                    r1.setGroupPaint(Color.RED);
                                                                                                    
                                                                                                    MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                    r2.setGroupPaint(Color.BLUE);
                                                                                                    
                                                                                                    assertFalse(r1.equals(r2));
                                                                                                }

 @Test
                                                                                                public void testEquals_DifferentGroupStroke4() {
                                                                                                    MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                                                                    r1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                    
                                                                                                    MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                                                                    r2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                    
                                                                                                    assertFalse(r1.equals(r2));
                                                                                                }

 @Test
                                                                                                public void testEquals_SuperClassDifference1() {
                                                                                                    // This would require mocking or creating a subclass where super.equals() returns false
                                                                                                    // Implementation would depend on the parent class behavior
                                                                                                }

 @Test
                                                                                               public void testEquals_SameInstance3() {
                                                                                                   MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                   assertTrue(renderer.equals(renderer));
                                                                                               }

 @Test
                                                                                               public void testEquals_Null2() {
                                                                                                   MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                   assertFalse(renderer.equals(null));
                                                                                               }

 @Test
                                                                                               public void testEquals_WrongClass() {
                                                                                                   MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                   assertFalse(renderer.equals("Not a renderer"));
                                                                                               }

 @Test
                                                                                               public void testEquals_EqualObjects4() {
                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                   renderer1.setDrawLines(true);
                                                                                                   renderer1.setGroupPaint(Color.RED);
                                                                                                   renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                           
                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                   renderer2.setDrawLines(true);
                                                                                                   renderer2.setGroupPaint(Color.RED);
                                                                                                   renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                           
                                                                                                   assertTrue(renderer1.equals(renderer2));
                                                                                               }

 @Test
                                                                                               public void testEquals_DifferentPlotLines5() {
                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                   renderer1.setDrawLines(true);
                                                                                           
                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                   renderer2.setDrawLines(false);
                                                                                           
                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                               }

 @Test
                                                                                               public void testEquals_DifferentGroupPaint5() {
                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                   renderer1.setGroupPaint(Color.RED);
                                                                                           
                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                   renderer2.setGroupPaint(Color.BLUE);
                                                                                           
                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                               }

 @Test
                                                                                               public void testEquals_DifferentGroupStroke5() {
                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                   renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                           
                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                   renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                           
                                                                                                   assertFalse(renderer1.equals(renderer2));
                                                                                               }

 @Test
                                                                                               public void testEquals_TransitiveProperty1() {
                                                                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                   renderer1.setDrawLines(true);
                                                                                                   renderer1.setGroupPaint(Color.RED);
                                                                                           
                                                                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                   renderer2.setDrawLines(true);
                                                                                                   renderer2.setGroupPaint(Color.RED);
                                                                                           
                                                                                                   MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                                   renderer3.setDrawLines(true);
                                                                                                   renderer3.setGroupPaint(Color.RED);
                                                                                           
                                                                                                   assertTrue(renderer1.equals(renderer2));
                                                                                                   assertTrue(renderer2.equals(renderer3));
                                                                                                   assertTrue(renderer1.equals(renderer3));
                                                                                               }

 @Test
                                                                                              public void testEquals_SameInstance4() {
                                                                                                  MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                  assertTrue(renderer.equals(renderer));
                                                                                              }

 @Test
                                                                                              public void testEquals_NullObject2() {
                                                                                                  MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                  assertFalse(renderer.equals(null));
                                                                                              }

 @Test
                                                                                              public void testEquals_WrongType1() {
                                                                                                  MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                                  assertFalse(renderer.equals("Not a renderer"));
                                                                                              }

 @Test
                                                                                              public void testEquals_DifferentPlotLines6() {
                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                  renderer1.setDrawLines(true);
                                                                                                  
                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                  renderer2.setDrawLines(false);
                                                                                                  
                                                                                                  assertFalse(renderer1.equals(renderer2));
                                                                                              }

 @Test
                                                                                              public void testEquals_DifferentGroupPaint6() {
                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                  renderer1.setGroupPaint(Color.RED);
                                                                                                  
                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                  renderer2.setGroupPaint(Color.BLUE);
                                                                                                  
                                                                                                  assertFalse(renderer1.equals(renderer2));
                                                                                              }

 @Test
                                                                                              public void testEquals_DifferentGroupStroke6() {
                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                  renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                  
                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                  renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                                  
                                                                                                  assertFalse(renderer1.equals(renderer2));
                                                                                              }

 @Test
                                                                                              public void testEquals_EqualObjects5() {
                                                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                  renderer1.setDrawLines(true);
                                                                                                  renderer1.setGroupPaint(Color.RED);
                                                                                                  renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                                  
                                                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                  renderer2.setDrawLines(true);
                                                                                                  renderer2.setGroupPaint(Color.RED);
                                                                                                  renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                                  
                                                                                                  assertTrue(renderer1.equals(renderer2));
                                                                                              }

 @Test
                                                                                             public void testEqualsWithDifferentPaintConfigurations() {
                                                                                                 // Create two renderers with different paint configurations
                                                                                                 MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                 MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                 
                                                                                                 // Set different group paints
                                                                                                 Paint paint1 = new Color(255, 0, 0);
                                                                                                 Paint paint2 = new Color(0, 255, 0);
                                                                                                 renderer1.setGroupPaint(paint1);
                                                                                                 renderer2.setGroupPaint(paint2);
                                                                                                 
                                                                                                 // Verify they're not equal due to different paints
                                                                                                 assertFalse(renderer1.equals(renderer2));
                                                                                                 
                                                                                                 // Now set same paints
                                                                                                 renderer2.setGroupPaint(paint1);
                                                                                                 
                                                                                                 // Create mock objects for testing
                                                                                                 Graphics2D g2 = mock(Graphics2D.class);
                                                                                                 CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                 Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                 CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                 CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                 ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                 CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                 
                                                                                                 // Test with row != column to catch the parameter swap mutation
                                                                                                 int row = 1;
                                                                                                 int column = 2;
                                                                                                 
                                                                                                 // Set up different paint returns for row,col vs col,row
                                                                                                 when(dataset.getRowCount()).thenReturn(3);
                                                                                                 when(dataset.getColumnCount()).thenReturn(3);
                                                                                                 when(renderer1.getItemPaint(row, column)).thenReturn(paint1);
                                                                                                 when(renderer1.getItemPaint(column, row)).thenReturn(paint2);
                                                                                                 
                                                                                                 // Draw items - this would reveal if parameters are swapped
                                                                                                 renderer1.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column, 0);
                                                                                                 
                                                                                                 // Verify the correct paint was used (should be paint1 for row,col)
                                                                                                 verify(g2).setPaint(paint1);
                                                                                                 
                                                                                                 // Now test equality again - should still be equal
                                                                                                 assertTrue(renderer1.equals(renderer2));
                                                                                             }

 @Test
                                                                                             public void testEqualsConsistency() {
                                                                                                 MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                                 MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                                 
                                                                                                 // Test basic equality
                                                                                                 assertTrue(renderer1.equals(renderer2));
                                                                                                 assertTrue(renderer1.equals(renderer1));
                                                                                                 
                                                                                                 // Test with null
                                                                                                 assertFalse(renderer1.equals(null));
                                                                                                 
                                                                                                 // Test with different class
                                                                                                 assertFalse(renderer1.equals(new Object()));
                                                                                                 
                                                                                                 // Modify plotLines and test
                                                                                                 renderer2.setDrawLines(!renderer1.isDrawLines());
                                                                                                 assertFalse(renderer1.equals(renderer2));
                                                                                                 renderer2.setDrawLines(renderer1.isDrawLines());
                                                                                                 assertTrue(renderer1.equals(renderer2));
                                                                                                 
                                                                                                 // Modify groupStroke and test
                                                                                                 Stroke stroke1 = new BasicStroke(1.0f);
                                                                                                 Stroke stroke2 = new BasicStroke(2.0f);
                                                                                                 renderer1.setGroupStroke(stroke1);
                                                                                                 renderer2.setGroupStroke(stroke2);
                                                                                                 assertFalse(renderer1.equals(renderer2));
                                                                                             }

 @Test
                                                                                        public void testDrawItemSetsCorrectPaint() {
                                                                                            // Setup test data
                                                                                            MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                            renderer.setGroupPaint(Color.RED); // Set a known paint
                                                                                            
                                                                                            // Mock dependencies
                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                            CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                            Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                            CategoryPlot plot = mock(CategoryPlot.class);
                                                                                            CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                            ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                            
                                                                                            // Configure mocks
                                                                                            when(dataset.getRowCount()).thenReturn(1);
                                                                                            when(dataset.getColumnCount()).thenReturn(1);
                                                                                            when(dataset.getValue(0, 0)).thenReturn(5.0);
                                                                                            
                                                                                            // Execute test
                                                                                            renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                                                                            
                                                                                            // Verify paint was set correctly (not null)
                                                                                            verify(g2).setPaint(any(Paint.class)); // This would fail if mutant sets paint to null
                                                                                            
                                                                                            // Additional verification - check it was set to group paint
                                                                                            verify(g2).setPaint(Color.RED);
                                                                                        }

 @Test
                                                                                       public void testEqualsWithDifferentGroupStroke3() {
                                                                                           // Create two renderers with same properties except groupStroke
                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                           
                                                                                           // Set same properties
                                                                                           renderer1.setDrawLines(true);
                                                                                           renderer2.setDrawLines(true);
                                                                                           renderer1.setGroupPaint(Color.RED);
                                                                                           renderer2.setGroupPaint(Color.RED);
                                                                                           
                                                                                           // Set different strokes
                                                                                           Stroke stroke1 = new BasicStroke(1.0f);
                                                                                           Stroke stroke2 = new BasicStroke(2.0f);
                                                                                           renderer1.setGroupStroke(stroke1);
                                                                                           renderer2.setGroupStroke(stroke2);
                                                                                           
                                                                                           // Verify they are not equal due to different strokes
                                                                                           assertFalse(renderer1.equals(renderer2));
                                                                                           
                                                                                           // Now set same stroke and verify equality
                                                                                           renderer2.setGroupStroke(stroke1);
                                                                                           assertTrue(renderer1.equals(renderer2));
                                                                                           
                                                                                           // Also test with null strokes
                                                                                           renderer1.setGroupStroke(null);
                                                                                           assertFalse(renderer1.equals(renderer2));
                                                                                           
                                                                                           renderer2.setGroupStroke(null);
                                                                                           assertTrue(renderer1.equals(renderer2));
                                                                                       }

 @Test
                                                                                      public void testDrawItemUsesCorrectStrokeParameters() {
                                                                                          // Setup
                                                                                          MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                          Graphics2D g2 = mock(Graphics2D.class);
                                                                                          CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                          Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                          CategoryPlot plot = mock(CategoryPlot.class);
                                                                                          CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                          ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                          CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                          
                                                                                          // Create two distinct strokes
                                                                                          Stroke row1col2Stroke = new BasicStroke(1.0f);
                                                                                          Stroke row2col1Stroke = new BasicStroke(2.0f);
                                                                                          
                                                                                          // Mock getItemStroke to return different strokes based on parameters
                                                                                          when(renderer.getItemStroke(1, 2)).thenReturn(row1col2Stroke);
                                                                                          when(renderer.getItemStroke(2, 1)).thenReturn(row2col1Stroke);
                                                                                          
                                                                                          // Test case where row=1, column=2
                                                                                          renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 2, 0);
                                                                                          
                                                                                          // Verify the correct stroke was set (should be row1col2Stroke)
                                                                                          verify(g2).setStroke(row1col2Stroke);
                                                                                          
                                                                                          // Test case where row=2, column=1
                                                                                          renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 2, 1, 0);
                                                                                          
                                                                                          // Verify the correct stroke was set (should be row2col1Stroke)
                                                                                          verify(g2).setStroke(row2col1Stroke);
                                                                                      }

 @Test
                                                                                     public void testEqualsWithDifferentIconDimensions() {
                                                                                         // Create two identical renderers
                                                                                         MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                         MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                         
                                                                                         // Set identical properties
                                                                                         renderer1.setDrawLines(true);
                                                                                         renderer2.setDrawLines(true);
                                                                                         
                                                                                         Paint testPaint = Color.RED;
                                                                                         Stroke testStroke = new BasicStroke(1.0f);
                                                                                         renderer1.setGroupPaint(testPaint);
                                                                                         renderer2.setGroupPaint(testPaint);
                                                                                         renderer1.setGroupStroke(testStroke);
                                                                                         renderer2.setGroupStroke(testStroke);
                                                                                         
                                                                                         // Mock necessary objects for drawItem call
                                                                                         Graphics2D g2 = mock(Graphics2D.class);
                                                                                         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                         CategoryPlot plot = mock(CategoryPlot.class);
                                                                                         CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                         ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                         CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                         
                                                                                         // Trigger icon creation (which will be affected by the mutation)
                                                                                         renderer1.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                                                                         renderer2.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                                                                         
                                                                                         // The mutation would cause different icon dimensions, making the renderers unequal
                                                                                         assertFalse("Renderers with different icon dimensions should not be equal", 
                                                                                                     renderer1.equals(renderer2));
                                                                                     }

 @Test
                                                                                    public void testEqualsAfterDrawItem() {
                                                                                        // Create two identical renderers
                                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                        
                                                                                        // Set identical properties
                                                                                        renderer1.setDrawLines(true);
                                                                                        renderer2.setDrawLines(true);
                                                                                        Paint paint = Color.RED;
                                                                                        renderer1.setGroupPaint(paint);
                                                                                        renderer2.setGroupPaint(paint);
                                                                                        Stroke stroke = new BasicStroke(1.0f);
                                                                                        renderer1.setGroupStroke(stroke);
                                                                                        renderer2.setGroupStroke(stroke);
                                                                                        
                                                                                        // Verify they are equal initially
                                                                                        assertTrue(renderer1.equals(renderer2));
                                                                                        
                                                                                        // Mock necessary objects for drawItem
                                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                                        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                                                        CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                        ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                        
                                                                                        // Call drawItem with same parameters on both renderers
                                                                                        renderer1.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                                                                        renderer2.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                                                                        
                                                                                        // Verify they remain equal (original behavior)
                                                                                        // The mutant would make them unequal due to different shape positions
                                                                                        assertTrue("Renderers should remain equal after identical draw operations", 
                                                                                                   renderer1.equals(renderer2));
                                                                                    }

 @Test
                                                                                       public void testEqualsWithSameObject2() {
                                                                                           MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                           assertTrue(renderer.equals(renderer));
                                                                                       }

 @Test
                                                                                       public void testEqualsWithDifferentClass2() {
                                                                                           MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                           assertFalse(renderer.equals(new Object()));
                                                                                       }

 @Test
                                                                                       public void testEqualsWithDifferentPlotLines4() {
                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                           renderer1.setDrawLines(true);
                                                                                           renderer2.setDrawLines(false);
                                                                                           assertFalse(renderer1.equals(renderer2));
                                                                                       }

 @Test
                                                                                       public void testEqualsWithDifferentGroupPaint2() {
                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                           renderer1.setGroupPaint(Color.RED);
                                                                                           renderer2.setGroupPaint(Color.BLUE);
                                                                                           assertFalse(renderer1.equals(renderer2));
                                                                                       }

 @Test
                                                                                       public void testEqualsWithDifferentGroupStroke4() {
                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                           renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                           renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                           assertFalse(renderer1.equals(renderer2));
                                                                                       }

 @Test
                                                                                       public void testEqualsWithEqualObjects() {
                                                                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                           renderer1.setDrawLines(true);
                                                                                           renderer2.setDrawLines(true);
                                                                                           renderer1.setGroupPaint(Color.RED);
                                                                                           renderer2.setGroupPaint(Color.RED);
                                                                                           renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                           renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                                                           assertTrue(renderer1.equals(renderer2));
                                                                                       }

 @Test
                                                                             public void testDrawItemWithDifferentOrientations() {
                                                                                 // Setup
                                                                                 MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                 MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                 
                                                                                 // Create mock objects
                                                                                 Graphics2D g2 = mock(Graphics2D.class);
                                                                                 CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                 Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                 CategoryPlot plot1 = mock(CategoryPlot.class);
                                                                                 CategoryPlot plot2 = mock(CategoryPlot.class);
                                                                                 CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                 ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                 CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                 
                                                                                 // Set different orientations for the plots
                                                                                 when(plot1.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
                                                                                 when(plot2.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
                                                                                 
                                                                                 // Create a spy to capture drawing behavior
                                                                                 MinMaxCategoryRenderer spyRenderer = spy(renderer1);
                                                                                 
                                                                                 // Test with horizontal orientation
                                                                                 spyRenderer.drawItem(g2, state, dataArea, plot1, domainAxis, rangeAxis, 
                                                                                                    dataset, 0, 0, 0);
                                                                                 
                                                                                 // Verify horizontal orientation behavior by checking public method calls
                                                                                 verify(g2, atLeastOnce()).setPaint(any(Paint.class));
                                                                                 verify(g2, atLeastOnce()).setStroke(any(Stroke.class));
                                                                                 
                                                                                 // Test with vertical orientation
                                                                                 spyRenderer.drawItem(g2, state, dataArea, plot2, domainAxis, rangeAxis, 
                                                                                                    dataset, 0, 0, 0);
                                                                                 
                                                                                 // Verify vertical orientation behavior by checking public method calls
                                                                                 verify(g2, atLeast(2)).setPaint(any(Paint.class));
                                                                                 verify(g2, atLeast(2)).setStroke(any(Stroke.class));
                                                                                 
                                                                                 // Additional verification that different orientations were handled
                                                                                 verify(plot1).getOrientation();
                                                                                 verify(plot2).getOrientation();
                                                                             }

 @Test
                                                                         public void testEqualsWithDifferentOrientations() {
                                                                             // Create two renderers with identical properties
                                                                             MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                             MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                             
                                                                             // Set identical properties
                                                                             renderer1.setDrawLines(true);
                                                                             renderer2.setDrawLines(true);
                                                                             
                                                                             Paint testPaint = Color.RED;
                                                                             Stroke testStroke = new BasicStroke(1.0f);
                                                                             renderer1.setGroupPaint(testPaint);
                                                                             renderer2.setGroupPaint(testPaint);
                                                                             renderer1.setGroupStroke(testStroke);
                                                                             renderer2.setGroupStroke(testStroke);
                                                                             
                                                                             // Mock the plot objects with different orientations
                                                                             CategoryPlot plot1 = mock(CategoryPlot.class);
                                                                             CategoryPlot plot2 = mock(CategoryPlot.class);
                                                                             when(plot1.getOrientation()).thenReturn(PlotOrientation.VERTICAL);
                                                                             when(plot2.getOrientation()).thenReturn(PlotOrientation.HORIZONTAL);
                                                                             
                                                                             // Set the plots to the renderers (assuming this affects orientation)
                                                                             // Note: This part depends on how orientation is actually used in the class
                                                                             // Since the actual implementation isn't shown, we need to test the equals behavior
                                                                             
                                                                             // The original equals should return true since all fields match
                                                                             // The mutated version would return false due to orientation difference
                                                                             assertTrue("Renderers with different orientations should be considered equal", 
                                                                                        renderer1.equals(renderer2));
                                                                             
                                                                             // Additional check for symmetry
                                                                             assertTrue("Equals should be symmetric", renderer2.equals(renderer1));
                                                                         }

 @Test
                                                                            public void testEquals_SameInstance5() {
                                                                                MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                assertTrue(renderer.equals(renderer));
                                                                            }

 @Test
                                                                            public void testEquals_Null3() {
                                                                                MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                assertFalse(renderer.equals(null));
                                                                            }

 @Test
                                                                            public void testEquals_DifferentClass3() {
                                                                                MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                                assertFalse(renderer.equals(new Object()));
                                                                            }

 @Test
                                                                            public void testEquals_EqualObjects6() {
                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                assertTrue(renderer1.equals(renderer2));
                                                                            }

 @Test
                                                                            public void testEquals_DifferentPlotLines7() {
                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                renderer1.setDrawLines(true);
                                                                                renderer2.setDrawLines(false);
                                                                                assertFalse(renderer1.equals(renderer2));
                                                                            }

 @Test
                                                                            public void testEquals_DifferentGroupPaint7() {
                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                renderer1.setGroupPaint(Color.RED);
                                                                                renderer2.setGroupPaint(Color.BLUE);
                                                                                assertFalse(renderer1.equals(renderer2));
                                                                            }

 @Test
                                                                            public void testEquals_DifferentGroupStroke7() {
                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                                                renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                                                assertFalse(renderer1.equals(renderer2));
                                                                            }

 @Test
                                                                            public void testEquals_Symmetry() {
                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                assertEquals(renderer1.equals(renderer2), renderer2.equals(renderer1));
                                                                            }

 @Test
                                                                            public void testEquals_Transitivity() {
                                                                                MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                                MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                                MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                                
                                                                                assertTrue(renderer1.equals(renderer2));
                                                                                assertTrue(renderer2.equals(renderer3));
                                                                                assertTrue(renderer1.equals(renderer3));
                                                                            }

 @Test
                                                                           public void testEquals18() {
                                                                               // Create test objects
                                                                               MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                               MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                               MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                               
                                                                               // Set different properties for renderer3
                                                                               renderer3.setDrawLines(!renderer1.isDrawLines());
                                                                               renderer3.setGroupPaint(Color.RED);
                                                                               renderer3.setGroupStroke(new BasicStroke(2.0f));
                                                                               
                                                                               // Test identity
                                                                               assertTrue(renderer1.equals(renderer1));
                                                                               
                                                                               // Test null
                                                                               assertFalse(renderer1.equals(null));
                                                                               
                                                                               // Test wrong type
                                                                               assertFalse(renderer1.equals("Not a renderer"));
                                                                               
                                                                               // Test equal objects
                                                                               assertTrue(renderer1.equals(renderer2));
                                                                               assertEquals(renderer1.hashCode(), renderer2.hashCode());
                                                                               
                                                                               // Test unequal objects - plotLines
                                                                               renderer2.setDrawLines(!renderer1.isDrawLines());
                                                                               assertFalse(renderer1.equals(renderer2));
                                                                               renderer2.setDrawLines(renderer1.isDrawLines());
                                                                               
                                                                               // Test unequal objects - groupPaint
                                                                               renderer2.setGroupPaint(Color.BLUE);
                                                                               assertFalse(renderer1.equals(renderer2));
                                                                               renderer2.setGroupPaint(renderer1.getGroupPaint());
                                                                               
                                                                               // Test unequal objects - groupStroke
                                                                               renderer2.setGroupStroke(new BasicStroke(1.5f));
                                                                               assertFalse(renderer1.equals(renderer2));
                                                                               
                                                                               // Test with completely different object
                                                                               assertFalse(renderer1.equals(renderer3));
                                                                           }

 @Test
                                                                      public void testEquals19() {
                                                                          // Create test objects
                                                                          MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                          MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                          MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                          
                                                                          // Test reflexivity
                                                                          assertTrue(renderer1.equals(renderer1));
                                                                          
                                                                          // Test symmetry with equal objects
                                                                          assertTrue(renderer1.equals(renderer2));
                                                                          assertTrue(renderer2.equals(renderer1));
                                                                          
                                                                          // Test with null
                                                                          assertFalse(renderer1.equals(null));
                                                                          
                                                                          // Test with different type
                                                                          assertFalse(renderer1.equals(new Object()));
                                                                          
                                                                          // Test transitivity
                                                                          assertTrue(renderer1.equals(renderer2));
                                                                          assertTrue(renderer2.equals(renderer3));
                                                                          assertTrue(renderer1.equals(renderer3));
                                                                          
                                                                          // Modify fields and test inequality
                                                                          renderer2.setDrawLines(!renderer1.isDrawLines());
                                                                          assertFalse(renderer1.equals(renderer2));
                                                                          
                                                                          // Reset and test another field
                                                                          renderer2.setDrawLines(renderer1.isDrawLines());
                                                                          renderer2.setGroupPaint(Color.RED);
                                                                          assertFalse(renderer1.equals(renderer2));
                                                                          
                                                                          // Reset and test stroke
                                                                          renderer2.setGroupPaint(renderer1.getGroupPaint());
                                                                          Stroke differentStroke = new BasicStroke(2.0f);
                                                                          renderer2.setGroupStroke(differentStroke);
                                                                          assertFalse(renderer1.equals(renderer2));
                                                                          
                                                                          // Test with all fields equal
                                                                          renderer2.setGroupStroke(renderer1.getGroupStroke());
                                                                          assertTrue(renderer1.equals(renderer2));
                                                                          
                                                                          // Test with different icons (should not affect equality)
                                                                          renderer2.setObjectIcon(new Icon() {
                                                                              public void paintIcon(Component c, Graphics g, int x, int y) {}
                                                                              public int getIconWidth() { return 0; }
                                                                              public int getIconHeight() { return 0; }
                                                                          });
                                                                          assertTrue(renderer1.equals(renderer2)); // Icons shouldn't affect equality
                                                                      }

 @Test
                                                                    public void testDrawItemCategoryChangeBehavior() throws Exception {
                                                                        // Setup
                                                                        MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                        MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                        
                                                                        // Use reflection to set different lastCategory values
                                                                        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
                                                                        lastCategoryField.setAccessible(true);
                                                                        lastCategoryField.setInt(renderer1, 1);
                                                                        lastCategoryField.setInt(renderer2, 2);
                                                                        
                                                                        // Mock dependencies
                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                        Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                                        CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                        ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                                                        
                                                                        // Test case 1: Same category (should not redraw in original)
                                                                        lastCategoryField.setInt(renderer1, 5);
                                                                        renderer1.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 5, 0);
                                                                        // Verify no drawing operations occurred (original behavior)
                                                                        verify(g2, never()).setPaint(any());
                                                                        verify(g2, never()).setStroke(any());
                                                                        
                                                                        // Test case 2: Different category (should redraw in original)
                                                                        lastCategoryField.setInt(renderer2, 5);
                                                                        renderer2.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 6, 0);
                                                                        // Verify drawing operations occurred (original behavior)
                                                                        verify(g2, atLeastOnce()).setPaint(any());
                                                                        verify(g2, atLeastOnce()).setStroke(any());
                                                                        
                                                                        // Test case 3: Edge case - first draw (lastCategory not set)
                                                                        MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                        renderer3.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                                                        // Should perform drawing operations
                                                                        verify(g2, atLeastOnce()).setPaint(any());
                                                                        verify(g2, atLeastOnce()).setStroke(any());
                                                                    }

 @Test
                                                                public void testEqualsWithDifferentLastCategory() {
                                                                    // Create two renderers with identical properties except lastCategory
                                                                    MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                    MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                    
                                                                    // Set all visible properties to be equal
                                                                    renderer1.setDrawLines(true);
                                                                    renderer2.setDrawLines(true);
                                                                    
                                                                    // Mock paint and stroke to return equal objects
                                                                    Paint mockPaint = mock(Paint.class);
                                                                    Stroke mockStroke = mock(Stroke.class);
                                                                    renderer1.setGroupPaint(mockPaint);
                                                                    renderer2.setGroupPaint(mockPaint);
                                                                    renderer1.setGroupStroke(mockStroke);
                                                                    renderer2.setGroupStroke(mockStroke);
                                                                    
                                                                    // Set different lastCategory values
                                                                    // Reflection needed since lastCategory is private
                                                                    try {
                                                                        Field lastCategoryField = MinMaxCategoryRenderer.class.getDeclaredField("lastCategory");
                                                                        lastCategoryField.setAccessible(true);
                                                                        lastCategoryField.set(renderer1, 1);
                                                                        lastCategoryField.set(renderer2, 2);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set lastCategory field via reflection");
                                                                    }
                                                                    
                                                                    // The objects should not be equal because lastCategory differs
                                                                    assertFalse(renderer1.equals(renderer2));
                                                                    
                                                                    // Verify symmetric property
                                                                    assertFalse(renderer2.equals(renderer1));
                                                                    
                                                                    // Verify reflexive property
                                                                    assertTrue(renderer1.equals(renderer1));
                                                                    assertTrue(renderer2.equals(renderer2));
                                                                }

 @Test
                                                              public void testEqualsWithSameMinValues() {
                                                                  // Create two renderers with identical properties
                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                  
                                                                  // Set identical properties
                                                                  renderer1.setDrawLines(true);
                                                                  renderer2.setDrawLines(true);
                                                                  
                                                                  Paint testPaint = Color.RED;
                                                                  Stroke testStroke = new BasicStroke(1.0f);
                                                                  
                                                                  renderer1.setGroupPaint(testPaint);
                                                                  renderer2.setGroupPaint(testPaint);
                                                                  
                                                                  renderer1.setGroupStroke(testStroke);
                                                                  renderer2.setGroupStroke(testStroke);
                                                                  
                                                                  try {
                                                                      // Use reflection to set private min and max fields
                                                                      Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                                                      minField.setAccessible(true);
                                                                      Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                                      maxField.setAccessible(true);
                                                                      
                                                                      // Set min values to be equal
                                                                      minField.setDouble(renderer1, 5.0);
                                                                      minField.setDouble(renderer2, 5.0);
                                                                      
                                                                      // Set max values to be equal
                                                                      maxField.setDouble(renderer1, 10.0);
                                                                      maxField.setDouble(renderer2, 10.0);
                                                                      
                                                                      // Test equality - should be true
                                                                      assertTrue(renderer1.equals(renderer2));
                                                                      assertTrue(renderer2.equals(renderer1));
                                                                      
                                                                      // Test reflexivity
                                                                      assertTrue(renderer1.equals(renderer1));
                                                                      
                                                                      // Test with null
                                                                      assertFalse(renderer1.equals(null));
                                                                      
                                                                      // Test with different class
                                                                      assertFalse(renderer1.equals(new Object()));
                                                                      
                                                                      // Test with different min value (to ensure min comparison works)
                                                                      minField.setDouble(renderer2, 5.1);
                                                                      assertFalse(renderer1.equals(renderer2));
                                                                  } catch (Exception e) {
                                                                      fail("Reflection failed: " + e.getMessage());
                                                                  }
                                                              }

 @Test
                                                              public void testEqualsReflexive() {
                                                                  MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                  renderer.setDrawLines(true);
                                                                  renderer.setGroupPaint(Color.RED);
                                                                  renderer.setGroupStroke(new BasicStroke(1.0f));
                                                                  
                                                                  assertTrue(renderer.equals(renderer));
                                                              }

 @Test
                                                              public void testEqualsNull() {
                                                                  MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                  assertFalse(renderer.equals(null));
                                                              }

 @Test
                                                              public void testEqualsDifferentType() {
                                                                  MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                                                  assertFalse(renderer.equals("Not a renderer"));
                                                              }

 @Test
                                                              public void testEqualsSameValues() {
                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                  renderer1.setDrawLines(true);
                                                                  renderer1.setGroupPaint(Color.BLUE);
                                                                  renderer1.setGroupStroke(new BasicStroke(2.0f));
                                                          
                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                  renderer2.setDrawLines(true);
                                                                  renderer2.setGroupPaint(Color.BLUE);
                                                                  renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                          
                                                                  assertTrue(renderer1.equals(renderer2));
                                                                  assertTrue(renderer2.equals(renderer1)); // Test symmetry
                                                              }

 @Test
                                                              public void testEqualsDifferentPlotLines() {
                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                  renderer1.setDrawLines(true);
                                                          
                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                  renderer2.setDrawLines(false);
                                                          
                                                                  assertFalse(renderer1.equals(renderer2));
                                                              }

 @Test
                                                              public void testEqualsDifferentGroupPaint() {
                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                  renderer1.setGroupPaint(Color.RED);
                                                          
                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                  renderer2.setGroupPaint(Color.GREEN);
                                                          
                                                                  assertFalse(renderer1.equals(renderer2));
                                                              }

 @Test
                                                              public void testEqualsDifferentGroupStroke() {
                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                  renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                          
                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                  renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                          
                                                                  assertFalse(renderer1.equals(renderer2));
                                                              }

 @Test
                                                              public void testEqualsTransitive() {
                                                                  MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                                  renderer1.setDrawLines(false);
                                                                  renderer1.setGroupPaint(Color.BLACK);
                                                                  renderer1.setGroupStroke(new BasicStroke(1.5f));
                                                          
                                                                  MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                                  renderer2.setDrawLines(false);
                                                                  renderer2.setGroupPaint(Color.BLACK);
                                                                  renderer2.setGroupStroke(new BasicStroke(1.5f));
                                                          
                                                                  MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                                  renderer3.setDrawLines(false);
                                                                  renderer3.setGroupPaint(Color.BLACK);
                                                                  renderer3.setGroupStroke(new BasicStroke(1.5f));
                                                          
                                                                  assertTrue(renderer1.equals(renderer2));
                                                                  assertTrue(renderer2.equals(renderer3));
                                                                  assertTrue(renderer1.equals(renderer3));
                                                              }

 @Test
                                                        public void testMinValuePrecisionAffectsEquality() throws Exception {
                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                            
                                                            // Use a value that would show precision difference between float and double
                                                            double testValue = 0.1234567890123456789;
                                                            
                                                            // Use reflection to set private min field
                                                            Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                                            minField.setAccessible(true);
                                                            
                                                            // Simulate original behavior (doubleValue)
                                                            minField.set(renderer1, testValue);
                                                            
                                                            // Simulate mutated behavior (floatValue)
                                                            minField.set(renderer2, (float)testValue);
                                                            
                                                            // Set all other fields equal using public setters
                                                            renderer1.setDrawLines(true);
                                                            renderer2.setDrawLines(true);
                                                            renderer1.setGroupPaint(Color.RED);
                                                            renderer2.setGroupPaint(Color.RED);
                                                            renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                            renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                            
                                                            // The objects should NOT be equal due to min precision difference
                                                            assertFalse(renderer1.equals(renderer2));
                                                            
                                                            // Set min values exactly equal
                                                            minField.set(renderer2, testValue);
                                                            assertTrue(renderer1.equals(renderer2));
                                                        }

 @Test
                                                        public void testEqualsWithDifferentPlotLines5() {
                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                            
                                                            renderer1.setDrawLines(true);
                                                            renderer2.setDrawLines(false);
                                                            
                                                            assertFalse(renderer1.equals(renderer2));
                                                        }

 @Test
                                                        public void testEqualsWithDifferentGroupPaint3() {
                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                            
                                                            renderer1.setGroupPaint(Color.RED);
                                                            renderer2.setGroupPaint(Color.BLUE);
                                                            
                                                            assertFalse(renderer1.equals(renderer2));
                                                        }

 @Test
                                                        public void testEqualsWithDifferentGroupStroke5() {
                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                            
                                                            renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                            renderer2.setGroupStroke(new BasicStroke(2.0f));
                                                            
                                                            assertFalse(renderer1.equals(renderer2));
                                                        }

 @Test
                                                        public void testEqualsWithSameFields() {
                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                            
                                                            renderer1.setDrawLines(true);
                                                            renderer2.setDrawLines(true);
                                                            renderer1.setGroupPaint(Color.RED);
                                                            renderer2.setGroupPaint(Color.RED);
                                                            renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                            renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                            
                                                            assertTrue(renderer1.equals(renderer2));
                                                        }

 @Test
                                                        public void testEqualsWithDecimalMinValue() {
                                                            // Create two renderers with identical properties except min value
                                                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                            
                                                            // Set identical properties
                                                            renderer1.setDrawLines(true);
                                                            renderer2.setDrawLines(true);
                                                            renderer1.setGroupPaint(Color.RED);
                                                            renderer2.setGroupPaint(Color.RED);
                                                            renderer1.setGroupStroke(new BasicStroke(1.0f));
                                                            renderer2.setGroupStroke(new BasicStroke(1.0f));
                                                            
                                                            // Set min values that would differ between doubleValue() and intValue()
                                                            // Using reflection since there's no direct setter for min field
                                                            try {
                                                                java.lang.reflect.Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                                                minField.setAccessible(true);
                                                                minField.set(renderer1, 1.5);  // original would store 1.5
                                                                minField.set(renderer2, 1.0);  // mutated would store 1 (from 1.5)
                                                            } catch (Exception e) {
                                                                fail("Failed to set min field via reflection");
                                                            }
                                                            
                                                            // The objects should be equal in original code (super.equals() would compare min values)
                                                            // But with mutation, they would be different (1.5 vs 1)
                                                            assertFalse("Mutation not detected - objects considered equal despite different min values", 
                                                                       renderer1.equals(renderer2));
                                                        }

 @Test
                                                       public void testEquals20() {
                                                           // Create two identical renderers
                                                           MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                           MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                           
                                                           // Test identity
                                                           assertTrue(r1.equals(r1));
                                                           
                                                           // Test equality of default instances
                                                           assertTrue(r1.equals(r2));
                                                           
                                                           // Test with different plotLines
                                                           r1.setDrawLines(true);
                                                           assertFalse(r1.equals(r2));
                                                           r2.setDrawLines(true);
                                                           assertTrue(r1.equals(r2));
                                                           
                                                           // Test with different groupPaint
                                                           r1.setGroupPaint(Color.RED);
                                                           assertFalse(r1.equals(r2));
                                                           r2.setGroupPaint(Color.RED);
                                                           assertTrue(r1.equals(r2));
                                                           
                                                           // Test with different groupStroke
                                                           Stroke s1 = new BasicStroke(1.0f);
                                                           Stroke s2 = new BasicStroke(2.0f);
                                                           r1.setGroupStroke(s1);
                                                           assertFalse(r1.equals(r2));
                                                           r2.setGroupStroke(s1);
                                                           assertTrue(r1.equals(r2));
                                                           
                                                           // Test with different types
                                                           assertFalse(r1.equals("Not a renderer"));
                                                           
                                                           // Test null case
                                                           assertFalse(r1.equals(null));
                                                       }

 @Test
                                                  public void testEqualsWithDifferentMaxValues() {
                                                      // Create first renderer with max = 10.0
                                                      MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                      renderer1.setDrawLines(true);
                                                      
                                                      // Create second renderer identical to first except max value
                                                      MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                      renderer2.setDrawLines(true);
                                                      
                                                      // Use reflection to set different max values since there's no setter
                                                      try {
                                                          Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                          maxField.setAccessible(true);
                                                          
                                                          // Case 1: renderer1.max > renderer2.max
                                                          maxField.set(renderer1, 10.0);
                                                          maxField.set(renderer2, 5.0);
                                                          assertFalse("Renderers with different max values should not be equal", 
                                                                     renderer1.equals(renderer2));
                                                          
                                                          // Case 2: renderer1.max < renderer2.max
                                                          maxField.set(renderer1, 5.0);
                                                          maxField.set(renderer2, 10.0);
                                                          assertFalse("Renderers with different max values should not be equal", 
                                                                     renderer1.equals(renderer2));
                                                      } catch (Exception e) {
                                                          fail("Failed to set max field via reflection: " + e.getMessage());
                                                      }
                                                      
                                                      // Also test equal max values
                                                      try {
                                                          Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                          maxField.setAccessible(true);
                                                          maxField.set(renderer1, 10.0);
                                                          maxField.set(renderer2, 10.0);
                                                          
                                                          // Need to set all other fields equal for proper test
                                                          Field plotLinesField = MinMaxCategoryRenderer.class.getDeclaredField("plotLines");
                                                          plotLinesField.setAccessible(true);
                                                          plotLinesField.set(renderer1, true);
                                                          plotLinesField.set(renderer2, true);
                                                          
                                                          // Mock equal paints and strokes
                                                          Paint mockPaint = mock(Paint.class);
                                                          Stroke mockStroke = mock(Stroke.class);
                                                          
                                                          Field groupPaintField = MinMaxCategoryRenderer.class.getDeclaredField("groupPaint");
                                                          groupPaintField.setAccessible(true);
                                                          groupPaintField.set(renderer1, mockPaint);
                                                          groupPaintField.set(renderer2, mockPaint);
                                                          
                                                          Field groupStrokeField = MinMaxCategoryRenderer.class.getDeclaredField("groupStroke");
                                                          groupStrokeField.setAccessible(true);
                                                          groupStrokeField.set(renderer1, mockStroke);
                                                          groupStrokeField.set(renderer2, mockStroke);
                                                          
                                                          when(mockStroke.equals(mockStroke)).thenReturn(true);
                                                          
                                                          assertTrue("Renderers with equal fields including max should be equal",
                                                                   renderer1.equals(renderer2));
                                                      } catch (Exception e) {
                                                          fail("Failed to set up equal test case: " + e.getMessage());
                                                      }
                                                  }

 @Test
                                                     public void testEquals21() {
                                                         // Create sample objects for testing
                                                         MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                         MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                         MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                                         
                                                         // Test reflexive property
                                                         assertTrue(renderer1.equals(renderer1));
                                                         
                                                         // Test symmetric property
                                                         assertTrue(renderer1.equals(renderer2));
                                                         assertTrue(renderer2.equals(renderer1));
                                                         
                                                         // Test transitive property
                                                         assertTrue(renderer1.equals(renderer2));
                                                         assertTrue(renderer2.equals(renderer3));
                                                         assertTrue(renderer1.equals(renderer3));
                                                         
                                                         // Test with null
                                                         assertFalse(renderer1.equals(null));
                                                         
                                                         // Test with different class
                                                         assertFalse(renderer1.equals(new Object()));
                                                         
                                                         // Test plotLines difference
                                                         renderer2.setDrawLines(!renderer1.isDrawLines());
                                                         assertFalse(renderer1.equals(renderer2));
                                                         renderer2.setDrawLines(renderer1.isDrawLines());
                                                         
                                                         // Test groupPaint difference
                                                         renderer2.setGroupPaint(Color.RED);
                                                         assertFalse(renderer1.equals(renderer2));
                                                         renderer2.setGroupPaint(renderer1.getGroupPaint());
                                                         
                                                         // Test groupStroke difference
                                                         Stroke differentStroke = new BasicStroke(2.0f);
                                                         renderer2.setGroupStroke(differentStroke);
                                                         assertFalse(renderer1.equals(renderer2));
                                                         
                                                         // Test with all fields equal should return true
                                                         renderer2.setGroupStroke(renderer1.getGroupStroke());
                                                         assertTrue(renderer1.equals(renderer2));
                                                     }

 @Test
                                               public void testEqualsWithDecimalMaxValues() {
                                                   // Create first renderer with decimal max value
                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                   renderer1.setMaxIcon(null); // Ensure other fields are equal
                                                   renderer1.setMinIcon(null);
                                                   renderer1.setGroupPaint(Color.RED);
                                                   renderer1.setGroupStroke(new BasicStroke());
                                                   renderer1.setDrawLines(true);
                                                   
                                                   // Use reflection to set decimal max value since there's no setter
                                                   try {
                                                       Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                       maxField.setAccessible(true);
                                                       maxField.setDouble(renderer1, 123.456);
                                                   } catch (Exception e) {
                                                       fail("Failed to set max field via reflection");
                                                   }
                                                
                                                   // Create second identical renderer
                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                   renderer2.setMaxIcon(null);
                                                   renderer2.setMinIcon(null);
                                                   renderer2.setGroupPaint(Color.RED);
                                                   renderer2.setGroupStroke(new BasicStroke());
                                                   renderer2.setDrawLines(true);
                                                   
                                                   // Set max value that would be different if truncated to int
                                                   try {
                                                       Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                       maxField.setAccessible(true);
                                                       maxField.setDouble(renderer2, 123.0); // Different from 123.456
                                                   } catch (Exception e) {
                                                       fail("Failed to set max field via reflection");
                                                   }
                                                
                                                   // Test equality - should be false due to different max values
                                                   assertFalse(renderer1.equals(renderer2));
                                                   
                                                   // Test symmetry
                                                   assertFalse(renderer2.equals(renderer1));
                                                   
                                                   // Test with same decimal values
                                                   try {
                                                       Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                                       maxField.setAccessible(true);
                                                       maxField.setDouble(renderer2, 123.456);
                                                   } catch (Exception e) {
                                                       fail("Failed to set max field via reflection");
                                                   }
                                                   assertTrue(renderer1.equals(renderer2));
                                               }

 @Test
                                               public void testEquals22() {
                                                   // Create test objects
                                                   MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                                   MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                                   
                                                   // Test reference equality
                                                   assertTrue(renderer1.equals(renderer1));
                                                   
                                                   // Test with null
                                                   assertFalse(renderer1.equals(null));
                                                   
                                                   // Test with different type
                                                   assertFalse(renderer1.equals("Not a renderer"));
                                                   
                                                   // Test with equal objects
                                                   assertTrue(renderer1.equals(renderer2));
                                                   
                                                   // Test plotLines difference
                                                   renderer1.setDrawLines(true);
                                                   renderer2.setDrawLines(false);
                                                   assertFalse(renderer1.equals(renderer2));
                                                   renderer2.setDrawLines(true);
                                                   assertTrue(renderer1.equals(renderer2));
                                                   
                                                   // Test groupPaint difference
                                                   Paint paint1 = mock(Paint.class);
                                                   Paint paint2 = mock(Paint.class);
                                                   renderer1.setGroupPaint(paint1);
                                                   renderer2.setGroupPaint(paint2);
                                                   // Mock PaintUtilities.equal() to return false
                                                   when(PaintUtilities.equal(paint1, paint2)).thenReturn(false);
                                                   assertFalse(renderer1.equals(renderer2));
                                                   // Mock PaintUtilities.equal() to return true
                                                   when(PaintUtilities.equal(paint1, paint2)).thenReturn(true);
                                                   assertTrue(renderer1.equals(renderer2));
                                                   
                                                   // Test groupStroke difference
                                                   Stroke stroke1 = mock(Stroke.class);
                                                   Stroke stroke2 = mock(Stroke.class);
                                                   renderer1.setGroupStroke(stroke1);
                                                   renderer2.setGroupStroke(stroke1);
                                                   assertTrue(renderer1.equals(renderer2));
                                                   renderer2.setGroupStroke(stroke2);
                                                   assertFalse(renderer1.equals(renderer2));
                                                   
                                                   // Note: Testing super.equals() would require knowledge of parent class
                                               }

 @Test
                                              public void testEquals23() {
                                                  // Create two equal renderers
                                                  MinMaxCategoryRenderer r1 = new MinMaxCategoryRenderer();
                                                  MinMaxCategoryRenderer r2 = new MinMaxCategoryRenderer();
                                                  
                                                  // Test reference equality
                                                  assertTrue(r1.equals(r1));
                                                  
                                                  // Test with null
                                                  assertFalse(r1.equals(null));
                                                  
                                                  // Test with wrong type
                                                  assertFalse(r1.equals("Not a renderer"));
                                                  
                                                  // Test with different plotLines
                                                  r1.setDrawLines(true);
                                                  assertFalse(r1.equals(r2));
                                                  r2.setDrawLines(true);
                                                  assertTrue(r1.equals(r2));
                                                  
                                                  // Test with different groupPaint
                                                  r1.setGroupPaint(Color.RED);
                                                  assertFalse(r1.equals(r2));
                                                  r2.setGroupPaint(Color.RED);
                                                  assertTrue(r1.equals(r2));
                                                  
                                                  // Test with different groupStroke
                                                  Stroke stroke1 = new BasicStroke(1.0f);
                                                  Stroke stroke2 = new BasicStroke(2.0f);
                                                  r1.setGroupStroke(stroke1);
                                                  r2.setGroupStroke(stroke2);
                                                  assertFalse(r1.equals(r2));
                                                  r2.setGroupStroke(stroke1);
                                                  assertTrue(r1.equals(r2));
                                                  
                                                  // Test with all fields equal
                                                  assertTrue(r1.equals(r2));
                                                  
                                                  // Test with different superclass fields (if any)
                                                  // This would require mocking or knowing the superclass implementation
                                              }

 @Test
                                         public void testDrawItemSetsCorrectGroupPaint() {
                                             // Setup
                                             MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                             Paint testPaint = Color.RED;
                                             renderer.setGroupPaint(testPaint);
                                             
                                             // Mock dependencies
                                             Graphics2D g2 = mock(Graphics2D.class);
                                             CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                             Rectangle2D dataArea = mock(Rectangle2D.class);
                                             CategoryPlot plot = mock(CategoryPlot.class);
                                             CategoryAxis domainAxis = mock(CategoryAxis.class);
                                             ValueAxis rangeAxis = mock(ValueAxis.class);
                                             CategoryDataset dataset = mock(CategoryDataset.class);
                                             
                                             // Call method
                                             renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                             
                                             // Verify the paint was set correctly - this would fail if mutated to setPaint(null)
                                             verify(g2).setPaint(testPaint);
                                         }

 @Test
                                       public void testEquals24() {
                                           // Create test paints and strokes
                                           Paint paint1 = Color.RED;
                                           Paint paint2 = Color.BLUE;
                                           BasicStroke stroke1 = new BasicStroke(1.0f);
                                           BasicStroke stroke2 = new BasicStroke(2.0f);
                                           
                                           // Create first renderer with specific properties
                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                           renderer1.setDrawLines(true);
                                           renderer1.setGroupPaint(paint1);
                                           renderer1.setGroupStroke(stroke1);
                                           
                                           // Test identity case
                                           assertTrue("Should be equal to itself", renderer1.equals(renderer1));
                                           
                                           // Create equal renderer
                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                           renderer2.setDrawLines(true);
                                           renderer2.setGroupPaint(paint1);
                                           renderer2.setGroupStroke(stroke1);
                                           assertTrue("Equal renderers should be equal", renderer1.equals(renderer2));
                                           
                                           // Test with different plotLines
                                           MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
                                           renderer3.setDrawLines(false);  // different plotLines
                                           renderer3.setGroupPaint(paint1);
                                           renderer3.setGroupStroke(stroke1);
                                           assertFalse("Different plotLines should make unequal", renderer1.equals(renderer3));
                                           
                                           // Test with different groupPaint
                                           MinMaxCategoryRenderer renderer4 = new MinMaxCategoryRenderer();
                                           renderer4.setDrawLines(true);
                                           renderer4.setGroupPaint(paint2);  // different paint
                                           renderer4.setGroupStroke(stroke1);
                                           assertFalse("Different groupPaint should make unequal", renderer1.equals(renderer4));
                                           
                                           // Test with different groupStroke
                                           MinMaxCategoryRenderer renderer5 = new MinMaxCategoryRenderer();
                                           renderer5.setDrawLines(true);
                                           renderer5.setGroupPaint(paint1);
                                           renderer5.setGroupStroke(stroke2);  // different stroke
                                           assertFalse("Different groupStroke should make unequal", renderer1.equals(renderer5));
                                           
                                           // Test with null
                                           assertFalse("Should not equal null", renderer1.equals(null));
                                           
                                           // Test with different class
                                           assertFalse("Should not equal different class", renderer1.equals(new Object()));
                                           
                                           // Test with same paint object but different instance (should still be equal)
                                           Paint paint1Copy = new Color(255, 0, 0); // same as Color.RED
                                           MinMaxCategoryRenderer renderer6 = new MinMaxCategoryRenderer();
                                           renderer6.setDrawLines(true);
                                           renderer6.setGroupPaint(paint1Copy);
                                           renderer6.setGroupStroke(stroke1);
                                           assertTrue("Equal paints (different instances) should be equal", 
                                                      renderer1.equals(renderer6));
                                       }

 @Test
                                       public void testEqualsWithDifferentGroupStrokes() {
                                           // Setup
                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                           
                                           // Set different strokes
                                           Stroke stroke1 = new BasicStroke(1.0f);
                                           Stroke stroke2 = new BasicStroke(2.0f);
                                           
                                           renderer1.setGroupStroke(stroke1);
                                           renderer2.setGroupStroke(stroke2);
                                           
                                           // Test - should return false when strokes are different
                                           assertFalse(renderer1.equals(renderer2));
                                       }

 @Test
                                       public void testEqualsWithNullGroupStroke5() {
                                           // Setup
                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                           
                                           // Set one stroke to null
                                           Stroke stroke = new BasicStroke(1.0f);
                                           renderer1.setGroupStroke(null);
                                           renderer2.setGroupStroke(stroke);
                                           
                                           // Test - should return false when one stroke is null
                                           assertFalse(renderer1.equals(renderer2));
                                           
                                           // Reverse case
                                           renderer1.setGroupStroke(stroke);
                                           renderer2.setGroupStroke(null);
                                           assertFalse(renderer1.equals(renderer2));
                                       }

 @Test
                                       public void testEqualsWithSameGroupStrokes() {
                                           // Setup
                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                           
                                           // Set same strokes
                                           Stroke stroke = new BasicStroke(1.0f);
                                           renderer1.setGroupStroke(stroke);
                                           renderer2.setGroupStroke(stroke);
                                           
                                           // Make other fields equal
                                           renderer1.setDrawLines(true);
                                           renderer2.setDrawLines(true);
                                           
                                           // Test - should return true when strokes are equal
                                           assertTrue(renderer1.equals(renderer2));
                                       }

 @Test(expected = NullPointerException.class)
                                       public void testEqualsWithNullGroupStrokeInMutant() {
                                           // This test specifically targets the mutant
                                           MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                           MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                                           
                                           // Set renderer1's stroke to null
                                           renderer1.setGroupStroke(null);
                                           renderer2.setGroupStroke(new BasicStroke(1.0f));
                                           
                                           // In original code, this would return false
                                           // In mutant, this would throw NullPointerException
                                           renderer1.equals(renderer2);
                                       }

 @Test
                                 public void testDrawItemUsesCorrectMinValue() {
                                     // Setup
                                     MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                                     
                                     Graphics2D g2 = mock(Graphics2D.class);
                                     CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                     Rectangle2D dataArea = mock(Rectangle2D.class);
                                     CategoryPlot plot = mock(CategoryPlot.class);
                                     CategoryAxis domainAxis = mock(CategoryAxis.class);
                                     ValueAxis rangeAxis = mock(ValueAxis.class);
                                     CategoryDataset dataset = mock(CategoryDataset.class);
                                     
                                     // Mock behavior
                                     when(dataset.getValue(0, 0)).thenReturn(5.0); // Set minimum value in dataset
                                     when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any())).thenReturn(0.0);
                                     
                                     // Test
                                     renderer1.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
                                     
                                     // Verify
                                     verify(rangeAxis).valueToJava2D(eq(5.0), eq(dataArea), any());
                                     // This will fail if the mutant is present (using 0 instead of 5.0)
                                 }

 @Test
                             public void testDrawItemUsesMaxValueForPositionCalculation() throws Exception {
                                 // Setup test renderer with known min/max values
                                 MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                                 renderer.setMinIcon(null);
                                 renderer.setMaxIcon(null);
                                 renderer.setObjectIcon(null);
                                 
                                 // Set specific min/max values that would show the difference
                                 double testMin = 10.0;
                                 double testMax = 20.0;
                                 
                                 // Use reflection to set private fields since there are no setters
                                 Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                 minField.setAccessible(true);
                                 minField.set(renderer, testMin);
                                 
                                 Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                 maxField.setAccessible(true);
                                 maxField.set(renderer, testMax);
                                 
                                 // Mock required objects
                                 Graphics2D g2 = mock(Graphics2D.class);
                                 CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                 Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                 CategoryPlot plot = mock(CategoryPlot.class);
                                 CategoryAxis domainAxis = mock(CategoryAxis.class);
                                 ValueAxis rangeAxis = mock(ValueAxis.class);
                                 CategoryDataset dataset = mock(CategoryDataset.class);
                                 
                                 // Stub rangeAxis behavior
                                 when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                                     .thenAnswer(invocation -> {
                                         double value = invocation.getArgument(0);
                                         // Verify the correct value (max) is being used
                                         assertEquals("Should use max value for position calculation", 
                                                     testMax, value, 0.0001);
                                         return 50.0; // arbitrary position
                                     });
                                 
                                 // Execute the drawItem method
                                 renderer.drawItem(g2, state, dataArea, plot, domainAxis, 
                                                  rangeAxis, dataset, 0, 0, 0);
                                 
                                 // Verify interactions
                                 verify(rangeAxis).valueToJava2D(anyDouble(), any(Rectangle2D.class), any());
                             }

 @Test
                           public void testDrawItemWithNonNullDataArea() {
                               // Setup test objects
                               MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                               renderer.setDrawLines(true);
                               
                               // Mock dependencies
                               Graphics2D g2 = mock(Graphics2D.class);
                               CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                               Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                               CategoryPlot plot = mock(CategoryPlot.class);
                               CategoryAxis domainAxis = mock(CategoryAxis.class);
                               ValueAxis rangeAxis = mock(ValueAxis.class);
                               CategoryDataset dataset = mock(CategoryDataset.class);
                               
                               // Set test values using reflection
                               try {
                                   Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                                   minField.setAccessible(true);
                                   minField.set(renderer, 10.0);
                                   
                                   Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                                   maxField.setAccessible(true);
                                   maxField.set(renderer, 20.0);
                               } catch (Exception e) {
                                   fail("Failed to set private fields via reflection");
                               }
                               
                               // Mock behavior
                               when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                                   .thenReturn(50.0);
                               
                               // Test - should not throw exception with proper dataArea
                               try {
                                   renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, 
                                                   dataset, 0, 0, 0);
                                   // If we get here, the test passes (no NPE)
                                   assertTrue(true);
                               } catch (NullPointerException e) {
                                   fail("Original code should handle non-null dataArea properly");
                               }
                           }

 @Test(expected = NullPointerException.class)
                           public void testDrawItemWithNullDataAreaShouldThrow() {
                               // Setup test objects
                               MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                               renderer.setDrawLines(true);
                               
                               // Mock dependencies
                               Graphics2D g2 = mock(Graphics2D.class);
                               CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                               CategoryPlot plot = mock(CategoryPlot.class);
                               CategoryAxis domainAxis = mock(CategoryAxis.class);
                               ValueAxis rangeAxis = mock(ValueAxis.class);
                               CategoryDataset dataset = mock(CategoryDataset.class);
                               
                               // Test - should throw NPE with null dataArea
                               renderer.drawItem(g2, state, null, plot, domainAxis, rangeAxis, 
                                                dataset, 0, 0, 0);
                           }

 @Test
                           public void testEquals25() {
                               // Create two equal renderers
                               MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                               MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                               
                               // Same object should be equal
                               assertTrue(renderer1.equals(renderer1));
                               
                               // Equal objects should be equal
                               assertTrue(renderer1.equals(renderer2));
                               assertTrue(renderer2.equals(renderer1));
                               
                               // Test with null
                               assertFalse(renderer1.equals(null));
                               
                               // Test with different type
                               assertFalse(renderer1.equals("Not a renderer"));
                               
                               // Test with different plotLines
                               renderer2.setDrawLines(!renderer1.isDrawLines());
                               assertFalse(renderer1.equals(renderer2));
                               renderer2.setDrawLines(renderer1.isDrawLines()); // reset
                               
                               // Test with different groupPaint
                               renderer2.setGroupPaint(Color.RED);
                               assertFalse(renderer1.equals(renderer2));
                               renderer2.setGroupPaint(renderer1.getGroupPaint()); // reset
                               
                               // Test with different groupStroke
                               Stroke differentStroke = new BasicStroke(2.0f);
                               renderer2.setGroupStroke(differentStroke);
                               assertFalse(renderer1.equals(renderer2));
                               
                               // Test with all fields equal should be equal
                               renderer2.setGroupStroke(renderer1.getGroupStroke());
                               assertTrue(renderer1.equals(renderer2));
                           }

 @Test
                          public void testEqualsWithDifferentPlotLines6() {
                              // Create two renderers with same properties except plotLines
                              MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                              MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                              
                              Paint testPaint = Color.RED;
                              Stroke testStroke = new BasicStroke(1.0f);
                              
                              // Set same properties for both
                              renderer1.setGroupPaint(testPaint);
                              renderer2.setGroupPaint(testPaint);
                              renderer1.setGroupStroke(testStroke);
                              renderer2.setGroupStroke(testStroke);
                              
                              // Set different plotLines values
                              renderer1.setDrawLines(true);
                              renderer2.setDrawLines(false);
                              
                              // Verify they are not equal due to plotLines difference
                              assertFalse(renderer1.equals(renderer2));
                              assertFalse(renderer2.equals(renderer1));
                              
                              // Now make plotLines same and verify equality
                              renderer2.setDrawLines(true);
                              assertTrue(renderer1.equals(renderer2));
                              assertTrue(renderer2.equals(renderer1));
                              
                              // Verify equals with itself
                              assertTrue(renderer1.equals(renderer1));
                              
                              // Verify equals with null
                              assertFalse(renderer1.equals(null));
                              
                              // Verify equals with different class
                              assertFalse(renderer1.equals(new Object()));
                          }

 @Test
                         public void testEquals_SameInstance6() {
                             MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                             assertTrue(renderer.equals(renderer));
                         }

 @Test
                         public void testEquals_DifferentType1() {
                             MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
                             assertFalse(renderer.equals("Not a renderer"));
                         }

 @Test
                         public void testEquals_DifferentPlotLines8() {
                             MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                             MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                             renderer1.setDrawLines(true);
                             renderer2.setDrawLines(false);
                             assertFalse(renderer1.equals(renderer2));
                         }

 @Test
                         public void testEquals_DifferentGroupPaint8() {
                             MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                             MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                             renderer1.setGroupPaint(Color.RED);
                             renderer2.setGroupPaint(Color.BLUE);
                             assertFalse(renderer1.equals(renderer2));
                         }

 @Test
                         public void testEquals_DifferentGroupStroke8() {
                             MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                             MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                             renderer1.setGroupStroke(new BasicStroke(1.0f));
                             renderer2.setGroupStroke(new BasicStroke(2.0f));
                             assertFalse(renderer1.equals(renderer2));
                         }

 @Test
                         public void testEquals_EqualObjects7() {
                             MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                             MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                             renderer1.setDrawLines(true);
                             renderer2.setDrawLines(true);
                             renderer1.setGroupPaint(Color.RED);
                             renderer2.setGroupPaint(Color.RED);
                             Stroke stroke = new BasicStroke(1.0f);
                             renderer1.setGroupStroke(stroke);
                             renderer2.setGroupStroke(stroke);
                             assertTrue(renderer1.equals(renderer2));
                         }

 @Test
                        public void testEqualsWithDifferentMinIcons() {
                            // Create two renderers with identical fields except minIcon
                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                            
                            // Set all other fields that are compared in equals() to be the same
                            renderer1.setDrawLines(true);
                            renderer2.setDrawLines(true);
                            
                            Paint mockPaint = mock(Paint.class);
                            renderer1.setGroupPaint(mockPaint);
                            renderer2.setGroupPaint(mockPaint);
                            
                            Stroke mockStroke = mock(Stroke.class);
                            renderer1.setGroupStroke(mockStroke);
                            renderer2.setGroupStroke(mockStroke);
                            
                            // Set different minIcons
                            Icon icon1 = mock(Icon.class);
                            Icon icon2 = mock(Icon.class);
                            renderer1.setMinIcon(icon1);
                            renderer2.setMinIcon(icon2);
                            
                            // The objects should not be equal due to different minIcons
                            assertFalse(renderer1.equals(renderer2));
                        }

 @Test
                        public void testEqualsWithSameMinIcons() {
                            // Create two renderers with identical fields including minIcon
                            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                            
                            // Set all fields to be the same
                            renderer1.setDrawLines(true);
                            renderer2.setDrawLines(true);
                            
                            Paint mockPaint = mock(Paint.class);
                            renderer1.setGroupPaint(mockPaint);
                            renderer2.setGroupPaint(mockPaint);
                            
                            Stroke mockStroke = mock(Stroke.class);
                            renderer1.setGroupStroke(mockStroke);
                            renderer2.setGroupStroke(mockStroke);
                            
                            // Set same minIcons
                            Icon icon = mock(Icon.class);
                            renderer1.setMinIcon(icon);
                            renderer2.setMinIcon(icon);
                            
                            // The objects should be equal
                            assertTrue(renderer1.equals(renderer2));
                        }

 @Test
                   public void testEquals26() {
                       // Create test objects
                       MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
                       MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
                       
                       // Test identity
                       assertTrue(renderer1.equals(renderer1));
                       
                       // Test with null
                       assertFalse(renderer1.equals(null));
                       
                       // Test with different type
                       assertFalse(renderer1.equals(new Object()));
                       
                       // Test with equal objects
                       assertTrue(renderer1.equals(renderer2));
                       
                       // Modify plotLines and test
                       renderer1.setDrawLines(true);
                       assertFalse(renderer1.equals(renderer2));
                       renderer2.setDrawLines(true);
                       assertTrue(renderer1.equals(renderer2));
                       
                       // Modify groupPaint and test
                       renderer1.setGroupPaint(Color.RED);
                       assertFalse(renderer1.equals(renderer2));
                       renderer2.setGroupPaint(Color.RED);
                       assertTrue(renderer1.equals(renderer2));
                       
                       // Modify groupStroke and test
                       BasicStroke stroke1 = new BasicStroke(1.0f);
                       BasicStroke stroke2 = new BasicStroke(2.0f);
                       renderer1.setGroupStroke(stroke1);
                       assertFalse(renderer1.equals(renderer2));
                       renderer2.setGroupStroke(stroke1);
                       assertTrue(renderer1.equals(renderer2));
                       
                       // Test with different stroke instances but same values
                       renderer2.setGroupStroke(stroke2);
                       assertFalse(renderer1.equals(renderer2));
                       
                       // Test super.equals() by mocking parent class behavior
                       MinMaxCategoryRenderer mockRenderer = mock(MinMaxCategoryRenderer.class);
                       when(mockRenderer.equals(any())).thenReturn(false);
                       assertFalse(mockRenderer.equals(renderer1));
                   }

 @Test
         public void testDrawItem_DrawsCorrectLineCoordinates() {
             // Setup test data
             MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
             java.awt.Graphics2D g2 = mock(java.awt.Graphics2D.class);
             CategoryItemRendererState state = mock(CategoryItemRendererState.class);
             java.awt.geom.Rectangle2D dataArea = new java.awt.geom.Rectangle2D.Double(0, 0, 100, 100);
             CategoryPlot plot = mock(CategoryPlot.class);
             CategoryAxis domainAxis = mock(CategoryAxis.class);
             ValueAxis rangeAxis = mock(ValueAxis.class);
             CategoryDataset dataset = mock(CategoryDataset.class);
             
             // Setup mocks
             when(dataset.getColumnCount()).thenReturn(1);
             when(dataset.getRowCount()).thenReturn(1);
             when(dataset.getValue(0, 0)).thenReturn(50.0); // some value
             
             // Set min/max values using reflection
             try {
                 Field minField = MinMaxCategoryRenderer.class.getDeclaredField("min");
                 minField.setAccessible(true);
                 minField.set(renderer, 10.0);
                 
                 Field maxField = MinMaxCategoryRenderer.class.getDeclaredField("max");
                 maxField.setAccessible(true);
                 maxField.set(renderer, 90.0);
             } catch (Exception e) {
                 fail("Failed to set min/max fields via reflection");
             }
             
             // Call method under test
             renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
             
             // Verify correct line was drawn
             org.mockito.ArgumentCaptor<java.awt.Shape> shapeCaptor = org.mockito.ArgumentCaptor.forClass(java.awt.Shape.class);
             verify(g2).draw(shapeCaptor.capture());
             
             java.awt.geom.Line2D drawnLine = (java.awt.geom.Line2D) shapeCaptor.getValue();
             assertEquals(10.0, drawnLine.getY1(), 0.001); // minY
             assertEquals(90.0, drawnLine.getY2(), 0.001); // should be maxY (mutant would make this minY)
         }

 @Test
     public void testEquals27() {
         // Create identical renderers
         MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
         renderer1.setDrawLines(true);
         renderer1.setGroupPaint(Color.RED);
         renderer1.setGroupStroke(new BasicStroke(1.0f));
         
         MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
         renderer2.setDrawLines(true);
         renderer2.setGroupPaint(Color.RED);
         renderer2.setGroupStroke(new BasicStroke(1.0f));
         
         // Test equality
         assertTrue(renderer1.equals(renderer2));
         assertTrue(renderer2.equals(renderer1));
         assertTrue(renderer1.equals(renderer1)); // reflexivity
         
         // Test inequality cases
         // Different plotLines
         MinMaxCategoryRenderer renderer3 = new MinMaxCategoryRenderer();
         renderer3.setDrawLines(false);
         renderer3.setGroupPaint(Color.RED);
         renderer3.setGroupStroke(new BasicStroke(1.0f));
         assertFalse(renderer1.equals(renderer3));
         
         // Different groupPaint
         MinMaxCategoryRenderer renderer4 = new MinMaxCategoryRenderer();
         renderer4.setDrawLines(true);
         renderer4.setGroupPaint(Color.BLUE);
         renderer4.setGroupStroke(new BasicStroke(1.0f));
         assertFalse(renderer1.equals(renderer4));
         
         // Different groupStroke
         MinMaxCategoryRenderer renderer5 = new MinMaxCategoryRenderer();
         renderer5.setDrawLines(true);
         renderer5.setGroupPaint(Color.RED);
         renderer5.setGroupStroke(new BasicStroke(2.0f));
         assertFalse(renderer1.equals(renderer5));
         
         // Test with null
         assertFalse(renderer1.equals(null));
         
         // Test with different type
         assertFalse(renderer1.equals("Not a renderer"));
         
         // Test super.equals() by changing a superclass field if possible
         // (This would require knowing the superclass implementation)
     }

 @Test
        public void testEquals28() {
            // Create two identical renderers
            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
            
            // Test reference equality
            assertTrue(renderer1.equals(renderer1));
            
            // Test with null
            assertFalse(renderer1.equals(null));
            
            // Test with different type
            assertFalse(renderer1.equals("Not a renderer"));
            
            // Test equality with same fields
            assertTrue(renderer1.equals(renderer2));
            
            // Test inequality for plotLines
            renderer1.setDrawLines(true);
            renderer2.setDrawLines(false);
            assertFalse(renderer1.equals(renderer2));
            renderer2.setDrawLines(true); // reset
            
            // Test inequality for groupPaint
            Paint paint1 = Color.RED;
            Paint paint2 = Color.BLUE;
            renderer1.setGroupPaint(paint1);
            renderer2.setGroupPaint(paint2);
            assertFalse(renderer1.equals(renderer2));
            renderer2.setGroupPaint(paint1); // reset
            
            // Test inequality for groupStroke
            Stroke stroke1 = new BasicStroke(1.0f);
            Stroke stroke2 = new BasicStroke(2.0f);
            renderer1.setGroupStroke(stroke1);
            renderer2.setGroupStroke(stroke2);
            assertFalse(renderer1.equals(renderer2));
        }

 @Test
        public void testEqualsWithSuperClassFields() {
            MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
            MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
            
            // Assuming super.equals() would check other fields
            // We can't directly test this without knowing super class,
            // but we can verify the equals call includes super.equals()
            assertTrue(renderer1.equals(renderer2));
        }

 @Test
   public void testDrawItemMaxIconCoordinates() {
       // Setup
       MinMaxCategoryRenderer renderer = new MinMaxCategoryRenderer();
       renderer.setMaxIcon(mock(Icon.class));
       
       Graphics2D g2 = mock(Graphics2D.class);
       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
       Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
       CategoryPlot plot = mock(CategoryPlot.class);
       CategoryAxis domainAxis = mock(CategoryAxis.class);
       ValueAxis rangeAxis = mock(ValueAxis.class);
       CategoryDataset dataset = mock(CategoryDataset.class);
       
       // Mock behavior
       when(dataset.getColumnCount()).thenReturn(1);
       when(dataset.getRowCount()).thenReturn(1);
       when(domainAxis.getCategoryMiddle(anyInt(), anyInt(), any(), any())).thenReturn(50.0);
       when(rangeAxis.valueToJava2D(anyDouble(), any(), any())).thenReturn(75.0);
       
       // Test
       renderer.drawItem(g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0, 0);
       
       // Verify maxIcon painting coordinates
       // Should be (int)maxY, (int)x1 - mutation swaps these
       verify(renderer.getMaxIcon()).paintIcon(
           isNull(), 
           eq(g2), 
           eq(75),  // y coordinate (maxY)
           eq(50)   // x coordinate (x1)
       );
   }

 @Test
  public void testEqualsWithDifferentIcons() {
      // Create two renderers with same properties except icons
      MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
      MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
      
      // Set same properties
      renderer1.setDrawLines(true);
      renderer2.setDrawLines(true);
      renderer1.setGroupPaint(Color.RED);
      renderer2.setGroupPaint(Color.RED);
      renderer1.setGroupStroke(new BasicStroke(1.0f));
      renderer2.setGroupStroke(new BasicStroke(1.0f));
      
      // Mock different icons
      Icon icon1 = mock(Icon.class);
      Icon icon2 = mock(Icon.class);
      
      // Set different icons
      renderer1.setMinIcon(icon1);
      renderer1.setMaxIcon(icon1);
      renderer1.setObjectIcon(icon1);
      
      renderer2.setMinIcon(icon2);
      renderer2.setMaxIcon(icon2);
      renderer2.setObjectIcon(icon2);
      
      // Should be false since icons are different
      assertFalse(renderer1.equals(renderer2));
      
      // Also test with one icon null
      renderer1.setMinIcon(null);
      assertFalse(renderer1.equals(renderer2));
      
      // Test with both having null icons
      renderer2.setMinIcon(null);
      assertTrue(renderer1.equals(renderer2));
  }

 @Test
 public void testEqualsWithDifferentFields() {
     // Create two renderers with same values
     MinMaxCategoryRenderer renderer1 = new MinMaxCategoryRenderer();
     MinMaxCategoryRenderer renderer2 = new MinMaxCategoryRenderer();
     
     // Test equal objects
     assertTrue(renderer1.equals(renderer2));
     
     // Test with different plotLines
     renderer1.setDrawLines(true);
     assertFalse(renderer1.equals(renderer2));
     renderer2.setDrawLines(true);
     assertTrue(renderer1.equals(renderer2));
     
     // Test with different groupPaint
     renderer1.setGroupPaint(Color.RED);
     assertFalse(renderer1.equals(renderer2));
     renderer2.setGroupPaint(Color.RED);
     assertTrue(renderer1.equals(renderer2));
     
     // Test with different groupStroke
     Stroke stroke1 = new BasicStroke(1.0f);
     Stroke stroke2 = new BasicStroke(2.0f);
     renderer1.setGroupStroke(stroke1);
     assertFalse(renderer1.equals(renderer2));
     renderer2.setGroupStroke(stroke1);
     assertTrue(renderer1.equals(renderer2));
     
     // Test with different strokes that are equal
     Stroke stroke3 = new BasicStroke(1.0f);
     renderer1.setGroupStroke(stroke1);
     renderer2.setGroupStroke(stroke3);
     assertTrue(renderer1.equals(renderer2));
     
     // Test super.equals() behavior
     // Mock a different but equal super class
     MinMaxCategoryRenderer mockRenderer = mock(MinMaxCategoryRenderer.class);
     when(mockRenderer.getGroupPaint()).thenReturn(Color.RED);
     when(mockRenderer.getGroupStroke()).thenReturn(stroke1);
     when(mockRenderer.isDrawLines()).thenReturn(true);
     // Make super.equals() return false
     doReturn(false).when(mockRenderer).equals(any());
     assertFalse(renderer1.equals(mockRenderer));
 }

}
