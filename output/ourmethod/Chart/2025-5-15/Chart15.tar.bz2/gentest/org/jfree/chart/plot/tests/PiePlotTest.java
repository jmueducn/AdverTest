package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.PaintMap;
import org.jfree.chart.StrokeMap;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.PieSectionEntity;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.PieToolTipGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.text.G2TextMeasurer;
import org.jfree.chart.text.TextAnchor;
import org.jfree.chart.text.TextBlock;
import org.jfree.chart.text.TextBox;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.urls.PieURLGenerator;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleAnchor;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.Rotation;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.ShapeUtilities;
import org.jfree.chart.util.UnitType;
import org.jfree.data.DefaultKeyedValues;
import org.jfree.data.KeyedValues;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.PieDataset;
 
public class PiePlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                          public void testGetMaximumExplodePercent_NullDataset() {
                                                                                                              PiePlot plot = new PiePlot();
                                                                                                              plot.setDataset(null); // Explicitly set to null
                                                                                                              double result = plot.getMaximumExplodePercent();
                                                                                                              assertEquals(0.0, result, 0.0001);
                                                                                                          }

 @Test
                                                                                                          public void testInitialise_WithDataset() {
                                                                                                              // Setup
                                                                                                              PiePlot plot = new PiePlot();
                                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                                              Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                              PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                              
                                                                                                              // Mock dataset with values
                                                                                                              PieDataset dataset = mock(PieDataset.class);
                                                                                                              when(dataset.getItemCount()).thenReturn(3);
                                                                                                              when(dataset.getValue(0)).thenReturn(10.0);
                                                                                                              when(dataset.getValue(1)).thenReturn(20.0);
                                                                                                              when(dataset.getValue(2)).thenReturn(30.0);
                                                                                                              plot.setDataset(dataset);
                                                                                                              plot.setStartAngle(90.0); // Set a specific start angle for testing
                                                                                                      
                                                                                                              // Execute
                                                                                                              PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                                      
                                                                                                              // Verify
                                                                                                              assertNotNull(state);
                                                                                                              assertEquals(2, state.getPassesRequired());
                                                                                                              assertEquals(60.0, state.getTotal(), 0.001); // 10+20+30
                                                                                                              assertEquals(90.0, state.getLatestAngle(), 0.001); // Should match start angle
                                                                                                          }

 @Test
                                                                                                          public void testInitialise_WithoutDataset() {
                                                                                                              // Setup
                                                                                                              PiePlot plot = new PiePlot();
                                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                                              Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                              PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                              plot.setStartAngle(45.0); // Set a specific start angle for testing
                                                                                                      
                                                                                                              // Execute (dataset is null by default)
                                                                                                              PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                                      
                                                                                                              // Verify
                                                                                                              assertNotNull(state);
                                                                                                              assertEquals(2, state.getPassesRequired());
                                                                                                              assertEquals(0.0, state.getTotal(), 0.001); // No dataset means total should be 0
                                                                                                              assertEquals(45.0, state.getLatestAngle(), 0.001); // Should match start angle
                                                                                                          }

 @Test
                                                                                                          public void testInitialise_WithEmptyDataset() {
                                                                                                              // Setup
                                                                                                              PiePlot plot = new PiePlot();
                                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                                              Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                              PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                              
                                                                                                              // Mock empty dataset
                                                                                                              PieDataset dataset = mock(PieDataset.class);
                                                                                                              when(dataset.getItemCount()).thenReturn(0);
                                                                                                              plot.setDataset(dataset);
                                                                                                              plot.setStartAngle(180.0);
                                                                                                      
                                                                                                              // Execute
                                                                                                              PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                                      
                                                                                                              // Verify
                                                                                                              assertNotNull(state);
                                                                                                              assertEquals(2, state.getPassesRequired());
                                                                                                              assertEquals(0.0, state.getTotal(), 0.001); // Empty dataset
                                                                                                              assertEquals(180.0, state.getLatestAngle(), 0.001);
                                                                                                          }

 @Test
                                                                                                          public void testInitialise_WithNullPlotArea() {
                                                                                                              // Setup
                                                                                                              PiePlot plot = new PiePlot();
                                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                                              PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                              
                                                                                                              // Expect exception
                                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                                              thrown.expectMessage("Null 'plotArea' argument.");
                                                                                                      
                                                                                                              // Execute
                                                                                                              plot.initialise(g2, null, plot, 0, info);
                                                                                                          }

 @Test
                                                                                                          public void testInitialise_WithNullPlot() {
                                                                                                              // Setup
                                                                                                              PiePlot plot = new PiePlot();
                                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                                              Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                              PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                              
                                                                                                              // Expect exception
                                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                                              thrown.expectMessage("Null 'plot' argument.");
                                                                                                      
                                                                                                              // Execute
                                                                                                              plot.initialise(g2, plotArea, null, 0, info);
                                                                                                          }

 @Test
                                                                                                          public void testInitialise_WithNegativeIndex() {
                                                                                                              // Setup
                                                                                                              PiePlot plot = new PiePlot();
                                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                                              Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                              PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                              
                                                                                                              // Execute with negative index (should be allowed)
                                                                                                              PiePlotState state = plot.initialise(g2, plotArea, plot, -1, info);
                                                                                                      
                                                                                                              // Verify
                                                                                                              assertNotNull(state);
                                                                                                              assertEquals(2, state.getPassesRequired());
                                                                                                          }

 @Test
                                                                                                          public void testInitialise_WithNullGraphics() {
                                                                                                              // Setup
                                                                                                              PiePlot plot = new PiePlot();
                                                                                                              Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                              PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                              
                                                                                                              // Expect exception
                                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                                              thrown.expectMessage("Null 'g2' argument.");
                                                                                                      
                                                                                                              // Execute
                                                                                                              plot.initialise(null, plotArea, plot, 0, info);
                                                                                                          }

 @Test
                                                                              public void testGetMaximumExplodePercent_MixedValues() {
                                                                                  PieDataset dataset = mock(PieDataset.class);
                                                                                  List<String> keys = new ArrayList<String>();
                                                                                  keys.add("Key1");
                                                                                  keys.add("Key2");
                                                                                  keys.add("Key3");
                                                                                  when(dataset.getKeys()).thenReturn(keys);
                                                                                  
                                                                                  PiePlot plot = new PiePlot(dataset);
                                                                                  plot.setExplodePercent("Key1", -0.10);
                                                                                  plot.setExplodePercent("Key2", 0.30);
                                                                                  plot.setExplodePercent("Key3", 0.0);
                                                                                  
                                                                                  double result = plot.getMaximumExplodePercent();
                                                                                  assertEquals(0.30, result, 0.0001);
                                                                              }

 @Test
                                                                          public void testGetMaximumExplodePercent_NegativeValues() {
                                                                              // Create mock dataset
                                                                              org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                                                                              dataset.setValue("Key1", 1);
                                                                              dataset.setValue("Key2", 1);
                                                                              
                                                                              // Create plot and set explode percentages
                                                                              org.jfree.chart.plot.PiePlot plot = new org.jfree.chart.plot.PiePlot(dataset);
                                                                              plot.setExplodePercent("Key1", -0.10);
                                                                              plot.setExplodePercent("Key2", -0.30);
                                                                              
                                                                              // Verify maximum explode percent (-0.10 is greater than -0.30)
                                                                              double result = plot.getMaximumExplodePercent();
                                                                              org.junit.Assert.assertEquals(-0.10, result, 0.0001);
                                                                          }

 @Test
                                                          public void testGetMaximumExplodePercent_EmptyExplodePercentages() throws Exception {
                                                              // Create plot instance using no-arg constructor
                                                              org.jfree.chart.plot.PiePlot plot = new org.jfree.chart.plot.PiePlot();
                                                              
                                                              // Use reflection to access private field
                                                              java.lang.reflect.Field explodePercentagesField = org.jfree.chart.plot.PiePlot.class.getDeclaredField("explodePercentages");
                                                              explodePercentagesField.setAccessible(true);
                                                              explodePercentagesField.set(plot, new java.util.HashMap<java.lang.Comparable<?>, java.lang.Double>());
                                                              
                                                              // Test the method
                                                              double result = plot.getMaximumExplodePercent();
                                                              org.junit.Assert.assertEquals(0.0, result, 0.0001);
                                                          }

 @Test
                                                      public void testGetMaximumExplodePercent_SingleValue() throws Exception {
                                                          // Create mock dataset
                                                          org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                                                          dataset.setValue("Key1", 1.0);
                                                          
                                                          // Create and populate keys set
                                                          java.util.Set<Comparable<?>> keys = new java.util.TreeSet<Comparable<?>>();
                                                          keys.add("Key1");
                                                          
                                                          // Create plot and set explode percent
                                                          org.jfree.chart.plot.PiePlot plot = new org.jfree.chart.plot.PiePlot(dataset);
                                                          plot.setExplodePercent("Key1", 0.25);
                                                          
                                                          // Verify maximum explode percent
                                                          double result = plot.getMaximumExplodePercent();
                                                          org.junit.Assert.assertEquals(0.25, result, 0.0001);
                                                      }

 @Test
                                                      public void testGetMaximumExplodePercent_MultipleValues() throws Exception {
                                                          // Create mock PieDataset
                                                          org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                                                          dataset.setValue("Key1", 1);
                                                          dataset.setValue("Key2", 1);
                                                          dataset.setValue("Key3", 1);
                                                          
                                                          // Create and populate keys set
                                                          java.util.Set<java.lang.Comparable<?>> keys = new java.util.TreeSet<java.lang.Comparable<?>>();
                                                          keys.add("Key1");
                                                          keys.add("Key2");
                                                          keys.add("Key3");
                                                          
                                                          // Create PiePlot instance
                                                          org.jfree.chart.plot.PiePlot plot = new org.jfree.chart.plot.PiePlot(dataset);
                                                          
                                                          // Use reflection to access private explodePercentages field
                                                          java.lang.reflect.Field explodePercentagesField = org.jfree.chart.plot.PiePlot.class.getDeclaredField("explodePercentages");
                                                          explodePercentagesField.setAccessible(true);
                                                          @SuppressWarnings("unchecked")
                                                          java.util.Map<java.lang.Comparable<?>, java.lang.Double> explodePercentages = 
                                                              (java.util.Map<java.lang.Comparable<?>, java.lang.Double>) explodePercentagesField.get(plot);
                                                          
                                                          // Set explode percentages
                                                          explodePercentages.put("Key1", 0.10);
                                                          explodePercentages.put("Key2", 0.30);
                                                          explodePercentages.put("Key3", 0.20);
                                                          
                                                          // Test the method
                                                          double result = plot.getMaximumExplodePercent();
                                                          org.junit.Assert.assertEquals(0.30, result, 0.0001);
                                                      }

 @Test
                  public void testGetMaximumExplodePercent_SomeNullValues() throws Exception {
                      // Create mock dataset
                      PiePlot plot = new PiePlot();
                      
                      // Create and populate keys set
                      java.util.Set<java.lang.Comparable<?>> keys = new java.util.HashSet<>();
                      keys.add("Key1");
                      keys.add("Key2");
                      keys.add("Key3");
                      
                      // Use reflection to access private field
                      java.lang.reflect.Field explodePercentagesField = org.jfree.chart.plot.PiePlot.class.getDeclaredField("explodePercentages");
                      explodePercentagesField.setAccessible(true);
                      @SuppressWarnings("unchecked")
                      java.util.Map<java.lang.Comparable<?>, Double> explodePercentages = 
                          (java.util.Map<java.lang.Comparable<?>, Double>) explodePercentagesField.get(plot);
                      
                      // Set values including null
                      explodePercentages.put("Key1", 0.1);
                      explodePercentages.put("Key2", null);
                      explodePercentages.put("Key3", 0.2);
                      
                      // Test method
                      double result = plot.getMaximumExplodePercent();
                      assertEquals(0.2, result, 0.0001);
                  }

 @Test(expected = NullPointerException.class)
              public void testInitialiseWithNullInfo() {
                  // Setup test objects with null info
                  PiePlot plot = new PiePlot();
                  Graphics2D g2 = mock(Graphics2D.class);
                  Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                  
                  // This should throw NullPointerException if the mutant is present
                  // because PiePlotState(null) would be called
                  plot.initialise(g2, plotArea, plot, 0, null);
              }

 @Test
             public void testInitialiseWithNonNullInfo() {
                 // Setup test objects
                 PiePlot plot = new PiePlot();
                 Graphics2D g2 = mock(Graphics2D.class);
                 Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                 org.jfree.chart.ChartRenderingInfo chartInfo = new org.jfree.chart.ChartRenderingInfo();
                 org.jfree.chart.plot.PlotRenderingInfo info = new org.jfree.chart.plot.PlotRenderingInfo(chartInfo);
                 
                 // Call the method under test
                 PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                 
                 // Verify the state was initialized correctly
                 assertNotNull(state);
                 assertEquals(2, state.getPassesRequired());
                 assertEquals(plot.getStartAngle(), state.getLatestAngle(), 0.001);
                 
                 // Verify the info object was properly passed to PiePlotState
                 // This would require either:
                 // 1. PiePlotState to expose the info object (needs getter)
                 // 2. Or verify no NullPointerException occurs during initialization
                 // Since we can't access the info object directly in PiePlotState,
                 // we'll verify the state is functional by checking other properties
                 
                 // Additional verification that operations work
                 state.setLatestAngle(45.0);
                 assertEquals(45.0, state.getLatestAngle(), 0.001);
             }

 @Test
        public void testInitialiseWithDatasetShouldCalculateTotal() {
            // Setup
            PiePlot plot = new PiePlot();
            org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
            dataset.setValue("A", 10);
            dataset.setValue("B", 20);
            plot.setDataset(dataset);
            
            // Mock dependencies
            Graphics2D g2 = mock(Graphics2D.class);
            Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
            PlotRenderingInfo info = mock(PlotRenderingInfo.class);
            
            // Test
            PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
            
            // Verify
            // The total should be 30 (10+20) if the original code is working
            // The mutant would skip this calculation
            assertEquals(30.0, state.getTotal(), 0.0001);
            
            // Also verify other required properties are set
            assertEquals(2, state.getPassesRequired());
            assertEquals(plot.getStartAngle(), state.getLatestAngle(), 0.0001);
        }

 @Test
    public void testInitialiseDatasetBehavior() {
        // Setup test objects
        PiePlot plot = new PiePlot();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        PlotRenderingInfo info = mock(PlotRenderingInfo.class);
        
        // Test case 1: null dataset
        plot.setDataset(null);
        PiePlotState state1 = plot.initialise(g2, plotArea, plot, 0, info);
        assertEquals(2, state1.getPassesRequired());
        // Verify total wasn't set when dataset is null
        try {
            state1.getTotal();
            fail("Expected IllegalStateException when total not set");
        } catch (IllegalStateException e) {
            // Expected behavior
        }
        
        // Test case 2: non-null dataset
        PieDataset dataset = mock(PieDataset.class);
        when(DatasetUtilities.calculatePieDatasetTotal(dataset)).thenReturn(100.0);
        plot.setDataset(dataset);
        PiePlotState state2 = plot.initialise(g2, plotArea, plot, 0, info);
        assertEquals(2, state2.getPassesRequired());
        assertEquals(100.0, state2.getTotal(), 0.001);
        
        // Test case 3: dataset changes during execution (to catch timing mutant)
        PieDataset changingDataset = mock(PieDataset.class);
        when(changingDataset.getKeys()).thenThrow(new RuntimeException("Dataset accessed unexpectedly"));
        plot.setDataset(changingDataset);
        // This would fail if the mutant checks dataset at wrong time
        PiePlotState state3 = plot.initialise(g2, plotArea, plot, 0, info);
        assertEquals(2, state3.getPassesRequired());
    }

 @Test
       public void testSetSectionPaintWithNullKeyThrowsIllegalArgumentException() {
           // Setup
           PiePlot plot = new PiePlot();
           Paint paint = mock(Paint.class);
           
           // Expect IllegalArgumentException
           thrown.expect(IllegalArgumentException.class);
           thrown.expectMessage("Null 'key' argument.");
           
           // Test
           plot.setSectionPaint(null, paint);
       }

 @Test
       public void testGetSectionPaintWithNullKeyThrowsIllegalArgumentException() {
           // Setup
           PiePlot plot = new PiePlot();
           
           // Expect IllegalArgumentException
           thrown.expect(IllegalArgumentException.class);
           thrown.expectMessage("Null 'key' argument.");
           
           // Test
           plot.getSectionPaint(null);
       }

 @Test
       public void testSetSectionOutlinePaintWithNullKeyThrowsIllegalArgumentException() {
           // Setup
           PiePlot plot = new PiePlot();
           Paint paint = mock(Paint.class);
           
           // Expect IllegalArgumentException
           thrown.expect(IllegalArgumentException.class);
           thrown.expectMessage("Null 'key' argument.");
           
           // Test
           plot.setSectionOutlinePaint(null, paint);
       }

 @Test
       public void testInitialiseWithNullDataset() {
           // Setup
           PiePlot plot = new PiePlot();
           Graphics2D g2 = mock(Graphics2D.class);
           Rectangle2D plotArea = mock(Rectangle2D.class);
           PlotRenderingInfo info = mock(PlotRenderingInfo.class);
           
           // Test - should not throw any exception
           plot.initialise(g2, plotArea, plot, 0, info);
           
           // Verify dataset is null
           assertNull(plot.getDataset());
       }

 @Test
      public void testGetSectionPaintWithNullKeyThrowsCorrectException() {
          // Setup
          PiePlot plot = new PiePlot();
          
          // Expect exception with specific message
          thrown.expect(IllegalArgumentException.class);
          thrown.expectMessage("Null 'key' argument.");
          
          // Test
          plot.getSectionPaint(null);
      }

 @Test
      public void testSetSectionPaintWithNullKeyThrowsCorrectException() {
          // Setup
          PiePlot plot = new PiePlot();
          
          // Expect exception with specific message
          thrown.expect(IllegalArgumentException.class);
          thrown.expectMessage("Null 'key' argument.");
          
          // Test
          plot.setSectionPaint(null, Color.RED);
      }

 @Test
      public void testGetSectionOutlinePaintWithNullKeyThrowsCorrectException() {
          // Setup
          PiePlot plot = new PiePlot();
          
          // Expect exception with specific message
          thrown.expect(IllegalArgumentException.class);
          thrown.expectMessage("Null 'key' argument.");
          
          // Test
          plot.getSectionOutlinePaint(null);
      }

 @Test
      public void testSetSectionOutlinePaintWithNullKeyThrowsCorrectException() {
          // Setup
          PiePlot plot = new PiePlot();
          
          // Expect exception with specific message
          thrown.expect(IllegalArgumentException.class);
          thrown.expectMessage("Null 'key' argument.");
          
          // Test
          plot.setSectionOutlinePaint(null, Color.BLUE);
      }

 @Test
     public void testExplodePercentagesInitialization() {
         // Create a PiePlot instance
         PiePlot plot = new PiePlot(mock(PieDataset.class));
         
         // Try to set an explode percentage
         try {
             plot.setExplodePercent("Section1", 0.1);
             
             // Verify we can retrieve the set value (original behavior)
             double percent = plot.getExplodePercent("Section1");
             assertEquals(0.1, percent, 0.0001);
             
             // Also verify the map is not null
             assertNotNull(plot.getExplodePercent("Section1"));
         } catch (NullPointerException e) {
             // This would catch the mutant behavior
             fail("NullPointerException occurred, indicating explodePercentages was not initialized");
         }
         
         // Additional test for non-existent key
         try {
             double percent = plot.getExplodePercent("NonExistentSection");
             assertEquals(0.0, percent, 0.0001);
         } catch (NullPointerException e) {
             fail("NullPointerException occurred for non-existent key");
         }
     }

}
