package gentest.org.jfree.data.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.*;
import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
 
public class KeyedObjects2DTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                                        public void testGetObject_EmptyTable() {
                                                                                                                            // Test with empty table
                                                                                                                            KeyedObjects2D emptyTable = new KeyedObjects2D();
                                                                                                                            assertNull(emptyTable.getObject(0, 0));
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_NullRowKey() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                            thrown.expectMessage("Null 'rowKey' argument.");
                                                                                                                            table.getObject(null, "column1");
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_NullColumnKey() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                            thrown.expectMessage("Null 'columnKey' argument.");
                                                                                                                            table.getObject("row1", null);
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_UnknownRowKey() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            // Add some column keys but no row keys
                                                                                                                            table.addObject("value", "row1", "column1");
                                                                                                                            
                                                                                                                            thrown.expect(UnknownKeyException.class);
                                                                                                                            thrown.expectMessage("Row key (unknownRow) not recognised.");
                                                                                                                            table.getObject("unknownRow", "column1");
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_UnknownColumnKey() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            // Add some data
                                                                                                                            table.addObject("value", "row1", "column1");
                                                                                                                            
                                                                                                                            thrown.expect(UnknownKeyException.class);
                                                                                                                            thrown.expectMessage("Column key (unknownColumn) not recognised.");
                                                                                                                            table.getObject("row1", "unknownColumn");
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_ValidKeysReturnsValue() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            String expectedValue = "testValue";
                                                                                                                            table.addObject(expectedValue, "row1", "column1");
                                                                                                                            
                                                                                                                            Object result = table.getObject("row1", "column1");
                                                                                                                            assertEquals(expectedValue, result);
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_ValidKeysReturnsNull() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            // Add a row and column but no value at that position
                                                                                                                            table.addObject("value", "row1", "column1");
                                                                                                                            
                                                                                                                            assertNull(table.getObject("row1", "column2"));
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_MultipleRowsAndColumns() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            String value1 = "value1";
                                                                                                                            String value2 = "value2";
                                                                                                                            String value3 = "value3";
                                                                                                                            
                                                                                                                            table.addObject(value1, "row1", "column1");
                                                                                                                            table.addObject(value2, "row1", "column2");
                                                                                                                            table.addObject(value3, "row2", "column1");
                                                                                                                            
                                                                                                                            assertEquals(value1, table.getObject("row1", "column1"));
                                                                                                                            assertEquals(value2, table.getObject("row1", "column2"));
                                                                                                                            assertEquals(value3, table.getObject("row2", "column1"));
                                                                                                                            assertNull(table.getObject("row2", "column2"));
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_AfterRemoval() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            String value = "value";
                                                                                                                            table.addObject(value, "row1", "column1");
                                                                                                                            
                                                                                                                            assertEquals(value, table.getObject("row1", "column1"));
                                                                                                                            table.removeObject("row1", "column1");
                                                                                                                            assertNull(table.getObject("row1", "column1"));
                                                                                                                        }

 @Test
                                                                                                                        public void testGetObject_WithDifferentKeyTypes() {
                                                                                                                            KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                            Integer intKey = 1;
                                                                                                                            Double doubleKey = 2.5;
                                                                                                                            String stringValue = "value";
                                                                                                                            
                                                                                                                            table.addObject(stringValue, intKey, doubleKey);
                                                                                                                            assertEquals(stringValue, table.getObject(intKey, doubleKey));
                                                                                                                        }

 @Test
                                                                                                                        public void testRemoveRow_EmptyTable() {
                                                                                                                            KeyedObjects2D emptyTable = new KeyedObjects2D();
                                                                                                                            thrown.expect(IndexOutOfBoundsException.class);
                                                                                                                            emptyTable.removeRow(0);
                                                                                                                        }

 @Test
                                                                                                                        public void testRemoveRow_WithExistingRowKey() {
                                                                                                                            // Setup
                                                                                                                            KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                            String rowKey = "Row1";
                                                                                                                            String columnKey = "Col1";
                                                                                                                            Object value = new Object();
                                                                                                                            
                                                                                                                            // Add test data
                                                                                                                            data.addObject(value, rowKey, columnKey);
                                                                                                                            int initialRowCount = data.getRowCount();
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            data.removeRow(rowKey);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertEquals(initialRowCount - 1, data.getRowCount());
                                                                                                                            assertFalse(data.getRowKeys().contains(rowKey));
                                                                                                                        }

 @Test
                                                                                                                        public void testRemoveRow_WithNonExistentRowKey() {
                                                                                                                            // Setup
                                                                                                                            KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                            String existingKey = "ExistingRow";
                                                                                                                            String nonExistentKey = "NonExistentRow";
                                                                                                                            data.addObject(new Object(), existingKey, "Col1");
                                                                                                                            
                                                                                                                            // Expect exception
                                                                                                                            thrown.expect(UnknownKeyException.class);
                                                                                                                            thrown.expectMessage("Row key (" + nonExistentKey + ") not recognised.");
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            data.removeRow(nonExistentKey);
                                                                                                                        }

 @Test
                                                                                                                        public void testRemoveRow_WithNullRowKey() {
                                                                                                                            // Setup
                                                                                                                            KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                            data.addObject(new Object(), "ValidRow", "Col1");
                                                                                                                            
                                                                                                                            // Expect exception
                                                                                                                            thrown.expect(UnknownKeyException.class);
                                                                                                                            thrown.expectMessage("Row key (null) not recognised.");
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            data.removeRow(null);
                                                                                                                        }

 @Test
                                                                                                                        public void testRemoveRow_WithEmptyRowKeys() {
                                                                                                                            // Setup - empty data structure
                                                                                                                            KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                            String testKey = "TestKey";
                                                                                                                            
                                                                                                                            // Expect exception
                                                                                                                            thrown.expect(UnknownKeyException.class);
                                                                                                                            thrown.expectMessage("Row key (" + testKey + ") not recognised.");
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            data.removeRow(testKey);
                                                                                                                        }

 @Test
                                                                                                                        public void testRemoveRow_VerifyRowContentsRemoved() {
                                                                                                                            // Setup
                                                                                                                            KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                            String rowKey = "RowToRemove";
                                                                                                                            String colKey1 = "Col1";
                                                                                                                            String colKey2 = "Col2";
                                                                                                                            Object value1 = new Object();
                                                                                                                            Object value2 = new Object();
                                                                                                                            
                                                                                                                            data.addObject(value1, rowKey, colKey1);
                                                                                                                            data.addObject(value2, rowKey, colKey2);
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            data.removeRow(rowKey);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertEquals(0, data.getRowCount());
                                                                                                                            assertEquals(0, data.getColumnCount()); // Columns should also be removed if they were only in this row
                                                                                                                        }

 @Test
                                                                                                                        public void testRemoveRow_WithMultipleRows() {
                                                                                                                            // Setup
                                                                                                                            KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                            String rowKey1 = "Row1";
                                                                                                                            String rowKey2 = "Row2";
                                                                                                                            String colKey = "Col1";
                                                                                                                            
                                                                                                                            data.addObject(new Object(), rowKey1, colKey);
                                                                                                                            data.addObject(new Object(), rowKey2, colKey);
                                                                                                                            int initialRowCount = data.getRowCount();
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            data.removeRow(rowKey1);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            assertEquals(initialRowCount - 1, data.getRowCount());
                                                                                                                            assertFalse(data.getRowKeys().contains(rowKey1));
                                                                                                                            assertTrue(data.getRowKeys().contains(rowKey2));
                                                                                                                        }

 @Test
                                                                                                                        public void testRemoveColumn_EmptyDataset() {
                                                                                                                            KeyedObjects2D emptyData = new KeyedObjects2D();
                                                                                                                            
                                                                                                                            thrown.expect(UnknownKeyException.class);
                                                                                                                            thrown.expectMessage("Column key (AnyCol) not recognised.");
                                                                                                                            
                                                                                                                            emptyData.removeColumn("AnyCol");
                                                                                                                        }

 @Test
                                                                                                                public void testGetObject_ValidRowAndColumn() {
                                                                                                                    // Initialize the test object
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    
                                                                                                                    // Add test data
                                                                                                                    keyedObjects2D.addObject("A1", "Row1", "Col1");
                                                                                                                    keyedObjects2D.addObject("B2", "Row2", "Col2");
                                                                                                                    keyedObjects2D.addObject("C3", "Row3", "Col3");
                                                                                                                    
                                                                                                                    // Test with valid indices
                                                                                                                    assertEquals("A1", keyedObjects2D.getObject(0, 0));
                                                                                                                    assertEquals("B2", keyedObjects2D.getObject(1, 1));
                                                                                                                    assertEquals("C3", keyedObjects2D.getObject(2, 2));
                                                                                                                }

 @Test
                                                                                                                public void testGetObject_RowDataNull() {
                                                                                                                    // Test when row data is null (row doesn't exist)
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    assertNull(keyedObjects2D.getObject(99, 0));
                                                                                                                }

 @Test
                                                                                                                public void testGetObject_ColumnKeyNull() {
                                                                                                                    // Create test instance and add test data
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    keyedObjects2D.addObject("TestObject", "Row1", "Column1");
                                                                                                                    
                                                                                                                    // Get the column keys list and set first column key to null
                                                                                                                    List columnKeys = keyedObjects2D.getColumnKeys();
                                                                                                                    columnKeys.set(0, null);
                                                                                                                    
                                                                                                                    // Verify that getObject returns null when column key is null
                                                                                                                    assertNull(keyedObjects2D.getObject(0, 0));
                                                                                                                }

 @Test
                                                                                                                public void testGetObject_ColumnKeyNotFoundInRow() {
                                                                                                                    // Create mock objects
                                                                                                                    KeyedObjects mockRowData = mock(KeyedObjects.class);
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    
                                                                                                                    // Mock a row where the column key doesn't exist
                                                                                                                    when(mockRowData.getIndex(any())).thenReturn(-1);
                                                                                                                    
                                                                                                                    List<KeyedObjects> rows = new ArrayList<>();
                                                                                                                    rows.add(mockRowData);
                                                                                                                    
                                                                                                                    // Use reflection to set the rows field for testing
                                                                                                                    try {
                                                                                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                                                                                        rowsField.setAccessible(true);
                                                                                                                        rowsField.set(keyedObjects2D, rows);
                                                                                                                        
                                                                                                                        List<Comparable> columnKeys = new ArrayList<>();
                                                                                                                        columnKeys.add("TestColumn");
                                                                                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                                                                                        columnKeysField.setAccessible(true);
                                                                                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                                                                                        
                                                                                                                        assertNull(keyedObjects2D.getObject(0, 0));
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                    }
                                                                                                                }

 @Test
                                                                                                                public void testGetObject_ColumnKeyFoundInRow() {
                                                                                                                    // Create instances and mocks
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    KeyedObjects mockRowData = mock(KeyedObjects.class);
                                                                                                                    
                                                                                                                    // Mock a row where the column key exists
                                                                                                                    when(mockRowData.getIndex(any())).thenReturn(0);
                                                                                                                    when(mockRowData.getObject(any())).thenReturn("MockValue");
                                                                                                                    
                                                                                                                    List<KeyedObjects> rows = new ArrayList<>();
                                                                                                                    rows.add(mockRowData);
                                                                                                                    
                                                                                                                    try {
                                                                                                                        java.lang.reflect.Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                                                                                        rowsField.setAccessible(true);
                                                                                                                        rowsField.set(keyedObjects2D, rows);
                                                                                                                        
                                                                                                                        List<Comparable> columnKeys = new ArrayList<>();
                                                                                                                        columnKeys.add("TestColumn");
                                                                                                                        java.lang.reflect.Field columnKeysField = KeyedObjects2D.class.getDeclaredField("columnKeys");
                                                                                                                        columnKeysField.setAccessible(true);
                                                                                                                        columnKeysField.set(keyedObjects2D, columnKeys);
                                                                                                                        
                                                                                                                        assertEquals("MockValue", keyedObjects2D.getObject(0, 0));
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                    }
                                                                                                                }

 @Test
                                                                                                                public void testGetObject_NegativeRowIndex() {
                                                                                                                    // Test with negative row index
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    assertNull(keyedObjects2D.getObject(-1, 0));
                                                                                                                }

 @Test
                                                                                                                public void testGetObject_NegativeColumnIndex() {
                                                                                                                    // Test with negative column index
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    assertNull(keyedObjects2D.getObject(0, -1));
                                                                                                                }

 @Test
                                                                                                                public void testGetObject_RowIndexOutOfBounds() {
                                                                                                                    // Create a new empty KeyedObjects2D instance
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    // Test with row index larger than row count (should return null)
                                                                                                                    assertNull(keyedObjects2D.getObject(99, 0));
                                                                                                                }

 @Test
                                                                                                                public void testGetObject_ColumnIndexOutOfBounds() {
                                                                                                                    // Create a new KeyedObjects2D instance
                                                                                                                    KeyedObjects2D keyedObjects2D = new KeyedObjects2D();
                                                                                                                    
                                                                                                                    // Test with column index larger than column count
                                                                                                                    assertNull(keyedObjects2D.getObject(0, 99));
                                                                                                                    
                                                                                                                    // Test with negative column index
                                                                                                                    assertNull(keyedObjects2D.getObject(0, -1));
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_RemovesObjectAndEmptyRow() {
                                                                                                                    // Setup test data
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    String rowKey = "Row1";
                                                                                                                    String columnKey = "Column1";
                                                                                                                    Object value = new Object();
                                                                                                                    
                                                                                                                    data.addObject(value, rowKey, columnKey);
                                                                                                                    assertEquals(1, data.getRowCount());
                                                                                                                    assertEquals(1, data.getColumnCount());
                                                                                                                    
                                                                                                                    // Remove the only object
                                                                                                                    data.removeObject(rowKey, columnKey);
                                                                                                                    
                                                                                                                    // Verify row and column were removed
                                                                                                                    assertEquals(0, data.getRowCount());
                                                                                                                    assertEquals(0, data.getColumnCount());
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_RemovesObjectButKeepsRowAndColumn() {
                                                                                                                    // Create new instance
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    
                                                                                                                    // Setup test with multiple rows and columns
                                                                                                                    data.addObject("val1", "Row1", "Column1");
                                                                                                                    data.addObject("val2", "Row1", "Column2");
                                                                                                                    data.addObject("val3", "Row2", "Column1");
                                                                                                                    
                                                                                                                    assertEquals(2, data.getRowCount());
                                                                                                                    assertEquals(2, data.getColumnCount());
                                                                                                                    
                                                                                                                    // Remove one object
                                                                                                                    data.removeObject("Row1", "Column1");
                                                                                                                    
                                                                                                                    // Verify row and column counts remain
                                                                                                                    assertEquals(2, data.getRowCount());
                                                                                                                    assertEquals(2, data.getColumnCount());
                                                                                                                    
                                                                                                                    // Verify specific object was removed
                                                                                                                    assertNull(data.getObject("Row1", "Column1"));
                                                                                                                    assertNotNull(data.getObject("Row1", "Column2"));
                                                                                                                    assertNotNull(data.getObject("Row2", "Column1"));
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_RemovesObjectAndEmptyColumn() {
                                                                                                                    // Setup test data
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    data.addObject("val1", "Row1", "Column1");
                                                                                                                    data.addObject("val2", "Row2", "Column1");
                                                                                                                    
                                                                                                                    assertEquals(2, data.getRowCount());
                                                                                                                    assertEquals(1, data.getColumnCount());
                                                                                                                    
                                                                                                                    // Remove all objects in column
                                                                                                                    data.removeObject("Row1", "Column1");
                                                                                                                    data.removeObject("Row2", "Column1");
                                                                                                                    
                                                                                                                    // Verify column was removed
                                                                                                                    assertEquals(0, data.getRowCount());
                                                                                                                    assertEquals(0, data.getColumnCount());
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_NonExistentRowKey() {
                                                                                                                    // Create new instance of KeyedObjects2D
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    
                                                                                                                    // Setup test data
                                                                                                                    data.addObject("val1", "Row1", "Column1");
                                                                                                                    
                                                                                                                    // Try to remove with non-existent row key
                                                                                                                    data.removeObject("NonExistentRow", "Column1");
                                                                                                                    
                                                                                                                    // Verify no changes to data structure
                                                                                                                    assertEquals(1, data.getRowCount());
                                                                                                                    assertEquals(1, data.getColumnCount());
                                                                                                                    assertNotNull(data.getObject("Row1", "Column1"));
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_NonExistentColumnKey() {
                                                                                                                    // Setup test data
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    data.addObject("val1", "Row1", "Column1");
                                                                                                                    
                                                                                                                    // Try to remove with non-existent column key
                                                                                                                    data.removeObject("Row1", "NonExistentColumn");
                                                                                                                    
                                                                                                                    // Verify no changes to data structure
                                                                                                                    assertEquals(1, data.getRowCount());
                                                                                                                    assertEquals(1, data.getColumnCount());
                                                                                                                    assertNotNull(data.getObject("Row1", "Column1"));
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_NullRowKey() {
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                    data.removeObject(null, "Column1");
                                                                                                                }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                public void testRemoveObject_NullColumnKey() {
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    data.removeObject("Row1", null);
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_FromEmptyTable() {
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    assertEquals(0, data.getRowCount());
                                                                                                                    assertEquals(0, data.getColumnCount());
                                                                                                                    
                                                                                                                    // Should not throw any exception
                                                                                                                    data.removeObject("AnyRow", "AnyColumn");
                                                                                                                    
                                                                                                                    assertEquals(0, data.getRowCount());
                                                                                                                    assertEquals(0, data.getColumnCount());
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_LastObjectInRowButNotColumn() {
                                                                                                                    // Setup test data
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    data.addObject("val1", "Row1", "Column1");
                                                                                                                    data.addObject("val2", "Row1", "Column2");
                                                                                                                    data.addObject("val3", "Row2", "Column1");
                                                                                                                    
                                                                                                                    // Remove one object from Row1
                                                                                                                    data.removeObject("Row1", "Column1");
                                                                                                                    
                                                                                                                    // Row1 should still exist (has Column2)
                                                                                                                    assertEquals(2, data.getRowCount());
                                                                                                                    assertEquals(2, data.getColumnCount());
                                                                                                                    assertNull(data.getObject("Row1", "Column1"));
                                                                                                                    assertNotNull(data.getObject("Row1", "Column2"));
                                                                                                                }

 @Test
                                                                                                                public void testRemoveObject_LastObjectInColumnButNotRow() {
                                                                                                                    // Setup test data
                                                                                                                    KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                    data.addObject("val1", "Row1", "Column1");
                                                                                                                    data.addObject("val2", "Row1", "Column2");
                                                                                                                    data.addObject("val3", "Row2", "Column2");
                                                                                                                    
                                                                                                                    // Remove one object from Column1
                                                                                                                    data.removeObject("Row1", "Column1");
                                                                                                                    
                                                                                                                    // Column1 should be removed, Column2 remains
                                                                                                                    assertEquals(2, data.getRowCount());
                                                                                                                    assertEquals(1, data.getColumnCount());
                                                                                                                    assertNull(data.getObject("Row1", "Column1"));
                                                                                                                    assertNotNull(data.getObject("Row1", "Column2"));
                                                                                                                }

 @Test
                                                                                                                public void testRemoveRow_ValidIndex() {
                                                                                                                    // Create and populate test data
                                                                                                                    KeyedObjects2D keyedObjects = new KeyedObjects2D();
                                                                                                                    keyedObjects.addObject("A1", "Row1", "Col1");
                                                                                                                    keyedObjects.addObject("A2", "Row1", "Col2");
                                                                                                                    keyedObjects.addObject("B1", "Row2", "Col1");
                                                                                                                    keyedObjects.addObject("B2", "Row2", "Col2");
                                                                                                                    keyedObjects.addObject("C1", "Row3", "Col1");
                                                                                                                    keyedObjects.addObject("C2", "Row3", "Col2");
                                                                                                                    
                                                                                                                    // Verify initial state
                                                                                                                    assertEquals(3, keyedObjects.getRowCount());
                                                                                                                    assertEquals("Row1", keyedObjects.getRowKey(0));
                                                                                                                    assertEquals("Row2", keyedObjects.getRowKey(1));
                                                                                                                    assertEquals("Row3", keyedObjects.getRowKey(2));
                                                                                                                    
                                                                                                                    // Remove middle row
                                                                                                                    keyedObjects.removeRow(1);
                                                                                                                    
                                                                                                                    // Verify post-removal state
                                                                                                                    assertEquals(2, keyedObjects.getRowCount());
                                                                                                                    assertEquals("Row1", keyedObjects.getRowKey(0));
                                                                                                                    assertEquals("Row3", keyedObjects.getRowKey(1));
                                                                                                                    
                                                                                                                    // Verify objects in remaining rows
                                                                                                                    assertEquals("A1", keyedObjects.getObject(0, 0));
                                                                                                                    assertEquals("A2", keyedObjects.getObject(0, 1));
                                                                                                                    assertEquals("C1", keyedObjects.getObject(1, 0));
                                                                                                                    assertEquals("C2", keyedObjects.getObject(1, 1));
                                                                                                                }

 @Test
                                                                                                                public void testRemoveRow_FirstIndex() {
                                                                                                                    // Create and populate test data
                                                                                                                    KeyedObjects2D keyedObjects = new KeyedObjects2D();
                                                                                                                    
                                                                                                                    // Add rows and columns
                                                                                                                    keyedObjects.addObject("A1", "Row1", "Col1");
                                                                                                                    keyedObjects.addObject("A2", "Row1", "Col2");
                                                                                                                    keyedObjects.addObject("B1", "Row2", "Col1");
                                                                                                                    keyedObjects.addObject("B2", "Row2", "Col2");
                                                                                                                    keyedObjects.addObject("C1", "Row3", "Col1");
                                                                                                                    keyedObjects.addObject("C2", "Row3", "Col2");
                                                                                                                    
                                                                                                                    // Remove first row
                                                                                                                    keyedObjects.removeRow(0);
                                                                                                                    
                                                                                                                    assertEquals(2, keyedObjects.getRowCount());
                                                                                                                    assertEquals("Row2", keyedObjects.getRowKey(0));
                                                                                                                    assertEquals("Row3", keyedObjects.getRowKey(1));
                                                                                                                    
                                                                                                                    // Verify objects
                                                                                                                    assertEquals("B1", keyedObjects.getObject(0, 0));
                                                                                                                    assertEquals("B2", keyedObjects.getObject(0, 1));
                                                                                                                    assertEquals("C1", keyedObjects.getObject(1, 0));
                                                                                                                    assertEquals("C2", keyedObjects.getObject(1, 1));
                                                                                                                }

 @Test
                                                                                                                public void testRemoveRow_LastIndex() {
                                                                                                                    // Create and populate test data
                                                                                                                    KeyedObjects2D keyedObjects = new KeyedObjects2D();
                                                                                                                    
                                                                                                                    // Add columns (assuming the class needs column keys)
                                                                                                                    keyedObjects.addObject("A1", "Row1", "Col1");
                                                                                                                    keyedObjects.addObject("A2", "Row1", "Col2");
                                                                                                                    keyedObjects.addObject("B1", "Row2", "Col1");
                                                                                                                    keyedObjects.addObject("B2", "Row2", "Col2");
                                                                                                                    keyedObjects.addObject("C1", "Row3", "Col1");
                                                                                                                    keyedObjects.addObject("C2", "Row3", "Col2");
                                                                                                                    
                                                                                                                    // Remove last row
                                                                                                                    keyedObjects.removeRow(2);
                                                                                                                    
                                                                                                                    assertEquals(2, keyedObjects.getRowCount());
                                                                                                                    assertEquals("Row1", keyedObjects.getRowKey(0));
                                                                                                                    assertEquals("Row2", keyedObjects.getRowKey(1));
                                                                                                                    
                                                                                                                    // Verify objects
                                                                                                                    assertEquals("A1", keyedObjects.getObject(0, 0));
                                                                                                                    assertEquals("A2", keyedObjects.getObject(0, 1));
                                                                                                                    assertEquals("B1", keyedObjects.getObject(1, 0));
                                                                                                                    assertEquals("B2", keyedObjects.getObject(1, 1));
                                                                                                                }

 @Test(expected = IndexOutOfBoundsException.class)
                                                                                                            public void testRemoveRow_IndexEqualToSize() {
                                                                                                                KeyedObjects2D keyedObjects = new KeyedObjects2D();
                                                                                                                // Add 3 rows to make size = 3
                                                                                                                keyedObjects.addObject("A", "Row1", "Col1");
                                                                                                                keyedObjects.addObject("B", "Row2", "Col1");
                                                                                                                keyedObjects.addObject("C", "Row3", "Col1");
                                                                                                                // Try to remove row at index 3 (invalid)
                                                                                                                keyedObjects.removeRow(3);
                                                                                                            }

 @Test
                                                                                                            public void testRemoveRow_IndexGreaterThanSize() {
                                                                                                                KeyedObjects2D keyedObjects = new KeyedObjects2D();
                                                                                                                thrown.expect(IndexOutOfBoundsException.class);
                                                                                                                keyedObjects.removeRow(100);
                                                                                                            }

 @Test
                                                                                                            public void testRemoveRow_VerifyRowKeysConsistency() {
                                                                                                                KeyedObjects2D keyedObjects = new KeyedObjects2D();
                                                                                                                // Add some sample data
                                                                                                                keyedObjects.addObject("A", "Row1", "Col1");
                                                                                                                keyedObjects.addObject("B", "Row2", "Col1");
                                                                                                                keyedObjects.addObject("C", "Row3", "Col1");
                                                                                                                
                                                                                                                List<Comparable> originalRowKeys = new ArrayList<>(keyedObjects.getRowKeys());
                                                                                                                List<Comparable> expectedRowKeys = new ArrayList<>(originalRowKeys);
                                                                                                                expectedRowKeys.remove(1);
                                                                                                                
                                                                                                                keyedObjects.removeRow(1);
                                                                                                                
                                                                                                                assertEquals(expectedRowKeys, keyedObjects.getRowKeys());
                                                                                                            }

 @Test
                                                                                                            public void testRemoveRow_AllRowsOneByOne() {
                                                                                                                // Create and initialize test object
                                                                                                                KeyedObjects2D keyedObjects = new KeyedObjects2D();
                                                                                                                
                                                                                                                // Add test data
                                                                                                                keyedObjects.addObject("Data1", "Row1", "Col1");
                                                                                                                keyedObjects.addObject("Data2", "Row2", "Col1");
                                                                                                                keyedObjects.addObject("Data3", "Row3", "Col1");
                                                                                                                
                                                                                                                // Remove all rows one by one and verify state after each removal
                                                                                                                assertEquals(3, keyedObjects.getRowCount());
                                                                                                                
                                                                                                                // Remove first row
                                                                                                                keyedObjects.removeRow(0);
                                                                                                                assertEquals(2, keyedObjects.getRowCount());
                                                                                                                assertEquals("Row2", keyedObjects.getRowKey(0));
                                                                                                                assertEquals("Row3", keyedObjects.getRowKey(1));
                                                                                                                
                                                                                                                // Remove first row (now Row2)
                                                                                                                keyedObjects.removeRow(0);
                                                                                                                assertEquals(1, keyedObjects.getRowCount());
                                                                                                                assertEquals("Row3", keyedObjects.getRowKey(0));
                                                                                                                
                                                                                                                // Remove last remaining row
                                                                                                                keyedObjects.removeRow(0);
                                                                                                                assertEquals(0, keyedObjects.getRowCount());
                                                                                                                
                                                                                                                // Verify empty state
                                                                                                                assertTrue(keyedObjects.getRowKeys().isEmpty());
                                                                                                                
                                                                                                                // Verify private field using reflection
                                                                                                                try {
                                                                                                                    Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                                                                                                    rowsField.setAccessible(true);
                                                                                                                    List<?> rows = (List<?>) rowsField.get(keyedObjects);
                                                                                                                    assertTrue(rows.isEmpty());
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Failed to verify private field using reflection: " + e.getMessage());
                                                                                                                }
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_EmptyTable() {
                                                                                                                // Should handle empty table gracefully
                                                                                                                KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                table.removeColumn(0); // Should not throw exception
                                                                                                                assertEquals(0, table.getColumnCount());
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_ValidIndex() {
                                                                                                                // Setup test data
                                                                                                                KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                table.addObject("R1C1", "Row1", "Col1");
                                                                                                                table.addObject("R1C2", "Row1", "Col2");
                                                                                                                table.addObject("R2C1", "Row2", "Col1");
                                                                                                                table.addObject("R2C2", "Row2", "Col2");
                                                                                                                
                                                                                                                int initialColumnCount = table.getColumnCount();
                                                                                                                int initialRowCount = table.getRowCount();
                                                                                                                
                                                                                                                // Remove first column
                                                                                                                table.removeColumn(0);
                                                                                                                
                                                                                                                // Verify column was removed
                                                                                                                assertEquals(initialColumnCount - 1, table.getColumnCount());
                                                                                                                assertEquals(initialRowCount, table.getRowCount());
                                                                                                                assertFalse(table.getColumnKeys().contains("Col1"));
                                                                                                                assertTrue(table.getColumnKeys().contains("Col2"));
                                                                                                                
                                                                                                                // Verify objects in remaining column
                                                                                                                assertEquals("R1C2", table.getObject("Row1", "Col2"));
                                                                                                                assertEquals("R2C2", table.getObject("Row2", "Col2"));
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_LastColumn() {
                                                                                                                KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                table.addObject("R1C1", "Row1", "Col1");
                                                                                                                table.addObject("R1C2", "Row1", "Col2");
                                                                                                                
                                                                                                                table.removeColumn(1); // Remove last column
                                                                                                                
                                                                                                                assertEquals(1, table.getColumnCount());
                                                                                                                assertEquals("Col1", table.getColumnKeys().get(0));
                                                                                                                assertEquals("R1C1", table.getObject("Row1", "Col1"));
                                                                                                            }

 @Test(expected = IndexOutOfBoundsException.class)
                                                                                                            public void testRemoveColumn_InvalidNegativeIndex() {
                                                                                                                KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                table.removeColumn(-1);
                                                                                                            }

 @Test(expected = IndexOutOfBoundsException.class)
                                                                                                            public void testRemoveColumn_InvalidIndexBeyondSize() {
                                                                                                                KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                table.addObject("R1C1", "Row1", "Col1");
                                                                                                                table.removeColumn(1); // Only column 0 exists
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_VerifyRowSizesReduced() {
                                                                                                                // Create new table instance
                                                                                                                KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                
                                                                                                                // Add data with different row sizes
                                                                                                                table.addObject("R1C1", "Row1", "Col1");
                                                                                                                table.addObject("R1C2", "Row1", "Col2");
                                                                                                                table.addObject("R2C1", "Row2", "Col1");
                                                                                                                
                                                                                                                // Before removal, row sizes should be 2 and 1
                                                                                                                assertEquals(2, ((List<?>)table.getObject("Row1", 0)).size());
                                                                                                                assertEquals(1, ((List<?>)table.getObject("Row2", 0)).size());
                                                                                                                
                                                                                                                table.removeColumn(0); // Remove Col1
                                                                                                                
                                                                                                                // After removal, row sizes should be reduced
                                                                                                                assertEquals(1, ((List<?>)table.getObject("Row1", 0)).size());
                                                                                                                assertEquals(0, ((List<?>)table.getObject("Row2", 0)).size());
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_MiddleColumn() {
                                                                                                                KeyedObjects2D table = new KeyedObjects2D();
                                                                                                                table.addObject("R1C1", "Row1", "Col1");
                                                                                                                table.addObject("R1C2", "Row1", "Col2");
                                                                                                                table.addObject("R1C3", "Row1", "Col3");
                                                                                                                
                                                                                                                table.removeColumn(1); // Remove middle column
                                                                                                                
                                                                                                                assertEquals(2, table.getColumnCount());
                                                                                                                assertEquals("Col1", table.getColumnKeys().get(0));
                                                                                                                assertEquals("Col3", table.getColumnKeys().get(1));
                                                                                                                assertEquals("R1C1", table.getObject("Row1", "Col1"));
                                                                                                                assertEquals("R1C3", table.getObject("Row1", "Col3"));
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_ExistingColumn() {
                                                                                                                // Setup test data
                                                                                                                KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                Comparable rowKey1 = "Row1";
                                                                                                                Comparable columnKey1 = "Column1";
                                                                                                                Comparable columnKey2 = "Column2";
                                                                                                                
                                                                                                                // Add test data
                                                                                                                data.addObject("Value1", rowKey1, columnKey1);
                                                                                                                data.addObject("Value2", rowKey1, columnKey2);
                                                                                                                
                                                                                                                // Verify initial state
                                                                                                                assertEquals(2, data.getColumnCount());
                                                                                                                assertNotNull(data.getObject(rowKey1, columnKey1));
                                                                                                                
                                                                                                                // Remove column
                                                                                                                data.removeColumn(columnKey1);
                                                                                                                
                                                                                                                // Verify column was removed
                                                                                                                assertEquals(1, data.getColumnCount());
                                                                                                                assertNull(data.getObject(rowKey1, columnKey1));
                                                                                                                assertNotNull(data.getObject(rowKey1, columnKey2));
                                                                                                                assertFalse(data.getColumnKeys().contains(columnKey1));
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_NonExistingColumn() {
                                                                                                                org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                thrown.expect(UnknownKeyException.class);
                                                                                                                thrown.expectMessage("Column key (NonExistingCol) not recognised.");
                                                                                                                
                                                                                                                KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                data.removeColumn("NonExistingCol");
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_NullKey() {
                                                                                                                org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                thrown.expect(UnknownKeyException.class);
                                                                                                                thrown.expectMessage("Column key (null) not recognised.");
                                                                                                                
                                                                                                                KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                data.removeColumn(null);
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_MultipleCalls() {
                                                                                                                // Setup test data
                                                                                                                KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                String columnKey1 = "Col1";
                                                                                                                String columnKey2 = "Col2";
                                                                                                                String rowKey = "Row1";
                                                                                                                
                                                                                                                // Add some test data
                                                                                                                data.addObject("Value1", rowKey, columnKey1);
                                                                                                                data.addObject("Value2", rowKey, columnKey2);
                                                                                                                
                                                                                                                // First removal should succeed
                                                                                                                data.removeColumn(columnKey1);
                                                                                                                assertEquals(1, data.getColumnCount());
                                                                                                                
                                                                                                                // Second removal should fail
                                                                                                                thrown.expect(UnknownKeyException.class);
                                                                                                                thrown.expectMessage("Column key (" + columnKey1 + ") not recognised.");
                                                                                                                data.removeColumn(columnKey1);
                                                                                                            }

 @Test
                                                                                                            public void testRemoveColumn_LastColumn1() {
                                                                                                                // Setup test data with two columns
                                                                                                                KeyedObjects2D data = new KeyedObjects2D();
                                                                                                                Comparable columnKey1 = "Column1";
                                                                                                                Comparable columnKey2 = "Column2";
                                                                                                                Comparable rowKey = "Row1";
                                                                                                                data.addObject("Value1", rowKey, columnKey1);
                                                                                                                data.addObject("Value2", rowKey, columnKey2);
                                                                                                                
                                                                                                                // Remove one column first
                                                                                                                data.removeColumn(columnKey1);
                                                                                                                
                                                                                                                // Now remove the last remaining column
                                                                                                                data.removeColumn(columnKey2);
                                                                                                                
                                                                                                                // Verify all columns are gone
                                                                                                                assertEquals(0, data.getColumnCount());
                                                                                                                assertTrue(data.getColumnKeys().isEmpty());
                                                                                                            }

 @Test
                                                                        public void testRemoveRow_VerifyRowsConsistency() {
                                                                            // Create test fixture
                                                                            KeyedObjects2D keyedObjects = new KeyedObjects2D();
                                                                            
                                                                            // Add test data
                                                                            keyedObjects.addObject("R0C0", "Row0", "Col0");
                                                                            keyedObjects.addObject("R1C0", "Row1", "Col0");
                                                                            keyedObjects.addObject("R2C0", "Row2", "Col0");
                                                                            
                                                                            // Get expected row keys (excluding the one we'll remove)
                                                                            List<Comparable> expectedRowKeys = new ArrayList<Comparable>();
                                                                            expectedRowKeys.add("Row0");
                                                                            expectedRowKeys.add("Row2");
                                                                            
                                                                            // Get expected values (excluding the one we'll remove)
                                                                            List<Object> expectedValues = new ArrayList<Object>();
                                                                            expectedValues.add("R0C0");
                                                                            expectedValues.add("R2C0");
                                                                            
                                                                            // Perform the removal
                                                                            keyedObjects.removeRow(1);
                                                                            
                                                                            // Verify results
                                                                            assertEquals(expectedRowKeys.size(), keyedObjects.getRowCount());
                                                                            for (int i = 0; i < expectedRowKeys.size(); i++) {
                                                                                assertEquals(expectedRowKeys.get(i), keyedObjects.getRowKey(i));
                                                                                assertEquals(expectedValues.get(i), keyedObjects.getObject(i, 0));
                                                                            }
                                                                        }

 @Test
                                                                        public void testRemoveColumn_VerifyRowDataCleanup() {
                                                                            // Setup test data
                                                                            KeyedObjects2D data = new KeyedObjects2D();
                                                                            Comparable<String> rowKey1 = "Row1";
                                                                            Comparable<String> rowKey2 = "Row2";
                                                                            Comparable<String> columnKey1 = "Column1";
                                                                            Comparable<String> columnKey2 = "Column2";
                                                                            
                                                                            // Add test data
                                                                            data.addObject("Value11", rowKey1, columnKey1);
                                                                            data.addObject("Value12", rowKey1, columnKey2);
                                                                            data.addObject("Value21", rowKey2, columnKey1);
                                                                            data.addObject("Value22", rowKey2, columnKey2);
                                                                            
                                                                            // Verify initial state
                                                                            assertEquals(2, data.getRowCount());
                                                                            
                                                                            // Remove column
                                                                            data.removeColumn(columnKey1);
                                                                            
                                                                            // Verify row data was cleaned up
                                                                            for (Object key : data.getRowKeys()) {
                                                                                Comparable<String> rowKey = (Comparable<String>) key;
                                                                                Object obj = data.getObject(rowKey, columnKey1);
                                                                                assertNull("Row data should be cleaned up", obj);
                                                                            }
                                                                        }

 @Test
                                public void testRemoveColumnWithListModification() {
                                    // Setup test data
                                    KeyedObjects2D data = new KeyedObjects2D();
                                    
                                    // Add sample data - 2 rows, 2 columns
                                    data.addObject("R1C1", "Row1", "Col1");
                                    data.addObject("R1C2", "Row1", "Col2");
                                    data.addObject("R2C1", "Row2", "Col1");
                                    data.addObject("R2C2", "Row2", "Col2");
                                    
                                    // Verify initial state
                                    assertEquals(2, data.getRowCount());
                                    assertEquals(2, data.getColumnCount());
                                    
                                    // Remove first column
                                    data.removeColumn(0);
                                    
                                    // Verify column was removed
                                    assertEquals(1, data.getColumnCount());
                                    assertEquals("Col2", data.getColumnKey(0));
                                    
                                    // Verify data was properly removed from all rows
                                    assertEquals("R1C2", data.getObject(0, 0));
                                    assertEquals("R2C2", data.getObject(1, 0));
                                    
                                    // Verify row count remains unchanged
                                    assertEquals(2, data.getRowCount());
                                    
                                    // Add another column to test list modification during iteration
                                    data.addObject("R1C3", "Row1", "Col3");
                                    data.addObject("R2C3", "Row2", "Col3");
                                    
                                    // Remove the newly added column
                                    data.removeColumn(1);
                                    
                                    // Final verification
                                    assertEquals(1, data.getColumnCount());
                                    assertEquals("Col2", data.getColumnKey(0));
                                    assertEquals("R1C2", data.getObject(0, 0));
                                    assertEquals("R2C2", data.getObject(1, 0));
                                }

 @Test
                               public void testRemoveColumnWithIteratorBehavior() {
                                   // Setup test data
                                   KeyedObjects2D table = new KeyedObjects2D();
                                   String columnKey = "Column1";
                                   String rowKey = "Row1";
                                   Object value = "TestValue";
                                   
                                   // Add test data
                                   table.addObject(value, rowKey, columnKey);
                                   
                                   // Mock the rows list to verify iterator behavior
                                   List<KeyedObjects> rows = mock(List.class);
                                   KeyedObjects rowData = mock(KeyedObjects.class);
                                   Iterator<KeyedObjects> iterator = mock(Iterator.class);
                                   when(rows.iterator()).thenReturn(iterator);
                                   when(iterator.hasNext()).thenReturn(true, false);
                                   when(iterator.next()).thenReturn(rowData);
                                   when(rowData.getIndex(columnKey)).thenReturn(0);
                                   
                                   // Use reflection to replace the rows field with our mock
                                   try {
                                       Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                                       rowsField.setAccessible(true);
                                       rowsField.set(table, rows);
                                   } catch (Exception e) {
                                       fail("Failed to set up test using reflection");
                                   }
                                   
                                   // Execute the method
                                   table.removeColumn(columnKey);
                                   
                                   // Verify the iterator behavior
                                   verify(rows).iterator();
                                   verify(rowData).removeValue(0);
                                   verify(rows).remove(columnKey);
                               }

 @Test
                           public void testRemoveColumnShouldRemoveDataAtCorrectIndex() {
                               // Setup test data
                               KeyedObjects2D data = new KeyedObjects2D();
                               String rowKey = "Row1";
                               String columnKey = "Column1";
                               Object testValue = "TestValue";
                               
                               // Add test data
                               data.addObject(testValue, rowKey, columnKey);
                               
                               // Verify initial state
                               assertEquals(1, data.getRowCount());
                               assertEquals(1, data.getColumnCount());
                               assertEquals(testValue, data.getObject(rowKey, columnKey));
                               
                               // Execute method under test
                               data.removeColumn(columnKey);
                               
                               // Verify post-conditions
                               assertEquals(0, data.getColumnCount()); // Column should be removed
                               assertFalse(data.getColumnKeys().contains(columnKey)); // Column key should be gone
                               assertNull(data.getObject(rowKey, columnKey)); // Data should be cleared
                               
                               // Verify row still exists (shouldn't be affected by column removal)
                               assertEquals(1, data.getRowCount());
                               assertTrue(data.getRowKeys().contains(rowKey));
                           }

 @Test
                           public void testRemoveColumnShouldRemoveValuesFromAllRows() {
                               // Setup test data
                               KeyedObjects2D table = new KeyedObjects2D();
                               
                               // Add sample data
                               String rowKey = "Row1";
                               String columnKey = "Column1";
                               Object testValue = "TestValue";
                               
                               table.addObject(testValue, rowKey, columnKey);
                               
                               // Verify data exists before removal
                               assertEquals(testValue, table.getObject(rowKey, columnKey));
                               
                               // Perform removal
                               table.removeColumn(columnKey);
                               
                               // Verify column key is removed
                               assertFalse(table.getColumnKeys().contains(columnKey));
                               
                               // Verify value is removed from row (this would fail with the mutant)
                               try {
                                   Object valueAfterRemoval = table.getObject(rowKey, columnKey);
                                   assertNull(valueAfterRemoval); // Should throw exception or return null
                               } catch (UnknownKeyException e) {
                                   // This is also acceptable behavior
                               }
                               
                               // Additional check - verify no rows contain the column value
                               for (int i = 0; i < table.getRowCount(); i++) {
                                   try {
                                       Object value = table.getObject(table.getRowKey(i), columnKey);
                                       assertNull(value);
                                   } catch (UnknownKeyException e) {
                                       // Expected
                                   }
                               }
                           }

 @Test
                          public void testRemoveColumnAtZeroIndex() {
                              // Setup test data
                              KeyedObjects2D data = new KeyedObjects2D();
                              
                              // Add some test data with multiple columns
                              data.addObject("val1", "row1", "col0");
                              data.addObject("val2", "row1", "col1");
                              data.addObject("val3", "row1", "col2");
                              
                              // Verify initial state (3 columns)
                              assertEquals(3, data.getColumnCount());
                              
                              // Test removing first column (index 0)
                              data.removeColumn(0);
                              
                              // Verify column was removed (should be 2 columns left)
                              assertEquals(2, data.getColumnCount());
                              
                              // Verify remaining columns are correct (col1 and col2)
                              assertEquals("val2", data.getObject("row1", "col1"));
                              assertEquals("val3", data.getObject("row1", "col2"));
                              
                              // Verify the removed column is gone
                              try {
                                  data.getObject("row1", "col0");
                                  fail("Expected to not find removed column");
                              } catch (Exception e) {
                                  // Expected behavior
                              }
                          }

 @Test
                          public void testRemoveColumnShouldRemoveValuesWhenColumnIndexIsZero() {
                              // Setup test data with a column at index 0
                              KeyedObjects2D table = new KeyedObjects2D();
                              String columnKey = "Column0";
                              String rowKey = "Row1";
                              
                              // Add test data
                              table.addObject("Value1", rowKey, columnKey);
                              table.addObject("Value2", rowKey, "Column1");
                              
                              // Verify initial state
                              assertEquals("Value1", table.getObject(rowKey, columnKey));
                              
                              // Execute the method under test
                              table.removeColumn(columnKey);
                              
                              // Verify the column was removed
                              try {
                                  table.getObject(rowKey, columnKey);
                                  fail("Expected UnknownKeyException");
                              } catch (UnknownKeyException e) {
                                  // Expected behavior
                              }
                              
                              // Verify the value at index 0 was removed (would fail with mutant)
                              // The row should now only contain "Value2" at index 0 (since original index 1 moves left)
                              assertEquals("Value2", table.getObject(rowKey, "Column1"));
                              assertEquals(1, table.getColumnCount());
                          }

 @Test
                         public void testRemoveColumnWithPositiveIndex() {
                             // Setup test data
                             KeyedObjects2D data = new KeyedObjects2D();
                             
                             // Add some test columns (we need at least 2 to test positive index)
                             data.addObject("val1", "row1", "col1");
                             data.addObject("val2", "row1", "col2");
                             data.addObject("val3", "row1", "col3");
                             
                             // Verify initial state
                             assertEquals(3, data.getColumnCount());
                             
                             // Test removing column at index 1 (positive index)
                             data.removeColumn(1);
                             
                             // Verify column was removed
                             assertEquals(2, data.getColumnCount());
                             
                             // Verify remaining columns are correct
                             assertEquals("col1", data.getColumnKey(0));
                             assertEquals("col3", data.getColumnKey(1));
                             
                             // Test removing column at index 0 (boundary case)
                             data.removeColumn(0);
                             assertEquals(1, data.getColumnCount());
                             assertEquals("col3", data.getColumnKey(0));
                         }

 @Test(expected = IndexOutOfBoundsException.class)
                         public void testRemoveColumnWithInvalidIndex() {
                             KeyedObjects2D data = new KeyedObjects2D();
                             data.addObject("val1", "row1", "col1");
                             
                             // This should throw exception
                             data.removeColumn(-1);
                         }

 @Test
                         public void testRemoveColumnShouldRemoveAllValuesForColumnKey() {
                             // Setup test data
                             KeyedObjects2D table = new KeyedObjects2D();
                             
                             // Add sample data with multiple columns
                             String rowKey = "row1";
                             String columnKey1 = "col1"; // Will have index > 0
                             String columnKey2 = "col2"; // Will have index > 0
                             Object value1 = new Object();
                             Object value2 = new Object();
                             
                             table.addObject(value1, rowKey, columnKey1);
                             table.addObject(value2, rowKey, columnKey2);
                             
                             // Verify columns exist before removal
                             assertEquals(value1, table.getObject(rowKey, columnKey1));
                             assertEquals(value2, table.getObject(rowKey, columnKey2));
                             
                             // Remove first column
                             table.removeColumn(columnKey1);
                             
                             // Verify column1 was removed but column2 remains
                             assertNull(table.getObject(rowKey, columnKey1)); // Should be null if properly removed
                             assertEquals(value2, table.getObject(rowKey, columnKey2)); // Should remain
                             
                             // The mutant would fail this test because:
                             // - For columnKey1 (index > 0), the mutated condition (i <= 0) would be false
                             // - So the value wouldn't be removed, and getObject() would still return value1
                             // - The assertion would fail as getObject() would not return null
                         }

 @Test(expected = IndexOutOfBoundsException.class)
                            public void testRemoveColumnWithNegativeIndexShouldThrowException() {
                                KeyedObjects2D data = new KeyedObjects2D();
                                
                                // Add some test data to ensure the object is in valid state
                                data.addObject("Test", "Row1", "Col1");
                                
                                // This should throw IndexOutOfBoundsException in original code
                                // But would proceed with mutation (if true) and likely fail later
                                data.removeColumn(-1);
                                
                                // If we get here without exception, the test fails
                                // (which would happen with the mutated code)
                            }

 @Test
                            public void testRemoveColumnWithNegativeIndexShouldNotModifyState() {
                                KeyedObjects2D data = new KeyedObjects2D();
                                data.addObject("Test", "Row1", "Col1");
                                
                                // Store original state
                                int originalRowCount = data.getRowCount();
                                int originalColumnCount = data.getColumnCount();
                                List originalRowKeys = new java.util.ArrayList(data.getRowKeys());
                                List originalColumnKeys = new java.util.ArrayList(data.getColumnKeys());
                                
                                try {
                                    data.removeColumn(-1);
                                } catch (IndexOutOfBoundsException e) {
                                    // Expected in original code
                                }
                                
                                // Verify state remains unchanged
                                assertEquals(originalRowCount, data.getRowCount());
                                assertEquals(originalColumnCount, data.getColumnCount());
                                assertEquals(originalRowKeys, data.getRowKeys());
                                assertEquals(originalColumnKeys, data.getColumnKeys());
                            }

 @Test
                       public void testRemoveColumnShouldNotRemoveFromRowsWithoutColumnKey() throws Exception {
                           // Setup test data
                           KeyedObjects2D table = new KeyedObjects2D();
                           
                           // Add column keys
                           String existingColumn = "Column1";
                           table.getColumnKeys().add(existingColumn);
                           
                           // Add rows - one with the column, one without
                           KeyedObjects rowWithColumn = mock(KeyedObjects.class);
                           when(rowWithColumn.getIndex(existingColumn)).thenReturn(0);
                           
                           KeyedObjects rowWithoutColumn = mock(KeyedObjects.class);
                           when(rowWithoutColumn.getIndex(existingColumn)).thenReturn(-1);
                           
                           // Use reflection to access private 'rows' field
                           Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                           rowsField.setAccessible(true);
                           @SuppressWarnings("unchecked")
                           List<KeyedObjects> rows = (List<KeyedObjects>) rowsField.get(table);
                           rows.add(rowWithColumn);
                           rows.add(rowWithoutColumn);
                           
                           // Execute
                           table.removeColumn(existingColumn);
                           
                           // Verify
                           // Should call removeValue only for row with column
                           verify(rowWithColumn).removeValue(0);
                           verify(rowWithoutColumn, never()).removeValue(anyInt());
                           
                           // Also verify column key was removed
                           assertFalse(table.getColumnKeys().contains(existingColumn));
                       }

 @Test
                   public void testRemoveColumnWithValidIndexShouldRemoveColumn() {
                       // Setup
                       KeyedObjects2D data = new KeyedObjects2D();
                       
                       // Add test data
                       Comparable rowKey = "Row1";
                       Comparable columnKey = "Column1";
                       Object value = "TestValue";
                       data.addObject(value, rowKey, columnKey);
                       
                       // Verify initial state
                       assertEquals(1, data.getColumnCount());
                       assertEquals(value, data.getObject(rowKey, columnKey));
                       
                       // Get column index (should be 0 since it's the first column)
                       int columnIndex = data.getColumnIndex(columnKey);
                       assertTrue(columnIndex >= 0); // Ensure we have a valid index
                       
                       // Action - this should remove the column in original version
                       data.removeColumn(columnIndex);
                       
                       // Verification - original would have 0 columns, mutant would still have 1
                       assertEquals(0, data.getColumnCount());
                       
                       // Additional verification that the column was actually removed
                       try {
                           data.getObject(rowKey, columnKey);
                           fail("Expected to throw exception when accessing removed column");
                       } catch (Exception e) {
                           // Expected behavior
                       }
                   }

 @Test
                   public void testRemoveColumnShouldRemoveValuesFromAllRows1() {
                       // Setup test data
                       KeyedObjects2D table = new KeyedObjects2D();
                       String columnKey = "Column1";
                       String rowKey = "Row1";
                       Object testValue = "TestValue";
                       
                       // Add a column and row with a value
                       table.addObject(testValue, rowKey, columnKey);
                       
                       // Verify the value exists before removal
                       assertEquals(testValue, table.getObject(rowKey, columnKey));
                       
                       // Execute the method under test
                       table.removeColumn(columnKey);
                       
                       // Verify the column was removed from columnKeys
                       assertFalse(table.getColumnKeys().contains(columnKey));
                       
                       // This assertion will catch the mutant - the value should be removed from the row
                       try {
                           Object valueAfterRemoval = table.getObject(rowKey, columnKey);
                           fail("Expected exception when getting value from removed column");
                       } catch (UnknownKeyException e) {
                           // Expected behavior - column was removed
                       }
                       
                       // Additional verification that the row still exists but without the column
                       assertTrue(table.getRowKeys().contains(rowKey));
                       assertEquals(0, table.getColumnCount());
                   }

 @Test
                 public void testRemoveColumnWithListIteratorMutant() {
                     // Setup test data
                     KeyedObjects2D data = new KeyedObjects2D();
                     
                     // Add sample data with multiple rows and columns
                     data.addObject("R1C1", "Row1", "Col1");
                     data.addObject("R1C2", "Row1", "Col2");
                     data.addObject("R2C1", "Row2", "Col1");
                     data.addObject("R2C2", "Row2", "Col2");
                     
                     // Verify initial state
                     assertEquals(2, data.getRowCount());
                     assertEquals(2, data.getColumnCount());
                     assertEquals("R1C1", data.getObject("Row1", "Col1"));
                     assertEquals("R1C2", data.getObject("Row1", "Col2"));
                     
                     // Remove first column
                     data.removeColumn(0);
                     
                     // Verify column was removed from all rows
                     assertEquals(2, data.getRowCount());
                     assertEquals(1, data.getColumnCount());
                     assertNull(data.getObject("Row1", "Col1"));  // Should be removed
                     assertEquals("R1C2", data.getObject("Row1", "Col2"));  // Should remain
                     assertNull(data.getObject("Row2", "Col1"));  // Should be removed
                     assertEquals("R2C2", data.getObject("Row2", "Col2"));  // Should remain
                     
                     // Verify column keys were updated
                     assertEquals(1, data.getColumnKeys().size());
                     assertEquals("Col2", data.getColumnKeys().get(0));
                     
                     // Verify row data structure integrity using reflection
                     try {
                         Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                         rowsField.setAccessible(true);
                         List rows = (List) rowsField.get(data);
                         
                         for (Object row : rows) {
                             // Each row should now contain only one entry (for Col2)
                             assertEquals(1, ((KeyedObjects)row).getItemCount());
                         }
                     } catch (Exception e) {
                         fail("Failed to access private 'rows' field: " + e.getMessage());
                     }
                 }

 @Test
             public void testRemoveColumnIteratorBehavior() {
                 // Setup test data
                 KeyedObjects2D table = new KeyedObjects2D();
                 String columnKey = "Column1";
                 String rowKey = "Row1";
                 
                 // Add test data
                 table.addObject("Value1", rowKey, columnKey);
                 table.addObject("Value2", rowKey, "Column2");
                 
                 // Mock the rows list to detect iterator type used
                 List<KeyedObjects> rows = new ArrayList<KeyedObjects>() {
                     @Override
                     public Iterator<KeyedObjects> iterator() {
                         throw new RuntimeException("Should use iterator()");
                     }
                     
                     @Override
                     public java.util.ListIterator<KeyedObjects> listIterator() {
                         throw new RuntimeException("Should not use listIterator()");
                     }
                 };
                 
                 // Replace the rows list with our mock version
                 try {
                     Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                     rowsField.setAccessible(true);
                     rowsField.set(table, rows);
                     
                     // This should throw if listIterator() is used
                     table.removeColumn(columnKey);
                 } catch (Exception e) {
                     // Verify the exception message indicates wrong iterator was used
                     if (e.getCause() != null && e.getCause().getMessage().contains("listIterator()")) {
                         fail("Method used listIterator() instead of iterator()");
                     }
                 }
                 
                 // Additional verification that the operation completed successfully
                 // (for the case where we don't use the mock)
                 table = new KeyedObjects2D();
                 table.addObject("Value1", rowKey, columnKey);
                 table.addObject("Value2", rowKey, "Column2");
                 
                 table.removeColumn(columnKey);
                 assertEquals(1, table.getColumnCount());
                 assertEquals(-1, table.getColumnIndex(columnKey));
             }

 @Test
         public void testRemoveColumnActuallyRemovesData() {
             // Setup test data
             KeyedObjects2D data = new KeyedObjects2D();
             
             // Add sample data
             data.addObject("R1C1", "Row1", "Col1");
             data.addObject("R1C2", "Row1", "Col2");
             data.addObject("R2C1", "Row2", "Col1");
             data.addObject("R2C2", "Row2", "Col2");
             
             // Verify initial state
             assertEquals(2, data.getColumnCount());
             assertEquals("Col1", data.getColumnKey(0));
             assertEquals("Col2", data.getColumnKey(1));
             
             // Remove first column
             data.removeColumn(0);
             
             // Verify column was actually removed
             assertEquals(1, data.getColumnCount());
             assertEquals("Col2", data.getColumnKey(0));
             
             // Verify data was removed from all rows
             assertEquals("R1C2", data.getObject("Row1", "Col2"));
             assertEquals("R2C2", data.getObject("Row2", "Col2"));
             assertNull(data.getObject("Row1", "Col1"));
             assertNull(data.getObject("Row2", "Col1"));
             
             // Verify column keys were updated
             assertEquals(1, data.getColumnKeys().size());
             assertEquals("Col2", data.getColumnKeys().get(0));
         }

 @Test
        public void testRemoveColumnRemovesValuesFromRows() {
            // Setup test data
            KeyedObjects2D table = new KeyedObjects2D();
            String columnKey = "Column1";
            String rowKey = "Row1";
            Object testValue = "TestValue";
            
            // Add test data
            table.addObject(testValue, rowKey, columnKey);
            
            // Verify data exists before removal
            assertEquals(testValue, table.getObject(rowKey, columnKey));
            
            // Perform removal
            table.removeColumn(columnKey);
            
            // Verify column key was removed
            assertFalse(table.getColumnKeys().contains(columnKey));
            
            // Verify value was removed from row (this would fail with the mutant)
            try {
                Object valueAfterRemoval = table.getObject(rowKey, columnKey);
                fail("Expected to throw UnknownKeyException after removal");
            } catch (UnknownKeyException e) {
                // Expected behavior
            }
            
            // Alternative verification - check row data directly using reflection
            try {
                Field rowsField = KeyedObjects2D.class.getDeclaredField("rows");
                rowsField.setAccessible(true);
                List rows = (List) rowsField.get(table);
                int rowIndex = table.getRowIndex(rowKey);
                KeyedObjects rowData = (KeyedObjects) rows.get(rowIndex);
                assertFalse(rowData.getKeys().contains(columnKey));
            } catch (Exception e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }

 @Test
    public void testRemoveColumnAtZeroIndex1() {
        // Setup test data
        KeyedObjects2D data = new KeyedObjects2D();
        String columnKey = "Column0";
        String rowKey = "Row1";
        Object testObj = new Object();
        
        // Add a column at index 0
        data.addObject(testObj, rowKey, columnKey);
        
        // Verify column exists before removal
        assertEquals(1, data.getColumnCount());
        assertEquals(testObj, data.getObject(rowKey, columnKey));
        
        // Perform removal of column at index 0
        data.removeColumn(0);
        
        // Verify column was removed (original behavior)
        assertEquals(0, data.getColumnCount());
        
        // The mutant would fail this test because:
        // - With mutation (i > 0), column at index 0 wouldn't be removed
        // - So columnCount would remain 1 and getObject wouldn't throw
        // - Original (i >= 0) would remove it properly
    }

 @Test
    public void testRemoveColumnShouldRemoveValueAtColumnIndexZero() {
        // Setup test data
        KeyedObjects2D table = new KeyedObjects2D();
        String columnKey = "Column0";
        String rowKey = "Row1";
        Object testValue = "TestValue";
        
        // Add a column that will be at index 0
        table.addObject(testValue, rowKey, columnKey);
        
        // Verify the value exists before removal
        assertEquals(testValue, table.getObject(rowKey, columnKey));
        
        // Execute the method under test
        table.removeColumn(columnKey);
        
        // Verify the column was removed (this checks the main functionality)
        try {
            table.getObject(rowKey, columnKey);
            fail("Expected UnknownKeyException");
        } catch (UnknownKeyException e) {
            // Expected behavior
        }
        
        // Additional verification that would catch the mutant:
        // For the original code, the value at index 0 should have been removed from the row
        // before the column was removed. The mutant would skip removing it.
        // We can verify this by checking if the row still contains the value (mutant case)
        // or not (original case)
        
        // Since we can't directly access the internal rows list, we can add another column
        // and verify the remaining values. In the original code, the row should be empty,
        // while in the mutant case it would still contain the testValue.
        
        // Add another column to the same row
        String anotherColumn = "Column1";
        table.addObject("AnotherValue", rowKey, anotherColumn);
        
        // Now remove the new column
        table.removeColumn(anotherColumn);
        
        // Try to get any remaining objects for the row
        // In original code, there should be no values left
        // In mutant code, the testValue would still be there
        try {
            Object remaining = table.getObject(rowKey, columnKey);
            // If we get here, it means the value wasn't removed (mutant case)
            fail("Expected UnknownKeyException - value at index 0 was not removed");
        } catch (UnknownKeyException e) {
            // This is the expected behavior for original code
        }
    }

 @Test
   public void testRemoveColumnWithPositiveIndex1() {
       // Setup test data
       KeyedObjects2D data = new KeyedObjects2D();
       
       // Add multiple columns to ensure we test positive indices
       data.addObject("obj1", "row1", "col1"); // index 0
       data.addObject("obj2", "row1", "col2"); // index 1
       data.addObject("obj3", "row1", "col3"); // index 2
       
       // Verify initial column count
       assertEquals(3, data.getColumnCount());
       
       // Try to remove column at index 1 (positive index)
       data.removeColumn(1);
       
       // Verify column was removed (original behavior)
       // If mutation exists (i <= 0), column wouldn't be removed
       assertEquals(2, data.getColumnCount());
       
       // Verify correct column was removed
       assertFalse(data.getColumnKeys().contains("col2"));
       assertTrue(data.getColumnKeys().contains("col1"));
       assertTrue(data.getColumnKeys().contains("col3"));
   }

 @Test
   public void testRemoveColumnDetectsMutatedCondition() {
       // Setup test data
       KeyedObjects2D table = new KeyedObjects2D();
       
       // Add some test data with multiple columns
       String rowKey = "Row1";
       String columnKey1 = "Col1"; // Will have index > 0
       String columnKey2 = "Col2"; // Will have index > 0
       Object value1 = "Value1";
       Object value2 = "Value2";
       
       // Add data to the table
       table.addObject(value1, rowKey, columnKey1);
       table.addObject(value2, rowKey, columnKey2);
       
       // Verify initial state
       assertEquals(value1, table.getObject(rowKey, columnKey1));
       assertEquals(value2, table.getObject(rowKey, columnKey2));
       
       // Remove column1 (index > 0)
       table.removeColumn(columnKey1);
       
       // Test the critical behavior:
       // Original: column1 value should be removed (i >= 0)
       // Mutant: column1 value would remain (i <= 0 would be false for positive index)
       try {
           assertNull("Column1 value should be removed", table.getObject(rowKey, columnKey1));
           // If we get here, the test passes (original behavior)
       } catch (UnknownKeyException e) {
           // This is also acceptable as the column might be completely removed
       }
       
       // Verify column2 remains unaffected
       assertEquals(value2, table.getObject(rowKey, columnKey2));
       
       // Additional test for index 0 case
       // Add a new column that will be at index 0
       String columnKey0 = "Col0";
       Object value0 = "Value0";
       table.addObject(value0, rowKey, columnKey0);
       
       // Remove column0 (index = 0)
       table.removeColumn(columnKey0);
       
       // Both original and mutant should remove index 0
       try {
           assertNull("Column0 value should be removed", table.getObject(rowKey, columnKey0));
       } catch (UnknownKeyException e) {
           // Also acceptable
       }
   }

 @Test
      public void testRemoveColumnWithNegativeIndexShouldFail() {
          KeyedObjects2D table = new KeyedObjects2D();
          
          // Add some test data
          table.addObject("Data1", "Row1", "Column1");
          table.addObject("Data2", "Row2", "Column2");
          
          // Set expectation for original behavior (should throw exception)
          thrown.expect(IndexOutOfBoundsException.class);
          
          // Try to remove column with negative index
          table.removeColumn(-1);
          
          // If we reach here, the mutant survived (no exception thrown)
          fail("Expected IndexOutOfBoundsException for negative column index");
      }

 @Test
      public void testRemoveColumnWithValidIndexShouldPass() {
          KeyedObjects2D table = new KeyedObjects2D();
          
          // Add test data
          table.addObject("Data1", "Row1", "Column1");
          table.addObject("Data2", "Row2", "Column2");
          
          // Original column count
          int originalCount = table.getColumnCount();
          
          // Remove valid column (index 0)
          table.removeColumn(0);
          
          // Verify column was removed
          assertEquals(originalCount - 1, table.getColumnCount());
      }

 @Test
  public void testRemoveColumnShouldNotRemoveFromRowsWithoutColumnKey1() {
      // Setup test data
      KeyedObjects2D table = new KeyedObjects2D();
      Comparable rowKey1 = "Row1";
      Comparable rowKey2 = "Row2";
      Comparable columnKey = "Column1";
      
      // Add data - Row1 has Column1, Row2 doesn't
      table.addObject("Value1", rowKey1, columnKey);
      table.addObject("Value2", rowKey2, "Column2"); // Different column
      
      // Store original row data for comparison
      Object row2OriginalValue = table.getObject(rowKey2, "Column2");
      
      // Execute
      table.removeColumn(columnKey);
      
      // Verify
      // Row1 should have column removed (original behavior)
      try {
          table.getObject(rowKey1, columnKey);
          fail("Expected exception for removed column");
      } catch (UnknownKeyException e) {
          // Expected
      }
      
      // Row2 should remain unchanged (tests the mutant)
      assertEquals(row2OriginalValue, table.getObject(rowKey2, "Column2"));
      assertEquals(1, table.getColumnCount()); // Only Column2 should remain
  }

 @Test
 public void testRemoveColumnWithValidIndexShouldRemoveColumn1() {
     // Setup
     KeyedObjects2D data = new KeyedObjects2D();
     String columnKey = "Column1";
     String rowKey = "Row1";
     Object value = new Object();
     
     // Add test data
     data.addObject(value, rowKey, columnKey);
     
     // Verify column exists before removal
     assertEquals(1, data.getColumnCount());
     assertEquals(value, data.getObject(rowKey, columnKey));
     
     // Get the column index (should be 0 since it's the first column)
     int columnIndex = data.getColumnIndex(columnKey);
     assertTrue(columnIndex >= 0); // Ensure we have a valid index
     
     // Execute removal
     data.removeColumn(columnIndex);
     
     // Verify column was removed
     assertEquals(0, data.getColumnCount());
     assertNull(data.getObject(rowKey, columnKey));
 }

 @Test
 public void testRemoveColumnActuallyRemovesValuesFromRows() {
     // Setup test data
     KeyedObjects2D table = new KeyedObjects2D();
     String columnKey = "Column1";
     String rowKey = "Row1";
     Object testValue = "TestValue";
     
     // Add test data
     table.addObject(testValue, rowKey, columnKey);
     
     // Verify initial state
     assertEquals(1, table.getRowCount());
     assertEquals(1, table.getColumnCount());
     assertEquals(testValue, table.getObject(rowKey, columnKey));
     
     // Execute method under test
     table.removeColumn(columnKey);
     
     // Verify column key was removed
     assertEquals(0, table.getColumnCount());
     
     // Verify value was removed from row - THIS WILL FAIL FOR THE MUTANT
     try {
         Object valueAfterRemoval = table.getObject(rowKey, columnKey);
         fail("Expected exception when getting value from removed column");
     } catch (UnknownKeyException e) {
         // Expected behavior - column was removed
     }
     
     // Additional verification - check row still exists but without the column
     assertEquals(1, table.getRowCount());
     assertEquals(0, table.getColumnCount());
 }

}
