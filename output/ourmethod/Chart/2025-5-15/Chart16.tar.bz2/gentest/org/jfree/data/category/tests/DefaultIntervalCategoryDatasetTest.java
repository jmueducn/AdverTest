package gentest.org.jfree.data.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.category.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import org.jfree.data.DataUtilities;
import org.jfree.data.UnknownKeyException;
import org.jfree.data.general.AbstractSeriesDataset;
 
public class DefaultIntervalCategoryDatasetTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                              public void testSetCategoryKeys_NullInput() {
                                                  // Setup test data
                                                  Number[][] startData = {{1, 2}, {3, 4}};
                                                  Number[][] endData = {{5, 6}, {7, 8}};
                                                  Comparable[] seriesKeys = {"Series1", "Series2"};
                                                  
                                                  // Create dataset
                                                  DefaultIntervalCategoryDataset dataset = 
                                                      new DefaultIntervalCategoryDataset(seriesKeys, null, startData, endData);
                                                  
                                                  // Expect exception
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("Null 'categoryKeys' argument.");
                                                  
                                                  // Test with null input
                                                  dataset.setCategoryKeys(null);
                                              }

 @Test
                                              public void testSetCategoryKeys_WrongLength() {
                                                  // Setup test data
                                                  Number[][] startData = {{1, 2}, {3, 4}};
                                                  Number[][] endData = {{5, 6}, {7, 8}};
                                                  Comparable[] seriesKeys = {"Series1", "Series2"};
                                                  Comparable[] wrongLengthKeys = {"OnlyOne"};
                                                  
                                                  // Create dataset
                                                  DefaultIntervalCategoryDataset dataset = 
                                                      new DefaultIntervalCategoryDataset(seriesKeys, null, startData, endData);
                                                  
                                                  // Expect exception
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("The number of categories does not match the data.");
                                                  
                                                  // Test with wrong length array
                                                  dataset.setCategoryKeys(wrongLengthKeys);
                                              }

 @Test
                                              public void testSetCategoryKeys_ContainsNull() {
                                                  // Setup test data
                                                  Number[][] startData = {{1, 2}, {3, 4}};
                                                  Number[][] endData = {{5, 6}, {7, 8}};
                                                  Comparable[] seriesKeys = {"Series1", "Series2"};
                                                  Comparable[] keysWithNull = {"Category1", null};
                                                  
                                                  // Create dataset
                                                  DefaultIntervalCategoryDataset dataset = 
                                                      new DefaultIntervalCategoryDataset(seriesKeys, null, startData, endData);
                                                  
                                                  // Expect exception
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("DefaultIntervalCategoryDataset.setCategoryKeys(): null category not permitted.");
                                                  
                                                  // Test with array containing null
                                                  dataset.setCategoryKeys(keysWithNull);
                                              }

 @Test
                                              public void testSetCategoryKeys_EmptyDataset() {
                                                  // Create empty dataset
                                                  DefaultIntervalCategoryDataset dataset = 
                                                      new DefaultIntervalCategoryDataset(new Number[0][0], new Number[0][0]);
                                                  
                                                  // Should work with empty array
                                                  dataset.setCategoryKeys(new Comparable[0]);
                                                  
                                                  assertEquals(0, dataset.getCategoryCount());
                                              }

 @Test
                                      public void testSetCategoryKeys_ValidInput() {
                                          // Setup test data
                                          Number[][] startData = {{1, 2}, {3, 4}};
                                          Number[][] endData = {{5, 6}, {7, 8}};
                                          Comparable[] seriesKeys = {"Series1", "Series2"};
                                          Comparable[] categoryKeys = {"Category1", "Category2"};
                                          
                                          // Create dataset with 2 categories
                                          DefaultIntervalCategoryDataset dataset = 
                                              new DefaultIntervalCategoryDataset(seriesKeys, null, startData, endData);
                                          
                                          // Test valid category keys
                                          dataset.setCategoryKeys(categoryKeys);
                                          
                                          // Verify category keys were set
                                          assertEquals(2, dataset.getCategoryCount());
                                          assertEquals("Category1", dataset.getColumnKeys().get(0));
                                          assertEquals("Category2", dataset.getColumnKeys().get(1));
                                      }

 @Test
                                      public void testSetCategoryKeys_FireDatasetChanged() {
                                          // Setup test data
                                          Number[][] startData = {{1}};
                                          Number[][] endData = {{2}};
                                          Comparable[] seriesKeys = {"Series1"};
                                          Comparable[] categoryKeys = {"Category1"};
                                          
                                          // Create dataset and spy on it to verify fireDatasetChanged is called
                                          DefaultIntervalCategoryDataset dataset = 
                                              new DefaultIntervalCategoryDataset(seriesKeys, null, startData, endData);
                                          DefaultIntervalCategoryDataset spyDataset = spy(dataset);
                                          
                                          // Set category keys
                                          spyDataset.setCategoryKeys(categoryKeys);
                                          
                                          // Verify fireDatasetChanged was called by checking if categoryKeys were updated
                                          assertEquals(categoryKeys, spyDataset.getColumnKeys().toArray(new Comparable[0]));
                                      }

 @Test(expected = IllegalArgumentException.class)
                                  public void testSetCategoryKeys_WhenCategoryKeysLongerThanCategoryCount_ShouldThrowException() {
                                      // Setup test data
                                      DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                                          new Number[][]{{1, 2}, {3, 4}}, 
                                          new Number[][]{{5, 6}, {7, 8}}
                                      );
                                      
                                      // Current category count is 2 (from the constructor)
                                      // Create categoryKeys array with 3 elements (longer than category count)
                                      Comparable[] categoryKeys = new Comparable[]{"A", "B", "C"};
                                      
                                      // This should throw IllegalArgumentException in original code
                                      // But would pass in mutated code (categoryKeys.length > getCategoryCount())
                                      dataset.setCategoryKeys(categoryKeys);
                                      
                                      // If we reach here, the test fails (mutant survived)
                                      // The @Test(expected) annotation will verify the exception is thrown
                                  }

 @Test
                                 public void testSetCategoryKeysWithChangingCategoryCount() {
                                     // Create a spy of the dataset to control getCategoryCount() behavior
                                     DefaultIntervalCategoryDataset dataset = spy(new DefaultIntervalCategoryDataset(
                                         new Number[][]{{1, 2}}, new Number[][]{{3, 4}}));
                                     
                                     // Make getCategoryCount() return different values on subsequent calls
                                     when(dataset.getCategoryCount())
                                         .thenReturn(2)  // first call returns correct count
                                         .thenReturn(3); // second call returns different count
                                     
                                     Comparable[] validKeys = {"A", "B"};
                                     
                                     try {
                                         dataset.setCategoryKeys(validKeys);
                                         // If we get here, the mutation wasn't caught
                                         fail("Expected IllegalArgumentException but none was thrown");
                                     } catch (IllegalArgumentException e) {
                                         // Verify the correct exception was thrown
                                         assertEquals("The number of categories does not match the data.", e.getMessage());
                                     }
                                     
                                     // Verify getCategoryCount() was called exactly once during validation
                                     verify(dataset, times(1)).getCategoryCount();
                                 }

 @Test
                                public void testSetCategoryKeysWithMatchingLengthShouldNotThrowException() {
                                    // Setup test data
                                    Number[][] starts = {{1, 2}, {3, 4}}; // 2 series, 2 categories
                                    Number[][] ends = {{5, 6}, {7, 8}};
                                    DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
                                    
                                    // Current category count should be 2 (from constructor)
                                    Comparable[] validKeys = {"Cat1", "Cat2"}; // Length matches category count
                                    
                                    // This should NOT throw exception in original code, but WILL throw in mutant
                                    dataset.setCategoryKeys(validKeys);
                                    
                                    // Verify keys were set
                                    assertEquals(validKeys, dataset.getColumnKeys().toArray());
                                }

 @Test(expected = IllegalArgumentException.class)
                                public void testSetCategoryKeysWithNonMatchingLengthShouldThrowException() {
                                    // Setup test data
                                    Number[][] starts = {{1, 2}, {3, 4}}; // 2 series, 2 categories
                                    Number[][] ends = {{5, 6}, {7, 8}};
                                    DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
                                    
                                    // Current category count should be 2 (from constructor)
                                    Comparable[] invalidKeys = {"Cat1", "Cat2", "Cat3"}; // Length doesn't match
                                    
                                    // This SHOULD throw exception in original code, but WON'T throw in mutant
                                    dataset.setCategoryKeys(invalidKeys);
                                }

 @Test(expected = IllegalArgumentException.class)
                               public void testSetCategoryKeysWithFewerElementsThanCategoryCount() {
                                   // Setup test data
                                   Number[][] starts = {{1, 2, 3}, {4, 5, 6}}; // 2 series, 3 categories
                                   Number[][] ends = {{7, 8, 9}, {10, 11, 12}};
                                   DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
                                   
                                   // Current category count should be 3 (from constructor)
                                   // Prepare category keys with only 2 elements (less than category count)
                                   Comparable[] categoryKeys = {"Cat1", "Cat2"};
                                   
                                   // This should throw IllegalArgumentException in original code
                                   // But would pass in mutated code (which we want to detect)
                                   dataset.setCategoryKeys(categoryKeys);
                               }

 @Test(expected = IllegalArgumentException.class)
                             public void testSetCategoryKeys_NullArray() {
                                 Number[][] starts = new Number[][]{{1, 2}, {3, 4}};
                                 Number[][] ends = new Number[][]{{5, 6}, {7, 8}};
                                 DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
                                 dataset.setCategoryKeys(null);
                             }

 @Test(expected = IllegalArgumentException.class)
                             public void testSetCategoryKeys_WrongLengthArray() {
                                 // Create dataset with 2 categories
                                 Number[][] starts = {{1.0, 2.0}, {3.0, 4.0}};
                                 Number[][] ends = {{5.0, 6.0}, {7.0, 8.0}};
                                 DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
                                 
                                 // Try to set category keys with wrong length (1 instead of 2)
                                 Comparable[] keys = {"A"}; // Only 1 key when we need 2
                                 dataset.setCategoryKeys(keys);
                             }

 @Test(expected = IllegalArgumentException.class)
                             public void testSetCategoryKeys_NullElementInArray() {
                                 // Create a valid dataset first
                                 Number[][] starts = {{1.0, 2.0}, {3.0, 4.0}};
                                 Number[][] ends = {{5.0, 6.0}, {7.0, 8.0}};
                                 DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
                                 
                                 // Test with array containing null element
                                 Comparable[] keys = {"A", null}; // Second element is null
                                 dataset.setCategoryKeys(keys);
                             }

 @Test
                             public void testSetCategoryKeys_ValidInput1() {
                                 // Create sample data for 1 series and 2 categories
                                 Number[][] starts = {{1.0, 2.0}};
                                 Number[][] ends = {{3.0, 4.0}};
                                 DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
                                 
                                 Comparable[] keys = {"A", "B"};
                                 dataset.setCategoryKeys(keys);
                                 assertArrayEquals(keys, dataset.getColumnKeys().toArray());
                             }

 @Test(expected = IllegalArgumentException.class)
                         public void testSetCategoryKeysWithNullElementShouldThrowExceptionWithSpecificMessage() {
                             // Setup
                             DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(new Number[1][1], new Number[1][1]);
                             Comparable[] categoryKeys = new Comparable[] {"Valid", null}; // Second element is null
                             
                             // This is needed because getCategoryCount() is used in validation
                             // We'll set up the dataset to expect 2 categories
                             Number[][] starts = new Number[][] {{1, 2}};
                             Number[][] ends = new Number[][] {{3, 4}};
                             dataset = new DefaultIntervalCategoryDataset(new Comparable[] {"Series1"}, 
                                                                       new Comparable[] {"Cat1", "Cat2"}, 
                                                                       starts, ends);
                             
                             try {
                                 dataset.setCategoryKeys(categoryKeys);
                                 fail("Expected IllegalArgumentException to be thrown");
                             } catch (IllegalArgumentException e) {
                                 // Verify the exception message contains the specific error text
                                 assertTrue("Exception message should contain 'null category not permitted'", 
                                           e.getMessage().contains("null category not permitted"));
                                 throw e; // rethrow to satisfy @Test(expected)
                             }
                         }

 @Test(expected = IllegalArgumentException.class)
                        public void testSetCategoryKeys_NullInput_ThrowsIllegalArgumentException() {
                            // Setup test data - create a dataset with some categories
                            Number[][] starts = {{1, 2}, {3, 4}};
                            Number[][] ends = {{5, 6}, {7, 8}};
                            DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                                new Comparable[]{"Series1", "Series2"}, 
                                new Comparable[]{"Cat1", "Cat2"},
                                starts, 
                                ends
                            );
                            
                            // This should throw IllegalArgumentException, not RuntimeException
                            dataset.setCategoryKeys(null);
                        }

 @Test(expected = IllegalArgumentException.class)
                       public void testSetCategoryKeys_NullArray_ShouldThrowIllegalArgumentException() {
                           // Setup test data
                           DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                               new Number[][]{{1}}, 
                               new Number[][]{{2}}
                           );
                           
                           // This should throw IllegalArgumentException (original behavior)
                           // If mutant exists, will throw NullPointerException instead
                           dataset.setCategoryKeys(null);
                       }

 @Test
                      public void testSetCategoryKeysStoresCorrectValue() throws Exception {
                          // Setup test data
                          Comparable[] validKeys = new Comparable[] {"Category1", "Category2"};
                          Number[][] starts = new Number[][] {{1, 2}, {3, 4}};
                          Number[][] ends = new Number[][] {{5, 6}, {7, 8}};
                          
                          // Create dataset with matching category count
                          DefaultIntervalCategoryDataset dataset = 
                              new DefaultIntervalCategoryDataset(starts, ends);
                          
                          // Store original count for verification
                          int originalCount = dataset.getCategoryCount();
                          
                          // Call method under test
                          dataset.setCategoryKeys(validKeys);
                          
                          // Verify the mutation by checking category count remains the same
                          // (since the keys were properly stored)
                          assertEquals("Category count should remain unchanged", 
                                      originalCount, dataset.getCategoryCount());
                          
                          // Additional verification using reflection to directly check the field
                          Field field = DefaultIntervalCategoryDataset.class.getDeclaredField("categoryKeys");
                          field.setAccessible(true);
                          Comparable[] storedKeys = (Comparable[]) field.get(dataset);
                          
                          assertSame("Category keys should be stored correctly", 
                                    validKeys, storedKeys);
                      }

 @Test
                         public void testSetCategoryKeysWithNullShouldThrowIllegalArgumentException() {
                             // Setup
                             DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(
                                 new Number[][]{{1}}, new Number[][]{{2}});
                             
                             // We know getCategoryCount() will return 1 from the constructor setup
                             // since we passed a 1x1 array for both starts and ends
                             
                             // Expect IllegalArgumentException, not NullPointerException
                             thrown.expect(IllegalArgumentException.class);
                             thrown.expectMessage("Null 'categoryKeys' argument.");
                             
                             // Test
                             dataset.setCategoryKeys(null);
                             
                             // If mutant is present, this would throw NullPointerException instead
                             // and the test would fail
                         }

 @Test
                   public void testConstructorSeriesKeysGeneration() {
                       // Setup test data
                       Number[][] starts = {{1, 2}, {3, 4}}; // 2 series, 2 categories
                       Number[][] ends = {{5, 6}, {7, 8}};
                       
                       // Create dataset with null seriesKeys to trigger generateKeys()
                       DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(null, null, starts, ends);
                       
                       // Verify seriesKeys were generated correctly
                       assertEquals("Number of series keys should match series count", 
                                   2, dataset.getSeriesCount());
                       assertEquals("Number of series keys should match series count", 
                                   2, dataset.getRowKeys().size());
                       
                       // Verify data access works correctly with generated keys
                       List<?> keys = dataset.getRowKeys();
                       for (int i = 0; i < keys.size(); i++) {
                           assertNotNull("Series key should not be null", keys.get(i));
                           assertEquals("Start value should match", 
                                       starts[i][0], dataset.getStartValue((Comparable)keys.get(i), (Comparable)dataset.getColumnKeys().get(0)));
                       }
                       
                       // Verify category count matches
                       assertEquals("Category count should match", 
                                   2, dataset.getCategoryCount());
                   }

 @Test
              public void testConstructorGeneratesSeriesKeysWithPrefix() throws Exception {
                  // Setup test data
                  Number[][] starts = {{1, 2}, {3, 4}};
                  Number[][] ends = {{5, 6}, {7, 8}};
                  
                  // Create dataset without providing seriesKeys
                  DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
                  
                  // Verify the generated series keys have the expected prefix
                  int seriesCount = dataset.getSeriesCount();
                  for (int i = 0; i < seriesCount; i++) {
                      Comparable<?> key = dataset.getSeriesKey(i);
                      assertNotNull("Series key should not be null", key);
                      assertTrue("Series key should start with expected prefix", 
                               key.toString().startsWith("Series "));
                  }
                  
                  // Also verify category keys were generated properly
                  int categoryCount = dataset.getCategoryCount();
                  for (int i = 0; i < categoryCount; i++) {
                      Comparable<?> key = dataset.getColumnKey(i);
                      assertNotNull("Category key should not be null", key);
                      assertTrue("Category key should start with expected prefix",
                               key.toString().startsWith("Category "));
                  }
              }

 @Test(expected = IllegalArgumentException.class)
         public void testSetCategoryKeys_NullArray1() {
             // Create a dataset with sample data
             Number[][] starts = new Number[][] {{1, 2}, {3, 4}};
             Number[][] ends = new Number[][] {{5, 6}, {7, 8}};
             DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
             
             // Test setting null category keys
             dataset.setCategoryKeys(null);
         }

 @Test(expected = IllegalArgumentException.class)
         public void testSetCategoryKeys_WrongLengthArray1() {
             // Create sample dataset with 2 categories
             Number[][] starts = {{1.0, 2.0}, {3.0, 4.0}};
             Number[][] ends = {{5.0, 6.0}, {7.0, 8.0}};
             DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
             
             // Try to set category keys with wrong length array (1 element when 2 needed)
             Comparable[] keys = {"A"}; // Only 1 key when we need 2
             dataset.setCategoryKeys(keys);
         }

 @Test(expected = IllegalArgumentException.class)
         public void testSetCategoryKeys_NullElementInArray1() {
             // Create a dataset with 1 series and 2 categories
             Number[][] starts = {{1.0, 2.0}};
             Number[][] ends = {{3.0, 4.0}};
             DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
             
             Comparable[] keys = {"A", null}; // Second element is null
             dataset.setCategoryKeys(keys); // Should throw IllegalArgumentException
         }

 @Test
         public void testSetCategoryKeys_ValidInput2() {
             // Create sample data with 2 categories
             Number[][] starts = {{1.0, 2.0}};
             Number[][] ends = {{3.0, 4.0}};
             DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
             
             Comparable[] keys = {"A", "B"};
             dataset.setCategoryKeys(keys);
             assertArrayEquals(keys, dataset.getColumnKeys().toArray());
         }

 @Test(expected = IllegalArgumentException.class)
     public void testSetCategoryKeysWithNullElementShouldThrowExceptionWithMessage() {
         // Setup test data
         Number[][] starts = {{1, 2}, {3, 4}};
         Number[][] ends = {{5, 6}, {7, 8}};
         DefaultIntervalCategoryDataset dataset = new DefaultIntervalCategoryDataset(starts, ends);
         
         // Create input with null element
         Comparable[] categoryKeys = new Comparable[] {"Valid", null};
         
         try {
             dataset.setCategoryKeys(categoryKeys);
             fail("Expected IllegalArgumentException to be thrown");
         } catch (IllegalArgumentException e) {
             // Verify the exception message contains the expected content
             assertTrue("Exception message should not be empty", 
                       !e.getMessage().isEmpty());
             assertTrue("Exception message should contain specific error text",
                       e.getMessage().contains("null category not permitted"));
             throw e; // rethrow to satisfy @Test(expected)
         }
     }

 @Test
    public void testConstructorWithMismatchedCategoryCounts() {
        // Setup test data with mismatched category counts
        Number[][] starts = new Number[][]{{1, 2}, {3, 4}};  // 2 categories
        Number[][] ends = new Number[][]{{5}, {6}};          // 1 category
        
        // Expected error message should contain the colon
        String expectedMessage = "DefaultIntervalCategoryDataset: the number of categories in the start value dataset does not match the number of categories in the end value dataset.";
        
        try {
            // Attempt to create dataset with mismatched categories
            new DefaultIntervalCategoryDataset(new Comparable[]{"Series1"}, 
                                             new Comparable[]{"Cat1", "Cat2"}, 
                                             starts, ends);
            fail("Expected IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            // Verify the exact error message contains the colon
            assertEquals("Error message should contain colon after class name", 
                        expectedMessage, 
                        e.getMessage());
        }
    }

 @Test
   public void testConstructorWithMismatchedSeriesLengths() {
       // Setup test data with mismatched series lengths
       Number[][] starts = new Number[][]{{1, 2}, {3, 4}}; // 2 series
       Number[][] ends = new Number[][]{{5, 6}};           // 1 series
       
       // Expected exception message (original version with "the")
       String expectedMessage = "DefaultIntervalCategoryDataset: the number "
               + "of series in the start value dataset does "
               + "not match the number of series in the end "
               + "value dataset.";
       
       try {
           // Attempt to create dataset with mismatched data
           new DefaultIntervalCategoryDataset(starts, ends);
           fail("Expected IllegalArgumentException");
       } catch (IllegalArgumentException e) {
           // Verify the exact error message matches expected format
           assertEquals(expectedMessage, e.getMessage());
       }
   }

 @Test
   public void testConstructorWithMismatchedCategoryLengths() {
       // Setup test data with mismatched category lengths
       Number[][] starts = new Number[][]{{1, 2}, {3, 4}}; // 2 categories per series
       Number[][] ends = new Number[][]{{5}, {6}};         // 1 category per series
       
       // Expected exception message (original version with "the")
       String expectedMessage = "DefaultIntervalCategoryDataset: the "
               + "number of categories in the start value "
               + "dataset does not match the number of "
               + "categories in the end value dataset.";
       
       try {
           // Attempt to create dataset with mismatched data
           new DefaultIntervalCategoryDataset(starts, ends);
           fail("Expected IllegalArgumentException");
       } catch (IllegalArgumentException e) {
           // Verify the exact error message matches expected format
           assertEquals(expectedMessage, e.getMessage());
       }
   }

 @Test
  public void testConstructorWithMismatchedSeriesCounts() {
      // Setup test data with mismatched series counts
      Number[][] starts = new Number[][]{{1, 2}, {3, 4}}; // 2 series
      Number[][] ends = new Number[][]{{5, 6}};           // 1 series
      
      // Expected error message (original version)
      String expectedMsg = "DefaultIntervalCategoryDataset: the number " +
              "of series in the start value dataset does " +
              "not match the number of series in the end " +
              "value dataset.";
      
      try {
          // Attempt to create dataset with mismatched data
          new DefaultIntervalCategoryDataset(starts, ends);
          fail("Expected IllegalArgumentException to be thrown");
      } catch (IllegalArgumentException e) {
          // Verify the exact error message matches original
          assertEquals(expectedMsg, e.getMessage());
      }
  }

 @Test
 public void testConstructorWithMismatchedSeriesLengths1() {
     // Setup test data with mismatched series lengths
     Number[][] starts = new Number[][]{{1, 2}, {3, 4}};  // 2 series
     Number[][] ends = new Number[][]{{5, 6}};             // 1 series
     
     // Expected error message from original code
     String expectedMsg = "DefaultIntervalCategoryDataset: the number "
             + "of series in the start value dataset does "
             + "not match the number of series in the end "
             + "value dataset.";
     
     try {
         // Attempt to create dataset with mismatched data
         new DefaultIntervalCategoryDataset(starts, ends);
         fail("Expected IllegalArgumentException but none was thrown");
     } catch (IllegalArgumentException e) {
         // Verify the exact error message matches
         assertEquals(expectedMsg, e.getMessage());
     }
 }

}
