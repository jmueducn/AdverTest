package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.Paint;
import java.awt.Stroke;
import org.jfree.chart.event.MarkerChangeEvent;
 
public class ValueMarkerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                    public void testConstructor_ValidValue() {
                                        ValueMarker marker = new ValueMarker(5.0);
                                        assertEquals(5.0, marker.getValue(), 0.0001);
                                        
                                        ValueMarker negativeMarker = new ValueMarker(-3.5);
                                        assertEquals(-3.5, negativeMarker.getValue(), 0.0001);
                                        
                                        ValueMarker zeroMarker = new ValueMarker(0.0);
                                        assertEquals(0.0, zeroMarker.getValue(), 0.0001);
                                        
                                        ValueMarker maxValueMarker = new ValueMarker(Double.MAX_VALUE);
                                        assertEquals(Double.MAX_VALUE, maxValueMarker.getValue(), 0.0001);
                                        
                                        ValueMarker minValueMarker = new ValueMarker(Double.MIN_VALUE);
                                        assertEquals(Double.MIN_VALUE, minValueMarker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_NaNValue() {
                                        ValueMarker nanMarker = new ValueMarker(Double.NaN);
                                        assertTrue(Double.isNaN(nanMarker.getValue()));
                                    }

    @Test
                                    public void testConstructor_PositiveInfinity() {
                                        ValueMarker infMarker = new ValueMarker(Double.POSITIVE_INFINITY);
                                        assertEquals(Double.POSITIVE_INFINITY, infMarker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_NegativeInfinity() {
                                        ValueMarker negInfMarker = new ValueMarker(Double.NEGATIVE_INFINITY);
                                        assertEquals(Double.NEGATIVE_INFINITY, negInfMarker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testEquals_SameObject() {
                                        ValueMarker marker = new ValueMarker(10.0);
                                        assertTrue(marker.equals(marker));
                                    }

    @Test
                                    public void testEquals_EqualValues() {
                                        ValueMarker marker1 = new ValueMarker(10.0);
                                        ValueMarker marker2 = new ValueMarker(10.0);
                                        assertTrue(marker1.equals(marker2));
                                    }

    @Test
                                    public void testEquals_DifferentValues() {
                                        ValueMarker marker1 = new ValueMarker(10.0);
                                        ValueMarker marker2 = new ValueMarker(10.1);
                                        assertFalse(marker1.equals(marker2));
                                    }

    @Test
                                    public void testEquals_DifferentTypes() {
                                        ValueMarker marker = new ValueMarker(10.0);
                                        assertFalse(marker.equals("10.0"));
                                    }

    @Test
                                    public void testEquals_Null() {
                                        ValueMarker marker = new ValueMarker(10.0);
                                        assertFalse(marker.equals(null));
                                    }

    @Test
                                    public void testEquals_NaNComparison() {
                                        ValueMarker marker1 = new ValueMarker(Double.NaN);
                                        ValueMarker marker2 = new ValueMarker(Double.NaN);
                                        assertTrue(marker1.equals(marker2));
                                    }

    @Test
                                    public void testSetValue_ValidValue() {
                                        ValueMarker marker = new ValueMarker(0.0);
                                        marker.setValue(15.5);
                                        assertEquals(15.5, marker.getValue(), 0.0001);
                                        
                                        marker.setValue(-15.5);
                                        assertEquals(-15.5, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testSetValue_SpecialValues() {
                                        ValueMarker marker = new ValueMarker(0.0);
                                        
                                        marker.setValue(Double.NaN);
                                        assertTrue(Double.isNaN(marker.getValue()));
                                        
                                        marker.setValue(Double.POSITIVE_INFINITY);
                                        assertEquals(Double.POSITIVE_INFINITY, marker.getValue(), 0.0001);
                                        
                                        marker.setValue(Double.NEGATIVE_INFINITY);
                                        assertEquals(Double.NEGATIVE_INFINITY, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_ValidParameters() {
                                        // Setup
                                        double testValue = 42.5;
                                        Paint testPaint = mock(Paint.class);
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise
                                        ValueMarker marker = new ValueMarker(testValue, testPaint, testStroke);
                                        
                                        // Verify
                                        assertEquals(testValue, marker.getValue(), 0.0001);
                                        // Note: Since paint and stroke are private and there are no getters,
                                        // we can't directly verify them. We assume if constructor completes,
                                        // the values were properly set.
                                    }

    @Test
                                    public void testConstructor_ZeroValue() {
                                        // Setup
                                        Paint testPaint = mock(Paint.class);
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise
                                        ValueMarker marker = new ValueMarker(0.0, testPaint, testStroke);
                                        
                                        // Verify
                                        assertEquals(0.0, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_NegativeValue() {
                                        // Setup
                                        Paint testPaint = mock(Paint.class);
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise
                                        ValueMarker marker = new ValueMarker(-100.0, testPaint, testStroke);
                                        
                                        // Verify
                                        assertEquals(-100.0, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_MaxDoubleValue() {
                                        // Setup
                                        Paint testPaint = mock(Paint.class);
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise
                                        ValueMarker marker = new ValueMarker(Double.MAX_VALUE, testPaint, testStroke);
                                        
                                        // Verify
                                        assertEquals(Double.MAX_VALUE, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_MinDoubleValue() {
                                        // Setup
                                        Paint testPaint = mock(Paint.class);
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise
                                        ValueMarker marker = new ValueMarker(Double.MIN_VALUE, testPaint, testStroke);
                                        
                                        // Verify
                                        assertEquals(Double.MIN_VALUE, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_NullPaint() {
                                        // Setup
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("Null 'paint' argument.");
                                        
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise & Verify
                                        new ValueMarker(10.0, null, testStroke);
                                    }

    @Test
                                    public void testConstructor_NullStroke() {
                                        // Setup
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("Null 'stroke' argument.");
                                        
                                        Paint testPaint = mock(Paint.class);
                                        
                                        // Exercise & Verify
                                        new ValueMarker(10.0, testPaint, null);
                                    }

    @Test
                                    public void testConstructor_NaNValue1() {
                                        // Setup
                                        Paint testPaint = mock(Paint.class);
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise
                                        ValueMarker marker = new ValueMarker(Double.NaN, testPaint, testStroke);
                                        
                                        // Verify
                                        assertTrue(Double.isNaN(marker.getValue()));
                                    }

    @Test
                                    public void testConstructor_PositiveInfinityValue() {
                                        // Setup
                                        Paint testPaint = mock(Paint.class);
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise
                                        ValueMarker marker = new ValueMarker(Double.POSITIVE_INFINITY, testPaint, testStroke);
                                        
                                        // Verify
                                        assertEquals(Double.POSITIVE_INFINITY, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_NegativeInfinityValue() {
                                        // Setup
                                        Paint testPaint = mock(Paint.class);
                                        Stroke testStroke = mock(Stroke.class);
                                        
                                        // Exercise
                                        ValueMarker marker = new ValueMarker(Double.NEGATIVE_INFINITY, testPaint, testStroke);
                                        
                                        // Verify
                                        assertEquals(Double.NEGATIVE_INFINITY, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testConstructor_ValidParameters1() {
                                        // Setup
                                        double value = 10.5;
                                        Paint paint = mock(Paint.class);
                                        Stroke stroke = mock(Stroke.class);
                                        Paint outlinePaint = mock(Paint.class);
                                        Stroke outlineStroke = mock(Stroke.class);
                                        float alpha = 0.5f;
                                
                                        // Execute
                                        ValueMarker marker = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                                
                                        // Verify
                                        assertEquals(value, marker.getValue(), 0.0001);
                                        // Note: We can't directly test the superclass fields as they're private,
                                        // but we can test their effects through other methods if available
                                    }

    @Test
                                    public void testConstructor_NullPaint1() {
                                        // Setup
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("Null 'paint' argument.");
                                
                                        double value = 10.5;
                                        Paint paint = null;
                                        Stroke stroke = mock(Stroke.class);
                                        Paint outlinePaint = mock(Paint.class);
                                        Stroke outlineStroke = mock(Stroke.class);
                                        float alpha = 0.5f;
                                
                                        // Execute
                                        new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                                    }

    @Test
                                    public void testConstructor_NullStroke1() {
                                        // Setup
                                        thrown.expect(IllegalArgumentException.class);
                                        thrown.expectMessage("Null 'stroke' argument.");
                                
                                        double value = 10.5;
                                        Paint paint = mock(Paint.class);
                                        Stroke stroke = null;
                                        Paint outlinePaint = mock(Paint.class);
                                        Stroke outlineStroke = mock(Stroke.class);
                                        float alpha = 0.5f;
                                
                                        // Execute
                                        new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                                    }

    @Test
                                    public void testGetSetValue() {
                                        // Setup
                                        ValueMarker marker = new ValueMarker(5.0, mock(Paint.class), mock(Stroke.class), 
                                                                           mock(Paint.class), mock(Stroke.class), 1.0f);
                                        
                                        // Test initial value
                                        assertEquals(5.0, marker.getValue(), 0.0001);
                                        
                                        // Set new value and verify
                                        marker.setValue(7.5);
                                        assertEquals(7.5, marker.getValue(), 0.0001);
                                        
                                        // Set negative value
                                        marker.setValue(-3.2);
                                        assertEquals(-3.2, marker.getValue(), 0.0001);
                                    }

    @Test
                                    public void testEquals() {
                                        // Setup
                                        Paint paint = mock(Paint.class);
                                        Stroke stroke = mock(Stroke.class);
                                        Paint outlinePaint = mock(Paint.class);
                                        Stroke outlineStroke = mock(Stroke.class);
                                        
                                        ValueMarker marker1 = new ValueMarker(10.0, paint, stroke, outlinePaint, outlineStroke, 1.0f);
                                        ValueMarker marker2 = new ValueMarker(10.0, paint, stroke, outlinePaint, outlineStroke, 1.0f);
                                        ValueMarker marker3 = new ValueMarker(20.0, paint, stroke, outlinePaint, outlineStroke, 1.0f);
                                        
                                        // Test equality
                                        assertTrue(marker1.equals(marker2));
                                        assertFalse(marker1.equals(marker3));
                                        
                                        // Test with null
                                        assertFalse(marker1.equals(null));
                                        
                                        // Test with different class
                                        assertFalse(marker1.equals("Not a ValueMarker"));
                                    }

    @Test
                                    public void testEquals_DifferentAlpha() {
                                        Paint paint = mock(Paint.class);
                                        Stroke stroke = mock(Stroke.class);
                                        
                                        ValueMarker marker1 = new ValueMarker(10.0, paint, stroke, mock(Paint.class), mock(Stroke.class), 1.0f);
                                        ValueMarker marker2 = new ValueMarker(10.0, paint, stroke, mock(Paint.class), mock(Stroke.class), 0.5f);
                                        
                                        assertFalse(marker1.equals(marker2));
                                    }

    @Test
                                    public void testEquals_DifferentOutline() {
                                        Paint paint = mock(Paint.class);
                                        Stroke stroke = mock(Stroke.class);
                                        
                                        ValueMarker marker1 = new ValueMarker(10.0, paint, stroke, mock(Paint.class), mock(Stroke.class), 1.0f);
                                        ValueMarker marker2 = new ValueMarker(10.0, paint, stroke, mock(Paint.class), mock(Stroke.class), 1.0f);
                                        
                                        // Should still be equal since outline properties are the same in this case
                                        assertTrue(marker1.equals(marker2));
                                    }

    @Test
                           public void testConstructorPassesOutlineStrokeToParent() {
                               // Prepare test data
                               java.awt.Paint paint = java.awt.Color.RED;
                               java.awt.Stroke stroke = new java.awt.BasicStroke(1.0f);
                               java.awt.Paint outlinePaint = java.awt.Color.BLUE;
                               java.awt.Stroke outlineStroke = new java.awt.BasicStroke(2.0f);
                               float alpha = 0.5f;
                               double value = 10.0;
                               
                               // Create two markers with same parameters
                               ValueMarker marker1 = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                               ValueMarker marker2 = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                               
                               // They should be equal if outlineStroke was properly passed to parent
                               assertTrue("Markers with same parameters should be equal", marker1.equals(marker2));
                               
                               // Verify the value was set correctly
                               assertEquals(value, marker1.getValue(), 0.0001);
                           }

    @Test
                           public void testConstructorSetsOutlineStroke() {
                               // Setup test data
                               double value = 10.0;
                               java.awt.Paint paint = java.awt.Color.RED;
                               java.awt.Stroke stroke = new java.awt.BasicStroke(1.0f);
                               java.awt.Paint outlinePaint = java.awt.Color.BLUE;
                               java.awt.Stroke outlineStroke = new java.awt.BasicStroke(2.0f);
                               float alpha = 0.5f;
                               
                               // Create marker with non-null outline stroke
                               ValueMarker marker = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                               
                               // Create another marker that should be equal if outline stroke was set properly
                               ValueMarker expectedMarker = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                               
                               // Test that markers are equal (would fail if outlineStroke was set to null)
                               assertTrue("Markers with same parameters should be equal", 
                                         marker.equals(expectedMarker));
                               
                               // Create a marker with null outline stroke that should NOT be equal
                               ValueMarker differentMarker = new ValueMarker(value, paint, stroke, outlinePaint, null, alpha);
                               assertFalse("Markers with different outline strokes should not be equal",
                                          marker.equals(differentMarker));
                           }

    @Test
                           public void testConstructorPassesOutlineStrokeToParent1() {
                               // Arrange
                               java.awt.Color paint = java.awt.Color.RED;
                               java.awt.BasicStroke stroke = new java.awt.BasicStroke(1.0f);
                               java.awt.Color outlinePaint = java.awt.Color.BLUE;
                               java.awt.BasicStroke outlineStroke = new java.awt.BasicStroke(2.0f);
                               float alpha = 0.5f;
                               double value = 10.0;
                               
                               // Act
                               ValueMarker marker1 = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                               ValueMarker marker2 = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                               
                               // Assert
                               // If outlineStroke was passed correctly to parent, equals should return true
                               // If mutant passed null, equals would likely return false
                               assertTrue("Two markers with same parameters should be equal", 
                                         marker1.equals(marker2));
                               
                               // Additional verification that value was set correctly
                               assertEquals(value, marker1.getValue(), 0.0001);
                           }

    @Test
                      public void testConstructorAlphaValue() {
                          // Create paint and stroke objects needed for constructor
                          java.awt.Paint paint = java.awt.Color.RED;
                          java.awt.Stroke stroke = new java.awt.BasicStroke(1.0f);
                          java.awt.Paint outlinePaint = java.awt.Color.BLUE;
                          java.awt.Stroke outlineStroke = new java.awt.BasicStroke(1.0f);
                          
                          // Test with different alpha values
                          float testAlpha = 0.5f;
                          
                          // Create original and potentially mutated markers
                          ValueMarker marker1 = new ValueMarker(10.0, paint, stroke, outlinePaint, outlineStroke, testAlpha);
                          ValueMarker marker2 = new ValueMarker(10.0, paint, stroke, outlinePaint, outlineStroke, 1.0f);
                          
                          // If the constructor properly passes the alpha value, these markers should not be equal
                          assertFalse("Markers with different alpha values should not be equal", 
                                     marker1.equals(marker2));
                          
                          // Also test with alpha = 1.0f explicitly
                          ValueMarker marker3 = new ValueMarker(10.0, paint, stroke, outlinePaint, outlineStroke, 1.0f);
                          assertTrue("Markers with same alpha values should be equal", 
                                    marker2.equals(marker3));
                      }

    @Test
                      public void testConstructorAlphaValueIsUsed() {
                          // Setup test data
                          double value = 10.0;
                          java.awt.Paint paint = java.awt.Color.RED;
                          java.awt.Stroke stroke = new java.awt.BasicStroke(1.0f);
                          java.awt.Paint outlinePaint = java.awt.Color.BLUE;
                          java.awt.Stroke outlineStroke = new java.awt.BasicStroke(1.0f);
                          float alpha = 0.5f; // Non-default alpha value
                          
                          // Create two markers - one with default alpha (1.0f) and one with our alpha
                          org.jfree.chart.plot.ValueMarker markerWithAlpha = new org.jfree.chart.plot.ValueMarker(
                              value, paint, stroke, outlinePaint, outlineStroke, alpha);
                          org.jfree.chart.plot.ValueMarker markerWithDefaultAlpha = new org.jfree.chart.plot.ValueMarker(
                              value, paint, stroke, outlinePaint, outlineStroke, 1.0f);
                          
                          // If the constructor properly uses the alpha parameter, these should NOT be equal
                          assertFalse("Markers with different alpha values should not be equal", 
                                     markerWithAlpha.equals(markerWithDefaultAlpha));
                          
                          // Create another marker with same alpha to verify equals works
                          org.jfree.chart.plot.ValueMarker markerWithSameAlpha = new org.jfree.chart.plot.ValueMarker(
                              value, paint, stroke, outlinePaint, outlineStroke, alpha);
                          assertTrue("Markers with same alpha values should be equal",
                                    markerWithAlpha.equals(markerWithSameAlpha));
                      }

    @Test
                  public void testConstructorAlphaValueIsPassedCorrectly() {
                      // Setup test data
                      java.awt.Paint paint = java.awt.Color.RED;
                      java.awt.Stroke stroke = new java.awt.BasicStroke(1.0f);
                      java.awt.Paint outlinePaint = java.awt.Color.BLUE;
                      java.awt.Stroke outlineStroke = new java.awt.BasicStroke(1.0f);
                      float testAlpha = 0.5f;  // Not 1.0f
                      
                      // Create the marker with test alpha
                      ValueMarker marker = new ValueMarker(0.0, paint, stroke, 
                                                         outlinePaint, outlineStroke, testAlpha);
                      
                      // Use reflection to verify the alpha value was set correctly
                      try {
                          Class<?> markerClass = marker.getClass().getSuperclass();
                          java.lang.reflect.Field alphaField = markerClass.getDeclaredField("alpha");
                          alphaField.setAccessible(true);
                          float actualAlpha = alphaField.getFloat(marker);
                          
                          // Verify the alpha value matches what we passed to constructor
                          assertEquals(testAlpha, actualAlpha, 0.0001f);
                      } catch (NoSuchFieldException | IllegalAccessException e) {
                          fail("Failed to access alpha field through reflection: " + e.getMessage());
                      }
                  }

    @Test
              public void testConstructorPassesOutlinePaintToParent() {
                  // Arrange
                  double value = 10.0;
                  Paint paint = mock(Paint.class);
                  Stroke stroke = mock(Stroke.class);
                  Paint outlinePaint = mock(Paint.class);
                  Stroke outlineStroke = mock(Stroke.class);
                  float alpha = 0.5f;
                  
                  // Act - create two markers with same parameters
                  ValueMarker marker1 = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                  ValueMarker marker2 = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                  
                  // Assert that they are equal (which would test all properties including outlinePaint)
                  assertTrue("Markers with same parameters should be equal", marker1.equals(marker2));
                  
                  // Additional test with different outlinePaint to ensure it's being compared
                  ValueMarker marker3 = new ValueMarker(value, paint, stroke, mock(Paint.class), outlineStroke, alpha);
                  assertFalse("Markers with different outlinePaint should not be equal", marker1.equals(marker3));
              }

    @Test
             public void testConstructorSetsOutlinePaint() throws Exception {
                 // Arrange
                 java.awt.Color paint = java.awt.Color.RED;
                 java.awt.BasicStroke stroke = new java.awt.BasicStroke(1.0f);
                 java.awt.Color outlinePaint = java.awt.Color.BLUE;
                 java.awt.BasicStroke outlineStroke = new java.awt.BasicStroke(2.0f);
                 float alpha = 0.5f;
                 double value = 10.0;
                 
                 // Act
                 ValueMarker marker = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
                 
                 // Assert - use reflection to verify the outlinePaint was properly set in parent class
                 Class<?> markerClass = marker.getClass().getSuperclass();
                 Field outlinePaintField = markerClass.getDeclaredField("outlinePaint");
                 outlinePaintField.setAccessible(true);
                 java.awt.Color actualOutlinePaint = (java.awt.Color) outlinePaintField.get(marker);
                 
                 assertEquals("Outline paint should be set to provided value", 
                            outlinePaint, actualOutlinePaint);
             }

    @Test
         public void testConstructorSetsOutlinePaintCorrectly() {
             // Setup test data
             double testValue = 10.0;
             java.awt.Paint testPaint = new java.awt.Color(255, 0, 0); // RED
             java.awt.Stroke testStroke = new java.awt.BasicStroke(1.0f);
             java.awt.Paint testOutlinePaint = new java.awt.Color(0, 0, 255); // BLUE
             java.awt.Stroke testOutlineStroke = new java.awt.BasicStroke(2.0f);
             float testAlpha = 0.5f;
             
             // Create original and potentially mutated markers
             ValueMarker originalMarker = new ValueMarker(testValue, testPaint, testStroke, 
                 testOutlinePaint, testOutlineStroke, testAlpha);
             ValueMarker potentiallyMutatedMarker = new ValueMarker(testValue, testPaint, testStroke, 
                 null, testOutlineStroke, testAlpha);
             
             // Create another marker that should match the original
             ValueMarker expectedOriginal = new ValueMarker(testValue, testPaint, testStroke, 
                 testOutlinePaint, testOutlineStroke, testAlpha);
             
             // Create another marker that should match the mutated version
             ValueMarker expectedMutated = new ValueMarker(testValue, testPaint, testStroke, 
                 null, testOutlineStroke, testAlpha);
             
             // Verify original behavior
             assertTrue("Original marker should equal expected original", 
                 originalMarker.equals(expectedOriginal));
             assertFalse("Original marker should not equal mutated version", 
                 originalMarker.equals(expectedMutated));
             
             // This assertion would fail if the mutant survives
             assertFalse("Original marker should not equal potentially mutated marker", 
                 originalMarker.equals(potentiallyMutatedMarker));
         }

    @Test
         public void testConstructorAlphaValueIsPassedCorrectly1() throws Exception {
             // Arrange
             Paint mockPaint = mock(Paint.class);
             Stroke mockStroke = mock(Stroke.class);
             Paint mockOutlinePaint = mock(Paint.class);
             Stroke mockOutlineStroke = mock(Stroke.class);
             float expectedAlpha = 0.5f; // Any non-zero value
             
             // Act
             ValueMarker marker = new ValueMarker(1.0, mockPaint, mockStroke, 
                                                mockOutlinePaint, mockOutlineStroke, expectedAlpha);
             
             // Assert - Use reflection to verify alpha was passed correctly to parent class
             Class<?> markerClass = marker.getClass().getSuperclass();
             Field alphaField = markerClass.getDeclaredField("alpha");
             alphaField.setAccessible(true);
             float actualAlpha = alphaField.getFloat(marker);
             
             assertEquals("Alpha value should be passed correctly to parent class", 
                         expectedAlpha, actualAlpha, 0.0001f);
         }

    @Test
     public void testMarkerRenderingWithDifferentAlphaValues() {
         // This would require setting up a test environment that can render the marker
         // and verify its appearance, which is beyond a simple unit test
         // Not recommended for unit testing level
     }

    @Test
    public void testConstructorSetsCorrectAlpha() {
        // Arrange
        java.awt.Paint paint = mock(java.awt.Paint.class);
        java.awt.Stroke stroke = mock(java.awt.Stroke.class);
        java.awt.Paint outlinePaint = mock(java.awt.Paint.class);
        java.awt.Stroke outlineStroke = mock(java.awt.Stroke.class);
        float expectedAlpha = 0.5f; // non-zero alpha
        
        // Act
        ValueMarker marker = new ValueMarker(1.0, paint, stroke, outlinePaint, outlineStroke, expectedAlpha);
        
        // Assert
        try {
            Field alphaField = marker.getClass().getSuperclass().getDeclaredField("alpha");
            alphaField.setAccessible(true);
            float actualAlpha = alphaField.getFloat(marker);
            assertEquals(expectedAlpha, actualAlpha, 0.0001f);
        } catch (Exception e) {
            fail("Failed to verify alpha value through reflection: " + e.getMessage());
        }
    }

    @Test
    public void testConstructorAlphaValue1() throws Exception {
        // Setup test data
        double value = 10.0;
        Paint paint = mock(Paint.class);
        Stroke stroke = mock(Stroke.class);
        Paint outlinePaint = mock(Paint.class);
        Stroke outlineStroke = mock(Stroke.class);
        float alpha = 1.0f;
        
        // Create instance
        ValueMarker marker = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);
        
        // Use reflection to get alpha value from parent class
        Class<?> parentClass = marker.getClass().getSuperclass();
        Field alphaField = parentClass.getDeclaredField("alpha");
        alphaField.setAccessible(true);
        float actualAlpha = alphaField.getFloat(marker);
        
        // Assert alpha is 1.0f (original behavior)
        assertEquals(1.0f, actualAlpha, 0.0001f);
        
        // Also verify other fields were set correctly
        assertEquals(value, marker.getValue(), 0.0001);
    }


}
