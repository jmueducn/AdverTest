package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryToPieDataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.PieDataset;
 
public class MultiplePiePlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                     public void testConstructor_WithValidDataset() {
                                                         // Arrange
                                                         CategoryDataset dataset = mock(CategoryDataset.class);
                                                         
                                                         // Act
                                                         MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                                         
                                                         // Assert
                                                         assertSame(dataset, plot.getDataset());
                                                         assertNotNull(plot.getPieChart());
                                                         assertEquals(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                                                         assertEquals("Other", plot.getAggregatedItemsKey());
                                                         assertEquals(Color.lightGray, plot.getAggregatedItemsPaint());
                                                         assertNotNull(plot.getPieChart().getTitle());
                                                         
                                                         // Verify pie chart configuration
                                                         JFreeChart pieChart = plot.getPieChart();
                                                         assertNull(pieChart.getBackgroundPaint());
                                                         assertEquals(0, pieChart.getSubtitles().size());
                                                         assertTrue(pieChart.getTitle() instanceof TextTitle);
                                                         
                                                         TextTitle title = (TextTitle) pieChart.getTitle();
                                                         assertEquals("Series Title", title.getText());
                                                         assertEquals(RectangleEdge.BOTTOM, title.getPosition());
                                                         assertEquals(new Font("SansSerif", Font.BOLD, 12), title.getFont());
                                                     }

    @Test
                                                     public void testConstructor_WithNullDataset() {
                                                         // Arrange
                                                         CategoryDataset dataset = null;
                                                         
                                                         // Act
                                                         MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                                         
                                                         // Assert
                                                         assertNull(plot.getDataset());
                                                         assertNotNull(plot.getPieChart()); // Should still create chart even with null dataset
                                                         assertEquals(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                                                     }

    @Test
                                                     public void testConstructor_VerifyPiePlotConfiguration() {
                                                         // Arrange
                                                         CategoryDataset dataset = mock(CategoryDataset.class);
                                                         
                                                         // Act
                                                         MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                                         
                                                         // Assert
                                                         PiePlot piePlot = (PiePlot) plot.getPieChart().getPlot();
                                                         assertNotNull(piePlot);
                                                         assertNull(piePlot.getDataset()); // Should be null as per constructor
                                                     }

    @Test
                                                     public void testConstructor_VerifyNoLegend() {
                                                         // Arrange
                                                         CategoryDataset dataset = mock(CategoryDataset.class);
                                                         
                                                         // Act
                                                         MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                                         
                                                         // Assert
                                                         assertNull(plot.getPieChart().getLegend());
                                                     }

    @Test
                                                     public void testConstructor_VerifyDefaultLimit() {
                                                         // Arrange
                                                         CategoryDataset dataset = mock(CategoryDataset.class);
                                                         
                                                         // Act
                                                         MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                                         
                                                         // Assert
                                                         assertEquals(0.0, plot.getLimit(), 0.0001);
                                                     }

    @Test
                                             public void testMultiplePiePlotConstructor() {
                                                 // Test default constructor initialization
                                                 MultiplePiePlot plot = new MultiplePiePlot();
                                                 
                                                 // Verify all fields are initialized to expected default values
                                                 assertNull("Dataset should be null", plot.getDataset());
                                                 assertNotNull("PieChart should not be null", plot.getPieChart());
                                                 assertEquals("Default data extract order should be BY_ROW", 
                                                     TableOrder.BY_ROW, plot.getDataExtractOrder());
                                                 assertEquals("Default limit should be 0.0", 0.0, plot.getLimit(), 0.0001);
                                                 assertNull("Aggregated items key should be null", plot.getAggregatedItemsKey());
                                                 assertNull("Aggregated items paint should be null", plot.getAggregatedItemsPaint());
                                                 
                                                 // Use reflection to access private sectionPaints field
                                                 try {
                                                     Field sectionPaintsField = MultiplePiePlot.class.getDeclaredField("sectionPaints");
                                                     sectionPaintsField.setAccessible(true);
                                                     Map<?,?> sectionPaints = (Map<?,?>) sectionPaintsField.get(plot);
                                                     assertNotNull("Section paints map should be initialized", sectionPaints);
                                                     assertTrue("Section paints map should be empty", sectionPaints.isEmpty());
                                                 } catch (Exception e) {
                                                     fail("Failed to access sectionPaints field: " + e.getMessage());
                                                 }
                                                 
                                                 // Verify pie chart properties
                                                 JFreeChart pieChart = plot.getPieChart();
                                                 assertNotNull("Pie chart plot should not be null", pieChart.getPlot());
                                                 assertEquals("Pie chart title should be empty", "", pieChart.getTitle().getText());
                                             }

    @Test
                                         public void testConstructor_VerifyInitialSectionPaints() {
                                             // Arrange
                                             CategoryDataset dataset = mock(CategoryDataset.class);
                                             
                                             // Act
                                             MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                             
                                             // Assert
                                             assertNotNull(plot.getAggregatedItemsPaint());
                                             // Section paints map should be initialized but empty
                                             try {
                                                 Field field = plot.getClass().getDeclaredField("sectionPaints");
                                                 field.setAccessible(true);
                                                 assertNotNull(field.get(plot));
                                             } catch (NoSuchFieldException | IllegalAccessException e) {
                                                 fail("Failed to access sectionPaints field: " + e.getMessage());
                                             }
                                         }

    @Test
                                    public void testConstructorInitialization() {
                                        // Create a mock dataset
                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                        
                                        // Create instance of MultiplePiePlot
                                        MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                        
                                        // Verify default values are set correctly
                                        assertNotNull("Pie chart should be initialized", plot.getPieChart());
                                        assertEquals("Default data extract order should be BY_COLUMN", 
                                            TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                                        assertEquals("Default aggregated items key should be 'Other'", 
                                            "Other", plot.getAggregatedItemsKey());
                                        assertEquals("Default aggregated items paint should be light gray", 
                                            Color.lightGray, plot.getAggregatedItemsPaint());
                                        assertNull("Background paint should be null", 
                                            plot.getPieChart().getBackgroundPaint());
                                        
                                        // Verify title was set correctly
                                        org.jfree.chart.title.Title title = plot.getPieChart().getTitle();
                                        assertNotNull("Chart should have a title", title);
                                        assertTrue("Title should be TextTitle", title instanceof org.jfree.chart.title.TextTitle);
                                        org.jfree.chart.title.TextTitle textTitle = (org.jfree.chart.title.TextTitle) title;
                                        assertEquals("Title text should be 'Series Title'", 
                                            "Series Title", textTitle.getText());
                                        assertEquals("Title position should be BOTTOM", 
                                            RectangleEdge.BOTTOM, textTitle.getPosition());
                                    }

    @Test
                                public void testConstructorInitializesSuperclass() {
                                    // Create instance with null dataset
                                    org.jfree.chart.plot.MultiplePiePlot plot = new org.jfree.chart.plot.MultiplePiePlot(null);
                                    
                                    // Verify superclass initialization by checking inherited methods
                                    // If super() wasn't called, these would likely throw exceptions or return wrong values
                                    
                                    // Test basic superclass functionality
                                    assertNotNull("Plot should have background paint", plot.getBackgroundPaint());
                                    assertNotNull("Plot should have outline stroke", plot.getOutlineStroke());
                                    assertNotNull("Plot should have outline paint", plot.getOutlinePaint());
                                    
                                    // Test that we can set/get properties inherited from superclass
                                    try {
                                        plot.setNoDataMessage("Test message");
                                        assertEquals("Test message", plot.getNoDataMessage());
                                    } catch (Exception e) {
                                        fail("Superclass methods should work if properly initialized");
                                    }
                                    
                                    // Verify some default values from superclass
                                    assertNotNull("Plot should have insets by default", plot.getInsets());
                                    assertTrue("Plot should have outline visible by default", plot.isOutlineVisible());
                                }

    @Test
                                public void testConstructorWithNull() {
                                    // Create instance with null parameter
                                    MultiplePiePlot plot = new MultiplePiePlot(null);
                                    
                                    // Get the internal pie chart
                                    JFreeChart pieChart = plot.getPieChart();
                                    assertNotNull("PieChart should not be null", pieChart);
                                    
                                    // Verify the plot is properly initialized with null dataset
                                    PiePlot innerPlot = (PiePlot) pieChart.getPlot();
                                    assertNull("Inner plot's dataset should be null", innerPlot.getDataset());
                                    
                                    // Additional check to ensure proper initialization
                                    assertEquals("Plot background should be white", 
                                        java.awt.Color.WHITE, innerPlot.getBackgroundPaint());
                                }

    @Test
                            public void testConstructorPiePlotInitialization() {
                                // Create a mock dataset
                                CategoryDataset dataset = mock(CategoryDataset.class);
                                
                                // Create the MultiplePiePlot instance
                                MultiplePiePlot plot = new MultiplePiePlot(dataset);
                                
                                // Get the internal pie chart and its plot
                                JFreeChart pieChart = plot.getPieChart();
                                PiePlot piePlot = (PiePlot) pieChart.getPlot();
                                
                                // Verify the plot's dataset is explicitly set to null (original behavior)
                                // This will fail if the mutant is present (where dataset would be not set rather than null)
                                assertNull("PiePlot's dataset should be null", piePlot.getDataset());
                                
                                // Additional verification that the chart was properly configured
                                assertEquals("Series Title", pieChart.getTitle().getText());
                                assertNull(pieChart.getBackgroundPaint());
                                assertNull(pieChart.getLegend());
                            }

    @Test
                               public void testConstructorInitializesPieChartWithValidPlot() {
                                   // Test that constructor creates pieChart with properly initialized plot
                                   MultiplePiePlot plot = new MultiplePiePlot(null);
                                   
                                   // Get the created pie chart
                                   JFreeChart pieChart = plot.getPieChart();
                                   assertNotNull("PieChart should not be null", pieChart);
                                   
                                   // Verify the plot inside is properly initialized
                                   PiePlot innerPlot = (PiePlot) pieChart.getPlot();
                                   assertNotNull("Inner PiePlot should not be null", innerPlot);
                                   
                                   // Verify the plot doesn't have null dataset (which the mutant would cause)
                                   try {
                                       innerPlot.getDataset(); // Should not throw NullPointerException
                                   } catch (NullPointerException e) {
                                       fail("PiePlot should have non-null dataset");
                                   }
                               }

    @Test
                               public void testConstructorUsesCorrectPiePlotInstance() {
                                   // Create a test dataset (can be null as per original code)
                                   CategoryDataset dataset = null;
                                   
                                   // Create a new MultiplePiePlot instance
                                   MultiplePiePlot multiplePiePlot = new MultiplePiePlot(dataset);
                                   
                                   // Get the pie chart and its plot
                                   JFreeChart pieChart = multiplePiePlot.getPieChart();
                                   PiePlot chartPlot = (PiePlot) pieChart.getPlot();
                                   
                                   // Verify the plot in the chart is the same instance that was created in the constructor
                                   // This will fail if the mutant is present, as the mutant creates a new PiePlot instance
                                   // instead of using the one created in the constructor
                                   PiePlot expectedPlot = new PiePlot(null);
                                   assertSame("The pie chart should use the exact PiePlot instance created in constructor", 
                                             expectedPlot.getClass(), chartPlot.getClass());
                                   
                                   // Additional check to ensure the plot has the expected null dataset
                                   assertNull("The pie plot should have null dataset", chartPlot.getDataset());
                               }

    @Test
                              public void testConstructorCallsSuper() {
                                  // The test will implicitly check that no exception is thrown during construction
                                  // which would happen if super() wasn't called and parent class wasn't initialized
                                  MultiplePiePlot plot = new MultiplePiePlot(null);
                                  
                                  // Verify some basic inherited behavior works (indicating superclass was initialized)
                                  assertNotNull(plot.getBackgroundPaint());
                                  assertNotNull(plot.getOutlineStroke());
                                  
                                  // Verify the null dataset was properly handled
                                  assertNull(plot.getDataset());
                                  
                                  // Verify default values are set (these depend on parent class initialization)
                                  assertNotNull(plot.getDataExtractOrder());
                                  assertEquals(0.0, plot.getLimit(), 0.0001);
                              }

    @Test
                         public void testConstructorInitializesAllFields() {
                             // Arrange
                             CategoryDataset dataset = mock(CategoryDataset.class);
                             
                             // Act
                             MultiplePiePlot plot = new MultiplePiePlot(dataset);
                             
                             // Assert - verify all fields are initialized
                             assertNotNull("pieChart should be initialized", plot.getPieChart());
                             assertNotNull("dataset should be set", plot.getDataset());
                             assertEquals("dataExtractOrder should be BY_COLUMN", 
                                 TableOrder.BY_COLUMN, plot.getDataExtractOrder());
                             assertEquals("aggregatedItemsKey should be 'Other'", 
                                 "Other", plot.getAggregatedItemsKey());
                             assertEquals("aggregatedItemsPaint should be lightGray", 
                                 Color.lightGray, plot.getAggregatedItemsPaint());
                             
                             // Verify sectionPaints using reflection since there's no public getter
                             try {
                                 Field sectionPaintsField = MultiplePiePlot.class.getDeclaredField("sectionPaints");
                                 sectionPaintsField.setAccessible(true);
                                 Object sectionPaints = sectionPaintsField.get(plot);
                                 assertNotNull("sectionPaints should be initialized", sectionPaints);
                             } catch (Exception e) {
                                 fail("Failed to access sectionPaints field: " + e.getMessage());
                             }
                             
                             // Verify pieChart properties
                             assertNull("pieChart background should be null", 
                                 plot.getPieChart().getBackgroundPaint());
                             assertNotNull("pieChart should have title", 
                                 plot.getPieChart().getTitle());
                             assertEquals("title position should be BOTTOM", 
                                 RectangleEdge.BOTTOM, 
                                 ((TextTitle)plot.getPieChart().getTitle()).getPosition());
                         }

    @Test
                         public void testConstructorWithNullInitializesPiePlotWithNullDataset() {
                             // Create the MultiplePiePlot with null parameter
                             MultiplePiePlot plot = new MultiplePiePlot(null);
                             
                             // Get the pie chart and its plot
                             JFreeChart pieChart = plot.getPieChart();
                             assertNotNull("Pie chart should not be null", pieChart);
                             
                             PiePlot piePlot = (PiePlot) pieChart.getPlot();
                             assertNotNull("Pie plot should not be null", piePlot);
                             
                             // The key assertion that will catch the mutant
                             assertNull("Pie plot dataset should be null when constructed with null", 
                                       piePlot.getDataset());
                             
                             // Additional assertions to verify other initialization states
                             assertEquals("Plot background should be white", 
                                         java.awt.Color.WHITE, piePlot.getBackgroundPaint());
                             assertTrue("Plot should have outline by default", 
                                       piePlot.isOutlineVisible());
                         }

    @Test
                         public void testConstructorInitializesPiePlotWithNullDataset() {
                             // Create a mock dataset
                             CategoryDataset dataset = mock(CategoryDataset.class);
                             
                             // Create instance of MultiplePiePlot which will initialize the PiePlot
                             MultiplePiePlot multiplePiePlot = new MultiplePiePlot(dataset);
                             
                             // Get the pie chart and its plot
                             JFreeChart pieChart = multiplePiePlot.getPieChart();
                             PiePlot plot = (PiePlot) pieChart.getPlot();
                             
                             // Verify the dataset in the PiePlot is null as expected in original code
                             assertNull("PiePlot should be initialized with null dataset", plot.getDataset());
                             
                             // Additional verification that the chart is properly configured
                             assertNotNull("PieChart should not be null", pieChart);
                             assertEquals("Chart should have correct title", 
                                 "Series Title", pieChart.getTitle().getText());
                         }

    @Test
                    public void testConstructorPiePlotReference() {
                        // Create a mock dataset
                        CategoryDataset dataset = mock(CategoryDataset.class);
                        
                        // Create instance of MultiplePiePlot
                        MultiplePiePlot plot = new MultiplePiePlot(dataset);
                        
                        // Get the pie plot from the chart
                        JFreeChart pieChart = plot.getPieChart();
                        PiePlot actualPlot = (PiePlot) pieChart.getPlot();
                        
                        // Verify the plot is not null
                        assertNotNull("Pie plot should not be null", actualPlot);
                        
                        // Verify the plot is the same instance that was created in constructor
                        // This will fail for the mutant since it creates a new instance
                        // We need to use reflection to get the piePlot variable created in constructor
                        try {
                            Field piePlotField = MultiplePiePlot.class.getDeclaredField("piePlot");
                            piePlotField.setAccessible(true);
                            PiePlot expectedPlot = (PiePlot) piePlotField.get(plot);
                            assertSame("PieChart should use the same PiePlot instance created in constructor", 
                                      expectedPlot, actualPlot);
                        } catch (Exception e) {
                            fail("Failed to access piePlot field via reflection: " + e.getMessage());
                        }
                    }

    @Test
                    public void testConstructorPiePlotInitialization1() {
                        // Create a mock dataset
                        CategoryDataset dataset = mock(CategoryDataset.class);
                        
                        // Create instance of MultiplePiePlot
                        MultiplePiePlot plot = new MultiplePiePlot(dataset);
                        
                        // Get the pie plot from the chart
                        JFreeChart pieChart = plot.getPieChart();
                        PiePlot actualPlot = (PiePlot) pieChart.getPlot();
                        
                        // Verify the plot is not null
                        assertNotNull("Pie plot should not be null", actualPlot);
                        
                        // Verify the plot has null dataset (as passed in constructor)
                        assertNull("PiePlot's dataset should be null", actualPlot.getDataset());
                        
                        // Verify the chart has the expected title
                        assertEquals("Series Title", pieChart.getTitle().getText());
                        
                        // Verify the chart has no legend
                        assertNull("Chart should have no legend", pieChart.getLegend());
                        
                        // Verify the chart has null background paint
                        assertNull("Chart should have null background paint", pieChart.getBackgroundPaint());
                    }

    @Test
                   public void testConstructorInitializesPieChartCorrectly() {
                       // Create a test dataset
                       org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                       dataset.setValue("Category 1", 10);
                       
                       // Create a test plot
                       org.jfree.chart.plot.PiePlot expectedPlot = new org.jfree.chart.plot.PiePlot(dataset);
                       
                       // Create instance - this would use either the original or mutated constructor
                       org.jfree.chart.plot.MultiplePiePlot plot = new org.jfree.chart.plot.MultiplePiePlot();
                       
                       // Set the expected plot (simulating what the original constructor would do)
                       plot.setPieChart(new org.jfree.chart.JFreeChart(expectedPlot));
                       
                       // Get the actual chart from the plot
                       org.jfree.chart.JFreeChart actualChart = plot.getPieChart();
                       
                       // Assertions to catch the mutant
                       assertNotNull("PieChart should not be null", actualChart);
                       org.jfree.chart.plot.PiePlot actualPlot = (org.jfree.chart.plot.PiePlot) actualChart.getPlot();
                       assertNotNull("Plot should not be null", actualPlot);
                       assertSame("Plot should be the expected plot instance", expectedPlot, actualPlot);
                       assertNotNull("Plot's dataset should not be null", actualPlot.getDataset());
                   }

    @Test
           public void testPieChartInitializationUsesCorrectPiePlotInstance() {
               // Create a mock dataset
               CategoryDataset dataset = mock(CategoryDataset.class);
               
               // Create a mock PiePlot
               PiePlot mockPiePlot = mock(PiePlot.class);
               when(mockPiePlot.getDataset()).thenReturn(null);
               
               // Spy on the MultiplePiePlot to verify PiePlot creation
               MultiplePiePlot plot = spy(new MultiplePiePlot(dataset));
               
               // Use reflection to get the pieChart field
               try {
                   Field pieChartField = MultiplePiePlot.class.getDeclaredField("pieChart");
                   pieChartField.setAccessible(true);
                   JFreeChart chart = mock(JFreeChart.class);
                   when(chart.getPlot()).thenReturn(mockPiePlot);
                   pieChartField.set(plot, chart);
               } catch (Exception e) {
                   fail("Failed to set up test due to reflection error: " + e.getMessage());
               }
               
               // Verify that PiePlot was properly initialized
               verify(mockPiePlot).setDataset(null);
           }

    @Test
           public void testConstructorCallsSuper1() {
               // This test will fail if super() is commented out
               MultiplePiePlot plot = new MultiplePiePlot(null);
               
               // Verify basic object state is initialized
               assertNotNull(plot);
               
               // Test inherited methods to ensure parent was initialized
               try {
                   // getPlotType() is a method from parent class
                   String plotType = plot.getPlotType();
                   assertNotNull(plotType);
                   
                   // equals() is inherited from Object via parent class
                   assertFalse(plot.equals(null));
                   
                   // hashCode() is inherited from Object via parent class
                   assertNotEquals(0, plot.hashCode());
               } catch (NullPointerException e) {
                   fail("NullPointerException indicates parent constructor wasn't called");
               }
               
               // Verify some default values that would be set by parent constructor
               assertEquals(1.0, plot.getLimit(), 0.0001);
               assertNull(plot.getDataset());
           }

    @Test
       public void testConstructorInitializesAllFields1() {
           // Arrange
           CategoryDataset dataset = mock(CategoryDataset.class);
           
           // Act
           MultiplePiePlot plot = new MultiplePiePlot(dataset);
           
           // Assert - verify all expected initializations
           assertNotNull("Pie chart should be initialized", plot.getPieChart());
           assertEquals("Dataset should be set", dataset, plot.getDataset());
           assertEquals("Default data extract order should be BY_COLUMN", 
               TableOrder.BY_COLUMN, plot.getDataExtractOrder());
           assertEquals("Default aggregated items key should be 'Other'", 
               "Other", plot.getAggregatedItemsKey());
           assertEquals("Default aggregated items paint should be light gray", 
               Color.lightGray, plot.getAggregatedItemsPaint());
           
           // Verify pie chart specific initializations
           JFreeChart pieChart = plot.getPieChart();
           assertNull("Background paint should be null", pieChart.getBackgroundPaint());
           assertNull("Legend should be removed", pieChart.getLegend());
           
           // Verify title settings
           TextTitle title = (TextTitle) pieChart.getTitle();
           assertNotNull("Title should be set", title);
           assertEquals("Title text should be 'Series Title'", 
               "Series Title", title.getText());
           assertEquals("Title position should be BOTTOM", 
               RectangleEdge.BOTTOM, title.getPosition());
       }

    @Test
          public void testConstructorWithNullInitializesPiePlotWithNullDataset1() {
              // Create instance with null parameter
              MultiplePiePlot multiplePiePlot = new MultiplePiePlot(null);
              
              // Get the pie chart and its plot
              JFreeChart pieChart = multiplePiePlot.getPieChart();
              assertNotNull("Pie chart should not be null", pieChart);
              
              PiePlot plot = (PiePlot) pieChart.getPlot();
              assertNotNull("Plot should not be null", plot);
              
              // Verify the dataset is null (original behavior)
              // This will fail if mutant is present (which uses default constructor)
              assertNull("PiePlot dataset should be null when constructed with null", 
                        plot.getDataset());
          }

    @Test
          public void testConstructorInitializesPiePlotWithNullDataset1() {
              // Create a mock dataset for the MultiplePiePlot constructor
              CategoryDataset dataset = mock(CategoryDataset.class);
              
              // Create the MultiplePiePlot instance
              MultiplePiePlot multiplePiePlot = new MultiplePiePlot(dataset);
              
              // Get the underlying pie chart and its plot
              JFreeChart pieChart = multiplePiePlot.getPieChart();
              PiePlot plot = (PiePlot) pieChart.getPlot();
              
              // Verify the plot's dataset is null as expected from the original constructor
              assertNull("PiePlot should be initialized with null dataset", 
                        plot.getDataset());
              
              // Additional verification that the chart is properly configured
              assertNotNull("PieChart should not be null", pieChart);
              assertEquals("Chart title should be 'Series Title'", 
                          "Series Title", pieChart.getTitle().getText());
              assertNull("Chart background paint should be null", 
                        pieChart.getBackgroundPaint());
          }

    @Test
         public void testConstructorInitializesPieChartProperly() {
             // Create an instance which will use the constructor
             MultiplePiePlot plot = new MultiplePiePlot(null);
             
             // Get the pieChart field
             JFreeChart pieChart = plot.getPieChart();
             
             // Verify the chart was created
             assertNotNull("PieChart should not be null", pieChart);
             
             // Verify the plot inside the chart is proper
             PiePlot plotInside = (PiePlot) pieChart.getPlot();
             assertNotNull("Plot inside chart should not be null", plotInside);
             
             // Additional verification that the plot is properly initialized
             // This would fail with the mutant since it creates a new PiePlot(null)
             assertNotSame("Plot should not be created with null dataset", 
                          null, plotInside.getDataset());
         }

    @Test
     public void testPieChartInitializationWithCorrectPiePlotInstance() {
         // Create a mock dataset
         CategoryDataset dataset = mock(CategoryDataset.class);
         
         // Create MultiplePiePlot instance
         MultiplePiePlot plot = new MultiplePiePlot(dataset);
         
         // Get the pie chart and its plot
         JFreeChart pieChart = plot.getPieChart();
         PiePlot chartPlot = (PiePlot) pieChart.getPlot();
         
         // Verify the plot is not null
         assertNotNull("PiePlot in chart should not be null", chartPlot);
         
         // The key assertion - verify the plot is the same instance that was created in the constructor
         // This will fail for the mutant since it creates a new PiePlot instance
         // We need to use reflection to get the original piePlot variable
         try {
             Field piePlotField = MultiplePiePlot.class.getDeclaredField("piePlot");
             piePlotField.setAccessible(true);
             PiePlot originalPiePlot = (PiePlot) piePlotField.get(plot);
             assertSame("PiePlot instance in chart should be the same as originally created", 
                       originalPiePlot, chartPlot);
         } catch (Exception e) {
             fail("Failed to access original piePlot field: " + e.getMessage());
         }
     }

    @Test
    public void testPieChartInitializationWithCorrectPiePlotInstance1() {
        // Create a mock dataset
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        // Create a spy PiePlot
        PiePlot spyPlot = mock(PiePlot.class);
        
        // Create MultiplePiePlot instance
        MultiplePiePlot plot = new MultiplePiePlot(dataset);
        
        // Get the pie chart and verify its plot
        JFreeChart pieChart = plot.getPieChart();
        assertNotNull("PieChart should not be null", pieChart);
        
        // Verify the plot is of type PiePlot (can't verify exact instance due to constructor limitations)
        assertTrue("PieChart should use a PiePlot instance", 
                  pieChart.getPlot() instanceof PiePlot);
        
        // Verify the plot was created with null dataset
        PiePlot actualPlot = (PiePlot) pieChart.getPlot();
        assertNull("PiePlot should be created with null dataset", 
                  actualPlot.getDataset());
    }


}
