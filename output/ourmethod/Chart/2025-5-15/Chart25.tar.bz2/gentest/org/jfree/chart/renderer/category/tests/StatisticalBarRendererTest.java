package gentest.org.jfree.chart.renderer.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.category.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
 
public class StatisticalBarRendererTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                   public void testDrawHorizontalItem_NullMeanValue() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock behavior
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(null);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Create instance and call method using reflection
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawHorizontalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify behavior
                                                                                                                                                                                                                                                       verify(g2, never()).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawHorizontalItem_WithoutStandardDeviation() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock behavior for state
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock behavior for dataset
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                                                                                                                       when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(null);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock behavior for plot
                                                                                                                                                                                                                                                       when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                       when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Create renderer and access protected method via reflection
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawHorizontalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify no lines were drawn (since no standard deviation)
                                                                                                                                                                                                                                                       verify(g2, never()).draw(any(Line2D.class));
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawHorizontalItem_WithItemLabels() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Create the renderer to test
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock required behaviors
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                                                                                                                       when(renderer.getItemLabelGenerator(anyInt(), anyInt())).thenReturn(mock(CategoryItemLabelGenerator.class));
                                                                                                                                                                                                                                                       when(renderer.isItemLabelVisible(anyInt(), anyInt())).thenReturn(true);
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                       when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawHorizontalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify the label was drawn
                                                                                                                                                                                                                                                       verify(g2, atLeastOnce()).drawString(anyString(), anyFloat(), anyFloat());
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawHorizontalItem_SingleSeries() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Stub the required methods
                                                                                                                                                                                                                                                       when(renderer.getRowCount()).thenReturn(1);
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to access the protected method
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawHorizontalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Call the method under test
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify the expected interaction
                                                                                                                                                                                                                                                       verify(g2, times(1)).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawHorizontalItem_MultipleSeries() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup mock behavior
                                                                                                                                                                                                                                                       when(renderer.getRowCount()).thenReturn(3);
                                                                                                                                                                                                                                                       when(renderer.getItemMargin()).thenReturn(0.1);
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup state
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup data area
                                                                                                                                                                                                                                                       when(dataArea.getHeight()).thenReturn(100.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawHorizontalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Call the method under test
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify the expected behavior
                                                                                                                                                                                                                                                       verify(g2, times(1)).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawVerticalItem_WithNullMeanValue() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock bar width in state
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock axis edges
                                                                                                                                                                                                                                                       when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                       when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock dataset to return null mean value
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(null);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Create renderer and access protected method via reflection
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawVerticalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify no drawing operations occurred
                                                                                                                                                                                                                                                       verify(g2, never()).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                       verify(g2, never()).draw(any(Rectangle2D.class));
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawVerticalItem_WithSingleSeries() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup mock behavior
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
                                                                                                                                                                                                                                                       when(dataset.getStdDevValue(0, 0)).thenReturn(2.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup state mock
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup plot mock
                                                                                                                                                                                                                                                       when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                       when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup axis mocks
                                                                                                                                                                                                                                                       when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                                                                                                           .thenReturn(0.0);
                                                                                                                                                                                                                                                       when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                                                                                                           .thenReturn(100.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawVerticalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       verify(g2).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                       verify(g2, times(3)).draw(any(Line2D.class)); // For error bars
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawVerticalItem_WithMultipleSeries() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Create real renderer
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup mock behavior
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(1, 0)).thenReturn(15.0);
                                                                                                                                                                                                                                                       when(dataset.getStdDevValue(1, 0)).thenReturn(3.0);
                                                                                                                                                                                                                                                       when(renderer.getRowCount()).thenReturn(3);
                                                                                                                                                                                                                                                       when(renderer.getColumnCount()).thenReturn(2);
                                                                                                                                                                                                                                                       when(renderer.getItemMargin()).thenReturn(0.1);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock state behavior
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       when(state.getEntityCollection()).thenReturn(null);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock plot behavior
                                                                                                                                                                                                                                                       when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                       when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock dataArea behavior
                                                                                                                                                                                                                                                       when(dataArea.getWidth()).thenReturn(100.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawVerticalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify interactions
                                                                                                                                                                                                                                                       verify(g2).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                       verify(g2, times(3)).draw(any(Line2D.class));
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawVerticalItem_WithValueAboveUpperClip() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Set up mock behavior
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(0, 0)).thenReturn(10.0);
                                                                                                                                                                                                                                                       when(renderer.getUpperClip()).thenReturn(5.0);
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawVerticalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify the expected behavior
                                                                                                                                                                                                                                                       verify(g2, never()).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawVerticalItem_WithValueBelowLowerClip() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Create the renderer
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Set up mock behavior
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(0, 0)).thenReturn(-10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to set private fields since they don't have public setters
                                                                                                                                                                                                                                                       Field lowerClipField = StatisticalBarRenderer.class.getDeclaredField("lowerClip");
                                                                                                                                                                                                                                                       lowerClipField.setAccessible(true);
                                                                                                                                                                                                                                                       lowerClipField.set(renderer, -5.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       Field upperClipField = StatisticalBarRenderer.class.getDeclaredField("upperClip");
                                                                                                                                                                                                                                                       upperClipField.setAccessible(true);
                                                                                                                                                                                                                                                       upperClipField.set(renderer, 5.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock plot behavior
                                                                                                                                                                                                                                                       when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                       when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock state behavior
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Get the method via reflection since it's protected
                                                                                                                                                                                                                                                       Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawVerticalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       drawVerticalItem.setAccessible(true);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Execute the test
                                                                                                                                                                                                                                                       drawVerticalItem.invoke(
                                                                                                                                                                                                                                                           renderer, 
                                                                                                                                                                                                                                                           g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify interactions
                                                                                                                                                                                                                                                       verify(g2).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                       // Verify the value was clipped to -5.0
                                                                                                                                                                                                                                                       verify(rangeAxis).valueToJava2D(-5.0, dataArea, RectangleEdge.LEFT);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawVerticalItem_WithValueBetweenClips() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = mock(StatisticalBarRenderer.class);
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Set up mock behavior
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(0, 0)).thenReturn(3.0);
                                                                                                                                                                                                                                                       when(renderer.getLowerClip()).thenReturn(-5.0);
                                                                                                                                                                                                                                                       when(renderer.getUpperClip()).thenReturn(5.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock bar width in state
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawVerticalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Call the method under test
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify interactions
                                                                                                                                                                                                                                                       verify(g2).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                       verify(rangeAxis).valueToJava2D(3.0, dataArea, RectangleEdge.LEFT);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                   public void testDrawVerticalItem_WithNegativeUpperClip() throws Exception {
                                                                                                                                                                                                                                                       // Create mock objects
                                                                                                                                                                                                                                                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                       Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                       Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                       CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                       ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Setup stubs
                                                                                                                                                                                                                                                       when(dataset.getMeanValue(0, 0)).thenReturn(-3.0);
                                                                                                                                                                                                                                                       when(renderer.getUpperClip()).thenReturn(-1.0);
                                                                                                                                                                                                                                                       when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                       when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                       when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Use reflection to access protected method
                                                                                                                                                                                                                                                       Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                           "drawVerticalItem", 
                                                                                                                                                                                                                                                           Graphics2D.class, 
                                                                                                                                                                                                                                                           CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                           Rectangle2D.class, 
                                                                                                                                                                                                                                                           CategoryPlot.class, 
                                                                                                                                                                                                                                                           CategoryAxis.class, 
                                                                                                                                                                                                                                                           ValueAxis.class, 
                                                                                                                                                                                                                                                           StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                           int.class, 
                                                                                                                                                                                                                                                           int.class
                                                                                                                                                                                                                                                       );
                                                                                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                                                                                       method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Verify interactions
                                                                                                                                                                                                                                                       verify(g2).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                       verify(rangeAxis).valueToJava2D(-1.0, dataArea, RectangleEdge.LEFT); // clipped value
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                               public void testDrawVerticalItem_WithItemLabels() throws Exception {
                                                                                                                                                                                                                                                   // Create mock objects
                                                                                                                                                                                                                                                   Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                   CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                   Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                   CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                   CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                   ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                   StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                   CategoryItemLabelGenerator labelGenerator = mock(CategoryItemLabelGenerator.class);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Mock state behavior
                                                                                                                                                                                                                                                   when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                   when(state.getEntityCollection()).thenReturn(null);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Mock dataset behavior
                                                                                                                                                                                                                                                   when(dataset.getMeanValue(0, 0)).thenReturn(5.0);
                                                                                                                                                                                                                                                   when(dataset.getStdDevValue(0, 0)).thenReturn(null);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Mock plot behavior
                                                                                                                                                                                                                                                   when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                   when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Create test renderer
                                                                                                                                                                                                                                                   StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Mock renderer behavior
                                                                                                                                                                                                                                                   when(renderer.isItemLabelVisible(0, 0)).thenReturn(true);
                                                                                                                                                                                                                                                   when(renderer.getItemLabelGenerator(0, 0)).thenReturn(labelGenerator);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Use reflection to access protected method
                                                                                                                                                                                                                                                   Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                       "drawVerticalItem", 
                                                                                                                                                                                                                                                       Graphics2D.class, 
                                                                                                                                                                                                                                                       CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                       Rectangle2D.class, 
                                                                                                                                                                                                                                                       CategoryPlot.class, 
                                                                                                                                                                                                                                                       CategoryAxis.class, 
                                                                                                                                                                                                                                                       ValueAxis.class, 
                                                                                                                                                                                                                                                       StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                       int.class, 
                                                                                                                                                                                                                                                       int.class
                                                                                                                                                                                                                                                   );
                                                                                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                                                                                   method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Verify interactions
                                                                                                                                                                                                                                                   verify(g2).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                   verify(g2, atLeastOnce()).drawString(anyString(), anyFloat(), anyFloat());
                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                               public void testDrawVerticalItem_WithBarOutline() throws Exception {
                                                                                                                                                                                                                                                   // Create mock objects
                                                                                                                                                                                                                                                   Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                   CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                   Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                   CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                   CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                   ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                   StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Set up test conditions
                                                                                                                                                                                                                                                   when(dataset.getMeanValue(0, 0)).thenReturn(5.0);
                                                                                                                                                                                                                                                   when(state.getBarWidth()).thenReturn(5.0); // > 3
                                                                                                                                                                                                                                                   when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                   when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Create renderer and set properties
                                                                                                                                                                                                                                                   StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                   renderer.setDrawBarOutline(true);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Get the protected method using reflection
                                                                                                                                                                                                                                                   Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                       "drawVerticalItem", 
                                                                                                                                                                                                                                                       Graphics2D.class, 
                                                                                                                                                                                                                                                       CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                       Rectangle2D.class, 
                                                                                                                                                                                                                                                       CategoryPlot.class, 
                                                                                                                                                                                                                                                       CategoryAxis.class, 
                                                                                                                                                                                                                                                       ValueAxis.class, 
                                                                                                                                                                                                                                                       StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                       int.class, 
                                                                                                                                                                                                                                                       int.class
                                                                                                                                                                                                                                                   );
                                                                                                                                                                                                                                                   drawVerticalItem.setAccessible(true);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Execute test
                                                                                                                                                                                                                                                   drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Verify behavior
                                                                                                                                                                                                                                                   verify(g2).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                                   verify(g2).draw(any(Rectangle2D.class));
                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                               public void testDrawVerticalItem_WithEntityCollection() throws Exception {
                                                                                                                                                                                                                                                   // Create all required mock objects
                                                                                                                                                                                                                                                   Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                   CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                   Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                   CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                   CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                   ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                   StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Set up mock behavior
                                                                                                                                                                                                                                                   when(dataset.getMeanValue(0, 0)).thenReturn(5.0);
                                                                                                                                                                                                                                                   EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                                                                                   when(state.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                                                                                   when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Mock plot behavior
                                                                                                                                                                                                                                                   when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                   when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Mock axis behavior
                                                                                                                                                                                                                                                   when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                                                                                                       .thenReturn(100.0);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Call the method under test using reflection
                                                                                                                                                                                                                                                   StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                   Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                       "drawVerticalItem", 
                                                                                                                                                                                                                                                       Graphics2D.class, 
                                                                                                                                                                                                                                                       CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                       Rectangle2D.class, 
                                                                                                                                                                                                                                                       CategoryPlot.class, 
                                                                                                                                                                                                                                                       CategoryAxis.class, 
                                                                                                                                                                                                                                                       ValueAxis.class, 
                                                                                                                                                                                                                                                       StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                       int.class, 
                                                                                                                                                                                                                                                       int.class
                                                                                                                                                                                                                                                   );
                                                                                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                                                                                   method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Verify the interaction
                                                                                                                                                                                                                                                   verify(entities).add(any());
                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                               public void testDrawHorizontalItem_WithStandardDeviation() throws Exception {
                                                                                                                                                                                                                                                   // Create mock objects
                                                                                                                                                                                                                                                   Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                   CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                   Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                                                   CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                   CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                   ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                   StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Configure state mock
                                                                                                                                                                                                                                                   when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Configure dataset mocks
                                                                                                                                                                                                                                                   when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                                                                                                                   when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(1.0);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Configure range axis mock
                                                                                                                                                                                                                                                   when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                                                                                                       .thenReturn(100.0).thenReturn(150.0).thenReturn(200.0);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Configure plot mock
                                                                                                                                                                                                                                                   when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                                                   when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Create renderer and set error indicator properties
                                                                                                                                                                                                                                                   StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                   renderer.setErrorIndicatorPaint(Color.GRAY);
                                                                                                                                                                                                                                                   renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Use reflection to access protected method
                                                                                                                                                                                                                                                   Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                       "drawHorizontalItem", 
                                                                                                                                                                                                                                                       Graphics2D.class, 
                                                                                                                                                                                                                                                       CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                       Rectangle2D.class, 
                                                                                                                                                                                                                                                       CategoryPlot.class, 
                                                                                                                                                                                                                                                       CategoryAxis.class, 
                                                                                                                                                                                                                                                       ValueAxis.class, 
                                                                                                                                                                                                                                                       StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                       int.class, 
                                                                                                                                                                                                                                                       int.class
                                                                                                                                                                                                                                                   );
                                                                                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Execute test
                                                                                                                                                                                                                                                   method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Verify drawing operations
                                                                                                                                                                                                                                                   verify(g2, atLeastOnce()).draw(any(Line2D.class));
                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                               public void testDrawHorizontalItem_WithBarOutline() throws Exception {
                                                                                                                                                                                                                                                   // Create mock objects
                                                                                                                                                                                                                                                   Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                                   CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                                   Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                                   CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                                   CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                                   ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                   StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Create renderer instance
                                                                                                                                                                                                                                                   StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Set up mock behavior
                                                                                                                                                                                                                                                   when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                                                                                                                   when(state.getBarWidth()).thenReturn(5.0); // > 3
                                                                                                                                                                                                                                                   when(renderer.isDrawBarOutline()).thenReturn(true);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Use reflection to access protected method
                                                                                                                                                                                                                                                   Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                       "drawHorizontalItem", 
                                                                                                                                                                                                                                                       Graphics2D.class, 
                                                                                                                                                                                                                                                       CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                       Rectangle2D.class, 
                                                                                                                                                                                                                                                       CategoryPlot.class, 
                                                                                                                                                                                                                                                       CategoryAxis.class, 
                                                                                                                                                                                                                                                       ValueAxis.class, 
                                                                                                                                                                                                                                                       StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                       int.class, 
                                                                                                                                                                                                                                                       int.class
                                                                                                                                                                                                                                                   );
                                                                                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                                                                                   method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Verify the expected behavior
                                                                                                                                                                                                                                                   verify(g2, atLeastOnce()).draw(any(Rectangle2D.class));
                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                           public void testDrawHorizontalItem_WithEntityCollection() throws Exception {
                                                                                                                                                                                                                                               // Create mock objects
                                                                                                                                                                                                                                               Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                               CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                               Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                               CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                               CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                               ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                               StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                               EntityCollection entities = mock(EntityCollection.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Stub method calls
                                                                                                                                                                                                                                               when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                                                                                                               when(state.getEntityCollection()).thenReturn(entities);
                                                                                                                                                                                                                                               when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Call the protected method using reflection
                                                                                                                                                                                                                                               StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                               Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                                   "drawHorizontalItem", 
                                                                                                                                                                                                                                                   Graphics2D.class, 
                                                                                                                                                                                                                                                   CategoryItemRendererState.class, 
                                                                                                                                                                                                                                                   Rectangle2D.class, 
                                                                                                                                                                                                                                                   CategoryPlot.class, 
                                                                                                                                                                                                                                                   CategoryAxis.class, 
                                                                                                                                                                                                                                                   ValueAxis.class, 
                                                                                                                                                                                                                                                   StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                                   int.class, 
                                                                                                                                                                                                                                                   int.class
                                                                                                                                                                                                                                               );
                                                                                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                                                                                               method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Verify the interaction
                                                                                                                                                                                                                                               verify(entities, times(1)).add(any(org.jfree.chart.entity.CategoryItemEntity.class));
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                       public void testDrawHorizontalItem_ValueBelowLowerClip() throws Exception {
                                                                                                                                                                                                                                           // Create mock objects
                                                                                                                                                                                                                                           Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                           CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                                           Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                                           CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                                           CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                                           ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                           StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Setup bar width in state
                                                                                                                                                                                                                                           when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Setup mock dataset to return test value
                                                                                                                                                                                                                                           when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Setup range axis to clip values below 15.0
                                                                                                                                                                                                                                           when(rangeAxis.getLowerBound()).thenReturn(15.0);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create renderer
                                                                                                                                                                                                                                           StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Use reflection to access protected method
                                                                                                                                                                                                                                           Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                                               "drawHorizontalItem", 
                                                                                                                                                                                                                                               Graphics2D.class, 
                                                                                                                                                                                                                                               CategoryItemRendererState.class, 
                                                                                                                                                                                                                                               Rectangle2D.class, 
                                                                                                                                                                                                                                               CategoryPlot.class, 
                                                                                                                                                                                                                                               CategoryAxis.class, 
                                                                                                                                                                                                                                               ValueAxis.class, 
                                                                                                                                                                                                                                               StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                                               int.class, 
                                                                                                                                                                                                                                               int.class
                                                                                                                                                                                                                                           );
                                                                                                                                                                                                                                           method.setAccessible(true);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Call the method under test
                                                                                                                                                                                                                                           method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify no bar was drawn
                                                                                                                                                                                                                                           verify(g2, never()).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                           public void testDrawHorizontalItem_ValueAboveUpperClip() throws Exception {
                                                                                                                                                                                                                               // Create mock objects
                                                                                                                                                                                                                               StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                               Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                               CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                               Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                               CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                               CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                               ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Set up bar width in state
                                                                                                                                                                                                                               when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Set up dataset to return value above upper clip
                                                                                                                                                                                                                               when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Set up range axis to simulate upper clip at 5.0
                                                                                                                                                                                                                               when(rangeAxis.getUpperBound()).thenReturn(5.0);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Create renderer
                                                                                                                                                                                                                               StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Use reflection to access protected method
                                                                                                                                                                                                                               java.lang.reflect.Method method = StatisticalBarRenderer.class
                                                                                                                                                                                                                                   .getDeclaredMethod("drawHorizontalItem", 
                                                                                                                                                                                                                                       Graphics2D.class,
                                                                                                                                                                                                                                       CategoryItemRendererState.class,
                                                                                                                                                                                                                                       Rectangle2D.class,
                                                                                                                                                                                                                                       CategoryPlot.class,
                                                                                                                                                                                                                                       CategoryAxis.class,
                                                                                                                                                                                                                                       ValueAxis.class,
                                                                                                                                                                                                                                       StatisticalCategoryDataset.class,
                                                                                                                                                                                                                                       int.class,
                                                                                                                                                                                                                                       int.class);
                                                                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                                                                               method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 1);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify no bar was drawn
                                                                                                                                                                                                                               verify(g2, never()).fill(any(Rectangle2D.class));
                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                      public void testDrawVerticalItem_DrawsErrorIndicators() throws Exception {
                                                                                                                                                                                                                          // Setup test data
                                                                                                                                                                                                                          StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                          when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
                                                                                                                                                                                                                          when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(2.0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Mock graphics and other dependencies
                                                                                                                                                                                                                          Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                          CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                          Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                                          CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                          ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                          CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Configure mocks
                                                                                                                                                                                                                          when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                          when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                          when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                                          when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                                                                              .thenReturn(50.0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Create renderer and set error indicator properties
                                                                                                                                                                                                                          StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                                          renderer.setErrorIndicatorPaint(Color.BLACK);
                                                                                                                                                                                                                          renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to access protected method
                                                                                                                                                                                                                          Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                              "drawVerticalItem", 
                                                                                                                                                                                                                              Graphics2D.class, 
                                                                                                                                                                                                                              CategoryItemRendererState.class, 
                                                                                                                                                                                                                              Rectangle2D.class, 
                                                                                                                                                                                                                              CategoryPlot.class, 
                                                                                                                                                                                                                              CategoryAxis.class, 
                                                                                                                                                                                                                              ValueAxis.class, 
                                                                                                                                                                                                                              StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                              int.class, 
                                                                                                                                                                                                                              int.class
                                                                                                                                                                                                                          );
                                                                                                                                                                                                                          drawVerticalItem.setAccessible(true);
                                                                                                                                                                                                                          drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify error indicators were drawn (3 lines per indicator)
                                                                                                                                                                                                                          verify(g2, times(3)).draw(any(Line2D.class));
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Additional verification that correct paint/stroke was used
                                                                                                                                                                                                                          verify(g2).setPaint(Color.BLACK);
                                                                                                                                                                                                                          verify(g2).setStroke(any(BasicStroke.class));
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                 public void testDrawVerticalItem_ItemLabelGeneratorUsesCorrectRowColumn() throws Exception {
                                                                                                                                                                                                                     // Setup test data
                                                                                                                                                                                                                     int row = 1;
                                                                                                                                                                                                                     int column = 2;
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Mock dependencies
                                                                                                                                                                                                                     Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                     CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                                     Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                                                                                                     CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                                     CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                                     ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                     StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Configure mocks
                                                                                                                                                                                                                     when(dataset.getMeanValue(row, column)).thenReturn(5.0);
                                                                                                                                                                                                                     when(dataset.getStdDevValue(row, column)).thenReturn(1.0);
                                                                                                                                                                                                                     when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                                     when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create different generators for row/column combinations
                                                                                                                                                                                                                     CategoryItemLabelGenerator row1Col2Generator = mock(CategoryItemLabelGenerator.class);
                                                                                                                                                                                                                     CategoryItemLabelGenerator row2Col1Generator = mock(CategoryItemLabelGenerator.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create test instance
                                                                                                                                                                                                                     StatisticalBarRenderer renderer = new StatisticalBarRenderer() {
                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                         public CategoryItemLabelGenerator getItemLabelGenerator(int r, int c) {
                                                                                                                                                                                                                             if (r == 1 && c == 2) return row1Col2Generator;
                                                                                                                                                                                                                             if (r == 2 && c == 1) return row2Col1Generator;
                                                                                                                                                                                                                             return null;
                                                                                                                                                                                                                         }
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                         public boolean isItemLabelVisible(int r, int c) {
                                                                                                                                                                                                                             return true;
                                                                                                                                                                                                                         }
                                                                                                                                                                                                                     };
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get the protected method via reflection
                                                                                                                                                                                                                     Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                         "drawVerticalItem", 
                                                                                                                                                                                                                         Graphics2D.class, 
                                                                                                                                                                                                                         CategoryItemRendererState.class, 
                                                                                                                                                                                                                         Rectangle2D.class, 
                                                                                                                                                                                                                         CategoryPlot.class, 
                                                                                                                                                                                                                         CategoryAxis.class, 
                                                                                                                                                                                                                         ValueAxis.class, 
                                                                                                                                                                                                                         StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                         int.class, 
                                                                                                                                                                                                                         int.class
                                                                                                                                                                                                                     );
                                                                                                                                                                                                                     drawVerticalItem.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Execute test
                                                                                                                                                                                                                     drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify the correct generator was used (should be row1Col2Generator)
                                                                                                                                                                                                                     // The mutation would have used row2Col1Generator instead
                                                                                                                                                                                                                     verify(row1Col2Generator, atLeastOnce()).generateLabel(dataset, row, column);
                                                                                                                                                                                                                     verify(row2Col1Generator, never()).generateLabel(any(), anyInt(), anyInt());
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                        public void testDrawVerticalItem_StdDevValueUsesCorrectIndices() throws Exception {
                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                            CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                                                            Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                                                            CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                                                            CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                                                            ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                            StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Configure mocks
                                                                                                                                                                                                            when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                                                            when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                                                            when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Set different values for (row,column) vs (row,row)
                                                                                                                                                                                                            int testRow = 1;
                                                                                                                                                                                                            int testColumn = 2;
                                                                                                                                                                                                            when(dataset.getMeanValue(testRow, testColumn)).thenReturn(50.0);
                                                                                                                                                                                                            when(dataset.getStdDevValue(testRow, testColumn)).thenReturn(5.0); // correct value
                                                                                                                                                                                                            when(dataset.getStdDevValue(testRow, testRow)).thenReturn(10.0); // wrong value if mutation exists
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Mock value to Java2D conversions
                                                                                                                                                                                                            when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                                                                                                                                                                                                                .thenAnswer(inv -> {
                                                                                                                                                                                                                    double val = inv.getArgument(0);
                                                                                                                                                                                                                    return 100 - val; // simple conversion for testing
                                                                                                                                                                                                                });
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create renderer and test using reflection to access protected method
                                                                                                                                                                                                            StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                                                            Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                                                "drawVerticalItem", 
                                                                                                                                                                                                                Graphics2D.class, 
                                                                                                                                                                                                                CategoryItemRendererState.class, 
                                                                                                                                                                                                                Rectangle2D.class, 
                                                                                                                                                                                                                CategoryPlot.class, 
                                                                                                                                                                                                                CategoryAxis.class, 
                                                                                                                                                                                                                ValueAxis.class, 
                                                                                                                                                                                                                StatisticalCategoryDataset.class, 
                                                                                                                                                                                                                int.class, 
                                                                                                                                                                                                                int.class
                                                                                                                                                                                                            );
                                                                                                                                                                                                            drawVerticalItem.setAccessible(true);
                                                                                                                                                                                                            drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, 
                                                                                                                                                                                                                                  dataset, testRow, testColumn);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify the error bars were drawn using correct stdDev (5.0)
                                                                                                                                                                                                            // Should draw lines at 45 and 55 (50±5)
                                                                                                                                                                                                            org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = 
                                                                                                                                                                                                                org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                                                                                                                                                                                            verify(g2, atLeastOnce()).draw(lineCaptor.capture());
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Check vertical error line (should be from 45 to 55)
                                                                                                                                                                                                            List<java.awt.geom.Line2D> lines = lineCaptor.getAllValues();
                                                                                                                                                                                                            boolean foundVertical = false;
                                                                                                                                                                                                            for (java.awt.geom.Line2D line : lines) {
                                                                                                                                                                                                                if (Math.abs(line.getY1() - 45) < 0.1 && 
                                                                                                                                                                                                                    Math.abs(line.getY2() - 55) < 0.1) {
                                                                                                                                                                                                                    foundVertical = true;
                                                                                                                                                                                                                    break;
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            assertTrue("Error bars not drawn at correct positions", foundVertical);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                               public void testDrawVerticalItem_ErrorIndicatorPosition() throws Exception {
                                                                                                                                                                                   // Setup test data
                                                                                                                                                                                   int row = 0;
                                                                                                                                                                                   int column = 0;
                                                                                                                                                                                   double meanValue = 10.0;
                                                                                                                                                                                   double stdDev = 2.0;
                                                                                                                                                                                   
                                                                                                                                                                                   // Mock required objects
                                                                                                                                                                                   java.awt.Graphics2D g2 = mock(java.awt.Graphics2D.class);
                                                                                                                                                                                   org.jfree.chart.renderer.category.CategoryItemRendererState state = mock(org.jfree.chart.renderer.category.CategoryItemRendererState.class);
                                                                                                                                                                                   java.awt.geom.Rectangle2D dataArea = new java.awt.geom.Rectangle2D.Double(0, 0, 200, 200);
                                                                                                                                                                                   org.jfree.chart.plot.CategoryPlot plot = mock(org.jfree.chart.plot.CategoryPlot.class);
                                                                                                                                                                                   org.jfree.chart.axis.CategoryAxis domainAxis = mock(org.jfree.chart.axis.CategoryAxis.class);
                                                                                                                                                                                   org.jfree.chart.axis.ValueAxis rangeAxis = mock(org.jfree.chart.axis.ValueAxis.class);
                                                                                                                                                                                   org.jfree.data.statistics.StatisticalCategoryDataset dataset = mock(org.jfree.data.statistics.StatisticalCategoryDataset.class);
                                                                                                                                                                                   
                                                                                                                                                                                   // Mock behavior
                                                                                                                                                                                   when(state.getBarWidth()).thenReturn(20.0);
                                                                                                                                                                                   when(dataset.getMeanValue(row, column)).thenReturn(meanValue);
                                                                                                                                                                                   when(dataset.getStdDevValue(row, column)).thenReturn(stdDev);
                                                                                                                                                                                   when(plot.getDomainAxisEdge()).thenReturn(org.jfree.chart.util.RectangleEdge.BOTTOM);
                                                                                                                                                                                   when(plot.getRangeAxisEdge()).thenReturn(org.jfree.chart.util.RectangleEdge.LEFT);
                                                                                                                                                                                   when(rangeAxis.valueToJava2D(anyDouble(), any(java.awt.geom.Rectangle2D.class), any(org.jfree.chart.util.RectangleEdge.class)))
                                                                                                                                                                                       .thenAnswer(inv -> {
                                                                                                                                                                                           double value = inv.getArgument(0);
                                                                                                                                                                                           return 200 - (value * 10); // Simple scaling for test
                                                                                                                                                                                       });
                                                                                                                                                                                   when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(java.awt.geom.Rectangle2D.class), any(org.jfree.chart.util.RectangleEdge.class)))
                                                                                                                                                                                       .thenReturn(50.0);
                                                                                                                                                                                   
                                                                                                                                                                                   // Create renderer and set error indicator properties
                                                                                                                                                                                   org.jfree.chart.renderer.category.StatisticalBarRenderer renderer = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
                                                                                                                                                                                   renderer.setErrorIndicatorPaint(java.awt.Color.BLACK);
                                                                                                                                                                                   renderer.setErrorIndicatorStroke(new java.awt.BasicStroke(1.0f));
                                                                                                                                                                                   
                                                                                                                                                                                   // Capture drawn lines
                                                                                                                                                                                   org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                                                                                                                                                                   
                                                                                                                                                                                   // Use reflection to access protected method
                                                                                                                                                                                   java.lang.reflect.Method method = org.jfree.chart.renderer.category.StatisticalBarRenderer.class
                                                                                                                                                                                       .getDeclaredMethod("drawVerticalItem", java.awt.Graphics2D.class, 
                                                                                                                                                                                           org.jfree.chart.renderer.category.CategoryItemRendererState.class, 
                                                                                                                                                                                           java.awt.geom.Rectangle2D.class, 
                                                                                                                                                                                           org.jfree.chart.plot.CategoryPlot.class, 
                                                                                                                                                                                           org.jfree.chart.axis.CategoryAxis.class, 
                                                                                                                                                                                           org.jfree.chart.axis.ValueAxis.class, 
                                                                                                                                                                                           org.jfree.data.statistics.StatisticalCategoryDataset.class, 
                                                                                                                                                                                           int.class, int.class);
                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                   method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify error indicators were drawn (3 lines total)
                                                                                                                                                                                   verify(g2, times(3)).draw(lineCaptor.capture());
                                                                                                                                                                                   
                                                                                                                                                                                   // Get all drawn lines
                                                                                                                                                                                   java.util.List<java.awt.geom.Line2D> drawnLines = lineCaptor.getAllValues();
                                                                                                                                                                                   
                                                                                                                                                                                   // The lower horizontal line should be the third one drawn
                                                                                                                                                                                   java.awt.geom.Line2D lowerHorizontalLine = drawnLines.get(2);
                                                                                                                                                                                   
                                                                                                                                                                                   // Calculate expected x-coordinates
                                                                                                                                                                                   double centerX = 50.0 + (20.0 / 2.0); // rectX + rectWidth/2
                                                                                                                                                                                   double expectedX1 = centerX - 5.0; // Original correct position
                                                                                                                                                                                   double expectedX2 = centerX + 5.0; // Mutated position
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify the x-coordinates of the lower horizontal line
                                                                                                                                                                                   assertEquals("Lower error indicator x1 should be center - 5", expectedX1, lowerHorizontalLine.getX1(), 0.001);
                                                                                                                                                                                   assertEquals("Lower error indicator x2 should be center + 5", expectedX2, lowerHorizontalLine.getX2(), 0.001);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                          public void testDrawVerticalItem_ErrorIndicatorPosition1() throws Exception {
                                                                                                                                                                              // Setup test data
                                                                                                                                                                              StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                              when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
                                                                                                                                                                              when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(2.0);
                                                                                                                                                                              
                                                                                                                                                                              // Mock dependencies
                                                                                                                                                                              Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                              CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                              when(state.getBarWidth()).thenReturn(20.0);
                                                                                                                                                                              when(state.getEntityCollection()).thenReturn(null);
                                                                                                                                                                              
                                                                                                                                                                              Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
                                                                                                                                                                              CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                              when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                              when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                              
                                                                                                                                                                              ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                              when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                                  .thenAnswer(inv -> inv.getArgument(0));
                                                                                                                                                                              
                                                                                                                                                                              // Create renderer and set up error indicators
                                                                                                                                                                              StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                              renderer.setErrorIndicatorPaint(Color.BLACK);
                                                                                                                                                                              renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                                                                                                                                                                              
                                                                                                                                                                              // Capture drawn lines
                                                                                                                                                                              List<Line2D> drawnLines = new ArrayList<>();
                                                                                                                                                                              doAnswer(inv -> {
                                                                                                                                                                                  drawnLines.add((Line2D) inv.getArgument(0));
                                                                                                                                                                                  return null;
                                                                                                                                                                              }).when(g2).draw(any(Line2D.class));
                                                                                                                                                                              
                                                                                                                                                                              // Get the protected method using reflection
                                                                                                                                                                              Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                                  "drawVerticalItem", 
                                                                                                                                                                                  Graphics2D.class, 
                                                                                                                                                                                  CategoryItemRendererState.class, 
                                                                                                                                                                                  Rectangle2D.class, 
                                                                                                                                                                                  CategoryPlot.class, 
                                                                                                                                                                                  CategoryAxis.class, 
                                                                                                                                                                                  ValueAxis.class, 
                                                                                                                                                                                  StatisticalCategoryDataset.class, 
                                                                                                                                                                                  int.class, 
                                                                                                                                                                                  int.class
                                                                                                                                                                              );
                                                                                                                                                                              drawVerticalItem.setAccessible(true);
                                                                                                                                                                              
                                                                                                                                                                              // Execute test
                                                                                                                                                                              drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, 
                                                                                                                                                                                  mock(CategoryAxis.class), rangeAxis, dataset, 0, 0);
                                                                                                                                                                              
                                                                                                                                                                              // Verify error indicator positions
                                                                                                                                                                              assertEquals(3, drawnLines.size()); // vertical line and two horizontal lines
                                                                                                                                                                              
                                                                                                                                                                              // Check lower error line position (should be at -5 units from center)
                                                                                                                                                                              Line2D lowerLine = drawnLines.get(2);
                                                                                                                                                                              double centerX = 10.0; // rectX + rectWidth/2 (assuming rectX=0 for simplicity)
                                                                                                                                                                              double expectedX1 = centerX - 5.0;
                                                                                                                                                                              double expectedX2 = centerX + 5.0;
                                                                                                                                                                              assertEquals(expectedX1, lowerLine.getX1(), 0.001);
                                                                                                                                                                              assertEquals(expectedX2, lowerLine.getX2(), 0.001);
                                                                                                                                                                              assertEquals(lowerLine.getY1(), lowerLine.getY2(), 0.001); // horizontal line
                                                                                                                                                                          }

    @Test
                                                                                                                                                                 public void testDrawVerticalItem_ErrorIndicatorLinePositions() throws Exception {
                                                                                                                                                                     // Setup test data
                                                                                                                                                                     StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                                     Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                     CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                                     Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                     CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                                     CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                                     ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                     StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                                     
                                                                                                                                                                     // Mock necessary behaviors
                                                                                                                                                                     when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                                     when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                                     when(state.getBarWidth()).thenReturn(20.0);
                                                                                                                                                                     when(state.getEntityCollection()).thenReturn(null);
                                                                                                                                                                     
                                                                                                                                                                     // Setup dataset to return valid values
                                                                                                                                                                     when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(50.0);
                                                                                                                                                                     when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                                     
                                                                                                                                                                     // Mock category axis behavior
                                                                                                                                                                     when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                         .thenReturn(10.0);
                                                                                                                                                                     
                                                                                                                                                                     // Mock range axis behavior
                                                                                                                                                                     when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                         .thenAnswer(inv -> {
                                                                                                                                                                             double value = inv.getArgument(0);
                                                                                                                                                                             return 100 - value; // Simple mapping for testing
                                                                                                                                                                         });
                                                                                                                                                                     
                                                                                                                                                                     // Create argument captor for Line2D objects
                                                                                                                                                                     org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = 
                                                                                                                                                                         org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to access protected method
                                                                                                                                                                     Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                         "drawVerticalItem", 
                                                                                                                                                                         Graphics2D.class, 
                                                                                                                                                                         CategoryItemRendererState.class, 
                                                                                                                                                                         Rectangle2D.class, 
                                                                                                                                                                         CategoryPlot.class, 
                                                                                                                                                                         CategoryAxis.class, 
                                                                                                                                                                         ValueAxis.class, 
                                                                                                                                                                         StatisticalCategoryDataset.class, 
                                                                                                                                                                         int.class, 
                                                                                                                                                                         int.class
                                                                                                                                                                     );
                                                                                                                                                                     drawVerticalItem.setAccessible(true);
                                                                                                                                                                     drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                                     
                                                                                                                                                                     // Verify the lines were drawn and capture them
                                                                                                                                                                     verify(g2, times(3)).draw(lineCaptor.capture());
                                                                                                                                                                     
                                                                                                                                                                     // Get all drawn lines
                                                                                                                                                                     List<java.awt.geom.Line2D> drawnLines = lineCaptor.getAllValues();
                                                                                                                                                                     
                                                                                                                                                                     // The third line is the lower error indicator line (mutated line)
                                                                                                                                                                     java.awt.geom.Line2D lowerErrorLine = drawnLines.get(2);
                                                                                                                                                                     
                                                                                                                                                                     // Calculate expected x-coordinate (center of bar + 5)
                                                                                                                                                                     double expectedX = 10 + (20 / 2.0) + 5.0;
                                                                                                                                                                     
                                                                                                                                                                     // Verify the x-coordinate of the lower error line
                                                                                                                                                                     assertEquals("Lower error line x1 coordinate incorrect", 
                                                                                                                                                                         expectedX, lowerErrorLine.getX1(), 0.001);
                                                                                                                                                                     assertEquals("Lower error line x2 coordinate incorrect",
                                                                                                                                                                         expectedX, lowerErrorLine.getX2(), 0.001);
                                                                                                                                                                     
                                                                                                                                                                     // Also verify the y-coordinates are the same (should be at lowVal)
                                                                                                                                                                     assertEquals("Lower error line y-coordinates should be equal",
                                                                                                                                                                         lowerErrorLine.getY1(), lowerErrorLine.getY2(), 0.001);
                                                                                                                                                                 }

    @Test
                                                                                                                                                        public void testDrawVerticalItem_ErrorIndicatorPosition2() throws Exception {
                                                                                                                                                            // Setup test data
                                                                                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                            CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                                            Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                            CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                            CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                                            ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                            StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                                            
                                                                                                                                                            // Configure mocks
                                                                                                                                                            when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                                            when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                                            when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                                            when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(50.0);
                                                                                                                                                            when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                                                                                            
                                                                                                                                                            // Mock the range axis value conversions
                                                                                                                                                            when(rangeAxis.valueToJava2D(eq(45.0), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                .thenReturn(60.0); // lowVal (mean - std dev)
                                                                                                                                                            when(rangeAxis.valueToJava2D(eq(50.0), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                .thenReturn(50.0); // mean
                                                                                                                                                            when(rangeAxis.valueToJava2D(eq(55.0), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                                .thenReturn(40.0); // highVal (mean + std dev)
                                                                                                                                                            
                                                                                                                                                            // Create the renderer and set error indicator properties
                                                                                                                                                            StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                                            renderer.setErrorIndicatorPaint(Color.BLACK);
                                                                                                                                                            renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                                                                                                                                                            
                                                                                                                                                            // Argument captor to verify line coordinates
                                                                                                                                                            org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = 
                                                                                                                                                                org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access protected method
                                                                                                                                                            Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                                "drawVerticalItem", 
                                                                                                                                                                Graphics2D.class, 
                                                                                                                                                                CategoryItemRendererState.class, 
                                                                                                                                                                Rectangle2D.class, 
                                                                                                                                                                CategoryPlot.class, 
                                                                                                                                                                CategoryAxis.class, 
                                                                                                                                                                ValueAxis.class, 
                                                                                                                                                                StatisticalCategoryDataset.class, 
                                                                                                                                                                int.class, 
                                                                                                                                                                int.class
                                                                                                                                                            );
                                                                                                                                                            drawVerticalItem.setAccessible(true);
                                                                                                                                                            drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                                            
                                                                                                                                                            // Verify the error indicator lines were drawn
                                                                                                                                                            verify(g2, times(3)).draw(lineCaptor.capture());
                                                                                                                                                            
                                                                                                                                                            // Get all drawn lines
                                                                                                                                                            List<java.awt.geom.Line2D> drawnLines = lineCaptor.getAllValues();
                                                                                                                                                            
                                                                                                                                                            // The third line should be the lower error indicator (horizontal line at lowVal)
                                                                                                                                                            java.awt.geom.Line2D lowerErrorLine = drawnLines.get(2);
                                                                                                                                                            assertEquals(60.0, lowerErrorLine.getY1(), 0.001); // Should be at lowVal (60)
                                                                                                                                                            assertEquals(60.0, lowerErrorLine.getY2(), 0.001); // Should be at lowVal (60)
                                                                                                                                                            
                                                                                                                                                            // The mutation would make this line be at highVal (40) instead
                                                                                                                                                        }

    @Test
                                                                                                                                           public void testDrawVerticalItem_DrawsErrorIndicators1() throws Exception {
                                                                                                                                               // Setup test data and mocks
                                                                                                                                               Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                               CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                               Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                               CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                               CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                               ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                               StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                               
                                                                                                                                               // Configure mocks
                                                                                                                                               when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                               when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                               when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
                                                                                                                                               when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(2.0);
                                                                                                                                               when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                                   .thenReturn(50.0);
                                                                                                                                               
                                                                                                                                               // Create renderer and set necessary properties
                                                                                                                                               StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                               renderer.setErrorIndicatorPaint(Color.BLACK);
                                                                                                                                               renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                                                                                                                                               
                                                                                                                                               // Use reflection to access protected method
                                                                                                                                               Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                                   "drawVerticalItem", 
                                                                                                                                                   Graphics2D.class, 
                                                                                                                                                   CategoryItemRendererState.class, 
                                                                                                                                                   Rectangle2D.class, 
                                                                                                                                                   CategoryPlot.class, 
                                                                                                                                                   CategoryAxis.class, 
                                                                                                                                                   ValueAxis.class, 
                                                                                                                                                   StatisticalCategoryDataset.class, 
                                                                                                                                                   int.class, 
                                                                                                                                                   int.class
                                                                                                                                               );
                                                                                                                                               drawVerticalItem.setAccessible(true);
                                                                                                                                               drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                               
                                                                                                                                               // Verify error indicators were drawn (3 lines total)
                                                                                                                                               verify(g2, times(3)).draw(any(java.awt.geom.Line2D.class));
                                                                                                                                               
                                                                                                                                               // Additional verification for the specific lines
                                                                                                                                               org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = 
                                                                                                                                                   org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                                                                                                                               verify(g2, times(3)).draw(lineCaptor.capture());
                                                                                                                                               
                                                                                                                                               List<java.awt.geom.Line2D> drawnLines = lineCaptor.getAllValues();
                                                                                                                                               assertEquals(3, drawnLines.size());
                                                                                                                                               // Could add more specific assertions about line positions if needed
                                                                                                                                           }

    @Test
                                                                                                                                  public void testDrawVerticalItemErrorIndicatorLinesAreDrawnNotFilled() throws Exception {
                                                                                                                                      // Setup test data
                                                                                                                                      StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                                                      when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
                                                                                                                                      when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(1.0);
                                                                                                                                      
                                                                                                                                      // Mock dependencies
                                                                                                                                      Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                      CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                      Rectangle2D dataArea = mock(Rectangle2D.class);
                                                                                                                                      CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                                                      ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                      CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                                                      
                                                                                                                                      // Configure mocks
                                                                                                                                      when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                                                      when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                                                      when(dataArea.getWidth()).thenReturn(100.0);
                                                                                                                                      when(state.getBarWidth()).thenReturn(10.0);
                                                                                                                                      when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                                                          .thenReturn(50.0);
                                                                                                                                      
                                                                                                                                      // Create renderer and set error indicator properties
                                                                                                                                      StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                                                      renderer.setErrorIndicatorPaint(Color.BLACK);
                                                                                                                                      renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                                                                                                                                      
                                                                                                                                      // Use reflection to access protected method
                                                                                                                                      Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                                                          "drawVerticalItem",
                                                                                                                                          Graphics2D.class,
                                                                                                                                          CategoryItemRendererState.class,
                                                                                                                                          Rectangle2D.class,
                                                                                                                                          CategoryPlot.class,
                                                                                                                                          CategoryAxis.class,
                                                                                                                                          ValueAxis.class,
                                                                                                                                          StatisticalCategoryDataset.class,
                                                                                                                                          int.class,
                                                                                                                                          int.class
                                                                                                                                      );
                                                                                                                                      drawVerticalItem.setAccessible(true);
                                                                                                                                      drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                                                                      
                                                                                                                                      // Verify error indicator lines were drawn (not filled)
                                                                                                                                      // Should be 3 draw calls for the error indicator lines (vertical line and two horizontal caps)
                                                                                                                                      verify(g2, times(3)).draw(any(Line2D.class));
                                                                                                                                      verify(g2, never()).fill(any(Line2D.class));
                                                                                                                                      
                                                                                                                                      // Additional verification that we're testing the right thing
                                                                                                                                      verify(dataset).getStdDevValue(0, 0); // Ensure we're testing error indicator case
                                                                                                                                  }

    @Test
                                                                                                     public void testDrawVerticalItem_ItemLabelGeneratorParameters() throws Exception {
                                                                                                         // Setup test data and mocks
                                                                                                         Graphics2D g2 = mock(Graphics2D.class);
                                                                                                         CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                         Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                         CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                         CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                         ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                         StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                         
                                                                                                         // Use different row and column values to detect parameter swap
                                                                                                         final int row = 1;
                                                                                                         final int column = 2;
                                                                                                         
                                                                                                         // Mock dataset behavior
                                                                                                         when(dataset.getMeanValue(row, column)).thenReturn(5.0);
                                                                                                         when(dataset.getStdDevValue(row, column)).thenReturn(1.0);
                                                                                                         
                                                                                                         // Create mock generators that return different values based on parameter order
                                                                                                         CategoryItemLabelGenerator rowFirstGenerator = mock(CategoryItemLabelGenerator.class);
                                                                                                         CategoryItemLabelGenerator columnFirstGenerator = mock(CategoryItemLabelGenerator.class);
                                                                                                         
                                                                                                         // Configure the renderer
                                                                                                         StatisticalBarRenderer renderer = new StatisticalBarRenderer() {
                                                                                                             @Override
                                                                                                             public CategoryItemLabelGenerator getItemLabelGenerator(int r, int c) {
                                                                                                                 // Return different mock generators based on parameter order
                                                                                                                 if (r == row && c == column) {
                                                                                                                     return rowFirstGenerator;
                                                                                                                 } else if (r == column && c == row) {
                                                                                                                     return columnFirstGenerator;
                                                                                                                 }
                                                                                                                 return null;
                                                                                                             }
                                                                                                         };
                                                                                                         renderer.setBaseItemLabelGenerator(rowFirstGenerator);
                                                                                                         
                                                                                                         // Use reflection to set item labels visible
                                                                                                         Method setItemLabelsVisible = StatisticalBarRenderer.class.getSuperclass()
                                                                                                             .getDeclaredMethod("setItemLabelsVisible", boolean.class);
                                                                                                         setItemLabelsVisible.setAccessible(true);
                                                                                                         setItemLabelsVisible.invoke(renderer, true);
                                                                                                         
                                                                                                         // Mock plot and axis behavior
                                                                                                         when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                         when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                         when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                             .thenReturn(10.0);
                                                                                                         when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                                                                             .thenReturn(50.0);
                                                                                                         
                                                                                                         // Use reflection to call protected method
                                                                                                         Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                             "drawVerticalItem", Graphics2D.class, CategoryItemRendererState.class,
                                                                                                             Rectangle2D.class, CategoryPlot.class, CategoryAxis.class,
                                                                                                             ValueAxis.class, StatisticalCategoryDataset.class, int.class, int.class);
                                                                                                         drawVerticalItem.setAccessible(true);
                                                                                                         drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, 
                                                                                                             rangeAxis, dataset, row, column);
                                                                                                         
                                                                                                         // Verify the correct generator was used (should be rowFirstGenerator)
                                                                                                         // If the mutant is present, it would use columnFirstGenerator instead
                                                                                                         verify(rowFirstGenerator, atLeastOnce()).generateLabel(dataset, row, column);
                                                                                                         verify(columnFirstGenerator, never()).generateLabel(any(), anyInt(), anyInt());
                                                                                                     }

    @Test
                                                                                                public void testDrawVerticalItemUsesCorrectStdDevValue() throws Exception {
                                                                                                    // Setup
                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                    CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                                    Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                    CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                                    ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                    StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                                    
                                                                                                    // Configure mocks
                                                                                                    when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                                    when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                                    when(state.getBarWidth()).thenReturn(10.0);
                                                                                                    
                                                                                                    // Set different mean values for row/column vs row/row
                                                                                                    when(dataset.getMeanValue(1, 2)).thenReturn(5.0);
                                                                                                    when(dataset.getStdDevValue(1, 2)).thenReturn(1.0);  // Correct value
                                                                                                    when(dataset.getStdDevValue(1, 1)).thenReturn(100.0); // Wrong value that mutant would use
                                                                                                    
                                                                                                    // Create renderer and enable error indicators
                                                                                                    StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                                    renderer.setErrorIndicatorPaint(Color.BLACK);
                                                                                                    renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                                                                                                    
                                                                                                    // Use reflection to access protected method
                                                                                                    Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                                        "drawVerticalItem", 
                                                                                                        Graphics2D.class, 
                                                                                                        CategoryItemRendererState.class, 
                                                                                                        Rectangle2D.class, 
                                                                                                        CategoryPlot.class, 
                                                                                                        CategoryAxis.class, 
                                                                                                        ValueAxis.class, 
                                                                                                        StatisticalCategoryDataset.class, 
                                                                                                        int.class, 
                                                                                                        int.class
                                                                                                    );
                                                                                                    drawVerticalItem.setAccessible(true);
                                                                                                    drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 1, 2);
                                                                                                    
                                                                                                    // Verify correct std dev value was used (should result in y positions ±1 from mean)
                                                                                                    // The mutant would use value 100.0 instead, resulting in much larger error bars
                                                                                                    verify(rangeAxis).valueToJava2D(eq(4.0), eq(dataArea), eq(RectangleEdge.LEFT));
                                                                                                    verify(rangeAxis).valueToJava2D(eq(6.0), eq(dataArea), eq(RectangleEdge.LEFT));
                                                                                                }

    @Test
                                                                                       public void testDrawVerticalItemUsesCorrectColumnMeanValue() throws Exception {
                                                                                           // Setup
                                                                                           StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                           Graphics2D g2 = mock(Graphics2D.class);
                                                                                           CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                           Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                           CategoryPlot plot = mock(CategoryPlot.class);
                                                                                           CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                           ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                           StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                           
                                                                                           // Configure mocks
                                                                                           when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                           when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                           when(state.getBarWidth()).thenReturn(10.0);
                                                                                           
                                                                                           // Set different mean values for adjacent columns
                                                                                           when(dataset.getMeanValue(0, 0)).thenReturn(10.0);  // Correct column
                                                                                           when(dataset.getMeanValue(0, 1)).thenReturn(20.0);  // Next column (mutant would use this)
                                                                                           when(dataset.getStdDevValue(0, 0)).thenReturn(1.0);
                                                                                           
                                                                                           // Configure axis value mapping
                                                                                           when(rangeAxis.valueToJava2D(anyDouble(), eq(dataArea), any()))
                                                                                               .thenAnswer(inv -> 100 - (double)inv.getArguments()[0]); // Simple mapping for testing
                                                                                           
                                                                                           // Use reflection to access protected method
                                                                                           Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                               "drawVerticalItem", 
                                                                                               Graphics2D.class, 
                                                                                               CategoryItemRendererState.class, 
                                                                                               Rectangle2D.class, 
                                                                                               CategoryPlot.class, 
                                                                                               CategoryAxis.class, 
                                                                                               ValueAxis.class, 
                                                                                               StatisticalCategoryDataset.class, 
                                                                                               int.class, 
                                                                                               int.class
                                                                                           );
                                                                                           drawVerticalItem.setAccessible(true);
                                                                                           drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                                                           
                                                                                           // Verify the correct mean value was used (should be 10.0, not 20.0)
                                                                                           // The y position should be based on 10.0 (100-10=90)
                                                                                           org.mockito.ArgumentCaptor<Rectangle2D> barCaptor = org.mockito.ArgumentCaptor.forClass(Rectangle2D.class);
                                                                                           verify(g2).fill(barCaptor.capture());
                                                                                           Rectangle2D drawnBar = barCaptor.getValue();
                                                                                           
                                                                                           // The bar should be drawn at y=90 (100-10) if using correct column mean
                                                                                           assertEquals(90.0, drawnBar.getY(), 0.001);
                                                                                           
                                                                                           // Also verify the error bars are drawn at correct positions (10±1)
                                                                                           org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                                                                           verify(g2, times(3)).draw(lineCaptor.capture());
                                                                                           List<java.awt.geom.Line2D> lines = lineCaptor.getAllValues();
                                                                                           
                                                                                           // Main error line (9 to 11)
                                                                                           assertEquals(91.0, lines.get(0).getY1(), 0.001);  // 100-9=91
                                                                                           assertEquals(89.0, lines.get(0).getY2(), 0.001);  // 100-11=89
                                                                                           
                                                                                           // Upper cap line (at 11)
                                                                                           assertEquals(89.0, lines.get(1).getY1(), 0.001);
                                                                                           
                                                                                           // Lower cap line (at 9)
                                                                                           assertEquals(91.0, lines.get(2).getY1(), 0.001);
                                                                                       }

    @Test
                                                                              public void testDrawVerticalItem_StdDevValueUsesCorrectColumn() throws Exception {
                                                                                  // Setup
                                                                                  Graphics2D g2 = mock(Graphics2D.class);
                                                                                  CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                                                  Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                  CategoryPlot plot = mock(CategoryPlot.class);
                                                                                  CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                                                  ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                  StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                                                  
                                                                                  // Configure mocks
                                                                                  when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                                                  when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                                                  when(state.getBarWidth()).thenReturn(10.0);
                                                                                  
                                                                                  // Setup different std dev values for different columns
                                                                                  when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(5.0);
                                                                                  when(dataset.getStdDevValue(0, 0)).thenReturn(1.0);  // Column 0
                                                                                  when(dataset.getStdDevValue(0, 1)).thenReturn(2.0);  // Column 1
                                                                                  
                                                                                  // Test with column 1 - should use std dev value 2.0
                                                                                  StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                                                  
                                                                                  // Use reflection to access protected method
                                                                                  Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                                                      "drawVerticalItem", 
                                                                                      Graphics2D.class, 
                                                                                      CategoryItemRendererState.class, 
                                                                                      Rectangle2D.class, 
                                                                                      CategoryPlot.class, 
                                                                                      CategoryAxis.class, 
                                                                                      ValueAxis.class, 
                                                                                      StatisticalCategoryDataset.class, 
                                                                                      int.class, 
                                                                                      int.class
                                                                                  );
                                                                                  drawVerticalItem.setAccessible(true);
                                                                                  drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 1);
                                                                                  
                                                                                  // Verify the lines were drawn with correct coordinates (based on std dev 2.0)
                                                                                  org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = 
                                                                                      org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                                                                  verify(g2, atLeastOnce()).draw(lineCaptor.capture());
                                                                                  
                                                                                  // Check that the vertical line spans 4 units (mean ± 2.0)
                                                                                  List<java.awt.geom.Line2D> lines = lineCaptor.getAllValues();
                                                                                  boolean foundCorrectLine = false;
                                                                                  for (java.awt.geom.Line2D line : lines) {
                                                                                      double height = Math.abs(line.getY1() - line.getY2());
                                                                                      if (height > 3.9 && height < 4.1) {  // Approximate check for 4.0 height
                                                                                          foundCorrectLine = true;
                                                                                          break;
                                                                                      }
                                                                                  }
                                                                                  assertTrue("Standard deviation lines should reflect std dev value of 2.0", foundCorrectLine);
                                                                              }

    @Test
                                                 public void testDrawVerticalItem_ErrorIndicatorLinePositions1() throws Exception {
                                                     // Setup test objects
                                                     StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                                     Graphics2D g2 = mock(Graphics2D.class);
                                                     CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                                     Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 200, 200);
                                                     CategoryPlot plot = mock(CategoryPlot.class);
                                                     CategoryAxis domainAxis = mock(CategoryAxis.class);
                                                     ValueAxis rangeAxis = mock(ValueAxis.class);
                                                     StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                                     
                                                     // Mock necessary behaviors
                                                     when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                                     when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                                     when(state.getBarWidth()).thenReturn(10.0);
                                                     when(state.getEntityCollection()).thenReturn(null);
                                                     
                                                     // Setup dataset to return valid values
                                                     when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(50.0);
                                                     when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(5.0);
                                                     
                                                     // Mock the domain axis positioning
                                                     when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                         .thenReturn(100.0);
                                                     
                                                     // Mock range axis conversion
                                                     when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                         .thenAnswer(inv -> {
                                                             double value = inv.getArgument(0);
                                                             return 200 - value; // Simple conversion for testing
                                                         });
                                                     
                                                     // Capture drawn lines
                                                     org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = 
                                                         org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                                     
                                                     // Use reflection to access protected method
                                                     Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                         "drawVerticalItem", 
                                                         Graphics2D.class, 
                                                         CategoryItemRendererState.class, 
                                                         Rectangle2D.class, 
                                                         CategoryPlot.class, 
                                                         CategoryAxis.class, 
                                                         ValueAxis.class, 
                                                         StatisticalCategoryDataset.class, 
                                                         int.class, 
                                                         int.class
                                                     );
                                                     drawVerticalItem.setAccessible(true);
                                                     drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                                     
                                                     // Verify the error indicator lines were drawn
                                                     verify(g2, times(3)).draw(lineCaptor.capture());
                                                     
                                                     // Get all drawn lines
                                                     List<java.awt.geom.Line2D> lines = lineCaptor.getAllValues();
                                                     
                                                     // The third line should be the lower horizontal error indicator
                                                     java.awt.geom.Line2D lowerHorizontalLine = lines.get(2);
                                                     
                                                     // Calculate expected positions
                                                     double rectX = 100.0; // From mocked category start
                                                     double rectWidth = 10.0; // From mocked bar width
                                                     double expectedX1 = rectX + rectWidth / 2.0 - 5.0;
                                                     double expectedX2 = rectX + rectWidth / 2.0 + 5.0;
                                                     
                                                     // Verify the lower horizontal line's x coordinates
                                                     assertEquals("Lower error line x1 should be center - 5", expectedX1, lowerHorizontalLine.getX1(), 0.001);
                                                     assertEquals("Lower error line x2 should be center + 5", expectedX2, lowerHorizontalLine.getX2(), 0.001);
                                                     
                                                     // Also verify y coordinates are equal (horizontal line)
                                                     assertEquals("Lower error line should be horizontal", 
                                                         lowerHorizontalLine.getY1(), lowerHorizontalLine.getY2(), 0.001);
                                                 }

    @Test
                                        public void testDrawVerticalItem_ErrorIndicatorPosition3() throws Exception {
                                            // Setup test data
                                            Graphics2D g2 = mock(Graphics2D.class);
                                            CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                                            Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 500, 500);
                                            CategoryPlot plot = mock(CategoryPlot.class);
                                            CategoryAxis domainAxis = mock(CategoryAxis.class);
                                            ValueAxis rangeAxis = mock(ValueAxis.class);
                                            StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                                            
                                            // Mock necessary objects and behaviors
                                            when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                                            when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                                            when(state.getBarWidth()).thenReturn(20.0);
                                            when(state.getEntityCollection()).thenReturn(null);
                                            
                                            // Setup dataset to return mean and std dev values
                                            when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(50.0);
                                            when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(5.0);
                                            
                                            // Setup mock for category axis
                                            when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                .thenReturn(100.0);
                                            
                                            // Setup range axis conversion
                                            when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any(RectangleEdge.class)))
                                                .thenAnswer(inv -> {
                                                    double value = inv.getArgument(0);
                                                    return 500 - value; // Simple conversion for testing
                                                });
                                            
                                            // Create renderer and set error indicator properties
                                            StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                                            renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                                            renderer.setErrorIndicatorPaint(Color.BLACK);
                                            
                                            // Use reflection to access protected method
                                            Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                                                "drawVerticalItem", 
                                                Graphics2D.class, 
                                                CategoryItemRendererState.class, 
                                                Rectangle2D.class, 
                                                CategoryPlot.class, 
                                                CategoryAxis.class, 
                                                ValueAxis.class, 
                                                StatisticalCategoryDataset.class, 
                                                int.class, 
                                                int.class
                                            );
                                            drawVerticalItem.setAccessible(true);
                                            drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                                            
                                            // Verify error indicator lines were drawn with correct coordinates
                                            org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = 
                                                org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                                            verify(g2, times(3)).draw(lineCaptor.capture());
                                            
                                            // Get all drawn lines
                                            java.util.List<java.awt.geom.Line2D> lines = lineCaptor.getAllValues();
                                            
                                            // The third line should be the lower error indicator horizontal line
                                            java.awt.geom.Line2D lowerErrorLine = lines.get(2);
                                            
                                            // Verify the x-coordinate is exactly 5 units from center (not 10)
                                            double expectedX1 = 110.0 - 5.0; // rectX + rectWidth/2 - 5
                                            double expectedX2 = 110.0 + 5.0; // rectX + rectWidth/2 + 5
                                            assertEquals(expectedX1, lowerErrorLine.getX1(), 0.001);
                                            assertEquals(expectedX2, lowerErrorLine.getX2(), 0.001);
                                            
                                            // Also verify y-coordinates are equal (horizontal line)
                                            assertEquals(lowerErrorLine.getY1(), lowerErrorLine.getY2(), 0.001);
                                        }

    @Test
                   public void testDrawVerticalItem_ErrorIndicatorLinesAreDrawn() throws Exception {
                       // Setup test data
                       StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                       when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
                       when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(2.0);
                       
                       // Mock dependencies
                       Graphics2D g2 = mock(Graphics2D.class);
                       CategoryPlot plot = mock(CategoryPlot.class);
                       Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                       CategoryAxis domainAxis = mock(CategoryAxis.class);
                       ValueAxis rangeAxis = mock(ValueAxis.class);
                       CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                       
                       // Configure mocks
                       when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                       when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                       when(state.getBarWidth()).thenReturn(10.0);
                       when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                           .thenReturn(50.0);
                       
                       // Create renderer and set error indicator properties
                       StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                       renderer.setErrorIndicatorPaint(Color.BLACK);
                       renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                       
                       // Use reflection to access protected method
                       Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                           "drawVerticalItem", 
                           Graphics2D.class, 
                           CategoryItemRendererState.class, 
                           Rectangle2D.class, 
                           CategoryPlot.class, 
                           CategoryAxis.class, 
                           ValueAxis.class, 
                           StatisticalCategoryDataset.class, 
                           int.class, 
                           int.class
                       );
                       drawVerticalItem.setAccessible(true);
                       
                       // Execute test
                       drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, 
                           rangeAxis, dataset, 0, 0);
                       
                       // Verify error indicator lines were drawn (3 calls expected)
                       verify(g2, times(3)).draw(any(java.awt.geom.Line2D.class));
                       
                       // Additional verification that it's the correct lines
                       @SuppressWarnings("unchecked")
                       org.mockito.ArgumentCaptor<java.awt.geom.Line2D> lineCaptor = org.mockito.ArgumentCaptor.forClass(java.awt.geom.Line2D.class);
                       verify(g2, times(3)).draw(lineCaptor.capture());
                       
                       List<java.awt.geom.Line2D> drawnLines = lineCaptor.getAllValues();
                       assertEquals(3, drawnLines.size());
                       // Could add more specific assertions about line positions if needed
                   }

    @Test
              public void testDrawVerticalItemErrorIndicatorLinesShouldBeDrawnNotFilled() throws Exception {
                  // Setup test data
                  StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
                  when(dataset.getMeanValue(anyInt(), anyInt())).thenReturn(10.0);
                  when(dataset.getStdDevValue(anyInt(), anyInt())).thenReturn(2.0);
                  
                  // Mock required objects
                  Graphics2D g2 = mock(Graphics2D.class);
                  CategoryItemRendererState state = mock(CategoryItemRendererState.class);
                  when(state.getBarWidth()).thenReturn(10.0);
                  when(state.getEntityCollection()).thenReturn(null);
                  
                  Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                  CategoryPlot plot = mock(CategoryPlot.class);
                  when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
                  when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
                  
                  CategoryAxis domainAxis = mock(CategoryAxis.class);
                  when(domainAxis.getCategoryStart(anyInt(), anyInt(), any(Rectangle2D.class), any()))
                      .thenReturn(10.0);
                  
                  ValueAxis rangeAxis = mock(ValueAxis.class);
                  when(rangeAxis.valueToJava2D(anyDouble(), any(Rectangle2D.class), any()))
                      .thenReturn(50.0);
                  
                  // Create renderer and set error indicator properties
                  StatisticalBarRenderer renderer = new StatisticalBarRenderer();
                  renderer.setErrorIndicatorPaint(Color.BLACK);
                  renderer.setErrorIndicatorStroke(new BasicStroke(1.0f));
                  
                  // Use reflection to access protected method
                  Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
                      "drawVerticalItem", 
                      Graphics2D.class, 
                      CategoryItemRendererState.class, 
                      Rectangle2D.class, 
                      CategoryPlot.class, 
                      CategoryAxis.class, 
                      ValueAxis.class, 
                      StatisticalCategoryDataset.class, 
                      int.class, 
                      int.class
                  );
                  drawVerticalItem.setAccessible(true);
                  drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, 0, 0);
                  
                  // Verify error indicator lines were drawn (not filled)
                  // Should be 3 lines drawn (vertical line and two horizontal caps)
                  verify(g2, times(3)).draw(any(Line2D.class));
                  verify(g2, never()).fill(any(Line2D.class));
                  
                  // Additional verification for correct paint and stroke usage
                  verify(g2).setPaint(Color.BLACK);
                  verify(g2).setStroke(any(BasicStroke.class));
              }

    @Test
         public void testDrawVerticalItemUsesCorrectItemLabelGenerator() throws Exception {
             // Setup test data
             int row = 1;
             int column = 2;
             
             // Mock dependencies
             Graphics2D g2 = mock(Graphics2D.class);
             CategoryItemRendererState state = mock(CategoryItemRendererState.class);
             Rectangle2D dataArea = mock(Rectangle2D.class);
             CategoryPlot plot = mock(CategoryPlot.class);
             CategoryAxis domainAxis = mock(CategoryAxis.class);
             ValueAxis rangeAxis = mock(ValueAxis.class);
             StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
             EntityCollection entities = mock(EntityCollection.class);
             
             // Configure mocks
             when(state.getEntityCollection()).thenReturn(entities);
             when(state.getBarWidth()).thenReturn(10.0);
             when(dataset.getMeanValue(row, column)).thenReturn(5.0);
             when(dataset.getStdDevValue(row, column)).thenReturn(1.0);
             when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
             when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
             when(dataArea.getWidth()).thenReturn(100.0);
             
             // Create different generators for row/column combinations
             CategoryItemLabelGenerator row1Col2Generator = mock(CategoryItemLabelGenerator.class);
             CategoryItemLabelGenerator col2Row1Generator = mock(CategoryItemLabelGenerator.class);
             
             // Create test instance
             StatisticalBarRenderer renderer = new StatisticalBarRenderer() {
                 @Override
                 public CategoryItemLabelGenerator getItemLabelGenerator(int row, int column) {
                     if (row == 1 && column == 2) return row1Col2Generator;
                     if (column == 2 && row == 1) return col2Row1Generator;
                     return null;
                 }
                 
                 @Override
                 public boolean isItemLabelVisible(int row, int column) {
                     return true;
                 }
             };
             
             // Use reflection to access protected method
             Method method = StatisticalBarRenderer.class.getDeclaredMethod(
                 "drawVerticalItem", 
                 Graphics2D.class, 
                 CategoryItemRendererState.class, 
                 Rectangle2D.class, 
                 CategoryPlot.class, 
                 CategoryAxis.class, 
                 ValueAxis.class, 
                 StatisticalCategoryDataset.class, 
                 int.class, 
                 int.class
             );
             method.setAccessible(true);
             method.invoke(renderer, g2, state, dataArea, plot, domainAxis, rangeAxis, dataset, row, column);
             
             // Verify correct generator was used
             verify(row1Col2Generator, atLeastOnce()).generateLabel(dataset, row, column);
             verify(col2Row1Generator, never()).generateLabel(dataset, column, row);
         }

    @Test
    public void testDrawVerticalItem_MeanValueColumnCheck() throws Exception {
        // Setup test data
        int testRow = 0;
        int testColumn = 1;
        double expectedMean = 10.0;
        double nextColumnMean = 20.0; // Different value to detect column shift
        
        // Create mock objects
        Graphics2D g2 = mock(Graphics2D.class);
        CategoryItemRendererState state = mock(CategoryItemRendererState.class);
        Rectangle2D dataArea = mock(Rectangle2D.class);
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryAxis domainAxis = mock(CategoryAxis.class);
        ValueAxis rangeAxis = mock(ValueAxis.class);
        StatisticalCategoryDataset dataset = mock(StatisticalCategoryDataset.class);
        
        // Configure mocks
        when(state.getBarWidth()).thenReturn(10.0);
        when(dataArea.getWidth()).thenReturn(100.0);
        when(plot.getDomainAxisEdge()).thenReturn(RectangleEdge.BOTTOM);
        when(plot.getRangeAxisEdge()).thenReturn(RectangleEdge.LEFT);
        
        // Setup dataset with different values in adjacent columns
        when(dataset.getMeanValue(testRow, testColumn)).thenReturn(expectedMean);
        when(dataset.getMeanValue(testRow, testColumn + 1)).thenReturn(nextColumnMean);
        when(dataset.getStdDevValue(testRow, testColumn)).thenReturn(null);
        
        // Setup renderer
        StatisticalBarRenderer renderer = new StatisticalBarRenderer();
        when(renderer.getItemPaint(testRow, testColumn)).thenReturn(Color.BLUE);
        
        // Use reflection to access protected method
        Method drawVerticalItem = StatisticalBarRenderer.class.getDeclaredMethod(
            "drawVerticalItem", 
            Graphics2D.class, 
            CategoryItemRendererState.class, 
            Rectangle2D.class, 
            CategoryPlot.class, 
            CategoryAxis.class, 
            ValueAxis.class, 
            StatisticalCategoryDataset.class, 
            int.class, 
            int.class
        );
        drawVerticalItem.setAccessible(true);
        drawVerticalItem.invoke(renderer, g2, state, dataArea, plot, domainAxis, 
                               rangeAxis, dataset, testRow, testColumn);
        
        // Verify correct mean value was used
        verify(dataset).getMeanValue(testRow, testColumn);
        
        // Additional verification that the value was actually used in drawing
        verify(rangeAxis).valueToJava2D(expectedMean, dataArea, RectangleEdge.LEFT);
    }


}
