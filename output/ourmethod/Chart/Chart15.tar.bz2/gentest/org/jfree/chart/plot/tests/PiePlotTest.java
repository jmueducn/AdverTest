package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.PaintMap;
import org.jfree.chart.StrokeMap;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.PieSectionEntity;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.PieToolTipGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.text.G2TextMeasurer;
import org.jfree.chart.text.TextAnchor;
import org.jfree.chart.text.TextBlock;
import org.jfree.chart.text.TextBox;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.urls.PieURLGenerator;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleAnchor;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.Rotation;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.ShapeUtilities;
import org.jfree.chart.util.UnitType;
import org.jfree.data.DefaultKeyedValues;
import org.jfree.data.KeyedValues;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.PieDataset;
 
public class PiePlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                public void testInitialise_WithDataset() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    PiePlot plot = new PiePlot();
                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                    PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                                                                                    PieDataset dataset = mock(PieDataset.class);
                                                                                                                                                                    
                                                                                                                                                                    // Mock dataset total calculation
                                                                                                                                                                    when(DatasetUtilities.calculatePieDatasetTotal(dataset)).thenReturn(100.0);
                                                                                                                                                                    plot.setDataset(dataset);
                                                                                                                                                                    plot.setStartAngle(90.0); // Set a specific start angle for testing
                                                                                                                                                            
                                                                                                                                                                    // Execute
                                                                                                                                                                    PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                                                                                            
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNotNull(state);
                                                                                                                                                                    assertEquals(2, state.getPassesRequired());
                                                                                                                                                                    assertEquals(100.0, state.getTotal(), 0.001);
                                                                                                                                                                    assertEquals(90.0, state.getLatestAngle(), 0.001);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testInitialise_WithoutDataset() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    PiePlot plot = new PiePlot();
                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                    PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                                                                                    plot.setDataset(null); // Explicitly no dataset
                                                                                                                                                                    plot.setStartAngle(45.0); // Set a specific start angle for testing
                                                                                                                                                            
                                                                                                                                                                    // Execute
                                                                                                                                                                    PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                                                                                            
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNotNull(state);
                                                                                                                                                                    assertEquals(2, state.getPassesRequired());
                                                                                                                                                                    assertEquals(0.0, state.getTotal(), 0.001); // Should be 0 when no dataset
                                                                                                                                                                    assertEquals(45.0, state.getLatestAngle(), 0.001);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testInitialise_NullPlotArea() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    PiePlot plot = new PiePlot();
                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                    PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                                                                                    
                                                                                                                                                                    // Expect exception
                                                                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    plot.initialise(g2, null, plot, 0, info);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testInitialise_NullPlot() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    PiePlot plot = new PiePlot();
                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                    PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                                                                                    
                                                                                                                                                                    // Expect exception
                                                                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                    
                                                                                                                                                                    // Execute
                                                                                                                                                                    plot.initialise(g2, plotArea, null, 0, info);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testInitialise_VerifyPassesRequired() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    PiePlot plot = new PiePlot();
                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                    PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                                                                                    plot.setDataset(null);
                                                                                                                                                            
                                                                                                                                                                    // Execute
                                                                                                                                                                    PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                                                                                            
                                                                                                                                                                    // Verify passes required is always 2
                                                                                                                                                                    assertEquals(2, state.getPassesRequired());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testInitialise_StartAnglePreserved() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    PiePlot plot = new PiePlot();
                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                                                                    PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                                                                                    double testAngle = 30.0;
                                                                                                                                                                    plot.setStartAngle(testAngle);
                                                                                                                                                            
                                                                                                                                                                    // Execute
                                                                                                                                                                    PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                                                                                            
                                                                                                                                                                    // Verify start angle is preserved in state
                                                                                                                                                                    assertEquals(testAngle, state.getLatestAngle(), 0.001);
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testGetMaximumExplodePercent_WhenDatasetIsNull() {
                                                                                                                                                            PiePlot piePlot = new PiePlot();
                                                                                                                                                            piePlot.setDataset(null);
                                                                                                                                                            double result = piePlot.getMaximumExplodePercent();
                                                                                                                                                            assertEquals(0.0, result, 0.0001);
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testGetMaximumExplodePercent_WhenNoExplodePercentages() {
                                                                                                                                                        // Import required classes
                                                                                                                                                        org.jfree.data.general.PieDataset mockDataset = mock(org.jfree.data.general.PieDataset.class);
                                                                                                                                                        org.jfree.chart.plot.PiePlot piePlot = new org.jfree.chart.plot.PiePlot(mockDataset);
                                                                                                                                                        
                                                                                                                                                        // Mock the dataset behavior
                                                                                                                                                        when(mockDataset.getKeys()).thenReturn(java.util.Arrays.asList("A", "B", "C"));
                                                                                                                                                        
                                                                                                                                                        // Test the method
                                                                                                                                                        double result = piePlot.getMaximumExplodePercent();
                                                                                                                                                        
                                                                                                                                                        // Assert the result
                                                                                                                                                        assertEquals(0.0, result, 0.0001);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testGetMaximumExplodePercent_WithMixedPositiveAndNegativeValues() {
                                                                                                                                                        // Create mock dataset
                                                                                                                                                        org.jfree.data.general.PieDataset mockDataset = mock(org.jfree.data.general.PieDataset.class);
                                                                                                                                                        when(mockDataset.getKeys()).thenReturn(java.util.Arrays.asList("A", "B", "C", "D"));
                                                                                                                                                        
                                                                                                                                                        // Create pie plot and set the dataset
                                                                                                                                                        org.jfree.chart.plot.PiePlot piePlot = new org.jfree.chart.plot.PiePlot(mockDataset);
                                                                                                                                                        
                                                                                                                                                        // Set explode percentages using reflection since explodePercentages is private
                                                                                                                                                        try {
                                                                                                                                                            java.lang.reflect.Field explodePercentagesField = org.jfree.chart.plot.PiePlot.class.getDeclaredField("explodePercentages");
                                                                                                                                                            explodePercentagesField.setAccessible(true);
                                                                                                                                                            @SuppressWarnings("unchecked")
                                                                                                                                                            java.util.Map<String, Double> explodePercentages = (java.util.Map<String, Double>) explodePercentagesField.get(piePlot);
                                                                                                                                                            
                                                                                                                                                            // Put test values
                                                                                                                                                            explodePercentages.put("A", 0.1);
                                                                                                                                                            explodePercentages.put("B", -0.5);
                                                                                                                                                            explodePercentages.put("C", 0.3);
                                                                                                                                                            explodePercentages.put("D", -0.2);
                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                            fail("Failed to set explode percentages via reflection: " + e.getMessage());
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        double result = piePlot.getMaximumExplodePercent();
                                                                                                                                                        assertEquals(0.3, result, 0.0001);
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testGetMaximumExplodePercent_WithMultipleExplodePercentages() {
                                                                                                                                                    // Create mock dataset
                                                                                                                                                    org.jfree.data.general.PieDataset mockDataset = mock(org.jfree.data.general.PieDataset.class);
                                                                                                                                                    when(mockDataset.getKeys()).thenReturn(java.util.Arrays.asList("A", "B", "C", "D"));
                                                                                                                                                    
                                                                                                                                                    // Create pie plot and set the dataset
                                                                                                                                                    org.jfree.chart.plot.PiePlot piePlot = new org.jfree.chart.plot.PiePlot(mockDataset);
                                                                                                                                                    
                                                                                                                                                    // Set explode percentages using reflection since it's a private field
                                                                                                                                                    try {
                                                                                                                                                        java.lang.reflect.Field explodePercentagesField = org.jfree.chart.plot.PiePlot.class.getDeclaredField("explodePercentages");
                                                                                                                                                        explodePercentagesField.setAccessible(true);
                                                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                                                        java.util.Map<String, Double> explodePercentages = (java.util.Map<String, Double>) explodePercentagesField.get(piePlot);
                                                                                                                                                        
                                                                                                                                                        // Add explode percentages
                                                                                                                                                        explodePercentages.put("A", 0.1);
                                                                                                                                                        explodePercentages.put("B", 0.3);
                                                                                                                                                        explodePercentages.put("C", 0.15);
                                                                                                                                                        explodePercentages.put("D", 0.25);
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Failed to set explode percentages due to reflection error: " + e.getMessage());
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    double result = piePlot.getMaximumExplodePercent();
                                                                                                                                                    assertEquals(0.3, result, 0.0001);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetMaximumExplodePercent_WithKeysNotInExplodePercentages() {
                                                                                                                                                    // Create mock dataset
                                                                                                                                                    PieDataset mockDataset = mock(PieDataset.class);
                                                                                                                                                    when(mockDataset.getKeys()).thenReturn(java.util.Arrays.asList("A", "B", "C", "D"));
                                                                                                                                                    
                                                                                                                                                    // Create pie plot and set the dataset
                                                                                                                                                    PiePlot piePlot = new PiePlot(mockDataset);
                                                                                                                                                    
                                                                                                                                                    // Get explode percentages map using reflection since it's private
                                                                                                                                                    Map<String, Double> explodePercentages;
                                                                                                                                                    try {
                                                                                                                                                        Field field = PiePlot.class.getDeclaredField("explodePercentages");
                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                        explodePercentages = (Map<String, Double>) field.get(piePlot);
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        throw new RuntimeException("Failed to access explodePercentages field", e);
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    // Add test data
                                                                                                                                                    explodePercentages.put("X", 0.5); // Not in dataset keys
                                                                                                                                                    explodePercentages.put("Y", 0.7); // Not in dataset keys
                                                                                                                                                    
                                                                                                                                                    double result = piePlot.getMaximumExplodePercent();
                                                                                                                                                    assertEquals(0.0, result, 0.0001);
                                                                                                                                                }

    @Test
                                                                                                                                    public void testGetMaximumExplodePercent_WithEmptyDataset() {
                                                                                                                                        // Create mock dataset
                                                                                                                                        PieDataset mockDataset = mock(PieDataset.class);
                                                                                                                                        when(mockDataset.getKeys()).thenReturn(java.util.Collections.<Comparable>emptyList());
                                                                                                                                        
                                                                                                                                        // Create pie plot and set the dataset
                                                                                                                                        PiePlot piePlot = new PiePlot(mockDataset);
                                                                                                                                        
                                                                                                                                        // Access the explodePercentages map using reflection since it's private
                                                                                                                                        try {
                                                                                                                                            Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
                                                                                                                                            explodePercentagesField.setAccessible(true);
                                                                                                                                            @SuppressWarnings("unchecked")
                                                                                                                                            Map<Comparable, Double> explodePercentages = 
                                                                                                                                                (Map<Comparable, Double>) explodePercentagesField.get(piePlot);
                                                                                                                                            explodePercentages.put("A", 0.1); // Should be ignored since not in dataset
                                                                                                                                        } catch (Exception e) {
                                                                                                                                            fail("Failed to access explodePercentages field: " + e.getMessage());
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        double result = piePlot.getMaximumExplodePercent();
                                                                                                                                        assertEquals(0.0, result, 0.0001);
                                                                                                                                    }

    @Test
                                                                                                                                public void testGetMaximumExplodePercent_WithZeroValues() {
                                                                                                                                    // Create mock dataset
                                                                                                                                    org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                                                                                                                                    dataset.setValue("A", 1);
                                                                                                                                    dataset.setValue("B", 1);
                                                                                                                                    dataset.setValue("C", 1);
                                                                                                                                    
                                                                                                                                    // Create pie plot and set the dataset
                                                                                                                                    org.jfree.chart.plot.PiePlot piePlot = new org.jfree.chart.plot.PiePlot(dataset);
                                                                                                                                    
                                                                                                                                    // Set explode percentages using reflection since it's a private field
                                                                                                                                    try {
                                                                                                                                        java.lang.reflect.Field explodePercentagesField = org.jfree.chart.plot.PiePlot.class.getDeclaredField("explodePercentages");
                                                                                                                                        explodePercentagesField.setAccessible(true);
                                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                                        java.util.Map<String, Double> explodePercentages = (java.util.Map<String, Double>) explodePercentagesField.get(piePlot);
                                                                                                                                        explodePercentages.put("A", 0.0);
                                                                                                                                        explodePercentages.put("B", 0.0);
                                                                                                                                        explodePercentages.put("C", 0.0);
                                                                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                        org.junit.Assert.fail("Failed to set explode percentages due to reflection error: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    double result = piePlot.getMaximumExplodePercent();
                                                                                                                                    org.junit.Assert.assertEquals(0.0, result, 0.0001);
                                                                                                                                }

    @Test
                                                                                                                            public void testGetMaximumExplodePercent_WithNegativeValues() {
                                                                                                                                // Setup mock dataset
                                                                                                                                PieDataset mockDataset = mock(PieDataset.class);
                                                                                                                                when(mockDataset.getKeys()).thenReturn(java.util.Arrays.asList("A", "B", "C"));
                                                                                                                                
                                                                                                                                // Create pie plot and set the dataset
                                                                                                                                PiePlot piePlot = new PiePlot(mockDataset);
                                                                                                                                
                                                                                                                                // Set explode percentages using reflection since explodePercentages is private
                                                                                                                                try {
                                                                                                                                    Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
                                                                                                                                    explodePercentagesField.setAccessible(true);
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<String, Double> explodePercentages = (Map<String, Double>) explodePercentagesField.get(piePlot);
                                                                                                                                    explodePercentages.put("A", -0.1);
                                                                                                                                    explodePercentages.put("B", -0.5);
                                                                                                                                    explodePercentages.put("C", -0.01);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set explode percentages via reflection: " + e.getMessage());
                                                                                                                                }
                                                                                                                                
                                                                                                                                double result = piePlot.getMaximumExplodePercent();
                                                                                                                                assertEquals(0.0, result, 0.0001); // Negative values should be ignored
                                                                                                                            }

    @Test
                                                                                                                        public void testGetMaximumExplodePercent_WithNullValuesInExplodePercentages() {
                                                                                                                            // Create mock dataset
                                                                                                                            PieDataset mockDataset = mock(PieDataset.class);
                                                                                                                            when(mockDataset.getKeys()).thenReturn(java.util.Arrays.asList("A", "B", "C"));
                                                                                                                            
                                                                                                                            // Create pie plot and set the dataset
                                                                                                                            PiePlot piePlot = new PiePlot(mockDataset);
                                                                                                                            
                                                                                                                            // Use reflection to access the private explodePercentages field
                                                                                                                            try {
                                                                                                                                Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
                                                                                                                                explodePercentagesField.setAccessible(true);
                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                Map<String, Double> explodePercentages = (Map<String, Double>) explodePercentagesField.get(piePlot);
                                                                                                                                
                                                                                                                                // Set values including null
                                                                                                                                explodePercentages.put("A", 0.1);
                                                                                                                                explodePercentages.put("B", null);
                                                                                                                                explodePercentages.put("C", 0.2);
                                                                                                                                
                                                                                                                                // Test the method
                                                                                                                                double result = piePlot.getMaximumExplodePercent();
                                                                                                                                assertEquals(0.2, result, 0.0001);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to access explodePercentages field: " + e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                    public void testGetMaximumExplodePercent_WithSingleExplodePercentage() {
                                                                                                                        // Setup
                                                                                                                        PiePlot piePlot = new PiePlot();
                                                                                                                        PieDataset mockDataset = mock(PieDataset.class);
                                                                                                                        Map<String, Double> explodePercentages = new TreeMap<String, Double>();
                                                                                                                        
                                                                                                                        // Use reflection to set private fields since they're not accessible directly
                                                                                                                        try {
                                                                                                                            Field datasetField = PiePlot.class.getDeclaredField("dataset");
                                                                                                                            datasetField.setAccessible(true);
                                                                                                                            datasetField.set(piePlot, mockDataset);
                                                                                                                            
                                                                                                                            Field explodePercentagesField = PiePlot.class.getDeclaredField("explodePercentages");
                                                                                                                            explodePercentagesField.setAccessible(true);
                                                                                                                            explodePercentagesField.set(piePlot, explodePercentages);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to set private fields via reflection: " + e.getMessage());
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test
                                                                                                                        when(mockDataset.getKeys()).thenReturn(java.util.Arrays.asList("A", "B", "C"));
                                                                                                                        explodePercentages.put("B", 0.2);
                                                                                                                        
                                                                                                                        double result = piePlot.getMaximumExplodePercent();
                                                                                                                        assertEquals(0.2, result, 0.0001);
                                                                                                                    }

    @Test
                                                                                                                public void testInitialisePassesCorrectInfoToPiePlotState() {
                                                                                                                    // Setup
                                                                                                                    PiePlot plot = new PiePlot();
                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                    Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                                                                                                                    PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                                                    
                                                                                                                    // Exercise
                                                                                                                    PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                                                    
                                                                                                                    // Verify - we need to ensure the info was passed to PiePlotState constructor
                                                                                                                    // Since we can't directly verify constructor calls, we can check if the state
                                                                                                                    // behaves correctly with our info object by checking some property
                                                                                                                    // or we can verify interactions if PiePlotState uses the info
                                                                                                                    
                                                                                                                    // Alternative approach: verify that a null info would cause different behavior
                                                                                                                    try {
                                                                                                                        PiePlotState stateWithNull = plot.initialise(g2, plotArea, plot, 0, null);
                                                                                                                        // If we get here, the method works with null, which is not what we want
                                                                                                                        // for our specific mutant test
                                                                                                                        fail("Expected NullPointerException when info is null");
                                                                                                                    } catch (NullPointerException e) {
                                                                                                                        // This is expected if PiePlotState constructor doesn't handle null
                                                                                                                    }
                                                                                                                    
                                                                                                                    // The key assertion is that the method works correctly with non-null info
                                                                                                                    assertNotNull(state);
                                                                                                                    assertEquals(2, state.getPassesRequired());
                                                                                                                }

    @Test
                                                                                                        public void testInitialiseWithDatasetShouldCalculateTotal() {
                                                                                                            // Setup
                                                                                                            PiePlot plot = new PiePlot();
                                                                                                            PieDataset dataset = mock(PieDataset.class);
                                                                                                            when(dataset.getKeys()).thenReturn(java.util.Arrays.asList("A", "B"));
                                                                                                            when(dataset.getValue("A")).thenReturn(10.0);
                                                                                                            when(dataset.getValue("B")).thenReturn(20.0);
                                                                                                            plot.setDataset(dataset);
                                                                                                            
                                                                                                            // Mock the plot's start angle
                                                                                                            when(plot.getStartAngle()).thenReturn(90.0);
                                                                                                            
                                                                                                            // Mock DatasetUtilities (since it's static, we'll assume it works correctly)
                                                                                                            // The expected total should be 30.0 (10 + 20)
                                                                                                            
                                                                                                            // Test
                                                                                                            PiePlotState state = plot.initialise(mock(Graphics2D.class), 
                                                                                                                new Rectangle2D.Double(), 
                                                                                                                plot, 
                                                                                                                0, 
                                                                                                                mock(PlotRenderingInfo.class));
                                                                                                            
                                                                                                            // Verify
                                                                                                            assertEquals("Passes required should be 2", 2, state.getPassesRequired());
                                                                                                            assertEquals("Total should be calculated from dataset", 30.0, state.getTotal(), 0.0001);
                                                                                                            assertEquals("Latest angle should match plot's start angle", 90.0, state.getLatestAngle(), 0.0001);
                                                                                                        }

    @Test
                                                                                            public void testInitialiseWithNonNullDatasetShouldCalculateCorrectTotal() {
                                                                                                // Setup
                                                                                                PiePlot plot = new PiePlot();
                                                                                                PieDataset mockDataset = mock(PieDataset.class);
                                                                                                plot.setDataset(mockDataset);
                                                                                                
                                                                                                // Create a real dataset that will return known values
                                                                                                org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                                                                                                dataset.setValue("A", 60.0);
                                                                                                dataset.setValue("B", 40.0);
                                                                                                double expectedTotal = 100.0;  // 60 + 40
                                                                                                
                                                                                                // Replace the mock dataset with our real dataset
                                                                                                plot.setDataset(dataset);
                                                                                                
                                                                                                // Test
                                                                                                PiePlotState result = plot.initialise(
                                                                                                    mock(Graphics2D.class), 
                                                                                                    mock(Rectangle2D.class), 
                                                                                                    plot, 
                                                                                                    0, 
                                                                                                    mock(PlotRenderingInfo.class)
                                                                                                );
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals("Total should be calculated from dataset", 
                                                                                                            expectedTotal, 
                                                                                                            result.getTotal(), 
                                                                                                            0.0001);
                                                                                            }

    @Test
                                                                                        public void testInitialiseNeverReturnsNull() {
                                                                                            // Setup
                                                                                            PiePlot plot = new PiePlot();
                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                            Rectangle2D plotArea = new Rectangle2D.Double();
                                                                                            PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                            
                                                                                            // Test with dataset
                                                                                            plot.setDataset(mock(PieDataset.class));
                                                                                            PiePlotState stateWithDataset = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                            assertNotNull("State should not be null when dataset exists", stateWithDataset);
                                                                                            
                                                                                            // Test without dataset
                                                                                            plot.setDataset(null);
                                                                                            PiePlotState stateWithoutDataset = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                            assertNotNull("State should not be null even when dataset is null", stateWithoutDataset);
                                                                                            
                                                                                            // Test with null plot
                                                                                            PiePlotState stateWithNullPlot = plot.initialise(g2, plotArea, null, 0, info);
                                                                                            assertNotNull("State should not be null even when plot is null", stateWithNullPlot);
                                                                                            
                                                                                            // Test with null info
                                                                                            PiePlotState stateWithNullInfo = plot.initialise(g2, plotArea, plot, 0, null);
                                                                                            assertNotNull("State should not be null even when info is null", stateWithNullInfo);
                                                                                        }

    @Test
                                                                                        public void testInitialiseWithNullDataset() {
                                                                                            // Setup
                                                                                            PiePlot plot = new PiePlot(null); // dataset is null
                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                            Rectangle2D plotArea = new Rectangle2D.Double();
                                                                                            PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                            
                                                                                            // Execute
                                                                                            PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                            
                                                                                            // Verify - with null dataset, calculateTotal should NOT be called
                                                                                            // If mutant is present (checking dataset == null), it would try to calculate
                                                                                            assertEquals(2, state.getPassesRequired());
                                                                                            assertEquals(plot.getStartAngle(), state.getLatestAngle(), 0.001);
                                                                                            // Total should remain unset (0.0 by default)
                                                                                            assertEquals(0.0, state.getTotal(), 0.001);
                                                                                        }

    @Test
                                                                                        public void testInitialiseWithNonNullDataset() {
                                                                                            // Setup
                                                                                            PieDataset dataset = mock(PieDataset.class);
                                                                                            when(dataset.getKeys()).thenReturn(new java.util.ArrayList());
                                                                                            PiePlot plot = new PiePlot(dataset);
                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                            Rectangle2D plotArea = new Rectangle2D.Double();
                                                                                            PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                            
                                                                                            // Mock the utility method
                                                                                            PieDataset spyDataset = spy(plot.getDataset());
                                                                                            plot.setDataset(spyDataset);
                                                                                            doReturn(100.0).when(spyDataset).getValue(anyInt());
                                                                                            
                                                                                            // Execute
                                                                                            PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                            
                                                                                            // Verify - with non-null dataset, calculateTotal should be called
                                                                                            // If mutant is present (checking dataset == null), it would skip calculation
                                                                                            assertEquals(2, state.getPassesRequired());
                                                                                            assertEquals(plot.getStartAngle(), state.getLatestAngle(), 0.001);
                                                                                            // Total should be set to some value (mock returns 100.0)
                                                                                            assertNotEquals(0.0, state.getTotal(), 0.001);
                                                                                        }

    @Test
                                                                                public void testInitialiseWithNullDataset1() {
                                                                                    // Setup
                                                                                    PiePlot plot = new PiePlot(null); // Create plot with null dataset
                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                    Rectangle2D plotArea = new Rectangle2D.Double();
                                                                                    PlotRenderingInfo info = mock(PlotRenderingInfo.class);
                                                                                    
                                                                                    // Exercise
                                                                                    PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                                                                    
                                                                                    // Verify - if mutation exists, this would throw NullPointerException
                                                                                    assertNotNull(state);
                                                                                    assertEquals(2, state.getPassesRequired());
                                                                                    // Verify no total was set (since dataset was null)
                                                                                    // This assumes PiePlotState has a way to check if total was set
                                                                                    // If not, we can verify by checking no interaction with DatasetUtilities
                                                                                }

    @Test
                                                                        public void testLookupSectionOutlinePaintWithNullKeyThrowsIllegalArgumentException() throws Exception {
                                                                            // Setup
                                                                            PiePlot plot = new PiePlot();
                                                                            Comparable<String> nullKey = null;
                                                                            
                                                                            // Get the protected method via reflection
                                                                            Method method = PiePlot.class.getDeclaredMethod("lookupSectionOutlinePaint", Comparable.class);
                                                                            method.setAccessible(true);
                                                                            
                                                                            // Expect exception
                                                                            thrown.expect(IllegalArgumentException.class);
                                                                            thrown.expectMessage("Null 'key' argument.");
                                                                            
                                                                            // Test
                                                                            method.invoke(plot, nullKey);
                                                                        }

    @Test
                                                                    public void testLookupSectionPaintWithNullKeyThrowsIllegalArgumentException() throws Exception {
                                                                        // Setup
                                                                        PiePlot plot = new PiePlot();
                                                                        Comparable<String> nullKey = null;
                                                                        
                                                                        // Get the protected method via reflection
                                                                        Method method = PiePlot.class.getDeclaredMethod("lookupSectionPaint", Comparable.class, boolean.class);
                                                                        method.setAccessible(true);
                                                                        
                                                                        // Expect exception
                                                                        thrown.expect(IllegalArgumentException.class);
                                                                        thrown.expectMessage("Null 'key' argument.");
                                                                        
                                                                        // Test
                                                                        method.invoke(plot, nullKey, true);
                                                                    }

    @Test
                                                                    public void testLookupSectionOutlineStrokeWithNullKeyThrowsIllegalArgumentException() throws Exception {
                                                                        // Setup
                                                                        PiePlot plot = new PiePlot();
                                                                        Comparable<String> nullKey = null;
                                                                        
                                                                        // Get the protected method via reflection
                                                                        Method method = PiePlot.class.getDeclaredMethod(
                                                                            "lookupSectionOutlineStroke", Comparable.class, boolean.class
                                                                        );
                                                                        method.setAccessible(true);
                                                                        
                                                                        // Expect exception
                                                                        thrown.expect(IllegalArgumentException.class);
                                                                        thrown.expectMessage("Null 'key' argument.");
                                                                        
                                                                        // Test
                                                                        method.invoke(plot, nullKey, true);
                                                                    }

    @Test
                                                                    public void testGetSectionPaintWithNullKeyThrowsCorrectException() {
                                                                        // Setup
                                                                        PiePlot piePlot = new PiePlot();
                                                                        
                                                                        // Expect exception
                                                                        thrown.expect(IllegalArgumentException.class);
                                                                        thrown.expectMessage("Null 'key' argument.");
                                                                        
                                                                        // Test
                                                                        piePlot.getSectionPaint(null);
                                                                    }

    @Test
                                                    public void testInitialiseWithoutExplodePercentages() {
                                                        // Setup
                                                        org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                                                        org.jfree.chart.plot.PiePlot plot = new org.jfree.chart.plot.PiePlot(dataset);
                                                        // No need to set explode percentages as they are null by default
                                                        
                                                        // Execute
                                                        org.jfree.chart.plot.PiePlotState state = plot.initialise(null, null, plot, 0, null);
                                                        
                                                        // Verify - The mutation would affect behavior here if checking explodePercentages != null
                                                        assertNotNull(state);
                                                        assertEquals(2, state.getPassesRequired());
                                                    }

    @Test
                                                public void testInitialiseWithExplodePercentages() {
                                                    // Setup
                                                    org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                                                    org.jfree.chart.plot.PiePlot plot = new org.jfree.chart.plot.PiePlot(dataset);
                                                    dataset.setValue("Key", 10.0); // Need to add a value to the dataset for the key
                                                    plot.setExplodePercent("Key", 0.1);
                                                    
                                                    // Execute
                                                    org.jfree.chart.plot.PiePlotState state = plot.initialise(null, null, plot, 0, null);
                                                    
                                                    // Verify - The mutation would affect behavior here if explodePercentages is not null
                                                    assertNotNull(state);
                                                    assertEquals(2, state.getPassesRequired());
                                                }

    @Test
                                    public void testInitialiseWithExplodePercentagesNotNull() {
                                        // Setup
                                        PiePlot plot = new PiePlot();
                                        java.util.Map<Comparable, Double> explodePercents = new java.util.HashMap<Comparable, Double>();
                                        explodePercents.put("Key", 0.1);
                                        // Use setExplodePercent for each entry instead of setExplodePercentages
                                        for (Map.Entry<Comparable, Double> entry : explodePercents.entrySet()) {
                                            plot.setExplodePercent(entry.getKey(), entry.getValue());
                                        }
                                        java.awt.Graphics2D g2 = mock(java.awt.Graphics2D.class);
                                        java.awt.geom.Rectangle2D plotArea = new java.awt.geom.Rectangle2D.Double(0, 0, 100, 100);
                                        org.jfree.chart.plot.PlotRenderingInfo info = mock(org.jfree.chart.plot.PlotRenderingInfo.class);
                                        
                                        // Execute
                                        org.jfree.chart.plot.PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                        
                                        // Verify
                                        assertNotNull(state);
                                        assertEquals(2, state.getPassesRequired());
                                        assertEquals(plot.getStartAngle(), state.getLatestAngle(), 0.001);
                                        
                                        // The behavior should be same as mutated version in this case
                                        // since original would enter if block when explodePercentages is null
                                        // and mutated version always enters if block
                                    }

    @Test
                                public void testInitialiseWithExplodePercentagesNull() {
                                    // Setup
                                    org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                                    org.jfree.chart.plot.PiePlot plot = new org.jfree.chart.plot.PiePlot(dataset);
                                    // Instead of setExplodePercentages(null), we'll set explode percent for a specific key
                                    dataset.setValue("Key", 10.0);
                                    plot.setExplodePercent("Key", 0.0); // set to 0 instead of null
                                    
                                    java.awt.Graphics2D g2 = (java.awt.Graphics2D) java.awt.GraphicsEnvironment
                                        .getLocalGraphicsEnvironment()
                                        .createGraphics(new java.awt.image.BufferedImage(100, 100, java.awt.image.BufferedImage.TYPE_INT_ARGB));
                                    java.awt.geom.Rectangle2D plotArea = new java.awt.geom.Rectangle2D.Double(0, 0, 100, 100);
                                    org.jfree.chart.plot.PlotRenderingInfo info = new org.jfree.chart.plot.PlotRenderingInfo(null);
                                    
                                    // Execute
                                    org.jfree.chart.plot.PiePlotState state = plot.initialise(g2, plotArea, plot, 0, info);
                                    
                                    // Verify - check if state is properly initialized
                                    org.junit.Assert.assertNotNull(state);
                                    org.junit.Assert.assertEquals(2, state.getPassesRequired());
                                    org.junit.Assert.assertEquals(plot.getStartAngle(), state.getLatestAngle(), 0.001);
                                }

    @Test
                        public void testExplodePercentagesInitialization() {
                            // Setup
                            org.jfree.data.general.DefaultPieDataset dataset = new org.jfree.data.general.DefaultPieDataset();
                            org.jfree.chart.plot.PiePlot plot = new org.jfree.chart.plot.PiePlot(dataset);
                            Comparable<String> key = "TestKey";
                            double explodePercent = 0.1;
                            
                            // Action - set and get explode percentage
                            plot.setExplodePercent(key, explodePercent);
                            double retrievedPercent = plot.getExplodePercent(key);
                            
                            // Verification
                            assertEquals("Explode percentage should match set value", 
                                explodePercent, retrievedPercent, 0.0001);
                            
                            // Additional check for maximum explode percent
                            double maxPercent = plot.getMaximumExplodePercent();
                            assertTrue("Maximum explode percent should be >= set value",
                                maxPercent >= explodePercent);
                        }

    @Test
                public void testSetExplodePercent_StoresExactValue() {
                    // Setup
                    PiePlot plot = new PiePlot();
                    Comparable<String> key = "TestKey";
                    double testPercent = 0.25;
                    
                    // Action
                    plot.setExplodePercent(key, testPercent);
                    
                    // Verification
                    double storedPercent = plot.getExplodePercent(key);
                    assertEquals("Explode percentage should be stored exactly as set", 
                                testPercent, storedPercent, 0.0001);
                    
                    // Additional check to ensure the Map contains the exact value
                    // This is more direct and would catch the mutant
                    try {
                        Field field = PiePlot.class.getDeclaredField("explodePercentages");
                        field.setAccessible(true);
                        Map<Comparable, Double> explodePercentages = (Map<Comparable, Double>) field.get(plot);
                        Double actualStoredValue = explodePercentages.get(key);
                        assertNotNull("Explode percentage should exist for the key", actualStoredValue);
                        assertEquals("Explode percentage in map should match exactly what was set",
                                    testPercent, actualStoredValue, 0.0001);
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        fail("Failed to access explodePercentages field using reflection: " + e.getMessage());
                    }
                }

    @Test
    public void testInitialiseWithNullAndNonNullDataset() {
        // Setup
        PiePlot plot = new PiePlot();
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        org.jfree.chart.ChartRenderingInfo chartInfo = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo info = new org.jfree.chart.plot.PlotRenderingInfo(chartInfo);
        
        // Test case 1: null dataset
        plot.setDataset(null);
        org.jfree.chart.plot.PiePlotState state1 = plot.initialise(g2, plotArea, plot, 0, info);
        assertEquals(2, state1.getPassesRequired());
        assertEquals(plot.getStartAngle(), state1.getLatestAngle(), 0.001);
        // Verify total wasn't set when dataset is null
        try {
            state1.getTotal();
            fail("Expected IllegalStateException when total not set");
        } catch (IllegalStateException e) {
            // expected
        }
        
        // Test case 2: non-null dataset
        org.jfree.data.general.PieDataset dataset = mock(org.jfree.data.general.PieDataset.class);
        when(org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(dataset)).thenReturn(100.0);
        plot.setDataset(dataset);
        org.jfree.chart.plot.PiePlotState state2 = plot.initialise(g2, plotArea, plot, 0, info);
        assertEquals(2, state2.getPassesRequired());
        assertEquals(plot.getStartAngle(), state2.getLatestAngle(), 0.001);
        // Verify total was set when dataset exists
        assertEquals(100.0, state2.getTotal(), 0.001);
    }


}
