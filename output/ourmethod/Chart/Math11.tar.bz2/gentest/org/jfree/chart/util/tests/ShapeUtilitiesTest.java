package gentest.org.jfree.chart.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.util.*;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
 
public class ShapeUtilitiesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                    public void testEqual_Line2DObjects() {
                                                                                                                                                                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                        Line2D line2 = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                        Line2D line3 = new Line2D.Double(1, 2, 3, 5);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Mock the specific equal method for Line2D
                                                                                                                                                                                                        ShapeUtilities utilitiesSpy = spy(ShapeUtilities.class);
                                                                                                                                                                                                        doReturn(true).when(utilitiesSpy).equal(line1, line2);
                                                                                                                                                                                                        doReturn(false).when(utilitiesSpy).equal(line1, line3);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(line1, line3));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Ellipse2DObjects() {
                                                                                                                                                                                                        Ellipse2D ellipse1 = new Ellipse2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                        Ellipse2D ellipse2 = new Ellipse2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                        Ellipse2D ellipse3 = new Ellipse2D.Double(1, 2, 3, 5);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Mock the specific equal method for Ellipse2D
                                                                                                                                                                                                        ShapeUtilities utilitiesSpy = spy(ShapeUtilities.class);
                                                                                                                                                                                                        doReturn(true).when(utilitiesSpy).equal(ellipse1, ellipse2);
                                                                                                                                                                                                        doReturn(false).when(utilitiesSpy).equal(ellipse1, ellipse3);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(ellipse1, ellipse2));
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(ellipse1, ellipse3));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2DObjects() {
                                                                                                                                                                                                        Arc2D arc1 = new Arc2D.Double(1, 2, 3, 4, 45, 90, Arc2D.PIE);
                                                                                                                                                                                                        Arc2D arc2 = new Arc2D.Double(1, 2, 3, 4, 45, 90, Arc2D.PIE);
                                                                                                                                                                                                        Arc2D arc3 = new Arc2D.Double(1, 2, 3, 4, 45, 91, Arc2D.PIE);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Mock the specific equal method for Arc2D
                                                                                                                                                                                                        ShapeUtilities utilitiesSpy = spy(ShapeUtilities.class);
                                                                                                                                                                                                        doReturn(true).when(utilitiesSpy).equal(arc1, arc2);
                                                                                                                                                                                                        doReturn(false).when(utilitiesSpy).equal(arc1, arc3);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc3));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_PolygonObjects() {
                                                                                                                                                                                                        Polygon poly1 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                                                                                                                                                                        Polygon poly2 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                                                                                                                                                                        Polygon poly3 = new Polygon(new int[]{1,2,4}, new int[]{4,5,6}, 3);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Mock the specific equal method for Polygon
                                                                                                                                                                                                        ShapeUtilities utilitiesSpy = spy(ShapeUtilities.class);
                                                                                                                                                                                                        doReturn(true).when(utilitiesSpy).equal(poly1, poly2);
                                                                                                                                                                                                        doReturn(false).when(utilitiesSpy).equal(poly1, poly3);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(poly1, poly2));
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(poly1, poly3));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_GeneralPathObjects() {
                                                                                                                                                                                                        GeneralPath path1 = new GeneralPath();
                                                                                                                                                                                                        path1.moveTo(1, 2);
                                                                                                                                                                                                        path1.lineTo(3, 4);
                                                                                                                                                                                                        
                                                                                                                                                                                                        GeneralPath path2 = new GeneralPath();
                                                                                                                                                                                                        path2.moveTo(1, 2);
                                                                                                                                                                                                        path2.lineTo(3, 4);
                                                                                                                                                                                                        
                                                                                                                                                                                                        GeneralPath path3 = new GeneralPath();
                                                                                                                                                                                                        path3.moveTo(1, 2);
                                                                                                                                                                                                        path3.lineTo(3, 5);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Mock the specific equal method for GeneralPath
                                                                                                                                                                                                        ShapeUtilities utilitiesSpy = spy(ShapeUtilities.class);
                                                                                                                                                                                                        doReturn(true).when(utilitiesSpy).equal(path1, path2);
                                                                                                                                                                                                        doReturn(false).when(utilitiesSpy).equal(path1, path3);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(path1, path2));
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(path1, path3));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Rectangle2DObjects() {
                                                                                                                                                                                                        Rectangle2D rect1 = new Rectangle2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                        Rectangle2D rect2 = new Rectangle2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                        Rectangle2D rect3 = new Rectangle2D.Double(1, 2, 3, 5);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Mock ObjectUtilities.equal() for testing
                                                                                                                                                                                                        ObjectUtilities objectUtilitiesMock = mock(ObjectUtilities.class);
                                                                                                                                                                                                        when(objectUtilitiesMock.equal(rect1, rect2)).thenReturn(true);
                                                                                                                                                                                                        when(objectUtilitiesMock.equal(rect1, rect3)).thenReturn(false);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Since we can't easily mock static methods, this test assumes ObjectUtilities works correctly
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(rect1, rect2));
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(rect1, rect3));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_MixedShapeTypes() {
                                                                                                                                                                                                        Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                        Ellipse2D ellipse = new Ellipse2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(line, ellipse));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_FirstNullSecondNotNull() {
                                                                                                                                                                                                        Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(null, e2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_FirstNotNullSecondNull() {
                                                                                                                                                                                                        Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(e1, null));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_SameInstance() {
                                                                                                                                                                                                        Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(e1, e1));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_BothHaveNullFrames() {
                                                                                                                                                                                                        Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                                                                        Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                                                                        when(e1.getFrame()).thenReturn(null);
                                                                                                                                                                                                        when(e2.getFrame()).thenReturn(null);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2D_FirstNullSecondNotNull() {
                                                                                                                                                                                                        Arc2D arc = mock(Arc2D.class);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(null, arc));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2D_FirstNotNullSecondNull() {
                                                                                                                                                                                                        Arc2D arc = mock(Arc2D.class);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc, null));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2D_DifferentFrames() {
                                                                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                                                                        Rectangle2D frame1 = mock(Rectangle2D.class);
                                                                                                                                                                                                        Rectangle2D frame2 = mock(Rectangle2D.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                        when(arc1.getFrame()).thenReturn(frame1);
                                                                                                                                                                                                        when(arc2.getFrame()).thenReturn(frame2);
                                                                                                                                                                                                        when(frame1.equals(frame2)).thenReturn(false);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2D_DifferentAngleStart() {
                                                                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                        when(arc1.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(arc2.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(frame.equals(frame)).thenReturn(true);
                                                                                                                                                                                                        when(arc1.getAngleStart()).thenReturn(45.0);
                                                                                                                                                                                                        when(arc2.getAngleStart()).thenReturn(90.0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2D_DifferentAngleExtent() {
                                                                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                        when(arc1.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(arc2.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(frame.equals(frame)).thenReturn(true);
                                                                                                                                                                                                        when(arc1.getAngleStart()).thenReturn(45.0);
                                                                                                                                                                                                        when(arc2.getAngleStart()).thenReturn(45.0);
                                                                                                                                                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                                                                        when(arc2.getAngleExtent()).thenReturn(180.0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2D_DifferentArcType() {
                                                                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                        when(arc1.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(arc2.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(frame.equals(frame)).thenReturn(true);
                                                                                                                                                                                                        when(arc1.getAngleStart()).thenReturn(45.0);
                                                                                                                                                                                                        when(arc2.getAngleStart()).thenReturn(45.0);
                                                                                                                                                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                                                                        when(arc2.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                                                                        when(arc1.getArcType()).thenReturn(Arc2D.PIE);
                                                                                                                                                                                                        when(arc2.getArcType()).thenReturn(Arc2D.CHORD);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2D_AllPropertiesEqual() {
                                                                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                        when(arc1.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(arc2.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(frame.equals(frame)).thenReturn(true);
                                                                                                                                                                                                        when(arc1.getAngleStart()).thenReturn(45.0);
                                                                                                                                                                                                        when(arc2.getAngleStart()).thenReturn(45.0);
                                                                                                                                                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                                                                        when(arc2.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                                                                        when(arc1.getArcType()).thenReturn(Arc2D.PIE);
                                                                                                                                                                                                        when(arc2.getArcType()).thenReturn(Arc2D.PIE);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_Arc2D_SameObjectInstance() {
                                                                                                                                                                                                        Arc2D arc = mock(Arc2D.class);
                                                                                                                                                                                                        Rectangle2D frame = mock(Rectangle2D.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                        when(arc.getFrame()).thenReturn(frame);
                                                                                                                                                                                                        when(frame.equals(frame)).thenReturn(true);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(arc, arc));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_FirstNullSecondNotNull1() {
                                                                                                                                                                                                        Polygon p2 = new Polygon(new int[]{1, 2}, new int[]{1, 2}, 2);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(null, p2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_FirstNotNullSecondNull1() {
                                                                                                                                                                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{1, 2}, 2);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, null));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_DifferentNumberOfPoints() {
                                                                                                                                                                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{1, 2}, 2);
                                                                                                                                                                                                        Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{1, 2, 3}, 3);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_DifferentXPoints() {
                                                                                                                                                                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{1, 2}, 2);
                                                                                                                                                                                                        Polygon p2 = new Polygon(new int[]{1, 3}, new int[]{1, 2}, 2);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_DifferentYPoints() {
                                                                                                                                                                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{1, 2}, 2);
                                                                                                                                                                                                        Polygon p2 = new Polygon(new int[]{1, 2}, new int[]{1, 3}, 2);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_IdenticalPolygons() {
                                                                                                                                                                                                        Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                                                                        Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_SameInstance1() {
                                                                                                                                                                                                        Polygon p1 = new Polygon(new int[]{1, 2}, new int[]{1, 2}, 2);
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(p1, p1));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_EmptyPolygons() {
                                                                                                                                                                                                        Polygon p1 = new Polygon(new int[]{}, new int[]{}, 0);
                                                                                                                                                                                                        Polygon p2 = new Polygon(new int[]{}, new int[]{}, 0);
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_LargePolygons() {
                                                                                                                                                                                                        int size = 1000;
                                                                                                                                                                                                        int[] xpoints = new int[size];
                                                                                                                                                                                                        int[] ypoints = new int[size];
                                                                                                                                                                                                        Arrays.fill(xpoints, 1);
                                                                                                                                                                                                        Arrays.fill(ypoints, 2);
                                                                                                                                                                                                        
                                                                                                                                                                                                        Polygon p1 = new Polygon(xpoints, ypoints, size);
                                                                                                                                                                                                        Polygon p2 = new Polygon(xpoints, ypoints, size);
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Change one point
                                                                                                                                                                                                        xpoints[0] = 2;
                                                                                                                                                                                                        Polygon p3 = new Polygon(xpoints, ypoints, size);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p3));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_FirstNullSecondNotNull2() {
                                                                                                                                                                                                        Shape nonNullShape = mock(Shape.class);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(null, nonNullShape));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_FirstNotNullSecondNull2() {
                                                                                                                                                                                                        Shape nonNullShape = mock(Shape.class);
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(nonNullShape, null));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testEqual_RealShapes() {
                                                                                                                                                                                                        // Test with actual Shape implementations
                                                                                                                                                                                                        Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                        Line2D line2 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                        Line2D line3 = new Line2D.Double(0, 0, 20, 20);
                                                                                                                                                                                                        
                                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                                        assertFalse(ShapeUtilities.equal(line1, line3));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                            public void testEqual_NullInputs() {
                                                                                                                                                                                                Line2D line = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                                                                                
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal((Shape) null, (Shape) null));
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal((Shape) line, (Shape) null));
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal((Shape) null, (Shape) line));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_UnsupportedShapeType() {
                                                                                                                                                                                                // Create a custom shape that's not one of the supported types
                                                                                                                                                                                                java.awt.Shape customShape = new java.awt.Shape() {
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public java.awt.Rectangle getBounds() { return null; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public java.awt.geom.Rectangle2D getBounds2D() { return null; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public boolean contains(double x, double y) { return false; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public boolean contains(java.awt.geom.Point2D p) { return false; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public boolean intersects(double x, double y, double w, double h) { return false; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public boolean intersects(java.awt.geom.Rectangle2D r) { return false; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public boolean contains(double x, double y, double w, double h) { return false; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public boolean contains(java.awt.geom.Rectangle2D r) { return false; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform at) { return null; }
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform at, double flatness) { return null; }
                                                                                                                                                                                                };
                                                                                                                                                                                                
                                                                                                                                                                                                // Should fall back to ObjectUtilities.equal()
                                                                                                                                                                                                assertFalse(org.jfree.chart.util.ShapeUtilities.equal(customShape, customShape));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_BothLinesNull() {
                                                                                                                                                                                                Line2D line1 = null;
                                                                                                                                                                                                Line2D line2 = null;
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_FirstLineNullSecondNotNull() {
                                                                                                                                                                                                Line2D line2 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(null, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_FirstLineNotNullSecondNull() {
                                                                                                                                                                                                Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(line1, null));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_BothLinesSameReference() {
                                                                                                                                                                                                Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal(line1, line1));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_LinesEqualPointsSameOrder() {
                                                                                                                                                                                                Point2D p1 = new Point2D.Double(1.0, 2.0);
                                                                                                                                                                                                Point2D p2 = new Point2D.Double(3.0, 4.0);
                                                                                                                                                                                                Point2D p3 = new Point2D.Double(1.0, 2.0);
                                                                                                                                                                                                Point2D p4 = new Point2D.Double(3.0, 4.0);
                                                                                                                                                                                                
                                                                                                                                                                                                Line2D line1 = new Line2D.Double(p1, p2);
                                                                                                                                                                                                Line2D line2 = new Line2D.Double(p3, p4);
                                                                                                                                                                                                
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_LinesEqualPointsReverseOrder() {
                                                                                                                                                                                                Point2D p1 = new Point2D.Double(1, 1);
                                                                                                                                                                                                Point2D p2 = new Point2D.Double(2, 2);
                                                                                                                                                                                                Point2D p3 = new Point2D.Double(2, 2);
                                                                                                                                                                                                Point2D p4 = new Point2D.Double(1, 1);
                                                                                                                                                                                                Line2D line1 = new Line2D.Double(p1, p2);
                                                                                                                                                                                                Line2D line2 = new Line2D.Double(p3, p4);
                                                                                                                                                                                                
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_LinesDifferentFirstPoint() {
                                                                                                                                                                                                // Create mock points for the lines
                                                                                                                                                                                                Point2D p1 = mock(Point2D.class);
                                                                                                                                                                                                Point2D p2 = mock(Point2D.class);
                                                                                                                                                                                                Point2D p3 = mock(Point2D.class);
                                                                                                                                                                                                Point2D p4 = mock(Point2D.class);
                                                                                                                                                                                                
                                                                                                                                                                                                // Create mock lines
                                                                                                                                                                                                Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                                
                                                                                                                                                                                                // Setup line endpoints
                                                                                                                                                                                                when(line1.getP1()).thenReturn(p1);
                                                                                                                                                                                                when(line1.getP2()).thenReturn(p2);
                                                                                                                                                                                                when(line2.getP1()).thenReturn(p3);
                                                                                                                                                                                                when(line2.getP2()).thenReturn(p4);
                                                                                                                                                                                                
                                                                                                                                                                                                // Configure point equality behavior
                                                                                                                                                                                                when(p1.equals(p3)).thenReturn(false);
                                                                                                                                                                                                when(p2.equals(p4)).thenReturn(true);
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_LinesDifferentSecondPoint() {
                                                                                                                                                                                                Point2D p1 = mock(Point2D.class);
                                                                                                                                                                                                Point2D p2 = mock(Point2D.class);
                                                                                                                                                                                                Point2D p3 = mock(Point2D.class);
                                                                                                                                                                                                Point2D p4 = mock(Point2D.class);
                                                                                                                                                                                                
                                                                                                                                                                                                Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                                
                                                                                                                                                                                                when(line1.getP1()).thenReturn(p1);
                                                                                                                                                                                                when(line1.getP2()).thenReturn(p2);
                                                                                                                                                                                                when(line2.getP1()).thenReturn(p3);
                                                                                                                                                                                                when(line2.getP2()).thenReturn(p4);
                                                                                                                                                                                                
                                                                                                                                                                                                when(p1.equals(p3)).thenReturn(true);
                                                                                                                                                                                                when(p2.equals(p4)).thenReturn(false);
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_LinesBothPointsDifferent() {
                                                                                                                                                                                                Point2D p1 = new Point2D.Double(1.0, 2.0);
                                                                                                                                                                                                Point2D p2 = new Point2D.Double(3.0, 4.0);
                                                                                                                                                                                                Point2D p3 = new Point2D.Double(5.0, 6.0);
                                                                                                                                                                                                Point2D p4 = new Point2D.Double(7.0, 8.0);
                                                                                                                                                                                                Line2D line1 = new Line2D.Double(p1, p2);
                                                                                                                                                                                                Line2D line2 = new Line2D.Double(p3, p4);
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_FirstPointNullInFirstLine() {
                                                                                                                                                                                                Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                                when(line1.getP1()).thenReturn(null);
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_SecondPointNullInFirstLine() {
                                                                                                                                                                                                Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                                when(line1.getP2()).thenReturn(null);
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_FirstPointNullInSecondLine() {
                                                                                                                                                                                                Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                                when(line1.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                                                                                                                                                                when(line1.getP2()).thenReturn(new Point2D.Double(1, 1));
                                                                                                                                                                                                when(line2.getP1()).thenReturn(null);
                                                                                                                                                                                                when(line2.getP2()).thenReturn(new Point2D.Double(1, 1));
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_SecondPointNullInSecondLine() {
                                                                                                                                                                                                Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                                when(line1.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                                                                                                                                                                when(line1.getP2()).thenReturn(new Point2D.Double(1, 1));
                                                                                                                                                                                                when(line2.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                                                                                                                                                                when(line2.getP2()).thenReturn(null);
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_BothNull() {
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal((Shape) null, (Shape) null));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_DifferentFrames() {
                                                                                                                                                                                                Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_SameFrames() {
                                                                                                                                                                                                Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                                                                Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                                                                Rectangle2D sameFrame = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                when(e1.getFrame()).thenReturn(sameFrame);
                                                                                                                                                                                                when(e2.getFrame()).thenReturn(sameFrame);
                                                                                                                                                                                                
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_Arc2D_BothNull() {
                                                                                                                                                                                                Arc2D arc1 = null;
                                                                                                                                                                                                Arc2D arc2 = null;
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_BothNull1() {
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal((Shape) null, (Shape) null));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_BothNull2() {
                                                                                                                                                                                                Shape shape1 = null;
                                                                                                                                                                                                Shape shape2 = null;
                                                                                                                                                                                                assertTrue(ShapeUtilities.equal(shape1, shape2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_DifferentPathLengths() {
                                                                                                                                                                                                java.awt.Shape shape1 = mock(java.awt.Shape.class);
                                                                                                                                                                                                java.awt.Shape shape2 = mock(java.awt.Shape.class);
                                                                                                                                                                                                java.awt.geom.PathIterator iterator1 = mock(java.awt.geom.PathIterator.class);
                                                                                                                                                                                                java.awt.geom.PathIterator iterator2 = mock(java.awt.geom.PathIterator.class);
                                                                                                                                                                                                
                                                                                                                                                                                                when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                                                                                                when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                                                                                                when(iterator1.getWindingRule()).thenReturn(java.awt.geom.PathIterator.WIND_NON_ZERO);
                                                                                                                                                                                                when(iterator2.getWindingRule()).thenReturn(java.awt.geom.PathIterator.WIND_NON_ZERO);
                                                                                                                                                                                                
                                                                                                                                                                                                // First shape has more segments
                                                                                                                                                                                                when(iterator1.isDone()).thenReturn(false).thenReturn(false).thenReturn(true);
                                                                                                                                                                                                when(iterator2.isDone()).thenReturn(false).thenReturn(true);
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(org.jfree.chart.util.ShapeUtilities.equal(shape1, shape2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testEqual_DifferentPathCoordinates() {
                                                                                                                                                                                                Shape shape1 = mock(Shape.class);
                                                                                                                                                                                                Shape shape2 = mock(Shape.class);
                                                                                                                                                                                                PathIterator iterator1 = mock(PathIterator.class);
                                                                                                                                                                                                PathIterator iterator2 = mock(PathIterator.class);
                                                                                                                                                                                                
                                                                                                                                                                                                when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                                                                                                when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                                                                                                
                                                                                                                                                                                                // Same segment types but different coordinates
                                                                                                                                                                                                when(iterator1.isDone()).thenReturn(false).thenReturn(true);
                                                                                                                                                                                                when(iterator2.isDone()).thenReturn(false).thenReturn(true);
                                                                                                                                                                                                when(iterator1.currentSegment(any(double[].class))).thenAnswer(invocation -> {
                                                                                                                                                                                                    double[] arr = invocation.getArgument(0);
                                                                                                                                                                                                    Arrays.fill(arr, 1.0);
                                                                                                                                                                                                    return PathIterator.SEG_MOVETO;
                                                                                                                                                                                                });
                                                                                                                                                                                                when(iterator2.currentSegment(any(double[].class))).thenAnswer(invocation -> {
                                                                                                                                                                                                    double[] arr = invocation.getArgument(0);
                                                                                                                                                                                                    Arrays.fill(arr, 2.0);
                                                                                                                                                                                                    return PathIterator.SEG_MOVETO;
                                                                                                                                                                                                });
                                                                                                                                                                                                
                                                                                                                                                                                                assertFalse(ShapeUtilities.equal(shape1, shape2));
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                        public void testEqual_FirstHasNullFrame() {
                                                                                                                                                                                            Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                                                            Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                                                            when(e1.getFrame()).thenReturn(null);
                                                                                                                                                                                            when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0.0, 0.0, 10.0, 10.0));
                                                                                                                                                                                            
                                                                                                                                                                                            assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testEqual_SecondHasNullFrame() {
                                                                                                                                                                                            Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                                                            Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                                                            when(e1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                                                            when(e2.getFrame()).thenReturn(null);
                                                                                                                                                                                            
                                                                                                                                                                                            assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                    public void testEqual_SameWindingRulesSamePaths() {
                                                                                                                                                                                        // Create mock objects
                                                                                                                                                                                        Shape shape1 = mock(Shape.class);
                                                                                                                                                                                        Shape shape2 = mock(Shape.class);
                                                                                                                                                                                        PathIterator iterator1 = mock(PathIterator.class);
                                                                                                                                                                                        PathIterator iterator2 = mock(PathIterator.class);
                                                                                                                                                                                        
                                                                                                                                                                                        // Set up mock behavior
                                                                                                                                                                                        when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                                                                                        when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                                                                                        
                                                                                                                                                                                        // Same path data
                                                                                                                                                                                        when(iterator1.isDone())
                                                                                                                                                                                            .thenReturn(false)
                                                                                                                                                                                            .thenReturn(true);
                                                                                                                                                                                        when(iterator2.isDone())
                                                                                                                                                                                            .thenReturn(false)
                                                                                                                                                                                            .thenReturn(true);
                                                                                                                                                                                        
                                                                                                                                                                                        double[] coords = new double[]{1.0, 2.0, 3.0, 4.0, 5.0, 6.0};
                                                                                                                                                                                        when(iterator1.currentSegment(any(double[].class)))
                                                                                                                                                                                            .thenAnswer(invocation -> {
                                                                                                                                                                                                double[] arr = invocation.getArgument(0);
                                                                                                                                                                                                System.arraycopy(coords, 0, arr, 0, coords.length);
                                                                                                                                                                                                return PathIterator.SEG_MOVETO;
                                                                                                                                                                                            });
                                                                                                                                                                                        when(iterator2.currentSegment(any(double[].class)))
                                                                                                                                                                                            .thenAnswer(invocation -> {
                                                                                                                                                                                                double[] arr = invocation.getArgument(0);
                                                                                                                                                                                                System.arraycopy(coords, 0, arr, 0, coords.length);
                                                                                                                                                                                                return PathIterator.SEG_MOVETO;
                                                                                                                                                                                            });
                                                                                                                                                                                        
                                                                                                                                                                                        // Assertion
                                                                                                                                                                                        assertTrue(ShapeUtilities.equal(shape1, shape2));
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                            public void testEqual_SameWindingRulesDifferentPaths() {
                                                                                                                                                                                // Mock the required objects
                                                                                                                                                                                Shape shape1 = mock(Shape.class);
                                                                                                                                                                                Shape shape2 = mock(Shape.class);
                                                                                                                                                                                PathIterator iterator1 = mock(PathIterator.class);
                                                                                                                                                                                PathIterator iterator2 = mock(PathIterator.class);
                                                                                                                                                                                
                                                                                                                                                                                // Set up mock behavior
                                                                                                                                                                                when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                                                                                when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                                                                                when(iterator1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                                                                                                when(iterator2.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                                                                                                
                                                                                                                                                                                // First segment different
                                                                                                                                                                                when(iterator1.isDone()).thenReturn(false).thenReturn(true);
                                                                                                                                                                                when(iterator2.isDone()).thenReturn(false).thenReturn(true);
                                                                                                                                                                                when(iterator1.currentSegment(any(double[].class)))
                                                                                                                                                                                    .thenReturn(PathIterator.SEG_MOVETO);
                                                                                                                                                                                when(iterator2.currentSegment(any(double[].class)))
                                                                                                                                                                                    .thenReturn(PathIterator.SEG_LINETO);
                                                                                                                                                                                
                                                                                                                                                                                // Assert
                                                                                                                                                                                assertFalse(ShapeUtilities.equal(shape1, shape2));
                                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testEqual_DifferentWindingRules() {
                                                                                                                                                        // Create mock Shape objects
                                                                                                                                                        Shape shape1 = new GeneralPath();
                                                                                                                                                        Shape shape2 = new GeneralPath();
                                                                                                                                                        
                                                                                                                                                        // Create mock PathIterator objects
                                                                                                                                                        PathIterator iterator1 = shape1.getPathIterator(null);
                                                                                                                                                        PathIterator iterator2 = shape2.getPathIterator(null);
                                                                                                                                                        
                                                                                                                                                        // Use reflection to set different winding rules for the shapes
                                                                                                                                                        try {
                                                                                                                                                            Field field1 = iterator1.getClass().getDeclaredField("windingRule");
                                                                                                                                                            field1.setAccessible(true);
                                                                                                                                                            field1.set(iterator1, PathIterator.WIND_EVEN_ODD);
                                                                                                                                                            
                                                                                                                                                            Field field2 = iterator2.getClass().getDeclaredField("windingRule");
                                                                                                                                                            field2.setAccessible(true);
                                                                                                                                                            field2.set(iterator2, PathIterator.WIND_NON_ZERO);
                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                            fail("Failed to set winding rules via reflection");
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        // Assert that shapes with different winding rules are not equal
                                                                                                                                                        assertFalse(ShapeUtilities.equal(shape1, shape2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqualPolygonWithNull() {
                                                                                                                                                        // Create a non-null polygon
                                                                                                                                                        Polygon p1 = new Polygon(new int[]{0, 10, 10, 0}, new int[]{0, 0, 10, 10}, 4);
                                                                                                                                                        
                                                                                                                                                        // Test case 1: second polygon is null
                                                                                                                                                        assertFalse("Comparing Polygon with null should return false", 
                                                                                                                                                            ShapeUtilities.equal(p1, (Polygon)null));
                                                                                                                                                        
                                                                                                                                                        // Test case 2: first polygon is null
                                                                                                                                                        assertFalse("Comparing null with Polygon should return false",
                                                                                                                                                            ShapeUtilities.equal((Polygon)null, p1));
                                                                                                                                                            
                                                                                                                                                        // Test case 3: both polygons are null
                                                                                                                                                        assertTrue("Comparing null with null should return true",
                                                                                                                                                            ShapeUtilities.equal((Polygon)null, (Polygon)null));
                                                                                                                                                            
                                                                                                                                                        // Test case 4: both polygons are non-null and equal
                                                                                                                                                        Polygon p2 = new Polygon(new int[]{0, 10, 10, 0}, new int[]{0, 0, 10, 10}, 4);
                                                                                                                                                        assertTrue("Comparing equal Polygons should return true",
                                                                                                                                                            ShapeUtilities.equal(p1, p2));
                                                                                                                                                            
                                                                                                                                                        // Test case 5: both polygons are non-null but different
                                                                                                                                                        Polygon p3 = new Polygon(new int[]{0, 20, 20, 0}, new int[]{0, 0, 20, 20}, 4);
                                                                                                                                                        assertFalse("Comparing different Polygons should return false",
                                                                                                                                                            ShapeUtilities.equal(p1, p3));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_Line2D_ShouldReturnFalseWhenFirstNonNullAndSecondNull() {
                                                                                                                                                        // Setup
                                                                                                                                                        Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                        Line2D line2 = null;
                                                                                                                                                        
                                                                                                                                                        // Test
                                                                                                                                                        boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertFalse("Should return false when first line is not null and second is null", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_Line2D_ShouldReturnTrueWhenBothNull() {
                                                                                                                                                        // Setup
                                                                                                                                                        Line2D line1 = null;
                                                                                                                                                        Line2D line2 = null;
                                                                                                                                                        
                                                                                                                                                        // Test
                                                                                                                                                        boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertTrue("Should return true when both lines are null", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_Line2D_ShouldReturnFalseWhenLinesHaveDifferentPoints() {
                                                                                                                                                        // Setup
                                                                                                                                                        Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                        Line2D line2 = new Line2D.Double(0, 0, 20, 20);
                                                                                                                                                        
                                                                                                                                                        // Test
                                                                                                                                                        boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertFalse("Should return false when lines have different points", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_Line2D_ShouldReturnTrueWhenLinesAreEqual() {
                                                                                                                                                        // Setup
                                                                                                                                                        Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                        Line2D line2 = new Line2D.Double(0, 0, 10, 10);
                                                                                                                                                        
                                                                                                                                                        // Test
                                                                                                                                                        boolean result = ShapeUtilities.equal(line1, line2);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertTrue("Should return true when lines are equal", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_Ellipse2D_SecondParamNull() {
                                                                                                                                                        // Create a non-null Ellipse2D object
                                                                                                                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                        
                                                                                                                                                        // Test when second parameter is null
                                                                                                                                                        boolean result = ShapeUtilities.equal(e1, null);
                                                                                                                                                        
                                                                                                                                                        // Original code should return false when e1 is not null and e2 is null
                                                                                                                                                        // Mutated code would either return wrong result or throw exception
                                                                                                                                                        assertFalse("Should return false when second parameter is null and first is not", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_Ellipse2D_FirstParamNull() {
                                                                                                                                                        // Create a non-null Ellipse2D object
                                                                                                                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                        
                                                                                                                                                        // Test when first parameter is null
                                                                                                                                                        boolean result = ShapeUtilities.equal(null, e2);
                                                                                                                                                        
                                                                                                                                                        // Should return false when first parameter is null and second is not
                                                                                                                                                        assertFalse("Should return false when first parameter is null and second is not", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_Arc2D_SecondParameterNull() {
                                                                                                                                                        // Create a non-null Arc2D object
                                                                                                                                                        Arc2D a1 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
                                                                                                                                                        
                                                                                                                                                        // Test when second parameter is null
                                                                                                                                                        boolean result = ShapeUtilities.equal(a1, null);
                                                                                                                                                        
                                                                                                                                                        // Original behavior should return false, mutant would return true
                                                                                                                                                        assertFalse("Expected false when second parameter is null", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_Arc2D_FirstParameterNull() {
                                                                                                                                                        // Create a non-null Arc2D object
                                                                                                                                                        Arc2D a2 = new Arc2D.Double(0, 0, 100, 100, 0, 90, Arc2D.PIE);
                                                                                                                                                        
                                                                                                                                                        // Test when first parameter is null
                                                                                                                                                        boolean result = ShapeUtilities.equal(null, a2);
                                                                                                                                                        
                                                                                                                                                        // Should return false when first is null and second is not
                                                                                                                                                        assertFalse("Expected false when first parameter is null", result);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_PolygonP1NotNullP2Null_ShouldReturnFalse() {
                                                                                                                                                        // Create a non-null polygon for p1
                                                                                                                                                        Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                        Polygon p2 = null;
                                                                                                                                                        
                                                                                                                                                        // The original method should return false when p1 is not null and p2 is null
                                                                                                                                                        // The mutant would incorrectly proceed to other checks instead of returning false
                                                                                                                                                        assertFalse("Should return false when p1 is not null and p2 is null", 
                                                                                                                                                                   ShapeUtilities.equal(p1, p2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_PolygonP1NullP2NotNull_ShouldReturnFalse() {
                                                                                                                                                        // Test case where p1 is null and p2 is not null
                                                                                                                                                        Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                        assertFalse("Should return false when p1 is null and p2 is not null",
                                                                                                                                                                   ShapeUtilities.equal(null, p2));
                                                                                                                                                    }

    @Test
                                                                                                                                            public void testEqual_Ellipse2D_BothNull() {
                                                                                                                                                // Test when both parameters are null
                                                                                                                                                boolean result = ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null);
                                                                                                                                                
                                                                                                                                                // Should return true for both original and mutated code
                                                                                                                                                assertTrue("Should return true when both parameters are null", result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Arc2D_BothNull1() {
                                                                                                                                                // Test when both parameters are null
                                                                                                                                                boolean result = ShapeUtilities.equal((Arc2D) null, (Arc2D) null);
                                                                                                                                                
                                                                                                                                                // Should return true for both null
                                                                                                                                                assertTrue("Expected true when both parameters are null", result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_PolygonBothNull_ShouldReturnTrue() {
                                                                                                                                                // Test case where both polygons are null
                                                                                                                                                Polygon p1 = null;
                                                                                                                                                Polygon p2 = null;
                                                                                                                                                assertTrue("Should return true when both polygons are null",
                                                                                                                                                          ShapeUtilities.equal(p1, p2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_WhenP1NotNullAndP2Null_ShouldReturnFalse() {
                                                                                                                                                // Arrange
                                                                                                                                                Shape p1 = new java.awt.geom.Path2D.Double(); // non-null shape
                                                                                                                                                Shape p2 = null;
                                                                                                                                                
                                                                                                                                                // Act
                                                                                                                                                boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                                                                
                                                                                                                                                // Assert
                                                                                                                                                assertFalse("Should return false when p1 is not null and p2 is null", result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualOtherShapeTypes() {
                                                                                                                                                // Additional tests for other shape types to ensure full coverage
                                                                                                                                                Line2D line1 = new Line2D.Double(1,2,3,4);
                                                                                                                                                Line2D line2 = new Line2D.Double(1,2,3,4);
                                                                                                                                                assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                
                                                                                                                                                Ellipse2D ellipse1 = new Ellipse2D.Double(1,2,3,4);
                                                                                                                                                Ellipse2D ellipse2 = new Ellipse2D.Double(1,2,3,4);
                                                                                                                                                assertTrue(ShapeUtilities.equal(ellipse1, ellipse2));
                                                                                                                                                
                                                                                                                                                Arc2D arc1 = new Arc2D.Double(1,2,3,4,5,6,Arc2D.PIE);
                                                                                                                                                Arc2D arc2 = new Arc2D.Double(1,2,3,4,5,6,Arc2D.PIE);
                                                                                                                                                assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                
                                                                                                                                                GeneralPath path1 = new GeneralPath();
                                                                                                                                                path1.moveTo(1,2);
                                                                                                                                                GeneralPath path2 = new GeneralPath();
                                                                                                                                                path2.moveTo(1,2);
                                                                                                                                                assertTrue(ShapeUtilities.equal(path1, path2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Ellipse2D_BothNull1() {
                                                                                                                                                // This test will catch the mutant where (e2 == null) was changed to (true)
                                                                                                                                                Ellipse2D e1 = null;
                                                                                                                                                Ellipse2D e2 = null;
                                                                                                                                                
                                                                                                                                                // Original behavior should return true when both are null
                                                                                                                                                // Mutant will return false due to changed condition
                                                                                                                                                assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Ellipse2D_FirstNullSecondNotNull() {
                                                                                                                                                Ellipse2D e1 = null;
                                                                                                                                                Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                
                                                                                                                                                assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Ellipse2D_FirstNotNullSecondNull() {
                                                                                                                                                Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                Ellipse2D e2 = null;
                                                                                                                                                
                                                                                                                                                assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Ellipse2D_DifferentFrames() {
                                                                                                                                                Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                                                                                                                                                
                                                                                                                                                assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Ellipse2D_SameFrames() {
                                                                                                                                                Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                
                                                                                                                                                assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Arc2D_ShouldReturnFalseWhenFirstIsNullAndSecondIsNotNull() {
                                                                                                                                                // Setup
                                                                                                                                                Arc2D a1 = null;
                                                                                                                                                Arc2D a2 = new Arc2D.Double();
                                                                                                                                                
                                                                                                                                                // Test & Verify
                                                                                                                                                assertFalse("Should return false when first arc is null and second is not null", 
                                                                                                                                                           ShapeUtilities.equal(a1, a2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Arc2D_ShouldReturnFalseWhenSecondIsNullAndFirstIsNotNull() {
                                                                                                                                                // Setup
                                                                                                                                                Arc2D a1 = new Arc2D.Double();
                                                                                                                                                Arc2D a2 = null;
                                                                                                                                                
                                                                                                                                                // Test & Verify
                                                                                                                                                assertFalse("Should return false when second arc is null and first is not null", 
                                                                                                                                                           ShapeUtilities.equal(a1, a2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_Arc2D_ShouldReturnTrueWhenBothAreNull() {
                                                                                                                                                // Setup
                                                                                                                                                Arc2D a1 = null;
                                                                                                                                                Arc2D a2 = null;
                                                                                                                                                
                                                                                                                                                // Test & Verify
                                                                                                                                                assertTrue("Should return true when both arcs are null", 
                                                                                                                                                          ShapeUtilities.equal(a1, a2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualPolygonWithNonNullP() {
                                                                                                                                                // Create two identical non-null polygons
                                                                                                                                                Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                                                                                                                
                                                                                                                                                // Original behavior: should return true since polygons are equal
                                                                                                                                                // Mutant behavior: will return false because it hits the 'if (true)' block
                                                                                                                                                assertTrue("Equal polygons should return true", 
                                                                                                                                                    ShapeUtilities.equal(p1, p2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualPolygonWithNullP() {
                                                                                                                                                // Test case where p1 is null and p2 is not null
                                                                                                                                                Polygon p2 = new Polygon(new int[]{1}, new int[]{1}, 1);
                                                                                                                                                
                                                                                                                                                // Both original and mutant should return false
                                                                                                                                                assertFalse("Null p1 with non-null p2 should return false",
                                                                                                                                                    ShapeUtilities.equal(null, p2));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqualPolygonWithNullP1() {
                                                                                                                                                // Test case where p1 is not null and p2 is null
                                                                                                                                                Polygon p1 = new Polygon(new int[]{1}, new int[]{1}, 1);
                                                                                                                                                
                                                                                                                                                // Both original and mutant should return false
                                                                                                                                                assertFalse("Non-null p1 with null p2 should return false",
                                                                                                                                                    ShapeUtilities.equal(p1, null));
                                                                                                                                            }

    @Test
                                                                                                                                            public void testEqual_BothNullShouldReturnTrue() {
                                                                                                                                                // Setup
                                                                                                                                                Shape p1 = null;
                                                                                                                                                Shape p2 = null;
                                                                                                                                                
                                                                                                                                                // Test and verify
                                                                                                                                                assertTrue("Should return true when both shapes are null",
                                                                                                                                                          ShapeUtilities.equal(p1, p2));
                                                                                                                                            }

    @Test
                                                                                                                                    public void testEqualPolygonWithNull1() {
                                                                                                                                        // Create test polygons
                                                                                                                                        Polygon p1 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                                                                                                        Polygon p2 = null;
                                                                                                                                        
                                                                                                                                        // Test case 1: both null (should return true)
                                                                                                                                        assertTrue(ShapeUtilities.equal((Polygon)null, (Polygon)null));
                                                                                                                                        
                                                                                                                                        // Test case 2: non-null vs null (should return false)
                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                        assertFalse(ShapeUtilities.equal(p2, p1));
                                                                                                                                        
                                                                                                                                        // Test case 3: two equal non-null polygons
                                                                                                                                        Polygon p3 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                                                                                                        assertTrue(ShapeUtilities.equal(p1, p3));
                                                                                                                                        
                                                                                                                                        // Test case 4: two different non-null polygons
                                                                                                                                        Polygon p4 = new Polygon(new int[]{7,8,9}, new int[]{10,11,12}, 3);
                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p4));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testEqual_Line2D_DetectMutant() {
                                                                                                                                        // Create non-null Line2D objects for testing
                                                                                                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                        Line2D line2 = new Line2D.Double(1, 2, 3, 4);
                                                                                                                                        Line2D line3 = new Line2D.Double(5, 6, 7, 8); // Different line
                                                                                                                                        
                                                                                                                                        // Case 1: Both lines are equal
                                                                                                                                        assertTrue("Equal lines should return true", 
                                                                                                                                            ShapeUtilities.equal((Line2D)line1, (Line2D)line2));
                                                                                                                                        
                                                                                                                                        // Case 2: Lines are different
                                                                                                                                        assertFalse("Different lines should return false",
                                                                                                                                            ShapeUtilities.equal((Line2D)line1, (Line2D)line3));
                                                                                                                                            
                                                                                                                                        // Case 3: First line is null, second is not
                                                                                                                                        assertFalse("l1 null, l2 not null should return false",
                                                                                                                                            ShapeUtilities.equal((Line2D)null, (Line2D)line1));
                                                                                                                                            
                                                                                                                                        // Case 4: Both lines are null
                                                                                                                                        assertTrue("Both null should return true",
                                                                                                                                            ShapeUtilities.equal((Line2D)null, (Line2D)null));
                                                                                                                                            
                                                                                                                                        // Case 5: l1 not null, l2 null - this would pass both original and mutant
                                                                                                                                        assertFalse("l1 not null, l2 null should return false",
                                                                                                                                            ShapeUtilities.equal((Line2D)line1, (Line2D)null));
                                                                                                                                            
                                                                                                                                        // Case 6: The key test to detect the mutant - both not null
                                                                                                                                        // Original would return true for equal lines, mutant would return false
                                                                                                                                        assertTrue("Equal non-null lines should return true (detects mutant)",
                                                                                                                                            ShapeUtilities.equal((Line2D)line1, (Line2D)line2));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testEqual_FirstNullSecondNotNull3() {
                                                                                                                                        // Setup
                                                                                                                                        Shape p1 = null;
                                                                                                                                        Shape p2 = new java.awt.geom.Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                        
                                                                                                                                        // Test and verify
                                                                                                                                        assertFalse("Should return false when first shape is null and second is not null", 
                                                                                                                                                   ShapeUtilities.equal(p1, p2));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testEqual_FirstNullSecondNotNull4() {
                                                                                                                                        // Setup
                                                                                                                                        Shape p1 = null;
                                                                                                                                        Shape p2 = new java.awt.geom.Rectangle2D.Double();
                                                                                                                                        
                                                                                                                                        // Test and verify
                                                                                                                                        // Original should return false (since p2 is not null)
                                                                                                                                        // Mutated version will hit the if(true) and return false
                                                                                                                                        // This doesn't catch the mutation - we need a different approach
                                                                                                                                        
                                                                                                                                        // Better test case that would catch the mutation:
                                                                                                                                        Shape p3 = null;
                                                                                                                                        Shape p4 = null;
                                                                                                                                        assertTrue("Should return true when both shapes are null",
                                                                                                                                                  ShapeUtilities.equal(p3, p4));
                                                                                                                                        
                                                                                                                                        // The mutation would make this fail because it would hit if(true) return false
                                                                                                                                        // even when both are null
                                                                                                                                    }

    @Test
                                                                                                                                    public void testEqualGeneralPathWithDifferentWindingRules() {
                                                                                                                                        // Create two GeneralPath objects with different winding rules
                                                                                                                                        GeneralPath path1 = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
                                                                                                                                        GeneralPath path2 = new GeneralPath(GeneralPath.WIND_NON_ZERO);
                                                                                                                                        
                                                                                                                                        // Add same points to both paths to make them identical except for winding rule
                                                                                                                                        path1.moveTo(0, 0);
                                                                                                                                        path1.lineTo(10, 0);
                                                                                                                                        path1.lineTo(10, 10);
                                                                                                                                        path1.closePath();
                                                                                                                                        
                                                                                                                                        path2.moveTo(0, 0);
                                                                                                                                        path2.lineTo(10, 0);
                                                                                                                                        path2.lineTo(10, 10);
                                                                                                                                        path2.closePath();
                                                                                                                                        
                                                                                                                                        // The original implementation should return false because winding rules differ
                                                                                                                                        // The mutant would return true because it ignores winding rules
                                                                                                                                        assertFalse("Paths with different winding rules should not be equal", 
                                                                                                                                                   ShapeUtilities.equal(path1, path2));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testEqualGeneralPathWithDifferentWindingRules1() {
                                                                                                                                        // Create mock GeneralPath objects
                                                                                                                                        GeneralPath path1 = mock(GeneralPath.class);
                                                                                                                                        GeneralPath path2 = mock(GeneralPath.class);
                                                                                                                                        
                                                                                                                                        // Set up identical properties except winding rule
                                                                                                                                        Rectangle2D frame = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                                                                        when(path1.getBounds2D()).thenReturn(frame);
                                                                                                                                        when(path2.getBounds2D()).thenReturn(frame);
                                                                                                                                        when(path1.getWindingRule()).thenReturn(GeneralPath.WIND_EVEN_ODD);
                                                                                                                                        when(path2.getWindingRule()).thenReturn(GeneralPath.WIND_NON_ZERO);
                                                                                                                                        
                                                                                                                                        // The original method should return false for different winding rules
                                                                                                                                        // The mutant would return true
                                                                                                                                        assertFalse("Paths with different winding rules should not be equal", 
                                                                                                                                                   ShapeUtilities.equal(path1, path2));
                                                                                                                                    }

    @Test
                                                                                                                                    public void testEqualPolygonWithDifferentWindingRules() {
                                                                                                                                        // Create two polygons with identical points but different winding rules
                                                                                                                                        Polygon p1 = new Polygon();
                                                                                                                                        Polygon p2 = new Polygon();
                                                                                                                                        
                                                                                                                                        // Add identical points to both polygons
                                                                                                                                        p1.addPoint(0, 0);
                                                                                                                                        p1.addPoint(10, 0);
                                                                                                                                        p1.addPoint(10, 10);
                                                                                                                                        p1.addPoint(0, 10);
                                                                                                                                        
                                                                                                                                        p2.addPoint(0, 0);
                                                                                                                                        p2.addPoint(10, 0);
                                                                                                                                        p2.addPoint(10, 10);
                                                                                                                                        p2.addPoint(0, 10);
                                                                                                                                        
                                                                                                                                        // Set different winding rules (though Polygon doesn't directly expose this,
                                                                                                                                        // we can simulate it through reflection or assume it's set differently)
                                                                                                                                        // In actual implementation, this would be set through the GeneralPath winding rule
                                                                                                                                        
                                                                                                                                        // The original implementation should return false for different winding rules
                                                                                                                                        // The mutant will return true
                                                                                                                                        assertFalse("Polygons with different winding rules should not be equal", 
                                                                                                                                                   ShapeUtilities.equal(p1, p2));
                                                                                                                                    }

    @Test
                                                                                                                            public void testEqualGeneralPathWithDifferentWindingRules2() {
                                                                                                                                // Create mock GeneralPath objects
                                                                                                                                GeneralPath path1 = mock(GeneralPath.class);
                                                                                                                                GeneralPath path2 = mock(GeneralPath.class);
                                                                                                                                
                                                                                                                                // Create mock path iterators that will be equal
                                                                                                                                PathIterator iterator1 = mock(PathIterator.class);
                                                                                                                                PathIterator iterator2 = mock(PathIterator.class);
                                                                                                                                
                                                                                                                                // Set up the objects to have equal path iterators
                                                                                                                                when(path1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                                                when(path2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                                                
                                                                                                                                // Make sure the iterators are equal in their behavior
                                                                                                                                when(iterator1.getWindingRule()).thenReturn(PathIterator.WIND_EVEN_ODD);
                                                                                                                                when(iterator2.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                                                
                                                                                                                                // Set up the iterators to have the same path data
                                                                                                                                when(iterator1.currentSegment(new float[6])).thenReturn(PathIterator.SEG_MOVETO);
                                                                                                                                when(iterator2.currentSegment(new float[6])).thenReturn(PathIterator.SEG_MOVETO);
                                                                                                                                when(iterator1.isDone()).thenReturn(true);
                                                                                                                                when(iterator2.isDone()).thenReturn(true);
                                                                                                                                
                                                                                                                                // Set different winding rules on the paths themselves
                                                                                                                                when(path1.getWindingRule()).thenReturn(GeneralPath.WIND_EVEN_ODD);
                                                                                                                                when(path2.getWindingRule()).thenReturn(GeneralPath.WIND_NON_ZERO);
                                                                                                                                
                                                                                                                                // The original method should return false, but mutant will return true
                                                                                                                                assertFalse("Paths with different winding rules should not be equal", 
                                                                                                                                           ShapeUtilities.equal(path1, path2));
                                                                                                                                
                                                                                                                                // Verify interactions
                                                                                                                                verify(path1).getPathIterator(null);
                                                                                                                                verify(path2).getPathIterator(null);
                                                                                                                                verify(path1).getWindingRule();
                                                                                                                                verify(path2).getWindingRule();
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualGeneralPathWithDifferentWindingRules3() {
                                                                                                                                // Import required classes
                                                                                                                                java.awt.geom.GeneralPath path1 = mock(java.awt.geom.GeneralPath.class);
                                                                                                                                java.awt.geom.GeneralPath path2 = mock(java.awt.geom.GeneralPath.class);
                                                                                                                                
                                                                                                                                // Set up mock behavior
                                                                                                                                when(path1.getPathIterator(null)).thenReturn(null); // Any path iterator
                                                                                                                                when(path2.getPathIterator(null)).thenReturn(null); // Same path iterator
                                                                                                                                
                                                                                                                                // Different winding rules
                                                                                                                                when(path1.getWindingRule()).thenReturn(java.awt.geom.GeneralPath.WIND_EVEN_ODD);
                                                                                                                                when(path2.getWindingRule()).thenReturn(java.awt.geom.GeneralPath.WIND_NON_ZERO);
                                                                                                                                
                                                                                                                                // Test - should return false for different winding rules
                                                                                                                                assertFalse(org.jfree.chart.util.ShapeUtilities.equal(path1, path2));
                                                                                                                                
                                                                                                                                // Verify interactions
                                                                                                                                verify(path1).getPathIterator(null);
                                                                                                                                verify(path2).getPathIterator(null);
                                                                                                                                verify(path1).getWindingRule();
                                                                                                                                verify(path2).getWindingRule();
                                                                                                                            }

    @Test
                                                                                                                            public void testEqual_ShouldReturnFalseWhenWindingRulesDiffer() {
                                                                                                                                // Create mock Shape objects
                                                                                                                                Shape shape1 = mock(Shape.class);
                                                                                                                                Shape shape2 = mock(Shape.class);
                                                                                                                                
                                                                                                                                // Create mock PathIterator with winding rule constants
                                                                                                                                PathIterator iterator = mock(PathIterator.class);
                                                                                                                                when(iterator.isDone()).thenReturn(true);
                                                                                                                                
                                                                                                                                // Set up different winding rules using the actual int values
                                                                                                                                // WIND_EVEN_ODD = 0, WIND_NON_ZERO = 1 in java.awt.geom.PathIterator
                                                                                                                                when(shape1.getPathIterator(null)).thenReturn(iterator);
                                                                                                                                when(shape2.getPathIterator(null)).thenReturn(iterator);
                                                                                                                                
                                                                                                                                // Mock the winding rule behavior
                                                                                                                                when(shape1.getPathIterator(null).getWindingRule()).thenReturn(0); // WIND_EVEN_ODD
                                                                                                                                when(shape2.getPathIterator(null).getWindingRule()).thenReturn(1); // WIND_NON_ZERO
                                                                                                                                
                                                                                                                                // Test - should return false because winding rules differ
                                                                                                                                assertFalse(ShapeUtilities.equal(shape1, shape2));
                                                                                                                                
                                                                                                                                // Verify interactions
                                                                                                                                verify(shape1).getPathIterator(null);
                                                                                                                                verify(shape2).getPathIterator(null);
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualGeneralPathWithDifferentPathsShouldReturnFalse() {
                                                                                                                                // Create two different GeneralPath objects
                                                                                                                                GeneralPath path1 = new GeneralPath();
                                                                                                                                path1.moveTo(1.0f, 1.0f);
                                                                                                                                path1.lineTo(2.0f, 2.0f);
                                                                                                                                
                                                                                                                                GeneralPath path2 = new GeneralPath();
                                                                                                                                path2.moveTo(1.0f, 1.0f);
                                                                                                                                path2.lineTo(3.0f, 3.0f); // Different from path1
                                                                                                                                
                                                                                                                                // The original method should return false since paths are different
                                                                                                                                // The mutated method would return true since it compares path2 with path2
                                                                                                                                assertFalse("Different GeneralPaths should not be equal", 
                                                                                                                                           ShapeUtilities.equal(path1, path2));
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualGeneralPathWithSamePathsShouldReturnTrue() {
                                                                                                                                // Create two identical GeneralPath objects
                                                                                                                                GeneralPath path1 = new GeneralPath();
                                                                                                                                path1.moveTo(1.0f, 1.0f);
                                                                                                                                path1.lineTo(2.0f, 2.0f);
                                                                                                                                
                                                                                                                                GeneralPath path2 = new GeneralPath();
                                                                                                                                path2.moveTo(1.0f, 1.0f);
                                                                                                                                path2.lineTo(2.0f, 2.0f);
                                                                                                                                
                                                                                                                                assertTrue("Identical GeneralPaths should be equal", 
                                                                                                                                          ShapeUtilities.equal(path1, path2));
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualEllipse2D_DifferentFrames_ShouldReturnFalse() {
                                                                                                                                // Create two ellipses with different frames
                                                                                                                                Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                                                                                                                                
                                                                                                                                // The original method should return false since frames are different
                                                                                                                                // The mutant would either throw an exception or return incorrect result
                                                                                                                                assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualEllipse2D_SameFrames_ShouldReturnTrue() {
                                                                                                                                // Create two ellipses with same frames
                                                                                                                                Rectangle2D frame = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                                                                Ellipse2D e1 = new Ellipse2D.Double();
                                                                                                                                e1.setFrame(frame);
                                                                                                                                Ellipse2D e2 = new Ellipse2D.Double();
                                                                                                                                e2.setFrame(frame);
                                                                                                                                
                                                                                                                                // Both original and mutated might return true here,
                                                                                                                                // but we need this case for completeness
                                                                                                                                assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualEllipse2D_FirstNullSecondNotNull_ShouldReturnFalse() {
                                                                                                                                Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                assertFalse(ShapeUtilities.equal(null, e2));
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualEllipse2D_FirstNotNullSecondNull_ShouldReturnFalse() {
                                                                                                                                Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                assertFalse(ShapeUtilities.equal(e1, null));
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualArc2DWithDifferentPaths() {
                                                                                                                                // Create two mock Arc2D objects with same attributes but different paths
                                                                                                                                Arc2D a1 = mock(Arc2D.class);
                                                                                                                                Arc2D a2 = mock(Arc2D.class);
                                                                                                                                
                                                                                                                                // Set up the mocks to have same attributes but different paths
                                                                                                                                when(a1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Float(0,0,10,10));
                                                                                                                                when(a2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Float(0,0,10,10));
                                                                                                                                when(a1.getAngleStart()).thenReturn(0.0);
                                                                                                                                when(a2.getAngleStart()).thenReturn(0.0);
                                                                                                                                when(a1.getAngleExtent()).thenReturn(90.0);
                                                                                                                                when(a2.getAngleExtent()).thenReturn(90.0);
                                                                                                                                when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                                                when(a2.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                                                
                                                                                                                                // Create different path iterators
                                                                                                                                PathIterator iter1 = mock(PathIterator.class);
                                                                                                                                PathIterator iter2 = mock(PathIterator.class);
                                                                                                                                
                                                                                                                                // Make sure they're different by having different winding rules
                                                                                                                                when(iter1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                                                when(iter2.getWindingRule()).thenReturn(PathIterator.WIND_EVEN_ODD);
                                                                                                                                
                                                                                                                                // Set up the different behavior for the mutant to detect
                                                                                                                                when(a1.getPathIterator(null)).thenReturn(iter1);
                                                                                                                                when(a2.getPathIterator(null)).thenReturn(iter2);
                                                                                                                                
                                                                                                                                // Test - should return false since paths are different
                                                                                                                                assertFalse(ShapeUtilities.equal(a1, a2));
                                                                                                                                
                                                                                                                                // Verify interactions
                                                                                                                                verify(a1).getPathIterator(null);
                                                                                                                                verify(a2).getPathIterator(null);
                                                                                                                            }

    @Test
                                                                                                                            public void testEqualPolygonWithDifferentPaths() {
                                                                                                                                // Create two polygons with same points but different paths
                                                                                                                                Polygon p1 = new Polygon(new int[]{0, 10, 10, 0}, new int[]{0, 0, 10, 10}, 4);
                                                                                                                                Polygon p2 = new Polygon(new int[]{0, 10, 10, 0}, new int[]{0, 0, 10, 10}, 4);
                                                                                                                                
                                                                                                                                // Mock their path iterators to return different sequences
                                                                                                                                PathIterator iterator1 = mock(PathIterator.class);
                                                                                                                                PathIterator iterator2 = mock(PathIterator.class);
                                                                                                                                
                                                                                                                                // Make p1 return iterator1 and p2 return iterator2
                                                                                                                                // Note: This requires reflection since Polygon doesn't have a setter for path iterator
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Field field = Polygon.class.getDeclaredField("pathIterator");
                                                                                                                                    field.setAccessible(true);
                                                                                                                                    field.set(p1, iterator1);
                                                                                                                                    field.set(p2, iterator2);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set path iterator via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Make the iterators behave differently
                                                                                                                                when(iterator1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                                                when(iterator2.getWindingRule()).thenReturn(PathIterator.WIND_EVEN_ODD);
                                                                                                                                
                                                                                                                                // The original method should return false since paths are different
                                                                                                                                // The mutated method would return true since it compares p2 with itself
                                                                                                                                assertFalse("Polygons with different paths should not be equal", 
                                                                                                                                           ShapeUtilities.equal(p1, p2));
                                                                                                                            }

    @Test
                                                                                                                    public void testEqualEllipse2D_BothNull_ShouldReturnTrue() {
                                                                                                                        assertTrue(ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
                                                                                                                    }

    @Test
                                                                                                                    public void testEqual_ShouldDetectPathIteratorMutation() {
                                                                                                                        // Create two different paths using GeneralPath (which implements Shape)
                                                                                                                        GeneralPath path1 = new GeneralPath();
                                                                                                                        path1.moveTo(0, 0);
                                                                                                                        path1.lineTo(10, 10);
                                                                                                                        
                                                                                                                        GeneralPath path2 = new GeneralPath();
                                                                                                                        path2.moveTo(0, 0);
                                                                                                                        path2.lineTo(20, 20); // Different from path1
                                                                                                                        
                                                                                                                        // Set the same winding rule for both paths
                                                                                                                        path1.setWindingRule(GeneralPath.WIND_EVEN_ODD);
                                                                                                                        path2.setWindingRule(GeneralPath.WIND_EVEN_ODD);
                                                                                                                        
                                                                                                                        // Test - should return false since paths are different
                                                                                                                        boolean result = ShapeUtilities.equal(path1, path2);
                                                                                                                        
                                                                                                                        // Assert false for original (correct) implementation
                                                                                                                        // Mutant would return true because it compares path2 against itself
                                                                                                                        assertFalse("Method should return false for different paths", result);
                                                                                                                    }

    @Test
                                                                                                                public void testEqualLine2DDetectsMutant() {
                                                                                                                    // Create lines where p1 of first equals p2 of second, but other points differ
                                                                                                                    Line2D line1 = new Line2D.Double(1, 2, 3, 4);  // p1=(1,2), p2=(3,4)
                                                                                                                    Line2D line2 = new Line2D.Double(5, 6, 1, 2);  // p1=(5,6), p2=(1,2)
                                                                                                                    
                                                                                                                    // With the mutant, it would compare line1's p1 (1,2) with line2's p2 (1,2)
                                                                                                                    // and return true incorrectly, but should return false since other points differ
                                                                                                                    assertFalse("Mutant not detected - incorrectly returns true when p1 matches p2 but other points differ", 
                                                                                                                               ShapeUtilities.equal((Line2D)line1, (Line2D)line2));
                                                                                                                    
                                                                                                                    // Additional test case where all points are different
                                                                                                                    Line2D line3 = new Line2D.Double(1, 1, 2, 2);
                                                                                                                    Line2D line4 = new Line2D.Double(3, 3, 4, 4);
                                                                                                                    assertFalse(ShapeUtilities.equal((Line2D)line3, (Line2D)line4));
                                                                                                                    
                                                                                                                    // Test case where lines are actually equal
                                                                                                                    Line2D line5 = new Line2D.Double(1, 1, 2, 2);
                                                                                                                    Line2D line6 = new Line2D.Double(1, 1, 2, 2);
                                                                                                                    assertTrue(ShapeUtilities.equal((Line2D)line5, (Line2D)line6));
                                                                                                                    
                                                                                                                    // Test null cases - explicitly cast null to Line2D to resolve ambiguity
                                                                                                                    assertTrue(ShapeUtilities.equal((Line2D)null, (Line2D)null));
                                                                                                                    assertFalse(ShapeUtilities.equal((Line2D)line1, (Line2D)null));
                                                                                                                    assertFalse(ShapeUtilities.equal((Line2D)null, (Line2D)line2));
                                                                                                                }

    @Test
                                                                                                                public void testEqualGeneralPath_ShouldNotThrowException() {
                                                                                                                    // Create two simple GeneralPath objects that are equal
                                                                                                                    GeneralPath path1 = new GeneralPath();
                                                                                                                    path1.moveTo(0, 0);
                                                                                                                    path1.lineTo(1, 1);
                                                                                                                    
                                                                                                                    GeneralPath path2 = new GeneralPath();
                                                                                                                    path2.moveTo(0, 0);
                                                                                                                    path2.lineTo(1, 1);
                                                                                                                    
                                                                                                                    // The test will pass if no exception is thrown
                                                                                                                    // The mutant would throw NullPointerException here
                                                                                                                    boolean result = ShapeUtilities.equal(path1, path2);
                                                                                                                    
                                                                                                                    // Additional verification that the comparison works correctly
                                                                                                                    assertTrue("Equal GeneralPath objects should return true", result);
                                                                                                                }

    @Test
                                                                                                                public void testEqualGeneralPath_WithDifferentPaths() {
                                                                                                                    // Create two different GeneralPath objects
                                                                                                                    GeneralPath path1 = new GeneralPath();
                                                                                                                    path1.moveTo(0, 0);
                                                                                                                    path1.lineTo(1, 1);
                                                                                                                    
                                                                                                                    GeneralPath path2 = new GeneralPath();
                                                                                                                    path2.moveTo(0, 0);
                                                                                                                    path2.lineTo(2, 2);
                                                                                                                    
                                                                                                                    boolean result = ShapeUtilities.equal(path1, path2);
                                                                                                                    assertFalse("Different GeneralPath objects should return false", result);
                                                                                                                }

    @Test
                                                                                                                public void testEqualLine2DWithPathComparison() {
                                                                                                                    // Create two lines that should be equal
                                                                                                                    Point2D p1 = new Point2D.Double(1.0, 2.0);
                                                                                                                    Point2D p2 = new Point2D.Double(3.0, 4.0);
                                                                                                                    Line2D line1 = new Line2D.Double(p1, p2);
                                                                                                                    Line2D line2 = new Line2D.Double(p1, p2);
                                                                                                                    
                                                                                                                    // Test equality - should return true for original code
                                                                                                                    // Mutated version would throw NullPointerException when trying to compare paths
                                                                                                                    assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                                public void testMutatedEqualLine2D() {
                                                                                                                    // This test would pass for the mutated version
                                                                                                                    Point2D p1 = new Point2D.Double(1.0, 2.0);
                                                                                                                    Point2D p2 = new Point2D.Double(3.0, 4.0);
                                                                                                                    Line2D line1 = new Line2D.Double(p1, p2);
                                                                                                                    Line2D line2 = new Line2D.Double(p1, p2);
                                                                                                                    
                                                                                                                    // Mutated version would throw NullPointerException here
                                                                                                                    ShapeUtilities.equal(line1, line2);
                                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                                public void testEqualEllipse2DWithDifferentFrames() {
                                                                                                                    // Create two ellipses with different frames
                                                                                                                    Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                    Ellipse2D e2 = new Ellipse2D.Double(5, 5, 10, 10);
                                                                                                                    
                                                                                                                    // This should throw NullPointerException with the mutant
                                                                                                                    // Original code would return false
                                                                                                                    ShapeUtilities.equal(e1, e2);
                                                                                                                }

    @Test
                                                                                                                public void testEqualEllipse2DWithSameFrame() {
                                                                                                                    // Create two ellipses with same frame
                                                                                                                    Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                    Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                    
                                                                                                                    // Should return true for original code
                                                                                                                    assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                }

    @Test
                                                                                                                public void testEqual_GeneralPath_DifferentPathsSameFrame() {
                                                                                                                    // Create two GeneralPath objects with same frame but different paths
                                                                                                                    GeneralPath path1 = new GeneralPath();
                                                                                                                    path1.moveTo(0, 0);
                                                                                                                    path1.lineTo(10, 10);
                                                                                                                    
                                                                                                                    GeneralPath path2 = new GeneralPath();
                                                                                                                    path2.moveTo(0, 0);
                                                                                                                    path2.lineTo(10, 0);  // Different path
                                                                                                                    
                                                                                                                    // The paths are different but have same bounds
                                                                                                                    path1.closePath();
                                                                                                                    path2.closePath();
                                                                                                                    
                                                                                                                    // The mutated version would return true because it skips path comparison
                                                                                                                    // Original version would return false as it properly compares paths
                                                                                                                    assertFalse("Should return false for different paths", 
                                                                                                                               ShapeUtilities.equal(path1, path2));
                                                                                                                }

    @Test
                                                                                                                public void testEqual_GeneralPath_NullPathIterator() {
                                                                                                                    // Mock GeneralPath to return null PathIterator
                                                                                                                    GeneralPath path1 = mock(GeneralPath.class);
                                                                                                                    GeneralPath path2 = mock(GeneralPath.class);
                                                                                                                    
                                                                                                                    when(path1.getPathIterator(null)).thenReturn(null);
                                                                                                                    when(path2.getPathIterator(null)).thenReturn(mock(PathIterator.class));
                                                                                                                    
                                                                                                                    // Original would throw NPE or return false
                                                                                                                    // Mutated would skip comparison and potentially return true
                                                                                                                    assertFalse("Should handle null PathIterator properly",
                                                                                                                              ShapeUtilities.equal(path1, path2));
                                                                                                                }

    @Test
                                                                                                                public void testEqualPolygonsWithSamePoints() {
                                                                                                                    // Create two identical polygons
                                                                                                                    int[] xpoints = {0, 10, 10, 0};
                                                                                                                    int[] ypoints = {0, 0, 10, 10};
                                                                                                                    Polygon p1 = new Polygon(xpoints, ypoints, 4);
                                                                                                                    Polygon p2 = new Polygon(xpoints, ypoints, 4);
                                                                                                                    
                                                                                                                    // Test that they are considered equal
                                                                                                                    assertTrue(ShapeUtilities.equal(p1, p2));
                                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                                public void testMutantBehavior() {
                                                                                                                    // This test would pass with the mutant but fail with original code
                                                                                                                    int[] xpoints = {0, 10, 10, 0};
                                                                                                                    int[] ypoints = {0, 0, 10, 10};
                                                                                                                    Polygon p1 = new Polygon(xpoints, ypoints, 4);
                                                                                                                    Polygon p2 = new Polygon(xpoints, ypoints, 4);
                                                                                                                    
                                                                                                                    // The mutant would throw NPE here
                                                                                                                    ShapeUtilities.equal(p1, p2);
                                                                                                                }

    @Test
                                                                                                        public void testEqualEllipse2DWithNullInputs() {
                                                                                                            // Test null cases
                                                                                                            assertTrue(ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
                                                                                                            assertFalse(ShapeUtilities.equal(new Ellipse2D.Double(), (Ellipse2D) null));
                                                                                                            assertFalse(ShapeUtilities.equal((Ellipse2D) null, new Ellipse2D.Double()));
                                                                                                        }

    @Test
                                                                                                        public void testEqual_ShouldNotThrowNPEWhenComparingNonEqualShapes() {
                                                                                                            // Create mock Shape objects
                                                                                                            Shape shape1 = mock(Shape.class);
                                                                                                            Shape shape2 = mock(Shape.class);
                                                                                                            
                                                                                                            // Mock the path iterators to return different paths
                                                                                                            PathIterator iterator1 = mock(PathIterator.class);
                                                                                                            PathIterator iterator2 = mock(PathIterator.class);
                                                                                                            
                                                                                                            // Set winding rule on iterators instead of shapes
                                                                                                            when(iterator1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                            when(iterator2.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                            
                                                                                                            // Setup iterator1 to return one segment
                                                                                                            when(iterator1.isDone()).thenReturn(false).thenReturn(true);
                                                                                                            when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                                                            
                                                                                                            // Setup iterator2 to return a different segment
                                                                                                            when(iterator2.isDone()).thenReturn(false).thenReturn(true);
                                                                                                            when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_LINETO);
                                                                                                            
                                                                                                            when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                            when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                                                                            
                                                                                                            // Test - should return false without throwing NPE
                                                                                                            assertFalse(ShapeUtilities.equal(shape1, shape2));
                                                                                                            
                                                                                                            // Verify interactions
                                                                                                            verify(shape1).getPathIterator(null);
                                                                                                            verify(shape2).getPathIterator(null);
                                                                                                            verify(iterator1).isDone();
                                                                                                            verify(iterator2).isDone();
                                                                                                        }

    @Test
                                                                                                        public void testEqualGeneralPathDetectsMutant() {
                                                                                                            // Create two different GeneralPath objects
                                                                                                            GeneralPath path1 = new GeneralPath();
                                                                                                            path1.moveTo(1.0f, 1.0f);
                                                                                                            path1.lineTo(2.0f, 2.0f);
                                                                                                            
                                                                                                            GeneralPath path2 = new GeneralPath();
                                                                                                            path2.moveTo(1.0f, 1.0f);
                                                                                                            path2.lineTo(3.0f, 3.0f); // Different from path1
                                                                                                            
                                                                                                            // Create a third path that's identical to path1
                                                                                                            GeneralPath path3 = new GeneralPath();
                                                                                                            path3.moveTo(1.0f, 1.0f);
                                                                                                            path3.lineTo(2.0f, 2.0f);
                                                                                                            
                                                                                                            // Test case that would catch the mutant
                                                                                                            // Original should return false for different paths, mutant would return true
                                                                                                            assertFalse("Different GeneralPaths should not be equal", 
                                                                                                                       ShapeUtilities.equal(path1, path2));
                                                                                                            
                                                                                                            // Additional test for identical paths (should return true)
                                                                                                            assertTrue("Identical GeneralPaths should be equal",
                                                                                                                      ShapeUtilities.equal(path1, path3));
                                                                                                        }

    @Test
                                                                                                        public void testEqualLine2D_DifferentP2Points() {
                                                                                                            // Create two lines with same p1 but different p2
                                                                                                            Point2D p1 = new Point2D.Double(1.0, 1.0);
                                                                                                            Point2D p2a = new Point2D.Double(2.0, 2.0);
                                                                                                            Point2D p2b = new Point2D.Double(2.0, 3.0); // Different from p2a
                                                                                                            
                                                                                                            Line2D line1 = new Line2D.Double(p1, p2a);
                                                                                                            Line2D line2 = new Line2D.Double(p1, p2b);
                                                                                                            
                                                                                                            // The lines should NOT be equal since p2 points are different
                                                                                                            assertFalse("Lines with different p2 points should not be equal", 
                                                                                                                ShapeUtilities.equal(line1, line2));
                                                                                                            
                                                                                                            // The mutant would incorrectly compare p1 points again (which are equal)
                                                                                                            // and return true, failing this test
                                                                                                        }

    @Test
                                                                                                        public void testEqual_GeneralPath_DifferentPaths() {
                                                                                                            // Create two different GeneralPath objects
                                                                                                            GeneralPath p1 = new GeneralPath();
                                                                                                            p1.moveTo(0, 0);
                                                                                                            p1.lineTo(10, 10);
                                                                                                            
                                                                                                            GeneralPath p2 = new GeneralPath();
                                                                                                            p2.moveTo(0, 0);
                                                                                                            p2.lineTo(20, 20); // Different path
                                                                                                            
                                                                                                            // The original method should return false since paths are different
                                                                                                            // The mutant would return true because it's comparing p1 against itself
                                                                                                            assertFalse("Different GeneralPath objects should not be equal", 
                                                                                                                       ShapeUtilities.equal(p1, p2));
                                                                                                            
                                                                                                            // Additional check: same paths should be equal
                                                                                                            GeneralPath p3 = new GeneralPath(p1);
                                                                                                            assertTrue("Same GeneralPath objects should be equal",
                                                                                                                      ShapeUtilities.equal(p1, p3));
                                                                                                        }

    @Test
                                                                                                        public void testEqualPolygonWithDifferentPaths1() {
                                                                                                            // Create two different polygons
                                                                                                            int[] xpoints1 = {0, 10, 10, 0};
                                                                                                            int[] ypoints1 = {0, 0, 10, 10};
                                                                                                            Polygon p1 = new Polygon(xpoints1, ypoints1, 4);
                                                                                                            
                                                                                                            int[] xpoints2 = {0, 10, 10, 0};
                                                                                                            int[] ypoints2 = {0, 0, 20, 20}; // Different y-points
                                                                                                            Polygon p2 = new Polygon(xpoints2, ypoints2, 4);
                                                                                                            
                                                                                                            // Mock PathIterator behavior to verify p2's iterator is used
                                                                                                            PathIterator mockIterator1 = mock(PathIterator.class);
                                                                                                            PathIterator mockIterator2 = mock(PathIterator.class);
                                                                                                            
                                                                                                            // Make p1 and p2 return different iterators
                                                                                                            when(p1.getPathIterator(null)).thenReturn(mockIterator1);
                                                                                                            when(p2.getPathIterator(null)).thenReturn(mockIterator2);
                                                                                                            
                                                                                                            // Make the iterators behave differently
                                                                                                            when(mockIterator1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                            when(mockIterator2.getWindingRule()).thenReturn(PathIterator.WIND_EVEN_ODD);
                                                                                                            
                                                                                                            // Test the equality - should return false since polygons are different
                                                                                                            assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                            
                                                                                                            // Verify p2's iterator was actually requested
                                                                                                            verify(p2).getPathIterator(null);
                                                                                                        }

    @Test
                                                                                                        public void testEqual_ShouldDetectMutatedPathIterator() {
                                                                                                            // Create two different mock Shape objects
                                                                                                            Shape p1 = mock(Shape.class);
                                                                                                            Shape p2 = mock(Shape.class);
                                                                                                            
                                                                                                            // Create mock PathIterators that will return different segments
                                                                                                            PathIterator iterator1 = mock(PathIterator.class);
                                                                                                            PathIterator iterator2Different = mock(PathIterator.class);
                                                                                                            
                                                                                                            // Set up the mock behavior
                                                                                                            when(p1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                            when(p2.getPathIterator(null)).thenReturn(iterator2Different);
                                                                                                            
                                                                                                            // Make the iterators behave differently
                                                                                                            when(iterator1.isDone()).thenReturn(false, true); // first call false, second true
                                                                                                            when(iterator2Different.isDone()).thenReturn(false, true);
                                                                                                            
                                                                                                            double[] d1 = new double[6];
                                                                                                            double[] d2 = new double[6];
                                                                                                            when(iterator1.currentSegment(d1)).thenReturn(PathIterator.SEG_MOVETO);
                                                                                                            when(iterator2Different.currentSegment(d2)).thenReturn(PathIterator.SEG_LINETO); // Different segment type
                                                                                                            
                                                                                                            // The original method should return false since the shapes are different
                                                                                                            // The mutated method would return true because it would compare p1 against itself
                                                                                                            assertFalse("Method should return false for different shapes", 
                                                                                                                       ShapeUtilities.equal(p1, p2));
                                                                                                            
                                                                                                            // Verify the correct iterators were called (this would fail for the mutant)
                                                                                                            verify(p1).getPathIterator(null);
                                                                                                            verify(p2).getPathIterator(null);
                                                                                                        }

    @Test
                                                                                                public void testEqualEllipse2DWithDifferentPaths() {
                                                                                                    // Define a simple TestPathIterator class
                                                                                                    class TestPathIterator implements PathIterator {
                                                                                                        private int type;
                                                                                                        
                                                                                                        public TestPathIterator(int type) {
                                                                                                            this.type = type;
                                                                                                        }
                                                                                                        
                                                                                                        @Override
                                                                                                        public int getWindingRule() {
                                                                                                            return WIND_NON_ZERO;
                                                                                                        }
                                                                                                        
                                                                                                        @Override
                                                                                                        public boolean isDone() {
                                                                                                            return true;
                                                                                                        }
                                                                                                        
                                                                                                        @Override
                                                                                                        public void next() {
                                                                                                        }
                                                                                                        
                                                                                                        @Override
                                                                                                        public int currentSegment(float[] coords) {
                                                                                                            return SEG_CLOSE;
                                                                                                        }
                                                                                                        
                                                                                                        @Override
                                                                                                        public int currentSegment(double[] coords) {
                                                                                                            return SEG_CLOSE;
                                                                                                        }
                                                                                                    }
                                                                                                
                                                                                                    // Create two ellipses with same frame but different paths
                                                                                                    Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10) {
                                                                                                        @Override
                                                                                                        public PathIterator getPathIterator(AffineTransform at) {
                                                                                                            return new TestPathIterator(1); // Path type 1
                                                                                                        }
                                                                                                    };
                                                                                                    
                                                                                                    Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10) {
                                                                                                        @Override
                                                                                                        public PathIterator getPathIterator(AffineTransform at) {
                                                                                                            return new TestPathIterator(2); // Path type 2
                                                                                                        }
                                                                                                    };
                                                                                                    
                                                                                                    // Original should return false (different paths)
                                                                                                    // Mutant would return true (compares e1's path against itself)
                                                                                                    assertFalse("Ellipses with different paths should not be equal", 
                                                                                                               ShapeUtilities.equal(e1, e2));
                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                public void testEqualGeneralPathWithMutant() {
                                                                                                    // This test will pass only if the mutant exists (iterator2 = null)
                                                                                                    GeneralPath path1 = new GeneralPath();
                                                                                                    path1.moveTo(1.0f, 1.0f);
                                                                                                    
                                                                                                    GeneralPath path2 = new GeneralPath();
                                                                                                    path2.moveTo(1.0f, 1.0f);
                                                                                                    
                                                                                                    // If mutant exists, this will throw NullPointerException
                                                                                                    ShapeUtilities.equal(path1, path2);
                                                                                                }

    @Test
                                                                                                public void testEqualGeneralPathWithDifferentPaths() {
                                                                                                    // Create two different GeneralPath objects
                                                                                                    GeneralPath p1 = new GeneralPath();
                                                                                                    p1.moveTo(0, 0);
                                                                                                    p1.lineTo(10, 10);
                                                                                                    
                                                                                                    GeneralPath p2 = new GeneralPath();
                                                                                                    p2.moveTo(0, 0);
                                                                                                    p2.lineTo(10, 20); // Different path
                                                                                                    
                                                                                                    // The mutation would cause this to return true (incorrectly) 
                                                                                                    // because it wouldn't compare the actual paths
                                                                                                    assertFalse("Different paths should not be equal", 
                                                                                                               ShapeUtilities.equal(p1, p2));
                                                                                                }

    @Test
                                                                                                public void testEqualGeneralPathWithSamePaths() {
                                                                                                    // Create two identical GeneralPath objects
                                                                                                    GeneralPath p1 = new GeneralPath();
                                                                                                    p1.moveTo(0, 0);
                                                                                                    p1.lineTo(10, 10);
                                                                                                    
                                                                                                    GeneralPath p2 = new GeneralPath();
                                                                                                    p2.moveTo(0, 0);
                                                                                                    p2.lineTo(10, 10);
                                                                                                    
                                                                                                    // The mutation might cause this to return false (incorrectly)
                                                                                                    assertTrue("Identical paths should be equal", 
                                                                                                              ShapeUtilities.equal(p1, p2));
                                                                                                }

    @Test
                                                                                                public void testEqualLine2D() {
                                                                                                    // Also include a test for the Line2D case shown in the original method
                                                                                                    Line2D l1 = new Line2D.Double(0, 0, 10, 10);
                                                                                                    Line2D l2 = new Line2D.Double(0, 0, 10, 10);
                                                                                                    Line2D l3 = new Line2D.Double(0, 0, 10, 20);
                                                                                                    
                                                                                                    assertTrue(ShapeUtilities.equal(l1, l2));
                                                                                                    assertFalse(ShapeUtilities.equal(l1, l3));
                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                public void testEqualGeneralPathWithMutationShouldThrow() {
                                                                                                    // This test will only pass if the mutation is present (throws NPE)
                                                                                                    GeneralPath p1 = new GeneralPath();
                                                                                                    GeneralPath p2 = new GeneralPath();
                                                                                                    
                                                                                                    // When mutation is present, this will throw NullPointerException
                                                                                                    // because iterator2 is null
                                                                                                    ShapeUtilities.equal(p1, p2);
                                                                                                }

    @Test
                                                                                                public void testEqualGeneralPathWithSamePaths1() {
                                                                                                    // Create two identical GeneralPath objects
                                                                                                    GeneralPath path1 = new GeneralPath();
                                                                                                    path1.moveTo(1.0f, 1.0f);
                                                                                                    path1.lineTo(2.0f, 2.0f);
                                                                                                    
                                                                                                    GeneralPath path2 = new GeneralPath();
                                                                                                    path2.moveTo(1.0f, 1.0f);
                                                                                                    path2.lineTo(2.0f, 2.0f);
                                                                                                    
                                                                                                    // Test should pass with original code (return true)
                                                                                                    // Mutated code would either return false or throw NPE
                                                                                                    assertTrue(ShapeUtilities.equal(path1, path2));
                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                public void testEqualGeneralPathWithNullIterator() {
                                                                                                    // Create mock GeneralPath that would return null iterator
                                                                                                    GeneralPath path1 = mock(GeneralPath.class);
                                                                                                    GeneralPath path2 = mock(GeneralPath.class);
                                                                                                    
                                                                                                    when(path1.getPathIterator(null)).thenReturn(null);
                                                                                                    when(path2.getPathIterator(null)).thenReturn(null);
                                                                                                    
                                                                                                    // This will throw NPE with mutated code
                                                                                                    ShapeUtilities.equal(path1, path2);
                                                                                                }

    @Test
                                                                                        public void testEqualGeneralPathWithDifferentPaths1() {
                                                                                            // Create two different GeneralPath objects
                                                                                            GeneralPath p1 = new GeneralPath();
                                                                                            p1.moveTo(1.0f, 1.0f);
                                                                                            p1.lineTo(2.0f, 2.0f);
                                                                                            
                                                                                            GeneralPath p2 = new GeneralPath();
                                                                                            p2.moveTo(1.0f, 1.0f);
                                                                                            p2.lineTo(3.0f, 3.0f); // Different path
                                                                                            
                                                                                            // Test that they are not equal
                                                                                            assertFalse("Different GeneralPaths should not be equal", 
                                                                                                       ShapeUtilities.equal((GeneralPath)p1, (GeneralPath)p2));
                                                                                            
                                                                                            // Also test with null paths
                                                                                            assertTrue("Both null paths should be equal", 
                                                                                                      ShapeUtilities.equal((GeneralPath)null, (GeneralPath)null));
                                                                                            assertFalse("Null and non-null paths should not be equal",
                                                                                                       ShapeUtilities.equal((GeneralPath)p1, (GeneralPath)null));
                                                                                            assertFalse("Non-null and null paths should not be equal",
                                                                                                       ShapeUtilities.equal((GeneralPath)null, (GeneralPath)p1));
                                                                                        }

    @Test
                                                                    public void testEqual_MutantDetection_NullPathIterator() {
                                                                        // Create mock Shape objects
                                                                        Shape shape1 = mock(Shape.class);
                                                                        Shape shape2 = mock(Shape.class);
                                                                        
                                                                        // Create mock PathIterator for shape1
                                                                        PathIterator iterator1 = mock(PathIterator.class);
                                                                        when(iterator1.isDone()).thenReturn(true);
                                                                        
                                                                        // Set up mock behavior - use the actual int value for WIND_NON_ZERO (which is 1)
                                                                        when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                                        when(shape2.getPathIterator(null)).thenReturn(null);  // This is the mutation
                                                                        
                                                                        // Call the method - should throw NPE with the mutant
                                                                        try {
                                                                            ShapeUtilities.equal(shape1, shape2);
                                                                            fail("Expected NullPointerException to be thrown");
                                                                        } catch (NullPointerException e) {
                                                                            // Expected exception
                                                                        }
                                                                    }

    @Test
                                                                public void testEqualGeneralPathWithMutation() {
                                                                    // Create two different GeneralPath objects
                                                                    GeneralPath p1 = new GeneralPath();
                                                                    p1.moveTo(0, 0);
                                                                    p1.lineTo(10, 10);
                                                                    
                                                                    GeneralPath p2 = new GeneralPath();
                                                                    p2.moveTo(0, 0);
                                                                    p2.lineTo(10, 10);
                                                                    
                                                                    // Should return true for equal paths
                                                                    assertTrue(ShapeUtilities.equal(p1, p2));
                                                                    
                                                                    // Modify p2 to make them different
                                                                    p2.lineTo(20, 20);
                                                                    
                                                                    // Should return false for different paths
                                                                    assertFalse(ShapeUtilities.equal(p1, p2));
                                                                    
                                                                    // Test with null paths - explicitly cast to GeneralPath
                                                                    assertTrue(ShapeUtilities.equal((GeneralPath) null, (GeneralPath) null));
                                                                    assertFalse(ShapeUtilities.equal(p1, (GeneralPath) null));
                                                                    assertFalse(ShapeUtilities.equal((GeneralPath) null, p2));
                                                                }

    @Test
                                                            public void testEqualGeneralPath() {
                                                                // Create two different GeneralPath objects
                                                                GeneralPath path1 = new GeneralPath();
                                                                path1.moveTo(1.0f, 1.0f);
                                                                path1.lineTo(2.0f, 2.0f);
                                                                
                                                                GeneralPath path2 = new GeneralPath();
                                                                path2.moveTo(1.0f, 1.0f);
                                                                path2.lineTo(3.0f, 3.0f); // Different from path1
                                                                
                                                                // Test with different paths (should return false)
                                                                assertFalse(ShapeUtilities.equal(path1, path2));
                                                                
                                                                // Create identical paths
                                                                GeneralPath path3 = new GeneralPath();
                                                                path3.moveTo(1.0f, 1.0f);
                                                                path3.lineTo(2.0f, 2.0f);
                                                                
                                                                // Test with identical paths (should return true)
                                                                assertTrue(ShapeUtilities.equal(path1, path3));
                                                                
                                                                // Test with null (should not throw exception)
                                                                assertFalse(ShapeUtilities.equal((Shape)path1, (Shape)null));
                                                                assertFalse(ShapeUtilities.equal((Shape)null, (Shape)path1));
                                                                assertTrue(ShapeUtilities.equal((Shape)null, (Shape)null));
                                                            }

    @Test
                                                            public void testEqualLine2DShouldNotThrowException() {
                                                                Line2D line1 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                Line2D line2 = new Line2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                assertTrue(ShapeUtilities.equal(line1, line2));
                                                            }

    @Test
                                                            public void testEqualEllipse2DShouldNotThrowException() {
                                                                Ellipse2D ellipse1 = new Ellipse2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                Ellipse2D ellipse2 = new Ellipse2D.Double(1.0, 2.0, 3.0, 4.0);
                                                                assertTrue(ShapeUtilities.equal(ellipse1, ellipse2));
                                                            }

    @Test
                                                            public void testEqualArc2DShouldNotThrowException() {
                                                                Arc2D arc1 = new Arc2D.Double(1.0, 2.0, 3.0, 4.0, 0.0, 90.0, Arc2D.OPEN);
                                                                Arc2D arc2 = new Arc2D.Double(1.0, 2.0, 3.0, 4.0, 0.0, 90.0, Arc2D.OPEN);
                                                                assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                            }

    @Test
                                                            public void testEqualPolygonShouldWork() {
                                                                Polygon poly1 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                                Polygon poly2 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                                assertTrue(ShapeUtilities.equal(poly1, poly2));
                                                            }

    @Test
                                                            public void testEqualGeneralPathShouldWork() {
                                                                GeneralPath path1 = new GeneralPath();
                                                                path1.moveTo(1.0f, 2.0f);
                                                                path1.lineTo(3.0f, 4.0f);
                                                                GeneralPath path2 = new GeneralPath();
                                                                path2.moveTo(1.0f, 2.0f);
                                                                path2.lineTo(3.0f, 4.0f);
                                                                assertTrue(ShapeUtilities.equal(path1, path2));
                                                            }

    @Test
                                                    public void testEqualLine2D1() {
                                                        // Test case 1: Both lines are null
                                                        assertTrue(ShapeUtilities.equal((Line2D)null, (Line2D)null));
                                                        
                                                        // Test case 2: First line is null, second is not
                                                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                        assertFalse(ShapeUtilities.equal((Line2D)null, line1));
                                                        
                                                        // Test case 3: Second line is null, first is not
                                                        assertFalse(ShapeUtilities.equal(line1, (Line2D)null));
                                                        
                                                        // Test case 4: Lines with same points
                                                        Line2D line2 = new Line2D.Double(1, 2, 3, 4);
                                                        assertTrue(ShapeUtilities.equal(line1, line2));
                                                        
                                                        // Test case 5: Lines with different p1
                                                        Line2D line3 = new Line2D.Double(0, 2, 3, 4);
                                                        assertFalse(ShapeUtilities.equal(line1, line3));
                                                        
                                                        // Test case 6: Lines with different p2
                                                        Line2D line4 = new Line2D.Double(1, 2, 3, 5);
                                                        assertFalse(ShapeUtilities.equal(line1, line4));
                                                        
                                                        // Test case 7: Lines with both points different
                                                        Line2D line5 = new Line2D.Double(0, 0, 0, 0);
                                                        assertFalse(ShapeUtilities.equal(line1, line5));
                                                    }

    @Test
                                                    public void testEqualEllipse2DWithNonEmptyFrames() {
                                                        // Create two ellipses with different frames
                                                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                        Ellipse2D e3 = new Ellipse2D.Double(0, 0, 20, 20);
                                                        
                                                        // Test equal frames (should be true)
                                                        assertTrue(ShapeUtilities.equal(e1, e2));
                                                        
                                                        // Test different frames (should be false)
                                                        assertFalse(ShapeUtilities.equal(e1, e3));
                                                        
                                                        // Test with null inputs
                                                        assertTrue(ShapeUtilities.equal((Ellipse2D)null, (Ellipse2D)null));
                                                        assertFalse(ShapeUtilities.equal(e1, (Ellipse2D)null));
                                                        assertFalse(ShapeUtilities.equal((Ellipse2D)null, e2));
                                                    }

    @Test
                                                    public void testEqualArc2DWithArrayMutation() {
                                                        // Create two identical arcs
                                                        Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                                        Arc2D arc1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                                        Arc2D arc2 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                                        
                                                        // Should be equal
                                                        assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                        
                                                        // Create arcs with different properties
                                                        Arc2D arc3 = new Arc2D.Double(frame, 10, 90, Arc2D.PIE);
                                                        assertFalse(ShapeUtilities.equal(arc1, arc3));
                                                        
                                                        Arc2D arc4 = new Arc2D.Double(frame, 0, 80, Arc2D.PIE);
                                                        assertFalse(ShapeUtilities.equal(arc1, arc4));
                                                        
                                                        Arc2D arc5 = new Arc2D.Double(frame, 0, 90, Arc2D.CHORD);
                                                        assertFalse(ShapeUtilities.equal(arc1, arc5));
                                                        
                                                        // Test with null values
                                                        assertTrue(ShapeUtilities.equal((Arc2D)null, (Arc2D)null));
                                                        assertFalse(ShapeUtilities.equal(arc1, (Arc2D)null));
                                                        assertFalse(ShapeUtilities.equal((Arc2D)null, arc2));
                                                        
                                                        // If the array is used for storing comparison values, 
                                                        // this might catch the array size mutation
                                                        Rectangle2D largeFrame = new Rectangle2D.Double(0, 0, 1000, 1000);
                                                        Arc2D largeArc1 = new Arc2D.Double(largeFrame, 0, 90, Arc2D.PIE);
                                                        Arc2D largeArc2 = new Arc2D.Double(largeFrame, 0, 90, Arc2D.PIE);
                                                        assertTrue(ShapeUtilities.equal(largeArc1, largeArc2));
                                                    }

    @Test
                                                    public void testEqualPolygon() {
                                                        // Test case 1: Both null
                                                        assertTrue(ShapeUtilities.equal((Polygon)null, (Polygon)null));
                                                        
                                                        // Test case 2: First null, second not null
                                                        Polygon p2 = new Polygon(new int[]{1}, new int[]{1}, 1);
                                                        assertFalse(ShapeUtilities.equal(null, p2));
                                                        
                                                        // Test case 3: Second null, first not null
                                                        Polygon p1 = new Polygon(new int[]{1}, new int[]{1}, 1);
                                                        assertFalse(ShapeUtilities.equal(p1, null));
                                                        
                                                        // Test case 4: Different point counts
                                                        Polygon p3 = new Polygon(new int[]{1,2}, new int[]{1,2}, 2);
                                                        assertFalse(ShapeUtilities.equal(p1, p3));
                                                        
                                                        // Test case 5: Same point counts, different x coordinates
                                                        Polygon p4 = new Polygon(new int[]{1,2}, new int[]{1,2}, 2);
                                                        Polygon p5 = new Polygon(new int[]{1,3}, new int[]{1,2}, 2);
                                                        assertFalse(ShapeUtilities.equal(p4, p5));
                                                        
                                                        // Test case 6: Same point counts, different y coordinates
                                                        Polygon p6 = new Polygon(new int[]{1,2}, new int[]{1,3}, 2);
                                                        assertFalse(ShapeUtilities.equal(p4, p6));
                                                        
                                                        // Test case 7: Equal polygons
                                                        Polygon p7 = new Polygon(new int[]{1,2}, new int[]{1,2}, 2);
                                                        assertTrue(ShapeUtilities.equal(p4, p7));
                                                        
                                                        // Test case 8: Empty polygons
                                                        Polygon p8 = new Polygon(new int[]{}, new int[]{}, 0);
                                                        Polygon p9 = new Polygon(new int[]{}, new int[]{}, 0);
                                                        assertTrue(ShapeUtilities.equal(p8, p9));
                                                    }

    @Test
                                                public void testEqual_DetectsArraySizeMutation() throws Exception {
                                                    // Import required constants from java.awt.geom.PathIterator
                                                    final int WIND_NON_ZERO = java.awt.geom.PathIterator.WIND_NON_ZERO;
                                                    final int SEG_MOVETO = java.awt.geom.PathIterator.SEG_MOVETO;
                                                    
                                                    // Create mock shapes with path data
                                                    Shape shape1 = mock(Shape.class);
                                                    Shape shape2 = mock(Shape.class);
                                                    
                                                    // Create mock path iterators that will return segment data
                                                    PathIterator iterator1 = mock(PathIterator.class);
                                                    PathIterator iterator2 = mock(PathIterator.class);
                                                    
                                                    // Set up the mock behavior
                                                    when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                                    when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                                    
                                                    // First call to isDone() returns false, then true
                                                    when(iterator1.isDone()).thenReturn(false).thenReturn(true);
                                                    when(iterator2.isDone()).thenReturn(false).thenReturn(true);
                                                    
                                                    // Mock segment data that would need to be stored in the array
                                                    when(iterator1.currentSegment(any(double[].class))).thenAnswer(invocation -> {
                                                        double[] coords = invocation.getArgument(0);
                                                        // This would throw ArrayIndexOutOfBoundsException if array size is 0
                                                        coords[0] = 1.0;
                                                        coords[1] = 2.0;
                                                        return SEG_MOVETO;
                                                    });
                                                    
                                                    when(iterator2.currentSegment(any(double[].class))).thenAnswer(invocation -> {
                                                        double[] coords = invocation.getArgument(0);
                                                        coords[0] = 1.0;
                                                        coords[1] = 2.0;
                                                        return SEG_MOVETO;
                                                    });
                                                    
                                                    // Test the comparison - should work with original code, fail with mutated code
                                                    assertTrue(ShapeUtilities.equal(shape1, shape2));
                                                    
                                                    // Verify the iterators were properly used
                                                    verify(iterator1, times(1)).currentSegment(any(double[].class));
                                                    verify(iterator2, times(1)).currentSegment(any(double[].class));
                                                    verify(iterator1, times(2)).isDone();
                                                    verify(iterator2, times(2)).isDone();
                                                }

    @Test
                                                public void testEqualWithDifferentShapeTypes() {
                                                    // Test Line2D comparison (likely where the array is used)
                                                    Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                                    Line2D line2 = new Line2D.Double(1, 2, 3, 4);
                                                    Line2D line3 = new Line2D.Double(5, 6, 7, 8);
                                                    assertTrue(ShapeUtilities.equal(line1, line2));
                                                    assertFalse(ShapeUtilities.equal(line1, line3));
                                            
                                                    // Test Ellipse2D comparison
                                                    Ellipse2D ellipse1 = new Ellipse2D.Double(1, 2, 3, 4);
                                                    Ellipse2D ellipse2 = new Ellipse2D.Double(1, 2, 3, 4);
                                                    Ellipse2D ellipse3 = new Ellipse2D.Double(5, 6, 7, 8);
                                                    assertTrue(ShapeUtilities.equal(ellipse1, ellipse2));
                                                    assertFalse(ShapeUtilities.equal(ellipse1, ellipse3));
                                            
                                                    // Test Arc2D comparison
                                                    Arc2D arc1 = new Arc2D.Double(1, 2, 3, 4, 0, 90, Arc2D.OPEN);
                                                    Arc2D arc2 = new Arc2D.Double(1, 2, 3, 4, 0, 90, Arc2D.OPEN);
                                                    Arc2D arc3 = new Arc2D.Double(1, 2, 3, 4, 0, 180, Arc2D.OPEN);
                                                    assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                    assertFalse(ShapeUtilities.equal(arc1, arc3));
                                            
                                                    // Test Polygon comparison
                                                    Polygon poly1 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                    Polygon poly2 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                                    Polygon poly3 = new Polygon(new int[]{7,8,9}, new int[]{4,5,6}, 3);
                                                    assertTrue(ShapeUtilities.equal(poly1, poly2));
                                                    assertFalse(ShapeUtilities.equal(poly1, poly3));
                                            
                                                    // Test GeneralPath comparison
                                                    GeneralPath path1 = new GeneralPath();
                                                    path1.moveTo(1, 2);
                                                    path1.lineTo(3, 4);
                                                    GeneralPath path2 = new GeneralPath();
                                                    path2.moveTo(1, 2);
                                                    path2.lineTo(3, 4);
                                                    GeneralPath path3 = new GeneralPath();
                                                    path3.moveTo(5, 6);
                                                    path3.lineTo(7, 8);
                                                    assertTrue(ShapeUtilities.equal(path1, path2));
                                                    assertFalse(ShapeUtilities.equal(path1, path3));
                                            
                                                    // Test fallback to ObjectUtilities.equal()
                                                    Rectangle2D rect1 = new Rectangle2D.Double(1, 2, 3, 4);
                                                    Rectangle2D rect2 = new Rectangle2D.Double(1, 2, 3, 4);
                                                    Rectangle2D rect3 = new Rectangle2D.Double(5, 6, 7, 8);
                                                    assertTrue(ShapeUtilities.equal(rect1, rect2));
                                                    assertFalse(ShapeUtilities.equal(rect1, rect3));
                                                }

    @Test
                                                public void testEqual_Line2D_WithArrayDependentPoints() {
                                                    // Create mock Line2D objects
                                                    Line2D l1 = mock(Line2D.class);
                                                    Line2D l2 = mock(Line2D.class);
                                                    
                                                    // Create mock points that might depend on the internal array
                                                    Point2D p1 = mock(Point2D.class);
                                                    Point2D p2 = mock(Point2D.class);
                                                    Point2D p3 = mock(Point2D.class);
                                                    Point2D p4 = mock(Point2D.class);
                                                    
                                                    // Setup mock behavior
                                                    when(l1.getP1()).thenReturn(p1);
                                                    when(l1.getP2()).thenReturn(p2);
                                                    when(l2.getP1()).thenReturn(p3);
                                                    when(l2.getP2()).thenReturn(p4);
                                                    
                                                    // Make points equal
                                                    when(p1.equals(p3)).thenReturn(true);
                                                    when(p2.equals(p4)).thenReturn(true);
                                                    
                                                    // Test the equality - this should pass in original but might fail in mutant
                                                    // if the array operations in point comparisons are affected
                                                    assertTrue(ShapeUtilities.equal(l1, l2));
                                                    
                                                    // Verify all interactions
                                                    verify(l1).getP1();
                                                    verify(l1).getP2();
                                                    verify(l2).getP1();
                                                    verify(l2).getP2();
                                                    verify(p1).equals(p3);
                                                    verify(p2).equals(p4);
                                                }

    @Test
                                                public void testEqual_Line2D_UnequalPoints() {
                                                    // Create real Line2D objects with different points
                                                    Line2D l1 = new Line2D.Double(1, 2, 3, 4);
                                                    Line2D l2 = new Line2D.Double(1, 2, 5, 6); // Different p2
                                                    
                                                    assertFalse(ShapeUtilities.equal(l1, l2));
                                                }

    @Test
                                                public void testEqual_NullFirst() {
                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                    assertFalse(ShapeUtilities.equal(null, e2));
                                                }

    @Test
                                                public void testEqual_NullSecond() {
                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                    assertFalse(ShapeUtilities.equal(e1, null));
                                                }

    @Test
                                                public void testEqual_DifferentFrames1() {
                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                    when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                    when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 20, 20));
                                                    assertFalse(ShapeUtilities.equal(e1, e2));
                                                }

    @Test
                                                public void testEqual_SameFrames1() {
                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                    Rectangle2D frame = new Rectangle2D.Double(0, 0, 10, 10);
                                                    when(e1.getFrame()).thenReturn(frame);
                                                    when(e2.getFrame()).thenReturn(frame);
                                                    assertTrue(ShapeUtilities.equal(e1, e2));
                                                }

    @Test
                                                public void testEqual_FirstFrameNull() {
                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                    when(e1.getFrame()).thenReturn(null);
                                                    when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                    assertFalse(ShapeUtilities.equal(e1, e2));
                                                }

    @Test
                                                public void testEqual_SecondFrameNull() {
                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                    when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                    when(e2.getFrame()).thenReturn(null);
                                                    assertFalse(ShapeUtilities.equal(e1, e2));
                                                }

    @Test(expected = NullPointerException.class)
                                                public void testEqualArc2DWithArrayAccess() {
                                                    // Create two non-null Arc2D objects that would trigger array access
                                                    Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                                    Arc2D a1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                                    Arc2D a2 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                                    
                                                    // The mutated version should throw NullPointerException when trying to access the null array
                                                    ShapeUtilities.equal(a1, a2);
                                                }

    @Test
                                                public void testEqualArc2DNonEqualCases() {
                                                    // Test non-equal cases which shouldn't involve array access
                                                    Rectangle2D frame1 = new Rectangle2D.Double(0, 0, 100, 100);
                                                    Rectangle2D frame2 = new Rectangle2D.Double(0, 0, 200, 200);
                                                    
                                                    Arc2D a1 = new Arc2D.Double(frame1, 0, 90, Arc2D.PIE);
                                                    Arc2D a2 = new Arc2D.Double(frame1, 0, 90, Arc2D.CHORD);
                                                    Arc2D a3 = new Arc2D.Double(frame1, 10, 90, Arc2D.PIE);
                                                    Arc2D a4 = new Arc2D.Double(frame1, 0, 100, Arc2D.PIE);
                                                    Arc2D a5 = new Arc2D.Double(frame2, 0, 90, Arc2D.PIE);
                                                    
                                                    assertFalse(ShapeUtilities.equal(a1, a2)); // different arcType
                                                    assertFalse(ShapeUtilities.equal(a1, a3)); // different angleStart
                                                    assertFalse(ShapeUtilities.equal(a1, a4)); // different angleExtent
                                                    assertFalse(ShapeUtilities.equal(a1, a5)); // different frame
                                                }

    @Test
                                                public void testEqualPolygonsWithNonNullArrays() {
                                                    // Create two identical polygons
                                                    int[] xpoints = {1, 2, 3};
                                                    int[] ypoints = {4, 5, 6};
                                                    Polygon p1 = new Polygon(xpoints, ypoints, 3);
                                                    Polygon p2 = new Polygon(xpoints, ypoints, 3);
                                                    
                                                    // Should return true for equal polygons
                                                    assertTrue(ShapeUtilities.equal(p1, p2));
                                                }

    @Test(expected = NullPointerException.class)
                                                public void testEqualPolygonsDetectsMutant() {
                                                    // Create two polygons that would require array comparison
                                                    int[] xpoints = {1, 2, 3};
                                                    int[] ypoints = {4, 5, 6};
                                                    Polygon p1 = new Polygon(xpoints, ypoints, 3);
                                                    Polygon p2 = new Polygon(xpoints, ypoints, 3);
                                                    
                                                    // The mutant would throw NullPointerException here when trying to use the null array
                                                    ShapeUtilities.equal(p1, p2);
                                                }

    @Test
                                                public void testEqualPolygonsWithDifferentPoints() {
                                                    // Create two different polygons
                                                    Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                    Polygon p2 = new Polygon(new int[]{1, 2, 4}, new int[]{4, 5, 6}, 3);
                                                    
                                                    // Should return false for different polygons
                                                    assertFalse(ShapeUtilities.equal(p1, p2));
                                                }

    @Test
                                        public void testEqual_Line2D_NullInputs() {
                                            // Test null cases
                                            assertTrue(ShapeUtilities.equal((Line2D) null, (Line2D) null));
                                            assertFalse(ShapeUtilities.equal(new Line2D.Double(), (Line2D) null));
                                            assertFalse(ShapeUtilities.equal((Line2D) null, new Line2D.Double()));
                                        }

    @Test
                                        public void testEqual_NullBoth() {
                                            Shape shape1 = null;
                                            Shape shape2 = null;
                                            assertTrue(ShapeUtilities.equal(shape1, shape2));
                                        }

    @Test
                                        public void testEqualArc2DNullCases() {
                                            // Test null cases which shouldn't involve array access
                                            assertTrue(ShapeUtilities.equal((Arc2D) null, (Arc2D) null));
                                            assertFalse(ShapeUtilities.equal(new Arc2D.Double(), (Arc2D) null));
                                            assertFalse(ShapeUtilities.equal((Arc2D) null, new Arc2D.Double()));
                                        }

    @Test
                                        public void testEqualPolygonsWithNullInputs() {
                                            // Test null cases
                                            assertTrue(ShapeUtilities.equal((Polygon) null, (Polygon) null));
                                            assertFalse(ShapeUtilities.equal(new Polygon(), (Polygon) null));
                                            assertFalse(ShapeUtilities.equal((Polygon) null, new Polygon()));
                                        }

    @Test
                                        public void testEqual_WithNonNullShapes_ShouldNotThrowNPE() {
                                            // Create mock shapes and iterators
                                            Shape shape1 = mock(Shape.class);
                                            Shape shape2 = mock(Shape.class);
                                            PathIterator iterator1 = mock(PathIterator.class);
                                            PathIterator iterator2 = mock(PathIterator.class);
                                            
                                            // Setup mock behavior
                                            when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                            when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                            
                                            // Setup iterator behavior
                                            when(iterator1.isDone()).thenReturn(false, true);
                                            when(iterator2.isDone()).thenReturn(false, true);
                                            when(iterator1.currentSegment(any(double[].class))).thenReturn(0); // SEG_MOVETO is 0
                                            when(iterator2.currentSegment(any(double[].class))).thenReturn(0); // SEG_MOVETO is 0
                                            
                                            // Test - should not throw NPE with original code
                                            boolean result = ShapeUtilities.equal(shape1, shape2);
                                            
                                            // Verify
                                            assertTrue(result);
                                            verify(iterator1).currentSegment(any(double[].class));
                                            verify(iterator2).currentSegment(any(double[].class));
                                        }

    @Test(expected = NullPointerException.class)
                                        public void testEqualWithMutatedArrayInitialization() {
                                            // Test Line2D comparison
                                            Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                            Line2D line2 = new Line2D.Double(1, 2, 3, 4);
                                            ShapeUtilities.equal(line1, line2);  // Would throw NPE if mutation is in Line2D comparison
                                            
                                            // Test Ellipse2D comparison
                                            Ellipse2D ellipse1 = new Ellipse2D.Double(1, 2, 3, 4);
                                            Ellipse2D ellipse2 = new Ellipse2D.Double(1, 2, 3, 4);
                                            ShapeUtilities.equal(ellipse1, ellipse2);  // Would throw NPE if mutation is in Ellipse2D comparison
                                            
                                            // Test Arc2D comparison
                                            Arc2D arc1 = new Arc2D.Double(1, 2, 3, 4, 0, 90, Arc2D.OPEN);
                                            Arc2D arc2 = new Arc2D.Double(1, 2, 3, 4, 0, 90, Arc2D.OPEN);
                                            ShapeUtilities.equal(arc1, arc2);  // Would throw NPE if mutation is in Arc2D comparison
                                            
                                            // If none of the above throw, the test will fail (which is good - means mutation was caught)
                                            fail("Expected NullPointerException from mutated array initialization");
                                        }

    @Test
                                        public void testEqualWithOtherShapeTypes() {
                                            // Test Polygon comparison (unlikely to be affected)
                                            Polygon poly1 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                            Polygon poly2 = new Polygon(new int[]{1,2,3}, new int[]{4,5,6}, 3);
                                            assertTrue(ShapeUtilities.equal(poly1, poly2));
                                            
                                            // Test GeneralPath comparison (unlikely to be affected)
                                            GeneralPath path1 = new GeneralPath();
                                            path1.moveTo(1, 2);
                                            path1.lineTo(3, 4);
                                            GeneralPath path2 = new GeneralPath();
                                            path2.moveTo(1, 2);
                                            path2.lineTo(3, 4);
                                            assertTrue(ShapeUtilities.equal(path1, path2));
                                            
                                            // Test fallback to ObjectUtilities.equal()
                                            Rectangle2D rect1 = new Rectangle2D.Double(1, 2, 3, 4);
                                            Rectangle2D rect2 = new Rectangle2D.Double(1, 2, 3, 4);
                                            assertTrue(ShapeUtilities.equal(rect1, rect2));
                                        }

    @Test
                                        public void testEqualEllipse2DWithNonNullFrames() {
                                            // Create two non-null Ellipse2D objects with frames
                                            Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                            Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                            
                                            // Test that the method doesn't throw an exception and returns true for equal frames
                                            assertTrue(ShapeUtilities.equal(e1, e2));
                                            
                                            // Create a different ellipse
                                            Ellipse2D e3 = new Ellipse2D.Double(0, 0, 20, 20);
                                            
                                            // Test that the method doesn't throw an exception and returns false for different frames
                                            assertFalse(ShapeUtilities.equal(e1, e3));
                                        }

    @Test
                                        public void testEqualArc2DWithNonNullValues() {
                                            // Create two identical arcs
                                            Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                            Arc2D a1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                            Arc2D a2 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                            
                                            // Should return true for equal arcs
                                            assertTrue(ShapeUtilities.equal(a1, a2));
                                        }

    @Test
                                        public void testEqualArc2DWithDifferentFrames() {
                                            // Create arcs with different frames
                                            Rectangle2D frame1 = new Rectangle2D.Double(0, 0, 100, 100);
                                            Rectangle2D frame2 = new Rectangle2D.Double(0, 0, 200, 200);
                                            Arc2D a1 = new Arc2D.Double(frame1, 0, 90, Arc2D.PIE);
                                            Arc2D a2 = new Arc2D.Double(frame2, 0, 90, Arc2D.PIE);
                                            
                                            // Should return false for different frames
                                            assertFalse(ShapeUtilities.equal(a1, a2));
                                        }

    @Test
                                        public void testEqualArc2DWithDifferentAngles() {
                                            // Create arcs with different angles
                                            Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                            Arc2D a1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                            Arc2D a2 = new Arc2D.Double(frame, 45, 90, Arc2D.PIE);
                                            
                                            // Should return false for different angles
                                            assertFalse(ShapeUtilities.equal(a1, a2));
                                        }

    @Test
                                        public void testEqualArc2DWithComplexFrame() {
                                            // Create arcs with more complex frames that might trigger array usage
                                            Rectangle2D frame1 = new Rectangle2D.Double(10.5, 20.3, 100.7, 200.9);
                                            Rectangle2D frame2 = new Rectangle2D.Double(10.5, 20.3, 100.7, 200.9);
                                            Arc2D a1 = new Arc2D.Double(frame1, 15.2, 45.7, Arc2D.CHORD);
                                            Arc2D a2 = new Arc2D.Double(frame2, 15.2, 45.7, Arc2D.CHORD);
                                            
                                            // This comparison would likely use the internal array for precise comparison
                                            assertTrue(ShapeUtilities.equal(a1, a2));
                                        }

    @Test
                                        public void testEqual_DetectsNullArrayMutant() {
                                            // Create two different GeneralPath objects
                                            GeneralPath path1 = new GeneralPath();
                                            path1.moveTo(1.0f, 1.0f);
                                            path1.lineTo(2.0f, 2.0f);
                                            
                                            GeneralPath path2 = new GeneralPath();
                                            path2.moveTo(1.0f, 1.0f);
                                            path2.lineTo(3.0f, 3.0f); // Different from path1
                                            
                                            // Test original behavior should return false (not throw exception)
                                            boolean result = ShapeUtilities.equal(path1, path2);
                                            assertFalse(result);
                                            
                                            // The mutant would throw NullPointerException when trying to use null d2 array
                                            // This test case would fail for the mutant version, thus detecting it
                                        }

    @Test
                                public void testEqual_Line2D_NullArrayHandling() {
                                    // Create two lines with the same points
                                    Point2D p1 = new Point2D.Double(1.0, 2.0);
                                    Point2D p2 = new Point2D.Double(3.0, 4.0);
                                    Line2D line1 = new Line2D.Double(p1, p2);
                                    Line2D line2 = new Line2D.Double(p1, p2);
                                    
                                    // Test equality - should return true
                                    assertTrue(ShapeUtilities.equal((Line2D)line1, (Line2D)line2));
                                    
                                    // Test with first line null
                                    assertFalse(ShapeUtilities.equal((Line2D)null, (Line2D)line2));
                                    
                                    // Test with second line null
                                    assertFalse(ShapeUtilities.equal((Line2D)line1, (Line2D)null));
                                    
                                    // Test with both lines null
                                    assertTrue(ShapeUtilities.equal((Line2D)null, (Line2D)null));
                                    
                                    // Create lines with different points
                                    Point2D p3 = new Point2D.Double(5.0, 6.0);
                                    Line2D line3 = new Line2D.Double(p1, p3);
                                    assertFalse(ShapeUtilities.equal((Line2D)line1, (Line2D)line3));
                                }

    @Test
                                public void testEqualEllipse2DWithNullInputs1() {
                                    // Test null cases
                                    assertTrue(ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
                                    assertFalse(ShapeUtilities.equal(new Ellipse2D.Double(0, 0, 10, 10), (Ellipse2D) null));
                                    assertFalse(ShapeUtilities.equal((Ellipse2D) null, new Ellipse2D.Double(0, 0, 10, 10)));
                                }

    @Test
                                public void testEqualArc2DWithNullInput() {
                                    // Test with null inputs
                                    Arc2D a1 = new Arc2D.Double(new Rectangle2D.Double(0, 0, 100, 100), 0, 90, Arc2D.PIE);
                                    
                                    // Cases with null inputs
                                    assertFalse(ShapeUtilities.equal(a1, (Arc2D) null));
                                    assertFalse(ShapeUtilities.equal((Arc2D) null, a1));
                                    assertTrue(ShapeUtilities.equal((Arc2D) null, (Arc2D) null));
                                }

    @Test
                                public void testEqualPolygonWithNullArrayMutation() {
                                    // Create two identical polygons
                                    int[] xpoints = {1, 2, 3};
                                    int[] ypoints = {4, 5, 6};
                                    Polygon p1 = new Polygon(xpoints, ypoints, 3);
                                    Polygon p2 = new Polygon(xpoints.clone(), ypoints.clone(), 3);
                                    
                                    // Test equal polygons - explicitly call equal(Polygon, Polygon)
                                    assertTrue(ShapeUtilities.equal(p1, p2));
                                    
                                    // Test with null polygons
                                    assertTrue(ShapeUtilities.equal((Polygon)null, (Polygon)null));
                                    assertFalse(ShapeUtilities.equal(p1, (Polygon)null));
                                    assertFalse(ShapeUtilities.equal((Polygon)null, p2));
                                    
                                    // Test with different point counts
                                    Polygon p3 = new Polygon(Arrays.copyOf(xpoints, 2), Arrays.copyOf(ypoints, 2), 2);
                                    assertFalse(ShapeUtilities.equal(p1, p3));
                                    
                                    // Test with different xpoints
                                    int[] xpoints2 = {1, 2, 4};
                                    Polygon p4 = new Polygon(xpoints2, ypoints, 3);
                                    assertFalse(ShapeUtilities.equal(p1, p4));
                                    
                                    // Test with different ypoints
                                    int[] ypoints2 = {4, 5, 7};
                                    Polygon p5 = new Polygon(xpoints, ypoints2, 3);
                                    assertFalse(ShapeUtilities.equal(p1, p5));
                                    
                                    // The following test would catch the null array mutant
                                    // by causing a NullPointerException when the method tries to use the null array
                                    try {
                                        ShapeUtilities.equal(p1, p2);
                                        // If we get here, the mutant survived
                                        fail("Expected NullPointerException from mutated null array");
                                    } catch (NullPointerException e) {
                                        // This is expected for the mutant
                                    }
                                }

    @Test
                                public void testEqual_WithMockedIteratorsToExplicitlyTestArrayUsage() {
                                    // Setup mock objects
                                    Shape shape1 = mock(Shape.class);
                                    Shape shape2 = mock(Shape.class);
                                    PathIterator iterator1 = mock(PathIterator.class);
                                    PathIterator iterator2 = mock(PathIterator.class);
                                    
                                    // Configure mock behavior
                                    when(shape1.getPathIterator(null)).thenReturn(iterator1);
                                    when(shape2.getPathIterator(null)).thenReturn(iterator2);
                                    
                                    // First iteration
                                    when(iterator1.isDone()).thenReturn(false).thenReturn(true);
                                    when(iterator2.isDone()).thenReturn(false).thenReturn(true);
                                    when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                    when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                    
                                    // This test explicitly checks for the array usage
                                    // The mutant version would throw NullPointerException
                                    ShapeUtilities.equal(shape1, shape2);
                                }

    @Test
                                public void testEqualGeneralPathWithDifferentLengths() {
                                    // Create two GeneralPaths with different number of segments but same initial segments
                                    GeneralPath path1 = new GeneralPath();
                                    GeneralPath path2 = new GeneralPath();
                                    
                                    // Both paths start with same segments
                                    path1.moveTo(0, 0);
                                    path1.lineTo(1, 1);
                                    path2.moveTo(0, 0);
                                    path2.lineTo(1, 1);
                                    
                                    // Add extra segment only to path1
                                    path1.lineTo(2, 2);
                                    
                                    // The paths should NOT be equal since they have different number of segments
                                    // Original implementation (using &&) will detect this difference
                                    // Mutant (using ||) might incorrectly return true
                                    
                                    assertFalse("Paths with different segment counts should not be equal", 
                                               ShapeUtilities.equal(path1, path2));
                                }

    @Test
                                public void testEqualGeneralPathWithSameLengths() {
                                    // Create two identical GeneralPaths
                                    GeneralPath path1 = new GeneralPath();
                                    GeneralPath path2 = new GeneralPath();
                                    
                                    path1.moveTo(0, 0);
                                    path1.lineTo(1, 1);
                                    path2.moveTo(0, 0);
                                    path2.lineTo(1, 1);
                                    
                                    // The paths should be equal
                                    assertTrue("Identical paths should be equal", 
                                              ShapeUtilities.equal(path1, path2));
                                }

    @Test
                                public void testEqualLine2D_DifferentLengths_ShouldReturnFalse() {
                                    // Create two lines with different number of points
                                    // Line1: p1 -> p2 -> p3
                                    // Line2: p1 -> p2
                                    Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                    Line2D line2 = new Line2D.Double(1, 2, 3, 4) {
                                        @Override
                                        public Point2D getP1() {
                                            return new Point2D.Double(1, 2);
                                        }
                                        @Override
                                        public Point2D getP2() {
                                            return new Point2D.Double(3, 4);
                                        }
                                        // Additional point that would make iteration longer
                                        public Point2D getP3() {
                                            return new Point2D.Double(5, 6);
                                        }
                                    };
                            
                                    // The original implementation would compare all points
                                    // The mutant would return true after comparing p1 and p2
                                    assertFalse("Lines with different lengths should not be equal", 
                                               ShapeUtilities.equal(line1, line2));
                                    
                                    // Also test reverse case
                                    assertFalse("Lines with different lengths should not be equal", 
                                               ShapeUtilities.equal(line2, line1));
                                }

    @Test
                                public void testEqualLine2D_SamePointsDifferentOrder_ShouldReturnFalse() {
                                    // Create two lines with same points but in different order
                                    Line2D line1 = new Line2D.Double(1, 2, 3, 4);
                                    Line2D line2 = new Line2D.Double(3, 4, 1, 2);
                                    
                                    // The original implementation would detect the different order
                                    // The mutant might return true if it stops after first point
                                    assertFalse("Lines with points in different order should not be equal", 
                                               ShapeUtilities.equal(line1, line2));
                                }

    @Test
                                public void testEqualArc2D_EqualArcs() {
                                    Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                    Arc2D arc1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                    Arc2D arc2 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                    
                                    assertTrue(ShapeUtilities.equal(arc1, arc2));
                                }

    @Test
                                public void testEqualArc2D_DifferentFrames() {
                                    Rectangle2D frame1 = new Rectangle2D.Double(0, 0, 100, 100);
                                    Rectangle2D frame2 = new Rectangle2D.Double(0, 0, 200, 200);
                                    Arc2D arc1 = new Arc2D.Double(frame1, 0, 90, Arc2D.PIE);
                                    Arc2D arc2 = new Arc2D.Double(frame2, 0, 90, Arc2D.PIE);
                                    
                                    assertFalse(ShapeUtilities.equal(arc1, arc2));
                                }

    @Test
                                public void testEqualArc2D_DifferentAngles() {
                                    Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                    Arc2D arc1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                    Arc2D arc2 = new Arc2D.Double(frame, 45, 90, Arc2D.PIE);
                                    
                                    assertFalse(ShapeUtilities.equal(arc1, arc2));
                                    
                                    Arc2D arc3 = new Arc2D.Double(frame, 0, 180, Arc2D.PIE);
                                    assertFalse(ShapeUtilities.equal(arc1, arc3));
                                }

    @Test
                                public void testEqualArc2D_DifferentArcTypes() {
                                    Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                    Arc2D arc1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE);
                                    Arc2D arc2 = new Arc2D.Double(frame, 0, 90, Arc2D.CHORD);
                                    
                                    assertFalse(ShapeUtilities.equal(arc1, arc2));
                                }

    @Test
                                public void testEqualArc2D_PartialComparison() {
                                    // This test would catch the iterator mutant by ensuring complete comparison
                                    Rectangle2D frame = new Rectangle2D.Double(0, 0, 100, 100);
                                    Arc2D arc1 = new Arc2D.Double(frame, 0, 90, Arc2D.PIE) {
                                        @Override
                                        public boolean equals(Object obj) {
                                            // Force equals to be called on frame
                                            if (obj instanceof Arc2D) {
                                                return this.getFrame().equals(((Arc2D)obj).getFrame());
                                            }
                                            return false;
                                        }
                                    };
                                    
                                    Arc2D arc2 = new Arc2D.Double(frame, 45, 90, Arc2D.PIE) {
                                        @Override
                                        public boolean equals(Object obj) {
                                            // Force equals to be called on frame
                                            if (obj instanceof Arc2D) {
                                                return this.getFrame().equals(((Arc2D)obj).getFrame());
                                            }
                                            return false;
                                        }
                                    };
                                    
                                    // Should return false because angles differ, despite frames being equal
                                    // This would catch the iterator mutant if it stopped early
                                    assertFalse(ShapeUtilities.equal(arc1, arc2));
                                }

    @Test
                                public void testEqualPolygonDifferentLengths() {
                                    // Create polygons with different number of points
                                    Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                    Polygon p2 = new Polygon(new int[]{1, 2}, new int[]{4, 5}, 2);
                                    
                                    // Should return false since lengths differ
                                    assertFalse(ShapeUtilities.equal(p1, p2));
                                }

    @Test
                                public void testEqualPolygonDifferentPoints() {
                                    // Create polygons with same length but different points
                                    Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                    Polygon p2 = new Polygon(new int[]{1, 2, 4}, new int[]{4, 5, 6}, 3);
                                    
                                    // Should return false since points differ
                                    assertFalse(ShapeUtilities.equal(p1, p2));
                                }

    @Test
                                public void testEqualPolygonSamePoints() {
                                    // Create identical polygons
                                    Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                    Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                    
                                    // Should return true
                                    assertTrue(ShapeUtilities.equal(p1, p2));
                                }

    @Test
                                public void testEqualPolygonDifferentYPoints() {
                                    // Create polygons with same xpoints but different ypoints
                                    Polygon p1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                    Polygon p2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 7}, 3);
                                    
                                    // Should return false since ypoints differ
                                    assertFalse(ShapeUtilities.equal(p1, p2));
                                }

    @Test
                        public void testEqualArc2D_NullCases() {
                            // Both null
                            assertTrue(ShapeUtilities.equal((Arc2D) null, (Arc2D) null));
                            
                            // First null, second not null
                            Arc2D arc = new Arc2D.Double();
                            assertFalse(ShapeUtilities.equal((Arc2D) null, arc));
                            
                            // Second null, first not null
                            assertFalse(ShapeUtilities.equal(arc, (Arc2D) null));
                        }

    @Test
                        public void testEqualPolygonNullCases() {
                            // Test null cases
                            Polygon p = new Polygon(new int[]{1}, new int[]{1}, 1);
                            assertTrue(ShapeUtilities.equal((Shape) null, (Shape) null));
                            assertFalse(ShapeUtilities.equal((Shape) p, (Shape) null));
                            assertFalse(ShapeUtilities.equal((Shape) null, (Shape) p));
                        }

    @Test
                        public void testEqual_ShouldDetectDifferentLengthPaths() {
                            // Create mock PathIterators with different lengths
                            PathIterator shortIterator = mock(PathIterator.class);
                            PathIterator longIterator = mock(PathIterator.class);
                            
                            // Set up the short path (1 segment)
                            when(shortIterator.isDone())
                                .thenReturn(false)  // first segment exists
                                .thenReturn(true);  // then done
                            when(shortIterator.currentSegment(any(double[].class)))
                                .thenReturn(PathIterator.SEG_MOVETO);
                            
                            // Set up the long path (2 segments)
                            when(longIterator.isDone())
                                .thenReturn(false)  // first segment exists
                                .thenReturn(false) // second segment exists
                                .thenReturn(true); // then done
                            when(longIterator.currentSegment(any(double[].class)))
                                .thenReturn(PathIterator.SEG_MOVETO)
                                .thenReturn(PathIterator.SEG_LINETO);
                            
                            // Create mock shapes
                            Shape shape1 = mock(Shape.class);
                            Shape shape2 = mock(Shape.class);
                            
                            // Both shapes have same winding rule
                            when(shape1.getPathIterator(null).getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                            when(shape2.getPathIterator(null).getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                            
                            // Return our iterators
                            when(shape1.getPathIterator(null)).thenReturn(shortIterator);
                            when(shape2.getPathIterator(null)).thenReturn(longIterator);
                            
                            // Test - should return false since paths have different lengths
                            assertFalse(ShapeUtilities.equal(shape1, shape2));
                            
                            // Verify iterators were used properly
                            verify(shortIterator, times(1)).next();
                            verify(longIterator, times(2)).next();
                        }

    @Test
                    public void testEqual_Ellipse2D_DifferentFrameComplexity() {
                        // Create two ellipses with different frame complexity
                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10) {
                            @Override
                            public Rectangle2D getFrame() {
                                return new Rectangle2D.Double(0, 0, 10, 10) {
                                    @Override
                                    public boolean equals(Object obj) {
                                        // Mock frame comparison that would fail with the mutant
                                        // Original would compare all segments, mutant would stop early
                                        return true; // Simulate partial comparison
                                    }
                                };
                            }
                        };
                        
                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10) {
                            @Override
                            public Rectangle2D getFrame() {
                                return new Rectangle2D.Double(0, 0, 10, 10) {
                                    @Override
                                    public boolean equals(Object obj) {
                                        // Different implementation to expose the mutant
                                        if (obj == this) return true;
                                        if (!(obj instanceof Rectangle2D)) return false;
                                        // This would fail if mutant stops early
                                        return super.equals(obj);
                                    }
                                };
                            }
                        };
                        
                        // The test should fail if the mutant is present
                        assertTrue(ShapeUtilities.equal((Shape)e1, (Shape)e2));
                        
                        // Additional test case with null values
                        assertTrue(ShapeUtilities.equal((Shape)null, (Shape)null));
                        assertFalse(ShapeUtilities.equal((Shape)e1, (Shape)null));
                        assertFalse(ShapeUtilities.equal((Shape)null, (Shape)e2));
                    }

    @Test
                    public void testEqualLine2DDetectsMutant1() {
                        // Create two lines that differ only in their second point
                        Line2D line1 = new Line2D.Double(1, 2, 3, 4);  // x1,y1,x2,y2
                        Line2D line2 = new Line2D.Double(1, 2, 3, 5);  // different y2
                        
                        // The original code should detect they're different
                        // The mutant would return true after first iteration
                        assertFalse(ShapeUtilities.equal(line1, line2));
                    }

    @Test
                    public void testEqualEllipse2DDetectsMutant() {
                        // Create two ellipses with different heights
                        Ellipse2D ellipse1 = new Ellipse2D.Double(1, 2, 3, 4);
                        Ellipse2D ellipse2 = new Ellipse2D.Double(1, 2, 3, 5);
                        
                        assertFalse(ShapeUtilities.equal(ellipse1, ellipse2));
                    }

    @Test
                    public void testEqualPolygonDetectsMutant() {
                        // Create two polygons with different points
                        Polygon poly1 = new Polygon(new int[]{1,2}, new int[]{3,4}, 2);
                        Polygon poly2 = new Polygon(new int[]{1,2}, new int[]{3,5}, 2);
                        
                        assertFalse(ShapeUtilities.equal(poly1, poly2));
                    }

    @Test
                    public void testEqualGeneralPathDetectsMutant1() {
                        // Create two GeneralPath objects with different segments
                        GeneralPath path1 = new GeneralPath();
                        path1.moveTo(1, 2);
                        path1.lineTo(3, 4);
                        
                        GeneralPath path2 = new GeneralPath();
                        path2.moveTo(1, 2);
                        path2.lineTo(3, 5);
                        
                        assertFalse(ShapeUtilities.equal(path1, path2));
                    }

    @Test
                    public void testEqualLine2D_SamePoints_ShouldReturnTrue() {
                        // Create two identical lines
                        Line2D line1 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                        Line2D line2 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                        
                        assertTrue("Identical lines should be equal",
                            ShapeUtilities.equal(line1, line2));
                    }

    @Test
                    public void testEqual_Ellipse2D_DifferentShapesSameFrame() {
                        // Create two ellipses with same frame but different shapes
                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10) {
                            // Override to make it behave differently while keeping same frame
                            @Override
                            public boolean contains(double x, double y) {
                                return false; // Different behavior from normal ellipse
                            }
                        };
                        
                        // The original code would detect they're different shapes despite same frame
                        // The mutant would return true because it only checks frame equality
                        assertFalse("Should detect different shapes with same frame", 
                                   ShapeUtilities.equal(e1, e2));
                    }

    @Test
                    public void testEqual_Ellipse2D_SameObject() {
                        Ellipse2D e = new Ellipse2D.Double(0, 0, 10, 10);
                        assertTrue(ShapeUtilities.equal(e, e));
                    }

    @Test
                    public void testEqual_Ellipse2D_DifferentFrames1() {
                        Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                        Ellipse2D e2 = new Ellipse2D.Double(0, 0, 20, 20);
                        assertFalse(ShapeUtilities.equal(e1, e2));
                    }

    @Test
                    public void testEqualArc2D_ShouldDetectMutant() {
                        // Create two different Arc2D objects
                        Rectangle2D frame1 = new Rectangle2D.Double(0, 0, 100, 100);
                        Rectangle2D frame2 = new Rectangle2D.Double(0, 0, 100, 100);
                        
                        // Same frame but different angles
                        Arc2D arc1 = new Arc2D.Double(frame1, 0, 90, Arc2D.OPEN);
                        Arc2D arc2 = new Arc2D.Double(frame2, 0, 45, Arc2D.OPEN);
                        
                        // These should not be equal due to different angle extents
                        assertFalse("Arcs with different angle extents should not be equal", 
                            ShapeUtilities.equal(arc1, arc2));
                            
                        // Test with different arc types
                        Arc2D arc3 = new Arc2D.Double(frame1, 0, 90, Arc2D.CHORD);
                        assertFalse("Arcs with different types should not be equal",
                            ShapeUtilities.equal(arc1, arc3));
                            
                        // Test with different start angles
                        Arc2D arc4 = new Arc2D.Double(frame1, 45, 90, Arc2D.OPEN);
                        assertFalse("Arcs with different start angles should not be equal",
                            ShapeUtilities.equal(arc1, arc4));
                            
                        // Test with different frames
                        Rectangle2D frame3 = new Rectangle2D.Double(10, 10, 100, 100);
                        Arc2D arc5 = new Arc2D.Double(frame3, 0, 90, Arc2D.OPEN);
                        assertFalse("Arcs with different frames should not be equal",
                            ShapeUtilities.equal(arc1, arc5));
                    }

    @Test
                    public void testEqualPolygonsWithDifferentPoints1() {
                        // Create two polygons with same number of points but different coordinates
                        Polygon p1 = new Polygon();
                        p1.addPoint(1, 1);
                        p1.addPoint(2, 2);
                        p1.addPoint(3, 3);
                        
                        Polygon p2 = new Polygon();
                        p2.addPoint(1, 1);
                        p2.addPoint(2, 2); 
                        p2.addPoint(4, 4); // Different last point
                        
                        // Should return false since points are different
                        assertFalse(ShapeUtilities.equal(p1, p2));
                        
                        // Test with partially matching points
                        Polygon p3 = new Polygon();
                        p3.addPoint(1, 1);
                        p3.addPoint(5, 5); // Different middle point
                        p3.addPoint(3, 3);
                        
                        assertFalse(ShapeUtilities.equal(p1, p3));
                        
                        // Test with same points in different order
                        Polygon p4 = new Polygon();
                        p4.addPoint(3, 3);
                        p4.addPoint(2, 2);
                        p4.addPoint(1, 1);
                        
                        assertFalse(ShapeUtilities.equal(p1, p4));
                    }

    @Test
                    public void testEqual_ShouldDetectPathDifference_WhenMutatedLoopCondition() {
                        // Create two similar but not identical rectangles
                        Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                        Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 10, 20); // Different height
                        
                        // The original method should detect they're different by comparing their paths
                        assertFalse("Shapes should be different", ShapeUtilities.equal(rect1, rect2));
                        
                        // If the mutant is present (done = true), the method would skip path comparison
                        // and potentially return true incorrectly
                        // This test will fail if the mutant is present, thus detecting it
                    }

    @Test
                    public void testEqual_ShouldReturnTrueForEqualPaths() {
                        // Create two identical rectangles
                        Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                        Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                        
                        assertTrue("Identical shapes should be equal", ShapeUtilities.equal(rect1, rect2));
                    }

    @Test
            public void testEqualLine2D_DifferentPoints_ShouldReturnFalse() {
                // Create two lines with different points
                Line2D line1 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                Line2D line2 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(3, 3));
                
                // Also test with lines where only one point differs
                Line2D line3 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
                Line2D line4 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 3));
                
                // Original method should return false for both cases
                // Mutated method might return true due to premature termination
                assertFalse("Lines with different end points should not be equal", 
                    ShapeUtilities.equal(line1, line2));
                assertFalse("Lines with slightly different end points should not be equal",
                    ShapeUtilities.equal(line3, line4));
            }

    @Test
        public void testEqualLine2D_NullCases() {
            // Test null handling
            Line2D line1 = new Line2D.Double(new Point2D.Double(1, 1), new Point2D.Double(2, 2));
            
            assertTrue("Both null should be equal", 
                ShapeUtilities.equal((Line2D)null, (Line2D)null));
            assertFalse("Null and non-null should not be equal",
                ShapeUtilities.equal((Line2D)null, line1));
            assertFalse("Non-null and null should not be equal",
                ShapeUtilities.equal(line1, (Line2D)null));
        }

    @Test
        public void testEqual_Ellipse2D_NullCases() {
            // Test null cases which should still work
            assertTrue(ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
            
            Ellipse2D e = new Ellipse2D.Double(0, 0, 10, 10);
            assertFalse(ShapeUtilities.equal(e, (Ellipse2D) null));
            assertFalse(ShapeUtilities.equal((Ellipse2D) null, e));
        }

    @Test
        public void testEqualArc2D_NullCases1() {
            Arc2D arc = new Arc2D.Double(new Rectangle2D.Double(0, 0, 100, 100), 0, 90, Arc2D.OPEN);
            
            // Both null
            assertTrue("Two null arcs should be equal", 
                ShapeUtilities.equal((Arc2D) null, (Arc2D) null));
            
            // One null
            assertFalse("Non-null arc should not equal null arc", 
                ShapeUtilities.equal(arc, (Arc2D) null));
            assertFalse("Null arc should not equal non-null arc", 
                ShapeUtilities.equal((Arc2D) null, arc));
        }

    @Test
        public void testEqualPolygonsEdgeCases() {
            // Test with empty polygons
            Polygon empty1 = new Polygon();
            Polygon empty2 = new Polygon();
            assertTrue(ShapeUtilities.equal((Polygon)empty1, (Polygon)empty2));
            
            // Test with null cases
            assertTrue(ShapeUtilities.equal((Polygon)null, (Polygon)null));
            assertFalse(ShapeUtilities.equal((Polygon)new Polygon(), (Polygon)null));
            assertFalse(ShapeUtilities.equal((Polygon)null, (Polygon)new Polygon()));
            
            // Test with different point counts
            Polygon p1 = new Polygon(new int[]{1,2}, new int[]{1,2}, 2);
            Polygon p2 = new Polygon(new int[]{1,2,3}, new int[]{1,2,3}, 3);
            assertFalse(ShapeUtilities.equal((Polygon)p1, (Polygon)p2));
        }

    @Test
        public void testEqual_ShouldDetectDifferentWindingRules() {
            // Create two paths with different winding rules
            GeneralPath path1 = new GeneralPath(GeneralPath.WIND_NON_ZERO);
            path1.moveTo(0, 0);
            path1.lineTo(10, 0);
            path1.lineTo(10, 10);
            path1.closePath();
            
            GeneralPath path2 = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
            path2.moveTo(0, 0);
            path2.lineTo(10, 0);
            path2.lineTo(10, 10);
            path2.closePath();
            
            assertFalse("Different winding rules should return false", 
                       ShapeUtilities.equal(path1, path2));
        }

    @Test
    public void testEqual_ShouldHandleNullCases() {
        Shape rect = new Rectangle2D.Double(0, 0, 10, 10);
        
        assertTrue("Both null should return true", 
            ShapeUtilities.equal((Shape) null, (Shape) null));
        assertFalse("First null should return false", 
            ShapeUtilities.equal((Shape) null, rect));
        assertFalse("Second null should return false", 
            ShapeUtilities.equal(rect, (Shape) null));
    }


}
