package gentest.org.jfree.chart.renderer.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.*;
import java.awt.Color;
import java.awt.Paint;
import java.io.Serializable;
import org.jfree.chart.util.PublicCloneable;
 
public class GrayPaintScaleTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testGetPaint_WithDifferentBounds() {
                GrayPaintScale customScale = new GrayPaintScale(50.0, 150.0);
                Paint result = customScale.getPaint(100.0);
                assertTrue(result instanceof Color);
                Color color = (Color) result;
                // Expected: (100 - 50)/(150 - 50) * 255 = 127.5 -> rounded to 128
                assertEquals(128, color.getRed());
                assertEquals(128, color.getGreen());
                assertEquals(128, color.getBlue());
            }

    @Test
            public void testGetPaint_WithNegativeBounds() {
                GrayPaintScale negativeScale = new GrayPaintScale(-100.0, 0.0);
                Paint result = negativeScale.getPaint(-50.0);
                assertTrue(result instanceof Color);
                Color color = (Color) result;
                // Expected: (-50 - -100)/(0 - -100) * 255 = 127.5 -> rounded to 128
                assertEquals(128, color.getRed());
                assertEquals(128, color.getGreen());
                assertEquals(128, color.getBlue());
            }

    @Test
            public void testGetPaint_WithVerySmallRange() {
                GrayPaintScale smallScale = new GrayPaintScale(0.0, 0.1);
                Paint result = smallScale.getPaint(0.05);
                assertTrue(result instanceof Color);
                Color color = (Color) result;
                // Expected: (0.05 - 0)/(0.1 - 0) * 255 = 127.5 -> rounded to 128
                assertEquals(128, color.getRed());
                assertEquals(128, color.getGreen());
                assertEquals(128, color.getBlue());
            }

    @Test
            public void testConstructor_InvalidBoundsThrowsException() {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("Requires lowerBound < upperBound.");
                new GrayPaintScale(100.0, 50.0);
            }

    @Test
            public void testConstructor_EqualBoundsThrowsException() {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("Requires lowerBound < upperBound.");
                new GrayPaintScale(50.0, 50.0);
            }

    @Test
    public void testGetPaint_ValueAtLowerBound() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);  // Create scale with lowerBound=0.0 and upperBound=1.0
        Paint result = scale.getPaint(0.0);
        assertTrue(result instanceof Color);
        Color color = (Color) result;
        assertEquals(0, color.getRed());
        assertEquals(0, color.getGreen());
        assertEquals(0, color.getBlue());
    }

    @Test
    public void testGetPaint_ValueAtUpperBound() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0);
        Paint result = scale.getPaint(100.0);
        assertTrue(result instanceof Color);
        Color color = (Color) result;
        assertEquals(255, color.getRed());
        assertEquals(255, color.getGreen());
        assertEquals(255, color.getBlue());
    }

    @Test
    public void testGetPaint_ValueBelowLowerBound() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0); // Create scale with bounds 0-100
        Paint result = scale.getPaint(-10.0);
        assertTrue(result instanceof Color);
        Color color = (Color) result;
        assertEquals(0, color.getRed()); // Should clamp to lower bound
        assertEquals(0, color.getGreen());
        assertEquals(0, color.getBlue());
    }

    @Test
    public void testGetPaint_ValueAboveUpperBound() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0); // Create scale with bounds 0-100
        Paint result = scale.getPaint(150.0);
        assertTrue(result instanceof Color);
        Color color = (Color) result;
        assertEquals(255, color.getRed()); // Should clamp to upper bound
        assertEquals(255, color.getGreen());
        assertEquals(255, color.getBlue());
    }

    @Test
    public void testGetPaint_MidRangeValue() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0);
        Paint result = scale.getPaint(50.0);
        assertTrue(result instanceof Color);
        Color color = (Color) result;
        // Expected: (50 - 0)/(100 - 0) * 255 = 127.5 -> rounded to 128
        assertEquals(128, color.getRed());
        assertEquals(128, color.getGreen());
        assertEquals(128, color.getBlue());
    }

    @Test
    public void testGetPaint_ExactQuarterValue() {
        GrayPaintScale scale = new GrayPaintScale(0.0, 100.0);  // Create scale instance with bounds
        Paint result = scale.getPaint(25.0);
        assertTrue(result instanceof Color);
        Color color = (Color) result;
        // Expected: (25 - 0)/(100 - 0) * 255 = 63.75 -> rounded to 64
        assertEquals(64, color.getRed());
        assertEquals(64, color.getGreen());
        assertEquals(64, color.getBlue());
    }


}
