package gentest.org.jfree.chart.block.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.block.*;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
 
public class BorderArrangementTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                        public void testArrangeFF_AllBlocksPresent() throws Exception {
                                                                            // Setup
                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                            RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                            
                                                                            Block topBlock = mock(Block.class);
                                                                            Block bottomBlock = mock(Block.class);
                                                                            Block leftBlock = mock(Block.class);
                                                                            Block rightBlock = mock(Block.class);
                                                                            Block centerBlock = mock(Block.class);
                                                                            
                                                                            // Use reflection to set private fields
                                                                            Field topBlockField = BorderArrangement.class.getDeclaredField("topBlock");
                                                                            topBlockField.setAccessible(true);
                                                                            topBlockField.set(arrangement, topBlock);
                                                                            
                                                                            Field bottomBlockField = BorderArrangement.class.getDeclaredField("bottomBlock");
                                                                            bottomBlockField.setAccessible(true);
                                                                            bottomBlockField.set(arrangement, bottomBlock);
                                                                            
                                                                            Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                                                            leftBlockField.setAccessible(true);
                                                                            leftBlockField.set(arrangement, leftBlock);
                                                                            
                                                                            Field rightBlockField = BorderArrangement.class.getDeclaredField("rightBlock");
                                                                            rightBlockField.setAccessible(true);
                                                                            rightBlockField.set(arrangement, rightBlock);
                                                                            
                                                                            Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
                                                                            centerBlockField.setAccessible(true);
                                                                            centerBlockField.set(arrangement, centerBlock);
                                                                            
                                                                            // Mock arrangements
                                                                            when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                                                .thenReturn(new Size2D(100.0, 20.0));
                                                                            when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                                                .thenReturn(new Size2D(100.0, 30.0));
                                                                            when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                                                .thenReturn(new Size2D(25.0, 150.0));
                                                                            when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                                                .thenReturn(new Size2D(25.0, 150.0));
                                                                            
                                                                            // Use reflection to access protected method
                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                            arrangeFFMethod.setAccessible(true);
                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                            
                                                                            // Verify
                                                                            assertEquals(100.0, result.getWidth(), 0.001);
                                                                            assertEquals(200.0, result.getHeight(), 0.001);
                                                                            
                                                                            // Verify bounds set correctly
                                                                            verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
                                                                            verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 170.0, 100.0, 30.0));
                                                                            verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 25.0, 150.0));
                                                                            verify(rightBlock).setBounds(new Rectangle2D.Double(75.0, 20.0, 25.0, 150.0));
                                                                            verify(centerBlock).setBounds(new Rectangle2D.Double(25.0, 20.0, 50.0, 150.0));
                                                                        }

    @Test
                                                                        public void testArrangeFF_OnlyCenterBlock() throws Exception {
                                                                            // Setup
                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                            RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                            
                                                                            Block centerBlock = mock(Block.class);
                                                                            
                                                                            // Use reflection to set private centerBlock field
                                                                            Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
                                                                            centerBlockField.setAccessible(true);
                                                                            centerBlockField.set(arrangement, centerBlock);
                                                                            
                                                                            // Use reflection to access protected arrangeFF method
                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                            arrangeFFMethod.setAccessible(true);
                                                                            
                                                                            // Execute
                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                            
                                                                            // Verify
                                                                            assertEquals(100.0, result.getWidth(), 0.001);
                                                                            assertEquals(200.0, result.getHeight(), 0.001);
                                                                            
                                                                            // Verify center block takes full space
                                                                            verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 200.0));
                                                                        }

    @Test
                                                                        public void testArrangeFF_LeftAndRightBlocksOnly() throws Exception {
                                                                            // Setup
                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                            RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                            
                                                                            Block leftBlock = mock(Block.class);
                                                                            Block rightBlock = mock(Block.class);
                                                                            
                                                                            // Use reflection to set private fields
                                                                            Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                                                            leftBlockField.setAccessible(true);
                                                                            leftBlockField.set(arrangement, leftBlock);
                                                                            
                                                                            Field rightBlockField = BorderArrangement.class.getDeclaredField("rightBlock");
                                                                            rightBlockField.setAccessible(true);
                                                                            rightBlockField.set(arrangement, rightBlock);
                                                                            
                                                                            // Mock arrangements
                                                                            when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                                                .thenReturn(new Size2D(30.0, 200.0));
                                                                            when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                                                .thenReturn(new Size2D(30.0, 200.0));
                                                                            
                                                                            // Use reflection to access protected method
                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                            arrangeFFMethod.setAccessible(true);
                                                                            
                                                                            // Execute
                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                            
                                                                            // Verify
                                                                            assertEquals(100.0, result.getWidth(), 0.001);
                                                                            assertEquals(200.0, result.getHeight(), 0.001);
                                                                            
                                                                            // Verify bounds
                                                                            verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 30.0, 200.0));
                                                                            verify(rightBlock).setBounds(new Rectangle2D.Double(70.0, 0.0, 30.0, 200.0));
                                                                        }

    @Test
                                                                        public void testArrangeFF_EmptyArrangement() throws Exception {
                                                                            // Setup
                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                            RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                            
                                                                            // Use reflection to access protected method
                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                            arrangeFFMethod.setAccessible(true);
                                                                            
                                                                            // Execute
                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                            
                                                                            // Verify
                                                                            assertEquals(100.0, result.getWidth(), 0.001);
                                                                            assertEquals(200.0, result.getHeight(), 0.001);
                                                                            
                                                                            // No blocks to verify
                                                                        }

    @Test
                                                                        public void testArrangeFF_ZeroDimensionConstraint() throws Exception {
                                                                            // Setup
                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                            RectangleConstraint constraint = new RectangleConstraint(0.0, 0.0);
                                                                            
                                                                            Block centerBlock = mock(Block.class);
                                                                            
                                                                            // Use reflection to set private centerBlock field
                                                                            Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
                                                                            centerBlockField.setAccessible(true);
                                                                            centerBlockField.set(arrangement, centerBlock);
                                                                            
                                                                            // Use reflection to access protected arrangeFF method
                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                            arrangeFFMethod.setAccessible(true);
                                                                            
                                                                            // Execute
                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                            
                                                                            // Verify
                                                                            assertEquals(0.0, result.getWidth(), 0.001);
                                                                            assertEquals(0.0, result.getHeight(), 0.001);
                                                                            
                                                                            // Verify center block gets zero dimension
                                                                            verify(centerBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 0.0, 0.0));
                                                                        }

    @Test
                                                                        public void testArrangeFF_WithNullConstraint() throws Exception {
                                                                            // Setup
                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                            
                                                                            thrown.expect(IllegalArgumentException.class);
                                                                            
                                                                            // Get the protected method using reflection
                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                                "arrangeFF", 
                                                                                BlockContainer.class, 
                                                                                Graphics2D.class, 
                                                                                RectangleConstraint.class
                                                                            );
                                                                            arrangeFFMethod.setAccessible(true);
                                                                            
                                                                            // Execute
                                                                            arrangeFFMethod.invoke(arrangement, null, g2, null);
                                                                        }

    @Test
                                                                    public void testArrangeFF_TopAndBottomBlocksOnly() throws Exception {
                                                                        // Setup
                                                                        BorderArrangement arrangement = new BorderArrangement();
                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                        
                                                                        Block topBlock = mock(Block.class);
                                                                        Block bottomBlock = mock(Block.class);
                                                                        
                                                                        // Use reflection to set private fields
                                                                        Field topBlockField = BorderArrangement.class.getDeclaredField("topBlock");
                                                                        topBlockField.setAccessible(true);
                                                                        topBlockField.set(arrangement, topBlock);
                                                                        
                                                                        Field bottomBlockField = BorderArrangement.class.getDeclaredField("bottomBlock");
                                                                        bottomBlockField.setAccessible(true);
                                                                        bottomBlockField.set(arrangement, bottomBlock);
                                                                        
                                                                        // Mock arrangements
                                                                        when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                                            .thenReturn(new Size2D(100.0, 30.0));
                                                                        when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                                            .thenReturn(new Size2D(100.0, 40.0));
                                                                        
                                                                        // Use reflection to access protected method
                                                                        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                        arrangeFFMethod.setAccessible(true);
                                                                        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                        
                                                                        // Verify
                                                                        assertEquals(100.0, result.getWidth(), 0.001);
                                                                        assertEquals(200.0, result.getHeight(), 0.001);
                                                                        
                                                                        // Verify bounds
                                                                        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 30.0));
                                                                        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 160.0, 100.0, 40.0));
                                                                    }

    @Test
                                                    public void testArrangeFF_DetectsRightBlockWidthConstraintMutation() throws Exception {
                                                        // Setup
                                                        BorderArrangement arrangement = new BorderArrangement();
                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                        
                                                        // Create a tight constraint where available width for right block would be < 1.0
                                                        RectangleConstraint constraint = new RectangleConstraint(1.5, 10.0);
                                                        
                                                        // Mock blocks
                                                        Block leftBlock = mock(Block.class);
                                                        Block rightBlock = mock(Block.class);
                                                        
                                                        // Set up arrangement with left and right blocks
                                                        arrangement.add(leftBlock, RectangleEdge.LEFT);
                                                        arrangement.add(rightBlock, RectangleEdge.RIGHT);
                                                        
                                                        // Configure mock behaviors
                                                        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                            .thenReturn(new Size2D(1.0, 5.0)); // left block takes 1.0 width
                                                        when(rightBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                                            .thenReturn(new Size2D(0.4, 5.0)); // right block would take 0.4 width
                                                        
                                                        // Create container
                                                        BlockContainer container = new BlockContainer();
                                                        
                                                        // Use reflection to call protected arrangeFF method
                                                        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                        arrangeFFMethod.setAccessible(true);
                                                        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
                                                        
                                                        // Verify right block arrangement - should be called with width range allowing 0.0
                                                        verify(rightBlock).arrange(any(Graphics2D.class), any(RectangleConstraint.class));
                                                        
                                                        // Get all constraints passed to rightBlock.arrange()
                                                        List<RectangleConstraint> constraints = new ArrayList<>();
                                                        verify(rightBlock, atLeastOnce()).arrange(
                                                            any(Graphics2D.class), 
                                                            argThat(rc -> {
                                                                constraints.add(rc);
                                                                return true;
                                                            })
                                                        );
                                                        
                                                        // Assert the constraint passed to rightBlock.arrange()
                                                        RectangleConstraint actualConstraint = constraints.get(0);
                                                        assertEquals(0.0, actualConstraint.getWidth(), 0.0001); // Original expects 0.0, mutant would fail this
                                                        assertEquals(0.0, actualConstraint.getWidthRange().getLowerBound(), 0.0001);
                                                        assertEquals(0.5, actualConstraint.getWidthRange().getUpperBound(), 0.0001); // 1.5 total - 1.0 left = 0.5 available
                                                        
                                                        // Verify final bounds setting
                                                        verify(rightBlock).setBounds(argThat(rect -> 
                                                            rect.getWidth() <= 0.5 && rect.getWidth() >= 0.0)); // Should accept any width in range
                                                    }

    @Test
                                    public void testArrangeFF_LeftBlockWidthConstraint() throws Exception {
                                        // Setup test objects
                                        BorderArrangement arrangement = new BorderArrangement();
                                        BlockContainer container = mock(BlockContainer.class);
                                        Graphics2D g2 = mock(Graphics2D.class);
                                        
                                        // Create a constraint with fixed width and height
                                        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                        
                                        // Mock left block that wants to occupy 30 width
                                        Block leftBlock = mock(Block.class);
                                        when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                                            .thenReturn(new Size2D(30.0, 50.0));
                                        
                                        // Use reflection to set private leftBlock field
                                        Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                        leftBlockField.setAccessible(true);
                                        leftBlockField.set(arrangement, leftBlock);
                                        
                                        // Use reflection to call protected arrangeFF method
                                        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                            "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                        arrangeFFMethod.setAccessible(true);
                                        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
                                        
                                        // Verify left block was arranged with RANGE constraint (original behavior)
                                        org.mockito.ArgumentCaptor<RectangleConstraint> constraintCaptor = 
                                            org.mockito.ArgumentCaptor.forClass(RectangleConstraint.class);
                                        verify(leftBlock).arrange(eq(g2), constraintCaptor.capture());
                                        
                                        // Assert the constraint type for width is RANGE (original behavior)
                                        assertEquals(LengthConstraintType.RANGE, 
                                            constraintCaptor.getValue().getWidthConstraintType());
                                        
                                        // Verify the left block got its requested width (30)
                                        org.mockito.ArgumentCaptor<java.awt.geom.Rectangle2D> boundsCaptor = 
                                            org.mockito.ArgumentCaptor.forClass(java.awt.geom.Rectangle2D.class);
                                        verify(leftBlock).setBounds(boundsCaptor.capture());
                                        assertEquals(30.0, boundsCaptor.getValue().getWidth(), 0.001);
                                        
                                        // Verify overall result
                                        assertEquals(100.0, result.getWidth(), 0.001);
                                        assertEquals(200.0, result.getHeight(), 0.001);
                                    }

    @Test
                public void testArrangeFF_LeftBlockHeightConstraint() throws Exception {
                    // Imports needed (normally at class level)
                    // import org.mockito.ArgumentCaptor;
                    // import java.awt.geom.Rectangle2D;
                    
                    // Setup
                    BorderArrangement arrangement = new BorderArrangement();
                    Graphics2D g2 = mock(Graphics2D.class);
                    RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                    
                    // Create mock blocks with known sizes
                    Block topBlock = mock(Block.class);
                    Block bottomBlock = mock(Block.class);
                    Block leftBlock = mock(Block.class);
                    
                    // Stub arrange methods to return specific sizes
                    when(topBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                        .thenReturn(new Size2D(100.0, 50.0));
                    when(bottomBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                        .thenReturn(new Size2D(100.0, 30.0));
                    when(leftBlock.arrange(any(Graphics2D.class), any(RectangleConstraint.class)))
                        .thenReturn(new Size2D(40.0, 120.0));
                    
                    // Add blocks to arrangement
                    arrangement.add(topBlock, "TOP");
                    arrangement.add(bottomBlock, "BOTTOM");
                    arrangement.add(leftBlock, "LEFT");
                    
                    // Expected middle height = total height (200) - top (50) - bottom (30) = 120
                    double expectedMiddleHeight = 120.0;
                    
                    // Create container
                    BlockContainer container = new BlockContainer(arrangement);
                    
                    // Act - use reflection to call protected method
                    Method arrangeFF = BorderArrangement.class.getDeclaredMethod(
                        "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                    arrangeFF.setAccessible(true);
                    arrangeFF.invoke(arrangement, container, g2, constraint);
                    
                    // Verify left block was arranged with correct height constraint
                    org.mockito.ArgumentCaptor<RectangleConstraint> constraintCaptor = 
                        org.mockito.ArgumentCaptor.forClass(RectangleConstraint.class);
                    verify(leftBlock).arrange(eq(g2), constraintCaptor.capture());
                    
                    // Assert the height constraint used was for the middle section (h[2])
                    assertEquals(expectedMiddleHeight, constraintCaptor.getValue().getHeight(), 0.001);
                    
                    // Also verify bounds were set correctly
                    org.mockito.ArgumentCaptor<java.awt.geom.Rectangle2D> boundsCaptor = 
                        org.mockito.ArgumentCaptor.forClass(java.awt.geom.Rectangle2D.class);
                    verify(leftBlock).setBounds(boundsCaptor.capture());
                    assertEquals(expectedMiddleHeight, boundsCaptor.getValue().getHeight(), 0.001);
                }

    @Test
    public void testArrangeFF_CenterBlockFixedConstraint() throws Exception {
        // Setup
        BorderArrangement arrangement = new BorderArrangement();
        Graphics2D g2 = mock(Graphics2D.class);
        BlockContainer container = mock(BlockContainer.class);
        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
        
        // Create and set center block using reflection
        Block centerBlock = mock(Block.class);
        Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
        centerBlockField.setAccessible(true);
        centerBlockField.set(arrangement, centerBlock);
        
        // Expected dimensions calculations
        double[] w = new double[5];
        double[] h = new double[5];
        w[0] = constraint.getWidth(); // 100
        h[0] = 0; // topBlock is null
        h[1] = 0; // bottomBlock is null
        h[2] = constraint.getHeight(); // 200 - 0 - 0
        w[2] = 0; // leftBlock is null
        w[3] = 0; // rightBlock is null
        w[4] = constraint.getWidth() - w[3] - w[2]; // 100 - 0 - 0 = 100
        h[4] = h[2]; // 200
        
        // Mock center block arrangement
        Size2D centerSize = new Size2D(w[4], h[4]);
        when(centerBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(centerSize);
        
        // Test using reflection to call protected method
        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", 
            BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
        arrangeFFMethod.setAccessible(true);
        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
        
        // Verify center block was arranged with FIXED constraint
        verify(centerBlock).arrange(g2, new RectangleConstraint(w[4], h[4]));
        
        // Verify overall result
        assertEquals(constraint.getWidth(), result.getWidth(), 0.001);
        assertEquals(constraint.getHeight(), result.getHeight(), 0.001);
    }


}
