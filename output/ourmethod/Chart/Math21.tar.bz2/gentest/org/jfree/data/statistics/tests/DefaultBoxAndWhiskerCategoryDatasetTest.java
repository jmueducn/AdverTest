package gentest.org.jfree.data.statistics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.statistics.*;
import java.util.List;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.data.KeyedObjects2D;
import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.general.AbstractDataset;
 
public class DefaultBoxAndWhiskerCategoryDatasetTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                        public void testAdd_FirstItemUpdatesBounds() {
                                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item.getMinOutlier()).thenReturn(10.0);
                                                                                                                            when(item.getMaxOutlier()).thenReturn(20.0);
                                                                                                                            
                                                                                                                            Comparable rowKey = "Row1";
                                                                                                                            Comparable columnKey = "Column1";
                                                                                                                            
                                                                                                                            dataset.add(item, rowKey, columnKey);
                                                                                                                            
                                                                                                                            assertEquals(10.0, dataset.getRangeBounds(false).getLowerBound(), 0.0001);
                                                                                                                            assertEquals(20.0, dataset.getRangeBounds(false).getUpperBound(), 0.0001);
                                                                                                                            assertEquals(0, dataset.getRowIndex(rowKey));
                                                                                                                            assertEquals(0, dataset.getColumnIndex(columnKey));
                                                                                                                        }

    @Test
                                                                                                                        public void testAdd_NewMinOutlierUpdatesBounds() {
                                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                            
                                                                                                                            // Add first item
                                                                                                                            BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item1.getMinOutlier()).thenReturn(10.0);
                                                                                                                            when(item1.getMaxOutlier()).thenReturn(20.0);
                                                                                                                            dataset.add(item1, "Row1", "Column1");
                                                                                                                            
                                                                                                                            // Add second item with smaller min outlier
                                                                                                                            BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item2.getMinOutlier()).thenReturn(5.0);
                                                                                                                            when(item2.getMaxOutlier()).thenReturn(15.0);
                                                                                                                            dataset.add(item2, "Row2", "Column1");
                                                                                                                            
                                                                                                                            assertEquals(5.0, dataset.getRangeBounds(false).getLowerBound(), 0.0001);
                                                                                                                            assertEquals(20.0, dataset.getRangeBounds(false).getUpperBound(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testAdd_NewMaxOutlierUpdatesBounds() {
                                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                            
                                                                                                                            // Add first item
                                                                                                                            BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item1.getMinOutlier()).thenReturn(10.0);
                                                                                                                            when(item1.getMaxOutlier()).thenReturn(20.0);
                                                                                                                            dataset.add(item1, "Row1", "Column1");
                                                                                                                            
                                                                                                                            // Add second item with larger max outlier
                                                                                                                            BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item2.getMinOutlier()).thenReturn(15.0);
                                                                                                                            when(item2.getMaxOutlier()).thenReturn(25.0);
                                                                                                                            dataset.add(item2, "Row1", "Column2");
                                                                                                                            
                                                                                                                            assertEquals(10.0, dataset.getRangeBounds(false).getLowerBound(), 0.0001);
                                                                                                                            assertEquals(25.0, dataset.getRangeBounds(false).getUpperBound(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testAdd_ItemWithNullOutliers() {
                                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item.getMinOutlier()).thenReturn(null);
                                                                                                                            when(item.getMaxOutlier()).thenReturn(null);
                                                                                                                            
                                                                                                                            dataset.add(item, "Row1", "Column1");
                                                                                                                            
                                                                                                                            assertTrue(Double.isNaN(dataset.getRangeBounds(false).getLowerBound()));
                                                                                                                            assertTrue(Double.isNaN(dataset.getRangeBounds(false).getUpperBound()));
                                                                                                                        }

    @Test
                                                                                                                        public void testAdd_ItemToExistingMinMaxPositionTriggersUpdateBounds() {
                                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                            
                                                                                                                            // Add first item that becomes min and max
                                                                                                                            BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item1.getMinOutlier()).thenReturn(10.0);
                                                                                                                            when(item1.getMaxOutlier()).thenReturn(20.0);
                                                                                                                            dataset.add(item1, "Row1", "Column1");
                                                                                                                            
                                                                                                                            // Add new item at same position (should trigger updateBounds)
                                                                                                                            BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item2.getMinOutlier()).thenReturn(15.0);
                                                                                                                            when(item2.getMaxOutlier()).thenReturn(25.0);
                                                                                                                            dataset.add(item2, "Row1", "Column1");
                                                                                                                            
                                                                                                                            // Verify bounds were updated (though we can't directly test updateBounds was called)
                                                                                                                            assertEquals(15.0, dataset.getRangeBounds(false).getLowerBound(), 0.0001);
                                                                                                                            assertEquals(25.0, dataset.getRangeBounds(false).getUpperBound(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testAdd_MultipleItemsWithVariousOutliers() {
                                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                            
                                                                                                                            // Add items in random order
                                                                                                                            BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item1.getMinOutlier()).thenReturn(5.0);
                                                                                                                            when(item1.getMaxOutlier()).thenReturn(15.0);
                                                                                                                            dataset.add(item1, "Row1", "Column1");
                                                                                                                            
                                                                                                                            BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item2.getMinOutlier()).thenReturn(10.0);
                                                                                                                            when(item2.getMaxOutlier()).thenReturn(30.0);
                                                                                                                            dataset.add(item2, "Row2", "Column1");
                                                                                                                            
                                                                                                                            BoxAndWhiskerItem item3 = mock(BoxAndWhiskerItem.class);
                                                                                                                            when(item3.getMinOutlier()).thenReturn(3.0);
                                                                                                                            when(item3.getMaxOutlier()).thenReturn(20.0);
                                                                                                                            dataset.add(item3, "Row1", "Column2");
                                                                                                                            
                                                                                                                            assertEquals(3.0, dataset.getRangeBounds(false).getLowerBound(), 0.0001);
                                                                                                                            assertEquals(30.0, dataset.getRangeBounds(false).getUpperBound(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testAdd_NullRowKeyThrowsException() {
                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                                                                            dataset.add(item, null, "Column1");
                                                                                                                        }

    @Test
                                                                                                                        public void testAdd_NullColumnKeyThrowsException() {
                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                                                                            dataset.add(item, "Row1", null);
                                                                                                                        }

    @Test
                                                                                                                public void testAdd_WithValidListAndKeys() {
                                                                                                                    // Setup
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    List<Double> values = new ArrayList<Double>();
                                                                                                                    values.add(1.0);
                                                                                                                    values.add(2.0);
                                                                                                                    values.add(3.0);
                                                                                                                    values.add(4.0);
                                                                                                                    values.add(5.0);
                                                                                                                    
                                                                                                                    Comparable<String> rowKey = "Row1";
                                                                                                                    Comparable<String> columnKey = "Column1";
                                                                                                                
                                                                                                                    // Execute
                                                                                                                    dataset.add(values, rowKey, columnKey);
                                                                                                                
                                                                                                                    // Verify
                                                                                                                    assertEquals(1, dataset.getRowCount());
                                                                                                                    assertEquals(1, dataset.getColumnCount());
                                                                                                                    assertEquals(rowKey, dataset.getRowKey(0));
                                                                                                                    assertEquals(columnKey, dataset.getColumnKey(0));
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem item = dataset.getItem(0, 0);
                                                                                                                    assertNotNull(item);
                                                                                                                    assertEquals(3.0, item.getMedian().doubleValue(), 0.001);
                                                                                                                }

    @Test
                                                                                                                public void testAdd_WithEmptyList() {
                                                                                                                    // Setup
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    List<Double> emptyList = new ArrayList<Double>();
                                                                                                                    Comparable<String> rowKey = "Row1";
                                                                                                                    Comparable<String> columnKey = "Column1";
                                                                                                                
                                                                                                                    // Execute
                                                                                                                    dataset.add(emptyList, rowKey, columnKey);
                                                                                                                
                                                                                                                    // Verify
                                                                                                                    BoxAndWhiskerItem item = dataset.getItem(0, 0);
                                                                                                                    assertNotNull(item);
                                                                                                                    assertTrue(Double.isNaN(item.getMean().doubleValue()));
                                                                                                                    assertTrue(Double.isNaN(item.getMedian().doubleValue()));
                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                public void testAdd_WithNullRowKey() {
                                                                                                                    // Setup
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    List<Double> values = new ArrayList<>();
                                                                                                                    values.add(1.0);
                                                                                                                    Comparable columnKey = "Column1";
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    dataset.add(values, null, columnKey);
                                                                                                                }

    @Test
                                                                                                                public void testAdd_WithNullColumnKey() {
                                                                                                                    // Setup
                                                                                                                    List<Double> values = new ArrayList<>();
                                                                                                                    values.add(1.0);
                                                                                                                    Comparable<String> rowKey = "Row1";
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    
                                                                                                                    // Expected exception setup
                                                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    dataset.add(values, rowKey, null);
                                                                                                                }

    @Test
                                                                                                                public void testAdd_UpdatesRangeBounds() {
                                                                                                                    // Setup
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    List<Double> values1 = new ArrayList<Double>();
                                                                                                                    values1.add(1.0);
                                                                                                                    values1.add(2.0);
                                                                                                                    values1.add(3.0);
                                                                                                                    
                                                                                                                    List<Double> values2 = new ArrayList<Double>();
                                                                                                                    values2.add(10.0);
                                                                                                                    values2.add(20.0);
                                                                                                                    values2.add(30.0);
                                                                                                                
                                                                                                                    Comparable<String> rowKey1 = "Row1";
                                                                                                                    Comparable<String> columnKey1 = "Column1";
                                                                                                                    Comparable<String> rowKey2 = "Row2";
                                                                                                                    Comparable<String> columnKey2 = "Column2";
                                                                                                                
                                                                                                                    // Execute
                                                                                                                    dataset.add(values1, rowKey1, columnKey1);
                                                                                                                    dataset.add(values2, rowKey2, columnKey2);
                                                                                                                
                                                                                                                    // Verify range bounds were updated
                                                                                                                    Range range = dataset.getRangeBounds(false);
                                                                                                                    assertEquals(1.0, range.getLowerBound(), 0.001);
                                                                                                                    assertEquals(30.0, range.getUpperBound(), 0.001);
                                                                                                                }

    @Test
                                                                                                                public void testAdd_WithDuplicateKeysOverwritesExisting() {
                                                                                                                    // Setup
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    List<Double> values1 = new ArrayList<Double>();
                                                                                                                    values1.add(1.0);
                                                                                                                    values1.add(2.0);
                                                                                                                    values1.add(3.0);
                                                                                                                    
                                                                                                                    List<Double> values2 = new ArrayList<Double>();
                                                                                                                    values2.add(10.0);
                                                                                                                    values2.add(20.0);
                                                                                                                    values2.add(30.0);
                                                                                                                
                                                                                                                    Comparable<String> rowKey = "Row1";
                                                                                                                    Comparable<String> columnKey = "Column1";
                                                                                                                
                                                                                                                    // Execute
                                                                                                                    dataset.add(values1, rowKey, columnKey);
                                                                                                                    dataset.add(values2, rowKey, columnKey);
                                                                                                                
                                                                                                                    // Verify only one item exists and it's the second one
                                                                                                                    assertEquals(1, dataset.getRowCount());
                                                                                                                    assertEquals(1, dataset.getColumnCount());
                                                                                                                    BoxAndWhiskerItem item = dataset.getItem(0, 0);
                                                                                                                    assertEquals(20.0, item.getMedian().doubleValue(), 0.001);
                                                                                                                }

    @Test
                                                                                                                public void testAdd_WithExtremeValues() {
                                                                                                                    // Setup
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    List<Double> values = new ArrayList<>();
                                                                                                                    values.add(Double.MAX_VALUE);
                                                                                                                    values.add(Double.MIN_VALUE);
                                                                                                                    values.add(Double.NaN);
                                                                                                                    values.add(Double.POSITIVE_INFINITY);
                                                                                                                    values.add(Double.NEGATIVE_INFINITY);
                                                                                                                    
                                                                                                                    Comparable<String> rowKey = "Row1";
                                                                                                                    Comparable<String> columnKey = "Column1";
                                                                                                                
                                                                                                                    // Execute
                                                                                                                    dataset.add(values, rowKey, columnKey);
                                                                                                                
                                                                                                                    // Verify
                                                                                                                    BoxAndWhiskerItem item = dataset.getItem(0, 0);
                                                                                                                    assertNotNull(item);
                                                                                                                    assertTrue(Double.isInfinite(item.getMaxOutlier().doubleValue()));
                                                                                                                    assertTrue(Double.isInfinite(item.getMinOutlier().doubleValue()));
                                                                                                                }

    @Test
                                                                                                                public void testAdd_NullItemThrowsException() {
                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    dataset.add((BoxAndWhiskerItem) null, "Row1", "Column1");
                                                                                                                }

    @Test
                                                                                                                public void testUpdateBounds_EmptyDataset() throws Exception {
                                                                                                                    // Create a new dataset instance
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    
                                                                                                                    // Mock getRowCount and getColumnCount to return 0 for empty dataset
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                                                                                    when(spyDataset.getRowCount()).thenReturn(0);
                                                                                                                    when(spyDataset.getColumnCount()).thenReturn(0);
                                                                                                                
                                                                                                                    // Use reflection to call private updateBounds method
                                                                                                                    Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                                                                                    updateBoundsMethod.setAccessible(true);
                                                                                                                    updateBoundsMethod.invoke(spyDataset);
                                                                                                                
                                                                                                                    // Use reflection to access private fields for assertions
                                                                                                                    Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                                                    minValueField.setAccessible(true);
                                                                                                                    Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                                                    minRowField.setAccessible(true);
                                                                                                                    Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                                                    minColField.setAccessible(true);
                                                                                                                    Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                                                                    maxValueField.setAccessible(true);
                                                                                                                    Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                                                                    maxRowField.setAccessible(true);
                                                                                                                    Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                                                                    maxColField.setAccessible(true);
                                                                                                                
                                                                                                                    // Assert the values
                                                                                                                    assertTrue(Double.isNaN((Double) minValueField.get(spyDataset)));
                                                                                                                    assertEquals(-1, minRowField.get(spyDataset));
                                                                                                                    assertEquals(-1, minColField.get(spyDataset));
                                                                                                                    assertTrue(Double.isNaN((Double) maxValueField.get(spyDataset)));
                                                                                                                    assertEquals(-1, maxRowField.get(spyDataset));
                                                                                                                    assertEquals(-1, maxColField.get(spyDataset));
                                                                                                                }

    @Test
                                                                                                                public void testUpdateBounds_SingleItemWithValidOutliers() throws Exception {
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                                                                                    
                                                                                                                    // Setup mock behavior
                                                                                                                    when(spyDataset.getRowCount()).thenReturn(1);
                                                                                                                    when(spyDataset.getColumnCount()).thenReturn(1);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem mockItem = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(mockItem.getMinOutlier()).thenReturn(5.0);
                                                                                                                    when(mockItem.getMaxOutlier()).thenReturn(15.0);
                                                                                                                    when(spyDataset.getItem(0, 0)).thenReturn(mockItem);
                                                                                                                
                                                                                                                    // Use reflection to call private updateBounds method
                                                                                                                    Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                                                                                    updateBoundsMethod.setAccessible(true);
                                                                                                                    updateBoundsMethod.invoke(spyDataset);
                                                                                                                
                                                                                                                    // Use reflection to access private fields
                                                                                                                    Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                                                    minValueField.setAccessible(true);
                                                                                                                    Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                                                    minRowField.setAccessible(true);
                                                                                                                    Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                                                    minColField.setAccessible(true);
                                                                                                                    Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                                                                    maxValueField.setAccessible(true);
                                                                                                                    Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                                                                    maxRowField.setAccessible(true);
                                                                                                                    Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                                                                    maxColField.setAccessible(true);
                                                                                                                
                                                                                                                    assertEquals(5.0, (Double)minValueField.get(spyDataset), 0.0001);
                                                                                                                    assertEquals(0, minRowField.get(spyDataset));
                                                                                                                    assertEquals(0, minColField.get(spyDataset));
                                                                                                                    assertEquals(15.0, (Double)maxValueField.get(spyDataset), 0.0001);
                                                                                                                    assertEquals(0, maxRowField.get(spyDataset));
                                                                                                                    assertEquals(0, maxColField.get(spyDataset));
                                                                                                                }

    @Test
                                                                                                                public void testUpdateBounds_SomeItemsWithNullOutliers() throws Exception {
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                                                                                    
                                                                                                                    when(spyDataset.getRowCount()).thenReturn(2);
                                                                                                                    when(spyDataset.getColumnCount()).thenReturn(2);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(item1.getMinOutlier()).thenReturn(null);
                                                                                                                    when(item1.getMaxOutlier()).thenReturn(20.0);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(item2.getMinOutlier()).thenReturn(5.0);
                                                                                                                    when(item2.getMaxOutlier()).thenReturn(null);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem item3 = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(item3.getMinOutlier()).thenReturn(3.0);
                                                                                                                    when(item3.getMaxOutlier()).thenReturn(15.0);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem item4 = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(item4.getMinOutlier()).thenReturn(null);
                                                                                                                    when(item4.getMaxOutlier()).thenReturn(null);
                                                                                                                    
                                                                                                                    when(spyDataset.getItem(0, 0)).thenReturn(item1);
                                                                                                                    when(spyDataset.getItem(0, 1)).thenReturn(item2);
                                                                                                                    when(spyDataset.getItem(1, 0)).thenReturn(item3);
                                                                                                                    when(spyDataset.getItem(1, 1)).thenReturn(item4);
                                                                                                                
                                                                                                                    // Use reflection to call private updateBounds method
                                                                                                                    Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class
                                                                                                                            .getDeclaredMethod("updateBounds");
                                                                                                                    updateBoundsMethod.setAccessible(true);
                                                                                                                    updateBoundsMethod.invoke(spyDataset);
                                                                                                                
                                                                                                                    // Use reflection to access private fields
                                                                                                                    Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                                                                            .getDeclaredField("minimumRangeValue");
                                                                                                                    minValueField.setAccessible(true);
                                                                                                                    Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                                                                            .getDeclaredField("minimumRangeValueRow");
                                                                                                                    minRowField.setAccessible(true);
                                                                                                                    Field minColField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                                                                            .getDeclaredField("minimumRangeValueColumn");
                                                                                                                    minColField.setAccessible(true);
                                                                                                                    Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                                                                            .getDeclaredField("maximumRangeValue");
                                                                                                                    maxValueField.setAccessible(true);
                                                                                                                    Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                                                                            .getDeclaredField("maximumRangeValueRow");
                                                                                                                    maxRowField.setAccessible(true);
                                                                                                                    Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class
                                                                                                                            .getDeclaredField("maximumRangeValueColumn");
                                                                                                                    maxColField.setAccessible(true);
                                                                                                                
                                                                                                                    // Should only consider items with non-null outliers
                                                                                                                    assertEquals(3.0, (Double)minValueField.get(spyDataset), 0.0001);
                                                                                                                    assertEquals(1, minRowField.get(spyDataset)); // row index of item3
                                                                                                                    assertEquals(0, minColField.get(spyDataset)); // column index of item3
                                                                                                                    assertEquals(20.0, (Double)maxValueField.get(spyDataset), 0.0001);
                                                                                                                    assertEquals(0, maxRowField.get(spyDataset)); // row index of item1
                                                                                                                    assertEquals(0, maxColField.get(spyDataset)); // column index of item1
                                                                                                                }

    @Test
                                                                                                                public void testUpdateBounds_ItemsWithNaNOutliers() throws Exception {
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                                                                                    
                                                                                                                    when(spyDataset.getRowCount()).thenReturn(2);
                                                                                                                    when(spyDataset.getColumnCount()).thenReturn(1);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(item1.getMinOutlier()).thenReturn(Double.NaN);
                                                                                                                    when(item1.getMaxOutlier()).thenReturn(Double.NaN);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(item2.getMinOutlier()).thenReturn(5.0);
                                                                                                                    when(item2.getMaxOutlier()).thenReturn(Double.NaN);
                                                                                                                    
                                                                                                                    when(spyDataset.getItem(0, 0)).thenReturn(item1);
                                                                                                                    when(spyDataset.getItem(1, 0)).thenReturn(item2);
                                                                                                                
                                                                                                                    // Use reflection to call private updateBounds method
                                                                                                                    Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                                                                                    updateBoundsMethod.setAccessible(true);
                                                                                                                    updateBoundsMethod.invoke(spyDataset);
                                                                                                                
                                                                                                                    // Use reflection to access private fields
                                                                                                                    Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                                                    minValueField.setAccessible(true);
                                                                                                                    Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                                                    minRowField.setAccessible(true);
                                                                                                                    Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                                                    minColField.setAccessible(true);
                                                                                                                    Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                                                                    maxValueField.setAccessible(true);
                                                                                                                    Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                                                                    maxRowField.setAccessible(true);
                                                                                                                    Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                                                                    maxColField.setAccessible(true);
                                                                                                                
                                                                                                                    // Should ignore NaN values
                                                                                                                    assertEquals(5.0, (Double)minValueField.get(spyDataset), 0.0001);
                                                                                                                    assertEquals(1, minRowField.get(spyDataset)); // row index of item2
                                                                                                                    assertEquals(0, minColField.get(spyDataset)); // column index of item2
                                                                                                                    assertTrue(Double.isNaN((Double)maxValueField.get(spyDataset)));
                                                                                                                    assertEquals(-1, maxRowField.get(spyDataset));
                                                                                                                    assertEquals(-1, maxColField.get(spyDataset));
                                                                                                                }

    @Test
                                                                                                                public void testUpdateBounds_SomeNullItems() throws Exception {
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                                                                                    
                                                                                                                    when(spyDataset.getRowCount()).thenReturn(2);
                                                                                                                    when(spyDataset.getColumnCount()).thenReturn(2);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(item1.getMinOutlier()).thenReturn(2.0);
                                                                                                                    when(item1.getMaxOutlier()).thenReturn(10.0);
                                                                                                                    
                                                                                                                    // Null item
                                                                                                                    when(spyDataset.getItem(0, 0)).thenReturn(item1);
                                                                                                                    when(spyDataset.getItem(0, 1)).thenReturn(null);
                                                                                                                    when(spyDataset.getItem(1, 0)).thenReturn(null);
                                                                                                                    when(spyDataset.getItem(1, 1)).thenReturn(null);
                                                                                                                
                                                                                                                    // Use reflection to call private updateBounds method
                                                                                                                    Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                                                                                    updateBoundsMethod.setAccessible(true);
                                                                                                                    updateBoundsMethod.invoke(spyDataset);
                                                                                                                
                                                                                                                    // Use reflection to access private fields
                                                                                                                    Field minRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                                                    minRangeValueField.setAccessible(true);
                                                                                                                    Field minRangeRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                                                    minRangeRowField.setAccessible(true);
                                                                                                                    Field minRangeColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                                                    minRangeColField.setAccessible(true);
                                                                                                                    Field maxRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                                                                    maxRangeValueField.setAccessible(true);
                                                                                                                    Field maxRangeRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                                                                    maxRangeRowField.setAccessible(true);
                                                                                                                    Field maxRangeColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                                                                    maxRangeColField.setAccessible(true);
                                                                                                                
                                                                                                                    // Assertions
                                                                                                                    assertEquals(2.0, (Double)minRangeValueField.get(spyDataset), 0.0001);
                                                                                                                    assertEquals(0, minRangeRowField.get(spyDataset)); // row index of item1
                                                                                                                    assertEquals(0, minRangeColField.get(spyDataset)); // column index of item1
                                                                                                                    assertEquals(10.0, (Double)maxRangeValueField.get(spyDataset), 0.0001);
                                                                                                                    assertEquals(0, maxRangeRowField.get(spyDataset)); // row index of item1
                                                                                                                    assertEquals(0, maxRangeColField.get(spyDataset)); // column index of item1
                                                                                                                }

    @Test
                                                                                                                public void testUpdateBounds_UpdatesFromPreviousValues() throws Exception {
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                    DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                                                                                    
                                                                                                                    // Use reflection to set initial values
                                                                                                                    Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                                                    minValueField.setAccessible(true);
                                                                                                                    minValueField.set(spyDataset, 10.0);
                                                                                                                    
                                                                                                                    Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                                                    minRowField.setAccessible(true);
                                                                                                                    minRowField.set(spyDataset, 1);
                                                                                                                    
                                                                                                                    Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                                                    minColField.setAccessible(true);
                                                                                                                    minColField.set(spyDataset, 1);
                                                                                                                    
                                                                                                                    Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                                                                    maxValueField.setAccessible(true);
                                                                                                                    maxValueField.set(spyDataset, 20.0);
                                                                                                                    
                                                                                                                    Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                                                                    maxRowField.setAccessible(true);
                                                                                                                    maxRowField.set(spyDataset, 1);
                                                                                                                    
                                                                                                                    Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                                                                    maxColField.setAccessible(true);
                                                                                                                    maxColField.set(spyDataset, 1);
                                                                                                                    
                                                                                                                    // Setup mock behavior for new data
                                                                                                                    when(spyDataset.getRowCount()).thenReturn(1);
                                                                                                                    when(spyDataset.getColumnCount()).thenReturn(1);
                                                                                                                    
                                                                                                                    BoxAndWhiskerItem mockItem = mock(BoxAndWhiskerItem.class);
                                                                                                                    when(mockItem.getMinOutlier()).thenReturn(5.0);
                                                                                                                    when(mockItem.getMaxOutlier()).thenReturn(25.0);
                                                                                                                    when(spyDataset.getItem(0, 0)).thenReturn(mockItem);
                                                                                                                
                                                                                                                    // Use reflection to call private updateBounds method
                                                                                                                    Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                                                                                    updateBoundsMethod.setAccessible(true);
                                                                                                                    updateBoundsMethod.invoke(spyDataset);
                                                                                                                
                                                                                                                    // Verify results using reflection
                                                                                                                    assertEquals(5.0, minValueField.getDouble(spyDataset), 0.0001);
                                                                                                                    assertEquals(0, minRowField.getInt(spyDataset));
                                                                                                                    assertEquals(0, minColField.getInt(spyDataset));
                                                                                                                    assertEquals(25.0, maxValueField.getDouble(spyDataset), 0.0001);
                                                                                                                    assertEquals(0, maxRowField.getInt(spyDataset));
                                                                                                                    assertEquals(0, maxColField.getInt(spyDataset));
                                                                                                                }

    @Test
                                                                                                            public void testUpdateBounds_MultipleItemsWithValidOutliers() throws Exception {
                                                                                                                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                                DefaultBoxAndWhiskerCategoryDataset spyDataset = spy(dataset);
                                                                                                                
                                                                                                                // Setup mock behavior for 2x2 grid
                                                                                                                when(spyDataset.getRowCount()).thenReturn(2);
                                                                                                                when(spyDataset.getColumnCount()).thenReturn(2);
                                                                                                                
                                                                                                                // Create mock items with different outlier values
                                                                                                                BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                                                                when(item1.getMinOutlier()).thenReturn(2.0);
                                                                                                                when(item1.getMaxOutlier()).thenReturn(10.0);
                                                                                                                
                                                                                                                BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                                                                                when(item2.getMinOutlier()).thenReturn(1.0);
                                                                                                                when(item2.getMaxOutlier()).thenReturn(12.0);
                                                                                                                
                                                                                                                BoxAndWhiskerItem item3 = mock(BoxAndWhiskerItem.class);
                                                                                                                when(item3.getMinOutlier()).thenReturn(3.0);
                                                                                                                when(item3.getMaxOutlier()).thenReturn(8.0);
                                                                                                                
                                                                                                                BoxAndWhiskerItem item4 = mock(BoxAndWhiskerItem.class);
                                                                                                                when(item4.getMinOutlier()).thenReturn(0.5);
                                                                                                                when(item4.getMaxOutlier()).thenReturn(15.0);
                                                                                                                
                                                                                                                // Setup which items are returned for which positions
                                                                                                                when(spyDataset.getItem(0, 0)).thenReturn(item1);
                                                                                                                when(spyDataset.getItem(0, 1)).thenReturn(item2);
                                                                                                                when(spyDataset.getItem(1, 0)).thenReturn(item3);
                                                                                                                when(spyDataset.getItem(1, 1)).thenReturn(item4);
                                                                                                            
                                                                                                                // Use reflection to call private updateBounds method
                                                                                                                Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                                                                                updateBoundsMethod.setAccessible(true);
                                                                                                                updateBoundsMethod.invoke(spyDataset);
                                                                                                            
                                                                                                                // Use reflection to access private fields for assertions
                                                                                                                Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                                                minValueField.setAccessible(true);
                                                                                                                Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                                                minRowField.setAccessible(true);
                                                                                                                Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                                                minColField.setAccessible(true);
                                                                                                                Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                                                                maxValueField.setAccessible(true);
                                                                                                                Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                                                                maxRowField.setAccessible(true);
                                                                                                                Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                                                                maxColField.setAccessible(true);
                                                                                                            
                                                                                                                // Should find the smallest min outlier (0.5) and largest max outlier (15.0)
                                                                                                                assertEquals(0.5, ((Double)minValueField.get(spyDataset)).doubleValue(), 0.0001);
                                                                                                                assertEquals(1, ((Integer)minRowField.get(spyDataset)).intValue()); // row index of item4
                                                                                                                assertEquals(1, ((Integer)minColField.get(spyDataset)).intValue()); // column index of item4
                                                                                                                assertEquals(15.0, ((Double)maxValueField.get(spyDataset)).doubleValue(), 0.0001);
                                                                                                                assertEquals(1, ((Integer)maxRowField.get(spyDataset)).intValue()); // row index of item4
                                                                                                                assertEquals(1, ((Integer)maxColField.get(spyDataset)).intValue()); // column index of item4
                                                                                                            }

    @Test
                                                                                                        public void testAdd_WithNullList() {
                                                                                                            // Setup
                                                                                                            Comparable<String> rowKey = "Row1";
                                                                                                            Comparable<String> columnKey = "Column1";
                                                                                                            
                                                                                                            ExpectedException thrown = ExpectedException.none();
                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                            
                                                                                                            // Execute
                                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                                            dataset.add((List) null, rowKey, columnKey);
                                                                                                        }

    @Test
                                                                                                public void testAddItemShouldCallUpdateBoundsOnce() {
                                                                                                    // Create a spy of the dataset to track method calls
                                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = spy(new DefaultBoxAndWhiskerCategoryDataset());
                                                                                                    
                                                                                                    // Setup test data
                                                                                                    BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                                                    when(item.getMinOutlier()).thenReturn(1.0);
                                                                                                    when(item.getMaxOutlier()).thenReturn(10.0);
                                                                                                    Comparable<String> rowKey = "Row1";
                                                                                                    Comparable<String> columnKey = "Column1";
                                                                                                    
                                                                                                    // Perform the operation
                                                                                                    dataset.add(item, rowKey, columnKey);
                                                                                                    
                                                                                                    // Verify the range was properly updated through public API
                                                                                                    Range range = dataset.getRangeBounds(false);
                                                                                                    assertEquals(1.0, range.getLowerBound(), 0.0001);
                                                                                                    assertEquals(10.0, range.getUpperBound(), 0.0001);
                                                                                                    
                                                                                                    // Remove the verification of private method calls and state
                                                                                                    // as they are implementation details that shouldn't be tested directly
                                                                                                }

    @Test
                                                                                            public void testAddItemAtCurrentMinMaxPositionShouldCallUpdateBoundsOnce() throws Exception {
                                                                                                // Setup
                                                                                                DefaultBoxAndWhiskerCategoryDataset dataset = spy(new DefaultBoxAndWhiskerCategoryDataset());
                                                                                                
                                                                                                // Use reflection to set private fields
                                                                                                Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                                minValueField.setAccessible(true);
                                                                                                minValueField.set(dataset, 1.0);
                                                                                                
                                                                                                Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                                minRowField.setAccessible(true);
                                                                                                minRowField.set(dataset, 0);
                                                                                                
                                                                                                Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                                minColField.setAccessible(true);
                                                                                                minColField.set(dataset, 0);
                                                                                                
                                                                                                Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                                                maxValueField.setAccessible(true);
                                                                                                maxValueField.set(dataset, 10.0);
                                                                                                
                                                                                                Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                                                maxRowField.setAccessible(true);
                                                                                                maxRowField.set(dataset, 0);
                                                                                                
                                                                                                Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                                                maxColField.setAccessible(true);
                                                                                                maxColField.set(dataset, 0);
                                                                                                
                                                                                                // Get the updateBounds method
                                                                                                Method updateBoundsMethod = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredMethod("updateBounds");
                                                                                                updateBoundsMethod.setAccessible(true);
                                                                                                
                                                                                                // Create a counter to track method calls
                                                                                                final int[] callCount = {0};
                                                                                                
                                                                                                // Replace the original method with our counter
                                                                                                doAnswer(invocation -> {
                                                                                                    callCount[0]++;
                                                                                                    return updateBoundsMethod.invoke(dataset);
                                                                                                }).when(dataset).add(any(BoxAndWhiskerItem.class), any(), any());
                                                                                                
                                                                                                // Create test item
                                                                                                BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                                                when(item.getMinOutlier()).thenReturn(1.0);
                                                                                                when(item.getMaxOutlier()).thenReturn(10.0);
                                                                                                
                                                                                                // Test
                                                                                                dataset.add(item, "row0", "col0");
                                                                                                
                                                                                                // Verify updateBounds was called exactly once through our counter
                                                                                                assertEquals(1, callCount[0]);
                                                                                                
                                                                                                // Additional assertions to ensure correct behavior using reflection
                                                                                                assertEquals(0, minRowField.get(dataset));
                                                                                                assertEquals(0, minColField.get(dataset));
                                                                                                assertEquals(0, maxRowField.get(dataset));
                                                                                                assertEquals(0, maxColField.get(dataset));
                                                                                            }

    @Test
                                                                                        public void testAddWithOnlyMinOutlierShouldUpdateMinimumRangeValue() {
                                                                                            // Setup
                                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                            Comparable<String> rowKey = "Row1";
                                                                                            Comparable<String> columnKey = "Column1";
                                                                                            
                                                                                            // Create a BoxAndWhiskerItem with only min outlier
                                                                                            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                                            when(item.getMinOutlier()).thenReturn(5.0);  // has min outlier
                                                                                            when(item.getMaxOutlier()).thenReturn(null); // no max outlier
                                                                                            
                                                                                            // Mock data object behavior
                                                                                            KeyedObjects2D data = mock(KeyedObjects2D.class);
                                                                                            when(data.getRowIndex(rowKey)).thenReturn(0);
                                                                                            when(data.getColumnIndex(columnKey)).thenReturn(0);
                                                                                            // Use reflection to set the private data field
                                                                                            try {
                                                                                                Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                                                                                                dataField.setAccessible(true);
                                                                                                dataField.set(dataset, data);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to set data field via reflection");
                                                                                            }
                                                                                            
                                                                                            // Execute
                                                                                            dataset.add(item, rowKey, columnKey);
                                                                                            
                                                                                            // Verify minimum range value was updated
                                                                                            try {
                                                                                                Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                                minValueField.setAccessible(true);
                                                                                                double actualMinValue = minValueField.getDouble(dataset);
                                                                                                
                                                                                                assertEquals(5.0, actualMinValue, 0.0001);
                                                                                                
                                                                                                // Also verify the row and column indices were set
                                                                                                Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                                minRowField.setAccessible(true);
                                                                                                Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                                minColField.setAccessible(true);
                                                                                                
                                                                                                assertEquals(0, minRowField.getInt(dataset));
                                                                                                assertEquals(0, minColField.getInt(dataset));
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to access private fields for verification");
                                                                                            }
                                                                                        }

    @Test
                                                                                public void testAddWithMinOutlierOnlyShouldUpdateBounds() {
                                                                                    // Setup
                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                    Comparable<String> rowKey = "Row1";
                                                                                    Comparable<String> columnKey = "Column1";
                                                                                    
                                                                                    // Create a BoxAndWhiskerItem with only min outlier
                                                                                    double minOutlier = 5.0;
                                                                                    List<Double> outliers = new ArrayList<Double>();
                                                                                    outliers.add(minOutlier);
                                                                                    BoxAndWhiskerItem item = new BoxAndWhiskerItem(
                                                                                        2.0,  // mean
                                                                                        1.0,  // median
                                                                                        0.5,  // q1
                                                                                        3.5,  // q3
                                                                                        1.0,  // min regular value
                                                                                        3.0,  // max regular value
                                                                                        minOutlier,  // min outlier
                                                                                        null,  // max outlier
                                                                                        outliers  // outliers list
                                                                                    );
                                                                                    
                                                                                    // Test
                                                                                    dataset.add(item, rowKey, columnKey);
                                                                                    
                                                                                    // Verify the bounds were updated with min outlier value
                                                                                    Range bounds = dataset.getRangeBounds(false);
                                                                                    assertNotNull("Range bounds should not be null", bounds);
                                                                                    assertEquals("Lower bound should match min outlier", 5.0, bounds.getLowerBound(), 0.0001);
                                                                                    
                                                                                    // Additional verification that the item was properly stored
                                                                                    BoxAndWhiskerItem storedItem = dataset.getItem(0, 0);
                                                                                    assertEquals("Stored item's min outlier should match", minOutlier, storedItem.getMinOutlier().doubleValue(), 0.0001);
                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                public void testAddWithNullItemShouldThrowException() {
                                                                                    // Setup
                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                    Comparable<String> rowKey = "Row1";
                                                                                    Comparable<String> columnKey = "Column1";
                                                                                    
                                                                                    // Create a list that will result in a null BoxAndWhiskerItem
                                                                                    // (assuming BoxAndWhiskerCalculator returns null for empty/invalid input)
                                                                                    List<Double> emptyList = new ArrayList<>();
                                                                                    
                                                                                    // This should throw NPE with original code, but pass with mutated code
                                                                                    dataset.add(emptyList, rowKey, columnKey);
                                                                                }

    @Test
                                                                                public void testAddWithNullItemShouldBeHandledGracefully() {
                                                                                    // Setup
                                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                                    Comparable<String> rowKey = "Row1";
                                                                                    Comparable<String> columnKey = "Column1";
                                                                                    
                                                                                    // Mock the BoxAndWhiskerCalculator to return null
                                                                                    BoxAndWhiskerItem nullItem = null;
                                                                                    // This is a simplified version - in real code you might need to mock the static method
                                                                                    
                                                                                    try {
                                                                                        // This should not throw exception with mutated code
                                                                                        dataset.add(new ArrayList<>(), rowKey, columnKey);
                                                                                        
                                                                                        // Verify the item wasn't added to the dataset
                                                                                        assertNull(dataset.getItem(0, 0));
                                                                                    } catch (NullPointerException e) {
                                                                                        fail("Mutated code should handle null item gracefully");
                                                                                    }
                                                                                }

    @Test
                                                                        public void testAddWithNullItemShouldThrowException1() throws Exception {
                                                                            // Setup
                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                            Comparable<String> rowKey = "Row1";
                                                                            Comparable<String> columnKey = "Column1";
                                                                            
                                                                            // Mock the data object to return specific indices
                                                                            KeyedObjects2D mockedData = mock(KeyedObjects2D.class);
                                                                            when(mockedData.getRowIndex(rowKey)).thenReturn(0);
                                                                            when(mockedData.getColumnIndex(columnKey)).thenReturn(0);
                                                                            
                                                                            // Use reflection to set protected data field
                                                                            Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                                                                            dataField.setAccessible(true);
                                                                            dataField.set(dataset, mockedData);
                                                                            
                                                                            // Use reflection to set private min/max fields
                                                                            Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                            minValueField.setAccessible(true);
                                                                            minValueField.set(dataset, 10.0);
                                                                            
                                                                            Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                            minRowField.setAccessible(true);
                                                                            minRowField.set(dataset, 0);
                                                                            
                                                                            Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                            minColField.setAccessible(true);
                                                                            minColField.set(dataset, 0);
                                                                            
                                                                            Field maxValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                                                                            maxValueField.setAccessible(true);
                                                                            maxValueField.set(dataset, 20.0);
                                                                            
                                                                            Field maxRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueRow");
                                                                            maxRowField.setAccessible(true);
                                                                            maxRowField.set(dataset, 0);
                                                                            
                                                                            Field maxColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValueColumn");
                                                                            maxColField.setAccessible(true);
                                                                            maxColField.set(dataset, 0);
                                                                            
                                                                            // This should throw NullPointerException
                                                                            try {
                                                                                dataset.add((BoxAndWhiskerItem)null, rowKey, columnKey);
                                                                                fail("Expected NullPointerException");
                                                                            } catch (NullPointerException e) {
                                                                                // Expected exception
                                                                            }
                                                                        }

    @Test
                                                                    public void testAddWithDifferentOutlierCombinations() {
                                                                        // Setup
                                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                        Comparable<String> rowKey = "Row1";
                                                                        Comparable<String> columnKey = "Column1";
                                                                        
                                                                        // Case 1: Only min outlier exists
                                                                        BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                                        when(item1.getMinOutlier()).thenReturn(1.0);
                                                                        when(item1.getMaxOutlier()).thenReturn(null);
                                                                        
                                                                        // Case 2: Only max outlier exists
                                                                        BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                                        when(item2.getMinOutlier()).thenReturn(null);
                                                                        when(item2.getMaxOutlier()).thenReturn(10.0);
                                                                        
                                                                        // Case 3: Both outliers exist
                                                                        BoxAndWhiskerItem item3 = mock(BoxAndWhiskerItem.class);
                                                                        when(item3.getMinOutlier()).thenReturn(2.0);
                                                                        when(item3.getMaxOutlier()).thenReturn(8.0);
                                                                        
                                                                        // Case 4: No outliers exist
                                                                        BoxAndWhiskerItem item4 = mock(BoxAndWhiskerItem.class);
                                                                        when(item4.getMinOutlier()).thenReturn(null);
                                                                        when(item4.getMaxOutlier()).thenReturn(null);
                                                                        
                                                                        // Execute and verify
                                                                        // Original would update bounds for all cases except case 4
                                                                        // Mutant would only update bounds for case 3
                                                                        
                                                                        // Test case 1 (only min outlier)
                                                                        dataset.add(item1, rowKey, columnKey);
                                                                        Range bounds1 = dataset.getRangeBounds(false);
                                                                        assertTrue("Bounds should include min outlier", bounds1.getLowerBound() <= 1.0);
                                                                        
                                                                        // Test case 2 (only max outlier)
                                                                        dataset.add(item2, rowKey, columnKey);
                                                                        Range bounds2 = dataset.getRangeBounds(false);
                                                                        assertTrue("Bounds should include max outlier", bounds2.getUpperBound() >= 10.0);
                                                                        
                                                                        // Test case 3 (both outliers)
                                                                        dataset.add(item3, rowKey, columnKey);
                                                                        Range bounds3 = dataset.getRangeBounds(false);
                                                                        assertTrue("Bounds should include both outliers", 
                                                                                   bounds3.getLowerBound() <= 2.0 && bounds3.getUpperBound() >= 8.0);
                                                                        
                                                                        // Test case 4 (no outliers)
                                                                        dataset.add(item4, rowKey, columnKey);
                                                                        Range bounds4 = dataset.getRangeBounds(false);
                                                                        // Should not affect the existing bounds
                                                                        assertTrue("Bounds should remain unchanged", 
                                                                                   bounds4.getLowerBound() <= 2.0 && bounds4.getUpperBound() >= 8.0);
                                                                    }

    @Test
                                                                        public void testAddItemWithOnlyMinOutlierShouldUpdateMinimumRange() {
                                                                            // Setup
                                                                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                            Comparable<String> rowKey = "Row1";
                                                                            Comparable<String> columnKey = "Column1";
                                                                            
                                                                            // Create a mock item with only min outlier
                                                                            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                            when(item.getMinOutlier()).thenReturn(5.0);
                                                                            when(item.getMaxOutlier()).thenReturn(null);
                                                                            
                                                                            // Mock data object behavior
                                                                            KeyedObjects2D data = mock(KeyedObjects2D.class);
                                                                            when(data.getRowIndex(rowKey)).thenReturn(0);
                                                                            when(data.getColumnIndex(columnKey)).thenReturn(0);
                                                                            // Use reflection to set the protected data field for testing
                                                                            try {
                                                                                java.lang.reflect.Field field = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                                                                                field.setAccessible(true);
                                                                                field.set(dataset, data);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set data field via reflection");
                                                                            }
                                                                            
                                                                            // Initialize current min/max values to NaN
                                                                            dataset.add(item, rowKey, columnKey);
                                                                            
                                                                            // Verify that minimumRangeValue was updated (should be 5.0)
                                                                            try {
                                                                                java.lang.reflect.Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                                minValueField.setAccessible(true);
                                                                                double actualMinValue = minValueField.getDouble(dataset);
                                                                                
                                                                                assertEquals(5.0, actualMinValue, 0.0001);
                                                                                
                                                                                // Also verify the row and column indices were set
                                                                                java.lang.reflect.Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                                minRowField.setAccessible(true);
                                                                                int minRow = minRowField.getInt(dataset);
                                                                                
                                                                                java.lang.reflect.Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                                minColField.setAccessible(true);
                                                                                int minCol = minColField.getInt(dataset);
                                                                                
                                                                                assertEquals(0, minRow);
                                                                                assertEquals(0, minCol);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to verify minimum range value via reflection");
                                                                            }
                                                                        }

    @Test
                                                                public void testAddWithDifferentOutlierCombinations1() {
                                                                    // Setup
                                                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                    Comparable rowKey = "Row1";
                                                                    Comparable columnKey = "Column1";
                                                                    
                                                                    // Create mock items with different outlier combinations
                                                                    BoxAndWhiskerItem itemOnlyMinOutlier = mock(BoxAndWhiskerItem.class);
                                                                    when(itemOnlyMinOutlier.getMinOutlier()).thenReturn(1.0);
                                                                    when(itemOnlyMinOutlier.getMaxOutlier()).thenReturn(null);
                                                                    
                                                                    BoxAndWhiskerItem itemOnlyMaxOutlier = mock(BoxAndWhiskerItem.class);
                                                                    when(itemOnlyMaxOutlier.getMinOutlier()).thenReturn(null);
                                                                    when(itemOnlyMaxOutlier.getMaxOutlier()).thenReturn(10.0);
                                                                    
                                                                    BoxAndWhiskerItem itemBothOutliers = mock(BoxAndWhiskerItem.class);
                                                                    when(itemBothOutliers.getMinOutlier()).thenReturn(1.0);
                                                                    when(itemBothOutliers.getMaxOutlier()).thenReturn(10.0);
                                                                    
                                                                    BoxAndWhiskerItem itemNoOutliers = mock(BoxAndWhiskerItem.class);
                                                                    when(itemNoOutliers.getMinOutlier()).thenReturn(null);
                                                                    when(itemNoOutliers.getMaxOutlier()).thenReturn(null);
                                                                    
                                                                    // Test case 1: Only min outlier - should affect bounds in both original and mutant
                                                                    dataset.add(itemOnlyMinOutlier, rowKey, columnKey);
                                                                    Range bounds1 = dataset.getRangeBounds(false);
                                                                    assertNotNull(bounds1);
                                                                    
                                                                    // Test case 2: Only max outlier - should ONLY affect bounds in mutant version
                                                                    dataset.add(itemOnlyMaxOutlier, rowKey, columnKey);
                                                                    Range bounds2 = dataset.getRangeBounds(false);
                                                                    
                                                                    // This assertion will fail in mutant version but pass in original
                                                                    // Original version ignores max outlier when min is null
                                                                    // Mutant version will include max outlier in range calculation
                                                                    assertEquals("Range should not be affected by max outlier alone in original version", 
                                                                                 bounds1.getUpperBound(), bounds2.getUpperBound(), 0.0001);
                                                                    
                                                                    // Test case 3: Both outliers
                                                                    dataset.add(itemBothOutliers, rowKey, columnKey);
                                                                    Range bounds3 = dataset.getRangeBounds(false);
                                                                    assertTrue(bounds3.getUpperBound() >= 10.0);
                                                                    
                                                                    // Test case 4: No outliers
                                                                    dataset.add(itemNoOutliers, rowKey, columnKey);
                                                                    Range bounds4 = dataset.getRangeBounds(false);
                                                                    assertEquals(bounds3, bounds4); // Should not change bounds
                                                                }

    @Test
                                                            public void testAddWithOnlyMaxOutlierShouldNotUpdateMinRange() {
                                                                // Setup
                                                                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                                BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                                when(item.getMinOutlier()).thenReturn(null);
                                                                when(item.getMaxOutlier()).thenReturn(10.0);
                                                                
                                                                Comparable rowKey = "Row1";
                                                                Comparable columnKey = "Column1";
                                                                
                                                                // Mock data object behavior
                                                                KeyedObjects2D data = mock(KeyedObjects2D.class);
                                                                when(data.getRowIndex(rowKey)).thenReturn(0);
                                                                when(data.getColumnIndex(columnKey)).thenReturn(0);
                                                                // Use reflection to set the protected data field
                                                                try {
                                                                    Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                                                                    dataField.setAccessible(true);
                                                                    dataField.set(dataset, data);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set data field via reflection");
                                                                }
                                                                
                                                                // Execute
                                                                dataset.add(item, rowKey, columnKey);
                                                                
                                                                // Verify
                                                                // Original behavior: minRange should remain NaN since minOutlier is null
                                                                // Mutated behavior would still result in NaN, but we can verify the flow
                                                                assertTrue(Double.isNaN(dataset.getRangeBounds(false).getLowerBound()));
                                                                assertEquals(10.0, dataset.getRangeBounds(false).getUpperBound(), 0.0001);
                                                                
                                                                // Additional verification to ensure the mutant is caught
                                                                // Verify that if only maxOutlier exists, minRange isn't updated
                                                                try {
                                                                    Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                                    minRowField.setAccessible(true);
                                                                    assertEquals(-1, minRowField.getInt(dataset));
                                                                    
                                                                    Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                                    minColField.setAccessible(true);
                                                                    assertEquals(-1, minColField.getInt(dataset));
                                                                    
                                                                    Field minValField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                                    minValField.setAccessible(true);
                                                                    assertTrue(Double.isNaN(minValField.getDouble(dataset)));
                                                                } catch (Exception e) {
                                                                    fail("Failed to access private fields via reflection");
                                                                }
                                                            }

    @Test
                                                    public void testAddUpdatesMinimumRangeValueRowCorrectly() throws Exception {
                                                        // Setup
                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                        
                                                        // Create mock items with different minimum values
                                                        BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                        when(item1.getMinRegularValue()).thenReturn(5.0);
                                                        
                                                        BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                        when(item2.getMinRegularValue()).thenReturn(2.0);  // This should be the new minimum
                                                        
                                                        BoxAndWhiskerItem item3 = mock(BoxAndWhiskerItem.class);
                                                        when(item3.getMinRegularValue()).thenReturn(7.0);
                                                        
                                                        // Add items to different rows/columns
                                                        // Row 0 will contain the minimum value (2.0)
                                                        dataset.add(item1, "Row1", "Column1");  // value 5.0
                                                        dataset.add(item2, "Row0", "Column0");  // value 2.0 (new minimum)
                                                        dataset.add(item3, "Row2", "Column2");  // value 7.0
                                                        
                                                        // Add another item with even lower value in different row/column
                                                        BoxAndWhiskerItem item4 = mock(BoxAndWhiskerItem.class);
                                                        when(item4.getMinRegularValue()).thenReturn(1.0);  // new minimum
                                                        dataset.add(item4, "Row3", "Column4");
                                                        
                                                        // Use reflection to access private field
                                                        Field field = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                        field.setAccessible(true);
                                                        int minimumRangeValueRow = field.getInt(dataset);
                                                        
                                                        // Verify minimumRangeValueRow is set to the correct row index (3)
                                                        assertEquals("Minimum range value row should be the row index where minimum was found", 
                                                                     3, minimumRangeValueRow);
                                                    }

    @Test
                                                    public void testAddItemUpdatesMinimumRangeValueRowCorrectly() throws Exception {
                                                        // Setup
                                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                        Comparable rowKey = "Row1";
                                                        Comparable columnKey = "Column1";
                                                        
                                                        // Create an item that will become the new minimum
                                                        BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                                                        when(item.getMinOutlier()).thenReturn(5.0);  // This will be the new minimum
                                                        when(item.getMaxOutlier()).thenReturn(10.0);
                                                        
                                                        // Add the item - this should update minimum range values
                                                        dataset.add(item, rowKey, columnKey);
                                                        
                                                        // Verify minimum value tracking
                                                        int expectedRow = dataset.getRowIndex(rowKey);  // Should be 0 (first row)
                                                        int expectedColumn = dataset.getColumnIndex(columnKey);  // Should be 0 (first column)
                                                        
                                                        // Use reflection to access private fields
                                                        Field minRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                        minRowField.setAccessible(true);
                                                        int actualMinRow = (int) minRowField.get(dataset);
                                                        
                                                        Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                                                        minColField.setAccessible(true);
                                                        int actualMinCol = (int) minColField.get(dataset);
                                                        
                                                        Field minValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                        minValueField.setAccessible(true);
                                                        double actualMinValue = (double) minValueField.get(dataset);
                                                        
                                                        // Check that minimumRangeValueRow was set to row index (r), not column index (c)
                                                        assertEquals("Minimum range value row should match the row index", 
                                                                     expectedRow, actualMinRow);
                                                        assertNotEquals("Minimum range value row should not equal column index", 
                                                                       actualMinCol, actualMinRow);
                                                        
                                                        // Additional assertions to ensure complete test
                                                        assertEquals(5.0, actualMinValue, 0.0001);
                                                        assertEquals(expectedColumn, actualMinCol);
                                                    }

    @Test
                                            public void testAddUpdatesMinimumRangeValueRowCorrectly1() throws Exception {
                                                // Setup
                                                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                
                                                // Create mock items with different range values
                                                BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                                                when(item1.getMinRegularValue()).thenReturn(5.0);
                                                when(item1.getMaxRegularValue()).thenReturn(10.0);
                                                
                                                BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                                                when(item2.getMinRegularValue()).thenReturn(2.0);  // This should be the new minimum
                                                when(item2.getMaxRegularValue()).thenReturn(8.0);
                                                
                                                BoxAndWhiskerItem item3 = mock(BoxAndWhiskerItem.class);
                                                when(item3.getMinRegularValue()).thenReturn(3.0);
                                                when(item3.getMaxRegularValue()).thenReturn(12.0);
                                                
                                                // Add items to different rows
                                                dataset.add(item1, "Row1", "Column1");
                                                dataset.add(item2, "Row2", "Column1");  // This contains the minimum value (2.0)
                                                dataset.add(item3, "Row3", "Column1");
                                                
                                                // Use reflection to access private fields
                                                Field minimumRangeValueRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                                minimumRangeValueRowField.setAccessible(true);
                                                int minimumRangeValueRow = minimumRangeValueRowField.getInt(dataset);
                                                
                                                Field minimumRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                                minimumRangeValueField.setAccessible(true);
                                                double minimumRangeValue = minimumRangeValueField.getDouble(dataset);
                                                
                                                // Verify minimumRangeValueRow points to Row2 (index 1)
                                                assertEquals("Minimum range value row should be 1 (Row2)", 
                                                             1, minimumRangeValueRow);
                                                
                                                // Additional verification that the minimum value is correct
                                                assertEquals("Minimum range value should be 2.0", 
                                                             2.0, minimumRangeValue, 0.0001);
                                            }

    @Test
                                            public void testAddItemUpdatesMinimumRangeValueRowCorrectly1() {
                                                // Setup
                                                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                                Comparable rowKey1 = "Row1";
                                                Comparable rowKey2 = "Row2";
                                                Comparable columnKey = "Column1";
                                                
                                                // Create items - first item will set initial min/max, second item will be new min
                                                BoxAndWhiskerItem initialItem = mock(BoxAndWhiskerItem.class);
                                                when(initialItem.getMinOutlier()).thenReturn(10.0);
                                                when(initialItem.getMaxOutlier()).thenReturn(20.0);
                                                
                                                BoxAndWhiskerItem newMinItem = mock(BoxAndWhiskerItem.class);
                                                when(newMinItem.getMinOutlier()).thenReturn(5.0);  // new minimum value
                                                when(newMinItem.getMaxOutlier()).thenReturn(15.0);
                                                
                                                // Add initial item at row 0
                                                dataset.add(initialItem, rowKey1, columnKey);
                                                
                                                // Add new minimum item at row 1
                                                dataset.add(newMinItem, rowKey2, columnKey);
                                                
                                                // Verify minimum value and its location
                                                assertEquals("Minimum value should be updated", 5.0, dataset.getRangeBounds(false).getLowerBound(), 0.0001);
                                                
                                                // Verify minimum value is in the second row (rowKey2)
                                                assertEquals("Minimum value should be from second row", 
                                                    5.0, dataset.getMinOutlier(rowKey2, columnKey).doubleValue(), 0.0001);
                                                
                                                // Additional verification that maximum wasn't affected
                                                assertEquals("Maximum value should remain", 20.0, dataset.getRangeBounds(false).getUpperBound(), 0.0001);
                                                assertEquals("Maximum value should be from first row", 
                                                    20.0, dataset.getMaxOutlier(rowKey1, columnKey).doubleValue(), 0.0001);
                                            }

    @Test
                                    public void testAddItemUpdatesMinimumRangeValueRowCorrectly2() throws Exception {
                                        // Setup
                                        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                        Comparable rowKey1 = "Row1";
                                        Comparable rowKey2 = "Row2";
                                        Comparable columnKey = "Column1";
                                        
                                        // Create initial item with higher min outlier
                                        BoxAndWhiskerItem initialItem = mock(BoxAndWhiskerItem.class);
                                        when(initialItem.getMinOutlier()).thenReturn(10.0);
                                        when(initialItem.getMaxOutlier()).thenReturn(20.0);
                                        
                                        // Add initial item to establish baseline min/max
                                        dataset.add(initialItem, rowKey1, columnKey);
                                        
                                        // Create new item with lower min outlier that should become new minimum
                                        BoxAndWhiskerItem newMinItem = mock(BoxAndWhiskerItem.class);
                                        when(newMinItem.getMinOutlier()).thenReturn(5.0);
                                        when(newMinItem.getMaxOutlier()).thenReturn(15.0);
                                        
                                        // Add the new item that should become the minimum
                                        dataset.add(newMinItem, rowKey2, columnKey);
                                        
                                        // Use reflection to access private fields
                                        Field minimumRangeValueRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                                        minimumRangeValueRowField.setAccessible(true);
                                        int actualMinimumRangeValueRow = minimumRangeValueRowField.getInt(dataset);
                                        
                                        Field minimumRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                                        minimumRangeValueField.setAccessible(true);
                                        double actualMinimumRangeValue = minimumRangeValueField.getDouble(dataset);
                                        
                                        // Verify the minimumRangeValueRow is correctly set to the row index of newMinItem
                                        int expectedRowIndex = dataset.getRowIndex(rowKey2); // should be 1 (0-based)
                                        assertEquals("Minimum range value row should match the row index of the item with smallest min outlier", 
                                                    expectedRowIndex, actualMinimumRangeValueRow);
                                        
                                        // Additional verification that the minimum value was correctly updated
                                        assertEquals(5.0, actualMinimumRangeValue, 0.0001);
                                    }

    @Test
                                public void testAddUpdatesMinimumRangeValueRowCorrectly2() {
                                    // Setup
                                    DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                                    Comparable<String> rowKey = "Row1";
                                    Comparable<String> columnKey = "Column1";
                                    
                                    // Create a BoxAndWhiskerItem with known minimum value
                                    double minValue = 1.0;
                                    double maxValue = 10.0;
                                    double mean = 5.0;
                                    double median = 5.0;
                                    double q1 = 2.0;
                                    double q3 = 8.0;
                                    List<Double> outliers = new ArrayList<Double>();
                                    BoxAndWhiskerItem item = new BoxAndWhiskerItem(
                                        new Double(minValue), new Double(maxValue), new Double(mean), 
                                        new Double(median), new Double(q1), new Double(q3), 
                                        new Double(minValue - 1.0), new Double(maxValue + 1.0), outliers);
                                    
                                    // Add the item to the dataset
                                    dataset.add(item, rowKey, columnKey);
                                    
                                    // Verify minimumRangeValue is correctly set
                                    assertEquals(minValue, dataset.getRangeLowerBound(true), 0.0001);
                                    
                                    // Verify the row key matches by checking the value in the first row
                                    assertEquals(rowKey, dataset.getRowKey(0));
                                }

    @Test
                        public void testAddItemUpdatesMinimumRangeValueColumnCorrectly() {
                            // Setup
                            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                            Comparable rowKey = "Row1";
                            Comparable columnKey = "Column1";
                            
                            // Create an item that will become the new minimum
                            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                            when(item.getMinOutlier()).thenReturn(5.0);  // This will be the new minimum
                            when(item.getMaxOutlier()).thenReturn(10.0);
                            
                            // Add item - this should update minimum range values
                            dataset.add(item, rowKey, columnKey);
                            
                            // Get the actual row and column indices (which will be different)
                            int rowIndex = dataset.getRowIndex(rowKey);
                            int columnIndex = dataset.getColumnIndex(columnKey);
                            
                            try {
                                // Use reflection to access private fields
                                Field minimumRangeValueColumnField = DefaultBoxAndWhiskerCategoryDataset.class
                                        .getDeclaredField("minimumRangeValueColumn");
                                minimumRangeValueColumnField.setAccessible(true);
                                int actualColumn = minimumRangeValueColumnField.getInt(dataset);
                                
                                Field minimumRangeValueRowField = DefaultBoxAndWhiskerCategoryDataset.class
                                        .getDeclaredField("minimumRangeValueRow");
                                minimumRangeValueRowField.setAccessible(true);
                                int actualRow = minimumRangeValueRowField.getInt(dataset);
                                
                                // Verify minimumRangeValueColumn was set to column index, not row index
                                assertEquals("Minimum range value column should be set to column index", 
                                             columnIndex, actualColumn);
                                
                                // Additional verification that row index was set correctly
                                assertEquals("Minimum range value row should be set to row index",
                                             rowIndex, actualRow);
                            } catch (Exception e) {
                                fail("Failed to access private fields via reflection: " + e.getMessage());
                            }
                        }

    @Test
                    public void testAddUpdatesMinimumRangeValueColumnCorrectly() {
                        // Setup
                        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset dataset = 
                            new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
                        Comparable<String> rowKey1 = "Row1";
                        Comparable<String> columnKey1 = "Column1";
                        Comparable<String> columnKey2 = "Column2";
                        
                        // Create test data where minimum value is in column 1 (second column)
                        java.util.List<Double> values1 = java.util.Arrays.asList(10.0, 20.0, 30.0);  // higher values
                        java.util.List<Double> values2 = java.util.Arrays.asList(1.0, 2.0, 3.0);     // contains minimum
                        
                        // Action
                        dataset.add(values1, rowKey1, columnKey1);  // column 0
                        dataset.add(values2, rowKey1, columnKey2);  // column 1 (contains minimum)
                        
                        // Verify minimum value was recorded in correct column
                        // Using reflection to check internal state since fields are private
                        try {
                            java.lang.reflect.Field minColField = org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset.class
                                .getDeclaredField("minimumRangeValueColumn");
                            minColField.setAccessible(true);
                            int minCol = minColField.getInt(dataset);
                            
                            // The minimum value is in column 1 (second column)
                            // Mutant would set this to row index (0) instead
                            assertEquals("Minimum value column should be 1", 1, minCol);
                            
                            // Additional verification through public API
                            double lowerBound = dataset.getRangeLowerBound(true);
                            assertEquals("Range lower bound should match minimum value", 1.0, lowerBound, 0.0001);
                        } catch (Exception e) {
                            fail("Reflection failed: " + e.getMessage());
                        }
                    }

    @Test
            public void testAddUpdatesMinimumRangeValueColumnCorrectly1() throws Exception {
                // Setup
                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                
                // Create mock items with different min values
                BoxAndWhiskerItem item1 = mock(BoxAndWhiskerItem.class);
                when(item1.getMinRegularValue()).thenReturn(10.0);
                
                BoxAndWhiskerItem item2 = mock(BoxAndWhiskerItem.class);
                when(item2.getMinRegularValue()).thenReturn(5.0);  // This should be the minimum
                
                BoxAndWhiskerItem item3 = mock(BoxAndWhiskerItem.class);
                when(item3.getMinRegularValue()).thenReturn(15.0);
                
                // Add items to different columns
                dataset.add(item1, "Row1", "Column1");
                dataset.add(item2, "Row1", "Column2");  // Column with minimum value
                dataset.add(item3, "Row1", "Column3");
                
                // Use reflection to access private fields
                Field minRangeValueColumnField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                minRangeValueColumnField.setAccessible(true);
                int minimumRangeValueColumn = minRangeValueColumnField.getInt(dataset);
                
                Field minRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                minRangeValueField.setAccessible(true);
                double minimumRangeValue = minRangeValueField.getDouble(dataset);
                
                // Verify minimumRangeValueColumn points to column with minimum value (should be 1 for Column2)
                assertEquals(1, minimumRangeValueColumn);
                
                // Additional verification that we have the correct minimum value
                assertEquals(5.0, minimumRangeValue, 0.0001);
            }

    @Test
            public void testAddUpdatesMinimumRangeValueColumnCorrectly2() throws Exception {
                // Setup
                DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
                Comparable rowKey = "Row1";
                Comparable columnKey = "Column2"; // Using column index 1 (0-based)
                
                // Create item with min outlier that should become new minimum
                BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
                when(item.getMinOutlier()).thenReturn(5.0); // This will be new minimum
                when(item.getMaxOutlier()).thenReturn(10.0);
                
                // Get private fields for initial verification
                Field minRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
                minRangeValueField.setAccessible(true);
                Field minRangeRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
                minRangeRowField.setAccessible(true);
                Field minRangeColumnField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                minRangeColumnField.setAccessible(true);
                
                // Initial state verification
                assertTrue(Double.isNaN((Double)minRangeValueField.get(dataset)));
                assertEquals(-1, minRangeRowField.get(dataset));
                assertEquals(-1, minRangeColumnField.get(dataset));
                
                // Execute
                dataset.add(item, rowKey, columnKey);
                
                // Get additional fields needed for verification
                Field maxRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("maximumRangeValue");
                maxRangeValueField.setAccessible(true);
                
                // Verify minimum range column was set correctly
                // This assertion will fail if mutant is present (would be 0 instead of 1)
                assertEquals(1, minRangeColumnField.get(dataset));
                
                // Additional verifications
                assertEquals(5.0, (Double)minRangeValueField.get(dataset), 0.0001);
                assertEquals(0, minRangeRowField.get(dataset)); // First row added is index 0
                assertEquals(10.0, (Double)maxRangeValueField.get(dataset), 0.0001);
            }

    @Test
        public void testAddItemUpdatesMinimumRangeValueColumnCorrectly2() {
            // Setup
            DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
            Comparable rowKey = "Row1";
            Comparable columnKey = "Column1";
            
            // Create an item that will become the new minimum
            BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
            when(item.getMinOutlier()).thenReturn(1.0);  // Will be new minimum
            when(item.getMaxOutlier()).thenReturn(10.0);
            
            // Mock data object behavior
            KeyedObjects2D data = mock(KeyedObjects2D.class);
            when(data.getRowIndex(rowKey)).thenReturn(0);
            when(data.getColumnIndex(columnKey)).thenReturn(0);
            // Use reflection to set private data field since it's protected
            try {
                Field dataField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("data");
                dataField.setAccessible(true);
                dataField.set(dataset, data);
            } catch (Exception e) {
                fail("Failed to set mock data field");
            }
            
            // Execute
            dataset.add(item, rowKey, columnKey);
            
            // Verify minimumRangeValueColumn is set correctly
            try {
                Field minColField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
                minColField.setAccessible(true);
                int actualColumn = (int) minColField.get(dataset);
                
                // This assertion will fail with the mutant (expects 0, gets -1)
                assertEquals("Minimum range value column should match actual column index", 
                            0, actualColumn);
            } catch (Exception e) {
                fail("Failed to verify minimumRangeValueColumn");
            }
        }

    @Test
    public void testAddItemUpdatesMinimumRangeValueColumnCorrectly1() throws Exception {
        // Setup
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        Comparable rowKey = "Row1";
        Comparable columnKey = "Column1";
        
        // Create a mock item that will be the new minimum
        BoxAndWhiskerItem item = mock(BoxAndWhiskerItem.class);
        when(item.getMinOutlier()).thenReturn(1.0);  // This will be the new minimum
        
        // Action
        dataset.add(item, rowKey, columnKey);
        
        // Use reflection to access private fields
        Field minimumRangeValueColumnField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueColumn");
        minimumRangeValueColumnField.setAccessible(true);
        int minimumRangeValueColumn = minimumRangeValueColumnField.getInt(dataset);
        
        Field minimumRangeValueField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValue");
        minimumRangeValueField.setAccessible(true);
        double minimumRangeValue = minimumRangeValueField.getDouble(dataset);
        
        Field minimumRangeValueRowField = DefaultBoxAndWhiskerCategoryDataset.class.getDeclaredField("minimumRangeValueRow");
        minimumRangeValueRowField.setAccessible(true);
        int minimumRangeValueRow = minimumRangeValueRowField.getInt(dataset);
        
        // Verification
        int expectedColumnIndex = 0;  // First column added should have index 0
        assertEquals("Minimum range value column should match actual column index", 
                    expectedColumnIndex, minimumRangeValueColumn);
        
        // Additional checks to ensure the minimum value was properly recorded
        assertEquals(1.0, minimumRangeValue, 0.0001);
        assertEquals(0, minimumRangeValueRow);  // First row added should have index 0
    }


}
