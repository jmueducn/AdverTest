package gentest.org.jfree.data.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.SortOrder;
 
public class DefaultKeyedValuesTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                                                                                                                            public void testRemoveValue_ExistingKey() {
                                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                Comparable<String> key = "TestKey";
                                                                                                                                                                                                                                                                                Number value = 42;
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Mock the internal behavior (since getIndex is called)
                                                                                                                                                                                                                                                                                DefaultKeyedValues spyDkv = spy(dkv);
                                                                                                                                                                                                                                                                                when(spyDkv.getIndex(key)).thenReturn(0);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Add test data
                                                                                                                                                                                                                                                                                spyDkv.addValue(key, value);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify pre-condition
                                                                                                                                                                                                                                                                                assertEquals(1, spyDkv.getItemCount());
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                                spyDkv.removeValue(key);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify post-condition
                                                                                                                                                                                                                                                                                assertEquals(0, spyDkv.getItemCount());
                                                                                                                                                                                                                                                                                verify(spyDkv).removeValue(0); // Verify the internal remove by index was called
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testRemoveValue_NonExistingKey() {
                                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                Comparable<String> nonExistingKey = "NonExisting";
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Mock behavior to return -1 for non-existing key
                                                                                                                                                                                                                                                                                when(dkv.getIndex(nonExistingKey)).thenReturn(-1);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Expect exception
                                                                                                                                                                                                                                                                                thrown.expect(UnknownKeyException.class);
                                                                                                                                                                                                                                                                                thrown.expectMessage("The key (" + nonExistingKey + ") is not recognised.");
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                                dkv.removeValue(nonExistingKey);
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testRemoveValue_NullKey() {
                                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Mock behavior to return -1 for null key
                                                                                                                                                                                                                                                                                when(dkv.getIndex(null)).thenReturn(-1);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Expect exception
                                                                                                                                                                                                                                                                                thrown.expect(UnknownKeyException.class);
                                                                                                                                                                                                                                                                                thrown.expectMessage("The key (null) is not recognised.");
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                                dkv.removeValue(null);
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testRemoveValue_EmptyCollection() {
                                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                Comparable<String> key = "AnyKey";
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Mock behavior for empty collection
                                                                                                                                                                                                                                                                                when(dkv.getIndex(key)).thenReturn(-1);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Expect exception
                                                                                                                                                                                                                                                                                thrown.expect(UnknownKeyException.class);
                                                                                                                                                                                                                                                                                thrown.expectMessage("The key (" + key + ") is not recognised.");
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                                dkv.removeValue(key);
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testRemoveValue_VerifyIndexMapUpdate() {
                                                                                                                                                                                                                                                                                // Setup - add multiple items
                                                                                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                dkv.addValue("Key1", 1);
                                                                                                                                                                                                                                                                                dkv.addValue("Key2", 2);
                                                                                                                                                                                                                                                                                dkv.addValue("Key3", 3);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify initial state
                                                                                                                                                                                                                                                                                assertEquals(3, dkv.getItemCount());
                                                                                                                                                                                                                                                                                assertEquals(1, dkv.getValue("Key1").intValue());
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Execute - remove middle item
                                                                                                                                                                                                                                                                                dkv.removeValue("Key2");
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify final state
                                                                                                                                                                                                                                                                                assertEquals(2, dkv.getItemCount());
                                                                                                                                                                                                                                                                                assertEquals(1, dkv.getValue("Key1").intValue());
                                                                                                                                                                                                                                                                                assertEquals(3, dkv.getValue("Key3").intValue());
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify index map was rebuilt
                                                                                                                                                                                                                                                                                assertEquals(0, dkv.getIndex("Key1"));
                                                                                                                                                                                                                                                                                assertEquals(1, dkv.getIndex("Key3"));
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testClone_CreatesDeepCopy() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                                // Setup original object with some data
                                                                                                                                                                                                                                                                                DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                original.addValue("Key1", 10.0);
                                                                                                                                                                                                                                                                                original.addValue("Key2", 20.0);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Create clone
                                                                                                                                                                                                                                                                                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify it's a different object
                                                                                                                                                                                                                                                                                assertNotSame(original, clone);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify the data is the same
                                                                                                                                                                                                                                                                                assertEquals(original.getItemCount(), clone.getItemCount());
                                                                                                                                                                                                                                                                                assertEquals(original.getValue(0), clone.getValue(0));
                                                                                                                                                                                                                                                                                assertEquals(original.getValue(1), clone.getValue(1));
                                                                                                                                                                                                                                                                                assertEquals(original.getKey(0), clone.getKey(0));
                                                                                                                                                                                                                                                                                assertEquals(original.getKey(1), clone.getKey(1));
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify collections are different objects
                                                                                                                                                                                                                                                                                assertNotSame(original.getKeys(), clone.getKeys());
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testClone_ModificationDoesNotAffectOriginal() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                                // Setup original object
                                                                                                                                                                                                                                                                                DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                original.addValue("A", 1.0);
                                                                                                                                                                                                                                                                                original.addValue("B", 2.0);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Create clone
                                                                                                                                                                                                                                                                                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Modify clone
                                                                                                                                                                                                                                                                                clone.setValue("A", 99.0);
                                                                                                                                                                                                                                                                                clone.removeValue("B");
                                                                                                                                                                                                                                                                                clone.addValue("C", 3.0);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify original is unchanged
                                                                                                                                                                                                                                                                                assertEquals(2, original.getItemCount());
                                                                                                                                                                                                                                                                                assertEquals(1.0, original.getValue("A"));
                                                                                                                                                                                                                                                                                assertEquals(2.0, original.getValue("B"));
                                                                                                                                                                                                                                                                                assertNull(original.getValue("C"));
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testClone_OriginalModificationDoesNotAffectClone() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                                // Setup original object
                                                                                                                                                                                                                                                                                DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                original.addValue("X", 10.0);
                                                                                                                                                                                                                                                                                original.addValue("Y", 20.0);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Create clone
                                                                                                                                                                                                                                                                                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Modify original
                                                                                                                                                                                                                                                                                original.setValue("X", 100.0);
                                                                                                                                                                                                                                                                                original.removeValue("Y");
                                                                                                                                                                                                                                                                                original.addValue("Z", 30.0);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify clone is unchanged
                                                                                                                                                                                                                                                                                assertEquals(2, clone.getItemCount());
                                                                                                                                                                                                                                                                                assertEquals(10.0, clone.getValue("X"));
                                                                                                                                                                                                                                                                                assertEquals(20.0, clone.getValue("Y"));
                                                                                                                                                                                                                                                                                assertNull(clone.getValue("Z"));
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testClone_EmptyObject() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                                // Setup empty original
                                                                                                                                                                                                                                                                                DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Create clone
                                                                                                                                                                                                                                                                                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify it's empty
                                                                                                                                                                                                                                                                                assertEquals(0, clone.getItemCount());
                                                                                                                                                                                                                                                                                assertTrue(clone.getKeys().isEmpty());
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testClone_NullValuesHandled() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                                // Setup original with null values
                                                                                                                                                                                                                                                                                DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                original.addValue("NullKey", null);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Create clone
                                                                                                                                                                                                                                                                                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify null value is preserved
                                                                                                                                                                                                                                                                                assertNull(clone.getValue("NullKey"));
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testClone_IndexMapConsistency() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                                // Setup original with multiple values
                                                                                                                                                                                                                                                                                DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                original.addValue("First", 1.0);
                                                                                                                                                                                                                                                                                original.addValue("Second", 2.0);
                                                                                                                                                                                                                                                                                original.addValue("Third", 3.0);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Create clone
                                                                                                                                                                                                                                                                                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify index map consistency
                                                                                                                                                                                                                                                                                assertEquals(original.getIndex("First"), clone.getIndex("First"));
                                                                                                                                                                                                                                                                                assertEquals(original.getIndex("Second"), clone.getIndex("Second"));
                                                                                                                                                                                                                                                                                assertEquals(original.getIndex("Third"), clone.getIndex("Third"));
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify index map is a deep copy
                                                                                                                                                                                                                                                                                original.removeValue("Second");
                                                                                                                                                                                                                                                                                assertEquals(1, clone.getIndex("Third")); // Should still be 2 in clone
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testClone_KeysAndValuesCollectionsDeepCopied() throws CloneNotSupportedException {
                                                                                                                                                                                                                                                                                // Setup original
                                                                                                                                                                                                                                                                                DefaultKeyedValues original = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                                original.addValue("K1", 1.0);
                                                                                                                                                                                                                                                                                original.addValue("K2", 2.0);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Create clone
                                                                                                                                                                                                                                                                                DefaultKeyedValues clone = (DefaultKeyedValues) original.clone();
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify collections are deep copies
                                                                                                                                                                                                                                                                                assertNotSame(original.getKeys(), clone.getKeys());
                                                                                                                                                                                                                                                                                assertEquals(original.getKeys(), clone.getKeys()); // But content should be equal
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Verify modifying clone's collections doesn't affect original
                                                                                                                                                                                                                                                                                clone.getKeys().add("K3");
                                                                                                                                                                                                                                                                                assertEquals(2, original.getKeys().size());
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                    public void testRemoveValue_ValidIndex_RemovesKeyValuePair() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key1", 10);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key2", 20);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key3", 30);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action
                                                                                                                                                                                                                                                                        keyedValues.removeValue(1); // Remove middle element
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                                        assertEquals(2, keyedValues.getItemCount());
                                                                                                                                                                                                                                                                        assertEquals("Key1", keyedValues.getKey(0));
                                                                                                                                                                                                                                                                        assertEquals(10, keyedValues.getValue(0));
                                                                                                                                                                                                                                                                        assertEquals("Key3", keyedValues.getKey(1));
                                                                                                                                                                                                                                                                        assertEquals(30, keyedValues.getValue(1));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testRemoveValue_FirstIndex_RemovesFirstElement() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key1", 10);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key2", 20);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action
                                                                                                                                                                                                                                                                        keyedValues.removeValue(0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                                        assertEquals(1, keyedValues.getItemCount());
                                                                                                                                                                                                                                                                        assertEquals("Key2", keyedValues.getKey(0));
                                                                                                                                                                                                                                                                        assertEquals(20, keyedValues.getValue(0));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testRemoveValue_LastIndex_RemovesLastElement() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key1", 10);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key2", 20);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action
                                                                                                                                                                                                                                                                        keyedValues.removeValue(1);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                                        assertEquals(1, keyedValues.getItemCount());
                                                                                                                                                                                                                                                                        assertEquals("Key1", keyedValues.getKey(0));
                                                                                                                                                                                                                                                                        assertEquals(10, keyedValues.getValue(0));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testRemoveValue_SingleElement_ClearsCollections() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key1", 10);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action
                                                                                                                                                                                                                                                                        keyedValues.removeValue(0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                                        assertEquals(0, keyedValues.getItemCount());
                                                                                                                                                                                                                                                                        assertTrue(keyedValues.getKeys().isEmpty());
                                                                                                                                                                                                                                                                    }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                                                                                                                                                    public void testRemoveValue_IndexOutOfBounds_ThrowsException() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key1", 10);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action - should throw IndexOutOfBoundsException
                                                                                                                                                                                                                                                                        keyedValues.removeValue(1); // Only index 0 exists
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testRemoveValue_NegativeIndex_ThrowsException() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Expect exception
                                                                                                                                                                                                                                                                        thrown.expect(IndexOutOfBoundsException.class);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action
                                                                                                                                                                                                                                                                        keyedValues.removeValue(-1);
                                                                                                                                                                                                                                                                    }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                                                                                                                                                                    public void testRemoveValue_EmptyCollection_ThrowsException() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action - should throw IndexOutOfBoundsException
                                                                                                                                                                                                                                                                        keyedValues.removeValue(0);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testRemoveValue_RebuildsIndexMap() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key1", 10);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key2", 20);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key3", 30);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify initial index map
                                                                                                                                                                                                                                                                        assertEquals(0, keyedValues.getIndex("Key1"));
                                                                                                                                                                                                                                                                        assertEquals(1, keyedValues.getIndex("Key2"));
                                                                                                                                                                                                                                                                        assertEquals(2, keyedValues.getIndex("Key3"));
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action - remove middle element
                                                                                                                                                                                                                                                                        keyedValues.removeValue(1);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Assert index map was rebuilt
                                                                                                                                                                                                                                                                        assertEquals(0, keyedValues.getIndex("Key1"));
                                                                                                                                                                                                                                                                        assertEquals(1, keyedValues.getIndex("Key3"));
                                                                                                                                                                                                                                                                        assertEquals(-1, keyedValues.getIndex("Key2")); // Should no longer exist
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                    public void testRemoveValue_MultipleRemovals_ConsistentState() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key1", 10);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key2", 20);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key3", 30);
                                                                                                                                                                                                                                                                        keyedValues.addValue("Key4", 40);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Action - remove multiple elements
                                                                                                                                                                                                                                                                        keyedValues.removeValue(1); // Remove Key2
                                                                                                                                                                                                                                                                        keyedValues.removeValue(1); // Now removes Key3 (original index 2)
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                                        assertEquals(2, keyedValues.getItemCount());
                                                                                                                                                                                                                                                                        assertEquals("Key1", keyedValues.getKey(0));
                                                                                                                                                                                                                                                                        assertEquals("Key4", keyedValues.getKey(1));
                                                                                                                                                                                                                                                                        assertEquals(10, keyedValues.getValue(0));
                                                                                                                                                                                                                                                                        assertEquals(40, keyedValues.getValue(1));
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify index map
                                                                                                                                                                                                                                                                        assertEquals(0, keyedValues.getIndex("Key1"));
                                                                                                                                                                                                                                                                        assertEquals(1, keyedValues.getIndex("Key4"));
                                                                                                                                                                                                                                                                        assertEquals(-1, keyedValues.getIndex("Key2"));
                                                                                                                                                                                                                                                                        assertEquals(-1, keyedValues.getIndex("Key3"));
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                            public void testRemoveValueShouldCallRebuildIndexExactlyOnce() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                DefaultKeyedValues instance = spy(new DefaultKeyedValues());
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Add some test data
                                                                                                                                                                                                                                                                Comparable<String> testKey = "testKey";
                                                                                                                                                                                                                                                                Number testValue = 42;
                                                                                                                                                                                                                                                                instance.addValue(testKey, testValue);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify initial state
                                                                                                                                                                                                                                                                assertEquals(1, instance.getItemCount());
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Get the rebuildIndex method and make it accessible
                                                                                                                                                                                                                                                                Method rebuildIndexMethod = DefaultKeyedValues.class.getDeclaredMethod("rebuildIndex");
                                                                                                                                                                                                                                                                rebuildIndexMethod.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Reset the call count before the actual test
                                                                                                                                                                                                                                                                reset(instance);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                instance.removeValue(0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                // The mutant calls rebuildIndex() twice, while original calls once
                                                                                                                                                                                                                                                                verify(instance, times(1)).removeValue(0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Additional assertions to ensure removal worked
                                                                                                                                                                                                                                                                assertEquals(0, instance.getItemCount());
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify rebuildIndex was called exactly once using reflection
                                                                                                                                                                                                                                                                // Note: We can't directly verify private method calls with Mockito,
                                                                                                                                                                                                                                                                // so we're verifying the observable behavior instead
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testRemoveValueShouldCallRebuildIndexOnce() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                DefaultKeyedValues values = spy(new DefaultKeyedValues());
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Add test data
                                                                                                                                                                                                                                                                Comparable<String> key = "testKey";
                                                                                                                                                                                                                                                                values.addValue(key, 10);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Mock getIndex to return valid index
                                                                                                                                                                                                                                                                when(values.getIndex(key)).thenReturn(0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Get the rebuildIndex method and make it accessible
                                                                                                                                                                                                                                                                Method rebuildIndexMethod = DefaultKeyedValues.class.getDeclaredMethod("rebuildIndex");
                                                                                                                                                                                                                                                                rebuildIndexMethod.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                values.removeValue(key);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify rebuildIndex was called exactly once using reflection
                                                                                                                                                                                                                                                                verify(values, times(1)).getIndex(key);
                                                                                                                                                                                                                                                                rebuildIndexMethod.invoke(values);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testRemoveValueAtZeroIndexShouldSucceed() {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                                Comparable<String> key = "testKey";
                                                                                                                                                                                                                                                                Number value = 10;
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Add a value at index 0
                                                                                                                                                                                                                                                                dkv.addValue(key, value);
                                                                                                                                                                                                                                                                assertEquals(1, dkv.getItemCount());
                                                                                                                                                                                                                                                                assertEquals(value, dkv.getValue(0));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test removal at index 0
                                                                                                                                                                                                                                                                dkv.removeValue(0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify the removal was successful
                                                                                                                                                                                                                                                                assertEquals(0, dkv.getItemCount());
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify the key and value were removed
                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                    dkv.getValue(0);
                                                                                                                                                                                                                                                                    fail("Expected IndexOutOfBoundsException");
                                                                                                                                                                                                                                                                } catch (IndexOutOfBoundsException e) {
                                                                                                                                                                                                                                                                    // Expected behavior
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                    public void testRemoveValueWithKeyAtFirstPosition() {
                                                                                                                                                                                                                                                        // Initialize test objects
                                                                                                                                                                                                                                                        DefaultKeyedValues defaultKeyedValues = new DefaultKeyedValues();
                                                                                                                                                                                                                                                        Comparable<String> key = "TestKey";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Setup - add a value at index 0
                                                                                                                                                                                                                                                        defaultKeyedValues.addValue(key, 10.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify the key exists at index 0
                                                                                                                                                                                                                                                        assertEquals(0, defaultKeyedValues.getIndex(key));
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            // This should work in original code, but fail in mutated code
                                                                                                                                                                                                                                                            defaultKeyedValues.removeValue(key);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Verify removal was successful
                                                                                                                                                                                                                                                            assertEquals(-1, defaultKeyedValues.getIndex(key));
                                                                                                                                                                                                                                                        } catch (UnknownKeyException e) {
                                                                                                                                                                                                                                                            // This will be caught for the mutated version
                                                                                                                                                                                                                                                            fail("Should not throw exception for existing key at index 0");
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testRemoveValueWithNegativeIndexShouldNotModifyState() {
                                                                                                                                                                                                                                                        // Setup test data
                                                                                                                                                                                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                        dkv.addValue("Key1", 10.0);
                                                                                                                                                                                                                                                        dkv.addValue("Key2", 20.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Store original state
                                                                                                                                                                                                                                                        ArrayList<Comparable> originalKeys = new ArrayList<>(dkv.getKeys());
                                                                                                                                                                                                                                                        ArrayList<Number> originalValues = new ArrayList<>();
                                                                                                                                                                                                                                                        for (int i = 0; i < dkv.getItemCount(); i++) {
                                                                                                                                                                                                                                                            originalValues.add(dkv.getValue(i));
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Attempt to remove at negative index
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            dkv.removeValue(-1);
                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                            fail("removeValue(-1) should not throw exception in original implementation");
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify state remains unchanged
                                                                                                                                                                                                                                                        assertEquals("Keys should remain unchanged after removeValue(-1)", 
                                                                                                                                                                                                                                                            originalKeys, dkv.getKeys());
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                        ArrayList<Number> currentValues = new ArrayList<>();
                                                                                                                                                                                                                                                        for (int i = 0; i < dkv.getItemCount(); i++) {
                                                                                                                                                                                                                                                            currentValues.add(dkv.getValue(i));
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        assertEquals("Values should remain unchanged after removeValue(-1)",
                                                                                                                                                                                                                                                            originalValues, currentValues);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testRemoveValueWithUnknownKeyShouldThrowException() {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        DefaultKeyedValues values = new DefaultKeyedValues();
                                                                                                                                                                                                                                                        Comparable<String> unknownKey = "non-existent-key";
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // We need to mock the getIndex behavior since it's used internally
                                                                                                                                                                                                                                                        // Create a spy to partially mock the real object
                                                                                                                                                                                                                                                        DefaultKeyedValues spyValues = spy(values);
                                                                                                                                                                                                                                                        when(spyValues.getIndex(unknownKey)).thenReturn(-1);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Expect the exception
                                                                                                                                                                                                                                                        thrown.expect(UnknownKeyException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage("The key (" + unknownKey + ") is not recognised.");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                        spyValues.removeValue(unknownKey);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                public void testHashCodeWithNullKeys() {
                                                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                    // Set keys to null through reflection since it's private
                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                        java.lang.reflect.Field field = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                                                                                                        field.set(dkv, null);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Original behavior should return 0
                                                                                                                                                                                                                                                        assertEquals(0, dkv.hashCode());
                                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                                        fail("Failed to test hashCode with null keys due to reflection error");
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testHashCodeWithNonNullKeys() {
                                                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                                    // Add some keys to ensure keys list is not null
                                                                                                                                                                                                                                                    dkv.addValue("Key1", 10);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get expected hash code from the keys list directly
                                                                                                                                                                                                                                                    int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify hashCode returns the proper value
                                                                                                                                                                                                                                                    assertEquals(expectedHash, dkv.hashCode());
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                        public void testHashCodeWithNullKeys1() {
                                                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Use reflection to set private keys field to null
                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                                                keysField.setAccessible(true);
                                                                                                                                                                                                                                                keysField.set(dkv, null);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                    int result = dkv.hashCode();
                                                                                                                                                                                                                                                    // Original code should return 0, mutant would throw NullPointerException
                                                                                                                                                                                                                                                    assertEquals(0, result);
                                                                                                                                                                                                                                                } catch (NullPointerException e) {
                                                                                                                                                                                                                                                    // This indicates the mutant was caught
                                                                                                                                                                                                                                                    fail("NullPointerException was thrown, indicating the mutant was detected");
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                fail("Failed to set keys field to null via reflection: " + e.getMessage());
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                        public void testHashCodeWithNonNullKeys1() {
                                                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                            // Add a value using public method instead of accessing private field
                                                                                                                                                                                                                                            dkv.addValue("testKey", 1.0);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            int result = dkv.hashCode();
                                                                                                                                                                                                                                            // Original code should return proper hash code, mutant would return 0
                                                                                                                                                                                                                                            assertNotEquals(0, result);
                                                                                                                                                                                                                                            assertEquals(dkv.getKeys().hashCode(), result);
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                        public void testHashCodeWithNonNullKeys2() {
                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                            dkv.addValue("Key1", 10);  // This will populate the keys list
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Test - original should return keys.hashCode(), mutant will return 0
                                                                                                                                                                                                                                            int expected = dkv.getKeys().hashCode();
                                                                                                                                                                                                                                            int actual = dkv.hashCode();
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            assertEquals("Hash code should equal keys list hash code", expected, actual);
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                        public void testHashCodeWithNullKeys2() {
                                                                                                                                                                                                                                            // Setup - create instance with null keys
                                                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                // Force keys to be null using reflection
                                                                                                                                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                                                keysField.setAccessible(true);
                                                                                                                                                                                                                                                keysField.set(dkv, null);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test - original should return 0, mutant will throw NullPointerException
                                                                                                                                                                                                                                                int result = dkv.hashCode();
                                                                                                                                                                                                                                                assertEquals("Hash code should be 0 when keys is null", 0, result);
                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                fail("Should not throw exception for null keys in original implementation");
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                public void testHashCodeWithNonNullKeys3() {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        // Get the private keys field
                                                                                                                                                                                                                                        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Set the keys field with a new ArrayList containing our test key
                                                                                                                                                                                                                                        List<String> keys = new ArrayList<String>();
                                                                                                                                                                                                                                        keys.add("testKey");
                                                                                                                                                                                                                                        keysField.set(dkv, keys);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Test - original should return keys.hashCode(), mutant returns 0
                                                                                                                                                                                                                                        assertNotEquals("Hash code should not be 0 when keys is not null", 
                                                                                                                                                                                                                                                        0, dkv.hashCode());
                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                        fail("Failed to access private fields using reflection: " + e.getMessage());
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testHashCodeWithNullKeys3() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private keys field to null
                                                                                                                                                                                                                                    Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test - should return 0 when keys is null
                                                                                                                                                                                                                                    assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                                                                                                                                                 0, dkv.hashCode());
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testHashCodeWithNullKeys4() {
                                                                                                                                                                                                                                    // Create instance with null keys (via reflection or constructor if possible)
                                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Force keys to be null (since constructor initializes it, we need reflection)
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Test that hashCode returns 0 when keys is null
                                                                                                                                                                                                                                        assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                        fail("Failed to set keys to null via reflection");
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testHashCodeWithNonNullKeys4() {
                                                                                                                                                                                                                                    // Create instance with some keys
                                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                                    dkv.addValue("Key1", 10);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Calculate expected hash code
                                                                                                                                                                                                                                    int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test that hashCode returns correct value
                                                                                                                                                                                                                                    assertEquals("Hash code should match keys hash code", expectedHash, dkv.hashCode());
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                        public void testHashCodeWithNullKeys5() throws Exception {
                                                                                                                                                                                                                            // Create object
                                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to set private keys field to null
                                                                                                                                                                                                                            Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                            keysField.setAccessible(true);
                                                                                                                                                                                                                            keysField.set(dkv, null);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test that hashCode returns 0 (original behavior)
                                                                                                                                                                                                                            // This will fail if mutant is present (would return 1)
                                                                                                                                                                                                                            assertEquals(0, dkv.hashCode());
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testHashCodeWithNonNullKeys5() {
                                                                                                                                                                                                                            // Create normal object
                                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test that hashCode returns keys.hashCode()
                                                                                                                                                                                                                            assertEquals(dkv.getKeys().hashCode(), dkv.hashCode());
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testHashCodeWhenKeysIsNull() {
                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to set keys to null since it's private
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                                keysField.setAccessible(true);
                                                                                                                                                                                                                                keysField.set(dkv, null);
                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                fail("Failed to set keys to null via reflection");
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test - original should return 0, mutant returns -1
                                                                                                                                                                                                                            assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testHashCodeWhenKeysIsNotNull() {
                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                            dkv.addValue("Key1", 10); // This will populate the keys list
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test - should return keys.hashCode()
                                                                                                                                                                                                                            assertEquals("Hash code should match keys.hashCode()", 
                                                                                                                                                                                                                                        dkv.getKeys().hashCode(), dkv.hashCode());
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                public void testHashCodeWhenKeysIsNull1() throws Exception {
                                                                                                                                                                                                                    // Create instance
                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to set keys to null
                                                                                                                                                                                                                    Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test that hashCode returns 0 when keys is null
                                                                                                                                                                                                                    assertEquals("HashCode should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Additional test for equals consistency
                                                                                                                                                                                                                    DefaultKeyedValues other = new DefaultKeyedValues();
                                                                                                                                                                                                                    keysField.set(other, null);
                                                                                                                                                                                                                    assertTrue("Equal objects should have equal hash codes", 
                                                                                                                                                                                                                        dkv.equals(other) ? dkv.hashCode() == other.hashCode() : true);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testHashCodeWhenKeysIsEmpty() {
                                                                                                                                                                                                                    // Create instance with empty keys (by default constructor)
                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Should return empty list's hashCode (which is 1)
                                                                                                                                                                                                                    assertEquals("HashCode should match empty list's hashCode", 
                                                                                                                                                                                                                        1, dkv.hashCode());
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testHashCodeReturnsDifferentValuesForDifferentKeys() {
                                                                                                                                                                                                                    // Create first instance with some keys
                                                                                                                                                                                                                    DefaultKeyedValues instance1 = new DefaultKeyedValues();
                                                                                                                                                                                                                    instance1.addValue("Key1", 10);
                                                                                                                                                                                                                    instance1.addValue("Key2", 20);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create second instance with different keys
                                                                                                                                                                                                                    DefaultKeyedValues instance2 = new DefaultKeyedValues();
                                                                                                                                                                                                                    instance2.addValue("KeyA", 30);
                                                                                                                                                                                                                    instance2.addValue("KeyB", 40);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Get hash codes
                                                                                                                                                                                                                    int hashCode1 = instance1.hashCode();
                                                                                                                                                                                                                    int hashCode2 = instance2.hashCode();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Assert they are different (would fail with mutant)
                                                                                                                                                                                                                    assertNotEquals("Hash codes should be different for different keys", 
                                                                                                                                                                                                                                   hashCode1, hashCode2);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Additional check that hash code isn't just 42
                                                                                                                                                                                                                    assertNotEquals("Hash code should not be constant value 42", 
                                                                                                                                                                                                                                   42, hashCode1);
                                                                                                                                                                                                                    assertNotEquals("Hash code should not be constant value 42", 
                                                                                                                                                                                                                                   42, hashCode2);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testHashCodeWithNullKeys6() {
                                                                                                                                                                                                                    DefaultKeyedValues instance = new DefaultKeyedValues();
                                                                                                                                                                                                                    // keys is empty but not null
                                                                                                                                                                                                                    assertEquals(0, instance.hashCode());
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // For completeness, test with null keys (though constructor initializes it)
                                                                                                                                                                                                                    instance = new DefaultKeyedValues();
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        // Use reflection to set keys to null for testing
                                                                                                                                                                                                                        java.lang.reflect.Field field = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                                                                        field.set(instance, null);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        assertEquals(0, instance.hashCode());
                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                        fail("Failed to test null keys case due to reflection error");
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testHashCodeReturnsSameValueAsKeysHashCode() {
                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                    dkv.addValue("Key1", 10.0);
                                                                                                                                                                                                                    dkv.addValue("Key2", 20.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Get the expected hash code from the keys list
                                                                                                                                                                                                                    int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify the hash code matches the keys' hash code
                                                                                                                                                                                                                    assertEquals("Hash code should equal keys.hashCode()", 
                                                                                                                                                                                                                                 expectedHash, dkv.hashCode());
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // This will fail with the mutant since mutant returns 42 instead
                                                                                                                                                                                                                    // of the actual keys.hashCode()
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                public void testHashCodeReturnsZeroForEmptyKeys() {
                                                                                                                                                                                                                    // Setup empty DefaultKeyedValues
                                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify hash code is 0 when keys is empty
                                                                                                                                                                                                                    assertEquals("Hash code should be 0 for empty keys", 
                                                                                                                                                                                                                                 0, dkv.hashCode());
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                            public void testHashCodeWithNullKeys7() {
                                                                                                                                                                                                                // Create instance and set keys to null through reflection
                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                try {
                                                                                                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test should pass for original implementation (returns 0)
                                                                                                                                                                                                                    // and fail for mutant (throws NullPointerException)
                                                                                                                                                                                                                    assertEquals(0, dkv.hashCode());
                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                    fail("Failed to set keys to null via reflection");
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                            public void testHashCodeMutantBehavior() {
                                                                                                                                                                                                                // This test expects NPE and would pass for mutant but fail for original
                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                try {
                                                                                                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    dkv.hashCode();
                                                                                                                                                                                                                    fail("Expected NullPointerException but none was thrown");
                                                                                                                                                                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                                                                                    fail("Failed to set keys to null via reflection");
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testHashCodeWithNullKeys8() {
                                                                                                                                                                                                                // Create an object and set keys to null through reflection
                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                try {
                                                                                                                                                                                                                    // Use reflection to set the private keys field to null
                                                                                                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test the original behavior - should return 0
                                                                                                                                                                                                                    assertEquals(0, dkv.hashCode());
                                                                                                                                                                                                                    
                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                    fail("Failed to set keys to null via reflection");
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                            public void testMutatedHashCodeWithNullKeys() {
                                                                                                                                                                                                                // This test would catch the mutant by expecting NPE
                                                                                                                                                                                                                // In reality, we can't test the mutant directly, but this shows
                                                                                                                                                                                                                // what behavior would catch it
                                                                                                                                                                                                                
                                                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                                try {
                                                                                                                                                                                                                    // Use reflection to set the private keys field to null
                                                                                                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // This would throw NPE with the mutant
                                                                                                                                                                                                                    dkv.hashCode();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                } catch (IllegalAccessException | NoSuchFieldException e) {
                                                                                                                                                                                                                    fail("Failed to set keys to null via reflection");
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                        public void testHashCodeWithNonNullKeys6() {
                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                            ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                                                                                                                                                            testKeys.add("key1");
                                                                                                                                                                                                            testKeys.add("key2");
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to set the private keys field since there's no public setter
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                keysField.setAccessible(true);
                                                                                                                                                                                                                keysField.set(dkv, testKeys);
                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                fail("Failed to set keys field via reflection");
                                                                                                                                                                                                            }
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test - original should return keys.hashCode(), mutant will return 0
                                                                                                                                                                                                            int expected = testKeys.hashCode();
                                                                                                                                                                                                            int actual = dkv.hashCode();
                                                                                                                                                                                                            assertEquals("Hash code should equal keys.hashCode() when keys is not null", 
                                                                                                                                                                                                                         expected, actual);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testHashCodeWithNullKeys9() {
                                                                                                                                                                                                            // Setup - new instance has empty keys list, not null
                                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to set keys to null
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                                keysField.setAccessible(true);
                                                                                                                                                                                                                keysField.set(dkv, null);
                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                fail("Failed to set keys field via reflection");
                                                                                                                                                                                                            }
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test - both original and mutant should return 0
                                                                                                                                                                                                            assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                                                                                                                         0, dkv.hashCode());
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                public void testHashCodeWithNonNullKeys7() {
                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                    ArrayList<Comparable> keys = new ArrayList<>();
                                                                                                                                                                                                    keys.add("key1");
                                                                                                                                                                                                    
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        // Use reflection to access private field
                                                                                                                                                                                                        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                                                                        keysField.set(dkv, keys);
                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                        fail("Failed to set keys field via reflection: " + e.getMessage());
                                                                                                                                                                                                    }
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test
                                                                                                                                                                                                    int result = dkv.hashCode();
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                    assertNotEquals("Hash code should not be 0 when keys exist", 0, result);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testHashCodeWithNullKeys10() {
                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                                                                        fail("Failed to set keys field to null via reflection");
                                                                                                                                                                                                    }
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Test
                                                                                                                                                                                                    int result = dkv.hashCode();
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                    assertEquals("Hash code should be 0 when keys are null", 0, result);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testHashCodeWithNullKeys11() {
                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                    // Set keys to null through reflection since it's private
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Original behavior should return 0, mutant will throw NullPointerException
                                                                                                                                                                                                        assertEquals(0, dkv.hashCode());
                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                    }
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testHashCodeWithNonNullKeys8() {
                                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                                    // Add some keys to ensure keys list is not null
                                                                                                                                                                                                    dkv.addValue("Key1", 10);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Both original and mutant should return same hash code when keys is not null
                                                                                                                                                                                                    int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                                                                                    assertEquals(expectedHash, dkv.hashCode());
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                        public void testHashCodeWithNonNullKeys9() throws Exception {
                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                            
                                                                                                                                                                                            // Use reflection to access private keys field
                                                                                                                                                                                            Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                            keysField.setAccessible(true);
                                                                                                                                                                                            List keys = (List) keysField.get(dkv);
                                                                                                                                                                                            
                                                                                                                                                                                            // Add test key
                                                                                                                                                                                            keys.add("testKey");
                                                                                                                                                                                            
                                                                                                                                                                                            // Get expected hash code
                                                                                                                                                                                            int expectedHash = keys.hashCode();
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify
                                                                                                                                                                                            assertEquals("Hash code should match keys' hash code", 
                                                                                                                                                                                                        expectedHash, dkv.hashCode());
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testHashCodeWithNullKeys12() throws Exception {
                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                            Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                            keysField.setAccessible(true);
                                                                                                                                                                                            keysField.set(dkv, null); // set private keys field to null
                                                                                                                                                                                            dkv.hashCode(); // should throw NPE with mutant, pass with original
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testHashCodeWithDifferentKeysSameSize() {
                                                                                                                                                                                            // Setup two instances with different keys but same size
                                                                                                                                                                                            DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                                            DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                                            
                                                                                                                                                                                            // Add different keys but same count
                                                                                                                                                                                            dkv1.addValue("Key1", 1.0);
                                                                                                                                                                                            dkv1.addValue("Key2", 2.0);
                                                                                                                                                                                            
                                                                                                                                                                                            dkv2.addValue("KeyA", 1.0);
                                                                                                                                                                                            dkv2.addValue("KeyB", 2.0);
                                                                                                                                                                                            
                                                                                                                                                                                            // Original should return different hash codes, mutant will return same (2)
                                                                                                                                                                                            assertNotEquals("Hash codes should differ for different keys", 
                                                                                                                                                                                                            dkv1.hashCode(), dkv2.hashCode());
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testHashCodeWithNullKeys13() {
                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                            // keys is initialized as empty ArrayList, not null
                                                                                                                                                                                            dkv.clear(); // This might set keys to null or empty
                                                                                                                                                                                            
                                                                                                                                                                                            // To properly test null case, we need to set keys to null via reflection
                                                                                                                                                                                            try {
                                                                                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                                keysField.setAccessible(true);
                                                                                                                                                                                                keysField.set(dkv, null);
                                                                                                                                                                                                
                                                                                                                                                                                                assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                                                                                                             0, dkv.hashCode());
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to test null keys case due to reflection error");
                                                                                                                                                                                            }
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testHashCodeConsistency() {
                                                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                            dkv.addValue("Key1", 1.0);
                                                                                                                                                                                            dkv.addValue("Key2", 2.0);
                                                                                                                                                                                            
                                                                                                                                                                                            int firstHash = dkv.hashCode();
                                                                                                                                                                                            int secondHash = dkv.hashCode();
                                                                                                                                                                                            
                                                                                                                                                                                            assertEquals("Hash code should be consistent", firstHash, secondHash);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                public void testHashCodeDetectsMutant() {
                                                                                                                                                                                    // Create two different key sets with same size
                                                                                                                                                                                    DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                                    DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                                    
                                                                                                                                                                                    // Add different keys but same count
                                                                                                                                                                                    dkv1.addValue("Key1", 1.0);
                                                                                                                                                                                    dkv1.addValue("Key2", 2.0);
                                                                                                                                                                                    
                                                                                                                                                                                    dkv2.addValue("KeyA", 1.0);
                                                                                                                                                                                    dkv2.addValue("KeyB", 2.0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Original would return different hash codes, mutant would return same (2)
                                                                                                                                                                                    assertNotEquals("Hash codes should differ for different key sets", 
                                                                                                                                                                                                   dkv1.hashCode(), dkv2.hashCode());
                                                                                                                                                                                    
                                                                                                                                                                                    // Test empty vs null keys
                                                                                                                                                                                    DefaultKeyedValues dkv3 = new DefaultKeyedValues();
                                                                                                                                                                                    DefaultKeyedValues dkv4 = new DefaultKeyedValues();
                                                                                                                                                                                    
                                                                                                                                                                                    try {
                                                                                                                                                                                        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                                                        keysField.set(dkv4, null);
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        fail("Failed to set keys field to null via reflection");
                                                                                                                                                                                    }
                                                                                                                                                                                    
                                                                                                                                                                                    // Both should return 0 (original and mutant agree here)
                                                                                                                                                                                    assertEquals(0, dkv4.hashCode());
                                                                                                                                                                                    
                                                                                                                                                                                    // Test single element vs multiple elements
                                                                                                                                                                                    DefaultKeyedValues dkv5 = new DefaultKeyedValues();
                                                                                                                                                                                    dkv5.addValue("Single", 1.0);
                                                                                                                                                                                    assertNotEquals("Single element hash should differ from two elements",
                                                                                                                                                                                                   dkv1.hashCode(), dkv5.hashCode());
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testHashCodeWithSameKeysContent() {
                                                                                                                                                                                    // Setup two objects with same keys content but different list instances
                                                                                                                                                                                    DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                                    DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                                    
                                                                                                                                                                                    // Use same keys but different ArrayList instances
                                                                                                                                                                                    ArrayList<Comparable> keys1 = new ArrayList<>();
                                                                                                                                                                                    keys1.add("Key1");
                                                                                                                                                                                    keys1.add("Key2");
                                                                                                                                                                                    
                                                                                                                                                                                    ArrayList<Comparable> keys2 = new ArrayList<>();
                                                                                                                                                                                    keys2.add("Key1");
                                                                                                                                                                                    keys2.add("Key2");
                                                                                                                                                                                    
                                                                                                                                                                                    // Set the keys using reflection since keys is private
                                                                                                                                                                                    try {
                                                                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                                                        keysField.set(dkv1, keys1);
                                                                                                                                                                                        keysField.set(dkv2, keys2);
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        fail("Failed to set keys field via reflection");
                                                                                                                                                                                    }
                                                                                                                                                                                    
                                                                                                                                                                                    // Test: hash codes should be equal for same content (original behavior)
                                                                                                                                                                                    // The mutant would fail this test because identityHashCode would differ
                                                                                                                                                                                    assertEquals("Hash codes should be equal for same keys content", 
                                                                                                                                                                                                 dkv1.hashCode(), dkv2.hashCode());
                                                                                                                                                                                    
                                                                                                                                                                                    // Additional check: verify hash code matches keys.hashCode()
                                                                                                                                                                                    assertEquals("Hash code should match keys.hashCode()", 
                                                                                                                                                                                                 keys1.hashCode(), dkv1.hashCode());
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testHashCodeReturnsSameValueForEqualKeyLists() {
                                                                                                                                                                                    // Create two instances with same keys
                                                                                                                                                                                    DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                                    DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                                    
                                                                                                                                                                                    // Add same keys to both instances
                                                                                                                                                                                    Comparable<String> key1 = "Key1";
                                                                                                                                                                                    Comparable<String> key2 = "Key2";
                                                                                                                                                                                    dkv1.addValue(key1, 1.0);
                                                                                                                                                                                    dkv1.addValue(key2, 2.0);
                                                                                                                                                                                    dkv2.addValue(key1, 3.0); // different values shouldn't affect keys hashCode
                                                                                                                                                                                    dkv2.addValue(key2, 4.0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get hashCodes
                                                                                                                                                                                    int hashCode1 = dkv1.hashCode();
                                                                                                                                                                                    int hashCode2 = dkv2.hashCode();
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify hashCodes are equal (would fail with mutated version)
                                                                                                                                                                                    assertEquals("Hash codes should be equal for instances with same keys", 
                                                                                                                                                                                                hashCode1, hashCode2);
                                                                                                                                                                                    
                                                                                                                                                                                    // Additional verification that it's not just returning 0
                                                                                                                                                                                    assertTrue("Hash code should not be 0 when keys exist", hashCode1 != 0);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testHashCodeReturnsZeroForEmptyKeys1() {
                                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                    assertEquals("Hash code should be 0 when keys is null or empty", 
                                                                                                                                                                                                0, dkv.hashCode());
                                                                                                                                                                                }

    @Test
                                                                                                                                                                            public void testHashCodeReturnsDifferentValuesForDifferentKeys1() {
                                                                                                                                                                                // Setup two different key-value pairs
                                                                                                                                                                                DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                                DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                                
                                                                                                                                                                                // Add different keys to each instance
                                                                                                                                                                                dkv1.addValue("Key1", 1.0);
                                                                                                                                                                                dkv2.addValue("Key2", 2.0);
                                                                                                                                                                                
                                                                                                                                                                                // Original implementation should return different hash codes
                                                                                                                                                                                // Mutated version would return same hash code (0)
                                                                                                                                                                                assertNotEquals("Hash codes should differ for different keys", 
                                                                                                                                                                                               dkv1.hashCode(), dkv2.hashCode());
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testHashCodeReturnsZeroForNullKeys() {
                                                                                                                                                                                // Create instance with null keys (simulate via reflection for testing)
                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                try {
                                                                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                                                                    
                                                                                                                                                                                    // Both original and mutated versions should return 0
                                                                                                                                                                                    assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                                                                                                 0, dkv.hashCode());
                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                    fail("Failed to set keys to null via reflection");
                                                                                                                                                                                }
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testHashCodeReturnsDifferentValuesForDifferentKeys2() {
                                                                                                                                                                                // Create first object with some keys
                                                                                                                                                                                DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                                dkv1.addValue("Key1", 10);
                                                                                                                                                                                
                                                                                                                                                                                // Create second object with different keys
                                                                                                                                                                                DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                                dkv2.addValue("Key2", 20);
                                                                                                                                                                                
                                                                                                                                                                                // Verify hash codes are different (original behavior)
                                                                                                                                                                                // Mutated version would return 0 for both
                                                                                                                                                                                assertNotEquals("Hash codes should be different for different keys", 
                                                                                                                                                                                               dkv1.hashCode(), dkv2.hashCode());
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testHashCodeReturnsConsistentValue() {
                                                                                                                                                                                // Create object with some keys
                                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                                dkv.addValue("Key1", 10);
                                                                                                                                                                                
                                                                                                                                                                                int firstHash = dkv.hashCode();
                                                                                                                                                                                int secondHash = dkv.hashCode();
                                                                                                                                                                                
                                                                                                                                                                                // Verify hash code is consistent
                                                                                                                                                                                assertEquals("Hash code should be consistent for same object state",
                                                                                                                                                                                            firstHash, secondHash);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                    public void testHashCodeReturnsZeroForNullKeys1() throws Exception {
                                                                                                                                                                        // Create object
                                                                                                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to set private keys field to null
                                                                                                                                                                        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                                                        
                                                                                                                                                                        // Should return 0 when keys is null
                                                                                                                                                                        assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                                                                                     0, dkv.hashCode());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testHashCodeReturnsDifferentValuesForDifferentKeys3() {
                                                                                                                                                                        // Setup two different instances with different keys
                                                                                                                                                                        DefaultKeyedValues instance1 = new DefaultKeyedValues();
                                                                                                                                                                        DefaultKeyedValues instance2 = new DefaultKeyedValues();
                                                                                                                                                                        
                                                                                                                                                                        // Add different keys to each instance
                                                                                                                                                                        instance1.addValue("Key1", 10);
                                                                                                                                                                        instance2.addValue("Key2", 20);
                                                                                                                                                                        
                                                                                                                                                                        // Original behavior: hash codes should be different
                                                                                                                                                                        // Mutated behavior: both will return 1
                                                                                                                                                                        assertNotEquals("Hash codes should be different for different keys", 
                                                                                                                                                                                        instance1.hashCode(), instance2.hashCode());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testHashCodeReturnsZeroForNullKeys2() {
                                                                                                                                                                        // Setup instance with null keys (simulate via reflection if needed)
                                                                                                                                                                        DefaultKeyedValues instance = new DefaultKeyedValues();
                                                                                                                                                                        
                                                                                                                                                                        // Original behavior: should return 0 when keys is null
                                                                                                                                                                        // Mutated behavior: will return 1
                                                                                                                                                                        // Note: Since keys is initialized in constructor, we'd need reflection to test null case
                                                                                                                                                                        // Alternatively, we can clear the keys
                                                                                                                                                                        instance.clear();
                                                                                                                                                                        assertEquals("Hash code should be 0 for empty/null keys", 
                                                                                                                                                                                     0, instance.hashCode());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testHashCodeConsistentWithSameKeys() {
                                                                                                                                                                        // Setup two instances with same keys
                                                                                                                                                                        DefaultKeyedValues instance1 = new DefaultKeyedValues();
                                                                                                                                                                        DefaultKeyedValues instance2 = new DefaultKeyedValues();
                                                                                                                                                                        
                                                                                                                                                                        // Add same keys to both instances
                                                                                                                                                                        instance1.addValue("Key1", 10);
                                                                                                                                                                        instance2.addValue("Key1", 10);
                                                                                                                                                                        
                                                                                                                                                                        // Original behavior: hash codes should be equal
                                                                                                                                                                        // Mutated behavior: both will return 1 (still equal, but not catching mutation)
                                                                                                                                                                        assertEquals("Hash codes should be equal for same keys", 
                                                                                                                                                                                     instance1.hashCode(), instance2.hashCode());
                                                                                                                                                                        
                                                                                                                                                                        // Additional check that it's not just returning 1
                                                                                                                                                                        assertNotEquals("Hash code should not be constant 1", 
                                                                                                                                                                                        1, instance1.hashCode());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testHashCodeReturnsDifferentValuesForDifferentKeys4() {
                                                                                                                                                                        // Create first instance with some keys
                                                                                                                                                                        DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                        dkv1.addValue("Key1", 10);
                                                                                                                                                                        dkv1.addValue("Key2", 20);
                                                                                                                                                                        
                                                                                                                                                                        // Create second instance with different keys
                                                                                                                                                                        DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                        dkv2.addValue("KeyA", 30);
                                                                                                                                                                        dkv2.addValue("KeyB", 40);
                                                                                                                                                                        
                                                                                                                                                                        // Get hash codes
                                                                                                                                                                        int hashCode1 = dkv1.hashCode();
                                                                                                                                                                        int hashCode2 = dkv2.hashCode();
                                                                                                                                                                        
                                                                                                                                                                        // Assert they are different (would fail with mutant)
                                                                                                                                                                        assertNotEquals("Hash codes should be different for different keys", 
                                                                                                                                                                                       hashCode1, hashCode2);
                                                                                                                                                                        
                                                                                                                                                                        // Additional check: hash code should not be 1 (would fail with mutant)
                                                                                                                                                                        assertNotEquals("Hash code should not be constant 1", 1, hashCode1);
                                                                                                                                                                        assertNotEquals("Hash code should not be constant 1", 1, hashCode2);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testHashCodeReturnsZeroForEmptyKeys2() {
                                                                                                                                                                        // Create instance with no keys
                                                                                                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                        
                                                                                                                                                                        // Get hash code
                                                                                                                                                                        int hashCode = dkv.hashCode();
                                                                                                                                                                        
                                                                                                                                                                        // Assert it's 0 (original behavior)
                                                                                                                                                                        assertEquals("Hash code should be 0 for empty keys", 0, hashCode);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testHashCodeReturnsSameValueForEqualObjects() {
                                                                                                                                                                    DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                    DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                    
                                                                                                                                                                    // Add same keys to both
                                                                                                                                                                    dkv1.addValue("Key1", 1.0);
                                                                                                                                                                    dkv2.addValue("Key1", 1.0);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals("Equal objects should have equal hash codes", 
                                                                                                                                                                                dkv1.hashCode(), dkv2.hashCode());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testHashCodeChangesWithDifferentKeys() {
                                                                                                                                                                    DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                                    DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                                    
                                                                                                                                                                    // Add different keys
                                                                                                                                                                    dkv1.addValue("Key1", 1.0);
                                                                                                                                                                    dkv2.addValue("Key2", 1.0);
                                                                                                                                                                    
                                                                                                                                                                    assertNotEquals("Different keys should produce different hash codes",
                                                                                                                                                                                   dkv1.hashCode(), dkv2.hashCode());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testHashCodeWithEmptyKeys() {
                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                    assertEquals("Empty keys should return 0", 0, dkv.hashCode());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testHashCodeWithNullKeys14() {
                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                    // Simulate keys being null (though constructor initializes it)
                                                                                                                                                                    try {
                                                                                                                                                                        java.lang.reflect.Field field = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                        field.set(dkv, null);
                                                                                                                                                                        
                                                                                                                                                                        assertEquals("Null keys should return 0", 0, dkv.hashCode());
                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                    }
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testHashCodeReturnsCorrectValue() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                    dkv.addValue("Key1", 10);
                                                                                                                                                                    dkv.addValue("Key2", 20);
                                                                                                                                                                    
                                                                                                                                                                    // Calculate expected hash code
                                                                                                                                                                    int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    assertEquals("Hash code should match keys list hash code", 
                                                                                                                                                                                 expectedHash, dkv.hashCode());
                                                                                                                                                                    
                                                                                                                                                                    // Test with empty keys
                                                                                                                                                                    dkv.clear();
                                                                                                                                                                    assertEquals("Hash code should be 0 for empty keys", 
                                                                                                                                                                                 0, dkv.hashCode());
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testHashCode() {
                                                                                                                                                                // Setup test data
                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                dkv.addValue("Key1", 10.0);
                                                                                                                                                                dkv.addValue("Key2", 20.0);
                                                                                                                                                                
                                                                                                                                                                // Calculate expected hash based on keys list's hashCode()
                                                                                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                                                
                                                                                                                                                                // Verify the actual hashCode matches expected
                                                                                                                                                                assertEquals("Hash code should be based on keys list's hashCode()", 
                                                                                                                                                                            expectedHash, dkv.hashCode());
                                                                                                                                                                
                                                                                                                                                                // The mutant would fail this test because:
                                                                                                                                                                // keys.toString().hashCode() would produce a different value than keys.hashCode()
                                                                                                                                                                // For example: 
                                                                                                                                                                // "[Key1, Key2]".hashCode() != Arrays.asList("Key1", "Key2").hashCode()
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testHashCodeWithKeys() {
                                                                                                                                                                // Setup test data
                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                dkv.addValue("Key1", 10);
                                                                                                                                                                dkv.addValue("Key2", 20);
                                                                                                                                                                
                                                                                                                                                                // Calculate expected hash code using original behavior
                                                                                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                                                
                                                                                                                                                                // The mutated version would do: dkv.getKeys().toString().hashCode()
                                                                                                                                                                int mutatedHash = dkv.getKeys().toString().hashCode();
                                                                                                                                                                
                                                                                                                                                                // Verify original behavior
                                                                                                                                                                assertEquals("Hash code should match keys list hash code", 
                                                                                                                                                                            expectedHash, dkv.hashCode());
                                                                                                                                                                
                                                                                                                                                                // This assertion would fail for the mutant
                                                                                                                                                                assertNotEquals("Hash code should not match toString().hashCode()", 
                                                                                                                                                                               mutatedHash, dkv.hashCode());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testHashCodeWithNullKeys15() {
                                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                                // For null keys, both original and mutant return 0
                                                                                                                                                                assertEquals(0, dkv.hashCode());
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testHashCodeConsistencyWithEquals() {
                                                                                                                                                            // Create two equal DefaultKeyedValues objects
                                                                                                                                                            DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                                                            DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                                                            
                                                                                                                                                            // Add same keys and values to both
                                                                                                                                                            Comparable key = "TestKey";
                                                                                                                                                            Number value = 10;
                                                                                                                                                            dkv1.addValue(key, value);
                                                                                                                                                            dkv2.addValue(key, value);
                                                                                                                                                            
                                                                                                                                                            // They should be equal
                                                                                                                                                            assertTrue(dkv1.equals(dkv2));
                                                                                                                                                            
                                                                                                                                                            // Therefore their hash codes should be equal
                                                                                                                                                            assertEquals("Equal objects must have equal hash codes", 
                                                                                                                                                                        dkv1.hashCode(), dkv2.hashCode());
                                                                                                                                                            
                                                                                                                                                            // Additionally test that hashCode is based on keys
                                                                                                                                                            DefaultKeyedValues dkv3 = new DefaultKeyedValues();
                                                                                                                                                            dkv3.addValue(key, value);
                                                                                                                                                            assertEquals("hashCode should be based on keys", 
                                                                                                                                                                        dkv1.hashCode(), dkv3.hashCode());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testHashCodeWithNullKeys16() {
                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                            assertEquals("hashCode should be 0 when keys is empty", 
                                                                                                                                                                        0, dkv.hashCode());
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testHashCodeWithKeys1() {
                                                                                                                                                            // Setup
                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                            ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                                                                                                            testKeys.add("Key1");
                                                                                                                                                            testKeys.add("Key2");
                                                                                                                                                            
                                                                                                                                                            // Using reflection to set the private keys field for testing
                                                                                                                                                            try {
                                                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                                keysField.setAccessible(true);
                                                                                                                                                                keysField.set(dkv, testKeys);
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Failed to set keys field via reflection");
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            int expectedHash = testKeys.hashCode();
                                                                                                                                                            int actualHash = dkv.hashCode();
                                                                                                                                                            
                                                                                                                                                            // Assert
                                                                                                                                                            assertEquals("hashCode() should return the hash code of the keys list", 
                                                                                                                                                                        expectedHash, actualHash);
                                                                                                                                                            
                                                                                                                                                            // The mutant would fail this test because:
                                                                                                                                                            // - Mutant returns super.hashCode() instead of keys.hashCode()
                                                                                                                                                            // - super.hashCode() would be different from keys.hashCode()
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testHashCodeWithNullKeys17() {
                                                                                                                                                            // Setup
                                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            int result = dkv.hashCode();
                                                                                                                                                            
                                                                                                                                                            // Assert
                                                                                                                                                            assertEquals("hashCode() should return 0 when keys is null", 
                                                                                                                                                                        0, result);
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testHashCodeWhenKeysIsNull2() {
                                                                                                                                                        // Setup
                                                                                                                                                        DefaultKeyedValues instance = new DefaultKeyedValues() {
                                                                                                                                                            // Override to return null keys
                                                                                                                                                            @Override
                                                                                                                                                            public List getKeys() {
                                                                                                                                                                return null;
                                                                                                                                                            }
                                                                                                                                                        };
                                                                                                                                                        
                                                                                                                                                        // Test - original should return 0 when keys is null
                                                                                                                                                        // Mutant would return super.hashCode() instead
                                                                                                                                                        assertEquals(0, instance.hashCode());
                                                                                                                                                        
                                                                                                                                                        // Additional verification that we're testing the right scenario
                                                                                                                                                        assertNull(instance.getKeys());
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testHashCodeWithNullKeys18() throws Exception {
                                                                                                                                                        // Create an instance with null keys
                                                                                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                        
                                                                                                                                                        // Use reflection to set keys to null since it's private
                                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                                        
                                                                                                                                                        // Test that hashCode returns 0 when keys is null
                                                                                                                                                        assertEquals(0, dkv.hashCode());
                                                                                                                                                        
                                                                                                                                                        // The mutant would fail this test by returning super.hashCode() instead of 0
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testHashCodeWithNullKeys19() {
                                                                                                                                                    // Create instance and set keys to null through reflection
                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                    try {
                                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                                        
                                                                                                                                                        // Test that hashCode returns 0 when keys is null (original behavior)
                                                                                                                                                        assertEquals(0, dkv.hashCode());
                                                                                                                                                        
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Failed to set keys to null via reflection");
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                                                public void testHashCodeWithEmptyKeys1() {
                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                    // With empty keys list, should return keys.hashCode()
                                                                                                                                                    assertEquals(dkv.getKeys().hashCode(), dkv.hashCode());
                                                                                                                                                }

    @Test
                                                                                                                                                public void testHashCodeWithNonEmptyKeys() {
                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                    dkv.addValue("Key1", 10);
                                                                                                                                                    // With non-empty keys list, should return keys.hashCode()
                                                                                                                                                    assertEquals(dkv.getKeys().hashCode(), dkv.hashCode());
                                                                                                                                                }

    @Test
                                                                                                                                                public void testHashCodeWhenKeysIsNull3() {
                                                                                                                                                    // Create a DefaultKeyedValues instance
                                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                    
                                                                                                                                                    // Set keys to null using reflection since it's private
                                                                                                                                                    try {
                                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Failed to set keys to null via reflection");
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    // Test that hashCode returns 0 when keys is null
                                                                                                                                                    assertEquals(0, dkv.hashCode());
                                                                                                                                                }

    @Test
                                                                                                                                            public void testHashCodeWithNullKeys20() {
                                                                                                                                                // Setup
                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                
                                                                                                                                                // Force keys to be null using reflection since it's private
                                                                                                                                                try {
                                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                                    
                                                                                                                                                    // Test - original should return 0, mutant would throw NullPointerException
                                                                                                                                                    assertEquals(0, dkv.hashCode());
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Reflection failed to set keys to null");
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                            public void testHashCodeWithNonNullKeys10() {
                                                                                                                                                // Setup normal case
                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                dkv.addValue("Key1", 10.0);
                                                                                                                                                
                                                                                                                                                // Calculate expected hash code
                                                                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                                
                                                                                                                                                // Test
                                                                                                                                                assertEquals(expectedHash, dkv.hashCode());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testHashCodeWithNullKeys21() {
                                                                                                                                                // Create new instance where keys is null (before initialization)
                                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                                
                                                                                                                                                // Original behavior should return 0 when keys is null
                                                                                                                                                // Mutated version would throw NullPointerException
                                                                                                                                                assertEquals(0, dkv.hashCode());
                                                                                                                                            }

    @Test
                                                                                                                                        public void testHashCodeWithNullKeys22() {
                                                                                                                                            // Create a DefaultKeyedValues instance
                                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                            
                                                                                                                                            // Use reflection to set the keys to null since it's private
                                                                                                                                            try {
                                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                                keysField.setAccessible(true);
                                                                                                                                                keysField.set(dkv, null);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Failed to set keys to null via reflection");
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Test the hashCode()
                                                                                                                                            int actualHashCode = dkv.hashCode();
                                                                                                                                            
                                                                                                                                            // Original would return 0, mutant would return Integer.MAX_VALUE
                                                                                                                                            assertEquals("Hash code should be 0 when keys is null", 0, actualHashCode);
                                                                                                                                        }

    @Test
                                                                                                                                public void testHashCodeWithNullKeys23() {
                                                                                                                                    // Create object
                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                    
                                                                                                                                    try {
                                                                                                                                        // Use reflection to set private keys field to null
                                                                                                                                        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                        
                                                                                                                                        // Test that hashCode returns 0 when keys is null
                                                                                                                                        assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                        fail("Failed to set keys field to null via reflection: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                                                                public void testHashCodeWithEmptyKeys2() throws Exception {
                                                                                                                                    // Create object with empty keys list
                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                    
                                                                                                                                    // Test that hashCode returns same value for empty keys and null keys
                                                                                                                                    int emptyHash = dkv.hashCode();
                                                                                                                                    
                                                                                                                                    // Use reflection to set keys to null
                                                                                                                                    Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                    
                                                                                                                                    int nullHash = dkv.hashCode();
                                                                                                                                    
                                                                                                                                    assertEquals("Hash code should be same for empty and null keys", emptyHash, nullHash);
                                                                                                                                }

    @Test
                                                                                                                                public void testHashCodeWithNullKeys24() {
                                                                                                                                    // Setup
                                                                                                                                    DefaultKeyedValues instance = new DefaultKeyedValues();
                                                                                                                                    
                                                                                                                                    // Use reflection to set keys to null since it's private
                                                                                                                                    try {
                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                        keysField.set(instance, null);
                                                                                                                                    } catch (Exception e) {
                                                                                                                                        fail("Failed to set keys to null via reflection");
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    // Test and verify
                                                                                                                                    int expected = 0; // Original behavior
                                                                                                                                    int actual = instance.hashCode();
                                                                                                                                    assertEquals("Hash code should be 0 when keys is null", expected, actual);
                                                                                                                                }

    @Test
                                                                                                                                public void testHashCodeWithNullKeys25() {
                                                                                                                                    // Setup
                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                    
                                                                                                                                    // Force keys to be null using reflection since it's private
                                                                                                                                    try {
                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                        keysField.set(dkv, null);
                                                                                                                                        
                                                                                                                                        // Test - original should return 0, mutant will return Integer.MIN_VALUE
                                                                                                                                        assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                                    } catch (Exception e) {
                                                                                                                                        fail("Failed to set keys to null via reflection");
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                                                                public void testHashCodeWithNonNullKeys11() {
                                                                                                                                    // Setup
                                                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                    ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                                                                                    testKeys.add("key1");
                                                                                                                                    testKeys.add("key2");
                                                                                                                                    
                                                                                                                                    // Force keys to our test list using reflection
                                                                                                                                    try {
                                                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                        keysField.setAccessible(true);
                                                                                                                                        keysField.set(dkv, testKeys);
                                                                                                                                        
                                                                                                                                        // Test - should return the same as testKeys.hashCode()
                                                                                                                                        assertEquals("Hash code should match keys list hash code", 
                                                                                                                                                    testKeys.hashCode(), dkv.hashCode());
                                                                                                                                    } catch (Exception e) {
                                                                                                                                        fail("Failed to set keys via reflection");
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                                                            public void testHashCodeWithNullKeys26() {
                                                                                                                                // Setup
                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                
                                                                                                                                // Force keys to be null using reflection
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                    
                                                                                                                                    // Also set indexMap to a known state to detect the mutant
                                                                                                                                    HashMap mockMap = mock(HashMap.class);
                                                                                                                                    when(mockMap.hashCode()).thenReturn(12345);
                                                                                                                                    
                                                                                                                                    java.lang.reflect.Field indexMapField = DefaultKeyedValues.class.getDeclaredField("indexMap");
                                                                                                                                    indexMapField.setAccessible(true);
                                                                                                                                    indexMapField.set(dkv, mockMap);
                                                                                                                                    
                                                                                                                                    // Test - original should return 0, mutant would return 12345
                                                                                                                                    assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                                    
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testHashCodeWithNonNullKeys12() {
                                                                                                                                // Setup normal object
                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                dkv.addValue("Key1", 10);
                                                                                                                                
                                                                                                                                // Calculate expected hash - should be same as keys.hashCode()
                                                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                                                
                                                                                                                                // Test
                                                                                                                                assertEquals("Hash code should match keys' hash code", expectedHash, dkv.hashCode());
                                                                                                                            }

    @Test
                                                                                                                            public void testHashCodeWhenKeysIsNull4() {
                                                                                                                                // Setup
                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                
                                                                                                                                // Set keys to null through reflection since it's private
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                    keysField.set(dkv, null);
                                                                                                                                    
                                                                                                                                    // Mock the indexMap to return a known hash code
                                                                                                                                    HashMap mockedMap = mock(HashMap.class);
                                                                                                                                    when(mockedMap.hashCode()).thenReturn(12345);
                                                                                                                                    
                                                                                                                                    java.lang.reflect.Field indexMapField = DefaultKeyedValues.class.getDeclaredField("indexMap");
                                                                                                                                    indexMapField.setAccessible(true);
                                                                                                                                    indexMapField.set(dkv, mockedMap);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Test - original should return 0 when keys is null
                                                                                                                                // Mutant will return indexMap.hashCode() which we mocked to 12345
                                                                                                                                assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                            }

    @Test
                                                                                                                            public void testHashCodeWhenKeysIsNotNull1() {
                                                                                                                                // Setup
                                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                                ArrayList<String> keys = new ArrayList<>();
                                                                                                                                keys.add("testKey");
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                    keysField.setAccessible(true);
                                                                                                                                    keysField.set(dkv, keys);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Test - should return keys.hashCode() in both original and mutant
                                                                                                                                assertEquals("Hash code should equal keys.hashCode()", 
                                                                                                                                            keys.hashCode(), dkv.hashCode());
                                                                                                                            }

    @Test
                                                                                                                        public void testHashCodeWithDifferentKeysAndValues() {
                                                                                                                            // Setup
                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                            ArrayList<Comparable> keys = new ArrayList<>();
                                                                                                                            ArrayList<Number> values = new ArrayList<>();
                                                                                                                            
                                                                                                                            // Add elements that will produce different hash codes for keys and values
                                                                                                                            keys.add("key1");
                                                                                                                            keys.add("key2");
                                                                                                                            values.add(1);
                                                                                                                            values.add(2);
                                                                                                                            
                                                                                                                            // Use reflection to set the private fields (since they're not accessible directly)
                                                                                                                            try {
                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                keysField.setAccessible(true);
                                                                                                                                keysField.set(dkv, keys);
                                                                                                                                
                                                                                                                                java.lang.reflect.Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                                                                                                                                valuesField.setAccessible(true);
                                                                                                                                valuesField.set(dkv, values);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Calculate expected hash code (based on keys)
                                                                                                                            int expectedHashCode = keys.hashCode();
                                                                                                                            
                                                                                                                            // Test - this will fail if the mutant is present (which uses values.hashCode())
                                                                                                                            assertEquals("Hash code should be based on keys, not values", expectedHashCode, dkv.hashCode());
                                                                                                                        }

    @Test
                                                                                                                        public void testHashCodeWithNullKeys27() {
                                                                                                                            // Setup
                                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                            
                                                                                                                            // Use reflection to set keys to null
                                                                                                                            try {
                                                                                                                                java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                                keysField.setAccessible(true);
                                                                                                                                keysField.set(dkv, null);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Test - both original and mutant should return 0
                                                                                                                            assertEquals("Hash code should be 0 when keys is null", 0, dkv.hashCode());
                                                                                                                        }

    @Test
                                                                                                                        public void testHashCodeBasedOnKeysNotValues() {
                                                                                                                            // Create first object with keys [A,B] and values [1,2]
                                                                                                                            DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                            dkv1.addValue("A", 1);
                                                                                                                            dkv1.addValue("B", 2);
                                                                                                                            
                                                                                                                            // Create second object with same keys [A,B] but different values [3,4]
                                                                                                                            DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                            dkv2.addValue("A", 3);
                                                                                                                            dkv2.addValue("B", 4);
                                                                                                                            
                                                                                                                            // Create third object with different keys [X,Y] but same values as dkv1 [1,2]
                                                                                                                            DefaultKeyedValues dkv3 = new DefaultKeyedValues();
                                                                                                                            dkv3.addValue("X", 1);
                                                                                                                            dkv3.addValue("Y", 2);
                                                                                                                            
                                                                                                                            // Original behavior: hash code should be same for same keys (dkv1 and dkv2)
                                                                                                                            // and different for different keys (dkv1 and dkv3)
                                                                                                                            // Mutated version would show dkv1 and dkv3 having same hash code (incorrect)
                                                                                                                            // and dkv1 and dkv2 having different hash codes (incorrect)
                                                                                                                            
                                                                                                                            // Verify hash codes for same keys are equal (should be true for original)
                                                                                                                            assertEquals("Hash codes should be equal for same keys", dkv1.hashCode(), dkv2.hashCode());
                                                                                                                            
                                                                                                                            // Verify hash codes for different keys are different (should be true for original)
                                                                                                                            assertNotEquals("Hash codes should differ for different keys", dkv1.hashCode(), dkv3.hashCode());
                                                                                                                            
                                                                                                                            // Additional test with null keys
                                                                                                                            DefaultKeyedValues dkv4 = new DefaultKeyedValues();
                                                                                                                            assertEquals("Hash code should be 0 for null keys", 0, dkv4.hashCode());
                                                                                                                        }

    @Test
                                                                                                            public void testHashCodeWhenKeysIsNull5() throws Exception {
                                                                                                                // Setup
                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                
                                                                                                                // Use reflection to access private fields
                                                                                                                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                keysField.setAccessible(true);
                                                                                                                Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                                                                                                                valuesField.setAccessible(true);
                                                                                                                
                                                                                                                // Force keys to be null while values is not null
                                                                                                                keysField.set(dkv, null);
                                                                                                                List<Number> values = new ArrayList<>();
                                                                                                                values.add(1); // Add some value to make sure values.hashCode() != 0
                                                                                                                valuesField.set(dkv, values);
                                                                                                                
                                                                                                                // Test - original should return 0, mutant will return values.hashCode()
                                                                                                                assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                             0, dkv.hashCode());
                                                                                                                
                                                                                                                // Additional check to ensure values.hashCode() is indeed different from 0
                                                                                                                assertNotEquals("Values hash code should not be 0 for this test", 
                                                                                                                               0, values.hashCode());
                                                                                                            }

    @Test
                                                                                                            public void testHashCodeWhenKeysIsNullAndValuesIsNull() throws Exception {
                                                                                                                // Setup
                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                
                                                                                                                // Use reflection to set private fields to null
                                                                                                                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                keysField.setAccessible(true);
                                                                                                                keysField.set(dkv, null);
                                                                                                                
                                                                                                                Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                                                                                                                valuesField.setAccessible(true);
                                                                                                                valuesField.set(dkv, null);
                                                                                                                
                                                                                                                // This should return 0 (original behavior) but mutant would throw NullPointerException
                                                                                                                assertEquals(0, dkv.hashCode());
                                                                                                            }

    @Test
                                                                                                            public void testHashCodeWhenKeysIsNullButValuesExists() throws Exception {
                                                                                                                // Setup
                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                
                                                                                                                // Use reflection to set private fields
                                                                                                                Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                keysField.setAccessible(true);
                                                                                                                keysField.set(dkv, null);
                                                                                                                
                                                                                                                Field valuesField = DefaultKeyedValues.class.getDeclaredField("values");
                                                                                                                valuesField.setAccessible(true);
                                                                                                                List values = new ArrayList();
                                                                                                                values.add(1); // Add some value
                                                                                                                valuesField.set(dkv, values);
                                                                                                                
                                                                                                                // Original would return 0, mutant would return values.hashCode()
                                                                                                                // We need to verify it returns 0 regardless of values
                                                                                                                assertEquals(0, dkv.hashCode());
                                                                                                            }

    @Test
                                                                                                            public void testHashCodeWhenKeysExists() {
                                                                                                                // Setup
                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                dkv.addValue("test", 1.0); // Using public API to add a key-value pair
                                                                                                                
                                                                                                                // Get private keys field using reflection
                                                                                                                try {
                                                                                                                    Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                    keysField.setAccessible(true);
                                                                                                                    List<?> keys = (List<?>) keysField.get(dkv);
                                                                                                                    int expectedHash = keys.hashCode();
                                                                                                                    
                                                                                                                    // Should return keys.hashCode() in both original and mutant
                                                                                                                    assertEquals(expectedHash, dkv.hashCode());
                                                                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                    fail("Failed to access private keys field: " + e.getMessage());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testHashCode1() {
                                                                                                                // Create test object with some keys
                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                dkv.addValue("Key1", 10);
                                                                                                                dkv.addValue("Key2", 20);
                                                                                                                
                                                                                                                // Calculate expected hash code (based on keys list's hash)
                                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                                
                                                                                                                // Verify the hash code matches exactly (should fail for mutant)
                                                                                                                assertEquals("Hash code should exactly match keys list's hash code", 
                                                                                                                            expectedHash, dkv.hashCode());
                                                                                                                
                                                                                                                // Additional test case with empty keys
                                                                                                                DefaultKeyedValues emptyDkv = new DefaultKeyedValues();
                                                                                                                assertEquals("Empty object should have hash code 0", 
                                                                                                                            0, emptyDkv.hashCode());
                                                                                                                
                                                                                                                // Test case with null keys (though constructor initializes it, this is defensive)
                                                                                                                DefaultKeyedValues dkvWithNullKeys = new DefaultKeyedValues();
                                                                                                                try {
                                                                                                                    // Use reflection to set keys to null for testing
                                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                    keysField.setAccessible(true);
                                                                                                                    keysField.set(dkvWithNullKeys, null);
                                                                                                                    
                                                                                                                    assertEquals("Null keys should return hash code 0", 
                                                                                                                                0, dkvWithNullKeys.hashCode());
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Reflection failed to set keys to null");
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testHashCodeWithKeys2() {
                                                                                                                // Setup
                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                                dkv.addValue("Key1", 10);  // This will add to keys list
                                                                                                                
                                                                                                                // Expected is the hash code of the keys list
                                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                                
                                                                                                                // Test - this will fail if the mutant is present (+1)
                                                                                                                assertEquals("Hash code should match keys list hash code", 
                                                                                                                            expectedHash, dkv.hashCode());
                                                                                                            }

    @Test
                                                                                                            public void testHashCodeWithNullKeys28() {
                                                                                                                // Setup - new instance has empty lists, not null
                                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues() {
                                                                                                                    @Override
                                                                                                                    public List getKeys() {
                                                                                                                        return null;  // override to return null for test
                                                                                                                    }
                                                                                                                };
                                                                                                                
                                                                                                                // Test
                                                                                                                assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                            0, dkv.hashCode());
                                                                                                            }

    @Test
                                                                                                            public void testHashCodeConsistency1() {
                                                                                                                // Setup
                                                                                                                DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                                                DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                                                dkv1.addValue("A", 1);
                                                                                                                dkv2.addValue("A", 1);
                                                                                                                
                                                                                                                // Test that equal objects have same hash code
                                                                                                                assertEquals("Equal objects should have equal hash codes",
                                                                                                                            dkv1.hashCode(), dkv2.hashCode());
                                                                                                            }

    @Test
                                                                                                        public void testHashCode2() {
                                                                                                            // Setup
                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                            dkv.addValue("Key1", 10);  // Using addValue to populate keys
                                                                                                            dkv.addValue("Key2", 20);
                                                                                                            
                                                                                                            // Calculate expected hash code (original behavior)
                                                                                                            int expectedHash = dkv.getKeys().hashCode();
                                                                                                            
                                                                                                            // Test - this will fail for the mutant (returns expectedHash-1)
                                                                                                            assertEquals("Hash code should match keys list hash code", 
                                                                                                                        expectedHash, dkv.hashCode());
                                                                                                            
                                                                                                            // Additional test with empty keys
                                                                                                            DefaultKeyedValues emptyDkv = new DefaultKeyedValues();
                                                                                                            assertEquals("Empty keys should return hash code 0", 
                                                                                                                        0, emptyDkv.hashCode());
                                                                                                        }

    @Test
                                                                                                        public void testHashCodeWithNonNullKeys13() {
                                                                                                            // Setup
                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                            dkv.addValue("Key1", 10);
                                                                                                            dkv.addValue("Key2", 20);
                                                                                                            
                                                                                                            // Calculate expected hash code (based on keys list's hash code)
                                                                                                            int expectedHashCode = dkv.getKeys().hashCode();
                                                                                                            
                                                                                                            // Verify
                                                                                                            assertEquals("Hash code should match keys list's hash code", 
                                                                                                                        expectedHashCode, 
                                                                                                                        dkv.hashCode());
                                                                                                        }

    @Test
                                                                                                        public void testHashCodeWithNullKeys29() {
                                                                                                            // Setup - create object with null keys (though constructor initializes it)
                                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                            // Force keys to null for testing (using reflection since it's private)
                                                                                                            try {
                                                                                                                java.lang.reflect.Field field = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                                field.setAccessible(true);
                                                                                                                field.set(dkv, null);
                                                                                                                
                                                                                                                // Verify
                                                                                                                assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                            0, 
                                                                                                                            dkv.hashCode());
                                                                                                            } catch (Exception e) {
                                                                                                                fail("Failed to set keys to null for testing");
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                    public void testHashCode3() {
                                                                                                        // Setup test data
                                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                        dkv.addValue("Key1", 10);
                                                                                                        dkv.addValue("Key2", 20);
                                                                                                        
                                                                                                        // Calculate expected hash code (based on keys' hash code)
                                                                                                        int expectedHashCode = dkv.getKeys().hashCode();
                                                                                                        
                                                                                                        // Verify hashCode() returns the correct value
                                                                                                        assertEquals("Hash code should match keys' hash code", 
                                                                                                                    expectedHashCode, dkv.hashCode());
                                                                                                        
                                                                                                        // Test with empty keys (should return 0)
                                                                                                        DefaultKeyedValues emptyDkv = new DefaultKeyedValues();
                                                                                                        assertEquals("Empty keys should return hash code 0", 
                                                                                                                    0, emptyDkv.hashCode());
                                                                                                    }

    @Test
                                                                                                    public void testHashCodeWithNonEmptyKeys1() {
                                                                                                        // Setup
                                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                        dkv.addValue("Key1", 10);  // This will add to keys list
                                                                                                        
                                                                                                        // Get the expected hash code from the keys list directly
                                                                                                        int expectedHash = dkv.getKeys().hashCode();
                                                                                                        
                                                                                                        // Test - this will fail if the mutant is present (would get expectedHash * 2)
                                                                                                        assertEquals("Hash code should match keys list hash code", 
                                                                                                                    expectedHash, dkv.hashCode());
                                                                                                    }

    @Test
                                                                                                    public void testHashCodeWithEmptyKeys3() {
                                                                                                        // Setup - new instance has empty keys
                                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                        
                                                                                                        // Test - should return 0 for empty keys
                                                                                                        assertEquals("Hash code should be 0 for empty keys", 
                                                                                                                    0, dkv.hashCode());
                                                                                                    }

    @Test
                                                                                                public void testHashCodeWithNonEmptyKeys2() {
                                                                                                    // Setup
                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                    dkv.addValue("Key1", 10);
                                                                                                    dkv.addValue("Key2", 20);
                                                                                                    
                                                                                                    // Calculate expected hash code based on original implementation
                                                                                                    int expectedHashCode = dkv.getKeys().hashCode();
                                                                                                    
                                                                                                    // Test
                                                                                                    int actualHashCode = dkv.hashCode();
                                                                                                    
                                                                                                    // Assert - this will catch the mutant since mutant returns hashCode/2
                                                                                                    assertEquals("Hash code should match keys list's hash code", 
                                                                                                                 expectedHashCode, actualHashCode);
                                                                                                }

    @Test
                                                                                                public void testHashCodeWithEmptyKeys4() {
                                                                                                    // Setup
                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                    
                                                                                                    // Test
                                                                                                    int hashCode = dkv.hashCode();
                                                                                                    
                                                                                                    // Assert - empty keys should return 0
                                                                                                    assertEquals("Hash code should be 0 for empty keys", 0, hashCode);
                                                                                                }

    @Test
                                                                                                public void testHashCodeWithNullKeys30() {
                                                                                                    // Setup - create a subclass where we can set keys to null
                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues() {
                                                                                                        @Override
                                                                                                        public List getKeys() {
                                                                                                            return null;
                                                                                                        }
                                                                                                    };
                                                                                                    
                                                                                                    // Test
                                                                                                    int hashCode = dkv.hashCode();
                                                                                                    
                                                                                                    // Assert - null keys should return 0
                                                                                                    assertEquals("Hash code should be 0 for null keys", 0, hashCode);
                                                                                                }

    @Test
                                                                                                public void testHashCodeWithNonEmptyKeys3() {
                                                                                                    // Setup
                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                    dkv.addValue("Key1", 10);
                                                                                                    dkv.addValue("Key2", 20);
                                                                                                    
                                                                                                    // Calculate expected hash code directly from the keys list
                                                                                                    int expectedHashCode = dkv.getKeys().hashCode();
                                                                                                    
                                                                                                    // Verify the hash code matches exactly (not half)
                                                                                                    assertEquals("Hash code should equal keys list's hash code", 
                                                                                                                expectedHashCode, 
                                                                                                                dkv.hashCode());
                                                                                                }

    @Test
                                                                                                public void testHashCodeWithEmptyKeys5() {
                                                                                                    // Setup empty instance
                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                    
                                                                                                    // Verify hash code is 0 when keys is empty (but not null)
                                                                                                    assertEquals("Hash code should be 0 for empty keys", 
                                                                                                                0, 
                                                                                                                dkv.hashCode());
                                                                                                }

    @Test
                                                                                                public void testHashCodeWithNullKeys31() {
                                                                                                    // This case might not be possible in normal usage since constructor initializes keys,
                                                                                                    // but we include it for completeness
                                                                                                    
                                                                                                    // Setup instance with null keys (using reflection since keys is private)
                                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                    try {
                                                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                        keysField.setAccessible(true);
                                                                                                        keysField.set(dkv, null);
                                                                                                        
                                                                                                        // Verify hash code is 0 when keys is null
                                                                                                        assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                    0, 
                                                                                                                    dkv.hashCode());
                                                                                                    } catch (Exception e) {
                                                                                                        fail("Failed to set keys to null via reflection");
                                                                                                    }
                                                                                                }

    @Test
                                                                                            public void testHashCode4() {
                                                                                                // Setup
                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                dkv.addValue("Key1", 10);
                                                                                                dkv.addValue("Key2", 20);
                                                                                                
                                                                                                // Calculate expected hash code (original behavior)
                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                
                                                                                                // Test - mutated version should return ~expectedHash
                                                                                                // So we verify the actual hash is equal to expectedHash
                                                                                                // This will fail if the mutant is present
                                                                                                assertEquals("Hash code should match keys list hash code", 
                                                                                                            expectedHash, dkv.hashCode());
                                                                                                
                                                                                                // Additional test with empty keys
                                                                                                DefaultKeyedValues empty = new DefaultKeyedValues();
                                                                                                assertEquals("Empty instance should return 0", 0, empty.hashCode());
                                                                                            }

    @Test
                                                                                            public void testHashCodeReturnsCorrectValue1() {
                                                                                                // Setup
                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                dkv.addValue("Key1", 10.0);
                                                                                                dkv.addValue("Key2", 20.0);
                                                                                                
                                                                                                // Get the actual hash code of the keys list
                                                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                                                
                                                                                                // Verify the hashCode() method doesn't return the bitwise NOT of keys' hash
                                                                                                assertNotEquals("Hash code should not be bitwise NOT of keys' hash code", 
                                                                                                                ~expectedHash, dkv.hashCode());
                                                                                                
                                                                                                // Also verify it returns the correct hash code (original behavior)
                                                                                                assertEquals("Hash code should match keys' hash code", 
                                                                                                            expectedHash, dkv.hashCode());
                                                                                            }

    @Test
                                                                                            public void testHashCodeWithNullKeys32() {
                                                                                                // Setup object with null keys (though constructor initializes it)
                                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                                // Force keys to null for testing - this would be bad practice in real code
                                                                                                // but needed to test this branch
                                                                                                try {
                                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                                    keysField.setAccessible(true);
                                                                                                    keysField.set(dkv, null);
                                                                                                    
                                                                                                    // Test
                                                                                                    assertEquals("Hash code should be 0 when keys is null", 
                                                                                                                0, dkv.hashCode());
                                                                                                } catch (Exception e) {
                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                }
                                                                                            }

    @Test
                                                                                        public void testHashCodeConsistency2() {
                                                                                            // Create two equal DefaultKeyedValues objects
                                                                                            DefaultKeyedValues dkv1 = new DefaultKeyedValues();
                                                                                            DefaultKeyedValues dkv2 = new DefaultKeyedValues();
                                                                                            
                                                                                            // Add same keys and values to both
                                                                                            dkv1.addValue("Key1", 10);
                                                                                            dkv1.addValue("Key2", 20);
                                                                                            dkv2.addValue("Key1", 10);
                                                                                            dkv2.addValue("Key2", 20);
                                                                                            
                                                                                            // Verify hash codes are equal for equal objects
                                                                                            assertEquals("Equal objects should have equal hash codes", 
                                                                                                        dkv1.hashCode(), dkv2.hashCode());
                                                                                        }

    @Test
                                                                                        public void testHashCodeWithEmptyKeys6() {
                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                            assertEquals("Empty keys should return 0", 0, dkv.hashCode());
                                                                                        }

    @Test
                                                                                        public void testHashCodeWithNonEmptyKeys4() {
                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                            dkv.addValue("Key1", 10);
                                                                                            
                                                                                            // Calculate expected hash code
                                                                                            int expectedHash = dkv.getKeys().hashCode();
                                                                                            assertEquals("Hash code should match keys list hash code", 
                                                                                                        expectedHash, dkv.hashCode());
                                                                                        }

    @Test
                                                                                        public void testHashCode5() {
                                                                                            // Setup test data
                                                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                            dkv.addValue("Key1", 10.0);
                                                                                            dkv.addValue("Key2", 20.0);
                                                                                            
                                                                                            // Calculate expected hash code (original behavior)
                                                                                            int expectedHash = dkv.getKeys().hashCode();
                                                                                            
                                                                                            // Verify hash code matches expected value
                                                                                            assertEquals("Hash code should match keys list hash code", 
                                                                                                        expectedHash, dkv.hashCode());
                                                                                            
                                                                                            // Test with empty keys (should return 0)
                                                                                            DefaultKeyedValues emptyDkv = new DefaultKeyedValues();
                                                                                            assertEquals("Empty keys should return hash code 0", 
                                                                                                        0, emptyDkv.hashCode());
                                                                                        }

    @Test
                                                                                    public void testHashCodeWithHighBitKeys() {
                                                                                        // Create a DefaultKeyedValues object
                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                        
                                                                                        // Add keys that will generate a hash code with bits set beyond first 16 bits
                                                                                        // Using strings that will produce hash codes > 0xFFFF
                                                                                        dkv.addValue("ThisIsALongStringThatWillGenerateHighHashCode1", 1.0);
                                                                                        dkv.addValue("ThisIsALongStringThatWillGenerateHighHashCode2", 2.0);
                                                                                        dkv.addValue("ThisIsALongStringThatWillGenerateHighHashCode3", 3.0);
                                                                                        
                                                                                        // Get the actual hash code of the keys list
                                                                                        int keysHashCode = dkv.getKeys().hashCode();
                                                                                        
                                                                                        // Verify it's larger than 0xFFFF (has bits set beyond first 16 bits)
                                                                                        assertTrue(keysHashCode > 0xFFFF);
                                                                                        
                                                                                        // Test the hashCode() method
                                                                                        int actualHashCode = dkv.hashCode();
                                                                                        
                                                                                        // The original should return the exact hash code
                                                                                        assertEquals(keysHashCode, actualHashCode);
                                                                                        
                                                                                        // The mutated version would return keysHashCode | 0xFFFF which would be different
                                                                                        // from keysHashCode when keysHashCode > 0xFFFF
                                                                                    }

    @Test
                                                                                    public void testHashCode6() {
                                                                                        // Setup
                                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                        dkv.addValue("Key1", 10);  // This will add to keys ArrayList
                                                                                        
                                                                                        // Calculate expected hash code (original behavior)
                                                                                        int expectedHash = dkv.getKeys().hashCode();
                                                                                        
                                                                                        // Test - this will fail if the mutant is present
                                                                                        assertEquals("Hash code should match keys ArrayList's hash code", 
                                                                                                    expectedHash, dkv.hashCode());
                                                                                        
                                                                                        // Additional test with empty keys
                                                                                        DefaultKeyedValues emptyDkv = new DefaultKeyedValues();
                                                                                        assertEquals("Hash code should be 0 for empty keys", 
                                                                                                    0, emptyDkv.hashCode());
                                                                                    }

    @Test
                                                                                public void testHashCodeDetectsMutant1() {
                                                                                    // Setup
                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                    dkv.addValue("Key1", 10.0);
                                                                                    dkv.addValue("Key2", 20.0);
                                                                                    dkv.addValue("Key3", 30.0);
                                                                                    
                                                                                    // Calculate expected hash code (original behavior)
                                                                                    int expectedHash = dkv.getKeys().hashCode();
                                                                                    
                                                                                    // Get actual hash code
                                                                                    int actualHash = dkv.hashCode();
                                                                                    
                                                                                    // For the mutant, actualHash would be expectedHash & 0xFFFF
                                                                                    // So we need to verify the hash isn't masked
                                                                                    assertNotEquals("Hash code should not be masked with 0xFFFF", 
                                                                                                   expectedHash & 0xFFFF, actualHash);
                                                                                    
                                                                                    // Also verify it matches the full hash code
                                                                                    assertEquals("Hash code should match keys' hash code", 
                                                                                                expectedHash, actualHash);
                                                                                }

    @Test
                                                                                public void testHashCodeReturnsFullHashValue() {
                                                                                    // Create a DefaultKeyedValues instance
                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                    
                                                                                    // Add keys that will generate a hash code larger than 16 bits
                                                                                    // Using strings that are known to produce larger hash codes
                                                                                    dkv.addValue("ThisIsALongKeyThatWillProduceLargeHashCode1", 1.0);
                                                                                    dkv.addValue("ThisIsALongKeyThatWillProduceLargeHashCode2", 2.0);
                                                                                    dkv.addValue("ThisIsALongKeyThatWillProduceLargeHashCode3", 3.0);
                                                                                    
                                                                                    // Get the expected hash code from the keys list directly
                                                                                    int expectedHash = dkv.getKeys().hashCode();
                                                                                    
                                                                                    // Verify the hash code matches the full value (not masked)
                                                                                    assertEquals("Hash code should not be masked with 0xFFFF", 
                                                                                                expectedHash, dkv.hashCode());
                                                                                    
                                                                                    // Additional assertion to verify the hash is indeed larger than 16 bits
                                                                                    assertTrue("Hash code should be larger than 16 bits", 
                                                                                              Math.abs(expectedHash) > 0xFFFF);
                                                                                }

    @Test
                                                                                public void testHashCodeWithNullKeys33() {
                                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                    assertEquals("Hash code should be 0 when keys are null", 
                                                                                                 0, dkv.hashCode());
                                                                                }

    @Test
                                                                            public void testHashCodeCanReturnNegative() {
                                                                                // Setup - create keys that will produce negative hash code
                                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                                ArrayList<Comparable> keys = new ArrayList<>();
                                                                                // Using strings that are known to produce negative hash codes
                                                                                keys.add("SPECIAL_STRING_1");
                                                                                keys.add("SPECIAL_STRING_2");
                                                                                
                                                                                try {
                                                                                    // Use reflection to set the private keys field for testing
                                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                                    keysField.setAccessible(true);
                                                                                    keysField.set(dkv, keys);
                                                                                    
                                                                                    // Test the hashCode()
                                                                                    int hash = dkv.hashCode();
                                                                                    
                                                                                    // Verify the hash can be negative (original behavior)
                                                                                    // If mutated, Math.abs would make it always positive
                                                                                    assertTrue("Hash code should be able to be negative", hash < 0 || hash >= 0);
                                                                                    // More specifically, we expect it could be negative with these keys
                                                                                    // This assertion would fail if Math.abs was applied
                                                                                    assertTrue("With these keys, hash code should be negative", hash < 0);
                                                                                    
                                                                                } catch (Exception e) {
                                                                                    fail("Exception during test: " + e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                    public void testHashCodeSignPreservation() throws Exception {
                                                                        // Create a DefaultKeyedValues instance
                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                        
                                                                        // Get the private 'keys' field using reflection
                                                                        Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                        keysField.setAccessible(true);
                                                                        
                                                                        // Create a custom ArrayList that returns a known negative hash code
                                                                        ArrayList<Comparable> keysWithNegativeHash = new ArrayList<Comparable>() {
                                                                            @Override
                                                                            public int hashCode() {
                                                                                // Return a known negative value
                                                                                return -123456;
                                                                            }
                                                                        };
                                                                        
                                                                        // Replace the keys list with our custom list
                                                                        keysField.set(dkv, keysWithNegativeHash);
                                                                        
                                                                        // Test that the hash code preserves the sign
                                                                        int hashCode = dkv.hashCode();
                                                                        assertTrue("Hash code should be negative for negative keys.hashCode()", 
                                                                                  hashCode < 0);
                                                                        
                                                                        // Also test with empty keys (should return 0)
                                                                        keysField.set(dkv, new ArrayList<>());
                                                                        assertEquals("Hash code should be 0 for empty keys", 
                                                                                   0, dkv.hashCode());
                                                                        
                                                                        // Test with null keys (should return 0)
                                                                        keysField.set(dkv, null);
                                                                        assertEquals("Hash code should be 0 for null keys", 
                                                                                   0, dkv.hashCode());
                                                                    }

    @Test
                                                                    public void testHashCodeReturnsPositiveValueWhenKeysExist() {
                                                                        // Setup
                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                        dkv.addValue("Key1", 10.0);
                                                                        dkv.addValue("Key2", 20.0);
                                                                        
                                                                        // Exercise
                                                                        int hashCode = dkv.hashCode();
                                                                        
                                                                        // Verify
                                                                        assertTrue("Hash code should be positive when keys exist", hashCode > 0);
                                                                        
                                                                        // Additional check to ensure it's not just any positive number
                                                                        // but actually the correct hash code
                                                                        int expectedHash = dkv.getKeys().hashCode();
                                                                        assertEquals("Hash code should match keys list hash code", expectedHash, hashCode);
                                                                    }

    @Test
                                                                    public void testHashCodeReturnsZeroWhenKeysAreNull() {
                                                                        // Setup - need to use reflection to set keys to null for this test
                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                        try {
                                                                            java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                            keysField.setAccessible(true);
                                                                            keysField.set(dkv, null);
                                                                            
                                                                            // Exercise
                                                                            int hashCode = dkv.hashCode();
                                                                            
                                                                            // Verify
                                                                            assertEquals("Hash code should be 0 when keys are null", 0, hashCode);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set keys to null via reflection");
                                                                        }
                                                                    }

    @Test
                                                                    public void testHashCodeWithKeysShouldReturnPositiveValue() {
                                                                        // Setup
                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                        // Add some keys to ensure keys list is not null
                                                                        dkv.addValue("Key1", 10);
                                                                        dkv.addValue("Key2", 20);
                                                                        
                                                                        // Exercise
                                                                        int hashCode = dkv.hashCode();
                                                                        
                                                                        // Verify
                                                                        // Original behavior: hash code should be positive when keys exist
                                                                        // Mutated behavior: hash code would be negative
                                                                        assertTrue("Hash code should be positive when keys exist", hashCode > 0);
                                                                        
                                                                        // Additional verification that it's actually using keys' hash code
                                                                        int expectedHash = new ArrayList(dkv.getKeys()).hashCode();
                                                                        assertEquals("Hash code should match keys' hash code", expectedHash, hashCode);
                                                                    }

    @Test
                                                                    public void testHashCodeWithNullKeysShouldReturnZero() {
                                                                        // Setup - create object with null keys (though constructor initializes it)
                                                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                        // Force keys to be null through reflection for testing
                                                                        try {
                                                                            java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                            keysField.setAccessible(true);
                                                                            keysField.set(dkv, null);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set keys to null via reflection");
                                                                        }
                                                                        
                                                                        // Exercise
                                                                        int hashCode = dkv.hashCode();
                                                                        
                                                                        // Verify
                                                                        assertEquals("Hash code should be 0 when keys is null", 0, hashCode);
                                                                    }

    @Test
                                                                public void testHashCodeWithNonEmptyKeys5() {
                                                                    // Setup
                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                    ArrayList<Comparable> testKeys = new ArrayList<>();
                                                                    testKeys.add("Key1");
                                                                    testKeys.add("Key2");
                                                                    
                                                                    // Use reflection to set the private keys field since there's no public setter
                                                                    try {
                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                        keysField.setAccessible(true);
                                                                        keysField.set(dkv, testKeys);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set keys field via reflection");
                                                                    }
                                                                    
                                                                    // Calculate expected value (original behavior)
                                                                    int expectedHash = testKeys.hashCode();
                                                                    
                                                                    // Test - this will fail if the mutant is present (would get expectedHash << 1)
                                                                    assertEquals("Hash code should match keys list hash code", 
                                                                                expectedHash, dkv.hashCode());
                                                                }

    @Test
                                                                public void testHashCodeWithNullKeys34() {
                                                                    // Setup
                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                    
                                                                    // Use reflection to set keys to null
                                                                    try {
                                                                        java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                        keysField.setAccessible(true);
                                                                        keysField.set(dkv, null);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set keys field via reflection");
                                                                    }
                                                                    
                                                                    // Test - mutant doesn't affect null case, but good to verify
                                                                    assertEquals("Hash code should be 0 when keys is null", 
                                                                                0, dkv.hashCode());
                                                                }

    @Test
                                                                public void testHashCode7() {
                                                                    // Setup
                                                                    DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                    dkv.addValue("Key1", 10);  // This will add to keys list
                                                                    
                                                                    // Calculate expected hash code (original behavior)
                                                                    int expectedHash = dkv.getKeys().hashCode();
                                                                    
                                                                    // Test
                                                                    int actualHash = dkv.hashCode();
                                                                    
                                                                    // Assert - mutated version would return expectedHash << 1
                                                                    assertEquals("Hash code should match keys list hash code", 
                                                                                expectedHash, actualHash);
                                                                    
                                                                    // Additional test with null keys
                                                                    DefaultKeyedValues emptyDkv = new DefaultKeyedValues();
                                                                    assertEquals("Hash code should be 0 for empty keys", 
                                                                                0, emptyDkv.hashCode());
                                                                }

    @Test
                                                            public void testHashCodeWithNonEmptyKeys6() {
                                                                // Setup
                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                dkv.addValue("Key1", 10.0);
                                                                dkv.addValue("Key2", 20.0);
                                                                
                                                                // Calculate expected hash code (original behavior)
                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                
                                                                // Verify the hash code matches exactly
                                                                assertEquals("Hash code should match keys list hash code exactly", 
                                                                            expectedHash, dkv.hashCode());
                                                                
                                                                // Additional check to ensure we're testing the right thing
                                                                assertNotEquals("Hash code should not be half of expected value",
                                                                               expectedHash >> 1, dkv.hashCode());
                                                            }

    @Test
                                                            public void testHashCodeWithEmptyKeys7() {
                                                                // Setup empty object
                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                
                                                                // Should return 0 for empty keys (same in both original and mutated)
                                                                assertEquals("Hash code should be 0 for empty keys", 
                                                                            0, dkv.hashCode());
                                                            }

    @Test
                                                            public void testHashCodeReturnsExactKeysHashCode() {
                                                                // Setup
                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                dkv.addValue("Key1", 10.0);
                                                                dkv.addValue("Key2", 20.0);
                                                                
                                                                // Calculate expected value - should be exactly keys.hashCode()
                                                                int expectedHash = dkv.getKeys().hashCode();
                                                                
                                                                // Verify
                                                                assertEquals("Hash code should be exactly equal to keys.hashCode()", 
                                                                            expectedHash, dkv.hashCode());
                                                                
                                                                // Additional check to ensure it's not the mutated version
                                                                assertNotEquals("Hash code should not be half of keys.hashCode()", 
                                                                               expectedHash >> 1, dkv.hashCode());
                                                            }

    @Test
                                                            public void testHashCodeWithNullKeys35() {
                                                                // Setup - new object has empty keys list (not null)
                                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                                
                                                                // For empty keys, both original and mutant return 0
                                                                assertEquals(0, dkv.hashCode());
                                                                
                                                                // To test null keys case, we need to force keys to be null via reflection
                                                                try {
                                                                    java.lang.reflect.Field keysField = DefaultKeyedValues.class.getDeclaredField("keys");
                                                                    keysField.setAccessible(true);
                                                                    keysField.set(dkv, null);
                                                                    
                                                                    // Both original and mutant return 0 when keys is null
                                                                    assertEquals(0, dkv.hashCode());
                                                                } catch (Exception e) {
                                                                    fail("Failed to test null keys case due to reflection error");
                                                                }
                                                            }

    @Test
                                                        public void testHashCodeWithNonEmptyKeys7() {
                                                            // Setup
                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                            dkv.addValue("Key1", 10.0);
                                                            dkv.addValue("Key2", 20.0);
                                                            
                                                            // Calculate expected hash code based on original implementation
                                                            int expectedHash = dkv.getKeys().hashCode();
                                                            
                                                            // Verify the hash code matches exactly (mutant would return expectedHash >>> 1)
                                                            assertEquals("Hash code should match exact keys hash value", 
                                                                        expectedHash, dkv.hashCode());
                                                        }

    @Test
                                                        public void testHashCodeWithEmptyKeys8() {
                                                            // Setup empty collection
                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                            
                                                            // Verify hash code is 0 for empty keys (mutant would also return 0)
                                                            assertEquals("Hash code should be 0 for empty keys", 
                                                                        0, dkv.hashCode());
                                                        }

    @Test
                                                        public void testHashCodeWithNullKeys36() {
                                                            // This test would require reflection to set keys to null,
                                                            // but since the constructor initializes keys, we can skip this case
                                                            // as it's not reachable through normal usage
                                                        }

    @Test
                                                        public void testHashCode8() {
                                                            // Setup test data
                                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                            dkv.addValue("Key1", 10);
                                                            dkv.addValue("Key2", 20);
                                                            
                                                            // Calculate expected hash code
                                                            int expectedHash = dkv.getKeys().hashCode(); // Original behavior
                                                            
                                                            // Test the actual hash code
                                                            assertEquals("Hash code should match keys list hash code", 
                                                                        expectedHash, dkv.hashCode());
                                                            
                                                            // Additional check to detect the mutant
                                                            // The mutated version would return expectedHash >>> 1
                                                            assertNotEquals("Hash code should not be shifted right", 
                                                                           expectedHash >>> 1, dkv.hashCode());
                                                        }

    @Test
                                            public void testRemoveValueIndexVsKeyIndexDifference() {
                                                // Setup test data where index and getIndex(key) would differ
                                                DefaultKeyedValues dkv = new DefaultKeyedValues();
                                                dkv.addValue("Key1", 10);
                                                dkv.addValue("Key2", 20);
                                                dkv.addValue("Key3", 30);
                                                
                                                // Key2 is at index 1, but we'll try to remove index 2 with Key2
                                                // This would work differently in original vs mutated code
                                                int indexToRemove = 2; // Key3's index
                                                Comparable<String> keyToRemove = "Key2"; // Which is at index 1
                                                
                                                // In original code: would remove index 2 (Key3)
                                                // In mutated code: would remove getIndex("Key2") which is 1 (Key2)
                                                
                                                // Call the method - in original should remove Key3, in mutant should remove Key2
                                                dkv.removeValue(indexToRemove);
                                                
                                                // Verify correct behavior:
                                                // Original should have removed Key3 (index 2), leaving Key1 and Key2
                                                assertEquals(2, dkv.getItemCount());
                                                assertEquals("Key1", dkv.getKey(0));
                                                assertEquals("Key2", dkv.getKey(1));  // Fixed typo here (was dvk)
                                                assertEquals(10, dkv.getValue(0));
                                                assertEquals(20, dkv.getValue(1));
                                                
                                                // Mutant would fail these assertions as it would have removed Key2 instead
                                            }

    @Test
                                            public void testRemoveValueShouldCallGetIndexOnlyOnce() {
                                                // Setup
                                                DefaultKeyedValues keyedValues = mock(DefaultKeyedValues.class);
                                                Comparable<String> testKey = "TestKey";
                                                
                                                // Stub getIndex to return 0 when called with testKey
                                                when(keyedValues.getIndex(testKey)).thenReturn(0);
                                                
                                                // Act
                                                keyedValues.removeValue(testKey);
                                                
                                                // Verify getIndex was called exactly once
                                                verify(keyedValues, times(1)).getIndex(testKey);
                                                
                                                // Also verify removeValue was called with the correct index
                                                verify(keyedValues).removeValue(0);
                                            }

    @Test(expected = UnknownKeyException.class)
                                            public void testRemoveValueWithUnknownKeyShouldThrowException1() {
                                                // Arrange
                                                DefaultKeyedValues keyedValues = new DefaultKeyedValues();
                                                Comparable testKey = "unknownKey";
                                                
                                                // Stub getIndex to return -1 (unknown key)
                                                when(keyedValues.getIndex(testKey)).thenReturn(-1);
                                                
                                                // Act - should throw exception
                                                keyedValues.removeValue(testKey);
                                            }

    @Test
                                        public void testRemoveValueRebuildsIndex() {
                                            // Setup
                                            DefaultKeyedValues dkv = new DefaultKeyedValues();
                                            Comparable key1 = "Key1";
                                            Comparable key2 = "Key2";
                                            Number value1 = 10;
                                            Number value2 = 20;
                                            
                                            // Add values
                                            dkv.addValue(key1, value1);
                                            dkv.addValue(key2, value2);
                                            
                                            // Verify initial index mapping
                                            assertEquals(0, dkv.getIndex(key1));
                                            assertEquals(1, dkv.getIndex(key2));
                                            
                                            // Remove first item
                                            dkv.removeValue(0);
                                            
                                            // Verify index map was rebuilt
                                            // If rebuildIndex() was called, key2 should now be at index 0
                                            // If not, it would still be at index 1 or the mapping might be wrong
                                            assertEquals(0, dkv.getIndex(key2));
                                            assertEquals(-1, dkv.getIndex(key1)); // key1 should no longer exist
                                            
                                            // Also verify the key is actually removed from keys list
                                            assertEquals(1, dkv.getItemCount());
                                            assertEquals(key2, dkv.getKey(0));
                                        }

    @Test
                                    public void testRemoveValueWithExistingKey() {
                                        // Create test data
                                        DefaultKeyedValues defaultKeyedValues = new DefaultKeyedValues();
                                        Comparable<String> testKey = "TestKey";
                                        
                                        // Setup - mock getIndex to return a valid index
                                        DefaultKeyedValues spy = spy(defaultKeyedValues);
                                        when(spy.getIndex(testKey)).thenReturn(0);
                                        
                                        // Add a value first
                                        spy.addValue(testKey, 10.0);
                                        
                                        // Test removal
                                        spy.removeValue(testKey);
                                        
                                        // Verify the value was removed by checking size
                                        assertEquals(0, spy.getItemCount());
                                    }

    @Test(expected = UnknownKeyException.class)
                                    public void testRemoveValueWithUnknownKeyThrowsException() {
                                        // Setup
                                        DefaultKeyedValues defaultKeyedValues = new DefaultKeyedValues();
                                        Comparable<String> testKey = "unknown_key";
                                        
                                        // Create spy and mock behavior
                                        DefaultKeyedValues spy = spy(defaultKeyedValues);
                                        when(spy.getIndex(testKey)).thenReturn(-1);
                                        
                                        // This should throw UnknownKeyException
                                        spy.removeValue(testKey);
                                    }

    @Test
                                    public void testRemoveValueRebuildsIndex1() {
                                        // Setup
                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                        String testKey = "key1";
                                        Number testValue = 10;
                                        
                                        // Add test data
                                        dkv.addValue(testKey, testValue);
                                        
                                        // Verify initial state
                                        assertEquals(1, dkv.getItemCount());
                                        assertEquals(0, dkv.getIndex(testKey));
                                        assertEquals(testValue, dkv.getValue(0));
                                        assertEquals(testValue, dkv.getValue(testKey));
                                        
                                        // Remove the value
                                        dkv.removeValue(0);
                                        
                                        // Verify post-removal state
                                        assertEquals(0, dkv.getItemCount());
                                        
                                        // This assertion will catch the mutant - original code would return -1,
                                        // mutant without rebuildIndex() might still return 0
                                        assertEquals(-1, dkv.getIndex(testKey));
                                        
                                        // Additional verification that value is no longer accessible by key
                                        try {
                                            dkv.getValue(testKey);
                                            fail("Expected exception when getting value for removed key");
                                        } catch (UnknownKeyException e) {
                                            // Expected behavior
                                        }
                                    }

    @Test
                                    public void testRemoveValueWithValidKeyActuallyRemovesEntry() throws UnknownKeyException {
                                        // Setup test data
                                        DefaultKeyedValues dkv = new DefaultKeyedValues();
                                        Comparable<String> testKey = "TestKey";
                                        Number testValue = 42;
                                        
                                        // Mock the internal state
                                        dkv.addValue(testKey, testValue); // Using available method to populate
                                        
                                        // Verify initial state
                                        assertEquals(1, dkv.getItemCount());
                                        assertEquals(testValue, dkv.getValue(testKey));
                                        
                                        // Execute test
                                        dkv.removeValue(testKey);
                                        
                                        // Verify post-conditions
                                        assertEquals(0, dkv.getItemCount());
                                        try {
                                            dkv.getValue(testKey);
                                            fail("Expected UnknownKeyException");
                                        } catch (UnknownKeyException e) {
                                            // Expected behavior
                                        }
                                    }

    @Test
                        public void testRemoveValueRebuildIndexCalledOnce() throws Exception {
                            // Setup
                            DefaultKeyedValues instance = new DefaultKeyedValues();
                            DefaultKeyedValues spyInstance = spy(instance);
                            
                            // Add some test data
                            Comparable<String> testKey = "testKey";
                            Number testValue = 10;
                            spyInstance.addValue(testKey, testValue);
                            
                            // Verify initial state
                            assertEquals(1, spyInstance.getItemCount());
                            
                            // Get the rebuildIndex method via reflection
                            Method rebuildIndexMethod = DefaultKeyedValues.class.getDeclaredMethod("rebuildIndex");
                            rebuildIndexMethod.setAccessible(true);
                            
                            // Reset the call count before our test
                            reset(spyInstance);
                            
                            // Execute
                            spyInstance.removeValue(0);
                            
                            // Verify rebuildIndex was called exactly once using reflection
                            verify(spyInstance, times(1)).getKeys(); // rebuildIndex is called after getKeys()
                            
                            // Verify the post-conditions
                            assertEquals(0, spyInstance.getItemCount());
                        }

    @Test
                    public void testRemoveValueShouldCallRebuildIndexOnce1() throws Exception {
                        // Setup test data
                        DefaultKeyedValues values = new DefaultKeyedValues();
                        Comparable<String> testKey = "testKey";
                        Number testValue = 10;
                        
                        // Add a value to be removed later
                        values.addValue(testKey, testValue);
                        
                        // Get the rebuildIndex method via reflection
                        Method rebuildIndexMethod = DefaultKeyedValues.class.getDeclaredMethod("rebuildIndex");
                        rebuildIndexMethod.setAccessible(true);
                        
                        // Create a spy
                        DefaultKeyedValues spyValues = spy(values);
                        
                        // Mock the removeValue method to count rebuildIndex calls
                        doAnswer(invocation -> {
                            // Call real removeValue
                            spyValues.removeValue((Comparable)invocation.getArguments()[0]);
                            // Call rebuildIndex via reflection
                            rebuildIndexMethod.invoke(spyValues);
                            return null;
                        }).when(spyValues).removeValue(any(Comparable.class));
                        
                        // Perform the removal
                        spyValues.removeValue(testKey);
                        
                        // Verify removeValue was called exactly once (which includes rebuildIndex)
                        verify(spyValues, times(1)).removeValue(testKey);
                    }

    @Test(expected = UnknownKeyException.class)
            public void testRemoveValueWithUnknownKeyThrowsException1() {
                // Setup - create instance and mock getIndex to return -1 (key not found)
                DefaultKeyedValues instance = new DefaultKeyedValues();
                DefaultKeyedValues spy = spy(instance);
                when(spy.getIndex(any(Comparable.class))).thenReturn(-1);
                
                // Test - should throw UnknownKeyException
                spy.removeValue("unknown_key");
            }

    @Test
            public void testRemoveValueWithValidKeyCallsRemoveValueIndex() {
                // Setup - create instance and mock getIndex to return valid index
                DefaultKeyedValues instance = new DefaultKeyedValues();
                DefaultKeyedValues spy = spy(instance);
                when(spy.getIndex("valid_key")).thenReturn(0);
                
                // Test
                spy.removeValue("valid_key");
                
                // Verify removeValue(int) was called
                verify(spy).removeValue(0);
            }

    @Test
        public void testRemoveValueAtIndexActuallyRemovesElements() {
            // Setup test data
            DefaultKeyedValues dkv = new DefaultKeyedValues();
            dkv.addValue("Key1", 10.0);
            dkv.addValue("Key2", 20.0);
            dkv.addValue("Key3", 30.0);
            
            // Store initial state
            int initialSize = dkv.getItemCount();
            Comparable<?> keyToRemove = dkv.getKey(1);  // Get key at index 1
            Number valueToRemove = dkv.getValue(1); // Get value at index 1
            
            // Perform removal
            dkv.removeValue(1);
            
            // Verify removal occurred
            assertEquals("Size should decrease by 1", initialSize - 1, dkv.getItemCount());
            assertFalse("Key should no longer be present", dkv.getKeys().contains(keyToRemove));
            
            // Verify value is no longer present by checking index
            try {
                dkv.getValue(keyToRemove);
                fail("Value should no longer be present");
            } catch (UnknownKeyException e) {
                // Expected behavior
            }
            
            // Verify remaining elements
            assertEquals("First element should remain", "Key1", dkv.getKey(0));
            assertEquals("Second element should now be original third", "Key3", dkv.getKey(1));
        }

    @Test
        public void testRemoveValueRebuildsIndexCorrectly() {
            // Setup test data
            DefaultKeyedValues dkv = new DefaultKeyedValues();
            dkv.addValue("Key1", 10);
            dkv.addValue("Key2", 20);
            dkv.addValue("Key3", 30);
            
            // Verify initial index mapping
            assertEquals(0, dkv.getIndex("Key1"));
            assertEquals(1, dkv.getIndex("Key2"));
            assertEquals(2, dkv.getIndex("Key3"));
            
            // Remove middle item
            dkv.removeValue(1);
            
            // Verify keys and values were removed
            assertEquals(2, dkv.getItemCount());
            assertEquals("Key1", dkv.getKey(0));
            assertEquals("Key3", dkv.getKey(1));
            assertEquals(10, dkv.getValue(0));
            assertEquals(30, dkv.getValue(1));
            
            // Critical assertion - verify indexMap was rebuilt
            // This would fail if rebuildIndex() wasn't properly called
            assertEquals(0, dkv.getIndex("Key1"));
            assertEquals(1, dkv.getIndex("Key3"));
            assertTrue(dkv.getIndex("Key2") < 0); // Key2 should no longer exist in index
        }

    @Test
    public void testRemoveValueActuallyRemovesEntry() {
        // Setup
        DefaultKeyedValues dkv = new DefaultKeyedValues();
        Comparable<String> key = "TestKey";
        Number value = 10;
        
        // Add a value first
        dkv.addValue(key, value);
        int initialCount = dkv.getItemCount();
        
        // Action - remove the value
        dkv.removeValue(key);
        
        // Verification
        // 1. Check item count decreased
        assertEquals(initialCount - 1, dkv.getItemCount());
        
        // 2. Check key no longer exists
        try {
            dkv.getValue(key);
            fail("Expected UnknownKeyException but none was thrown");
        } catch (UnknownKeyException e) {
            // Expected behavior
        }
        
        // 3. Check cannot get index for removed key
        assertEquals(-1, dkv.getIndex(key));
        
        // 4. Check keys list doesn't contain the key
        assertFalse(dkv.getKeys().contains(key));
    }

}
