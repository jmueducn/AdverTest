package gentest.org.jfree.chart.renderer.category.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.category.*;
import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.RenderingSource;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.CategoryItemEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.labels.CategoryItemLabelGenerator;
import org.jfree.chart.labels.CategorySeriesLabelGenerator;
import org.jfree.chart.labels.CategoryToolTipGenerator;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategorySeriesLabelGenerator;
import org.jfree.chart.plot.CategoryCrosshairState;
import org.jfree.chart.plot.CategoryMarker;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DrawingSupplier;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.AbstractRenderer;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.urls.CategoryURLGenerator;
import org.jfree.chart.util.GradientPaintTransformer;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.LengthAdjustmentType;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleAnchor;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryDatasetSelectionState;
import org.jfree.data.category.SelectableCategoryDataset;
import org.jfree.data.general.DatasetUtilities;
 
public class AbstractCategoryItemRendererTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                public void testGetLegendItems_WhenPlotIsNull_ReturnsEmptyCollection() {
                                                                                                                                                    // Setup
                                                                                                                                                    AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                                                        @Override
                                                                                                                                                        public void drawItem(Graphics2D g2, CategoryItemRendererState state, 
                                                                                                                                                                Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis, 
                                                                                                                                                                ValueAxis rangeAxis, CategoryDataset dataset, int row, int column, 
                                                                                                                                                                boolean selected, int pass) {
                                                                                                                                                            // Minimal implementation required by abstract class
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                    renderer.setPlot(null); // Explicitly set plot to null
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    LegendItemCollection result = renderer.getLegendItems();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(result);
                                                                                                                                                    assertEquals(0, result.getItemCount());
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLegendItems_WhenDatasetIsNull_ReturnsEmptyCollection() {
                                                                                                                                                    // Setup
                                                                                                                                                    AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                                                        @Override
                                                                                                                                                        public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                                                Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                                                ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                                                boolean selected, int pass) {
                                                                                                                                                            // Minimal implementation required by abstract class
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                    renderer.setPlot(plot);
                                                                                                                                                    
                                                                                                                                                    when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                                                    when(plot.getDataset(0)).thenReturn(null);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    LegendItemCollection result = renderer.getLegendItems();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(result);
                                                                                                                                                    assertEquals(0, result.getItemCount());
                                                                                                                                                    verify(plot).getIndexOf(renderer);
                                                                                                                                                    verify(plot).getDataset(0);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLegendItems_WithAscendingOrder_AddsVisibleItemsInOrder() {
                                                                                                                                                    // Setup
                                                                                                                                                    AbstractCategoryItemRenderer renderer = spy(new AbstractCategoryItemRenderer() {
                                                                                                                                                        @Override
                                                                                                                                                        public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                                                Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                                                ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                                                boolean selected, int pass) {
                                                                                                                                                            // Minimal implementation required for test
                                                                                                                                                        }
                                                                                                                                                    });
                                                                                                                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                    CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                                    LegendItem item1 = mock(LegendItem.class);
                                                                                                                                                    LegendItem item2 = mock(LegendItem.class);
                                                                                                                                                    
                                                                                                                                                    renderer.setPlot(plot);
                                                                                                                                                    
                                                                                                                                                    when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                                                    when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                                                    when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                                                    when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                                    
                                                                                                                                                    // Only series 0 and 2 are visible
                                                                                                                                                    doReturn(true).when(renderer).isSeriesVisibleInLegend(0);
                                                                                                                                                    doReturn(false).when(renderer).isSeriesVisibleInLegend(1);
                                                                                                                                                    
                                                                                                                                                    when(renderer.getLegendItem(0, 0)).thenReturn(item1);
                                                                                                                                                    when(renderer.getLegendItem(0, 1)).thenReturn(null);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    LegendItemCollection result = renderer.getLegendItems();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(result);
                                                                                                                                                    assertEquals(1, result.getItemCount());
                                                                                                                                                    assertEquals(item1, result.get(0));
                                                                                                                                                    
                                                                                                                                                    verify(renderer).getLegendItem(0, 0);
                                                                                                                                                    verify(renderer, never()).getLegendItem(0, 1);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLegendItems_WhenNoSeriesVisible_ReturnsEmptyCollection() {
                                                                                                                                                    // Setup
                                                                                                                                                    AbstractCategoryItemRenderer renderer = spy(new AbstractCategoryItemRenderer() {
                                                                                                                                                        @Override
                                                                                                                                                        public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                                                Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                                                ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                                                boolean selected, int pass) {
                                                                                                                                                            // Minimal implementation required for testing
                                                                                                                                                        }
                                                                                                                                                    });
                                                                                                                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                    CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                                    
                                                                                                                                                    renderer.setPlot(plot);
                                                                                                                                                    
                                                                                                                                                    when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                                                    when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                                                    when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                                                    when(dataset.getRowCount()).thenReturn(2);
                                                                                                                                                    
                                                                                                                                                    // All series invisible
                                                                                                                                                    doReturn(false).when(renderer).isSeriesVisibleInLegend(0);
                                                                                                                                                    doReturn(false).when(renderer).isSeriesVisibleInLegend(1);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    LegendItemCollection result = renderer.getLegendItems();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(result);
                                                                                                                                                    assertEquals(0, result.getItemCount());
                                                                                                                                                    
                                                                                                                                                    verify(renderer, never()).getLegendItem(anyInt(), anyInt());
                                                                                                                                                }

    @Test
                                                                                                                                                public void testGetLegendItems_WhenLegendItemIsNull_DoesNotAddToCollection() {
                                                                                                                                                    // Setup
                                                                                                                                                    AbstractCategoryItemRenderer renderer = spy(new AbstractCategoryItemRenderer() {
                                                                                                                                                        @Override
                                                                                                                                                        public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                                                Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                                                ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                                                boolean selected, int pass) {
                                                                                                                                                            // Minimal implementation required by abstract class
                                                                                                                                                        }
                                                                                                                                                    });
                                                                                                                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                    CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                                    
                                                                                                                                                    renderer.setPlot(plot);
                                                                                                                                                    
                                                                                                                                                    when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                                                    when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                                                    when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                                                    when(dataset.getRowCount()).thenReturn(1);
                                                                                                                                                    
                                                                                                                                                    // Series is visible but returns null legend item
                                                                                                                                                    doReturn(true).when(renderer).isSeriesVisibleInLegend(0);
                                                                                                                                                    when(renderer.getLegendItem(0, 0)).thenReturn(null);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    LegendItemCollection result = renderer.getLegendItems();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(result);
                                                                                                                                                    assertEquals(0, result.getItemCount());
                                                                                                                                                    
                                                                                                                                                    verify(renderer).getLegendItem(0, 0);
                                                                                                                                                }

    @Test
                                                                                                                                            public void testGetLegendItems_WithDescendingOrder_AddsVisibleItemsInReverseOrder() {
                                                                                                                                                // Setup
                                                                                                                                                AbstractCategoryItemRenderer renderer = spy(new AbstractCategoryItemRenderer() {
                                                                                                                                                    @Override
                                                                                                                                                    public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                                            Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                                            ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                                            boolean selected, int pass) {
                                                                                                                                                        // Minimal implementation for testing
                                                                                                                                                    }
                                                                                                                                                });
                                                                                                                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                                                LegendItem item1 = mock(LegendItem.class);
                                                                                                                                                LegendItem item2 = mock(LegendItem.class);
                                                                                                                                                
                                                                                                                                                renderer.setPlot(plot);
                                                                                                                                                
                                                                                                                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                                                when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.DESCENDING);
                                                                                                                                                when(dataset.getRowCount()).thenReturn(3);
                                                                                                                                                
                                                                                                                                                // Series 0 and 2 are visible
                                                                                                                                                doReturn(true).when(renderer).isSeriesVisibleInLegend(0);
                                                                                                                                                doReturn(false).when(renderer).isSeriesVisibleInLegend(1);
                                                                                                                                                doReturn(true).when(renderer).isSeriesVisibleInLegend(2);
                                                                                                                                                
                                                                                                                                                when(renderer.getLegendItem(0, 2)).thenReturn(item1);
                                                                                                                                                when(renderer.getLegendItem(0, 0)).thenReturn(item2);
                                                                                                                                                
                                                                                                                                                // Execute
                                                                                                                                                LegendItemCollection result = renderer.getLegendItems();
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertNotNull(result);
                                                                                                                                                assertEquals(2, result.getItemCount());
                                                                                                                                                assertEquals(item1, result.get(0)); // First added item should be from series 2
                                                                                                                                                assertEquals(item2, result.get(1)); // Then series 0
                                                                                                                                                
                                                                                                                                                verify(renderer).getLegendItem(0, 2);
                                                                                                                                                verify(renderer, never()).getLegendItem(0, 1);
                                                                                                                                                verify(renderer).getLegendItem(0, 0);
                                                                                                                                            }

    @Test
                                                                                                                                public void testGetLegendItemsUsesCorrectDatasetIndex() {
                                                                                                                                    // Setup
                                                                                                                                    AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                                        @Override
                                                                                                                                        public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                                                            return new LegendItem("Series " + series);
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public boolean isSeriesVisibleInLegend(int series) {
                                                                                                                                            return true;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                                Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                                ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                                boolean selected, int pass) {
                                                                                                                                            // Empty implementation for test purposes
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                                    renderer.setPlot(plot);
                                                                                                                                    
                                                                                                                                    // Set renderer index to 1 (non-zero)
                                                                                                                                    when(plot.getIndexOf(renderer)).thenReturn(1);
                                                                                                                                    
                                                                                                                                    // Create two different datasets
                                                                                                                                    CategoryDataset dataset0 = mock(CategoryDataset.class);
                                                                                                                                    when(dataset0.getRowCount()).thenReturn(1); // Only 1 series
                                                                                                                                    
                                                                                                                                    CategoryDataset dataset1 = mock(CategoryDataset.class);
                                                                                                                                    when(dataset1.getRowCount()).thenReturn(2); // 2 series
                                                                                                                                    
                                                                                                                                    // Return different datasets based on index
                                                                                                                                    when(plot.getDataset(0)).thenReturn(dataset0);
                                                                                                                                    when(plot.getDataset(1)).thenReturn(dataset1);
                                                                                                                                    
                                                                                                                                    when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                    LegendItemCollection result = renderer.getLegendItems();
                                                                                                                                    
                                                                                                                                    // Verify - should use dataset1 (index 1) which has 2 series
                                                                                                                                    assertEquals(2, result.getItemCount());
                                                                                                                                    
                                                                                                                                    // Verify the legend items come from the correct dataset
                                                                                                                                    // (implementation detail - we know it calls getLegendItem with dataset index 1)
                                                                                                                                    verify(plot, times(1)).getDataset(1);
                                                                                                                                }

    @Test
                                                                                                                        public void testGetLegendItemsWithNonNullDataset() {
                                                                                                                            // Setup test objects
                                                                                                                            AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                                // Implement required abstract method
                                                                                                                                @Override
                                                                                                                                public void drawItem(Graphics2D g2, CategoryItemRendererState state, 
                                                                                                                                        Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis, 
                                                                                                                                        ValueAxis rangeAxis, CategoryDataset dataset, int row, 
                                                                                                                                        int column, boolean selected, int pass) {
                                                                                                                                    // Empty implementation for test
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Override methods needed for test
                                                                                                                                @Override
                                                                                                                                public boolean isSeriesVisibleInLegend(int series) {
                                                                                                                                    return true;
                                                                                                                                }
                                                                                                                                
                                                                                                                                @Override
                                                                                                                                public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                                                    return new LegendItem("Test");
                                                                                                                                }
                                                                                                                            };
                                                                                                                            
                                                                                                                            // Mock required objects
                                                                                                                            CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                            CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                                            
                                                                                                                            // Configure mocks
                                                                                                                            when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                                            when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                                            when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                                            when(dataset.getRowCount()).thenReturn(1);
                                                                                                                            
                                                                                                                            // Set the plot on renderer
                                                                                                                            renderer.setPlot(plot);
                                                                                                                            
                                                                                                                            // Execute test
                                                                                                                            LegendItemCollection result = renderer.getLegendItems();
                                                                                                                            
                                                                                                                            // Verify results
                                                                                                                            assertNotNull("Result should not be null", result);
                                                                                                                            assertEquals("Should contain one legend item", 1, result.getItemCount());
                                                                                                                            
                                                                                                                            // Additional verification to ensure dataset was processed
                                                                                                                            verify(dataset).getRowCount();
                                                                                                                        }

    @Test
                                                                                                                public void testGetLegendItemsReturnsOriginalCollectionWhenPlotIsNull() {
                                                                                                                    // Setup
                                                                                                                    AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                        // Anonymous subclass for testing - implementing required abstract method
                                                                                                                        @Override
                                                                                                                        public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                boolean selected, int pass) {
                                                                                                                            // Empty implementation for testing
                                                                                                                        }
                                                                                                                    };
                                                                                                                    
                                                                                                                    // Force plot to be null
                                                                                                                    renderer.setPlot(null);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    LegendItemCollection result = renderer.getLegendItems();
                                                                                                                    
                                                                                                                    // Verify we get back the exact same collection object that was created initially
                                                                                                                    // This will fail if the mutant returns new LegendItemCollection() instead
                                                                                                                    assertEquals("Should return the original collection instance when plot is null", 
                                                                                                                            result, renderer.getLegendItems());
                                                                                                                }

    @Test
                                                                                                                public void testGetLegendItemsReturnsOriginalCollectionWhenDatasetIsNull() {
                                                                                                                    // Setup
                                                                                                                    AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                                        // Anonymous subclass for testing
                                                                                                                        @Override
                                                                                                                        public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                                Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                                ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                                boolean selected, int pass) {
                                                                                                                            // Empty implementation for testing
                                                                                                                        }
                                                                                                                    };
                                                                                                                    
                                                                                                                    // Mock plot and its behavior
                                                                                                                    CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                                    when(plot.getIndexOf(any())).thenReturn(0);
                                                                                                                    when(plot.getDataset(0)).thenReturn(null);
                                                                                                                    
                                                                                                                    renderer.setPlot(plot);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    LegendItemCollection result = renderer.getLegendItems();
                                                                                                                    
                                                                                                                    // Verify we get back the exact same collection object that was created initially
                                                                                                                    // This will fail if the mutant returns new LegendItemCollection() instead
                                                                                                                    assertEquals("Should return the original collection instance when dataset is null", 
                                                                                                                            result, renderer.getLegendItems());
                                                                                                                }

    @Test
                                                                                                    public void testGetLegendItemsWithNonEmptyDatasetShouldReturnNonEmptyCollection() {
                                                                                                        // Setup test data
                                                                                                        AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                            @Override
                                                                                                            public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                                return new LegendItem("Series " + series);
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public boolean isSeriesVisibleInLegend(int series) {
                                                                                                                return true;
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                                    Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                                    ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                                    boolean selected, int pass) {
                                                                                                                // Empty implementation for test purposes
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Mock dependencies
                                                                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                        
                                                                                                        // Configure mocks
                                                                                                        when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                        when(plot.getDataset(0)).thenReturn(dataset);
                                                                                                        when(dataset.getRowCount()).thenReturn(3); // Dataset has 3 rows
                                                                                                        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                        
                                                                                                        // Set the plot
                                                                                                        renderer.setPlot(plot);
                                                                                                        
                                                                                                        // Execute test
                                                                                                        LegendItemCollection result = renderer.getLegendItems();
                                                                                                        
                                                                                                        // Verify results - original should have 3 items, mutant will have 0
                                                                                                        assertEquals("Legend item count should match dataset row count", 3, result.getItemCount());
                                                                                                        
                                                                                                        // Verify mock interactions
                                                                                                        verify(dataset).getRowCount();
                                                                                                        verify(plot).getRowRenderingOrder();
                                                                                                    }

    @Test
                                                                                            public void testGetLegendItemsDetectsRowCountMutation() {
                                                                                                // Setup test data
                                                                                                AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                                    @Override
                                                                                                    public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                        return new LegendItem("Series " + series);
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public boolean isSeriesVisibleInLegend(int series) {
                                                                                                        return true;
                                                                                                    }
                                                                                                    
                                                                                                    @Override
                                                                                                    public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                            Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                            ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                            boolean selected, int pass) {
                                                                                                        // Empty implementation for test purposes
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                // Create mock plot and dataset
                                                                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                                
                                                                                                // Configure mocks
                                                                                                when(plot.getDataset(anyInt())).thenReturn(dataset);
                                                                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                                when(dataset.getRowCount()).thenReturn(3); // Dataset has 3 rows
                                                                                                
                                                                                                // Set the plot
                                                                                                renderer.setPlot(plot);
                                                                                                
                                                                                                // Execute test
                                                                                                LegendItemCollection result = renderer.getLegendItems();
                                                                                                
                                                                                                // Verify results - mutant would return 0 items
                                                                                                assertEquals("Should return 3 legend items for 3-row dataset", 3, result.getItemCount());
                                                                                                
                                                                                                // Additional verification of items
                                                                                                for (int i = 0; i < 3; i++) {
                                                                                                    assertNotNull("Legend item should not be null", result.get(i));
                                                                                                    assertEquals("Series label should match", "Series " + i, result.get(i).getLabel());
                                                                                                }
                                                                                            }

    @Test
                                                                                    public void testGetLegendItems_DetectsRowCountVsColumnCountMutation() {
                                                                                        // Setup
                                                                                        AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                            @Override
                                                                                            public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                                return new LegendItem("Series " + series);
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public boolean isSeriesVisibleInLegend(int series) {
                                                                                                return true;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                                    Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                                    ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                                    boolean selected, int pass) {
                                                                                                // Empty implementation for testing purposes
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                                                        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                        when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                                        
                                                                                        // Create dataset with different row and column counts
                                                                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                        when(dataset.getRowCount()).thenReturn(3);    // 3 rows
                                                                                        when(dataset.getColumnCount()).thenReturn(5); // 5 columns
                                                                                        when(plot.getDataset(0)).thenReturn(dataset);
                                                                                        
                                                                                        renderer.setPlot(plot);
                                                                                        
                                                                                        // Execute
                                                                                        LegendItemCollection result = renderer.getLegendItems();
                                                                                        
                                                                                        // Verify - should be based on row count (3), not column count (5)
                                                                                        assertEquals(3, result.getItemCount());
                                                                                        
                                                                                        // Verify legend items correspond to row series
                                                                                        assertEquals("Series 0", result.get(0).getLabel());
                                                                                        assertEquals("Series 1", result.get(1).getLabel());
                                                                                        assertEquals("Series 2", result.get(2).getLabel());
                                                                                    }

    @Test
                                                                            public void testGetLegendItemsReturnsCollectionNotNullWhenValidInput() {
                                                                                // Setup test objects
                                                                                AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                                    @Override
                                                                                    public void drawItem(Graphics2D g2, CategoryItemRendererState state, 
                                                                                            Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis, 
                                                                                            ValueAxis rangeAxis, CategoryDataset dataset, int row, int column, 
                                                                                            boolean selected, int pass) {
                                                                                        // Empty implementation for test purposes
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public boolean isSeriesVisibleInLegend(int series) {
                                                                                        return true; // All series visible for this test
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                        return mock(LegendItem.class); // Return non-null legend item
                                                                                    }
                                                                                };
                                                                                
                                                                                // Mock dependencies
                                                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                                                
                                                                                // Configure mocks
                                                                                when(plot.getDataset(anyInt())).thenReturn(dataset);
                                                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                                                when(dataset.getRowCount()).thenReturn(2); // 2 series in dataset
                                                                                when(plot.getIndexOf(renderer)).thenReturn(0); // renderer index is 0
                                                                                
                                                                                // Set the plot
                                                                                renderer.setPlot(plot);
                                                                                
                                                                                // Execute test
                                                                                LegendItemCollection result = renderer.getLegendItems();
                                                                                
                                                                                // Verify results
                                                                                assertNotNull("LegendItemCollection should not be null", result);
                                                                                assertEquals("Should contain 2 legend items", 2, result.getItemCount());
                                                                            }

    @Test
                                                                    public void testGetLegendItems_DescendingOrder_IncludesFirstSeries() {
                                                                        // Setup test data
                                                                        AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                            @Override
                                                                            public boolean isSeriesVisibleInLegend(int series) {
                                                                                return true; // All series visible for this test
                                                                            }
                                                                            
                                                                            @Override
                                                                            public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                                return new LegendItem("Series " + series); // Return non-null items
                                                                            }
                                                                            
                                                                            @Override
                                                                            public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                                    Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                                    ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                                    boolean selected, int pass) {
                                                                                // Empty implementation for test purposes
                                                                            }
                                                                        };
                                                                        
                                                                        // Mock the plot and dataset
                                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                                                        
                                                                        // Configure mocks
                                                                        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.DESCENDING);
                                                                        when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                        when(plot.getDataset(0)).thenReturn(dataset);
                                                                        when(dataset.getRowCount()).thenReturn(2); // Test with 2 series
                                                                        
                                                                        // Set the plot on renderer
                                                                        renderer.setPlot(plot);
                                                                        
                                                                        // Execute
                                                                        LegendItemCollection result = renderer.getLegendItems();
                                                                        
                                                                        // Verify - should contain items for both series (1 and 0)
                                                                        assertEquals(2, result.getItemCount());
                                                                        
                                                                        // Specifically check that series 0 is included (would be missed by mutant)
                                                                        boolean foundSeries0 = false;
                                                                        for (int i = 0; i < result.getItemCount(); i++) {
                                                                            if (result.get(i).getLabel().equals("Series 0")) {
                                                                                foundSeries0 = true;
                                                                                break;
                                                                            }
                                                                        }
                                                                        assertTrue("Legend items should contain series 0", foundSeries0);
                                                                    }

    @Test
                                                            public void testGetLegendItemsWithDescendingOrderShouldNotAccessInvalidIndex() {
                                                                // Setup
                                                                AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                                    @Override
                                                                    public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                        return new LegendItem("Series " + series);
                                                                    }
                                                                    
                                                                    @Override
                                                                    public boolean isSeriesVisibleInLegend(int series) {
                                                                        return true;
                                                                    }
                                                                    
                                                                    @Override
                                                                    public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                            Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                            ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                            boolean selected, int pass) {
                                                                        // Empty implementation for test purposes
                                                                    }
                                                                };
                                                                
                                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                                
                                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.DESCENDING);
                                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                                when(plot.getDataset(0)).thenReturn(dataset);
                                                                when(dataset.getRowCount()).thenReturn(3); // 3 series (indices 0,1,2)
                                                                
                                                                renderer.setPlot(plot);
                                                                
                                                                // Execute
                                                                LegendItemCollection result = renderer.getLegendItems();
                                                                
                                                                // Verify
                                                                assertEquals(3, result.getItemCount());
                                                                assertEquals("Series 2", result.get(0).getLabel());
                                                                assertEquals("Series 1", result.get(1).getLabel());
                                                                assertEquals("Series 0", result.get(2).getLabel());
                                                                
                                                                // The mutant would either:
                                                                // 1. Throw ArrayIndexOutOfBoundsException when trying to access series 3
                                                                // 2. Or include an extra invalid item if the dataset mock incorrectly handles index 3
                                                                // Either way, the test would fail for the mutant
                                                            }

    @Test
                                                    public void testGetLegendItems_SeriesVisibility() {
                                                        // Setup test data
                                                        AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                            @Override
                                                            public boolean isSeriesVisibleInLegend(int series) {
                                                                // Series 0: visible, Series 1: not visible
                                                                return series == 0;
                                                            }
                                                            
                                                            @Override
                                                            public LegendItem getLegendItem(int datasetIndex, int series) {
                                                                return new LegendItem("Series " + series);
                                                            }
                                                            
                                                            @Override
                                                            public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                                    Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                                    ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                                    boolean selected, int pass) {
                                                                // Empty implementation for testing purposes
                                                            }
                                                        };
                                                        
                                                        // Mock the plot and dataset
                                                        CategoryPlot plot = mock(CategoryPlot.class);
                                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                                        
                                                        // Configure mocks
                                                        when(plot.getIndexOf(renderer)).thenReturn(0);
                                                        when(plot.getDataset(0)).thenReturn(dataset);
                                                        when(dataset.getRowCount()).thenReturn(2); // 2 series
                                                        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                        
                                                        // Set the plot on renderer
                                                        renderer.setPlot(plot);
                                                        
                                                        // Execute
                                                        LegendItemCollection result = renderer.getLegendItems();
                                                        
                                                        // Verify
                                                        assertEquals(1, result.getItemCount()); // Only series 0 should be included
                                                        assertEquals("Series 0", result.get(0).getLabel());
                                                        
                                                        // Additional verification to catch the mutant
                                                        // The mutant would include series 1 instead of series 0
                                                        boolean containsSeries0 = false;
                                                        boolean containsSeries1 = false;
                                                        for (int i = 0; i < result.getItemCount(); i++) {
                                                            if ("Series 0".equals(result.get(i).getLabel())) {
                                                                containsSeries0 = true;
                                                            }
                                                            if ("Series 1".equals(result.get(i).getLabel())) {
                                                                containsSeries1 = true;
                                                            }
                                                        }
                                                        assertTrue(containsSeries0);
                                                        assertFalse(containsSeries1);
                                                    }

    @Test
                                            public void testGetLegendItems_OnlyIncludesVisibleSeries() {
                                                // Setup test data
                                                AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                                    @Override
                                                    public boolean isSeriesVisibleInLegend(int series) {
                                                        // Make series 0 visible, series 1 invisible
                                                        return series == 0;
                                                    }
                                                    
                                                    @Override
                                                    public LegendItem getLegendItem(int datasetIndex, int series) {
                                                        return new LegendItem("Series " + series);
                                                    }
                                                    
                                                    @Override
                                                    public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                            Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                            ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                            boolean selected, int pass) {
                                                        // Empty implementation for test purposes
                                                    }
                                                };
                                                
                                                // Mock the plot and dataset
                                                CategoryPlot plot = mock(CategoryPlot.class);
                                                CategoryDataset dataset = mock(CategoryDataset.class);
                                                
                                                // Configure mocks
                                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                                when(plot.getDataset(0)).thenReturn(dataset);
                                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                                when(dataset.getRowCount()).thenReturn(2); // 2 series
                                                
                                                // Set the plot on the renderer
                                                renderer.setPlot(plot);
                                                
                                                // Execute the method
                                                LegendItemCollection result = renderer.getLegendItems();
                                                
                                                // Verify results
                                                assertEquals("Should only contain visible series", 1, result.getItemCount());
                                                assertEquals("Should contain series 0", "Series 0", result.get(0).getLabel());
                                                
                                                // This assertion would fail with the mutant since the mutant would return 2 items
                                                // (both series 0 and 1) instead of just 1 (series 0)
                                            }

    @Test
                                    public void testGetLegendItems_VerifyLegendItemParameters() {
                                        // Setup
                                        AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                            // Override getLegendItem to verify parameters
                                            @Override
                                            public LegendItem getLegendItem(int datasetIndex, int series) {
                                                // Verify parameters are passed correctly (should be index, i)
                                                assertEquals(1, datasetIndex);  // Expected dataset index
                                                assertTrue(series == 0 || series == 1);  // Expected series indices
                                                return new LegendItem("Series " + series);
                                            }
                                            
                                            @Override
                                            public boolean isSeriesVisibleInLegend(int series) {
                                                return true;  // Make all series visible for testing
                                            }
                                            
                                            // Implement required abstract method
                                            @Override
                                            public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                                    Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                                    ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                                    boolean selected, int pass) {
                                                // Empty implementation for testing
                                            }
                                        };
                                        
                                        CategoryPlot plot = mock(CategoryPlot.class);
                                        when(plot.getIndexOf(renderer)).thenReturn(1);  // Set index to 1
                                        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                        
                                        CategoryDataset dataset = mock(CategoryDataset.class);
                                        when(dataset.getRowCount()).thenReturn(2);  // 2 series
                                        when(plot.getDataset(1)).thenReturn(dataset);  // Return dataset for index 1
                                        
                                        renderer.setPlot(plot);
                                        
                                        // Execute
                                        LegendItemCollection result = renderer.getLegendItems();
                                        
                                        // Verify
                                        assertEquals(2, result.getItemCount());  // Should have 2 legend items
                                        // The assertions in getLegendItem override will verify parameters
                                    }

    @Test
                            public void testGetLegendItemsShouldReturnNonEmptyCollectionWhenSeriesVisible() {
                                // Setup test data
                                AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                                    @Override
                                    public boolean isSeriesVisibleInLegend(int series) {
                                        return true; // Make all series visible for this test
                                    }
                                    
                                    @Override
                                    public LegendItem getLegendItem(int datasetIndex, int series) {
                                        return new LegendItem("Test"); // Return actual legend item
                                    }
                                    
                                    @Override
                                    public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                            Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                            ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                            boolean selected, int pass) {
                                        // Empty implementation for test purposes
                                    }
                                };
                                
                                // Mock dependencies
                                CategoryPlot plot = mock(CategoryPlot.class);
                                CategoryDataset dataset = mock(CategoryDataset.class);
                                
                                // Configure mocks
                                when(plot.getDataset(anyInt())).thenReturn(dataset);
                                when(plot.getIndexOf(renderer)).thenReturn(0);
                                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                                when(dataset.getRowCount()).thenReturn(1); // One series
                                
                                // Set the plot
                                renderer.setPlot(plot);
                                
                                // Execute and verify
                                LegendItemCollection result = renderer.getLegendItems();
                                assertNotNull("Result should not be null", result);
                                assertEquals("Should contain one legend item", 1, result.getItemCount());
                            }

    @Test
                    public void testGetLegendItems_ShouldOnlyAddNonNullItems() {
                        // Setup test data
                        AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                            @Override
                            public LegendItem getLegendItem(int datasetIndex, int series) {
                                // Return null for even series, non-null for odd
                                return series % 2 == 0 ? null : new LegendItem("Series " + series);
                            }
                        
                            @Override
                            public boolean isSeriesVisibleInLegend(int series) {
                                // All series are visible for this test
                                return true;
                            }
                            
                            @Override
                            public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                                    Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                                    ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                                    boolean selected, int pass) {
                                // Empty implementation for test purposes
                            }
                        };
                    
                        // Mock the plot and dataset
                        CategoryPlot plot = mock(CategoryPlot.class);
                        CategoryDataset dataset = mock(CategoryDataset.class);
                        
                        // Configure mocks
                        when(plot.getIndexOf(renderer)).thenReturn(0);
                        when(plot.getDataset(0)).thenReturn(dataset);
                        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                        when(dataset.getRowCount()).thenReturn(4); // 4 series
                        
                        // Set the plot
                        renderer.setPlot(plot);
                        
                        // Execute
                        LegendItemCollection result = renderer.getLegendItems();
                        
                        // Verify - should only contain items for series 1 and 3 (non-null)
                        assertEquals(2, result.getItemCount());
                        
                        // Verify the correct items were added
                        List<LegendItem> items = new ArrayList<>();
                        for (int i = 0; i < result.getItemCount(); i++) {
                            items.add(result.get(i));
                        }
                        
                        assertTrue(items.stream().anyMatch(item -> item.getLabel().equals("Series 1")));
                        assertTrue(items.stream().anyMatch(item -> item.getLabel().equals("Series 3")));
                        
                        // This test will fail with the mutant because:
                        // - Original: adds 2 items (series 1 and 3)
                        // - Mutant: would add 2 items (series 0 and 2) which are null
                        //   (but since we can't add null to LegendItemCollection, it might add 0 items)
                    }

    @Test
            public void testGetLegendItemsShouldNotAddNullLegendItems() {
                // Setup test objects
                AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
                    @Override
                    public boolean isSeriesVisibleInLegend(int series) {
                        return true; // All series visible for this test
                    }
                    
                    @Override
                    public LegendItem getLegendItem(int datasetIndex, int series) {
                        return null; // Return null to test null handling
                    }
                    
                    @Override
                    public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                            Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                            ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                            boolean selected, int pass) {
                        // Empty implementation for test purposes
                    }
                };
                
                // Mock dependencies
                CategoryPlot plot = mock(CategoryPlot.class);
                CategoryDataset dataset = mock(CategoryDataset.class);
                
                // Configure mocks
                when(plot.getIndexOf(renderer)).thenReturn(0);
                when(plot.getDataset(0)).thenReturn(dataset);
                when(dataset.getRowCount()).thenReturn(2); // 2 series to test
                when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
                
                // Set the plot on renderer
                renderer.setPlot(plot);
                
                // Execute test
                LegendItemCollection result = renderer.getLegendItems();
                
                // Verify behavior - original should have 0 items, mutant would have 2
                assertEquals("LegendItemCollection should be empty when all legend items are null", 
                            0, result.getItemCount());
            }

    @Test
    public void testGetLegendItems_AddsNonNullLegendItems() {
        // Setup test data
        AbstractCategoryItemRenderer renderer = new AbstractCategoryItemRenderer() {
            @Override
            public LegendItem getLegendItem(int datasetIndex, int series) {
                return new LegendItem("Test Series");
            }
            
            @Override
            public boolean isSeriesVisibleInLegend(int series) {
                return true;
            }
            
            @Override
            public void drawItem(Graphics2D g2, CategoryItemRendererState state,
                    Rectangle2D dataArea, CategoryPlot plot, CategoryAxis domainAxis,
                    ValueAxis rangeAxis, CategoryDataset dataset, int row, int column,
                    boolean selected, int pass) {
                // Empty implementation for test purposes
            }
        };
        
        // Mock required objects
        CategoryPlot plot = mock(CategoryPlot.class);
        CategoryDataset dataset = mock(CategoryDataset.class);
        
        // Configure mocks
        when(plot.getDataset(anyInt())).thenReturn(dataset);
        when(plot.getIndexOf(renderer)).thenReturn(0);
        when(plot.getRowRenderingOrder()).thenReturn(SortOrder.ASCENDING);
        when(dataset.getRowCount()).thenReturn(1);
        
        // Set the plot
        renderer.setPlot(plot);
        
        // Execute method
        LegendItemCollection result = renderer.getLegendItems();
        
        // Verify results
        assertNotNull("LegendItemCollection should not be null", result);
        assertEquals("Should contain one item", 1, result.getItemCount());
        
        // This assertion will catch the mutant - verify the item is not null
        LegendItem item = result.get(0);
        assertNotNull("LegendItem in collection should not be null", item);
        assertEquals("LegendItem should have correct label", "Test Series", item.getLabel());
    }


}
