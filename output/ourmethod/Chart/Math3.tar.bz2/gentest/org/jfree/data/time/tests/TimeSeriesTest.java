package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.event.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                    public void testCreateCopy_StartNegative() throws CloneNotSupportedException {
                                                                                                                                                                        // Setup
                                                                                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                        
                                                                                                                                                                        // Expect exception
                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                        thrown.expectMessage("Requires start >= 0.");
                                                                                                                                                                        
                                                                                                                                                                        // Execute
                                                                                                                                                                        series.createCopy(-1, 0);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testCreateCopy_EmptyRange_EndBeforeStartIndex() throws CloneNotSupportedException {
                                                                                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                        RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                                        RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                                        
                                                                                                                                                                        // Add some data to the series
                                                                                                                                                                        series.add(mock(RegularTimePeriod.class), 10.0);
                                                                                                                                                                        series.add(mock(RegularTimePeriod.class), 20.0);
                                                                                                                                                                        
                                                                                                                                                                        // Mock behavior where start index is after end index
                                                                                                                                                                        when(series.getIndex(start)).thenReturn(1); // start at index 1
                                                                                                                                                                        when(series.getIndex(end)).thenReturn(-1); // end before index 0
                                                                                                                                                                        when(start.compareTo(end)).thenReturn(-1);
                                                                                                                                                                        
                                                                                                                                                                        TimeSeries result = series.createCopy(start, end);
                                                                                                                                                                        assertNotNull(result);
                                                                                                                                                                        assertEquals(0, result.getItemCount());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testCreateCopy_EndNotInOriginalSeries() throws CloneNotSupportedException {
                                                                                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                        
                                                                                                                                                                        // Create mock time periods
                                                                                                                                                                        RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                                                                                                                                                        RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                                                                                                                                                        RegularTimePeriod endPeriod = mock(RegularTimePeriod.class);
                                                                                                                                                                        
                                                                                                                                                                        // Add data to the series
                                                                                                                                                                        series.add(period1, 10.0);
                                                                                                                                                                        series.add(period2, 20.0);
                                                                                                                                                                        
                                                                                                                                                                        // Mock behavior for getIndex
                                                                                                                                                                        when(series.getIndex(period1)).thenReturn(0);
                                                                                                                                                                        when(series.getIndex(endPeriod)).thenReturn(-3); // not in series
                                                                                                                                                                        when(period1.compareTo(endPeriod)).thenReturn(-1);
                                                                                                                                                                        
                                                                                                                                                                        // Mock the internal createCopy method that takes indices
                                                                                                                                                                        TimeSeries mockCopy = mock(TimeSeries.class);
                                                                                                                                                                        when(series.createCopy(0, 1)).thenReturn(mockCopy); // endIndex adjusted to 1
                                                                                                                                                                        
                                                                                                                                                                        TimeSeries result = series.createCopy(period1, endPeriod);
                                                                                                                                                                        assertSame(mockCopy, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testCreateCopy_StartNotInOriginalSeries() throws CloneNotSupportedException {
                                                                                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                        
                                                                                                                                                                        // Create mock time periods
                                                                                                                                                                        RegularTimePeriod startPeriod = mock(RegularTimePeriod.class);
                                                                                                                                                                        RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                                                                                                                                                        RegularTimePeriod period3 = mock(RegularTimePeriod.class);
                                                                                                                                                                        
                                                                                                                                                                        // Add data to the series
                                                                                                                                                                        series.add(period2, 20.0);
                                                                                                                                                                        series.add(period3, 30.0);
                                                                                                                                                                        
                                                                                                                                                                        // Mock behavior for getIndex
                                                                                                                                                                        when(series.getIndex(startPeriod)).thenReturn(-1); // not in series
                                                                                                                                                                        when(series.getIndex(period3)).thenReturn(1);
                                                                                                                                                                        when(startPeriod.compareTo(period3)).thenReturn(-1);
                                                                                                                                                                        
                                                                                                                                                                        // Mock the internal createCopy method that takes indices
                                                                                                                                                                        TimeSeries mockCopy = mock(TimeSeries.class);
                                                                                                                                                                        when(series.createCopy(0, 1)).thenReturn(mockCopy); // startIndex adjusted to 0
                                                                                                                                                                        
                                                                                                                                                                        TimeSeries result = series.createCopy(startPeriod, period3);
                                                                                                                                                                        assertSame(mockCopy, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                            public void testCreateCopy_SingleItemRange() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                // Setup
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                TimeSeriesDataItem item = mock(TimeSeriesDataItem.class);
                                                                                                                                                                when(item.clone()).thenReturn(item);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access the protected data field
                                                                                                                                                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                                                dataField.setAccessible(true);
                                                                                                                                                                List data = (List) dataField.get(series);
                                                                                                                                                                data.add(item);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                TimeSeries copy = series.createCopy(0, 0);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertNotNull(copy);
                                                                                                                                                                List copyData = (List) dataField.get(copy);
                                                                                                                                                                assertEquals(1, copyData.size());
                                                                                                                                                                assertEquals(item, copyData.get(0));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_EmptySeries() throws CloneNotSupportedException {
                                                                                                                                                                // Setup
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                TimeSeries copy = series.createCopy(0, 0);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertNotNull(copy);
                                                                                                                                                                assertEquals(0, copy.getItems().size());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_EndBeforeStart() throws CloneNotSupportedException {
                                                                                                                                                                // Setup
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                series.add(new TimeSeriesDataItem(new Day(), 1.0)); // Using add() instead of directly accessing data
                                                                                                                                                                
                                                                                                                                                                // Expect exception
                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                thrown.expectMessage("Requires start <= end.");
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                series.createCopy(1, 0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_IndexOutOfBounds() throws CloneNotSupportedException {
                                                                                                                                                                // Setup
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                series.add(new TimeSeriesDataItem(new Day(), 1.0)); // Using public add method instead of accessing data directly
                                                                                                                                                                
                                                                                                                                                                // Execute - should not throw exception for end > size, just copies what's available
                                                                                                                                                                TimeSeries copy = series.createCopy(0, 5);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(1, copy.getItemCount()); // Using public getItemCount() instead of accessing data.size()
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_CloneException() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                // Setup
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                TimeSeriesDataItem item = mock(TimeSeriesDataItem.class);
                                                                                                                                                                when(item.clone()).thenThrow(new CloneNotSupportedException());
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access the protected data field
                                                                                                                                                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                                                dataField.setAccessible(true);
                                                                                                                                                                List data = (List) dataField.get(series);
                                                                                                                                                                data.add(item);
                                                                                                                                                                
                                                                                                                                                                // Execute - should handle the exception internally
                                                                                                                                                                TimeSeries copy = series.createCopy(0, 0);
                                                                                                                                                                
                                                                                                                                                                // Verify - the item won't be added to the copy
                                                                                                                                                                assertEquals(0, copy.getItemCount());
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_EmptyRange_StartAfterLastItem() throws CloneNotSupportedException {
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                                RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                                
                                                                                                                                                                // Mock behavior for empty data list
                                                                                                                                                                when(series.getIndex(start)).thenReturn(-(series.getItems().size() + 1));
                                                                                                                                                                when(start.compareTo(end)).thenReturn(-1);
                                                                                                                                                                
                                                                                                                                                                TimeSeries result = series.createCopy(start, end);
                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                assertEquals(0, result.getItemCount());
                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testCreateCopy_ValidRange() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                        // Setup
                                                                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                        TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                                                                        TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                                                                        TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                                                                                                        
                                                                                                                                                        when(item1.clone()).thenReturn(item1);
                                                                                                                                                        when(item2.clone()).thenReturn(item2);
                                                                                                                                                        when(item3.clone()).thenReturn(item3);
                                                                                                                                                        
                                                                                                                                                        // Get the data field using reflection and add items
                                                                                                                                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                                        dataField.setAccessible(true);
                                                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                                                        List<TimeSeriesDataItem> data = (List<TimeSeriesDataItem>) dataField.get(series);
                                                                                                                                                        data.add(item1);
                                                                                                                                                        data.add(item2);
                                                                                                                                                        data.add(item3);
                                                                                                                                                        
                                                                                                                                                        // Execute
                                                                                                                                                        TimeSeries copy = series.createCopy(0, 1);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertNotNull(copy);
                                                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                                                        List<TimeSeriesDataItem> copyData = (List<TimeSeriesDataItem>) dataField.get(copy);
                                                                                                                                                        assertEquals(2, copyData.size());
                                                                                                                                                        
                                                                                                                                                        assertEquals(item1, copyData.get(0));
                                                                                                                                                        assertEquals(item2, copyData.get(1));
                                                                                                                                                        
                                                                                                                                                        Field minYField = TimeSeries.class.getDeclaredField("minY");
                                                                                                                                                        minYField.setAccessible(true);
                                                                                                                                                        double minY = minYField.getDouble(copy);
                                                                                                                                                        assertTrue(Double.isNaN(minY));
                                                                                                                                                        
                                                                                                                                                        Field maxYField = TimeSeries.class.getDeclaredField("maxY");
                                                                                                                                                        maxYField.setAccessible(true);
                                                                                                                                                        double maxY = maxYField.getDouble(copy);
                                                                                                                                                        assertTrue(Double.isNaN(maxY));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testCreateCopy_SeriesExceptionDuringAdd() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                        // Setup
                                                                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                        TimeSeriesDataItem item = mock(TimeSeriesDataItem.class);
                                                                                                                                                        TimeSeriesDataItem clone = mock(TimeSeriesDataItem.class);
                                                                                                                                                        when(item.clone()).thenReturn(clone);
                                                                                                                                                        
                                                                                                                                                        // Mock the copy to throw exception when adding
                                                                                                                                                        TimeSeries spySeries = spy(series);
                                                                                                                                                        TimeSeries copy = mock(TimeSeries.class);
                                                                                                                                                        when(spySeries.createCopy(anyInt(), anyInt())).thenCallRealMethod();
                                                                                                                                                        when(spySeries.clone()).thenReturn(copy);
                                                                                                                                                        doThrow(new RuntimeException("Test exception")).when(copy).add(any(TimeSeriesDataItem.class));
                                                                                                                                                        
                                                                                                                                                        // Use reflection to access protected data field
                                                                                                                                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                                        dataField.setAccessible(true);
                                                                                                                                                        List data = (List) dataField.get(spySeries);
                                                                                                                                                        data.add(item);
                                                                                                                                                        
                                                                                                                                                        // Execute - should handle the exception internally
                                                                                                                                                        TimeSeries result = spySeries.createCopy(0, 0);
                                                                                                                                                        
                                                                                                                                                        // Verify - the copy should still be returned
                                                                                                                                                        assertNotNull(result);
                                                                                                                                                        verify(copy).add(clone);
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testCreateCopy_ValidRange1() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                    // Setup
                                                                                                                                                    TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                    TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                                                                    TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                                                                    TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                                                                                                    
                                                                                                                                                    when(item1.clone()).thenReturn(item1);
                                                                                                                                                    when(item2.clone()).thenReturn(item2);
                                                                                                                                                    when(item3.clone()).thenReturn(item3);
                                                                                                                                                    
                                                                                                                                                    // Get the data field using reflection and add items
                                                                                                                                                    Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                                    dataField.setAccessible(true);
                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                    List<TimeSeriesDataItem> data = (List<TimeSeriesDataItem>) dataField.get(series);
                                                                                                                                                    data.add(item1);
                                                                                                                                                    data.add(item2);
                                                                                                                                                    data.add(item3);
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    TimeSeries copy = series.createCopy(0, 1);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(copy);
                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                    List<TimeSeriesDataItem> copyData = (List<TimeSeriesDataItem>) dataField.get(copy);
                                                                                                                                                    assertEquals(2, copyData.size());
                                                                                                                                                    
                                                                                                                                                    assertEquals(item1, copyData.get(0));
                                                                                                                                                    assertEquals(item2, copyData.get(1));
                                                                                                                                                    
                                                                                                                                                    Field minYField = TimeSeries.class.getDeclaredField("minY");
                                                                                                                                                    minYField.setAccessible(true);
                                                                                                                                                    double minY = minYField.getDouble(copy);
                                                                                                                                                    assertTrue(Double.isNaN(minY));
                                                                                                                                                    
                                                                                                                                                    Field maxYField = TimeSeries.class.getDeclaredField("maxY");
                                                                                                                                                    maxYField.setAccessible(true);
                                                                                                                                                    double maxY = maxYField.getDouble(copy);
                                                                                                                                                    assertTrue(Double.isNaN(maxY));
                                                                                                                                                }

    @Test
                                                                                                                                            public void testCreateCopy_NullStartArgument() throws CloneNotSupportedException {
                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                
                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                thrown.expectMessage("Null 'start' argument.");
                                                                                                                                                series.createCopy(null, end);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testCreateCopy_NullEndArgument() throws CloneNotSupportedException {
                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                
                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                thrown.expectMessage("Null 'end' argument.");
                                                                                                                                                series.createCopy(start, null);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testCreateCopy_StartAfterEnd() throws CloneNotSupportedException {
                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                
                                                                                                                                                when(start.compareTo(end)).thenReturn(1);
                                                                                                                                                
                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                thrown.expectMessage("Requires start on or before end.");
                                                                                                                                                series.createCopy(start, end);
                                                                                                                                            }

    @Test
                                                                                                                            public void testCreateCopyInitializesMinYAsNaN() {
                                                                                                                                // Setup original TimeSeries with some data
                                                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                                                
                                                                                                                                // Create mock items and add them to original series using public methods
                                                                                                                                TimeSeriesDataItem mockItem1 = mock(TimeSeriesDataItem.class);
                                                                                                                                when(mockItem1.getValue()).thenReturn(1.0);
                                                                                                                                
                                                                                                                                TimeSeriesDataItem mockItem2 = mock(TimeSeriesDataItem.class);
                                                                                                                                when(mockItem2.getValue()).thenReturn(2.0);
                                                                                                                                
                                                                                                                                original.add(mockItem1);
                                                                                                                                original.add(mockItem2);
                                                                                                                                
                                                                                                                                // Create copy
                                                                                                                                TimeSeries copy = null;
                                                                                                                                try {
                                                                                                                                    copy = original.createCopy(0, 1);
                                                                                                                                } catch (CloneNotSupportedException e) {
                                                                                                                                    fail("CloneNotSupportedException should not be thrown");
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Verify minY is initialized as NaN (not POSITIVE_INFINITY)
                                                                                                                                assertTrue("minY should be initialized as NaN", 
                                                                                                                                          Double.isNaN(copy.getMinY()));
                                                                                                                                
                                                                                                                                // Also verify maxY for completeness
                                                                                                                                assertTrue("maxY should be initialized as NaN",
                                                                                                                                          Double.isNaN(copy.getMaxY()));
                                                                                                                            }

    @Test
                                                                                                                            public void testCreateCopyWithEmptyRangeShouldHaveNaNMinY() throws CloneNotSupportedException {
                                                                                                                                // Setup - create a time series with some data
                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                org.jfree.data.time.Day start = new org.jfree.data.time.Day(1, 1, 2000); // fixed day
                                                                                                                                org.jfree.data.time.Day end = new org.jfree.data.time.Day(2, 1, 2000); // next day
                                                                                                                                
                                                                                                                                // Force empty range by setting start after last data item
                                                                                                                                start = new org.jfree.data.time.Day(11, 1, 2000);
                                                                                                                                end = new org.jfree.data.time.Day(12, 1, 2000);
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                TimeSeries copy = series.createCopy(start, end);
                                                                                                                                
                                                                                                                                // Verify - check minY is NaN for empty series
                                                                                                                                assertEquals(Double.NaN, copy.getMinY(), 0.0001);
                                                                                                                                
                                                                                                                                // Additional verification that the copy is indeed empty
                                                                                                                                assertEquals(0, copy.getItemCount());
                                                                                                                            }

    @Test
                                                                                                            public void testCreateCopyResetsMinYToNaN() {
                                                                                                                // Setup - create a TimeSeries with some data
                                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                                original.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
                                                                                                                original.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0));
                                                                                                                
                                                                                                                try {
                                                                                                                    // Exercise - create a copy
                                                                                                                    TimeSeries copy = original.createCopy(0, 1);
                                                                                                                    
                                                                                                                    // Verify - minY should be NaN (needs recalculation)
                                                                                                                    // This will catch the mutant that sets minY to 0.0
                                                                                                                    assertTrue("minY should be NaN after copy creation", 
                                                                                                                              Double.isNaN(copy.getMinY()));
                                                                                                                    
                                                                                                                    // Additional verification that maxY is also NaN
                                                                                                                    assertTrue("maxY should be NaN after copy creation",
                                                                                                                              Double.isNaN(copy.getMaxY()));
                                                                                                                } catch (CloneNotSupportedException e) {
                                                                                                                    fail("CloneNotSupportedException should not be thrown: " + e.getMessage());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testCreateCopyWithEmptyRangeShouldHaveNaNMinY1() {
                                                                                                                // Setup
                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                
                                                                                                                // Stub behavior to create empty range scenario
                                                                                                                when(start.compareTo(end)).thenReturn(-1); // start < end
                                                                                                                when(series.getIndex(start)).thenReturn(-(series.getItems().size() + 1)); // start after last item
                                                                                                                
                                                                                                                // Execute
                                                                                                                TimeSeries copy = null;
                                                                                                                try {
                                                                                                                    copy = series.createCopy(start, end);
                                                                                                                } catch (CloneNotSupportedException e) {
                                                                                                                    fail("CloneNotSupportedException was thrown: " + e.getMessage());
                                                                                                                }
                                                                                                                
                                                                                                                // Verify
                                                                                                                assertTrue("Copied series should be empty", copy.getItemCount() == 0);
                                                                                                                assertTrue("minY should be NaN for empty series", 
                                                                                                                           Double.isNaN(copy.getMinY()));
                                                                                                            }

    @Test
                                                                                                        public void testCreateCopyEmptyRangeMaxY() throws CloneNotSupportedException {
                                                                                                            // Create a time series with some data
                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                            Day day1 = new Day(1, 1, 2000);
                                                                                                            series.add(day1, 100.0);
                                                                                                            
                                                                                                            // Create a start period that's after all data (will result in empty range)
                                                                                                            Day start = new Day(2, 1, 2000);
                                                                                                            Day end = new Day(3, 1, 2000);
                                                                                                            
                                                                                                            // Create the copy
                                                                                                            TimeSeries copy = series.createCopy(start, end);
                                                                                                            
                                                                                                            // Verify maxY is NaN (original behavior)
                                                                                                            // This will catch the mutant which sets it to Double.NEGATIVE_INFINITY
                                                                                                            assertTrue("maxY should be NaN for empty range copy", 
                                                                                                                       Double.isNaN(copy.getMaxY()));
                                                                                                            
                                                                                                            // Also verify minY is NaN for completeness
                                                                                                            assertTrue("minY should be NaN for empty range copy",
                                                                                                                       Double.isNaN(copy.getMinY()));
                                                                                                            
                                                                                                            // Verify the copy is indeed empty
                                                                                                            assertEquals("Empty range copy should have 0 items", 
                                                                                                                         0, copy.getItemCount());
                                                                                                        }

    @Test
                                                                                                    public void testCreateCopyMaxYInitialization() throws Exception {
                                                                                                        // Setup original time series with some data
                                                                                                        TimeSeries original = new TimeSeries("Test Series");
                                                                                                        
                                                                                                        // Create mock items and add them to the series using public methods
                                                                                                        TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                        TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                        
                                                                                                        // Use reflection to get the value from the mock items since we can't directly set them
                                                                                                        when(item1.getValue()).thenReturn(1.0);
                                                                                                        when(item2.getValue()).thenReturn(2.0);
                                                                                                        
                                                                                                        // Add items to original series using public method
                                                                                                        original.add(item1);
                                                                                                        original.add(item2);
                                                                                                        
                                                                                                        // Create copy
                                                                                                        TimeSeries copy = original.createCopy(0, 1);
                                                                                                        
                                                                                                        // Verify maxY was initialized to NaN, not NEGATIVE_INFINITY
                                                                                                        assertEquals("maxY should be initialized to NaN", 
                                                                                                                    Double.NaN, copy.getMaxY(), 0.0001);
                                                                                                        
                                                                                                        // Additional verification that minY is also NaN for completeness
                                                                                                        assertEquals("minY should be initialized to NaN",
                                                                                                                    Double.NaN, copy.getMinY(), 0.0001);
                                                                                                    }

    @Test
                                                                                                    public void testCreateCopyResetsMaxYToNaN() throws Exception {
                                                                                                        // Setup original TimeSeries with some data
                                                                                                        TimeSeries original = new TimeSeries("Test Series");
                                                                                                        TimeSeriesDataItem mockItem1 = mock(TimeSeriesDataItem.class);
                                                                                                        TimeSeriesDataItem mockItem2 = mock(TimeSeriesDataItem.class);
                                                                                                        when(mockItem1.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                        when(mockItem2.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                        
                                                                                                        // Add items to original series (need to use reflection since data is protected)
                                                                                                        // Alternatively, we could use actual add methods if they're properly implemented
                                                                                                        java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                        dataField.setAccessible(true);
                                                                                                        List data = (List) dataField.get(original);
                                                                                                        data.add(mockItem1);
                                                                                                        data.add(mockItem2);
                                                                                                        
                                                                                                        // Also set original maxY to a known value
                                                                                                        java.lang.reflect.Field maxYField = TimeSeries.class.getDeclaredField("maxY");
                                                                                                        maxYField.setAccessible(true);
                                                                                                        maxYField.set(original, 100.0);
                                                                                                        
                                                                                                        // Create copy
                                                                                                        TimeSeries copy = original.createCopy(0, 1);
                                                                                                        
                                                                                                        // Verify maxY was reset to NaN (not 0.0)
                                                                                                        assertEquals(Double.NaN, copy.getMaxY(), 0.0001);
                                                                                                        
                                                                                                        // Additional verification that minY was also reset
                                                                                                        assertEquals(Double.NaN, copy.getMinY(), 0.0001);
                                                                                                    }

    @Test
                                                                                        public void testCreateCopyWithEmptyRangeShouldSetMaxYToNaN() {
                                                                                            // Setup
                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                            RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                            RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                            
                                                                                            // Mock behavior to create empty range scenario
                                                                                            when(start.compareTo(end)).thenReturn(-1); // start < end
                                                                                            when(series.getIndex(start)).thenReturn(-1); // indicates not found
                                                                                            
                                                                                            // Execute
                                                                                            TimeSeries copy = null;
                                                                                            try {
                                                                                                copy = series.createCopy(start, end);
                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                fail("CloneNotSupportedException should not be thrown");
                                                                                            }
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals("MaxY should be Double.NaN for empty range", 
                                                                                                         Double.NaN, copy.getMaxY(), 0.0001);
                                                                                            
                                                                                            // Additional checks for empty range behavior
                                                                                            assertEquals(0, copy.getItemCount());
                                                                                            assertEquals(0, copy.getItems().size()); // Using public method instead of accessing data directly
                                                                                        }

    @Test
                                                                                        public void testCreateCopyDataIsolation() throws Exception {
                                                                                            // Setup original TimeSeries with some data
                                                                                            TimeSeries original = new TimeSeries("Test Series");
                                                                                            TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                            TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                            TimeSeriesDataItem clonedItem1 = mock(TimeSeriesDataItem.class);
                                                                                            TimeSeriesDataItem clonedItem2 = mock(TimeSeriesDataItem.class);
                                                                                            
                                                                                            // Mock clone behavior
                                                                                            when(item1.clone()).thenReturn(clonedItem1);
                                                                                            when(item2.clone()).thenReturn(clonedItem2);
                                                                                            
                                                                                            // Add items to original (using reflection since data is protected)
                                                                                            java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                            dataField.setAccessible(true);
                                                                                            List<TimeSeriesDataItem> dataList = new ArrayList<>();
                                                                                            dataList.add(item1);
                                                                                            dataList.add(item2);
                                                                                            dataField.set(original, dataList);
                                                                                            
                                                                                            // Create copy
                                                                                            TimeSeries copy = original.createCopy(0, 1);
                                                                                            
                                                                                            // Verify copy has its own independent data list
                                                                                            List<TimeSeriesDataItem> copyData = (List<TimeSeriesDataItem>) dataField.get(copy);
                                                                                            assertNotSame("Copy should have its own data list", dataList, copyData);
                                                                                            
                                                                                            // Modify copy's data and verify original is unaffected
                                                                                            copyData.clear();
                                                                                            List<TimeSeriesDataItem> originalData = (List<TimeSeriesDataItem>) dataField.get(original);
                                                                                            assertEquals("Original data should remain unchanged", 2, originalData.size());
                                                                                        }

    @Test
                                                                                public void testCreateCopyWithEmptyRangeShouldReturnIndependentEmptyCopy() throws Exception {
                                                                                    // Setup - create a time series with some data
                                                                                    TimeSeries originalSeries = new TimeSeries("Test Series");
                                                                                    RegularTimePeriod start = new Day(); // mock or real implementation
                                                                                    RegularTimePeriod end = new Day();   // mock or real implementation
                                                                                    
                                                                                    // Force emptyRange=true by making start after end
                                                                                    // We need to make sure startIndex would be >= data.size()
                                                                                    // and endIndex would be < startIndex
                                                                                    // This can be achieved by having empty data and specific start/end
                                                                                    
                                                                                    // Mock getIndex() behavior to simulate empty range condition
                                                                                    TimeSeries spySeries = spy(originalSeries);
                                                                                    when(spySeries.getIndex(any(RegularTimePeriod.class))).thenReturn(-1);
                                                                                    
                                                                                    // Execute
                                                                                    TimeSeries copy = spySeries.createCopy(start, end);
                                                                                    
                                                                                    // Verify the copy is independent
                                                                                    // 1. Original data should be empty (since we didn't add any)
                                                                                    assertEquals(0, originalSeries.getItemCount());
                                                                                    
                                                                                    // 2. Copy's data should be empty (original behavior)
                                                                                    assertEquals(0, copy.getItemCount());
                                                                                    
                                                                                    // 3. Modifying copy shouldn't affect original
                                                                                    copy.add(new Day(), 1.0);
                                                                                    assertEquals(0, originalSeries.getItemCount()); // Would fail if mutant survives
                                                                                    assertEquals(1, copy.getItemCount());
                                                                                    
                                                                                    // 4. Verify data references are different (using reflection)
                                                                                    Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                    dataField.setAccessible(true);
                                                                                    List<?> originalData = (List<?>) dataField.get(originalSeries);
                                                                                    List<?> copyData = (List<?>) dataField.get(copy);
                                                                                    assertNotSame(originalData, copyData); // Would fail if mutant survives
                                                                                }

    @Test
                                                                            public void testCreateCopyIncludesEndIndex() throws CloneNotSupportedException {
                                                                                // Setup test data
                                                                                TimeSeries series = new TimeSeries("Test");
                                                                                Day day1 = new Day(1, 1, 2000);
                                                                                Day day2 = new Day(2, 1, 2000);
                                                                                series.add(day1, 100.0);
                                                                                series.add(day2, 200.0);
                                                                                
                                                                                // Execute copy operation
                                                                                TimeSeries copy = series.createCopy(day1, day2);
                                                                                
                                                                                // Verify the copy includes both items
                                                                                assertEquals(2, copy.getItemCount());
                                                                                assertEquals(100.0, copy.getValue(0).doubleValue(), 0.0001);
                                                                                assertEquals(200.0, copy.getValue(1).doubleValue(), 0.0001);
                                                                                
                                                                                // Specifically verify the end item is included
                                                                                assertEquals(day2, copy.getTimePeriod(1));
                                                                                assertEquals(200.0, copy.getValue(day2).doubleValue(), 0.0001);
                                                                            }

    @Test
                                                                    public void testCreateCopyRangeInclusion() throws SeriesException, CloneNotSupportedException {
                                                                        // Setup test data
                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                        TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                        TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                        TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                        
                                                                        // Mock clone behavior
                                                                        when(item1.clone()).thenReturn(item1);
                                                                        when(item2.clone()).thenReturn(item2);
                                                                        when(item3.clone()).thenReturn(item3);
                                                                        
                                                                        // Add items to series using public methods
                                                                        series.add(item1);
                                                                        series.add(item2);
                                                                        series.add(item3);
                                                                        
                                                                        // Test copying a range of 2 items (indices 0 to 1)
                                                                        TimeSeries copy = series.createCopy(0, 1);
                                                                        
                                                                        // Verify correct number of items were copied
                                                                        // Original should copy 2 items (0 and 1), mutant would only copy 1 (0)
                                                                        assertEquals("Should copy 2 items when end=1", 2, copy.getItemCount());
                                                                        
                                                                        // Test boundary case where start=0, end=2 (all 3 items)
                                                                        TimeSeries fullCopy = series.createCopy(0, 2);
                                                                        assertEquals("Should copy all 3 items", 3, fullCopy.getItemCount());
                                                                        
                                                                        // Test single item copy case (start == end)
                                                                        TimeSeries singleCopy = series.createCopy(1, 1);
                                                                        assertEquals("Should copy exactly 1 item", 1, singleCopy.getItemCount());
                                                                    }

    @Test
                                                            public void testCreateCopyMaintainsItemOrder() throws Exception {
                                                                // Setup test data with 3 items having distinct values
                                                                TimeSeries series = new TimeSeries("Test");
                                                                TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                
                                                                // Add items to original series using proper methods
                                                                series.add(item1);
                                                                series.add(item2);
                                                                series.add(item3);
                                                                
                                                                // Create copy from index 0 to 2
                                                                TimeSeries copy = series.createCopy(0, 2);
                                                                
                                                                // Verify the order of items in the copy matches original order
                                                                assertEquals("First item should be item1", item1, copy.getDataItem(0));
                                                                assertEquals("Second item should be item2", item2, copy.getDataItem(1));
                                                                assertEquals("Third item should be item3", item3, copy.getDataItem(2));
                                                                
                                                                // Alternative verification by checking items in order
                                                                List items = copy.getItems();
                                                                assertEquals("First item should be item1", item1, items.get(0));
                                                                assertEquals("Second item should be item2", item2, items.get(1));
                                                                assertEquals("Third item should be item3", item3, items.get(2));
                                                            }

    @Test
                                                        public void testCreateCopyMaintainsElementOrder() throws CloneNotSupportedException {
                                                            // Setup test data
                                                            TimeSeries series = new TimeSeries("Test Series");
                                                            Day day1 = new Day(1, 1, 2000);
                                                            Day day2 = new Day(2, 1, 2000);
                                                            Day day3 = new Day(3, 1, 2000);
                                                            
                                                            series.add(day1, 1.0);
                                                            series.add(day2, 2.0);
                                                            series.add(day3, 3.0);
                                                            
                                                            // Call method under test
                                                            TimeSeries copy = series.createCopy(day1, day3);
                                                            
                                                            // Verify order is maintained (should fail if mutation is present)
                                                            assertEquals(day1, copy.getTimePeriod(0));
                                                            assertEquals(day2, copy.getTimePeriod(1));
                                                            assertEquals(day3, copy.getTimePeriod(2));
                                                            
                                                            // Also verify values are in correct order
                                                            assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                                                            assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                                                            assertEquals(3.0, copy.getValue(2).doubleValue(), 0.0001);
                                                            
                                                            // Verify size is correct
                                                            assertEquals(3, copy.getItemCount());
                                                        }

    @Test
                                                public void testCreateCopyWithEmptyRangeShouldHaveNaNMinY2() throws Exception {
                                                    // Setup
                                                    RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                    RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                    when(start.compareTo(end)).thenReturn(1); // start > end to trigger empty range
                                                    
                                                    TimeSeries originalSeries = new TimeSeries("Test Series");
                                                    // Add some data to ensure getIndex returns negative values
                                                    RegularTimePeriod period = mock(RegularTimePeriod.class);
                                                    originalSeries.add(period, 10.0);
                                                    
                                                    // Get the data size using reflection
                                                    Field dataField = TimeSeries.class.getDeclaredField("data");
                                                    dataField.setAccessible(true);
                                                    @SuppressWarnings("unchecked")
                                                    List<?> data = (List<?>) dataField.get(originalSeries);
                                                    int dataSize = data.size();
                                                    
                                                    // Mock getIndex behavior to simulate empty range
                                                    TimeSeries spySeries = spy(originalSeries);
                                                    when(spySeries.getIndex(start)).thenReturn(-(dataSize + 1));
                                                    when(spySeries.getIndex(end)).thenReturn(-1);
                                                    
                                                    // Test
                                                    TimeSeries copy = spySeries.createCopy(start, end);
                                                    
                                                    // Verify
                                                    assertEquals("Empty range copy should have NaN minY", 
                                                                 Double.NaN, 
                                                                 copy.getMinY(), 
                                                                 0.0001);
                                                    
                                                    // Additional verification that we're testing the right case
                                                    Field copyDataField = TimeSeries.class.getDeclaredField("data");
                                                    copyDataField.setAccessible(true);
                                                    @SuppressWarnings("unchecked")
                                                    List<?> copyData = (List<?>) copyDataField.get(copy);
                                                    assertTrue("Data should be empty", copyData.isEmpty());
                                                }

    @Test
                                            public void testCreateCopyMinYIsSetToNaN() {
                                                // Setup original TimeSeries with some data
                                                TimeSeries original = new TimeSeries("Test Series");
                                                original.add(new Day(1, 1, 2023), 10.0);
                                                original.add(new Day(2, 1, 2023), 20.0);
                                                
                                                // Create copy
                                                TimeSeries copy = null;
                                                try {
                                                    copy = original.createCopy(0, 1);
                                                } catch (CloneNotSupportedException e) {
                                                    fail("CloneNotSupportedException should not be thrown");
                                                }
                                                
                                                // Verify minY is set to NaN (original behavior)
                                                // This will fail if mutant is present (would be POSITIVE_INFINITY)
                                                assertTrue("minY should be NaN after copy creation", 
                                                          Double.isNaN(copy.getMinY()));
                                                
                                                // Also verify maxY for completeness
                                                assertTrue("maxY should be NaN after copy creation",
                                                          Double.isNaN(copy.getMaxY()));
                                            }

    @Test
                                    public void testCreateCopyResetsMinYToNaN1() throws Exception {
                                        // Setup original TimeSeries with some data
                                        TimeSeries original = new TimeSeries("Test Series");
                                        TimeSeriesDataItem mockItem1 = mock(TimeSeriesDataItem.class);
                                        TimeSeriesDataItem mockItem2 = mock(TimeSeriesDataItem.class);
                                        when(mockItem1.clone()).thenReturn(mockItem1);
                                        when(mockItem2.clone()).thenReturn(mockItem2);
                                        
                                        // Add items to original series using public methods
                                        // We need to mock the period and value for the items
                                        RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                        RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                        when(mockItem1.getPeriod()).thenReturn(period1);
                                        when(mockItem2.getPeriod()).thenReturn(period2);
                                        when(mockItem1.getValue()).thenReturn(1.0);
                                        when(mockItem2.getValue()).thenReturn(2.0);
                                        
                                        // Add the items to the series
                                        original.add(mockItem1);
                                        original.add(mockItem2);
                                        
                                        // Create copy
                                        TimeSeries copy = original.createCopy(0, 1);
                                        
                                        // Verify minY was reset to NaN (original behavior)
                                        // This will fail if mutant changes it to 0.0
                                        assertTrue("minY should be NaN after copy creation", 
                                                  Double.isNaN(copy.getMinY()));
                                        
                                        // Also verify maxY for completeness
                                        assertTrue("maxY should be NaN after copy creation",
                                                  Double.isNaN(copy.getMaxY()));
                                    }

    @Test
                                public void testCreateCopyWithEmptyRangeShouldSetMinYToNaN() {
                                    // Setup - create a time series with some data
                                    TimeSeries series = new TimeSeries("Test Series");
                                    RegularTimePeriod start = new Day(1, 1, 2023); // arbitrary dates
                                    RegularTimePeriod end = new Day(2, 1, 2023);
                                    
                                    // Force empty range by making start after the last data item
                                    // (no data added to series, so any range would be empty)
                                    
                                    // Execute
                                    TimeSeries copy = null;
                                    try {
                                        copy = series.createCopy(start, end);
                                    } catch (CloneNotSupportedException e) {
                                        fail("Unexpected CloneNotSupportedException");
                                    }
                                    
                                    // Verify - check minY is NaN (original behavior)
                                    // This will fail if mutation is present (would be 0.0)
                                    assertTrue("minY should be NaN for empty range", 
                                               Double.isNaN(copy.getMinY()));
                                    
                                    // Additional verification that the copy is indeed empty
                                    assertEquals(0, copy.getItemCount());
                                }

    @Test
                        public void testCreateCopyWithEmptyRange_ShouldSetMaxYToNaN() {
                            // Setup
                            TimeSeries series = new TimeSeries("Test Series");
                            RegularTimePeriod start = mock(RegularTimePeriod.class);
                            RegularTimePeriod end = mock(RegularTimePeriod.class);
                            
                            try {
                                // Get the data field using reflection
                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                dataField.setAccessible(true);
                                List<?> data = (List<?>) dataField.get(series);
                                
                                // Mock behavior to create empty range scenario
                                when(start.compareTo(end)).thenReturn(-1); // start < end
                                when(series.getIndex(start)).thenReturn(-(data.size() + 1)); // start after last item
                                
                                // Execute
                                TimeSeries copy = series.createCopy(start, end);
                                
                                // Verify
                                assertEquals("MaxY should be Double.NaN for empty range copy", 
                                            Double.NaN, copy.getMaxY(), 0.0001);
                                
                                // Additional verification that we're testing the right scenario
                                assertEquals(0, copy.getItemCount());
                            } catch (Exception e) {
                                fail("Exception occurred during test: " + e.getMessage());
                            }
                        }

    @Test
                    public void testCreateCopyInitializesMaxYAsNaN() {
                        // Setup
                        TimeSeries originalSeries = new TimeSeries("Test Series");
                        
                        // Add some data to ensure the copy path is executed
                        TimeSeriesDataItem mockItem = mock(TimeSeriesDataItem.class);
                        when(mockItem.clone()).thenReturn(mockItem);
                        
                        // Use reflection to access the protected data field
                        try {
                            Field dataField = TimeSeries.class.getDeclaredField("data");
                            dataField.setAccessible(true);
                            List data = (List) dataField.get(originalSeries);
                            data.add(mockItem);
                        } catch (NoSuchFieldException | IllegalAccessException e) {
                            fail("Failed to access protected data field: " + e.getMessage());
                        }
                        
                        // Execute
                        TimeSeries copy = null;
                        try {
                            copy = originalSeries.createCopy(0, 0);
                        } catch (CloneNotSupportedException e) {
                            fail("Clone not supported: " + e.getMessage());
                        }
                        
                        // Verify
                        // The key assertion - original should have NaN, mutant will have NEGATIVE_INFINITY
                        assertTrue("maxY should be initialized to Double.NaN", 
                                  Double.isNaN(copy.getMaxY()));
                        
                        // Additional sanity checks
                        assertTrue("minY should be initialized to Double.NaN",
                                  Double.isNaN(copy.getMinY()));
                        assertEquals("Data size should match copied range", 
                                   1, copy.getItemCount());
                    }

    @Test
                public void testCreateCopyEmptyRangeMaxY1() throws CloneNotSupportedException {
                    // Setup test data
                    TimeSeries series = new TimeSeries("Test Series");
                    series.add(new Day(1, 1, 2023), 10.0);  // Add some data
                    series.add(new Day(2, 1, 2023), 20.0);
                    
                    // Create parameters that will result in empty range
                    // Start after the last data item
                    RegularTimePeriod start = new Day(3, 1, 2023);
                    RegularTimePeriod end = new Day(4, 1, 2023);
                    
                    // Execute
                    TimeSeries copy = series.createCopy(start, end);
                    
                    // Verify maxY is NaN for empty range
                    assertEquals(Double.NaN, copy.getMaxY(), 0.0001);
                    
                    // Also verify the copy is empty
                    assertEquals(0, copy.getItemCount());
                }

    @Test
            public void testCreateCopyResetsMaxYToNaN1() {
                // Setup original TimeSeries with some data
                TimeSeries original = new TimeSeries("Test Series");
                TimeSeriesDataItem mockItem1 = mock(TimeSeriesDataItem.class);
                TimeSeriesDataItem mockItem2 = mock(TimeSeriesDataItem.class);
                when(mockItem1.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                when(mockItem2.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                
                // Add items to original series (need to use reflection or package visibility methods
                // since data is protected and we don't have direct access in test)
                // For testing purposes, we'll assume the data gets added properly
                
                // Create copy
                TimeSeries copy = null;
                try {
                    copy = original.createCopy(0, 1);
                } catch (CloneNotSupportedException e) {
                    fail("CloneNotSupportedException should not be thrown");
                }
                
                // Verify maxY was reset to NaN (original behavior)
                // This will fail if mutant is present (which sets maxY to 0.0)
                assertTrue("maxY should be Double.NaN after copy creation", 
                          Double.isNaN(copy.getMaxY()));
                
                // Additional verification that minY was also reset (though not mutated)
                assertTrue("minY should be Double.NaN after copy creation",
                          Double.isNaN(copy.getMinY()));
            }

    @Test
            public void testCreateCopyMaintainsOriginalOrder() throws SeriesException, CloneNotSupportedException {
                // Setup test data with 3 items
                TimeSeries original = new TimeSeries("Test");
                TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                
                // Setup clones to track order
                TimeSeriesDataItem clone1 = mock(TimeSeriesDataItem.class);
                TimeSeriesDataItem clone2 = mock(TimeSeriesDataItem.class);
                TimeSeriesDataItem clone3 = mock(TimeSeriesDataItem.class);
                
                when(item1.clone()).thenReturn(clone1);
                when(item2.clone()).thenReturn(clone2);
                when(item3.clone()).thenReturn(clone3);
                
                // Add items to original series
                original.add(item1);
                original.add(item2);
                original.add(item3);
                
                // Create copy from index 0 to 2
                TimeSeries copy = original.createCopy(0, 2);
                
                // Verify clones were created in correct order
                verify(item1, times(1)).clone();
                verify(item2, times(1)).clone();
                verify(item3, times(1)).clone();
                
                // Verify adds were called in correct order
                // This is the key assertion that will catch the mutant
                // We verify the order of add operations matches original order
                verify(copy).add(clone1);
                verify(copy).add(clone2);
                verify(copy).add(clone3);
                
                // Additional verification
                assertEquals(3, copy.getItemCount());
                assertTrue(Double.isNaN(copy.getMinY()));
                assertTrue(Double.isNaN(copy.getMaxY()));
            }

    @Test
    public void testCreateCopyPreservesItemOrder() throws CloneNotSupportedException {
        // Setup test data
        TimeSeries series = new TimeSeries("Test Series");
        Day day1 = new Day(1, 1, 2023);
        Day day2 = new Day(2, 1, 2023);
        Day day3 = new Day(3, 1, 2023);
        
        series.add(day1, 1.0);
        series.add(day2, 2.0);
        series.add(day3, 3.0);
        
        // Create copy
        TimeSeries copy = series.createCopy(day1, day3);
        
        // Verify order is preserved
        assertEquals("First item should be day1", day1, copy.getTimePeriod(0));
        assertEquals("Second item should be day2", day2, copy.getTimePeriod(1));
        assertEquals("Third item should be day3", day3, copy.getTimePeriod(2));
        
        // Verify values are correct
        assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
        assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
        assertEquals(3.0, copy.getValue(2).doubleValue(), 0.0001);
        
        // Verify size
        assertEquals(3, copy.getItemCount());
    }


}
